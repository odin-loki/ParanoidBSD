typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == (((wcaps & (7<<13)) >> 13) + 1) * 2; */

static inline    unsigned int snd_hdac_get_wcaps_channels(u32 wcaps)
{
 unsigned int chans;

 chans = (wcaps & (7<<13)) >> 13;
 chans = (chans + 1) * 2;

 return chans;
}
