typedef unsigned short __uint16_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __uint16_t uint16_t;
typedef __uint64_t uint64_t;
typedef __size_t size_t;
typedef uint64_t bus_addr_t;
static __inline char *
index(const char *p, int ch)
;
struct vnic_dev_ring {
 void *descs;
 size_t size;
 bus_addr_t base_addr;
 size_t base_align;
 void *descs_unaligned;
 size_t size_unaligned;
 bus_addr_t base_addr_unaligned;
 unsigned int desc_size;
 unsigned int desc_count;
 unsigned int desc_avail;
 unsigned int last_count;
 iflib_dma_info_t ifdip;
};
struct vnic_dev;
struct vnic_wq {
 unsigned int index;
 uint64_t tx_offload_notsup_mask;
 struct vnic_dev *vdev;
 struct vnic_res *ctrl;
 struct vnic_dev_ring ring;
 unsigned int head_idx;
 unsigned int cq_pend;
 unsigned int tail_idx;
 unsigned int socket_id;
 unsigned int processed;
 const struct rte_memzone *cqmsg_rz;
 uint16_t last_completed_index;
 uint64_t offloads;
};
/*@ requires wq->ring.desc_avail < wq->ring.desc_count; ensures \result == wq->ring.desc_count - wq->ring.desc_avail - 1; */

static inline unsigned int vnic_wq_desc_used(struct vnic_wq *wq)
{

 return wq->ring.desc_count - wq->ring.desc_avail - 1;
}
