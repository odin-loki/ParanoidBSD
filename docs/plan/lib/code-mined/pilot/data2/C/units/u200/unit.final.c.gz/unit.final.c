__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == (config | (1ULL << 63)); */

static inline    u64 p4_set_ht_bit(u64 config)
{
 return config | (1ULL << 63);
}
