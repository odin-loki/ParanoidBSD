typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef __u16 __be16;
typedef __u32 __be32;
typedef __u32 __wsum;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s32 int32_t;
typedef u32 uint32_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lock_class_key { };
struct lockdep_map { };
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;







} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct cacheline_padding {
 char x[1];
} ;
typedef __s64 time64_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
struct static_key_false {
 struct static_key key;
};
struct orc_entry {
 s16 sp_offset;
 s16 bp_offset;

 unsigned sp_reg:4;
 unsigned bp_reg:4;
 unsigned type:3;
 unsigned signal:1;







} __attribute__((__packed__));
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
struct task_struct;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct task_struct;
struct task_struct;
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;







};
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
struct device;
typedef struct cpumask { unsigned long bits[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 6)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct module;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct page;
struct vm_area_struct;
struct mm_struct;
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct optimistic_spin_queue {




 atomic_t tail;
};
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;
 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;







} rwlock_t;
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;






};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;




};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct task_struct;
struct mm_struct;
struct static_key;
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;



} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; ; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; ; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;





} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;







} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;
 struct task_group *sched_task_group;
 struct sched_statistics stats;







 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;
 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;
 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;






 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;
 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;






 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;






 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;






 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;
 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;
 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;
 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;
 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 unsigned long trace_recursion;
 struct gendisk *throttle_disk;



 struct uprobe_task *utask;





 struct kmap_ctrl kmap_ctrl;






 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;
 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;
 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct user_namespace;
struct uid_gid_map;
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct vm_area_struct;
struct file;
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct task_struct;
struct device;
struct page;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct task_struct;
struct maple_tree {
 union {
  spinlock_t ma_lock;



 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;






};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;



};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];



 long len;

 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[2 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct blocking_notifier_head {
 struct rw_semaphore rwsem;
 struct notifier_block *head;
};
struct raw_notifier_head {
 struct notifier_block *head;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;
 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct futex_private_hash;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;





  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;






 refcount_t vm_refcnt ;
 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;
 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;


  struct mutex futex_hash_lock;
  struct futex_private_hash *futex_phash;
  struct futex_private_hash *futex_phash_new;

  unsigned long futex_batches;
  struct callback_head futex_rcu;
  atomic_long_t futex_atomic;
  unsigned int *futex_ref;


  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;
 } ;





 unsigned long cpu_bitmap[1];
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct page;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct cred;
struct file;
struct rhash_head {
 struct rhash_head *next;
};
struct bucket_table;
struct rhashtable_compare_arg {
 struct rhashtable *ht;
 const void *key;
};
typedef u32 (*rht_hashfn_t)(const void *data, u32 len, u32 seed);
typedef u32 (*rht_obj_hashfn_t)(const void *data, u32 len, u32 seed);
typedef int (*rht_obj_cmpfn_t)(struct rhashtable_compare_arg *arg,
          const void *obj);
struct rhashtable_params {
 u16 nelem_hint;
 u16 key_len;
 u16 key_offset;
 u16 head_offset;
 unsigned int max_size;
 u16 min_size;
 bool automatic_shrinking;
 rht_hashfn_t hashfn;
 rht_obj_hashfn_t obj_hashfn;
 rht_obj_cmpfn_t obj_cmpfn;
};
struct rhashtable {
 struct bucket_table *tbl;
 unsigned int key_len;
 unsigned int max_elems;
 struct rhashtable_params p;
 bool rhlist;
 struct work_struct run_work;
 struct mutex mutex;
 spinlock_t lock;
 atomic_t nelems;



};
struct task_struct;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
typedef unsigned short __kernel_sa_family_t;
struct file;
struct pid;
struct cred;
struct sock;
struct sk_buff;
struct seq_file;
typedef __kernel_sa_family_t sa_family_t;
struct sockaddr {
 sa_family_t sa_family;
 union {
  char sa_data_min[14];
  struct { struct { } __empty_sa_data; char sa_data[1]; };
 };
};
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
} sync_serial_settings;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
 unsigned int slot_map;
} te1_settings;
typedef struct {
 unsigned short encoding;
 unsigned short parity;
} raw_hdlc_proto;
typedef struct {
 unsigned int t391;
 unsigned int t392;
 unsigned int n391;
 unsigned int n392;
 unsigned int n393;
 unsigned short lmi;
 unsigned short dce;
} fr_proto;
typedef struct {
 unsigned int dlci;
} fr_proto_pvc;
typedef struct {
 unsigned int dlci;
 char master[16];
}fr_proto_pvc_info;
typedef struct {
    unsigned int interval;
    unsigned int timeout;
} cisco_proto;
typedef struct {
 unsigned short dce;
 unsigned int modulo;
 unsigned int window;
 unsigned int t1;
 unsigned int t2;
 unsigned int n2;
} x25_hdlc_proto;
struct ifmap {
 unsigned long mem_start;
 unsigned long mem_end;
 unsigned short base_addr;
 unsigned char irq;
 unsigned char dma;
 unsigned char port;

};
struct if_settings {
 unsigned int type;
 unsigned int size;
 union {

  raw_hdlc_proto *raw_hdlc;
  cisco_proto *cisco;
  fr_proto *fr;
  fr_proto_pvc *fr_pvc;
  fr_proto_pvc_info *fr_pvc_info;
  x25_hdlc_proto *x25;


  sync_serial_settings *sync;
  te1_settings *te1;
 } ifs_ifsu;
};
struct ifreq {
 union
 {
  char ifrn_name[16];
 } ifr_ifrn;

 union {
  struct sockaddr ifru_addr;
  struct sockaddr ifru_dstaddr;
  struct sockaddr ifru_broadaddr;
  struct sockaddr ifru_netmask;
  struct sockaddr ifru_hwaddr;
  short ifru_flags;
  int ifru_ivalue;
  int ifru_mtu;
  struct ifmap ifru_map;
  char ifru_slave[16];
  char ifru_newname[16];
  void * ifru_data;
  struct if_settings ifru_settings;
 } ifr_ifru;
};
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {

  __u64  lock_count;

  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;
 atomic_long_t *nr_deferred;
};
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;
};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;




};
extern void up(struct semaphore *sem);
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };



 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;






 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;
 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;



};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;
};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;




 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;
 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;
 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;
 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;





};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;




};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct kernel_param;
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {

 unsigned int num_orcs;
 int *orc_unwind_ip;
 struct orc_entry *orc_unwind;

 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];







 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;






 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;






 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;
 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
}  ;
struct device;
struct device;
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;
};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;
 struct dev_msi_info msi;



 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;
 struct io_tlb_mem *dma_io_tlb_mem;







 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
struct page;
typedef struct {
 atomic_long_t a;
} local_t;
struct dql {

 unsigned int num_queued;
 unsigned int adj_limit;
 unsigned int last_obj_cnt;


 unsigned short stall_thrs;

 unsigned long history_head;

 unsigned long history[4];



 unsigned int limit ;
 unsigned int num_completed;

 unsigned int prev_ovlimit;
 unsigned int prev_num_queued;
 unsigned int prev_last_obj_cnt;

 unsigned int lowest_slack;
 unsigned long slack_start_time;


 unsigned int max_limit;
 unsigned int min_limit;
 unsigned int slack_hold_time;


 unsigned short stall_max;
 unsigned long last_reap;
 unsigned long stall_cnt;
};
struct in6_addr {
 union {
  __u8 u6_addr8[16];

  __be16 u6_addr16[8];
  __be32 u6_addr32[4];

 } in6_u;


};
struct ctl_table_header;
struct prot_inuse;
struct cpumask;
struct netns_core {

 struct ctl_table_header *sysctl_hdr;

 int sysctl_somaxconn;
 int sysctl_optmem_max;
 u8 sysctl_txrehash;
 u8 sysctl_tstamp_allow_data;


 struct prot_inuse *prot_inuse;



 struct cpumask *rps_default_mask;

};
enum
{
 IPSTATS_MIB_NUM = 0,

 IPSTATS_MIB_INPKTS,
 IPSTATS_MIB_INOCTETS,
 IPSTATS_MIB_INDELIVERS,
 IPSTATS_MIB_NOECTPKTS,
 IPSTATS_MIB_ECT1PKTS,
 IPSTATS_MIB_ECT0PKTS,
 IPSTATS_MIB_CEPKTS,
 IPSTATS_MIB_OUTREQUESTS,
 IPSTATS_MIB_OUTPKTS,
 IPSTATS_MIB_OUTOCTETS,
 IPSTATS_MIB_OUTFORWDATAGRAMS,

 IPSTATS_MIB_INHDRERRORS,
 IPSTATS_MIB_INTOOBIGERRORS,
 IPSTATS_MIB_INNOROUTES,
 IPSTATS_MIB_INADDRERRORS,
 IPSTATS_MIB_INUNKNOWNPROTOS,
 IPSTATS_MIB_INTRUNCATEDPKTS,
 IPSTATS_MIB_INDISCARDS,
 IPSTATS_MIB_OUTDISCARDS,
 IPSTATS_MIB_OUTNOROUTES,
 IPSTATS_MIB_REASMTIMEOUT,
 IPSTATS_MIB_REASMREQDS,
 IPSTATS_MIB_REASMOKS,
 IPSTATS_MIB_REASMFAILS,
 IPSTATS_MIB_FRAGOKS,
 IPSTATS_MIB_FRAGFAILS,
 IPSTATS_MIB_FRAGCREATES,
 IPSTATS_MIB_INMCASTPKTS,
 IPSTATS_MIB_OUTMCASTPKTS,
 IPSTATS_MIB_INBCASTPKTS,
 IPSTATS_MIB_OUTBCASTPKTS,
 IPSTATS_MIB_INMCASTOCTETS,
 IPSTATS_MIB_OUTMCASTOCTETS,
 IPSTATS_MIB_INBCASTOCTETS,
 IPSTATS_MIB_OUTBCASTOCTETS,
 IPSTATS_MIB_CSUMERRORS,
 IPSTATS_MIB_REASM_OVERLAPS,
 __IPSTATS_MIB_MAX
};
enum
{
 ICMP_MIB_NUM = 0,
 ICMP_MIB_INMSGS,
 ICMP_MIB_INERRORS,
 ICMP_MIB_INDESTUNREACHS,
 ICMP_MIB_INTIMEEXCDS,
 ICMP_MIB_INPARMPROBS,
 ICMP_MIB_INSRCQUENCHS,
 ICMP_MIB_INREDIRECTS,
 ICMP_MIB_INECHOS,
 ICMP_MIB_INECHOREPS,
 ICMP_MIB_INTIMESTAMPS,
 ICMP_MIB_INTIMESTAMPREPS,
 ICMP_MIB_INADDRMASKS,
 ICMP_MIB_INADDRMASKREPS,
 ICMP_MIB_OUTMSGS,
 ICMP_MIB_OUTERRORS,
 ICMP_MIB_OUTDESTUNREACHS,
 ICMP_MIB_OUTTIMEEXCDS,
 ICMP_MIB_OUTPARMPROBS,
 ICMP_MIB_OUTSRCQUENCHS,
 ICMP_MIB_OUTREDIRECTS,
 ICMP_MIB_OUTECHOS,
 ICMP_MIB_OUTECHOREPS,
 ICMP_MIB_OUTTIMESTAMPS,
 ICMP_MIB_OUTTIMESTAMPREPS,
 ICMP_MIB_OUTADDRMASKS,
 ICMP_MIB_OUTADDRMASKREPS,
 ICMP_MIB_CSUMERRORS,
 ICMP_MIB_RATELIMITGLOBAL,
 ICMP_MIB_RATELIMITHOST,
 __ICMP_MIB_MAX
};
enum
{
 ICMP6_MIB_NUM = 0,
 ICMP6_MIB_INMSGS,
 ICMP6_MIB_INERRORS,
 ICMP6_MIB_OUTMSGS,
 ICMP6_MIB_OUTERRORS,
 ICMP6_MIB_CSUMERRORS,
 ICMP6_MIB_RATELIMITHOST,
 __ICMP6_MIB_MAX
};
enum
{
 TCP_MIB_NUM = 0,
 TCP_MIB_RTOALGORITHM,
 TCP_MIB_RTOMIN,
 TCP_MIB_RTOMAX,
 TCP_MIB_MAXCONN,
 TCP_MIB_ACTIVEOPENS,
 TCP_MIB_PASSIVEOPENS,
 TCP_MIB_ATTEMPTFAILS,
 TCP_MIB_ESTABRESETS,
 TCP_MIB_CURRESTAB,
 TCP_MIB_INSEGS,
 TCP_MIB_OUTSEGS,
 TCP_MIB_RETRANSSEGS,
 TCP_MIB_INERRS,
 TCP_MIB_OUTRSTS,
 TCP_MIB_CSUMERRORS,
 __TCP_MIB_MAX
};
enum
{
 UDP_MIB_NUM = 0,
 UDP_MIB_INDATAGRAMS,
 UDP_MIB_NOPORTS,
 UDP_MIB_INERRORS,
 UDP_MIB_OUTDATAGRAMS,
 UDP_MIB_RCVBUFERRORS,
 UDP_MIB_SNDBUFERRORS,
 UDP_MIB_CSUMERRORS,
 UDP_MIB_IGNOREDMULTI,
 UDP_MIB_MEMERRORS,
 __UDP_MIB_MAX
};
enum
{
 LINUX_MIB_NUM = 0,
 LINUX_MIB_SYNCOOKIESSENT,
 LINUX_MIB_SYNCOOKIESRECV,
 LINUX_MIB_SYNCOOKIESFAILED,
 LINUX_MIB_EMBRYONICRSTS,
 LINUX_MIB_PRUNECALLED,
 LINUX_MIB_RCVPRUNED,
 LINUX_MIB_OFOPRUNED,
 LINUX_MIB_OUTOFWINDOWICMPS,
 LINUX_MIB_LOCKDROPPEDICMPS,
 LINUX_MIB_ARPFILTER,
 LINUX_MIB_TIMEWAITED,
 LINUX_MIB_TIMEWAITRECYCLED,
 LINUX_MIB_TIMEWAITKILLED,
 LINUX_MIB_PAWSACTIVEREJECTED,
 LINUX_MIB_PAWSESTABREJECTED,
 LINUX_MIB_BEYOND_WINDOW,
 LINUX_MIB_TSECRREJECTED,
 LINUX_MIB_PAWS_OLD_ACK,
 LINUX_MIB_PAWS_TW_REJECTED,
 LINUX_MIB_DELAYEDACKS,
 LINUX_MIB_DELAYEDACKLOCKED,
 LINUX_MIB_DELAYEDACKLOST,
 LINUX_MIB_LISTENOVERFLOWS,
 LINUX_MIB_LISTENDROPS,
 LINUX_MIB_TCPHPHITS,
 LINUX_MIB_TCPPUREACKS,
 LINUX_MIB_TCPHPACKS,
 LINUX_MIB_TCPRENORECOVERY,
 LINUX_MIB_TCPSACKRECOVERY,
 LINUX_MIB_TCPSACKRENEGING,
 LINUX_MIB_TCPSACKREORDER,
 LINUX_MIB_TCPRENOREORDER,
 LINUX_MIB_TCPTSREORDER,
 LINUX_MIB_TCPFULLUNDO,
 LINUX_MIB_TCPPARTIALUNDO,
 LINUX_MIB_TCPDSACKUNDO,
 LINUX_MIB_TCPLOSSUNDO,
 LINUX_MIB_TCPLOSTRETRANSMIT,
 LINUX_MIB_TCPRENOFAILURES,
 LINUX_MIB_TCPSACKFAILURES,
 LINUX_MIB_TCPLOSSFAILURES,
 LINUX_MIB_TCPFASTRETRANS,
 LINUX_MIB_TCPSLOWSTARTRETRANS,
 LINUX_MIB_TCPTIMEOUTS,
 LINUX_MIB_TCPLOSSPROBES,
 LINUX_MIB_TCPLOSSPROBERECOVERY,
 LINUX_MIB_TCPRENORECOVERYFAIL,
 LINUX_MIB_TCPSACKRECOVERYFAIL,
 LINUX_MIB_TCPRCVCOLLAPSED,
 LINUX_MIB_TCPDSACKOLDSENT,
 LINUX_MIB_TCPDSACKOFOSENT,
 LINUX_MIB_TCPDSACKRECV,
 LINUX_MIB_TCPDSACKOFORECV,
 LINUX_MIB_TCPABORTONDATA,
 LINUX_MIB_TCPABORTONCLOSE,
 LINUX_MIB_TCPABORTONMEMORY,
 LINUX_MIB_TCPABORTONTIMEOUT,
 LINUX_MIB_TCPABORTONLINGER,
 LINUX_MIB_TCPABORTFAILED,
 LINUX_MIB_TCPMEMORYPRESSURES,
 LINUX_MIB_TCPMEMORYPRESSURESCHRONO,
 LINUX_MIB_TCPSACKDISCARD,
 LINUX_MIB_TCPDSACKIGNOREDOLD,
 LINUX_MIB_TCPDSACKIGNOREDNOUNDO,
 LINUX_MIB_TCPSPURIOUSRTOS,
 LINUX_MIB_TCPMD5NOTFOUND,
 LINUX_MIB_TCPMD5UNEXPECTED,
 LINUX_MIB_TCPMD5FAILURE,
 LINUX_MIB_SACKSHIFTED,
 LINUX_MIB_SACKMERGED,
 LINUX_MIB_SACKSHIFTFALLBACK,
 LINUX_MIB_TCPBACKLOGDROP,
 LINUX_MIB_PFMEMALLOCDROP,
 LINUX_MIB_TCPMINTTLDROP,
 LINUX_MIB_TCPDEFERACCEPTDROP,
 LINUX_MIB_IPRPFILTER,
 LINUX_MIB_TCPTIMEWAITOVERFLOW,
 LINUX_MIB_TCPREQQFULLDOCOOKIES,
 LINUX_MIB_TCPREQQFULLDROP,
 LINUX_MIB_TCPRETRANSFAIL,
 LINUX_MIB_TCPRCVCOALESCE,
 LINUX_MIB_TCPBACKLOGCOALESCE,
 LINUX_MIB_TCPOFOQUEUE,
 LINUX_MIB_TCPOFODROP,
 LINUX_MIB_TCPOFOMERGE,
 LINUX_MIB_TCPCHALLENGEACK,
 LINUX_MIB_TCPSYNCHALLENGE,
 LINUX_MIB_TCPFASTOPENACTIVE,
 LINUX_MIB_TCPFASTOPENACTIVEFAIL,
 LINUX_MIB_TCPFASTOPENPASSIVE,
 LINUX_MIB_TCPFASTOPENPASSIVEFAIL,
 LINUX_MIB_TCPFASTOPENLISTENOVERFLOW,
 LINUX_MIB_TCPFASTOPENCOOKIEREQD,
 LINUX_MIB_TCPFASTOPENBLACKHOLE,
 LINUX_MIB_TCPSPURIOUS_RTX_HOSTQUEUES,
 LINUX_MIB_BUSYPOLLRXPACKETS,
 LINUX_MIB_TCPAUTOCORKING,
 LINUX_MIB_TCPFROMZEROWINDOWADV,
 LINUX_MIB_TCPTOZEROWINDOWADV,
 LINUX_MIB_TCPWANTZEROWINDOWADV,
 LINUX_MIB_TCPSYNRETRANS,
 LINUX_MIB_TCPORIGDATASENT,
 LINUX_MIB_TCPHYSTARTTRAINDETECT,
 LINUX_MIB_TCPHYSTARTTRAINCWND,
 LINUX_MIB_TCPHYSTARTDELAYDETECT,
 LINUX_MIB_TCPHYSTARTDELAYCWND,
 LINUX_MIB_TCPACKSKIPPEDSYNRECV,
 LINUX_MIB_TCPACKSKIPPEDPAWS,
 LINUX_MIB_TCPACKSKIPPEDSEQ,
 LINUX_MIB_TCPACKSKIPPEDFINWAIT2,
 LINUX_MIB_TCPACKSKIPPEDTIMEWAIT,
 LINUX_MIB_TCPACKSKIPPEDCHALLENGE,
 LINUX_MIB_TCPWINPROBE,
 LINUX_MIB_TCPKEEPALIVE,
 LINUX_MIB_TCPMTUPFAIL,
 LINUX_MIB_TCPMTUPSUCCESS,
 LINUX_MIB_TCPDELIVERED,
 LINUX_MIB_TCPDELIVEREDCE,
 LINUX_MIB_TCPACKCOMPRESSED,
 LINUX_MIB_TCPZEROWINDOWDROP,
 LINUX_MIB_TCPRCVQDROP,
 LINUX_MIB_TCPWQUEUETOOBIG,
 LINUX_MIB_TCPFASTOPENPASSIVEALTKEY,
 LINUX_MIB_TCPTIMEOUTREHASH,
 LINUX_MIB_TCPDUPLICATEDATAREHASH,
 LINUX_MIB_TCPDSACKRECVSEGS,
 LINUX_MIB_TCPDSACKIGNOREDDUBIOUS,
 LINUX_MIB_TCPMIGRATEREQSUCCESS,
 LINUX_MIB_TCPMIGRATEREQFAILURE,
 LINUX_MIB_TCPPLBREHASH,
 LINUX_MIB_TCPAOREQUIRED,
 LINUX_MIB_TCPAOBAD,
 LINUX_MIB_TCPAOKEYNOTFOUND,
 LINUX_MIB_TCPAOGOOD,
 LINUX_MIB_TCPAODROPPEDICMPS,
 __LINUX_MIB_MAX
};
struct u64_stats_sync {



};
typedef struct {
 local_t a;
} local64_t;
typedef struct {
 local64_t v;
} u64_stats_t ;
struct ipstats_mib {

 u64 mibs[__IPSTATS_MIB_MAX];
 struct u64_stats_sync syncp;
};
struct icmp_mib {
 unsigned long mibs[__ICMP_MIB_MAX];
};
struct icmpmsg_mib {
 atomic_long_t mibs[512];
};
struct icmpv6_mib {
 unsigned long mibs[__ICMP6_MIB_MAX];
};
struct icmpv6msg_mib {
 atomic_long_t mibs[512];
};
struct tcp_mib {
 unsigned long mibs[__TCP_MIB_MAX];
};
struct udp_mib {
 unsigned long mibs[__UDP_MIB_MAX];
};
struct linux_mib {
 unsigned long mibs[__LINUX_MIB_MAX];
};
struct netns_mib {
 __typeof__(struct ipstats_mib) *ip_statistics;

 __typeof__(struct ipstats_mib) *ipv6_statistics;


 __typeof__(struct tcp_mib) *tcp_statistics;
 __typeof__(struct linux_mib) *net_statistics;

 __typeof__(struct udp_mib) *udp_statistics;

 __typeof__(struct udp_mib) *udp_stats_in6;
 __typeof__(struct udp_mib) *udplite_statistics;

 __typeof__(struct udp_mib) *udplite_stats_in6;


 __typeof__(struct icmp_mib) *icmp_statistics;
 __typeof__(struct icmpmsg_mib) *icmpmsg_statistics;

 __typeof__(struct icmpv6_mib) *icmpv6_statistics;
 __typeof__(struct icmpv6msg_mib) *icmpv6msg_statistics;
 struct proc_dir_entry *proc_net_devsnmp6;

};
struct unix_table {
 spinlock_t *locks;
 struct hlist_head *buckets;
};
struct ctl_table_header;
struct netns_unix {
 struct unix_table table;
 int sysctl_max_dgram_qlen;
 struct ctl_table_header *ctl;
};
struct netns_packet {
 struct mutex sklist_lock;
 struct hlist_head sklist;
};
struct fqdir {

 long high_thresh;
 long low_thresh;
 int timeout;
 int max_dist;
 struct inet_frags *f;
 struct net *net;
 bool dead;

 struct rhashtable rhashtable ;


 atomic_long_t mem ;
 struct work_struct destroy_work;
 struct llist_node free_list;
};
struct frag_v4_compare_key {
 __be32 saddr;
 __be32 daddr;
 u32 user;
 u32 vif;
 __be16 id;
 u16 protocol;
};
struct frag_v6_compare_key {
 struct in6_addr saddr;
 struct in6_addr daddr;
 u32 user;
 __be32 id;
 u32 iif;
};
struct inet_frag_queue {
 struct rhash_head node;
 union {
  struct frag_v4_compare_key v4;
  struct frag_v6_compare_key v6;
 } key;
 struct timer_list timer;
 spinlock_t lock;
 refcount_t refcnt;
 struct rb_root rb_fragments;
 struct sk_buff *fragments_tail;
 struct sk_buff *last_run_head;
 ktime_t stamp;
 int len;
 int meat;
 u8 tstamp_type;
 __u8 flags;
 u16 max_size;
 struct fqdir *fqdir;
 struct callback_head rcu;
};
struct inet_frags {
 unsigned int qsize;

 void (*constructor)(struct inet_frag_queue *q,
            const void *arg);
 void (*destructor)(struct inet_frag_queue *);
 void (*frag_expire)(struct timer_list *t);
 struct kmem_cache *frags_cachep;
 const char *frags_cache_name;
 struct rhashtable_params rhash_params;
 refcount_t refcnt;
 struct completion completion;
};
typedef struct {
 u64 key[2];
} siphash_key_t;
struct ctl_table_header;
struct ipv4_devconf;
struct fib_rules_ops;
struct hlist_head;
struct fib_table;
struct sock;
struct local_ports {
 u32 range;
 bool warned;
};
struct ping_group_range {
 seqlock_t lock;
 kgid_t range[2];
};
struct inet_hashinfo;
struct inet_timewait_death_row {
 refcount_t tw_refcount;


 struct inet_hashinfo *hashinfo ;
 int sysctl_max_tw_buckets;
};
struct tcp_fastopen_context;
struct sysctl_fib_multipath_hash_seed {
 u32 user_seed;
 u32 mp_seed;
};
struct netns_ipv4 {






 __u8 __cacheline_group_begin__netns_ipv4_read_tx[1];
 u8 sysctl_tcp_early_retrans;
 u8 sysctl_tcp_tso_win_divisor;
 u8 sysctl_tcp_tso_rtt_log;
 u8 sysctl_tcp_autocorking;
 int sysctl_tcp_min_snd_mss;
 unsigned int sysctl_tcp_notsent_lowat;
 int sysctl_tcp_limit_output_bytes;
 int sysctl_tcp_min_rtt_wlen;
 int sysctl_tcp_wmem[3];
 u8 sysctl_ip_fwd_use_pmtu;
 __u8 __cacheline_group_end__netns_ipv4_read_tx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_txrx[1];
 u8 sysctl_tcp_moderate_rcvbuf;
 __u8 __cacheline_group_end__netns_ipv4_read_txrx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_rx[1];
 u8 sysctl_ip_early_demux;
 u8 sysctl_tcp_early_demux;
 u8 sysctl_tcp_l3mdev_accept;

 int sysctl_tcp_reordering;
 int sysctl_tcp_rmem[3];
 __u8 __cacheline_group_end__netns_ipv4_read_rx[1];


 __u8 __cacheline_group_begin__icmp[1] ;
 atomic_t icmp_global_credit;
 u32 icmp_global_stamp;
 __u8 __cacheline_group_end__icmp[1] ; struct { } __cacheline_group_pad__icmp ;

 struct inet_timewait_death_row tcp_death_row;
 struct udp_table *udp_table;







 struct ctl_table_header *forw_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *ipv4_hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *xfrm4_hdr;

 struct ipv4_devconf *devconf_all;
 struct ipv4_devconf *devconf_dflt;
 struct ip_ra_chain *ra_chain;
 struct mutex ra_mutex;

 struct fib_rules_ops *rules_ops;
 struct fib_table *fib_main;
 struct fib_table *fib_default;
 unsigned int fib_rules_require_fldissect;
 bool fib_has_custom_rules;

 bool fib_has_custom_local_routes;
 bool fib_offload_disabled;
 u8 sysctl_tcp_shrink_window;



 struct hlist_head *fib_table_hash;
 struct sock *fibnl;
 struct hlist_head *fib_info_hash;
 unsigned int fib_info_hash_bits;
 unsigned int fib_info_cnt;

 struct sock *mc_autojoin_sk;

 struct inet_peer_base *peers;
 struct fqdir *fqdir;

 u8 sysctl_icmp_echo_ignore_all;
 u8 sysctl_icmp_echo_enable_probe;
 u8 sysctl_icmp_echo_ignore_broadcasts;
 u8 sysctl_icmp_ignore_bogus_error_responses;
 u8 sysctl_icmp_errors_use_inbound_ifaddr;
 int sysctl_icmp_ratelimit;
 int sysctl_icmp_ratemask;
 int sysctl_icmp_msgs_per_sec;
 int sysctl_icmp_msgs_burst;

 u32 ip_rt_min_pmtu;
 int ip_rt_mtu_expires;
 int ip_rt_min_advmss;

 struct local_ports ip_local_ports;

 u8 sysctl_tcp_ecn;
 u8 sysctl_tcp_ecn_option;
 u8 sysctl_tcp_ecn_option_beacon;
 u8 sysctl_tcp_ecn_fallback;

 u8 sysctl_ip_default_ttl;
 u8 sysctl_ip_no_pmtu_disc;
 u8 sysctl_ip_fwd_update_priority;
 u8 sysctl_ip_nonlocal_bind;
 u8 sysctl_ip_autobind_reuse;

 u8 sysctl_ip_dynaddr;



 u8 sysctl_udp_early_demux;

 u8 sysctl_nexthop_compat_mode;

 u8 sysctl_fwmark_reflect;
 u8 sysctl_tcp_fwmark_accept;
 u8 sysctl_tcp_mtu_probing;
 int sysctl_tcp_mtu_probe_floor;
 int sysctl_tcp_base_mss;
 int sysctl_tcp_probe_threshold;
 u32 sysctl_tcp_probe_interval;

 int sysctl_tcp_keepalive_time;
 int sysctl_tcp_keepalive_intvl;
 u8 sysctl_tcp_keepalive_probes;

 u8 sysctl_tcp_syn_retries;
 u8 sysctl_tcp_synack_retries;
 u8 sysctl_tcp_syncookies;
 u8 sysctl_tcp_migrate_req;
 u8 sysctl_tcp_comp_sack_nr;
 u8 sysctl_tcp_backlog_ack_defer;
 u8 sysctl_tcp_pingpong_thresh;

 u8 sysctl_tcp_retries1;
 u8 sysctl_tcp_retries2;
 u8 sysctl_tcp_orphan_retries;
 u8 sysctl_tcp_tw_reuse;
 unsigned int sysctl_tcp_tw_reuse_delay;
 int sysctl_tcp_fin_timeout;
 u8 sysctl_tcp_sack;
 u8 sysctl_tcp_window_scaling;
 u8 sysctl_tcp_timestamps;
 int sysctl_tcp_rto_min_us;
 int sysctl_tcp_rto_max_ms;
 u8 sysctl_tcp_recovery;
 u8 sysctl_tcp_thin_linear_timeouts;
 u8 sysctl_tcp_slow_start_after_idle;
 u8 sysctl_tcp_retrans_collapse;
 u8 sysctl_tcp_stdurg;
 u8 sysctl_tcp_rfc1337;
 u8 sysctl_tcp_abort_on_overflow;
 u8 sysctl_tcp_fack;
 int sysctl_tcp_max_reordering;
 int sysctl_tcp_adv_win_scale;
 u8 sysctl_tcp_dsack;
 u8 sysctl_tcp_app_win;
 u8 sysctl_tcp_frto;
 u8 sysctl_tcp_nometrics_save;
 u8 sysctl_tcp_no_ssthresh_metrics_save;
 u8 sysctl_tcp_workaround_signed_windows;
 int sysctl_tcp_challenge_ack_limit;
 u8 sysctl_tcp_min_tso_segs;
 u8 sysctl_tcp_reflect_tos;
 int sysctl_tcp_invalid_ratelimit;
 int sysctl_tcp_pacing_ss_ratio;
 int sysctl_tcp_pacing_ca_ratio;
 unsigned int sysctl_tcp_child_ehash_entries;
 unsigned long sysctl_tcp_comp_sack_delay_ns;
 unsigned long sysctl_tcp_comp_sack_slack_ns;
 int sysctl_max_syn_backlog;
 int sysctl_tcp_fastopen;
 const struct tcp_congestion_ops *tcp_congestion_control;
 struct tcp_fastopen_context *tcp_fastopen_ctx;
 unsigned int sysctl_tcp_fastopen_blackhole_timeout;
 atomic_t tfo_active_disable_times;
 unsigned long tfo_active_disable_stamp;
 u32 tcp_challenge_timestamp;
 u32 tcp_challenge_count;
 u8 sysctl_tcp_plb_enabled;
 u8 sysctl_tcp_plb_idle_rehash_rounds;
 u8 sysctl_tcp_plb_rehash_rounds;
 u8 sysctl_tcp_plb_suspend_rto_sec;
 int sysctl_tcp_plb_cong_thresh;

 int sysctl_udp_wmem_min;
 int sysctl_udp_rmem_min;

 u8 sysctl_fib_notify_on_flag_change;
 u8 sysctl_tcp_syn_linear_timeouts;





 u8 sysctl_igmp_llm_reports;
 int sysctl_igmp_max_memberships;
 int sysctl_igmp_max_msf;
 int sysctl_igmp_qrv;

 struct ping_group_range ping_group_range;
 u16 ping_port_rover;

 atomic_t dev_addr_genid;

 unsigned int sysctl_udp_child_hash_entries;


 unsigned long *sysctl_local_reserved_ports;
 int sysctl_ip_prot_sock;




 struct mr_table *mrt;






 struct sysctl_fib_multipath_hash_seed sysctl_fib_multipath_hash_seed;
 u32 sysctl_fib_multipath_hash_fields;
 u8 sysctl_fib_multipath_use_neigh;
 u8 sysctl_fib_multipath_hash_policy;


 struct fib_notifier_ops *notifier_ops;
 unsigned int fib_seq;

 struct fib_notifier_ops *ipmr_notifier_ops;
 unsigned int ipmr_seq;

 atomic_t rt_genid;
 siphash_key_t ip_id_key;
 struct hlist_head *inet_addr_lst;
 struct delayed_work addr_chk_work;
};
struct dst_entry;
struct kmem_cachep;
struct net_device;
struct sk_buff;
struct sock;
struct net;
struct dst_ops {
 unsigned short family;
 unsigned int gc_thresh;

 void (*gc)(struct dst_ops *ops);
 struct dst_entry * (*check)(struct dst_entry *, __u32 cookie);
 unsigned int (*default_advmss)(const struct dst_entry *);
 unsigned int (*mtu)(const struct dst_entry *);
 u32 * (*cow_metrics)(struct dst_entry *, unsigned long);
 void (*destroy)(struct dst_entry *);
 void (*ifdown)(struct dst_entry *,
       struct net_device *dev);
 void (*negative_advice)(struct sock *sk, struct dst_entry *);
 void (*link_failure)(struct sk_buff *);
 void (*update_pmtu)(struct dst_entry *dst, struct sock *sk,
            struct sk_buff *skb, u32 mtu,
            bool confirm_neigh);
 void (*redirect)(struct dst_entry *dst, struct sock *sk,
         struct sk_buff *skb);
 int (*local_out)(struct net *net, struct sock *sk, struct sk_buff *skb);
 struct neighbour * (*neigh_lookup)(const struct dst_entry *dst,
      struct sk_buff *skb,
      const void *daddr);
 void (*confirm_neigh)(const struct dst_entry *dst,
       const void *daddr);

 struct kmem_cache *kmem_cachep;

 struct percpu_counter pcpuc_entries ;
};
struct ctl_table_header;
struct netns_sysctl_ipv6 {

 struct ctl_table_header *hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *icmp_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *xfrm6_hdr;

 int flush_delay;
 int ip6_rt_max_size;
 int ip6_rt_gc_min_interval;
 int ip6_rt_gc_timeout;
 int ip6_rt_gc_interval;
 int ip6_rt_gc_elasticity;
 int ip6_rt_mtu_expires;
 int ip6_rt_min_advmss;
 u32 multipath_hash_fields;
 u8 multipath_hash_policy;
 u8 bindv6only;
 u8 flowlabel_consistency;
 u8 auto_flowlabels;
 int icmpv6_time;
 u8 icmpv6_echo_ignore_all;
 u8 icmpv6_echo_ignore_multicast;
 u8 icmpv6_echo_ignore_anycast;
 unsigned long icmpv6_ratemask[(((255 + 1) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long *icmpv6_ratemask_ptr;
 u8 anycast_src_echo_reply;
 u8 ip_nonlocal_bind;
 u8 fwmark_reflect;
 u8 flowlabel_state_ranges;
 int idgen_retries;
 int idgen_delay;
 int flowlabel_reflect;
 int max_dst_opts_cnt;
 int max_hbh_opts_cnt;
 int max_dst_opts_len;
 int max_hbh_opts_len;
 int seg6_flowlabel;
 u32 ioam6_id;
 u64 ioam6_id_wide;
 u8 skip_notify_on_dev_down;
 u8 fib_notify_on_flag_change;
 u8 icmpv6_error_anycast_as_unicast;
};
struct netns_ipv6 {

 struct dst_ops ip6_dst_ops;

 struct netns_sysctl_ipv6 sysctl;
 struct ipv6_devconf *devconf_all;
 struct ipv6_devconf *devconf_dflt;
 struct inet_peer_base *peers;
 struct fqdir *fqdir;
 struct fib6_info *fib6_null_entry;
 struct rt6_info *ip6_null_entry;
 struct rt6_statistics *rt6_stats;
 struct timer_list ip6_fib_timer;
 struct hlist_head *fib_table_hash;
 spinlock_t fib_table_hash_lock;
 struct fib6_table *fib6_main_tbl;
 struct list_head fib6_walkers;
 rwlock_t fib6_walker_lock;
 spinlock_t fib6_gc_lock;
 atomic_t ip6_rt_gc_expire;
 unsigned long ip6_rt_last_gc;
 unsigned char flowlabel_has_excl;
 struct sock *ndisc_sk;
 struct sock *tcp_sk;
 struct sock *igmp_sk;
 struct sock *mc_autojoin_sk;

 struct hlist_head *inet6_addr_lst;
 spinlock_t addrconf_hash_lock;
 struct delayed_work addr_chk_work;
 atomic_t dev_addr_genid;
 atomic_t fib6_sernum;
 struct seg6_pernet_data *seg6_data;
 struct fib_notifier_ops *notifier_ops;
 struct fib_notifier_ops *ip6mr_notifier_ops;
 unsigned int ipmr_seq;
 struct {
  struct hlist_head head;
  spinlock_t lock;
  u32 seq;
 } ip6addrlbl_table;
 struct ioam6_pernet_data *ioam6_data;
};
struct netns_nexthop {
 struct rb_root rb_root;
 struct hlist_head *devhash;

 unsigned int seq;
 u32 last_id_allocated;
 struct blocking_notifier_head notifier_chain;
};
struct sock;
struct proc_dir_entry;
struct ctl_table_header;
enum nf_inet_hooks {
 NF_INET_PRE_ROUTING,
 NF_INET_LOCAL_IN,
 NF_INET_FORWARD,
 NF_INET_LOCAL_OUT,
 NF_INET_POST_ROUTING,
 NF_INET_NUMHOOKS,
 NF_INET_INGRESS = NF_INET_NUMHOOKS,
};
enum {
 NFPROTO_UNSPEC = 0,
 NFPROTO_INET = 1,
 NFPROTO_IPV4 = 2,
 NFPROTO_ARP = 3,
 NFPROTO_NETDEV = 5,
 NFPROTO_BRIDGE = 7,
 NFPROTO_IPV6 = 10,



 NFPROTO_NUMPROTO,
};
struct proc_dir_entry;
struct nf_logger;
struct netns_nf {

 struct proc_dir_entry *proc_netfilter;

 const struct nf_logger *nf_loggers[NFPROTO_NUMPROTO];

 struct ctl_table_header *nf_log_dir_header;




 struct nf_hook_entries *hooks_ipv4[NF_INET_NUMHOOKS];
 struct nf_hook_entries *hooks_ipv6[NF_INET_NUMHOOKS];







 unsigned int defrag_ipv4_users;


 unsigned int defrag_ipv6_users;

};
enum tcp_conntrack {
 TCP_CONNTRACK_NONE,
 TCP_CONNTRACK_SYN_SENT,
 TCP_CONNTRACK_SYN_RECV,
 TCP_CONNTRACK_ESTABLISHED,
 TCP_CONNTRACK_FIN_WAIT,
 TCP_CONNTRACK_CLOSE_WAIT,
 TCP_CONNTRACK_LAST_ACK,
 TCP_CONNTRACK_TIME_WAIT,
 TCP_CONNTRACK_CLOSE,
 TCP_CONNTRACK_LISTEN,
 TCP_CONNTRACK_MAX,
 TCP_CONNTRACK_IGNORE,
 TCP_CONNTRACK_RETRANS,
 TCP_CONNTRACK_UNACK,
 TCP_CONNTRACK_TIMEOUT_MAX
};
struct ctl_table_header;
struct nf_generic_net {
 unsigned int timeout;
};
struct nf_tcp_net {
 unsigned int timeouts[TCP_CONNTRACK_TIMEOUT_MAX];
 u8 tcp_loose;
 u8 tcp_be_liberal;
 u8 tcp_max_retrans;
 u8 tcp_ignore_invalid_rst;



};
enum udp_conntrack {
 UDP_CT_UNREPLIED,
 UDP_CT_REPLIED,
 UDP_CT_MAX
};
struct nf_udp_net {
 unsigned int timeouts[UDP_CT_MAX];



};
struct nf_icmp_net {
 unsigned int timeout;
};
struct nf_ip_net {
 struct nf_generic_net generic;
 struct nf_tcp_net tcp;
 struct nf_udp_net udp;
 struct nf_icmp_net icmp;
 struct nf_icmp_net icmpv6;






};
struct netns_ct {



 u8 sysctl_log_invalid;
 u8 sysctl_events;
 u8 sysctl_acct;
 u8 sysctl_tstamp;
 u8 sysctl_checksum;

 struct ip_conntrack_stat *stat;
 struct nf_ct_event_notifier *nf_conntrack_event_cb;
 struct nf_ip_net nf_ct_proto;



};
enum {
 XFRM_POLICY_IN = 0,
 XFRM_POLICY_OUT = 1,
 XFRM_POLICY_FWD = 2,
 XFRM_POLICY_MASK = 3,
 XFRM_POLICY_MAX = 3
};
struct ctl_table_header;
struct xfrm_policy_hash {
 struct hlist_head *table;
 unsigned int hmask;
 u8 dbits4;
 u8 sbits4;
 u8 dbits6;
 u8 sbits6;
};
struct xfrm_policy_hthresh {
 struct work_struct work;
 seqlock_t lock;
 u8 lbits4;
 u8 rbits4;
 u8 lbits6;
 u8 rbits6;
};
struct netns_xfrm {
 struct list_head state_all;
 struct hlist_head *state_bydst;
 struct hlist_head *state_bysrc;
 struct hlist_head *state_byspi;
 struct hlist_head *state_byseq;
 struct hlist_head *state_cache_input;
 unsigned int state_hmask;
 unsigned int state_num;
 struct work_struct state_hash_work;

 struct list_head policy_all;
 struct hlist_head *policy_byidx;
 unsigned int policy_idx_hmask;
 unsigned int idx_generator;
 struct xfrm_policy_hash policy_bydst[XFRM_POLICY_MAX];
 unsigned int policy_count[XFRM_POLICY_MAX * 2];
 struct work_struct policy_hash_work;
 struct xfrm_policy_hthresh policy_hthresh;
 struct list_head inexact_bins;


 struct sock *nlsk;
 struct sock *nlsk_stash;

 u32 sysctl_aevent_etime;
 u32 sysctl_aevent_rseqth;
 int sysctl_larval_drop;
 u32 sysctl_acq_expires;

 u8 policy_default[XFRM_POLICY_MAX];


 struct ctl_table_header *sysctl_hdr;


 struct dst_ops xfrm4_dst_ops;

 struct dst_ops xfrm6_dst_ops;

 spinlock_t xfrm_state_lock;
 seqcount_spinlock_t xfrm_state_hash_generation;
 seqcount_spinlock_t xfrm_policy_hash_generation;

 spinlock_t xfrm_policy_lock;
 struct mutex xfrm_cfg_mutex;
 struct delayed_work nat_keepalive_work;
};
struct ctl_table_header;
struct bpf_prog;
struct bpf_prog_array;
enum netns_bpf_attach_type {
 NETNS_BPF_INVALID = -1,
 NETNS_BPF_FLOW_DISSECTOR = 0,
 NETNS_BPF_SK_LOOKUP,
 MAX_NETNS_BPF_ATTACH_TYPE
};
struct netns_bpf {

 struct bpf_prog_array *run_array[MAX_NETNS_BPF_ATTACH_TYPE];
 struct bpf_prog *progs[MAX_NETNS_BPF_ATTACH_TYPE];
 struct list_head links[MAX_NETNS_BPF_ATTACH_TYPE];
};
struct ref_tracker_dir {
};
typedef struct {} netdevice_tracker;
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct task_struct;
struct file;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
};
struct inode;
struct kobject;
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
struct page;
struct kmem_cache;
struct task_struct;
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct in6_addr;
struct sk_buff;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
typedef u64 netdev_features_t;
struct bpf_prog;
struct net;
struct sk_buff;
struct ip_conntrack_stat {
 unsigned int found;
 unsigned int invalid;
 unsigned int insert;
 unsigned int insert_failed;
 unsigned int clash_resolve;
 unsigned int drop;
 unsigned int early_drop;
 unsigned int error;
 unsigned int expect_new;
 unsigned int expect_create;
 unsigned int expect_delete;
 unsigned int search_restart;
 unsigned int chaintoolong;
};
struct net_device;
struct net_device;
struct pipe_inode_info;
struct iov_iter;
struct napi_struct;
struct bpf_prog;
union bpf_attr;
struct skb_ext;
struct sk_buff;
struct skb_shared_hwtstamps {
 union {
  ktime_t hwtstamp;
  void *netdev_data;
 };
};
typedef unsigned int sk_buff_data_t;
struct sk_buff {
 union {
  struct {

   struct sk_buff *next;
   struct sk_buff *prev;

   union {
    struct net_device *dev;




    unsigned long dev_scratch;
   };
  };
  struct rb_node rbnode;
  struct list_head list;
  struct llist_node ll_node;
 };

 struct sock *sk;

 union {
  ktime_t tstamp;
  u64 skb_mstamp_ns;
 };






 char cb[48] ;

 union {
  struct {
   unsigned long _skb_refdst;
   void (*destructor)(struct sk_buff *skb);
  };
  struct list_head tcp_tsorted_anchor;



 };


 unsigned long _nfct;

 unsigned int len,
    data_len;
 __u16 mac_len,
    hdr_len;




 __u16 queue_mapping;








 __u8 __cloned_offset[1];

 __u8 cloned:1,
    nohdr:1,
    fclone:2,
    peeked:1,
    head_frag:1,
    pfmemalloc:1,
    pp_recycle:1;

 __u8 active_extensions;





 union { struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 redirected:1; __u8 nf_skip_egress:1; __u8 slow_gro:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } ; struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 redirected:1; __u8 nf_skip_egress:1; __u8 slow_gro:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } headers; }
  ;


 sk_buff_data_t tail;
 sk_buff_data_t end;
 unsigned char *head,
    *data;
 unsigned int truesize;
 refcount_t users;



 struct skb_ext *extensions;

};
enum skb_ext_id {




 SKB_EXT_SEC_PATH,
 SKB_EXT_NUM,
};
struct skb_ext {
 refcount_t refcnt;
 u8 offset[SKB_EXT_NUM];
 u8 chunks;
 char data[1] ;
};
struct user_namespace;
struct proc_dir_entry;
struct net_device;
struct sock;
struct ctl_table_header;
struct net_generic;
struct uevent_sock;
struct bpf_prog;
struct net {



 refcount_t passive;


 spinlock_t rules_mod_lock;

 unsigned int dev_base_seq;
 u32 ifindex;

 spinlock_t nsid_lock;
 atomic_t fnhe_genid;

 struct list_head list;
 struct list_head exit_list;





 struct llist_node defer_free_list;
 struct llist_node cleanup_list;

 struct list_head ptype_all;
 struct list_head ptype_specific;


 struct key_tag *key_domain;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct idr netns_ids;

 struct ns_common ns;
 struct ref_tracker_dir refcnt_tracker;
 struct ref_tracker_dir notrefcnt_tracker;


 struct list_head dev_base_head;
 struct proc_dir_entry *proc_net;
 struct proc_dir_entry *proc_net_stat;


 struct ctl_table_set sysctls;


 struct sock *rtnl;
 struct sock *genl_sock;

 struct uevent_sock *uevent_sock;

 struct hlist_head *dev_name_head;
 struct hlist_head *dev_index_head;
 struct xarray dev_by_index;
 struct raw_notifier_head netdev_chain;




 u32 hash_mix;

 struct net_device *loopback_dev;


 struct list_head rules_ops;

 struct netns_core core;
 struct netns_mib mib;
 struct netns_packet packet;

 struct netns_unix unx;

 struct netns_nexthop nexthop;
 struct netns_ipv4 ipv4;

 struct netns_ipv6 ipv6;
 struct netns_nf nf;

 struct netns_ct ct;
 struct net_generic *gen;


 struct netns_bpf bpf;



 struct netns_xfrm xfrm;


 u64 net_cookie;
 struct sock *diag_nlsk;







} ;
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct net;
typedef struct {

 struct net *net;

} possible_net_t;
struct ctl_table;
static inline    int fnhe_genid(const struct net *net)
;
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,





 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;






 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
extern char _data[], _sdata[], _edata[];
struct device;
struct irq_affinity_notify {
 unsigned int irq;
 struct kref kref;
 struct work_struct work;
 void (*notify)(struct irq_affinity_notify *, const cpumask_t *mask);
 void (*release)(struct kref *ref);
};
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct cgroup_bpf {};
struct mm_struct;
struct cgroup_subsys_state;
struct psi_group { };
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,







devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,
debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;




 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[1];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;






 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
static inline    u64 cgroup_id(const struct cgroup *cgrp)
;
void css_rstat_flush(struct cgroup_subsys_state *css);
struct netprio_map {
 struct callback_head rcu;
 u32 priomap_len;
 u32 priomap[1];
};
struct poll_table_struct;
struct pipe_inode_info;
struct inode;
struct file;
struct net;
struct vm_area_struct;
struct page;
struct sockaddr;
struct module;
struct sk_buff;
struct iovec;
struct kvec;
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct fd {
 unsigned long word;
};
struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};
enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 __MAX_BPF_MAP_TYPE
};
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};
enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 __MAX_BPF_ATTACH_TYPE
};
enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};
union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64  excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64  key;
  union {
   __u64  value;
   __u64  next_key;
  };
  __u64 flags;
 };

 struct {
  __u64  in_batch;


  __u64  out_batch;
  __u64  keys;
  __u64  values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64  insns;
  __u64  license;
  __u32 log_level;
  __u32 log_size;
  __u64  log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64  func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64  line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64  fd_array;
  __u64  core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
  __u32 fd_array_cnt;



  __u64  signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64  pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64  data_in;
  __u64  data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64  ctx_in;
  __u64  ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64  info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64  prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64  prog_attach_flags;
  __u64  link_ids;
  __u64  link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64  cookie;
 } raw_tracepoint;

 struct {
  __u64  btf;
  __u64  btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64  buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64  iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64  syms;
    __u64  addrs;
    __u64  cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64  path;
    __u64  offsets;
    __u64  ref_ctr_offsets;
    __u64  cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64  stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

} ;
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};
struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64  tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64  target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64  addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64  cookies;
  } kprobe_multi;
  struct {
   __u64  path;
   __u64  offsets;
   __u64  ref_ctr_offsets;
   __u64  cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64  file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64  func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64  tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} ;
struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};
struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};
struct sock_filter {
 __u16 code;
 __u8 jt;
 __u8 jf;
 __u32 k;
};
struct cred;
struct module;
struct btf_type {
 __u32 name_off;
 __u32 info;







 union {
  __u32 size;
  __u32 type;
 };
};
struct btf_member {
 __u32 name_off;
 __u32 type;






 __u32 offset;
};
struct btf;
struct btf_member;
struct btf_type;
union bpf_attr;
struct bpf_prog;
struct bpf_verifier_log;
struct node {
 struct device dev;
 struct list_head access_list;




};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct file;
struct mem_cgroup;
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;
};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;





 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct page;
struct io_context;
struct cgroup_subsys_state;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;



 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;
};
struct bdi_writeback;
struct mem_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
struct sock;
struct qspinlock;
struct bpf_verifier_env;
struct bpf_verifier_log;
struct perf_event;
struct bpf_prog;
struct bpf_prog_aux;
struct bpf_map;
struct bpf_arena;
struct sock;
struct seq_file;
struct btf;
struct btf_type;
struct exception_table_entry;
struct seq_operations;
struct bpf_iter_aux_info;
struct bpf_local_storage;
struct bpf_local_storage_map;
struct kobject;
struct mem_cgroup;
struct module;
struct bpf_func_state;
struct ftrace_ops;
struct cgroup;
struct bpf_token;
struct user_namespace;
struct super_block;
struct inode;
typedef u64 (*bpf_callback_t)(u64, u64, u64, u64, u64);
typedef int (*bpf_iter_init_seq_priv_t)(void *private_data,
     struct bpf_iter_aux_info *aux);
typedef void (*bpf_iter_fini_seq_priv_t)(void *private_data);
struct bpf_iter_seq_info {
 const struct seq_operations *seq_ops;
 bpf_iter_init_seq_priv_t init_seq_private;
 bpf_iter_fini_seq_priv_t fini_seq_private;
 u32 seq_priv_size;
};
struct bpf_map_ops {

 int (*map_alloc_check)(union bpf_attr *attr);
 struct bpf_map *(*map_alloc)(union bpf_attr *attr);
 void (*map_release)(struct bpf_map *map, struct file *map_file);
 void (*map_free)(struct bpf_map *map);
 int (*map_get_next_key)(struct bpf_map *map, void *key, void *next_key);
 void (*map_release_uref)(struct bpf_map *map);
 void *(*map_lookup_elem_sys_only)(struct bpf_map *map, void *key);
 int (*map_lookup_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_lookup_and_delete_elem)(struct bpf_map *map, void *key,
       void *value, u64 flags);
 int (*map_lookup_and_delete_batch)(struct bpf_map *map,
        const union bpf_attr *attr,
        union bpf_attr *uattr);
 int (*map_update_batch)(struct bpf_map *map, struct file *map_file,
    const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_delete_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);


 void *(*map_lookup_elem)(struct bpf_map *map, void *key);
 long (*map_update_elem)(struct bpf_map *map, void *key, void *value, u64 flags);
 long (*map_delete_elem)(struct bpf_map *map, void *key);
 long (*map_push_elem)(struct bpf_map *map, void *value, u64 flags);
 long (*map_pop_elem)(struct bpf_map *map, void *value);
 long (*map_peek_elem)(struct bpf_map *map, void *value);
 void *(*map_lookup_percpu_elem)(struct bpf_map *map, void *key, u32 cpu);
 int (*map_get_hash)(struct bpf_map *map, u32 hash_buf_size, void *hash_buf);


 void *(*map_fd_get_ptr)(struct bpf_map *map, struct file *map_file,
    int fd);




 void (*map_fd_put_ptr)(struct bpf_map *map, void *ptr, bool need_defer);
 int (*map_gen_lookup)(struct bpf_map *map, struct bpf_insn *insn_buf);
 u32 (*map_fd_sys_lookup_elem)(void *ptr);
 void (*map_seq_show_elem)(struct bpf_map *map, void *key,
      struct seq_file *m);
 int (*map_check_btf)(const struct bpf_map *map,
        const struct btf *btf,
        const struct btf_type *key_type,
        const struct btf_type *value_type);


 int (*map_poke_track)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_untrack)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_run)(struct bpf_map *map, u32 key, struct bpf_prog *old,
        struct bpf_prog *new);


 int (*map_direct_value_addr)(const struct bpf_map *map,
         u64 *imm, u32 off);
 int (*map_direct_value_meta)(const struct bpf_map *map,
         u64 imm, u32 *off);
 int (*map_mmap)(struct bpf_map *map, struct vm_area_struct *vma);
 __poll_t (*map_poll)(struct bpf_map *map, struct file *filp,
        struct poll_table_struct *pts);
 unsigned long (*map_get_unmapped_area)(struct file *filep, unsigned long addr,
            unsigned long len, unsigned long pgoff,
            unsigned long flags);


 int (*map_local_storage_charge)(struct bpf_local_storage_map *smap,
     void *owner, u32 size);
 void (*map_local_storage_uncharge)(struct bpf_local_storage_map *smap,
        void *owner, u32 size);
 struct bpf_local_storage ** (*map_owner_storage_ptr)(void *owner);


 long (*map_redirect)(struct bpf_map *map, u64 key, u64 flags);
 bool (*map_meta_equal)(const struct bpf_map *meta0,
          const struct bpf_map *meta1);


 int (*map_set_for_each_callback_args)(struct bpf_verifier_env *env,
           struct bpf_func_state *caller,
           struct bpf_func_state *callee);
 long (*map_for_each_callback)(struct bpf_map *map,
         bpf_callback_t callback_fn,
         void *callback_ctx, u64 flags);

 u64 (*map_mem_usage)(const struct bpf_map *map);


 int *map_btf_id;


 const struct bpf_iter_seq_info *iter_seq_info;
};
enum btf_field_type {
 BPF_SPIN_LOCK = (1 << 0),
 BPF_TIMER = (1 << 1),
 BPF_KPTR_UNREF = (1 << 2),
 BPF_KPTR_REF = (1 << 3),
 BPF_KPTR_PERCPU = (1 << 4),
 BPF_KPTR = BPF_KPTR_UNREF | BPF_KPTR_REF | BPF_KPTR_PERCPU,
 BPF_LIST_HEAD = (1 << 5),
 BPF_LIST_NODE = (1 << 6),
 BPF_RB_ROOT = (1 << 7),
 BPF_RB_NODE = (1 << 8),
 BPF_GRAPH_NODE = BPF_RB_NODE | BPF_LIST_NODE,
 BPF_GRAPH_ROOT = BPF_RB_ROOT | BPF_LIST_HEAD,
 BPF_REFCOUNT = (1 << 9),
 BPF_WORKQUEUE = (1 << 10),
 BPF_UPTR = (1 << 11),
 BPF_RES_SPIN_LOCK = (1 << 12),
 BPF_TASK_WORK = (1 << 13),
};
enum bpf_cgroup_storage_type {
 BPF_CGROUP_STORAGE_SHARED,
 BPF_CGROUP_STORAGE_PERCPU,
 __BPF_CGROUP_STORAGE_MAX
};
typedef void (*btf_dtor_kfunc_t)(void *);
struct btf_field_kptr {
 struct btf *btf;
 struct module *module;



 btf_dtor_kfunc_t dtor;
 u32 btf_id;
};
struct btf_field_graph_root {
 struct btf *btf;
 u32 value_btf_id;
 u32 node_offset;
 struct btf_record *value_rec;
};
struct btf_field {
 u32 offset;
 u32 size;
 enum btf_field_type type;
 union {
  struct btf_field_kptr kptr;
  struct btf_field_graph_root graph_root;
 };
};
struct btf_record {
 u32 cnt;
 u32 field_mask;
 int spin_lock_off;
 int res_spin_lock_off;
 int timer_off;
 int wq_off;
 int refcount_off;
 int task_work_off;
 struct btf_field fields[1];
};
struct bpf_map_owner {
 enum bpf_prog_type type;
 bool jited;
 bool xdp_has_frags;
 u64 storage_cookie[__BPF_CGROUP_STORAGE_MAX];
 const struct btf_type *attach_func_proto;
 enum bpf_attach_type expected_attach_type;
};
struct bpf_map {
 u8 sha[32];
 u32 excl;
 const struct bpf_map_ops *ops;
 struct bpf_map *inner_map_meta;

 void *security;

 enum bpf_map_type map_type;
 u32 key_size;
 u32 value_size;
 u32 max_entries;
 u64 map_extra;
 u32 map_flags;
 u32 id;
 struct btf_record *record;
 int numa_node;
 u32 btf_key_type_id;
 u32 btf_value_type_id;
 u32 btf_vmlinux_value_type_id;
 struct btf *btf;



 char name[16U];
 struct mutex freeze_mutex;
 atomic64_t refcnt;
 atomic64_t usercnt;

 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 atomic64_t writecnt;
 spinlock_t owner_lock;
 struct bpf_map_owner *owner;
 bool bypass_spec_v1;
 bool frozen;
 bool free_after_mult_rcu_gp;
 bool free_after_rcu_gp;
 atomic64_t sleepable_refcnt;
 s64 *elem_count;
 u64 cookie;
 char *excl_prog_sha;
};
struct bpf_offload_dev;
struct bpf_offloaded_map;
struct bpf_map_dev_ops {
 int (*map_get_next_key)(struct bpf_offloaded_map *map,
    void *key, void *next_key);
 int (*map_lookup_elem)(struct bpf_offloaded_map *map,
          void *key, void *value);
 int (*map_update_elem)(struct bpf_offloaded_map *map,
          void *key, void *value, u64 flags);
 int (*map_delete_elem)(struct bpf_offloaded_map *map, void *key);
};
struct bpf_offloaded_map {
 struct bpf_map map;
 struct net_device *netdev;
 const struct bpf_map_dev_ops *dev_ops;
 void *dev_priv;
 struct list_head offloads;
};
enum bpf_type_flag {

 PTR_MAYBE_NULL = ((((1UL))) << (0 + 8)),




 MEM_RDONLY = ((((1UL))) << (1 + 8)),


 MEM_RINGBUF = ((((1UL))) << (2 + 8)),


 MEM_USER = ((((1UL))) << (3 + 8)),







 MEM_PERCPU = ((((1UL))) << (4 + 8)),


 OBJ_RELEASE = ((((1UL))) << (5 + 8)),







 PTR_UNTRUSTED = ((((1UL))) << (6 + 8)),


 MEM_UNINIT = ((((1UL))) << (7 + 8)),


 DYNPTR_TYPE_LOCAL = ((((1UL))) << (8 + 8)),


 DYNPTR_TYPE_RINGBUF = ((((1UL))) << (9 + 8)),


 MEM_FIXED_SIZE = ((((1UL))) << (10 + 8)),




 MEM_ALLOC = ((((1UL))) << (11 + 8)),
 PTR_TRUSTED = ((((1UL))) << (12 + 8)),


 MEM_RCU = ((((1UL))) << (13 + 8)),





 NON_OWN_REF = ((((1UL))) << (14 + 8)),


 DYNPTR_TYPE_SKB = ((((1UL))) << (15 + 8)),


 DYNPTR_TYPE_XDP = ((((1UL))) << (16 + 8)),




 MEM_ALIGNED = ((((1UL))) << (17 + 8)),






 MEM_WRITE = ((((1UL))) << (18 + 8)),


 DYNPTR_TYPE_SKB_META = ((((1UL))) << (19 + 8)),

 __BPF_TYPE_FLAG_MAX,
 __BPF_TYPE_LAST_FLAG = __BPF_TYPE_FLAG_MAX - 1,
};
enum bpf_arg_type {
 ARG_DONTCARE = 0,




 ARG_CONST_MAP_PTR,
 ARG_PTR_TO_MAP_KEY,
 ARG_PTR_TO_MAP_VALUE,




 ARG_PTR_TO_MEM,
 ARG_PTR_TO_ARENA,

 ARG_CONST_SIZE,
 ARG_CONST_SIZE_OR_ZERO,

 ARG_PTR_TO_CTX,
 ARG_ANYTHING,
 ARG_SCALAR,
 ARG_PTR_TO_SPIN_LOCK,
 ARG_PTR_TO_SOCK_COMMON,
 ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_BTF_ID,
 ARG_PTR_TO_RINGBUF_MEM,
 ARG_CONST_ALLOC_SIZE_OR_ZERO,
 ARG_PTR_TO_BTF_ID_SOCK_COMMON,
 ARG_PTR_TO_PERCPU_BTF_ID,
 ARG_PTR_TO_FUNC,
 ARG_PTR_TO_STACK,
 ARG_PTR_TO_CONST_STR,
 ARG_PTR_TO_TIMER,
 ARG_KPTR_XCHG_DEST,
 ARG_PTR_TO_DYNPTR,
 __BPF_ARG_TYPE_MAX,


 ARG_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MAP_VALUE,
 ARG_PTR_TO_MEM_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MEM,
 ARG_PTR_TO_CTX_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_CTX,
 ARG_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_STACK_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_STACK,
 ARG_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_BTF_ID,



 ARG_PTR_TO_UNINIT_MEM = MEM_UNINIT | MEM_WRITE | ARG_PTR_TO_MEM,

 ARG_PTR_TO_FIXED_SIZE_MEM = MEM_FIXED_SIZE | ARG_PTR_TO_MEM,




 __BPF_ARG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
enum bpf_return_type {
 RET_INTEGER,
 RET_VOID,
 RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_MEM,
 RET_PTR_TO_MEM_OR_BTF_ID,
 RET_PTR_TO_BTF_ID,
 __BPF_RET_TYPE_MAX,


 RET_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_RINGBUF_MEM_OR_NULL = PTR_MAYBE_NULL | MEM_RINGBUF | RET_PTR_TO_MEM,
 RET_PTR_TO_DYNPTR_MEM_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MEM,
 RET_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_BTF_ID,
 RET_PTR_TO_BTF_ID_TRUSTED = PTR_TRUSTED | RET_PTR_TO_BTF_ID,




 __BPF_RET_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_func_proto {
 u64 (*func)(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5);
 bool gpl_only;
 bool pkt_access;
 bool might_sleep;





 bool allow_fastcall;
 enum bpf_return_type ret_type;
 union {
  struct {
   enum bpf_arg_type arg1_type;
   enum bpf_arg_type arg2_type;
   enum bpf_arg_type arg3_type;
   enum bpf_arg_type arg4_type;
   enum bpf_arg_type arg5_type;
  };
  enum bpf_arg_type arg_type[5];
 };
 union {
  struct {
   u32 *arg1_btf_id;
   u32 *arg2_btf_id;
   u32 *arg3_btf_id;
   u32 *arg4_btf_id;
   u32 *arg5_btf_id;
  };
  u32 *arg_btf_id[5];
  struct {
   size_t arg1_size;
   size_t arg2_size;
   size_t arg3_size;
   size_t arg4_size;
   size_t arg5_size;
  };
  size_t arg_size[5];
 };
 int *ret_btf_id;
 bool (*allowed)(const struct bpf_prog *prog);
};
enum bpf_access_type {
 BPF_READ = 1,
 BPF_WRITE = 2
};
enum bpf_reg_type {
 NOT_INIT = 0,
 SCALAR_VALUE,
 PTR_TO_CTX,
 CONST_PTR_TO_MAP,
 PTR_TO_MAP_VALUE,
 PTR_TO_MAP_KEY,
 PTR_TO_STACK,
 PTR_TO_PACKET_META,
 PTR_TO_PACKET,
 PTR_TO_PACKET_END,
 PTR_TO_FLOW_KEYS,
 PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK,
 PTR_TO_TP_BUFFER,
 PTR_TO_XDP_SOCK,
 PTR_TO_BTF_ID,
 PTR_TO_MEM,
 PTR_TO_ARENA,
 PTR_TO_BUF,
 PTR_TO_FUNC,
 CONST_PTR_TO_DYNPTR,
 __BPF_REG_TYPE_MAX,


 PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | PTR_TO_MAP_VALUE,
 PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | PTR_TO_TCP_SOCK,




 PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | PTR_TO_BTF_ID,




 __BPF_REG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_insn_access_aux {
 enum bpf_reg_type reg_type;
 bool is_ldsx;
 union {
  int ctx_field_size;
  struct {
   struct btf *btf;
   u32 btf_id;
   u32 ref_obj_id;
  };
 };
 struct bpf_verifier_log *log;
 bool is_retval;
};
struct bpf_prog_ops {
 int (*test_run)(struct bpf_prog *prog, const union bpf_attr *kattr,
   union bpf_attr *uattr);
};
struct bpf_reg_state;
struct bpf_verifier_ops {

 const struct bpf_func_proto *
 (*get_func_proto)(enum bpf_func_id func_id,
     const struct bpf_prog *prog);




 bool (*is_valid_access)(int off, int size, enum bpf_access_type type,
    const struct bpf_prog *prog,
    struct bpf_insn_access_aux *info);
 int (*gen_prologue)(struct bpf_insn *insn, bool direct_write,
       const struct bpf_prog *prog);
 int (*gen_epilogue)(struct bpf_insn *insn, const struct bpf_prog *prog,
       s16 ctx_stack_off);
 int (*gen_ld_abs)(const struct bpf_insn *orig,
     struct bpf_insn *insn_buf);
 u32 (*convert_ctx_access)(enum bpf_access_type type,
      const struct bpf_insn *src,
      struct bpf_insn *dst,
      struct bpf_prog *prog, u32 *target_size);
 int (*btf_struct_access)(struct bpf_verifier_log *log,
     const struct bpf_reg_state *reg,
     int off, int size);
};
struct bpf_prog_offload {
 struct bpf_prog *prog;
 struct net_device *netdev;
 struct bpf_offload_dev *offdev;
 void *dev_priv;
 struct list_head offloads;
 bool dev_state;
 bool opt_failed;
 void *jited_image;
 u32 jited_len;
};
struct btf_func_model {
 u8 ret_size;
 u8 ret_flags;
 u8 nr_args;
 u8 arg_size[12];
 u8 arg_flags[12];
};
struct bpf_tramp_image;
struct bpf_ksym {
 unsigned long start;
 unsigned long end;
 char name[512];
 struct list_head lnode;
 struct latch_tree_node tnode;
 bool prog;
};
enum bpf_tramp_prog_type {
 BPF_TRAMP_FENTRY,
 BPF_TRAMP_FEXIT,
 BPF_TRAMP_MODIFY_RETURN,
 BPF_TRAMP_MAX,
 BPF_TRAMP_REPLACE,
};
struct bpf_tramp_image {
 void *image;
 int size;
 struct bpf_ksym ksym;
 struct percpu_ref pcref;
 void *ip_after_call;
 void *ip_epilogue;
 union {
  struct callback_head rcu;
  struct work_struct work;
 };
};
struct bpf_trampoline {

 struct hlist_node hlist;
 struct ftrace_ops *fops;

 struct mutex mutex;
 refcount_t refcnt;
 u32 flags;
 u64 key;
 struct {
  struct btf_func_model model;
  void *addr;
  bool ftrace_managed;
 } func;




 struct bpf_prog *extension_prog;

 struct hlist_head progs_hlist[BPF_TRAMP_MAX];

 int progs_cnt[BPF_TRAMP_MAX];

 struct bpf_tramp_image *cur_image;
};
struct bpf_func_info_aux {
 u16 linkage;
 bool unreliable;
 bool called : 1;
 bool verified : 1;
};
struct bpf_jit_poke_descriptor {
 void *tailcall_target;
 void *tailcall_bypass;
 void *bypass_addr;
 void *aux;
 union {
  struct {
   struct bpf_map *map;
   u32 key;
  } tail_call;
 };
 bool tailcall_target_stable;
 u8 adj_off;
 u16 reason;
 u32 insn_idx;
};
struct bpf_ctx_arg_aux {
 u32 offset;
 enum bpf_reg_type reg_type;
 struct btf *btf;
 u32 btf_id;
 u32 ref_obj_id;
 bool refcounted;
};
struct btf_mod_pair {
 struct btf *btf;
 struct module *module;
};
struct bpf_kfunc_desc_tab;
struct bpf_stream {
 atomic_t capacity;
 struct llist_head log;

 struct mutex lock;
 struct llist_node *backlog_head;
 struct llist_node *backlog_tail;
};
struct bpf_prog_aux {
 atomic64_t refcnt;
 u32 used_map_cnt;
 u32 used_btf_cnt;
 u32 max_ctx_offset;
 u32 max_pkt_offset;
 u32 max_tp_access;
 u32 stack_depth;
 u32 id;
 u32 func_cnt;
 u32 real_func_cnt;
 u32 func_idx;
 u32 attach_btf_id;
 u32 attach_st_ops_member_off;
 u32 ctx_arg_info_size;
 u32 max_rdonly_access;
 u32 max_rdwr_access;
 struct btf *attach_btf;
 struct bpf_ctx_arg_aux *ctx_arg_info;
 void *priv_stack_ptr;
 struct mutex dst_mutex;
 struct bpf_prog *dst_prog;
 struct bpf_trampoline *dst_trampoline;
 enum bpf_prog_type saved_dst_prog_type;
 enum bpf_attach_type saved_dst_attach_type;
 bool verifier_zext;
 bool dev_bound;
 bool offload_requested;
 bool attach_btf_trace;
 bool attach_tracing_prog;
 bool func_proto_unreliable;
 bool tail_call_reachable;
 bool xdp_has_frags;
 bool exception_cb;
 bool exception_boundary;
 bool is_extended;
 bool jits_use_priv_stack;
 bool priv_stack_requested;
 bool changes_pkt_data;
 bool might_sleep;
 bool kprobe_write_ctx;
 u64 prog_array_member_cnt;
 struct mutex ext_mutex;
 struct bpf_arena *arena;
 void (*recursion_detected)(struct bpf_prog *prog);

 const struct btf_type *attach_func_proto;

 const char *attach_func_name;
 struct bpf_prog **func;
 struct bpf_prog_aux *main_prog_aux;
 void *jit_data;
 struct bpf_jit_poke_descriptor *poke_tab;
 struct bpf_kfunc_desc_tab *kfunc_tab;
 struct bpf_kfunc_btf_tab *kfunc_btf_tab;
 u32 size_poke_tab;



 struct bpf_ksym ksym;
 const struct bpf_prog_ops *ops;
 const struct bpf_struct_ops *st_ops;
 struct bpf_map **used_maps;
 struct mutex used_maps_mutex;
 struct btf_mod_pair *used_btfs;
 struct bpf_prog *prog;
 struct user_struct *user;
 u64 load_time;
 u32 verified_insns;
 int cgroup_atype;
 struct bpf_map *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
 char name[16U];
 u64 (*bpf_exception_cb)(u64 cookie, u64 sp, u64 bp, u64, u64);

 void *security;

 struct bpf_token *token;
 struct bpf_prog_offload *offload;
 struct btf *btf;
 struct bpf_func_info *func_info;
 struct bpf_func_info_aux *func_info_aux;






 struct bpf_line_info *linfo;







 void **jited_linfo;
 u32 func_info_cnt;
 u32 nr_linfo;




 u32 linfo_idx;
 struct module *mod;
 u32 num_exentries;
 struct exception_table_entry *extable;
 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 struct bpf_stream stream[2];
};
struct bpf_prog {
 u16 pages;
 u16 jited:1,
    jit_requested:1,
    gpl_compatible:1,
    cb_access:1,
    dst_needed:1,
    blinding_requested:1,
    blinded:1,
    is_func:1,
    kprobe_override:1,
    has_callchain_buf:1,
    enforce_expected_attach_type:1,
    call_get_stack:1,
    call_get_func_ip:1,
    tstamp_type_access:1,
    sleepable:1;
 enum bpf_prog_type type;
 enum bpf_attach_type expected_attach_type;
 u32 len;
 u32 jited_len;
 union {
  u8 digest[32];
  u8 tag[8];
 };
 struct bpf_prog_stats *stats;
 int *active;
 unsigned int (*bpf_func)(const void *ctx,
         const struct bpf_insn *insn);
 struct bpf_prog_aux *aux;
 struct sock_fprog_kern *orig_prog;

 union {
  struct { struct { } __empty_insns; struct sock_filter insns[1]; };
  struct { struct { } __empty_insnsi; struct bpf_insn insnsi[1]; };
 };
};
struct bpf_link {
 atomic64_t refcnt;
 u32 id;
 enum bpf_link_type type;
 const struct bpf_link_ops *ops;
 struct bpf_prog *prog;

 u32 flags;
 enum bpf_attach_type attach_type;




 union {
  struct callback_head rcu;
  struct work_struct work;
 };




 bool sleepable;
};
struct bpf_link_ops {
 void (*release)(struct bpf_link *link);



 void (*dealloc)(struct bpf_link *link);






 void (*dealloc_deferred)(struct bpf_link *link);
 int (*detach)(struct bpf_link *link);
 int (*update_prog)(struct bpf_link *link, struct bpf_prog *new_prog,
      struct bpf_prog *old_prog);
 void (*show_fdinfo)(const struct bpf_link *link, struct seq_file *seq);
 int (*fill_link_info)(const struct bpf_link *link,
         struct bpf_link_info *info);
 int (*update_map)(struct bpf_link *link, struct bpf_map *new_map,
     struct bpf_map *old_map);
 __poll_t (*poll)(struct file *file, struct poll_table_struct *pts);
};
struct bpf_token {
 struct work_struct work;
 atomic64_t refcnt;
 struct user_namespace *userns;
 u64 allowed_cmds;
 u64 allowed_maps;
 u64 allowed_progs;
 u64 allowed_attachs;

 void *security;

};
struct btf_member;
struct bpf_struct_ops {
 const struct bpf_verifier_ops *verifier_ops;
 int (*init)(struct btf *btf);
 int (*check_member)(const struct btf_type *t,
       const struct btf_member *member,
       const struct bpf_prog *prog);
 int (*init_member)(const struct btf_type *t,
      const struct btf_member *member,
      void *kdata, const void *udata);
 int (*reg)(void *kdata, struct bpf_link *link);
 void (*unreg)(void *kdata, struct bpf_link *link);
 int (*update)(void *kdata, void *old_kdata, struct bpf_link *link);
 int (*validate)(void *kdata);
 void *cfi_stubs;
 struct module *owner;
 const char *name;
 struct btf_func_model func_models[64];
};
struct bpf_prog_array_item {
 struct bpf_prog *prog;
 union {
  struct bpf_cgroup_storage *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
  u64 bpf_cookie;
 };
};
struct bpf_prog_array {
 struct callback_head rcu;
 struct bpf_prog_array_item items[1];
};
struct xdp_frame;
struct sk_buff;
static inline    int btf_struct_access(struct bpf_verifier_log *log,
        const struct bpf_reg_state *reg,
        int off, int size, enum bpf_access_type atype,
        u32 *next_btf_id, enum bpf_type_flag *flag,
        const char **field_name)
;
struct key;
struct cred;
struct rlimit;
struct kernel_siginfo;
struct audit_context;
struct super_block;
struct inode;
struct dentry;
struct file;
struct vfsmount;
struct path;
struct qstr;
struct iattr;
struct fown_struct;
struct file_operations;
struct kernfs_node;
struct mm_struct;
struct fs_context;
struct ctl_table;
struct user_namespace;
struct sk_buff;
struct sock;
struct sockaddr;
struct dst_entry;
struct seq_file;
struct perf_event;
struct sock;
struct nlmsghdr {
 __u32 nlmsg_len;
 __u16 nlmsg_type;
 __u16 nlmsg_flags;
 __u32 nlmsg_seq;
 __u32 nlmsg_pid;
};
struct nlattr {
 __u16 nla_len;
 __u16 nla_type;
};
struct net;
struct netlink_ext_ack {
 const char *_msg;
 const struct nlattr *bad_attr;
 const struct nla_policy *policy;
 const struct nlattr *miss_nest;
 u16 miss_type;
 u8 cookie[8];
 u8 cookie_len;
 char _msg_buf[80];
};
struct netlink_callback {
 struct sk_buff *skb;
 const struct nlmsghdr *nlh;
 int (*dump)(struct sk_buff * skb,
     struct netlink_callback *cb);
 int (*done)(struct netlink_callback *cb);
 void *data;

 struct module *module;
 struct netlink_ext_ack *extack;
 u16 family;
 u16 answer_flags;
 u32 min_dump_alloc;
 unsigned int prev_seq, seq;
 int flags;
 bool strict_check;
 union {
  u8 ctx[48];




  long args[6];
 };
};
struct ndmsg {
 __u8 ndm_family;
 __u8 ndm_pad1;
 __u16 ndm_pad2;
 __s32 ndm_ifindex;
 __u16 ndm_state;
 __u8 ndm_flags;
 __u8 ndm_type;
};
struct rtnl_link_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
 __u64 collisions;


 __u64 rx_length_errors;
 __u64 rx_over_errors;
 __u64 rx_crc_errors;
 __u64 rx_frame_errors;
 __u64 rx_fifo_errors;
 __u64 rx_missed_errors;


 __u64 tx_aborted_errors;
 __u64 tx_carrier_errors;
 __u64 tx_fifo_errors;
 __u64 tx_heartbeat_errors;
 __u64 tx_window_errors;


 __u64 rx_compressed;
 __u64 tx_compressed;
 __u64 rx_nohandler;

 __u64 rx_otherhost_dropped;
};
struct rtnl_hw_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
};
struct ifla_vf_guid {
 __u32 vf;
 __u64 guid;
};
struct ifla_vf_stats {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 broadcast;
 __u64 multicast;
 __u64 rx_dropped;
 __u64 tx_dropped;
};
struct ifla_vf_info {
 __u32 vf;
 __u8 mac[32];
 __u32 vlan;
 __u32 qos;
 __u32 spoofchk;
 __u32 linkstate;
 __u32 min_tx_rate;
 __u32 max_tx_rate;
 __u32 rss_query_en;
 __u32 trusted;
 __be16 vlan_proto;
};
enum {
 NEIGH_ARP_TABLE = 0,
 NEIGH_ND_TABLE = 1,
 NEIGH_NR_TABLES,
 NEIGH_LINK_TABLE = NEIGH_NR_TABLES
};
struct netpoll_info;
struct device;
struct ethtool_ops;
struct kernel_hwtstamp_config;
struct phy_device;
struct ip_tunnel_parm_kern;
struct netdev_config;
struct netdev_name_node;
struct sfp_bus;
struct wireless_dev;
struct udp_tunnel_nic_info;
struct udp_tunnel_nic;
struct bpf_prog;
struct xdp_buff;
struct xdp_frame;
struct xdp_metadata_ops;
struct ethtool_netdev_state;
struct phy_link_topology;
struct hwtstamp_provider;
typedef u32 xdp_features_t;
enum netdev_tx {
 __NETDEV_TX_MIN = (-((int)(~0U >> 1)) - 1),
 NETDEV_TX_OK = 0x00,
 NETDEV_TX_BUSY = 0x10,
};
typedef enum netdev_tx netdev_tx_t;
struct net_device_stats {
 union { unsigned long rx_packets; atomic_long_t __rx_packets; };
 union { unsigned long tx_packets; atomic_long_t __tx_packets; };
 union { unsigned long rx_bytes; atomic_long_t __rx_bytes; };
 union { unsigned long tx_bytes; atomic_long_t __tx_bytes; };
 union { unsigned long rx_errors; atomic_long_t __rx_errors; };
 union { unsigned long tx_errors; atomic_long_t __tx_errors; };
 union { unsigned long rx_dropped; atomic_long_t __rx_dropped; };
 union { unsigned long tx_dropped; atomic_long_t __tx_dropped; };
 union { unsigned long multicast; atomic_long_t __multicast; };
 union { unsigned long collisions; atomic_long_t __collisions; };
 union { unsigned long rx_length_errors; atomic_long_t __rx_length_errors; };
 union { unsigned long rx_over_errors; atomic_long_t __rx_over_errors; };
 union { unsigned long rx_crc_errors; atomic_long_t __rx_crc_errors; };
 union { unsigned long rx_frame_errors; atomic_long_t __rx_frame_errors; };
 union { unsigned long rx_fifo_errors; atomic_long_t __rx_fifo_errors; };
 union { unsigned long rx_missed_errors; atomic_long_t __rx_missed_errors; };
 union { unsigned long tx_aborted_errors; atomic_long_t __tx_aborted_errors; };
 union { unsigned long tx_carrier_errors; atomic_long_t __tx_carrier_errors; };
 union { unsigned long tx_fifo_errors; atomic_long_t __tx_fifo_errors; };
 union { unsigned long tx_heartbeat_errors; atomic_long_t __tx_heartbeat_errors; };
 union { unsigned long tx_window_errors; atomic_long_t __tx_window_errors; };
 union { unsigned long rx_compressed; atomic_long_t __rx_compressed; };
 union { unsigned long tx_compressed; atomic_long_t __tx_compressed; };
};
struct net_device_core_stats {
 unsigned long rx_dropped;
 unsigned long tx_dropped;
 unsigned long rx_nohandler;
 unsigned long rx_otherhost_dropped;
} ;
struct neighbour;
struct neigh_parms;
struct sk_buff;
struct netdev_hw_addr_list {
 struct list_head list;
 int count;


 struct rb_root tree;
};
struct hh_cache {
 unsigned int hh_len;
 seqlock_t hh_lock;




 unsigned long hh_data[(((96)+(16 -1))&~(16 - 1)) / sizeof(long)];
};
struct header_ops {
 int (*create) (struct sk_buff *skb, struct net_device *dev,
      unsigned short type, const void *daddr,
      const void *saddr, unsigned int len);
 int (*parse)(const struct sk_buff *skb,
    const struct net_device *dev,
    unsigned char *haddr);
 int (*cache)(const struct neighbour *neigh, struct hh_cache *hh, __be16 type);
 void (*cache_update)(struct hh_cache *hh,
    const struct net_device *dev,
    const unsigned char *haddr);
 bool (*validate)(const char *ll_header, unsigned int len);
 __be16 (*parse_protocol)(const struct sk_buff *skb);
};
struct gro_list {
 struct list_head list;
 int count;
};
struct gro_node {
 unsigned long bitmask;
 struct gro_list hash[8];
 struct list_head rx_list;
 u32 rx_count;
 u32 cached_napi_id;
};
struct napi_config {
 u64 gro_flush_timeout;
 u64 irq_suspend_timeout;
 u32 defer_hard_irqs;
 cpumask_t affinity_mask;
 u8 threaded;
 unsigned int napi_id;
};
struct napi_struct {






 struct list_head poll_list;

 unsigned long state;
 int weight;
 u32 defer_hard_irqs_count;
 int (*poll)(struct napi_struct *, int);


 int poll_owner;


 int list_owner;
 struct net_device *dev;
 struct sk_buff *skb;
 struct gro_node gro;
 struct hrtimer timer;

 struct task_struct *thread;
 unsigned long gro_flush_timeout;
 unsigned long irq_suspend_timeout;
 u32 defer_hard_irqs;

 u32 napi_id;
 struct list_head dev_list;
 struct hlist_node napi_hash_node;
 int irq;
 struct irq_affinity_notify notify;
 int napi_rmap_idx;
 int index;
 struct napi_config *config;
};
enum rx_handler_result {
 RX_HANDLER_CONSUMED,
 RX_HANDLER_ANOTHER,
 RX_HANDLER_EXACT,
 RX_HANDLER_PASS,
};
typedef enum rx_handler_result rx_handler_result_t;
typedef rx_handler_result_t rx_handler_func_t(struct sk_buff **pskb);
struct netdev_queue {



 struct net_device *dev;
 netdevice_tracker dev_tracker;

 struct Qdisc *qdisc;
 struct Qdisc *qdisc_sleeping;

 struct kobject kobj;
 const struct attribute_group **groups;

 unsigned long tx_maxrate;




 atomic_long_t trans_timeout;


 struct net_device *sb_dev;
 struct dql dql;

 spinlock_t _xmit_lock ;
 int xmit_lock_owner;



 unsigned long trans_start;

 unsigned long state;







 struct napi_struct *napi;


 int numa_node;

} ;
enum xps_map_type {
 XPS_CPUS = 0,
 XPS_RXQS,
 XPS_MAPS_MAX,
};
struct xps_map {
 unsigned int len;
 unsigned int alloc_len;
 struct callback_head rcu;
 u16 queues[1];
};
struct xps_dev_maps {
 struct callback_head rcu;
 unsigned int nr_ids;
 s16 num_tc;
 struct xps_map *attr_map[1];
};
struct netdev_tc_txq {
 u16 count;
 u16 offset;
};
struct netdev_phys_item_id {
 unsigned char id[32];
 unsigned char id_len;
};
enum net_device_path_type {
 DEV_PATH_ETHERNET = 0,
 DEV_PATH_VLAN,
 DEV_PATH_BRIDGE,
 DEV_PATH_PPPOE,
 DEV_PATH_DSA,
 DEV_PATH_MTK_WDMA,
};
struct net_device_path {
 enum net_device_path_type type;
 const struct net_device *dev;
 union {
  struct {
   u16 id;
   __be16 proto;
   u8 h_dest[6];
  } encap;
  struct {
   enum {
    DEV_PATH_BR_VLAN_KEEP,
    DEV_PATH_BR_VLAN_TAG,
    DEV_PATH_BR_VLAN_UNTAG,
    DEV_PATH_BR_VLAN_UNTAG_HW,
   } vlan_mode;
   u16 vlan_id;
   __be16 vlan_proto;
  } bridge;
  struct {
   int port;
   u16 proto;
  } dsa;
  struct {
   u8 wdma_idx;
   u8 queue;
   u16 wcid;
   u8 bss;
   u8 amsdu;
  } mtk_wdma;
 };
};
struct net_device_path_ctx {
 const struct net_device *dev;
 u8 daddr[6];

 int num_vlans;
 struct {
  u16 id;
  __be16 proto;
 } vlan[2];
};
enum tc_setup_type {
 TC_QUERY_CAPS,
 TC_SETUP_QDISC_MQPRIO,
 TC_SETUP_CLSU32,
 TC_SETUP_CLSFLOWER,
 TC_SETUP_CLSMATCHALL,
 TC_SETUP_CLSBPF,
 TC_SETUP_BLOCK,
 TC_SETUP_QDISC_CBS,
 TC_SETUP_QDISC_RED,
 TC_SETUP_QDISC_PRIO,
 TC_SETUP_QDISC_MQ,
 TC_SETUP_QDISC_ETF,
 TC_SETUP_ROOT_QDISC,
 TC_SETUP_QDISC_GRED,
 TC_SETUP_QDISC_TAPRIO,
 TC_SETUP_FT,
 TC_SETUP_QDISC_ETS,
 TC_SETUP_QDISC_TBF,
 TC_SETUP_QDISC_FIFO,
 TC_SETUP_QDISC_HTB,
 TC_SETUP_ACT,
};
enum bpf_netdev_command {







 XDP_SETUP_PROG,
 XDP_SETUP_PROG_HW,

 BPF_OFFLOAD_MAP_ALLOC,
 BPF_OFFLOAD_MAP_FREE,
 XDP_SETUP_XSK_POOL,
};
struct netlink_ext_ack;
struct xdp_dev_bulk_queue;
struct bpf_xdp_link;
enum bpf_xdp_mode {
 XDP_MODE_SKB = 0,
 XDP_MODE_DRV = 1,
 XDP_MODE_HW = 2,
 __MAX_XDP_MODE
};
struct bpf_xdp_entity {
 struct bpf_prog *prog;
 struct bpf_xdp_link *link;
};
struct netdev_bpf {
 enum bpf_netdev_command command;
 union {

  struct {
   u32 flags;
   struct bpf_prog *prog;
   struct netlink_ext_ack *extack;
  };

  struct {
   struct bpf_offloaded_map *offmap;
  };

  struct {
   struct xsk_buff_pool *pool;
   u16 queue_id;
  } xsk;
 };
};
struct dev_ifalias {
 struct callback_head rcuhead;
 char ifalias[1];
};
struct net_device_ops {
 int (*ndo_init)(struct net_device *dev);
 void (*ndo_uninit)(struct net_device *dev);
 int (*ndo_open)(struct net_device *dev);
 int (*ndo_stop)(struct net_device *dev);
 netdev_tx_t (*ndo_start_xmit)(struct sk_buff *skb,
        struct net_device *dev);
 netdev_features_t (*ndo_features_check)(struct sk_buff *skb,
            struct net_device *dev,
            netdev_features_t features);
 u16 (*ndo_select_queue)(struct net_device *dev,
          struct sk_buff *skb,
          struct net_device *sb_dev);
 void (*ndo_change_rx_flags)(struct net_device *dev,
             int flags);
 void (*ndo_set_rx_mode)(struct net_device *dev);
 int (*ndo_set_mac_address)(struct net_device *dev,
             void *addr);
 int (*ndo_validate_addr)(struct net_device *dev);
 int (*ndo_do_ioctl)(struct net_device *dev,
             struct ifreq *ifr, int cmd);
 int (*ndo_eth_ioctl)(struct net_device *dev,
       struct ifreq *ifr, int cmd);
 int (*ndo_siocbond)(struct net_device *dev,
      struct ifreq *ifr, int cmd);
 int (*ndo_siocwandev)(struct net_device *dev,
        struct if_settings *ifs);
 int (*ndo_siocdevprivate)(struct net_device *dev,
            struct ifreq *ifr,
            void *data, int cmd);
 int (*ndo_set_config)(struct net_device *dev,
               struct ifmap *map);
 int (*ndo_change_mtu)(struct net_device *dev,
        int new_mtu);
 int (*ndo_neigh_setup)(struct net_device *dev,
         struct neigh_parms *);
 void (*ndo_tx_timeout) (struct net_device *dev,
         unsigned int txqueue);

 void (*ndo_get_stats64)(struct net_device *dev,
         struct rtnl_link_stats64 *storage);
 bool (*ndo_has_offload_stats)(const struct net_device *dev, int attr_id);
 int (*ndo_get_offload_stats)(int attr_id,
        const struct net_device *dev,
        void *attr_data);
 struct net_device_stats* (*ndo_get_stats)(struct net_device *dev);

 int (*ndo_vlan_rx_add_vid)(struct net_device *dev,
             __be16 proto, u16 vid);
 int (*ndo_vlan_rx_kill_vid)(struct net_device *dev,
              __be16 proto, u16 vid);

 void (*ndo_poll_controller)(struct net_device *dev);
 int (*ndo_netpoll_setup)(struct net_device *dev);
 void (*ndo_netpoll_cleanup)(struct net_device *dev);

 int (*ndo_set_vf_mac)(struct net_device *dev,
        int queue, u8 *mac);
 int (*ndo_set_vf_vlan)(struct net_device *dev,
         int queue, u16 vlan,
         u8 qos, __be16 proto);
 int (*ndo_set_vf_rate)(struct net_device *dev,
         int vf, int min_tx_rate,
         int max_tx_rate);
 int (*ndo_set_vf_spoofchk)(struct net_device *dev,
             int vf, bool setting);
 int (*ndo_set_vf_trust)(struct net_device *dev,
          int vf, bool setting);
 int (*ndo_get_vf_config)(struct net_device *dev,
           int vf,
           struct ifla_vf_info *ivf);
 int (*ndo_set_vf_link_state)(struct net_device *dev,
        int vf, int link_state);
 int (*ndo_get_vf_stats)(struct net_device *dev,
          int vf,
          struct ifla_vf_stats
          *vf_stats);
 int (*ndo_set_vf_port)(struct net_device *dev,
         int vf,
         struct nlattr *port[]);
 int (*ndo_get_vf_port)(struct net_device *dev,
         int vf, struct sk_buff *skb);
 int (*ndo_get_vf_guid)(struct net_device *dev,
         int vf,
         struct ifla_vf_guid *node_guid,
         struct ifla_vf_guid *port_guid);
 int (*ndo_set_vf_guid)(struct net_device *dev,
         int vf, u64 guid,
         int guid_type);
 int (*ndo_set_vf_rss_query_en)(
         struct net_device *dev,
         int vf, bool setting);
 int (*ndo_setup_tc)(struct net_device *dev,
      enum tc_setup_type type,
      void *type_data);
 int (*ndo_rx_flow_steer)(struct net_device *dev,
           const struct sk_buff *skb,
           u16 rxq_index,
           u32 flow_id);

 int (*ndo_add_slave)(struct net_device *dev,
       struct net_device *slave_dev,
       struct netlink_ext_ack *extack);
 int (*ndo_del_slave)(struct net_device *dev,
       struct net_device *slave_dev);
 struct net_device* (*ndo_get_xmit_slave)(struct net_device *dev,
            struct sk_buff *skb,
            bool all_slaves);
 struct net_device* (*ndo_sk_get_lower_dev)(struct net_device *dev,
       struct sock *sk);
 netdev_features_t (*ndo_fix_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_set_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_neigh_construct)(struct net_device *dev,
             struct neighbour *n);
 void (*ndo_neigh_destroy)(struct net_device *dev,
           struct neighbour *n);

 int (*ndo_fdb_add)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            u16 flags,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del_bulk)(struct nlmsghdr *nlh,
          struct net_device *dev,
          struct netlink_ext_ack *extack);
 int (*ndo_fdb_dump)(struct sk_buff *skb,
      struct netlink_callback *cb,
      struct net_device *dev,
      struct net_device *filter_dev,
      int *idx);
 int (*ndo_fdb_get)(struct sk_buff *skb,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid, u32 portid, u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_add)(struct net_device *dev,
            struct nlattr *tb[],
            u16 nlmsg_flags,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del)(struct net_device *dev,
            struct nlattr *tb[],
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del_bulk)(struct net_device *dev,
          struct nlattr *tb[],
          struct netlink_ext_ack *extack);
 int (*ndo_mdb_dump)(struct net_device *dev,
      struct sk_buff *skb,
      struct netlink_callback *cb);
 int (*ndo_mdb_get)(struct net_device *dev,
            struct nlattr *tb[], u32 portid,
            u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_setlink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_getlink)(struct sk_buff *skb,
            u32 pid, u32 seq,
            struct net_device *dev,
            u32 filter_mask,
            int nlflags);
 int (*ndo_bridge_dellink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags);
 int (*ndo_change_carrier)(struct net_device *dev,
            bool new_carrier);
 int (*ndo_get_phys_port_id)(struct net_device *dev,
       struct netdev_phys_item_id *ppid);
 int (*ndo_get_port_parent_id)(struct net_device *dev,
         struct netdev_phys_item_id *ppid);
 int (*ndo_get_phys_port_name)(struct net_device *dev,
         char *name, size_t len);
 void* (*ndo_dfwd_add_station)(struct net_device *pdev,
       struct net_device *dev);
 void (*ndo_dfwd_del_station)(struct net_device *pdev,
       void *priv);

 int (*ndo_set_tx_maxrate)(struct net_device *dev,
            int queue_index,
            u32 maxrate);
 int (*ndo_get_iflink)(const struct net_device *dev);
 int (*ndo_fill_metadata_dst)(struct net_device *dev,
             struct sk_buff *skb);
 void (*ndo_set_rx_headroom)(struct net_device *dev,
             int needed_headroom);
 int (*ndo_bpf)(struct net_device *dev,
        struct netdev_bpf *bpf);
 int (*ndo_xdp_xmit)(struct net_device *dev, int n,
      struct xdp_frame **xdp,
      u32 flags);
 struct net_device * (*ndo_xdp_get_xmit_slave)(struct net_device *dev,
         struct xdp_buff *xdp);
 int (*ndo_xsk_wakeup)(struct net_device *dev,
        u32 queue_id, u32 flags);
 int (*ndo_tunnel_ctl)(struct net_device *dev,
        struct ip_tunnel_parm_kern *p,
        int cmd);
 struct net_device * (*ndo_get_peer_dev)(struct net_device *dev);
 int (*ndo_fill_forward_path)(struct net_device_path_ctx *ctx,
                                                         struct net_device_path *path);
 ktime_t (*ndo_get_tstamp)(struct net_device *dev,
        const struct skb_shared_hwtstamps *hwtstamps,
        bool cycles);
 int (*ndo_hwtstamp_get)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config);
 int (*ndo_hwtstamp_set)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config,
          struct netlink_ext_ack *extack);
};
enum netdev_ml_priv_type {
 ML_PRIV_NONE,
 ML_PRIV_CAN,
};
enum netdev_stat_type {
 NETDEV_PCPU_STAT_NONE,
 NETDEV_PCPU_STAT_LSTATS,
 NETDEV_PCPU_STAT_TSTATS,
 NETDEV_PCPU_STAT_DSTATS,
};
struct net_device {






 __u8 __cacheline_group_begin__net_device_read_tx[1];
 union { struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } ; struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } priv_flags_fast; }



  ;
 const struct net_device_ops *netdev_ops;
 const struct header_ops *header_ops;
 struct netdev_queue *_tx;
 netdev_features_t gso_partial_features;
 unsigned int real_num_tx_queues;
 unsigned int gso_max_size;
 unsigned int gso_ipv4_max_size;
 u16 gso_max_segs;
 s16 num_tc;





 unsigned int mtu;
 unsigned short needed_headroom;
 struct netdev_tc_txq tc_to_txq[16];

 struct xps_dev_maps *xps_maps[XPS_MAPS_MAX];


 struct nf_hook_entries *nf_hooks_egress;


 struct bpf_mprog_entry *tcx_egress;

 __u8 __cacheline_group_end__net_device_read_tx[1];


 __u8 __cacheline_group_begin__net_device_read_txrx[1];
 union {
  struct pcpu_lstats *lstats;
  struct pcpu_sw_netstats *tstats;
  struct pcpu_dstats *dstats;
 };
 unsigned long state;
 unsigned int flags;
 unsigned short hard_header_len;
 enum netdev_stat_type pcpu_stat_type:8;
 netdev_features_t features;
 struct inet6_dev *ip6_ptr;
 __u8 __cacheline_group_end__net_device_read_txrx[1];


 __u8 __cacheline_group_begin__net_device_read_rx[1];
 struct bpf_prog *xdp_prog;
 struct list_head ptype_specific;
 int ifindex;
 unsigned int real_num_rx_queues;
 struct netdev_rx_queue *_rx;
 unsigned int gro_max_size;
 unsigned int gro_ipv4_max_size;
 rx_handler_func_t *rx_handler;
 void *rx_handler_data;
 possible_net_t nd_net;

 struct netpoll_info *npinfo;


 struct bpf_mprog_entry *tcx_ingress;

 __u8 __cacheline_group_end__net_device_read_rx[1];

 char name[16];
 struct netdev_name_node *name_node;
 struct dev_ifalias *ifalias;




 unsigned long mem_end;
 unsigned long mem_start;
 unsigned long base_addr;
 struct list_head dev_list;
 struct list_head napi_list;
 struct list_head unreg_list;
 struct list_head close_list;
 struct list_head ptype_all;

 struct {
  struct list_head upper;
  struct list_head lower;
 } adj_list;


 xdp_features_t xdp_features;
 const struct xdp_metadata_ops *xdp_metadata_ops;
 const struct xsk_tx_metadata_ops *xsk_tx_metadata_ops;
 unsigned short gflags;

 unsigned short needed_tailroom;

 netdev_features_t hw_features;
 netdev_features_t wanted_features;
 netdev_features_t vlan_features;
 netdev_features_t hw_enc_features;
 netdev_features_t mpls_features;
 netdev_features_t mangleid_features;

 unsigned int min_mtu;
 unsigned int max_mtu;
 unsigned short type;
 unsigned char min_header_len;
 unsigned char name_assign_type;

 int group;

 struct net_device_stats stats;

 struct net_device_core_stats *core_stats;


 atomic_t carrier_up_count;
 atomic_t carrier_down_count;




 const struct ethtool_ops *ethtool_ops;




 const struct ndisc_ops *ndisc_ops;
 unsigned int operstate;
 unsigned char link_mode;

 unsigned char if_port;
 unsigned char dma;


 unsigned char perm_addr[32];
 unsigned char addr_assign_type;
 unsigned char addr_len;
 unsigned char upper_level;
 unsigned char lower_level;
 u8 threaded;

 unsigned short neigh_priv_len;
 unsigned short dev_id;
 unsigned short dev_port;
 int irq;
 u32 priv_len;

 spinlock_t addr_list_lock;

 struct netdev_hw_addr_list uc;
 struct netdev_hw_addr_list mc;
 struct netdev_hw_addr_list dev_addrs;


 struct kset *queues_kset;




 unsigned int promiscuity;
 unsigned int allmulti;
 bool uc_promisc;






 struct in_device *ip_ptr;

 struct hlist_head fib_nh_head;
 struct wireless_dev *ieee80211_ptr;
 const unsigned char *dev_addr;

 unsigned int num_rx_queues;



 unsigned int xdp_zc_max_segs;
 struct netdev_queue *ingress_queue;

 struct nf_hook_entries *nf_hooks_ingress;


 unsigned char broadcast[32];

 struct cpu_rmap *rx_cpu_rmap;

 struct hlist_node index_hlist;




 unsigned int num_tx_queues;
 struct Qdisc *qdisc;
 unsigned int tx_queue_len;
 spinlock_t tx_global_lock;

 struct xdp_dev_bulk_queue *xdp_bulkq;


 struct hlist_head qdisc_hash[1 << (4)];


 struct timer_list watchdog_timer;
 int watchdog_timeo;
 spinlock_t watchdog_lock;
 bool watchdog_ref_held;

 u32 proto_down_reason;

 struct list_head todo_list;


 int *pcpu_refcnt;



 struct ref_tracker_dir refcnt_tracker;

 struct list_head link_watch_list;

 u8 reg_state;

 bool dismantle;


 bool moving_ns;

 bool rtnl_link_initializing;

 bool needs_free_netdev;
 void (*priv_destructor)(struct net_device *dev);


 void *ml_priv;
 enum netdev_ml_priv_type ml_priv_type;
 struct device dev;
 const struct attribute_group *sysfs_groups[5];
 const struct attribute_group *sysfs_rx_queue_group;

 const struct rtnl_link_ops *rtnl_link_ops;

 const struct netdev_stat_ops *stat_ops;

 const struct netdev_queue_mgmt_ops *queue_mgmt_ops;






 unsigned int tso_max_size;
 u16 tso_max_segs;




 u8 prio_tc_map[15 + 1];





 struct netprio_map *priomap;

 struct phy_link_topology *link_topo;
 struct phy_device *phydev;
 struct sfp_bus *sfp_bus;
 struct lock_class_key *qdisc_tx_busylock;
 bool proto_down;
 bool irq_affinity_auto;
 bool rx_cpu_rmap_auto;


 unsigned long see_all_hwtstamp_requests:1;
 unsigned long change_proto_down:1;
 unsigned long netns_immutable:1;
 unsigned long fcoe_mtu:1;

 struct list_head net_notifier_list;





 const struct udp_tunnel_nic_info *udp_tunnel_nic_info;
 struct udp_tunnel_nic *udp_tunnel_nic;


 struct netdev_config *cfg;





 struct netdev_config *cfg_pending;
 struct ethtool_netdev_state *ethtool;


 struct bpf_xdp_entity xdp_state[__MAX_XDP_MODE];

 u8 dev_addr_shadow[32];
 netdevice_tracker linkwatch_dev_tracker;
 netdevice_tracker watchdog_dev_tracker;
 netdevice_tracker dev_registered_tracker;
 struct rtnl_hw_stats64 *offload_xstats_l3;

 struct devlink_port *devlink_port;
 struct dim_irq_moder *irq_moder;

 u64 max_pacing_offload_horizon;
 struct napi_config *napi_config;
 u32 num_napi_configs;
 u32 napi_defer_hard_irqs;
 unsigned long gro_flush_timeout;






 bool up;





 bool request_ops_lock;
 struct mutex lock;
 struct hlist_head neighbours[NEIGH_NR_TABLES];

 struct hwtstamp_provider *hwprov;

 u8 priv[1] 
           ;
} ;
struct pcpu_sw_netstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 struct u64_stats_sync syncp;
} ;
struct pcpu_dstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 u64_stats_t rx_drops;
 u64_stats_t tx_drops;
 struct u64_stats_sync syncp;
} ;
struct pcpu_lstats {
 u64_stats_t packets;
 u64_stats_t bytes;
 struct u64_stats_sync syncp;
} ;
/*@ requires true; ensures \result == false; */

static inline    bool
br_port_flag_is_set(const struct net_device *dev, unsigned long flag)
{
 return false;
}
