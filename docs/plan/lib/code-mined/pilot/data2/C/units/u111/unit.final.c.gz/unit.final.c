/*@ requires 1; ensures \result == 1; */

static inline int
console_trylock(void)
{
 return (1);
}
