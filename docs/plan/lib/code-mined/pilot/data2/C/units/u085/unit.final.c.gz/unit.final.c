int sw_sync_timeline_create(void);
int sw_sync_timeline_is_valid(int fd);
void sw_sync_timeline_destroy(int fd);
int sw_sync_fence_create(int fd, const char *name, unsigned int value);
int sw_sync_fence_is_valid(int fd);
void sw_sync_fence_destroy(int fd);
static inline  void ksft_print_msg(const char *msg, ...)
;
int test_alloc_fence(void);
/*@ requires 1; ensures \result == 0; */

int test_alloc_fence(void)
{
 int timeline, fence, valid;

 timeline = sw_sync_timeline_create();
 valid = sw_sync_timeline_is_valid(timeline);
 do { if (!(valid)) { ksft_print_msg("[ERROR]\t%s", ("Failure allocating timeline\n")); return 1; } } while (0);

 fence = sw_sync_fence_create(timeline, "allocFence", 1);
 valid = sw_sync_fence_is_valid(fence);
 do { if (!(valid)) { ksft_print_msg("[ERROR]\t%s", ("Failure allocating fence\n")); return 1; } } while (0);

 sw_sync_fence_destroy(fence);
 sw_sync_timeline_destroy(timeline);
 return 0;
}
