typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
struct hte_line_attr {
 u32 line_id;
 void *line_data;
 unsigned long edge_flags;
 const char *name;
};
struct hte_ts_desc {
 struct hte_line_attr attr;
 void *hte_data;
};
/*@ requires true; ensures \result == -95; */

static inline    int hte_enable_ts(struct hte_ts_desc *desc)
{
 return -95;
}
