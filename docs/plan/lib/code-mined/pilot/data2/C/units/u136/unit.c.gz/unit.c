typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
int mock_calloc_fail = 0;
extern void *__real_calloc(size_t, size_t);
/*@ requires true; ensures mock_calloc_fail == 0 ==> \result != 0; */

void *
__wrap_calloc(size_t nmemb, size_t size)
{
 if (mock_calloc_fail)
  return (((void *)0));
 return (__real_calloc(nmemb, size));
}
