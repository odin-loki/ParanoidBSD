typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_paddr_t;
typedef unsigned int u_int;
typedef __int32_t int32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef char * caddr_t;
typedef __vm_paddr_t vm_paddr_t;
struct socket;
struct mbuf;
struct m_tag {
 struct { struct m_tag *sle_next; } m_tag_link;
 u_int16_t m_tag_id;
 u_int16_t m_tag_len;
 u_int32_t m_tag_cookie;
 void (*m_tag_free)(struct m_tag *);
};
struct if_snd_tag_sw;
struct m_snd_tag {
 struct ifnet *ifp;
 const struct if_snd_tag_sw *sw;
 volatile u_int refcount;
};
struct pkthdr {
 union {
  struct m_snd_tag *snd_tag;
  struct ifnet *rcvif;
  struct {
   uint16_t rcvidx;
   uint16_t rcvgen;
  };
 };
 union {
  struct ifnet *leaf_rcvif;
  struct {
   uint16_t leaf_rcvidx;
   uint16_t leaf_rcvgen;
  };
 };
 struct packet_tags { struct m_tag *slh_first; } tags;
 int32_t len;


 uint32_t flowid;
 uint32_t csum_flags;
 uint16_t fibnum;
 uint8_t numa_domain;
 uint8_t rsstype;



 union {
  uint64_t rcv_tstmp;
  struct {
   uint8_t l2hlen;
   uint8_t l3hlen;
   uint8_t l4hlen;
   uint8_t l5hlen;
   uint8_t inner_l2hlen;
   uint8_t inner_l3hlen;
   uint8_t inner_l4hlen;
   uint8_t inner_l5hlen;
  };
 };
 union {
  uint8_t eight[8];
  uint16_t sixteen[4];
  uint32_t thirtytwo[2];
  uint64_t sixtyfour[1];
  uintptr_t unintptr[1];
  void *ptr;
 } PH_per;


 union {
  union {
   uint8_t eight[8];
   uint16_t sixteen[4];
   uint32_t thirtytwo[2];
   uint64_t sixtyfour[1];
   uintptr_t unintptr[1];
   void *ptr;
  } PH_loc;

  u_int memlen;
 };
};
struct ktls_session;
struct socket;
typedef void m_ext_free_t(struct mbuf *);
struct m_ext {
 union {
  volatile u_int ext_count;
  volatile u_int *ext_cnt;
 };
 uint32_t ext_size;
 uint32_t ext_type:8,
    ext_flags:24;
 union {
  struct {
   char *ext_buf;
   void *ext_arg2;
  };
  struct {







   vm_paddr_t extpg_pa[(40 / sizeof(vm_paddr_t))];
   char extpg_trail[64];
   char extpg_hdr[23];

  };
 };




 m_ext_free_t *ext_free;
 void *ext_arg1;
};
struct mbuf {







 union {
  struct mbuf *m_next;
  struct { struct mbuf *sle_next; } m_slist;
  struct { struct mbuf *stqe_next; } m_stailq;
 };
 union {
  struct mbuf *m_nextpkt;
  struct { struct mbuf *sle_next; } m_slistpkt;
  struct { struct mbuf *stqe_next; } m_stailqpkt;
 };
 caddr_t m_data;
 int32_t m_len;
 uint32_t m_type:8,
    m_flags:24;
 union {
  struct {
   union {

    struct pkthdr m_pkthdr;
    struct {


     uint8_t m_epg_npgs;
     uint8_t m_epg_nrdy;


     uint8_t m_epg_hdrlen;
     uint8_t m_epg_trllen;


     uint16_t m_epg_1st_off;
     uint16_t m_epg_last_len;
     uint8_t m_epg_flags;
     uint8_t m_epg_record_type;
     uint8_t __spare[2];
     int m_epg_enc_cnt;
     struct ktls_session *m_epg_tls;
     struct socket *m_epg_so;
     uint64_t m_epg_seqno;
     struct { struct mbuf *stqe_next; } m_epg_stailq;
    };
   };
   union {

    struct m_ext m_ext;

    char m_pktdat[1];
   };
  };
  char m_dat[1];
 };
};
int m_dup_pkthdr(struct mbuf *, const struct mbuf *, int);
int m_tag_copy_chain(struct mbuf *, const struct mbuf *, int);
static __inline void
m_tag_free(struct m_tag *t)
;
static inline struct m_snd_tag *
m_snd_tag_ref(struct m_snd_tag *mst)
;
struct mbuf;
struct ifnet;
struct socket;
struct socket;
struct ifnet;
struct mbuf;
struct ifnet;
struct m_tag;
struct mbuf;
struct socket;
/*@ requires to != \null && from != \null; ensures \result == 0 || \result < 0; */

int
m_dup_pkthdr(struct mbuf *to, const struct mbuf *from, int how)
{
 do { if (how == 0x0002) (void)0; } while (0);




 to->m_flags = (from->m_flags & (0x00000002|0x00000004|0x00000008|0x00000010|0x00000020|0x00000040|0x00000080|0x00000400| 0x00000800|0x00001000|(0x00002000|0x00004000|0x00008000|0x00010000|0x00020000|0x00040000|0x00080000|0x00100000| 0x00200000|0x00400000|0x00800000))) |
     (to->m_flags & (0x00000001 | 0x00000100));
 if ((to->m_flags & 0x00000001) == 0)
  to->m_data = to->m_pktdat;
 to->m_pkthdr = from->m_pkthdr;
 if (from->m_pkthdr.csum_flags & 0x80000000)
  m_snd_tag_ref(from->m_pkthdr.snd_tag);
 do { (((&to->m_pkthdr.tags))->slh_first) = ((void *)0); } while (0);
 return (m_tag_copy_chain(to, from, how));
}
