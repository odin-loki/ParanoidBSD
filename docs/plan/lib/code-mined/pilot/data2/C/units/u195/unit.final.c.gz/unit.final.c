typedef unsigned int __u32;
typedef __u32 u32;
/*@ requires 0 <= quadlet <= 4294967295; ensures 0 <= \result <= 3 && \result == (quadlet / 16384) % 4; */

static inline    unsigned int phy_packet_self_id_zero_get_scode(u32 quadlet)
{
 return (quadlet & 0x0000c000) >> 14;
}
