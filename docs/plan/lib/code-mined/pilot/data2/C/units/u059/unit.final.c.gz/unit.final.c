typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
typedef _Bool bool;
struct list_head {
 struct list_head *next, *prev;
};

int _printk(const char *fmt, ...);
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct module;
struct module;
struct file;
struct file;
struct module;
enum clocksource_ids {
 CSID_GENERIC = 0,
 CSID_ARM_ARCH_COUNTER,
 CSID_S390_TOD,
 CSID_X86_TSC_EARLY,
 CSID_X86_TSC,
 CSID_X86_KVM_CLK,
 CSID_X86_ART,
 CSID_MAX,
};
struct file;
struct module;
struct file;
struct clocksource_base;
struct clocksource;
struct module;
enum vdso_clock_mode {
 VDSO_CLOCKMODE_NONE,

 VDSO_CLOCKMODE_TSC, VDSO_CLOCKMODE_PVCLOCK, VDSO_CLOCKMODE_HVCLOCK,

 VDSO_CLOCKMODE_MAX,


 VDSO_CLOCKMODE_TIMENS = ((int)(~0U >> 1))
};
struct clocksource {
 u64 (*read)(struct clocksource *cs);
 u64 mask;
 u32 mult;
 u32 shift;
 u64 max_idle_ns;
 u32 maxadj;
 u32 uncertainty_margin;



 u64 max_cycles;
 u64 max_raw_delta;
 const char *name;
 struct list_head list;
 u32 freq_khz;
 int rating;
 enum clocksource_ids id;
 enum vdso_clock_mode vdso_clock_mode;
 unsigned long flags;
 struct clocksource_base *base;

 int (*enable)(struct clocksource *cs);
 void (*disable)(struct clocksource *cs);
 void (*suspend)(struct clocksource *cs);
 void (*resume)(struct clocksource *cs);
 void (*mark_unstable)(struct clocksource *cs);
 void (*tick_stable)(struct clocksource *cs);




 struct list_head wd_list;
 u64 cs_last;
 u64 wd_last;

 struct module *owner;
};
extern u64 clocksource_mmio_readl_up(struct clocksource *);
extern int clocksource_mmio_init(void *, const char *,
 unsigned long, int, unsigned, u64 (*)(struct clocksource *));
struct clocksource_base {
 enum clocksource_ids id;
 u32 freq_khz;
 u64 offset;
 u32 numerator;
 u32 denominator;
};
struct module;
struct module;
struct module;
static inline    void sched_clock_register(u64 (*read)(void), int bits,
     unsigned long rate)
;
struct ftm_clock_device {
 void *clksrc_base;
 void *clkevt_base;
 unsigned long periodic_cyc;
 unsigned long ps;
 bool big_endian;
};
static struct ftm_clock_device *priv;
static inline    void ftm_writel(u32 val, void *addr)
;
static inline    void ftm_counter_enable(void *base)
;
static inline    void ftm_reset_counter(void *base)
;
static u64  ftm_read_sched_clock(void)
;
/*@ requires 0 < freq; ensures \result == 0 || \result < 0; */

static int  ftm_clocksource_init(unsigned long freq)
{
 int err;

 ftm_writel(0x00, priv->clksrc_base + 0x4C);
 ftm_writel(~0u, priv->clksrc_base + 0x8);

 ftm_reset_counter(priv->clksrc_base);

 sched_clock_register(ftm_read_sched_clock, 16, freq / (1 << priv->ps));
 err = clocksource_mmio_init(priv->clksrc_base + 0x4, "fsl-ftm",
        freq / (1 << priv->ps), 300, 16,
        clocksource_mmio_readl_up);
 if (err) {
  ({ do { if (__builtin_constant_p("\001" "3" "ftm: init clock source mmio failed: %d\n") && __builtin_constant_p(((void *)0))) { static const struct pi_entry _entry  = { .fmt = __builtin_constant_p("\001" "3" "ftm: init clock source mmio failed: %d\n") ? ("\001" "3" "ftm: init clock source mmio failed: %d\n") : ((void *)0), .func = __func__, .file = "drivers/clocksource/timer-fsl-ftm.c", .line = 221, .level = __builtin_constant_p(((void *)0)) ? (((void *)0)) : ((void *)0), .subsys_fmt_prefix = ((void *)0), }; static const struct pi_entry *_entry_ptr   = &_entry; } } while (0); _printk("\001" "3" "ftm: init clock source mmio failed: %d\n", err); });
  return err;
 }

 ftm_counter_enable(priv->clksrc_base);

 return 0;
}
