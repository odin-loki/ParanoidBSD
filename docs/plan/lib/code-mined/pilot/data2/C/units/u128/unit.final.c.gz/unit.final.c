typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_size_t size_t;
typedef unsigned int gfp_t;
enum {
 ___GFP_DMA_BIT,
 ___GFP_HIGHMEM_BIT,
 ___GFP_DMA32_BIT,
 ___GFP_MOVABLE_BIT,
 ___GFP_RECLAIMABLE_BIT,
 ___GFP_HIGH_BIT,
 ___GFP_IO_BIT,
 ___GFP_FS_BIT,
 ___GFP_ZERO_BIT,
 ___GFP_UNUSED_BIT,
 ___GFP_DIRECT_RECLAIM_BIT,
 ___GFP_KSWAPD_RECLAIM_BIT,
 ___GFP_WRITE_BIT,
 ___GFP_NOWARN_BIT,
 ___GFP_RETRY_MAYFAIL_BIT,
 ___GFP_NOFAIL_BIT,
 ___GFP_NORETRY_BIT,
 ___GFP_MEMALLOC_BIT,
 ___GFP_COMP_BIT,
 ___GFP_NOMEMALLOC_BIT,
 ___GFP_HARDWALL_BIT,
 ___GFP_THISNODE_BIT,
 ___GFP_ACCOUNT_BIT,
 ___GFP_ZEROTAGS_BIT,





 ___GFP_NOLOCKDEP_BIT,


 ___GFP_NO_OBJ_EXT_BIT,

 ___GFP_LAST_BIT
};
/*@ requires flags >= 0; ensures (\result & ~(( gfp_t)((((1UL))) << (___GFP_NOFAIL_BIT)))) == \result && (!(flags & (( gfp_t)((((1UL))) << (___GFP_RETRY_MAYFAIL_BIT)))) ==> (\result & (( gfp_t)((((1UL))) << (___GFP_DIRECT_RECLAIM_BIT)))) == 0) && ((flags & (( gfp_t)((((1UL))) << (___GFP_RETRY_MAYFAIL_BIT)))) ==> \result == flags); */

static gfp_t kmalloc_gfp_adjust(gfp_t flags, size_t size)
{
 if (size > ((1UL) << 12)) {
  flags |= (( gfp_t)((((1UL))) << (___GFP_NOWARN_BIT)));

  if (!(flags & (( gfp_t)((((1UL))) << (___GFP_RETRY_MAYFAIL_BIT)))))
   flags &= ~(( gfp_t)((((1UL))) << (___GFP_DIRECT_RECLAIM_BIT)));


  flags &= ~(( gfp_t)((((1UL))) << (___GFP_NOFAIL_BIT)));
 }

 return flags;
}
