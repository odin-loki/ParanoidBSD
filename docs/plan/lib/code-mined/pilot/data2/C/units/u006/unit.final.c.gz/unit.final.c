enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == 16; */

static unsigned int team_get_num_rx_queues(void)
{
 return 16;
}
