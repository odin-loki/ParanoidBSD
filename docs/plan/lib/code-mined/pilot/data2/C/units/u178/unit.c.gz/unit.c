typedef uint64_t *counter_u64_t;
typedef unsigned long __uint64_t;
typedef unsigned int u_int;
typedef __uint64_t uint64_t;
uint64_t counter_u64_fetch(counter_u64_t);
struct vmmeter {



 counter_u64_t v_swtch;
 counter_u64_t v_trap;
 counter_u64_t v_syscall;
 counter_u64_t v_intr;
 counter_u64_t v_soft;



 counter_u64_t v_vm_faults;
 counter_u64_t v_io_faults;
 counter_u64_t v_cow_faults;
 counter_u64_t v_cow_optim;
 counter_u64_t v_zfod;
 counter_u64_t v_ozfod;
 counter_u64_t v_swapin;
 counter_u64_t v_swapout;
 counter_u64_t v_swappgsin;
 counter_u64_t v_swappgsout;
 counter_u64_t v_vnodein;
 counter_u64_t v_vnodeout;
 counter_u64_t v_vnodepgsin;
 counter_u64_t v_vnodepgsout;
 counter_u64_t v_intrans;
 counter_u64_t v_reactivated;
 counter_u64_t v_pdwakeups;
 counter_u64_t v_pdpages;
 counter_u64_t v_pdshortfalls;

 counter_u64_t v_dfree;
 counter_u64_t v_pfree;
 counter_u64_t v_tfree;



 counter_u64_t v_forks;
 counter_u64_t v_vforks;
 counter_u64_t v_rforks;
 counter_u64_t v_kthreads;
 counter_u64_t v_forkpages;
 counter_u64_t v_vforkpages;
 counter_u64_t v_rforkpages;
 counter_u64_t v_kthreadpages;
 counter_u64_t v_wire_count;
 counter_u64_t v_nofree_count;




 u_int v_page_size;
 u_int v_page_count;
 u_int v_free_reserved;
 u_int v_free_target;
 u_int v_free_min;
 u_int v_inactive_target;
 u_int v_pageout_free_min;
 u_int v_interrupt_free_min;
 u_int v_free_severe;
};
extern struct vmmeter vm_cnt;
/*@ requires 1; ensures \result == vm_cnt.v_wire_count; */

static inline u_int
vm_wire_count(void)
{

 return (counter_u64_fetch(vm_cnt.v_wire_count));
}
