enum {
 false = 0,
 true = 1
};
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_size_t size_t;
int  vdo_allocate_memory(size_t size, size_t align, const char *what, void *ptr);
/*@ requires true; ensures \result == 0 || \result < 0; */

static inline    int  vdo_allocate_cache_aligned(size_t size, const char *what, void *ptr)
{
 return vdo_allocate_memory(size, (1 << (6)), what, ptr);
}
