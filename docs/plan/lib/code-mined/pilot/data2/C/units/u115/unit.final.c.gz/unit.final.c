typedef _Bool bool;
struct regmap;
struct regmap;
static inline    int regmap_assign_bits(struct regmap *map, unsigned int reg,
         unsigned int bits, bool value)
;
/*@ requires mask_buf >> 8 == 0; ensures \result == 0 || \result < 0; */

static int max7360_handle_mask_sync(const int index,
        const unsigned int mask_buf_def,
        const unsigned int mask_buf,
        void *const irq_drv_data)
{
 struct regmap *regmap = irq_drv_data;
 int ret;

 for (unsigned int i = 0; i < 8; i++) {
  ret = regmap_assign_bits(regmap, (0x58 + (i)),
      ((((1UL))) << (7)), mask_buf & ((((1UL))) << (i)));
  if (ret)
   return ret;
 }

 return 0;
}
