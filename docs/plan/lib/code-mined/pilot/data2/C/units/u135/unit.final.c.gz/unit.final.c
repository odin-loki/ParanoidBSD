enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result <= nr_pages; */

static inline    unsigned long preallocate_image_highmem(unsigned long nr_pages)
{
 return 0;
}
