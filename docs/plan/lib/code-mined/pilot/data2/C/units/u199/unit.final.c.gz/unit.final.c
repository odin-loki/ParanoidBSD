typedef unsigned int __u32;
typedef __u32 u32;
typedef _Bool bool;
/*@ requires 0 <= quadlet <= 4294967295; ensures \result == (quadlet % 2 == 1); */

static inline    bool phy_packet_self_id_get_more_packets(u32 quadlet)
{
 return (quadlet & 0x00000001) >> 0;
}
