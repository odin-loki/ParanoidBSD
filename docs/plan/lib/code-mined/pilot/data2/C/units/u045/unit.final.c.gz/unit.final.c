typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
struct cyclecounter {
 u64 (*read)(struct cyclecounter *cc);
 u64 mask;
 u32 mult;
 u32 shift;
};
struct timecounter {
 struct cyclecounter *cc;
 u64 cycle_last;
 u64 nsec;
 u64 mask;
 u64 frac;
};
/*@ requires \valid(tc); ensures tc->nsec == \old(tc->nsec) + delta; */

static inline    void timecounter_adjtime(struct timecounter *tc, s64 delta)
{
 tc->nsec += delta;
}
