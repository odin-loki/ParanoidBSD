typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u32 __wsum;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s32 int32_t;
typedef u8 uint8_t;
typedef u32 uint32_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
void abort(void);
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct net_device;
struct kernel_param;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
static inline     void
generic___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
generic_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
const_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
arch___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
arch_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
_Static_assert(__builtin_types_compatible_p(typeof(arch___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(generic___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(___set_bit), typeof(generic___set_bit)), "__same_type(arch___set_bit, generic___set_bit) && __same_type(const___set_bit, generic___set_bit) && __same_type(___set_bit, generic___set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(generic___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(___clear_bit), typeof(generic___clear_bit)), "__same_type(arch___clear_bit, generic___clear_bit) && __same_type(const___clear_bit, generic___clear_bit) && __same_type(___clear_bit, generic___clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(generic___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(___change_bit), typeof(generic___change_bit)), "__same_type(arch___change_bit, generic___change_bit) && __same_type(const___change_bit, generic___change_bit) && __same_type(___change_bit, generic___change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(___test_and_set_bit), typeof(generic___test_and_set_bit)), "__same_type(arch___test_and_set_bit, generic___test_and_set_bit) && __same_type(const___test_and_set_bit, generic___test_and_set_bit) && __same_type(___test_and_set_bit, generic___test_and_set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(___test_and_clear_bit), typeof(generic___test_and_clear_bit)), "__same_type(arch___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(const___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(___test_and_clear_bit, generic___test_and_clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(___test_and_change_bit), typeof(generic___test_and_change_bit)), "__same_type(arch___test_and_change_bit, generic___test_and_change_bit) && __same_type(const___test_and_change_bit, generic___test_and_change_bit) && __same_type(___test_and_change_bit, generic___test_and_change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(const_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(_test_bit), typeof(generic_test_bit)), "__same_type(arch_test_bit, generic_test_bit) && __same_type(const_test_bit, generic_test_bit) && __same_type(_test_bit, generic_test_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(generic_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(_test_bit_acquire), typeof(generic_test_bit_acquire)), "__same_type(arch_test_bit_acquire, generic_test_bit_acquire) && __same_type(const_test_bit_acquire, generic_test_bit_acquire) && __same_type(_test_bit_acquire, generic_test_bit_acquire)");
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
static inline     u64 field_mask(u64 field)
;
struct cacheline_padding {
 char x[1];
} ;
struct task_struct;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct task_struct;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct page;
struct range {
 u64 start;
 u64 end;
};
struct task_struct;
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
enum _cache_table_type {
 CACHE_L1_INST = 1,
 CACHE_L1_DATA,
 CACHE_L2,
 CACHE_L3

} __attribute__((__packed__));
_Static_assert(sizeof(enum _cache_table_type) == 1, "sizeof(enum _cache_table_type) == 1");
enum _tlb_table_type {
 TLB_INST_4K = (CACHE_L3 + 1),
 TLB_INST_4M,
 TLB_INST_2M_4M,
 TLB_INST_ALL,

 TLB_DATA_4K,
 TLB_DATA_4M,
 TLB_DATA_2M_4M,
 TLB_DATA_4K_4M,
 TLB_DATA_1G,
 TLB_DATA_1G_2M_4M,

 TLB_DATA0_4K,
 TLB_DATA0_4M,
 TLB_DATA0_2M_4M,

 STLB_4K,
 STLB_4K_2M,
} __attribute__((__packed__));
_Static_assert(sizeof(enum _tlb_table_type) == 1, "sizeof(enum _tlb_table_type) == 1");
struct mm_struct;
struct static_key;
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct device;
struct module;
struct page;
struct vm_area_struct;
struct mm_struct;
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
struct task_struct;
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct page;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
typedef __s64 time64_t;
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct blocking_notifier_head {
 struct rw_semaphore rwsem;
 struct notifier_block *head;
};
struct raw_notifier_head {
 struct notifier_block *head;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
_Static_assert(__builtin_offsetof(struct page, flags) == __builtin_offsetof(struct folio, flags), "offsetof(struct page, flags) == offsetof(struct folio, flags)");
_Static_assert(__builtin_offsetof(struct page, lru) == __builtin_offsetof(struct folio, lru), "offsetof(struct page, lru) == offsetof(struct folio, lru)");
_Static_assert(__builtin_offsetof(struct page, mapping) == __builtin_offsetof(struct folio, mapping), "offsetof(struct page, mapping) == offsetof(struct folio, mapping)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct folio, lru), "offsetof(struct page, compound_head) == offsetof(struct folio, lru)");
_Static_assert(__builtin_offsetof(struct page, __folio_index) == __builtin_offsetof(struct folio, index), "offsetof(struct page, __folio_index) == offsetof(struct folio, index)");
_Static_assert(__builtin_offsetof(struct page, private) == __builtin_offsetof(struct folio, private), "offsetof(struct page, private) == offsetof(struct folio, private)");
_Static_assert(__builtin_offsetof(struct page, _mapcount) == __builtin_offsetof(struct folio, _mapcount), "offsetof(struct page, _mapcount) == offsetof(struct folio, _mapcount)");
_Static_assert(__builtin_offsetof(struct page, _refcount) == __builtin_offsetof(struct folio, _refcount), "offsetof(struct page, _refcount) == offsetof(struct folio, _refcount)");
_Static_assert(__builtin_offsetof(struct page, memcg_data) == __builtin_offsetof(struct folio, memcg_data), "offsetof(struct page, memcg_data) == offsetof(struct folio, memcg_data)");
_Static_assert(__builtin_offsetof(struct folio, _flags_1) == __builtin_offsetof(struct page, flags) + sizeof(struct page), "offsetof(struct folio, _flags_1) == offsetof(struct page, flags) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_1) == __builtin_offsetof(struct page, compound_head) + sizeof(struct page), "offsetof(struct folio, _head_1) == offsetof(struct page, compound_head) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _mapcount_1) == __builtin_offsetof(struct page, _mapcount) + sizeof(struct page), "offsetof(struct folio, _mapcount_1) == offsetof(struct page, _mapcount) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _refcount_1) == __builtin_offsetof(struct page, _refcount) + sizeof(struct page), "offsetof(struct folio, _refcount_1) == offsetof(struct page, _refcount) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _flags_2) == __builtin_offsetof(struct page, flags) + 2 * sizeof(struct page), "offsetof(struct folio, _flags_2) == offsetof(struct page, flags) + 2 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_2) == __builtin_offsetof(struct page, compound_head) + 2 * sizeof(struct page), "offsetof(struct folio, _head_2) == offsetof(struct page, compound_head) + 2 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _flags_3) == __builtin_offsetof(struct page, flags) + 3 * sizeof(struct page), "offsetof(struct folio, _flags_3) == offsetof(struct page, flags) + 3 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_3) == __builtin_offsetof(struct page, compound_head) + 3 * sizeof(struct page), "offsetof(struct folio, _head_3) == offsetof(struct page, compound_head) + 3 * sizeof(struct page)");
struct ptdesc {
 memdesc_flags_t pt_flags;

 union {
  struct callback_head pt_rcu_head;
  struct list_head pt_list;
  struct {
   unsigned long _pt_pad_1;
   pgtable_t pmd_huge_pte;
  };
 };
 unsigned long __page_mapping;

 union {
  unsigned long pt_index;
  struct mm_struct *pt_mm;
  atomic_t pt_frag_refcount;

  atomic_t pt_share_count;

 };

 union {
  unsigned long _pt_pad_2;

  spinlock_t *ptl;



 };
 unsigned int __page_type;
 atomic_t __page_refcount;

 unsigned long pt_memcg_data;

};
_Static_assert(__builtin_offsetof(struct page, flags) == __builtin_offsetof(struct ptdesc, pt_flags), "offsetof(struct page, flags) == offsetof(struct ptdesc, pt_flags)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct ptdesc, pt_list), "offsetof(struct page, compound_head) == offsetof(struct ptdesc, pt_list)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct ptdesc, _pt_pad_1), "offsetof(struct page, compound_head) == offsetof(struct ptdesc, _pt_pad_1)");
_Static_assert(__builtin_offsetof(struct page, mapping) == __builtin_offsetof(struct ptdesc, __page_mapping), "offsetof(struct page, mapping) == offsetof(struct ptdesc, __page_mapping)");
_Static_assert(__builtin_offsetof(struct page, __folio_index) == __builtin_offsetof(struct ptdesc, pt_index), "offsetof(struct page, __folio_index) == offsetof(struct ptdesc, pt_index)");
_Static_assert(__builtin_offsetof(struct page, callback_head) == __builtin_offsetof(struct ptdesc, pt_rcu_head), "offsetof(struct page, callback_head) == offsetof(struct ptdesc, pt_rcu_head)");
_Static_assert(__builtin_offsetof(struct page, page_type) == __builtin_offsetof(struct ptdesc, __page_type), "offsetof(struct page, page_type) == offsetof(struct ptdesc, __page_type)");
_Static_assert(__builtin_offsetof(struct page, _refcount) == __builtin_offsetof(struct ptdesc, __page_refcount), "offsetof(struct page, _refcount) == offsetof(struct ptdesc, __page_refcount)");
_Static_assert(__builtin_offsetof(struct page, memcg_data) == __builtin_offsetof(struct ptdesc, pt_memcg_data), "offsetof(struct page, memcg_data) == offsetof(struct ptdesc, pt_memcg_data)");
_Static_assert(sizeof(struct ptdesc) <= sizeof(struct page), "sizeof(struct ptdesc) <= sizeof(struct page)");
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
_Static_assert((u64)((((((1UL))) << (2)) - 1) | ((((((1UL))) << (9)) - 1) << 2) | (((((1UL))) << (24)) | ((((1UL))) << (23))) | ((((1UL))) << (28)) | ((((1UL))) << (30)) | ((((1UL))) << (31))) <= (u64)(~0U), "(u64)MMF_INIT_LEGACY_MASK <= (u64)UINT_MAX");
enum pageflags {
 PG_locked,
 PG_writeback,
 PG_referenced,
 PG_uptodate,
 PG_dirty,
 PG_lru,
 PG_head,
 PG_waiters,
 PG_active,
 PG_workingset,
 PG_owner_priv_1,
 PG_owner_2,
 PG_arch_1,
 PG_reserved,
 PG_private,
 PG_private_2,
 PG_reclaim,
 PG_swapbacked,
 PG_unevictable,
 PG_dropbehind,

 PG_mlocked,


 PG_hwpoison,


 PG_young,
 PG_idle,


 PG_arch_2,




 __NR_PAGEFLAGS,

 PG_readahead = PG_reclaim,


 PG_swapcache = PG_owner_priv_1,

 PG_checked = PG_owner_priv_1,
 PG_anon_exclusive = PG_owner_2,





 PG_mappedtodisk = PG_owner_2,





 PG_fscache = PG_private_2,



 PG_pinned = PG_owner_priv_1,

 PG_savepinned = PG_dirty,

 PG_foreign = PG_owner_priv_1,

 PG_xen_remapped = PG_owner_priv_1,



 PG_movable_ops_isolated = PG_reclaim,

 PG_movable_ops = PG_uptodate,



 PG_reported = PG_uptodate,



 PG_vmemmap_self_hosted = PG_owner_priv_1,
 PG_has_hwpoisoned = PG_active,
 PG_large_rmappable = PG_workingset,
 PG_partially_mapped = PG_reclaim,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct user_namespace;
struct uid_gid_map;
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
typedef struct {
 __u8 b[16];
} uuid_t;
typedef unsigned long kernel_ulong_t;
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
struct firmware {
 size_t size;
 const u8 *data;


 void *priv;
};
struct module;
struct device;
struct pci_dev;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct device;
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;


 unsigned long last_holder;

};
extern void up(struct semaphore *sem);
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
_Static_assert(sizeof(vfsuid_t) == sizeof(kuid_t), "sizeof(vfsuid_t) == sizeof(kuid_t)");
_Static_assert(sizeof(vfsgid_t) == sizeof(kgid_t), "sizeof(vfsgid_t) == sizeof(kgid_t)");
_Static_assert(__builtin_offsetof(vfsuid_t, val) == __builtin_offsetof(kuid_t, val), "offsetof(vfsuid_t, val) == offsetof(kuid_t, val)");
_Static_assert(__builtin_offsetof(vfsgid_t, val) == __builtin_offsetof(kgid_t, val), "offsetof(vfsgid_t, val) == offsetof(kgid_t, val)");
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
_Static_assert(12 <= 20, "PAGE_SHIFT <= 20");
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
_Static_assert(sizeof(enum rw_hint) == 1, "sizeof(enum rw_hint) == 1");
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
struct fasync_struct {
 rwlock_t fa_lock;
 int magic;
 int fa_fd;
 struct fasync_struct *fa_next;
 struct file *fa_file;
 struct callback_head fa_rcu;
};
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
_Static_assert(__builtin_offsetof(struct filename, iname) % sizeof(long) == 0, "offsetof(struct filename, iname) % sizeof(long) == 0");
static inline    struct filename *getname(const char *name)
;
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct pglist_data;
struct file;
struct device;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct kobject;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct kvec;
enum pt_flags {
 PT_kernel = PG_referenced,
 PT_reserved = PG_reserved,

};
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
typedef unsigned short __kernel_sa_family_t;
struct file;
struct pid;
struct cred;
struct socket;
struct sock;
struct sk_buff;
struct proto_accept_arg;
struct seq_file;
typedef __kernel_sa_family_t sa_family_t;
struct sockaddr {
 sa_family_t sa_family;
 union {
  char sa_data_min[14];
  struct { struct { } __empty_sa_data; char sa_data[1]; };
 };
};
struct sockaddr_unsized {
 __kernel_sa_family_t sa_family;
 char sa_data[1];
};
struct msghdr {
 void *msg_name;
 int msg_namelen;

 int msg_inq;

 struct iov_iter msg_iter;






 union {
  void *msg_control;
  void *msg_control_user;
 };
 bool msg_control_is_user : 1;
 bool msg_get_inq : 1;
 unsigned int msg_flags;
 __kernel_size_t msg_controllen;
 struct kiocb *msg_iocb;
 struct ubuf_info *msg_ubuf;
 int (*sg_from_iter)(struct sk_buff *skb,
       struct iov_iter *from, size_t length);
};
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct in6_addr;
struct sk_buff;
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct vm_area_struct;
struct file;
struct cred;
struct file;
struct rhash_head {
 struct rhash_head *next;
};
struct bucket_table;
struct rhashtable_compare_arg {
 struct rhashtable *ht;
 const void *key;
};
typedef u32 (*rht_hashfn_t)(const void *data, u32 len, u32 seed);
typedef u32 (*rht_obj_hashfn_t)(const void *data, u32 len, u32 seed);
typedef int (*rht_obj_cmpfn_t)(struct rhashtable_compare_arg *arg,
          const void *obj);
struct rhashtable_params {
 u16 nelem_hint;
 u16 key_len;
 u16 key_offset;
 u16 head_offset;
 unsigned int max_size;
 u16 min_size;
 bool automatic_shrinking;
 rht_hashfn_t hashfn;
 rht_obj_hashfn_t obj_hashfn;
 rht_obj_cmpfn_t obj_cmpfn;
};
struct rhashtable {
 struct bucket_table *tbl;
 unsigned int key_len;
 unsigned int max_elems;
 struct rhashtable_params p;
 bool rhlist;
 struct work_struct run_work;
 struct mutex mutex;
 spinlock_t lock;
 atomic_t nelems;



};
struct task_struct;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
} sync_serial_settings;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
 unsigned int slot_map;
} te1_settings;
typedef struct {
 unsigned short encoding;
 unsigned short parity;
} raw_hdlc_proto;
typedef struct {
 unsigned int t391;
 unsigned int t392;
 unsigned int n391;
 unsigned int n392;
 unsigned int n393;
 unsigned short lmi;
 unsigned short dce;
} fr_proto;
typedef struct {
 unsigned int dlci;
} fr_proto_pvc;
typedef struct {
 unsigned int dlci;
 char master[16];
}fr_proto_pvc_info;
typedef struct {
    unsigned int interval;
    unsigned int timeout;
} cisco_proto;
typedef struct {
 unsigned short dce;
 unsigned int modulo;
 unsigned int window;
 unsigned int t1;
 unsigned int t2;
 unsigned int n2;
} x25_hdlc_proto;
struct ifmap {
 unsigned long mem_start;
 unsigned long mem_end;
 unsigned short base_addr;
 unsigned char irq;
 unsigned char dma;
 unsigned char port;

};
struct if_settings {
 unsigned int type;
 unsigned int size;
 union {

  raw_hdlc_proto *raw_hdlc;
  cisco_proto *cisco;
  fr_proto *fr;
  fr_proto_pvc *fr_pvc;
  fr_proto_pvc_info *fr_pvc_info;
  x25_hdlc_proto *x25;


  sync_serial_settings *sync;
  te1_settings *te1;
 } ifs_ifsu;
};
struct ifreq {
 union
 {
  char ifrn_name[16];
 } ifr_ifrn;

 union {
  struct sockaddr ifru_addr;
  struct sockaddr ifru_dstaddr;
  struct sockaddr ifru_broadaddr;
  struct sockaddr ifru_netmask;
  struct sockaddr ifru_hwaddr;
  short ifru_flags;
  int ifru_ivalue;
  int ifru_mtu;
  struct ifmap ifru_map;
  char ifru_slave[16];
  char ifru_newname[16];
  void * ifru_data;
  struct if_settings ifru_settings;
 } ifr_ifru;
};
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
typedef u64 netdev_features_t;
struct in6_addr {
 union {
  __u8 u6_addr8[16];

  __be16 u6_addr16[8];
  __be32 u6_addr32[4];

 } in6_u;


};
typedef struct {
 u64 key[2];
} siphash_key_t;
struct ethhdr {
 unsigned char h_dest[6];
 unsigned char h_source[6];
 __be16 h_proto;
} __attribute__((packed));
struct bpf_prog;
struct net;
struct sk_buff;
struct ip_conntrack_stat {
 unsigned int found;
 unsigned int invalid;
 unsigned int insert;
 unsigned int insert_failed;
 unsigned int clash_resolve;
 unsigned int drop;
 unsigned int early_drop;
 unsigned int error;
 unsigned int expect_new;
 unsigned int expect_create;
 unsigned int expect_delete;
 unsigned int search_restart;
 unsigned int chaintoolong;
};
struct net_device;
struct netmem_desc {
 unsigned long _flags;
 unsigned long pp_magic;
 struct page_pool *pp;
 unsigned long _pp_mapping_pad;
 unsigned long dma_addr;
 atomic_long_t pp_ref_count;
};
_Static_assert(__builtin_offsetof(struct page, flags) == __builtin_offsetof(struct netmem_desc, _flags), "offsetof(struct page, flags) == offsetof(struct netmem_desc, _flags)");
_Static_assert(__builtin_offsetof(struct page, pp_magic) == __builtin_offsetof(struct netmem_desc, pp_magic), "offsetof(struct page, pp_magic) == offsetof(struct netmem_desc, pp_magic)");
_Static_assert(__builtin_offsetof(struct page, pp) == __builtin_offsetof(struct netmem_desc, pp), "offsetof(struct page, pp) == offsetof(struct netmem_desc, pp)");
_Static_assert(__builtin_offsetof(struct page, _pp_mapping_pad) == __builtin_offsetof(struct netmem_desc, _pp_mapping_pad), "offsetof(struct page, _pp_mapping_pad) == offsetof(struct netmem_desc, _pp_mapping_pad)");
_Static_assert(__builtin_offsetof(struct page, dma_addr) == __builtin_offsetof(struct netmem_desc, dma_addr), "offsetof(struct page, dma_addr) == offsetof(struct netmem_desc, dma_addr)");
_Static_assert(__builtin_offsetof(struct page, pp_ref_count) == __builtin_offsetof(struct netmem_desc, pp_ref_count), "offsetof(struct page, pp_ref_count) == offsetof(struct netmem_desc, pp_ref_count)");
_Static_assert(sizeof(struct netmem_desc) <= __builtin_offsetof(struct page, _refcount), "sizeof(struct netmem_desc) <= offsetof(struct page, _refcount)");
enum net_iov_type {
 NET_IOV_DMABUF,
 NET_IOV_IOURING,



 NET_IOV_MAX = (~0UL)
};
struct net_iov {
 union {
  struct netmem_desc desc;






  struct {
   unsigned long _flags;
   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
 };
 struct net_iov_area *owner;
 enum net_iov_type type;
};
struct net_iov_area {

 struct net_iov *niovs;
 size_t num_niovs;


 unsigned long base_virtual;
};
_Static_assert(__builtin_offsetof(struct netmem_desc, _flags) == __builtin_offsetof(struct net_iov, _flags), "offsetof(struct netmem_desc, _flags) == offsetof(struct net_iov, _flags)");
_Static_assert(__builtin_offsetof(struct netmem_desc, pp_magic) == __builtin_offsetof(struct net_iov, pp_magic), "offsetof(struct netmem_desc, pp_magic) == offsetof(struct net_iov, pp_magic)");
_Static_assert(__builtin_offsetof(struct netmem_desc, pp) == __builtin_offsetof(struct net_iov, pp), "offsetof(struct netmem_desc, pp) == offsetof(struct net_iov, pp)");
_Static_assert(__builtin_offsetof(struct netmem_desc, _pp_mapping_pad) == __builtin_offsetof(struct net_iov, _pp_mapping_pad), "offsetof(struct netmem_desc, _pp_mapping_pad) == offsetof(struct net_iov, _pp_mapping_pad)");
_Static_assert(__builtin_offsetof(struct netmem_desc, dma_addr) == __builtin_offsetof(struct net_iov, dma_addr), "offsetof(struct netmem_desc, dma_addr) == offsetof(struct net_iov, dma_addr)");
_Static_assert(__builtin_offsetof(struct netmem_desc, pp_ref_count) == __builtin_offsetof(struct net_iov, pp_ref_count), "offsetof(struct netmem_desc, pp_ref_count) == offsetof(struct net_iov, pp_ref_count)");
struct net_device;
struct scatterlist;
struct pipe_inode_info;
struct iov_iter;
struct napi_struct;
struct bpf_prog;
union bpf_attr;
struct skb_ext;
struct sk_buff_head {

 union { struct { struct sk_buff *next; struct sk_buff *prev; } ; struct sk_buff_list { struct sk_buff *next; struct sk_buff *prev; } list; }


  ;

 __u32 qlen;
 spinlock_t lock;
};
struct sk_buff;
struct skb_shared_hwtstamps {
 union {
  ktime_t hwtstamp;
  void *netdev_data;
 };
};
struct ubuf_info_ops {
 void (*complete)(struct sk_buff *, struct ubuf_info *,
    bool zerocopy_success);

 int (*link_skb)(struct sk_buff *skb, struct ubuf_info *uarg);
};
struct ubuf_info {
 const struct ubuf_info_ops *ops;
 refcount_t refcnt;
 u8 flags;
};
typedef unsigned int sk_buff_data_t;
struct sk_buff {
 union {
  struct {

   struct sk_buff *next;
   struct sk_buff *prev;

   union {
    struct net_device *dev;




    unsigned long dev_scratch;
   };
  };
  struct rb_node rbnode;
  struct list_head list;
  struct llist_node ll_node;
 };

 struct sock *sk;

 union {
  ktime_t tstamp;
  u64 skb_mstamp_ns;
 };






 char cb[48] ;

 union {
  struct {
   unsigned long _skb_refdst;
   void (*destructor)(struct sk_buff *skb);
  };
  struct list_head tcp_tsorted_anchor;

  unsigned long _sk_redir;

 };


 unsigned long _nfct;

 unsigned int len,
    data_len;
 __u16 mac_len,
    hdr_len;




 __u16 queue_mapping;








 __u8 __cloned_offset[1];

 __u8 cloned:1,
    nohdr:1,
    fclone:2,
    peeked:1,
    head_frag:1,
    pfmemalloc:1,
    pp_recycle:1;

 __u8 active_extensions;





 union { struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 ipvs_property:1; __u8 nf_trace:1; __u8 offload_fwd_mark:1; __u8 offload_l3_fwd_mark:1; __u8 redirected:1; __u8 from_ingress:1; __u8 nf_skip_egress:1; __u8 decrypted:1; __u8 slow_gro:1; __u8 csum_not_inet:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } ; struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 ipvs_property:1; __u8 nf_trace:1; __u8 offload_fwd_mark:1; __u8 offload_l3_fwd_mark:1; __u8 redirected:1; __u8 from_ingress:1; __u8 nf_skip_egress:1; __u8 decrypted:1; __u8 slow_gro:1; __u8 csum_not_inet:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } headers; }
  ;


 sk_buff_data_t tail;
 sk_buff_data_t end;
 unsigned char *head,
    *data;
 unsigned int truesize;
 refcount_t users;



 struct skb_ext *extensions;

};
enum skb_ext_id {

 SKB_EXT_BRIDGE_NF,


 SKB_EXT_SEC_PATH,


 TC_SKB_EXT,


 SKB_EXT_MPTCP,


 SKB_EXT_MCTP,


 SKB_EXT_PSP,

 SKB_EXT_NUM,
};
struct skb_ext {
 refcount_t refcnt;
 u8 offset[SKB_EXT_NUM];
 u8 chunks;
 char data[1] ;
};
struct page;
typedef struct {
 atomic_long_t a;
} local_t;
struct dql {

 unsigned int num_queued;
 unsigned int adj_limit;
 unsigned int last_obj_cnt;


 unsigned short stall_thrs;

 unsigned long history_head;

 unsigned long history[4];



 unsigned int limit ;
 unsigned int num_completed;

 unsigned int prev_ovlimit;
 unsigned int prev_num_queued;
 unsigned int prev_last_obj_cnt;

 unsigned int lowest_slack;
 unsigned long slack_start_time;


 unsigned int max_limit;
 unsigned int min_limit;
 unsigned int slack_hold_time;


 unsigned short stall_max;
 unsigned long last_reap;
 unsigned long stall_cnt;
};
struct ctl_table_header;
struct prot_inuse;
struct cpumask;
struct netns_core {

 struct ctl_table_header *sysctl_hdr;

 int sysctl_somaxconn;
 int sysctl_optmem_max;
 u8 sysctl_txrehash;
 u8 sysctl_tstamp_allow_data;


 struct prot_inuse *prot_inuse;



 struct cpumask *rps_default_mask;

};
enum
{
 IPSTATS_MIB_NUM = 0,

 IPSTATS_MIB_INPKTS,
 IPSTATS_MIB_INOCTETS,
 IPSTATS_MIB_INDELIVERS,
 IPSTATS_MIB_NOECTPKTS,
 IPSTATS_MIB_ECT1PKTS,
 IPSTATS_MIB_ECT0PKTS,
 IPSTATS_MIB_CEPKTS,
 IPSTATS_MIB_OUTREQUESTS,
 IPSTATS_MIB_OUTPKTS,
 IPSTATS_MIB_OUTOCTETS,
 IPSTATS_MIB_OUTFORWDATAGRAMS,

 IPSTATS_MIB_INHDRERRORS,
 IPSTATS_MIB_INTOOBIGERRORS,
 IPSTATS_MIB_INNOROUTES,
 IPSTATS_MIB_INADDRERRORS,
 IPSTATS_MIB_INUNKNOWNPROTOS,
 IPSTATS_MIB_INTRUNCATEDPKTS,
 IPSTATS_MIB_INDISCARDS,
 IPSTATS_MIB_OUTDISCARDS,
 IPSTATS_MIB_OUTNOROUTES,
 IPSTATS_MIB_REASMTIMEOUT,
 IPSTATS_MIB_REASMREQDS,
 IPSTATS_MIB_REASMOKS,
 IPSTATS_MIB_REASMFAILS,
 IPSTATS_MIB_FRAGOKS,
 IPSTATS_MIB_FRAGFAILS,
 IPSTATS_MIB_FRAGCREATES,
 IPSTATS_MIB_INMCASTPKTS,
 IPSTATS_MIB_OUTMCASTPKTS,
 IPSTATS_MIB_INBCASTPKTS,
 IPSTATS_MIB_OUTBCASTPKTS,
 IPSTATS_MIB_INMCASTOCTETS,
 IPSTATS_MIB_OUTMCASTOCTETS,
 IPSTATS_MIB_INBCASTOCTETS,
 IPSTATS_MIB_OUTBCASTOCTETS,
 IPSTATS_MIB_CSUMERRORS,
 IPSTATS_MIB_REASM_OVERLAPS,
 __IPSTATS_MIB_MAX
};
enum
{
 ICMP_MIB_NUM = 0,
 ICMP_MIB_INMSGS,
 ICMP_MIB_INERRORS,
 ICMP_MIB_INDESTUNREACHS,
 ICMP_MIB_INTIMEEXCDS,
 ICMP_MIB_INPARMPROBS,
 ICMP_MIB_INSRCQUENCHS,
 ICMP_MIB_INREDIRECTS,
 ICMP_MIB_INECHOS,
 ICMP_MIB_INECHOREPS,
 ICMP_MIB_INTIMESTAMPS,
 ICMP_MIB_INTIMESTAMPREPS,
 ICMP_MIB_INADDRMASKS,
 ICMP_MIB_INADDRMASKREPS,
 ICMP_MIB_OUTMSGS,
 ICMP_MIB_OUTERRORS,
 ICMP_MIB_OUTDESTUNREACHS,
 ICMP_MIB_OUTTIMEEXCDS,
 ICMP_MIB_OUTPARMPROBS,
 ICMP_MIB_OUTSRCQUENCHS,
 ICMP_MIB_OUTREDIRECTS,
 ICMP_MIB_OUTECHOS,
 ICMP_MIB_OUTECHOREPS,
 ICMP_MIB_OUTTIMESTAMPS,
 ICMP_MIB_OUTTIMESTAMPREPS,
 ICMP_MIB_OUTADDRMASKS,
 ICMP_MIB_OUTADDRMASKREPS,
 ICMP_MIB_CSUMERRORS,
 ICMP_MIB_RATELIMITGLOBAL,
 ICMP_MIB_RATELIMITHOST,
 __ICMP_MIB_MAX
};
enum
{
 ICMP6_MIB_NUM = 0,
 ICMP6_MIB_INMSGS,
 ICMP6_MIB_INERRORS,
 ICMP6_MIB_OUTMSGS,
 ICMP6_MIB_OUTERRORS,
 ICMP6_MIB_CSUMERRORS,
 ICMP6_MIB_RATELIMITHOST,
 __ICMP6_MIB_MAX
};
enum
{
 TCP_MIB_NUM = 0,
 TCP_MIB_RTOALGORITHM,
 TCP_MIB_RTOMIN,
 TCP_MIB_RTOMAX,
 TCP_MIB_MAXCONN,
 TCP_MIB_ACTIVEOPENS,
 TCP_MIB_PASSIVEOPENS,
 TCP_MIB_ATTEMPTFAILS,
 TCP_MIB_ESTABRESETS,
 TCP_MIB_CURRESTAB,
 TCP_MIB_INSEGS,
 TCP_MIB_OUTSEGS,
 TCP_MIB_RETRANSSEGS,
 TCP_MIB_INERRS,
 TCP_MIB_OUTRSTS,
 TCP_MIB_CSUMERRORS,
 __TCP_MIB_MAX
};
enum
{
 UDP_MIB_NUM = 0,
 UDP_MIB_INDATAGRAMS,
 UDP_MIB_NOPORTS,
 UDP_MIB_INERRORS,
 UDP_MIB_OUTDATAGRAMS,
 UDP_MIB_RCVBUFERRORS,
 UDP_MIB_SNDBUFERRORS,
 UDP_MIB_CSUMERRORS,
 UDP_MIB_IGNOREDMULTI,
 UDP_MIB_MEMERRORS,
 __UDP_MIB_MAX
};
enum
{
 LINUX_MIB_NUM = 0,
 LINUX_MIB_SYNCOOKIESSENT,
 LINUX_MIB_SYNCOOKIESRECV,
 LINUX_MIB_SYNCOOKIESFAILED,
 LINUX_MIB_EMBRYONICRSTS,
 LINUX_MIB_PRUNECALLED,
 LINUX_MIB_RCVPRUNED,
 LINUX_MIB_OFOPRUNED,
 LINUX_MIB_OUTOFWINDOWICMPS,
 LINUX_MIB_LOCKDROPPEDICMPS,
 LINUX_MIB_ARPFILTER,
 LINUX_MIB_TIMEWAITED,
 LINUX_MIB_TIMEWAITRECYCLED,
 LINUX_MIB_TIMEWAITKILLED,
 LINUX_MIB_PAWSACTIVEREJECTED,
 LINUX_MIB_PAWSESTABREJECTED,
 LINUX_MIB_BEYOND_WINDOW,
 LINUX_MIB_TSECRREJECTED,
 LINUX_MIB_PAWS_OLD_ACK,
 LINUX_MIB_PAWS_TW_REJECTED,
 LINUX_MIB_DELAYEDACKS,
 LINUX_MIB_DELAYEDACKLOCKED,
 LINUX_MIB_DELAYEDACKLOST,
 LINUX_MIB_LISTENOVERFLOWS,
 LINUX_MIB_LISTENDROPS,
 LINUX_MIB_TCPHPHITS,
 LINUX_MIB_TCPPUREACKS,
 LINUX_MIB_TCPHPACKS,
 LINUX_MIB_TCPRENORECOVERY,
 LINUX_MIB_TCPSACKRECOVERY,
 LINUX_MIB_TCPSACKRENEGING,
 LINUX_MIB_TCPSACKREORDER,
 LINUX_MIB_TCPRENOREORDER,
 LINUX_MIB_TCPTSREORDER,
 LINUX_MIB_TCPFULLUNDO,
 LINUX_MIB_TCPPARTIALUNDO,
 LINUX_MIB_TCPDSACKUNDO,
 LINUX_MIB_TCPLOSSUNDO,
 LINUX_MIB_TCPLOSTRETRANSMIT,
 LINUX_MIB_TCPRENOFAILURES,
 LINUX_MIB_TCPSACKFAILURES,
 LINUX_MIB_TCPLOSSFAILURES,
 LINUX_MIB_TCPFASTRETRANS,
 LINUX_MIB_TCPSLOWSTARTRETRANS,
 LINUX_MIB_TCPTIMEOUTS,
 LINUX_MIB_TCPLOSSPROBES,
 LINUX_MIB_TCPLOSSPROBERECOVERY,
 LINUX_MIB_TCPRENORECOVERYFAIL,
 LINUX_MIB_TCPSACKRECOVERYFAIL,
 LINUX_MIB_TCPRCVCOLLAPSED,
 LINUX_MIB_TCPDSACKOLDSENT,
 LINUX_MIB_TCPDSACKOFOSENT,
 LINUX_MIB_TCPDSACKRECV,
 LINUX_MIB_TCPDSACKOFORECV,
 LINUX_MIB_TCPABORTONDATA,
 LINUX_MIB_TCPABORTONCLOSE,
 LINUX_MIB_TCPABORTONMEMORY,
 LINUX_MIB_TCPABORTONTIMEOUT,
 LINUX_MIB_TCPABORTONLINGER,
 LINUX_MIB_TCPABORTFAILED,
 LINUX_MIB_TCPMEMORYPRESSURES,
 LINUX_MIB_TCPMEMORYPRESSURESCHRONO,
 LINUX_MIB_TCPSACKDISCARD,
 LINUX_MIB_TCPDSACKIGNOREDOLD,
 LINUX_MIB_TCPDSACKIGNOREDNOUNDO,
 LINUX_MIB_TCPSPURIOUSRTOS,
 LINUX_MIB_TCPMD5NOTFOUND,
 LINUX_MIB_TCPMD5UNEXPECTED,
 LINUX_MIB_TCPMD5FAILURE,
 LINUX_MIB_SACKSHIFTED,
 LINUX_MIB_SACKMERGED,
 LINUX_MIB_SACKSHIFTFALLBACK,
 LINUX_MIB_TCPBACKLOGDROP,
 LINUX_MIB_PFMEMALLOCDROP,
 LINUX_MIB_TCPMINTTLDROP,
 LINUX_MIB_TCPDEFERACCEPTDROP,
 LINUX_MIB_IPRPFILTER,
 LINUX_MIB_TCPTIMEWAITOVERFLOW,
 LINUX_MIB_TCPREQQFULLDOCOOKIES,
 LINUX_MIB_TCPREQQFULLDROP,
 LINUX_MIB_TCPRETRANSFAIL,
 LINUX_MIB_TCPRCVCOALESCE,
 LINUX_MIB_TCPBACKLOGCOALESCE,
 LINUX_MIB_TCPOFOQUEUE,
 LINUX_MIB_TCPOFODROP,
 LINUX_MIB_TCPOFOMERGE,
 LINUX_MIB_TCPCHALLENGEACK,
 LINUX_MIB_TCPSYNCHALLENGE,
 LINUX_MIB_TCPFASTOPENACTIVE,
 LINUX_MIB_TCPFASTOPENACTIVEFAIL,
 LINUX_MIB_TCPFASTOPENPASSIVE,
 LINUX_MIB_TCPFASTOPENPASSIVEFAIL,
 LINUX_MIB_TCPFASTOPENLISTENOVERFLOW,
 LINUX_MIB_TCPFASTOPENCOOKIEREQD,
 LINUX_MIB_TCPFASTOPENBLACKHOLE,
 LINUX_MIB_TCPSPURIOUS_RTX_HOSTQUEUES,
 LINUX_MIB_BUSYPOLLRXPACKETS,
 LINUX_MIB_TCPAUTOCORKING,
 LINUX_MIB_TCPFROMZEROWINDOWADV,
 LINUX_MIB_TCPTOZEROWINDOWADV,
 LINUX_MIB_TCPWANTZEROWINDOWADV,
 LINUX_MIB_TCPSYNRETRANS,
 LINUX_MIB_TCPORIGDATASENT,
 LINUX_MIB_TCPHYSTARTTRAINDETECT,
 LINUX_MIB_TCPHYSTARTTRAINCWND,
 LINUX_MIB_TCPHYSTARTDELAYDETECT,
 LINUX_MIB_TCPHYSTARTDELAYCWND,
 LINUX_MIB_TCPACKSKIPPEDSYNRECV,
 LINUX_MIB_TCPACKSKIPPEDPAWS,
 LINUX_MIB_TCPACKSKIPPEDSEQ,
 LINUX_MIB_TCPACKSKIPPEDFINWAIT2,
 LINUX_MIB_TCPACKSKIPPEDTIMEWAIT,
 LINUX_MIB_TCPACKSKIPPEDCHALLENGE,
 LINUX_MIB_TCPWINPROBE,
 LINUX_MIB_TCPKEEPALIVE,
 LINUX_MIB_TCPMTUPFAIL,
 LINUX_MIB_TCPMTUPSUCCESS,
 LINUX_MIB_TCPDELIVERED,
 LINUX_MIB_TCPDELIVEREDCE,
 LINUX_MIB_TCPACKCOMPRESSED,
 LINUX_MIB_TCPZEROWINDOWDROP,
 LINUX_MIB_TCPRCVQDROP,
 LINUX_MIB_TCPWQUEUETOOBIG,
 LINUX_MIB_TCPFASTOPENPASSIVEALTKEY,
 LINUX_MIB_TCPTIMEOUTREHASH,
 LINUX_MIB_TCPDUPLICATEDATAREHASH,
 LINUX_MIB_TCPDSACKRECVSEGS,
 LINUX_MIB_TCPDSACKIGNOREDDUBIOUS,
 LINUX_MIB_TCPMIGRATEREQSUCCESS,
 LINUX_MIB_TCPMIGRATEREQFAILURE,
 LINUX_MIB_TCPPLBREHASH,
 LINUX_MIB_TCPAOREQUIRED,
 LINUX_MIB_TCPAOBAD,
 LINUX_MIB_TCPAOKEYNOTFOUND,
 LINUX_MIB_TCPAOGOOD,
 LINUX_MIB_TCPAODROPPEDICMPS,
 __LINUX_MIB_MAX
};
enum
{
 LINUX_MIB_XFRMNUM = 0,
 LINUX_MIB_XFRMINERROR,
 LINUX_MIB_XFRMINBUFFERERROR,
 LINUX_MIB_XFRMINHDRERROR,
 LINUX_MIB_XFRMINNOSTATES,
 LINUX_MIB_XFRMINSTATEPROTOERROR,
 LINUX_MIB_XFRMINSTATEMODEERROR,
 LINUX_MIB_XFRMINSTATESEQERROR,
 LINUX_MIB_XFRMINSTATEEXPIRED,
 LINUX_MIB_XFRMINSTATEMISMATCH,
 LINUX_MIB_XFRMINSTATEINVALID,
 LINUX_MIB_XFRMINTMPLMISMATCH,
 LINUX_MIB_XFRMINNOPOLS,
 LINUX_MIB_XFRMINPOLBLOCK,
 LINUX_MIB_XFRMINPOLERROR,
 LINUX_MIB_XFRMOUTERROR,
 LINUX_MIB_XFRMOUTBUNDLEGENERROR,
 LINUX_MIB_XFRMOUTBUNDLECHECKERROR,
 LINUX_MIB_XFRMOUTNOSTATES,
 LINUX_MIB_XFRMOUTSTATEPROTOERROR,
 LINUX_MIB_XFRMOUTSTATEMODEERROR,
 LINUX_MIB_XFRMOUTSTATESEQERROR,
 LINUX_MIB_XFRMOUTSTATEEXPIRED,
 LINUX_MIB_XFRMOUTPOLBLOCK,
 LINUX_MIB_XFRMOUTPOLDEAD,
 LINUX_MIB_XFRMOUTPOLERROR,
 LINUX_MIB_XFRMFWDHDRERROR,
 LINUX_MIB_XFRMOUTSTATEINVALID,
 LINUX_MIB_XFRMACQUIREERROR,
 LINUX_MIB_XFRMOUTSTATEDIRERROR,
 LINUX_MIB_XFRMINSTATEDIRERROR,
 LINUX_MIB_XFRMINIPTFSERROR,
 LINUX_MIB_XFRMOUTNOQSPACE,
 __LINUX_MIB_XFRMMAX
};
enum
{
 LINUX_MIB_TLSNUM = 0,
 LINUX_MIB_TLSCURRTXSW,
 LINUX_MIB_TLSCURRRXSW,
 LINUX_MIB_TLSCURRTXDEVICE,
 LINUX_MIB_TLSCURRRXDEVICE,
 LINUX_MIB_TLSTXSW,
 LINUX_MIB_TLSRXSW,
 LINUX_MIB_TLSTXDEVICE,
 LINUX_MIB_TLSRXDEVICE,
 LINUX_MIB_TLSDECRYPTERROR,
 LINUX_MIB_TLSRXDEVICERESYNC,
 LINUX_MIB_TLSDECRYPTRETRY,
 LINUX_MIB_TLSRXNOPADVIOL,
 LINUX_MIB_TLSRXREKEYOK,
 LINUX_MIB_TLSRXREKEYERROR,
 LINUX_MIB_TLSTXREKEYOK,
 LINUX_MIB_TLSTXREKEYERROR,
 LINUX_MIB_TLSRXREKEYRECEIVED,
 __LINUX_MIB_TLSMAX
};
struct u64_stats_sync {



};
typedef struct {
 local_t a;
} local64_t;
typedef struct {
 local64_t v;
} u64_stats_t ;
struct ipstats_mib {

 u64 mibs[__IPSTATS_MIB_MAX];
 struct u64_stats_sync syncp;
};
struct icmp_mib {
 unsigned long mibs[__ICMP_MIB_MAX];
};
struct icmpmsg_mib {
 atomic_long_t mibs[512];
};
struct icmpv6_mib {
 unsigned long mibs[__ICMP6_MIB_MAX];
};
struct icmpv6msg_mib {
 atomic_long_t mibs[512];
};
struct tcp_mib {
 unsigned long mibs[__TCP_MIB_MAX];
};
struct udp_mib {
 unsigned long mibs[__UDP_MIB_MAX];
};
struct linux_mib {
 unsigned long mibs[__LINUX_MIB_MAX];
};
struct linux_xfrm_mib {
 unsigned long mibs[__LINUX_MIB_XFRMMAX];
};
struct linux_tls_mib {
 unsigned long mibs[__LINUX_MIB_TLSMAX];
};
struct netns_mib {
 __typeof__(struct ipstats_mib) *ip_statistics;

 __typeof__(struct ipstats_mib) *ipv6_statistics;


 __typeof__(struct tcp_mib) *tcp_statistics;
 __typeof__(struct linux_mib) *net_statistics;

 __typeof__(struct udp_mib) *udp_statistics;

 __typeof__(struct udp_mib) *udp_stats_in6;



 __typeof__(struct linux_xfrm_mib) *xfrm_statistics;


 __typeof__(struct linux_tls_mib) *tls_statistics;


 __typeof__(struct mptcp_mib) *mptcp_statistics;


 __typeof__(struct udp_mib) *udplite_statistics;

 __typeof__(struct udp_mib) *udplite_stats_in6;


 __typeof__(struct icmp_mib) *icmp_statistics;
 __typeof__(struct icmpmsg_mib) *icmpmsg_statistics;

 __typeof__(struct icmpv6_mib) *icmpv6_statistics;
 __typeof__(struct icmpv6msg_mib) *icmpv6msg_statistics;
 struct proc_dir_entry *proc_net_devsnmp6;

};
struct unix_table {
 spinlock_t *locks;
 struct hlist_head *buckets;
};
struct ctl_table_header;
struct netns_unix {
 struct unix_table table;
 int sysctl_max_dgram_qlen;
 struct ctl_table_header *ctl;
};
struct netns_packet {
 struct mutex sklist_lock;
 struct hlist_head sklist;
};
struct fqdir {

 long high_thresh;
 long low_thresh;
 int timeout;
 int max_dist;
 struct inet_frags *f;
 struct net *net;
 bool dead;

 struct rhashtable rhashtable ;


 atomic_long_t mem ;
 struct work_struct destroy_work;
 struct llist_node free_list;
};
struct frag_v4_compare_key {
 __be32 saddr;
 __be32 daddr;
 u32 user;
 u32 vif;
 __be16 id;
 u16 protocol;
};
struct frag_v6_compare_key {
 struct in6_addr saddr;
 struct in6_addr daddr;
 u32 user;
 __be32 id;
 u32 iif;
};
struct inet_frag_queue {
 struct rhash_head node;
 union {
  struct frag_v4_compare_key v4;
  struct frag_v6_compare_key v6;
 } key;
 struct timer_list timer;
 spinlock_t lock;
 refcount_t refcnt;
 struct rb_root rb_fragments;
 struct sk_buff *fragments_tail;
 struct sk_buff *last_run_head;
 ktime_t stamp;
 int len;
 int meat;
 u8 tstamp_type;
 __u8 flags;
 u16 max_size;
 struct fqdir *fqdir;
 struct callback_head rcu;
};
struct inet_frags {
 unsigned int qsize;

 void (*constructor)(struct inet_frag_queue *q,
            const void *arg);
 void (*destructor)(struct inet_frag_queue *);
 void (*frag_expire)(struct timer_list *t);
 struct kmem_cache *frags_cachep;
 const char *frags_cache_name;
 struct rhashtable_params rhash_params;
 refcount_t refcnt;
 struct completion completion;
};
struct ctl_table_header;
struct ipv4_devconf;
struct fib_rules_ops;
struct hlist_head;
struct fib_table;
struct sock;
struct local_ports {
 u32 range;
 bool warned;
};
struct ping_group_range {
 seqlock_t lock;
 kgid_t range[2];
};
struct inet_hashinfo;
struct inet_timewait_death_row {
 refcount_t tw_refcount;


 struct inet_hashinfo *hashinfo ;
 int sysctl_max_tw_buckets;
};
struct tcp_fastopen_context;
struct sysctl_fib_multipath_hash_seed {
 u32 user_seed;
 u32 mp_seed;
};
struct udp_tunnel_gro {
 struct sock *sk;
 struct hlist_head list;
};
struct netns_ipv4 {






 __u8 __cacheline_group_begin__netns_ipv4_read_tx[1];
 u8 sysctl_tcp_early_retrans;
 u8 sysctl_tcp_tso_win_divisor;
 u8 sysctl_tcp_tso_rtt_log;
 u8 sysctl_tcp_autocorking;
 int sysctl_tcp_min_snd_mss;
 unsigned int sysctl_tcp_notsent_lowat;
 int sysctl_tcp_limit_output_bytes;
 int sysctl_tcp_min_rtt_wlen;
 int sysctl_tcp_wmem[3];
 u8 sysctl_ip_fwd_use_pmtu;
 __u8 __cacheline_group_end__netns_ipv4_read_tx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_txrx[1];
 u8 sysctl_tcp_moderate_rcvbuf;
 __u8 __cacheline_group_end__netns_ipv4_read_txrx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_rx[1];
 u8 sysctl_ip_early_demux;
 u8 sysctl_tcp_early_demux;
 u8 sysctl_tcp_l3mdev_accept;

 int sysctl_tcp_reordering;
 int sysctl_tcp_rmem[3];
 __u8 __cacheline_group_end__netns_ipv4_read_rx[1];


 __u8 __cacheline_group_begin__icmp[1] ;
 atomic_t icmp_global_credit;
 u32 icmp_global_stamp;
 __u8 __cacheline_group_end__icmp[1] ; struct { } __cacheline_group_pad__icmp ;

 struct inet_timewait_death_row tcp_death_row;
 struct udp_table *udp_table;



 struct udp_tunnel_gro udp_tunnel_gro[2];



 struct ctl_table_header *forw_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *ipv4_hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *xfrm4_hdr;

 struct ipv4_devconf *devconf_all;
 struct ipv4_devconf *devconf_dflt;
 struct ip_ra_chain *ra_chain;
 struct mutex ra_mutex;

 struct fib_rules_ops *rules_ops;
 struct fib_table *fib_main;
 struct fib_table *fib_default;
 unsigned int fib_rules_require_fldissect;
 bool fib_has_custom_rules;

 bool fib_has_custom_local_routes;
 bool fib_offload_disabled;
 u8 sysctl_tcp_shrink_window;

 atomic_t fib_num_tclassid_users;

 struct hlist_head *fib_table_hash;
 struct sock *fibnl;
 struct hlist_head *fib_info_hash;
 unsigned int fib_info_hash_bits;
 unsigned int fib_info_cnt;

 struct sock *mc_autojoin_sk;

 struct inet_peer_base *peers;
 struct fqdir *fqdir;

 u8 sysctl_icmp_echo_ignore_all;
 u8 sysctl_icmp_echo_enable_probe;
 u8 sysctl_icmp_echo_ignore_broadcasts;
 u8 sysctl_icmp_ignore_bogus_error_responses;
 u8 sysctl_icmp_errors_use_inbound_ifaddr;
 int sysctl_icmp_ratelimit;
 int sysctl_icmp_ratemask;
 int sysctl_icmp_msgs_per_sec;
 int sysctl_icmp_msgs_burst;

 u32 ip_rt_min_pmtu;
 int ip_rt_mtu_expires;
 int ip_rt_min_advmss;

 struct local_ports ip_local_ports;

 u8 sysctl_tcp_ecn;
 u8 sysctl_tcp_ecn_option;
 u8 sysctl_tcp_ecn_option_beacon;
 u8 sysctl_tcp_ecn_fallback;

 u8 sysctl_ip_default_ttl;
 u8 sysctl_ip_no_pmtu_disc;
 u8 sysctl_ip_fwd_update_priority;
 u8 sysctl_ip_nonlocal_bind;
 u8 sysctl_ip_autobind_reuse;

 u8 sysctl_ip_dynaddr;

 u8 sysctl_raw_l3mdev_accept;

 u8 sysctl_udp_early_demux;

 u8 sysctl_nexthop_compat_mode;

 u8 sysctl_fwmark_reflect;
 u8 sysctl_tcp_fwmark_accept;
 u8 sysctl_tcp_mtu_probing;
 int sysctl_tcp_mtu_probe_floor;
 int sysctl_tcp_base_mss;
 int sysctl_tcp_probe_threshold;
 u32 sysctl_tcp_probe_interval;

 int sysctl_tcp_keepalive_time;
 int sysctl_tcp_keepalive_intvl;
 u8 sysctl_tcp_keepalive_probes;

 u8 sysctl_tcp_syn_retries;
 u8 sysctl_tcp_synack_retries;
 u8 sysctl_tcp_syncookies;
 u8 sysctl_tcp_migrate_req;
 u8 sysctl_tcp_comp_sack_nr;
 u8 sysctl_tcp_backlog_ack_defer;
 u8 sysctl_tcp_pingpong_thresh;

 u8 sysctl_tcp_retries1;
 u8 sysctl_tcp_retries2;
 u8 sysctl_tcp_orphan_retries;
 u8 sysctl_tcp_tw_reuse;
 unsigned int sysctl_tcp_tw_reuse_delay;
 int sysctl_tcp_fin_timeout;
 u8 sysctl_tcp_sack;
 u8 sysctl_tcp_window_scaling;
 u8 sysctl_tcp_timestamps;
 int sysctl_tcp_rto_min_us;
 int sysctl_tcp_rto_max_ms;
 u8 sysctl_tcp_recovery;
 u8 sysctl_tcp_thin_linear_timeouts;
 u8 sysctl_tcp_slow_start_after_idle;
 u8 sysctl_tcp_retrans_collapse;
 u8 sysctl_tcp_stdurg;
 u8 sysctl_tcp_rfc1337;
 u8 sysctl_tcp_abort_on_overflow;
 u8 sysctl_tcp_fack;
 int sysctl_tcp_max_reordering;
 int sysctl_tcp_adv_win_scale;
 u8 sysctl_tcp_dsack;
 u8 sysctl_tcp_app_win;
 u8 sysctl_tcp_frto;
 u8 sysctl_tcp_nometrics_save;
 u8 sysctl_tcp_no_ssthresh_metrics_save;
 u8 sysctl_tcp_workaround_signed_windows;
 int sysctl_tcp_challenge_ack_limit;
 u8 sysctl_tcp_min_tso_segs;
 u8 sysctl_tcp_reflect_tos;
 int sysctl_tcp_invalid_ratelimit;
 int sysctl_tcp_pacing_ss_ratio;
 int sysctl_tcp_pacing_ca_ratio;
 unsigned int sysctl_tcp_child_ehash_entries;
 unsigned long sysctl_tcp_comp_sack_delay_ns;
 unsigned long sysctl_tcp_comp_sack_slack_ns;
 int sysctl_max_syn_backlog;
 int sysctl_tcp_fastopen;
 const struct tcp_congestion_ops *tcp_congestion_control;
 struct tcp_fastopen_context *tcp_fastopen_ctx;
 unsigned int sysctl_tcp_fastopen_blackhole_timeout;
 atomic_t tfo_active_disable_times;
 unsigned long tfo_active_disable_stamp;
 u32 tcp_challenge_timestamp;
 u32 tcp_challenge_count;
 u8 sysctl_tcp_plb_enabled;
 u8 sysctl_tcp_plb_idle_rehash_rounds;
 u8 sysctl_tcp_plb_rehash_rounds;
 u8 sysctl_tcp_plb_suspend_rto_sec;
 int sysctl_tcp_plb_cong_thresh;

 int sysctl_udp_wmem_min;
 int sysctl_udp_rmem_min;

 u8 sysctl_fib_notify_on_flag_change;
 u8 sysctl_tcp_syn_linear_timeouts;


 u8 sysctl_udp_l3mdev_accept;


 u8 sysctl_igmp_llm_reports;
 int sysctl_igmp_max_memberships;
 int sysctl_igmp_max_msf;
 int sysctl_igmp_qrv;

 struct ping_group_range ping_group_range;
 u16 ping_port_rover;

 atomic_t dev_addr_genid;

 unsigned int sysctl_udp_child_hash_entries;


 unsigned long *sysctl_local_reserved_ports;
 int sysctl_ip_prot_sock;






 struct list_head mr_tables;
 struct fib_rules_ops *mr_rules_ops;



 struct sysctl_fib_multipath_hash_seed sysctl_fib_multipath_hash_seed;
 u32 sysctl_fib_multipath_hash_fields;
 u8 sysctl_fib_multipath_use_neigh;
 u8 sysctl_fib_multipath_hash_policy;


 struct fib_notifier_ops *notifier_ops;
 unsigned int fib_seq;

 struct fib_notifier_ops *ipmr_notifier_ops;
 unsigned int ipmr_seq;

 atomic_t rt_genid;
 siphash_key_t ip_id_key;
 struct hlist_head *inet_addr_lst;
 struct delayed_work addr_chk_work;
};
struct dst_entry;
struct kmem_cachep;
struct net_device;
struct sk_buff;
struct sock;
struct net;
struct dst_ops {
 unsigned short family;
 unsigned int gc_thresh;

 void (*gc)(struct dst_ops *ops);
 struct dst_entry * (*check)(struct dst_entry *, __u32 cookie);
 unsigned int (*default_advmss)(const struct dst_entry *);
 unsigned int (*mtu)(const struct dst_entry *);
 u32 * (*cow_metrics)(struct dst_entry *, unsigned long);
 void (*destroy)(struct dst_entry *);
 void (*ifdown)(struct dst_entry *,
       struct net_device *dev);
 void (*negative_advice)(struct sock *sk, struct dst_entry *);
 void (*link_failure)(struct sk_buff *);
 void (*update_pmtu)(struct dst_entry *dst, struct sock *sk,
            struct sk_buff *skb, u32 mtu,
            bool confirm_neigh);
 void (*redirect)(struct dst_entry *dst, struct sock *sk,
         struct sk_buff *skb);
 int (*local_out)(struct net *net, struct sock *sk, struct sk_buff *skb);
 struct neighbour * (*neigh_lookup)(const struct dst_entry *dst,
      struct sk_buff *skb,
      const void *daddr);
 void (*confirm_neigh)(const struct dst_entry *dst,
       const void *daddr);

 struct kmem_cache *kmem_cachep;

 struct percpu_counter pcpuc_entries ;
};
struct ctl_table_header;
struct netns_sysctl_ipv6 {

 struct ctl_table_header *hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *icmp_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *xfrm6_hdr;

 int flush_delay;
 int ip6_rt_max_size;
 int ip6_rt_gc_min_interval;
 int ip6_rt_gc_timeout;
 int ip6_rt_gc_interval;
 int ip6_rt_gc_elasticity;
 int ip6_rt_mtu_expires;
 int ip6_rt_min_advmss;
 u32 multipath_hash_fields;
 u8 multipath_hash_policy;
 u8 bindv6only;
 u8 flowlabel_consistency;
 u8 auto_flowlabels;
 int icmpv6_time;
 u8 icmpv6_echo_ignore_all;
 u8 icmpv6_echo_ignore_multicast;
 u8 icmpv6_echo_ignore_anycast;
 unsigned long icmpv6_ratemask[(((255 + 1) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long *icmpv6_ratemask_ptr;
 u8 anycast_src_echo_reply;
 u8 ip_nonlocal_bind;
 u8 fwmark_reflect;
 u8 flowlabel_state_ranges;
 int idgen_retries;
 int idgen_delay;
 int flowlabel_reflect;
 int max_dst_opts_cnt;
 int max_hbh_opts_cnt;
 int max_dst_opts_len;
 int max_hbh_opts_len;
 int seg6_flowlabel;
 u32 ioam6_id;
 u64 ioam6_id_wide;
 u8 skip_notify_on_dev_down;
 u8 fib_notify_on_flag_change;
 u8 icmpv6_error_anycast_as_unicast;
};
struct netns_ipv6 {

 struct dst_ops ip6_dst_ops;

 struct netns_sysctl_ipv6 sysctl;
 struct ipv6_devconf *devconf_all;
 struct ipv6_devconf *devconf_dflt;
 struct inet_peer_base *peers;
 struct fqdir *fqdir;
 struct fib6_info *fib6_null_entry;
 struct rt6_info *ip6_null_entry;
 struct rt6_statistics *rt6_stats;
 struct timer_list ip6_fib_timer;
 struct hlist_head *fib_table_hash;
 spinlock_t fib_table_hash_lock;
 struct fib6_table *fib6_main_tbl;
 struct list_head fib6_walkers;
 rwlock_t fib6_walker_lock;
 spinlock_t fib6_gc_lock;
 atomic_t ip6_rt_gc_expire;
 unsigned long ip6_rt_last_gc;
 unsigned char flowlabel_has_excl;

 bool fib6_has_custom_rules;
 unsigned int fib6_rules_require_fldissect;

 unsigned int fib6_routes_require_src;

 struct rt6_info *ip6_prohibit_entry;
 struct rt6_info *ip6_blk_hole_entry;
 struct fib6_table *fib6_local_tbl;
 struct fib_rules_ops *fib6_rules_ops;

 struct sock *ndisc_sk;
 struct sock *tcp_sk;
 struct sock *igmp_sk;
 struct sock *mc_autojoin_sk;

 struct hlist_head *inet6_addr_lst;
 spinlock_t addrconf_hash_lock;
 struct delayed_work addr_chk_work;





 struct list_head mr6_tables;
 struct fib_rules_ops *mr6_rules_ops;


 atomic_t dev_addr_genid;
 atomic_t fib6_sernum;
 struct seg6_pernet_data *seg6_data;
 struct fib_notifier_ops *notifier_ops;
 struct fib_notifier_ops *ip6mr_notifier_ops;
 unsigned int ipmr_seq;
 struct {
  struct hlist_head head;
  spinlock_t lock;
  u32 seq;
 } ip6addrlbl_table;
 struct ioam6_pernet_data *ioam6_data;
};
struct netns_nexthop {
 struct rb_root rb_root;
 struct hlist_head *devhash;

 unsigned int seq;
 u32 last_id_allocated;
 struct blocking_notifier_head notifier_chain;
};
struct netns_sysctl_lowpan {

 struct ctl_table_header *frags_hdr;

};
struct netns_ieee802154_lowpan {
 struct netns_sysctl_lowpan sysctl;
 struct fqdir *fqdir;
};
struct sock;
struct proc_dir_entry;
struct sctp_mib;
struct ctl_table_header;
struct netns_sctp {
 __typeof__(struct sctp_mib) *sctp_statistics;


 struct proc_dir_entry *proc_net_sctp;


 struct ctl_table_header *sysctl_header;





 struct sock *ctl_sock;


 struct sock *udp4_sock;
 struct sock *udp6_sock;

 int udp_port;

 int encap_port;







 struct list_head local_addr_list;
 struct list_head addr_waitq;
 struct timer_list addr_wq_timer;
 struct list_head auto_asconf_splist;

 spinlock_t addr_wq_lock;


 spinlock_t local_addr_lock;
 unsigned int rto_initial;
 unsigned int rto_min;
 unsigned int rto_max;




 int rto_alpha;
 int rto_beta;


 int max_burst;


 int cookie_preserve_enable;


 int cookie_auth_enable;


 unsigned int valid_cookie_life;


 unsigned int sack_timeout;


 unsigned int hb_interval;


 unsigned int probe_interval;





 int max_retrans_association;
 int max_retrans_path;
 int max_retrans_init;




 int pf_retrans;





 int ps_retrans;






 int pf_enable;







 int pf_expose;






 int sndbuf_policy;






 int rcvbuf_policy;

 int default_auto_asconf;


 int addip_enable;
 int addip_noauth;


 int prsctp_enable;


 int reconf_enable;


 int auth_enable;


 int intl_enable;


 int ecn_enable;
 int scope_policy;




 int rwnd_upd_shift;


 unsigned long max_autoclose;


 int l3mdev_accept;

};
enum nf_inet_hooks {
 NF_INET_PRE_ROUTING,
 NF_INET_LOCAL_IN,
 NF_INET_FORWARD,
 NF_INET_LOCAL_OUT,
 NF_INET_POST_ROUTING,
 NF_INET_NUMHOOKS,
 NF_INET_INGRESS = NF_INET_NUMHOOKS,
};
enum {
 NFPROTO_UNSPEC = 0,
 NFPROTO_INET = 1,
 NFPROTO_IPV4 = 2,
 NFPROTO_ARP = 3,
 NFPROTO_NETDEV = 5,
 NFPROTO_BRIDGE = 7,
 NFPROTO_IPV6 = 10,



 NFPROTO_NUMPROTO,
};
struct proc_dir_entry;
struct nf_logger;
struct netns_nf {

 struct proc_dir_entry *proc_netfilter;

 const struct nf_logger *nf_loggers[NFPROTO_NUMPROTO];

 struct ctl_table_header *nf_log_dir_header;

 struct ctl_table_header *nf_lwtnl_dir_header;


 struct nf_hook_entries *hooks_ipv4[NF_INET_NUMHOOKS];
 struct nf_hook_entries *hooks_ipv6[NF_INET_NUMHOOKS];

 struct nf_hook_entries *hooks_arp[3];


 struct nf_hook_entries *hooks_bridge[NF_INET_NUMHOOKS];


 unsigned int defrag_ipv4_users;


 unsigned int defrag_ipv6_users;

};
enum tcp_conntrack {
 TCP_CONNTRACK_NONE,
 TCP_CONNTRACK_SYN_SENT,
 TCP_CONNTRACK_SYN_RECV,
 TCP_CONNTRACK_ESTABLISHED,
 TCP_CONNTRACK_FIN_WAIT,
 TCP_CONNTRACK_CLOSE_WAIT,
 TCP_CONNTRACK_LAST_ACK,
 TCP_CONNTRACK_TIME_WAIT,
 TCP_CONNTRACK_CLOSE,
 TCP_CONNTRACK_LISTEN,
 TCP_CONNTRACK_MAX,
 TCP_CONNTRACK_IGNORE,
 TCP_CONNTRACK_RETRANS,
 TCP_CONNTRACK_UNACK,
 TCP_CONNTRACK_TIMEOUT_MAX
};
enum sctp_conntrack {
 SCTP_CONNTRACK_NONE,
 SCTP_CONNTRACK_CLOSED,
 SCTP_CONNTRACK_COOKIE_WAIT,
 SCTP_CONNTRACK_COOKIE_ECHOED,
 SCTP_CONNTRACK_ESTABLISHED,
 SCTP_CONNTRACK_SHUTDOWN_SENT,
 SCTP_CONNTRACK_SHUTDOWN_RECD,
 SCTP_CONNTRACK_SHUTDOWN_ACK_SENT,
 SCTP_CONNTRACK_HEARTBEAT_SENT,
 SCTP_CONNTRACK_HEARTBEAT_ACKED,
 SCTP_CONNTRACK_MAX
};
struct ctl_table_header;
struct nf_generic_net {
 unsigned int timeout;
};
struct nf_tcp_net {
 unsigned int timeouts[TCP_CONNTRACK_TIMEOUT_MAX];
 u8 tcp_loose;
 u8 tcp_be_liberal;
 u8 tcp_max_retrans;
 u8 tcp_ignore_invalid_rst;

 unsigned int offload_timeout;

};
enum udp_conntrack {
 UDP_CT_UNREPLIED,
 UDP_CT_REPLIED,
 UDP_CT_MAX
};
struct nf_udp_net {
 unsigned int timeouts[UDP_CT_MAX];

 unsigned int offload_timeout;

};
struct nf_icmp_net {
 unsigned int timeout;
};
struct nf_sctp_net {
 unsigned int timeouts[SCTP_CONNTRACK_MAX];
};
enum gre_conntrack {
 GRE_CT_UNREPLIED,
 GRE_CT_REPLIED,
 GRE_CT_MAX
};
struct nf_gre_net {
 struct list_head keymap_list;
 unsigned int timeouts[GRE_CT_MAX];
};
struct nf_ip_net {
 struct nf_generic_net generic;
 struct nf_tcp_net tcp;
 struct nf_udp_net udp;
 struct nf_icmp_net icmp;
 struct nf_icmp_net icmpv6;

 struct nf_sctp_net sctp;


 struct nf_gre_net gre;

};
struct netns_ct {

 bool ecache_dwork_pending;

 u8 sysctl_log_invalid;
 u8 sysctl_events;
 u8 sysctl_acct;
 u8 sysctl_tstamp;
 u8 sysctl_checksum;

 struct ip_conntrack_stat *stat;
 struct nf_ct_event_notifier *nf_conntrack_event_cb;
 struct nf_ip_net nf_ct_proto;

 atomic_t labels_used;

};
struct nf_flow_table_stat {
 unsigned int count_wq_add;
 unsigned int count_wq_del;
 unsigned int count_wq_stats;
};
struct netns_ft {
 struct nf_flow_table_stat *stat;
};
struct netns_nftables {
 unsigned int base_seq;
 u8 gencursor;
};
enum {
 XFRM_POLICY_IN = 0,
 XFRM_POLICY_OUT = 1,
 XFRM_POLICY_FWD = 2,
 XFRM_POLICY_MASK = 3,
 XFRM_POLICY_MAX = 3
};
struct ctl_table_header;
struct xfrm_policy_hash {
 struct hlist_head *table;
 unsigned int hmask;
 u8 dbits4;
 u8 sbits4;
 u8 dbits6;
 u8 sbits6;
};
struct xfrm_policy_hthresh {
 struct work_struct work;
 seqlock_t lock;
 u8 lbits4;
 u8 rbits4;
 u8 lbits6;
 u8 rbits6;
};
struct netns_xfrm {
 struct list_head state_all;
 struct hlist_head *state_bydst;
 struct hlist_head *state_bysrc;
 struct hlist_head *state_byspi;
 struct hlist_head *state_byseq;
 struct hlist_head *state_cache_input;
 unsigned int state_hmask;
 unsigned int state_num;
 struct work_struct state_hash_work;

 struct list_head policy_all;
 struct hlist_head *policy_byidx;
 unsigned int policy_idx_hmask;
 unsigned int idx_generator;
 struct xfrm_policy_hash policy_bydst[XFRM_POLICY_MAX];
 unsigned int policy_count[XFRM_POLICY_MAX * 2];
 struct work_struct policy_hash_work;
 struct xfrm_policy_hthresh policy_hthresh;
 struct list_head inexact_bins;


 struct sock *nlsk;
 struct sock *nlsk_stash;

 u32 sysctl_aevent_etime;
 u32 sysctl_aevent_rseqth;
 int sysctl_larval_drop;
 u32 sysctl_acq_expires;

 u8 policy_default[XFRM_POLICY_MAX];


 struct ctl_table_header *sysctl_hdr;


 struct dst_ops xfrm4_dst_ops;

 struct dst_ops xfrm6_dst_ops;

 spinlock_t xfrm_state_lock;
 seqcount_spinlock_t xfrm_state_hash_generation;
 seqcount_spinlock_t xfrm_policy_hash_generation;

 spinlock_t xfrm_policy_lock;
 struct mutex xfrm_cfg_mutex;
 struct delayed_work nat_keepalive_work;
};
struct mpls_route;
struct ctl_table_header;
struct netns_mpls {
 int ip_ttl_propagate;
 int default_ttl;
 size_t platform_labels;
 struct mpls_route * *platform_label;

 struct ctl_table_header *ctl;
};
struct can_dev_rcv_lists;
struct can_pkg_stats;
struct can_rcv_lists_stats;
struct netns_can {

 struct proc_dir_entry *proc_dir;
 struct proc_dir_entry *pde_stats;
 struct proc_dir_entry *pde_reset_stats;
 struct proc_dir_entry *pde_rcvlist_all;
 struct proc_dir_entry *pde_rcvlist_fil;
 struct proc_dir_entry *pde_rcvlist_inv;
 struct proc_dir_entry *pde_rcvlist_sff;
 struct proc_dir_entry *pde_rcvlist_eff;
 struct proc_dir_entry *pde_rcvlist_err;
 struct proc_dir_entry *bcmproc_dir;



 struct can_dev_rcv_lists *rx_alldev_list;
 spinlock_t rcvlists_lock;
 struct timer_list stattimer;
 struct can_pkg_stats *pkg_stats;
 struct can_rcv_lists_stats *rcv_lists_stats;


 struct hlist_head cgw_list;
};
struct netns_xdp {
 struct mutex lock;
 struct hlist_head list;
};
struct smc_stats_rsn;
struct smc_stats;
struct netns_smc {

 struct smc_stats *smc_stats;

 struct mutex mutex_fback_rsn;
 struct smc_stats_rsn *fback_rsn;

 bool limit_smc_hs;

 struct ctl_table_header *smc_hdr;

 unsigned int sysctl_autocorking_size;
 unsigned int sysctl_smcr_buf_type;
 int sysctl_smcr_testlink_time;
 int sysctl_wmem;
 int sysctl_rmem;
 int sysctl_max_links_per_lgr;
 int sysctl_max_conns_per_lgr;
};
struct bpf_prog;
struct bpf_prog_array;
enum netns_bpf_attach_type {
 NETNS_BPF_INVALID = -1,
 NETNS_BPF_FLOW_DISSECTOR = 0,
 NETNS_BPF_SK_LOOKUP,
 MAX_NETNS_BPF_ATTACH_TYPE
};
struct netns_bpf {

 struct bpf_prog_array *run_array[MAX_NETNS_BPF_ATTACH_TYPE];
 struct bpf_prog *progs[MAX_NETNS_BPF_ATTACH_TYPE];
 struct list_head links[MAX_NETNS_BPF_ATTACH_TYPE];
};
struct netns_mctp {

 struct list_head routes;







 struct mutex bind_lock;
 struct hlist_head binds[1 << (7)];




 spinlock_t keys_lock;
 struct hlist_head keys;


 unsigned int default_net;


 struct mutex neigh_lock;
 struct list_head neighbours;
};
struct ref_tracker;
struct ref_tracker_dir {

 spinlock_t lock;
 unsigned int quarantine_avail;
 refcount_t untracked;
 refcount_t no_tracker;
 bool dead;
 struct list_head list;
 struct list_head quarantine;
 const char *class;

};
typedef struct ref_tracker *netdevice_tracker;
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct user_namespace;
struct proc_dir_entry;
struct net_device;
struct sock;
struct ctl_table_header;
struct net_generic;
struct uevent_sock;
struct netns_ipvs;
struct bpf_prog;
struct net {



 refcount_t passive;


 spinlock_t rules_mod_lock;

 unsigned int dev_base_seq;
 u32 ifindex;

 spinlock_t nsid_lock;
 atomic_t fnhe_genid;

 struct list_head list;
 struct list_head exit_list;





 struct llist_node defer_free_list;
 struct llist_node cleanup_list;

 struct list_head ptype_all;
 struct list_head ptype_specific;


 struct key_tag *key_domain;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct idr netns_ids;

 struct ns_common ns;
 struct ref_tracker_dir refcnt_tracker;
 struct ref_tracker_dir notrefcnt_tracker;


 struct list_head dev_base_head;
 struct proc_dir_entry *proc_net;
 struct proc_dir_entry *proc_net_stat;


 struct ctl_table_set sysctls;


 struct sock *rtnl;
 struct sock *genl_sock;

 struct uevent_sock *uevent_sock;

 struct hlist_head *dev_name_head;
 struct hlist_head *dev_index_head;
 struct xarray dev_by_index;
 struct raw_notifier_head netdev_chain;




 u32 hash_mix;

 struct net_device *loopback_dev;


 struct list_head rules_ops;

 struct netns_core core;
 struct netns_mib mib;
 struct netns_packet packet;

 struct netns_unix unx;

 struct netns_nexthop nexthop;
 struct netns_ipv4 ipv4;

 struct netns_ipv6 ipv6;


 struct netns_ieee802154_lowpan ieee802154_lowpan;


 struct netns_sctp sctp;


 struct netns_nf nf;

 struct netns_ct ct;


 struct netns_nftables nft;


 struct netns_ft ft;



 struct sk_buff_head wext_nlevents;

 struct net_generic *gen;


 struct netns_bpf bpf;



 struct netns_xfrm xfrm;


 u64 net_cookie;


 struct netns_ipvs *ipvs;


 struct netns_mpls mpls;


 struct netns_can can;


 struct netns_xdp xdp;


 struct netns_mctp mctp;


 struct sock *crypto_nlsk;

 struct sock *diag_nlsk;

 struct netns_smc smc;



 struct mutex rtnl_mutex;

} ;
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct net;
typedef struct {

 struct net *net;

} possible_net_t;
struct ctl_table;
static inline    int fnhe_genid(const struct net *net)
;
struct ieee_ets {
 __u8 willing;
 __u8 ets_cap;
 __u8 cbs;
 __u8 tc_tx_bw[8];
 __u8 tc_rx_bw[8];
 __u8 tc_tsa[8];
 __u8 prio_tc[8];
 __u8 tc_reco_bw[8];
 __u8 tc_reco_tsa[8];
 __u8 reco_prio_tc[8];
};
struct ieee_maxrate {
 __u64 tc_maxrate[8];
};
struct ieee_qcn {
 __u8 rpg_enable[8];
 __u32 rppp_max_rps[8];
 __u32 rpg_time_reset[8];
 __u32 rpg_byte_reset[8];
 __u32 rpg_threshold[8];
 __u32 rpg_max_rate[8];
 __u32 rpg_ai_rate[8];
 __u32 rpg_hai_rate[8];
 __u32 rpg_gd[8];
 __u32 rpg_min_dec_fac[8];
 __u32 rpg_min_rate[8];
 __u32 cndd_state_machine[8];
};
struct ieee_qcn_stats {
 __u64 rppp_rp_centiseconds[8];
 __u32 rppp_created_rps[8];
};
struct ieee_pfc {
 __u8 pfc_cap;
 __u8 pfc_en;
 __u8 mbc;
 __u16 delay;
 __u64 requests[8];
 __u64 indications[8];
};
struct dcbnl_buffer {

 __u8 prio2buffer[8];

 __u32 buffer_size[8];
 __u32 total_size;
};
struct cee_pg {
 __u8 willing;
 __u8 error;
 __u8 pg_en;
 __u8 tcs_supported;
 __u8 pg_bw[8];
 __u8 prio_pg[8];
};
struct cee_pfc {
 __u8 willing;
 __u8 error;
 __u8 pfc_en;
 __u8 tcs_supported;
};
struct dcb_app {
 __u8 selector;
 __u8 priority;
 __u16 protocol;
};
struct dcb_peer_app_info {
 __u8 willing;
 __u8 error;
};
struct net_device;
struct dcbnl_rtnl_ops {

 int (*ieee_getets) (struct net_device *, struct ieee_ets *);
 int (*ieee_setets) (struct net_device *, struct ieee_ets *);
 int (*ieee_getmaxrate) (struct net_device *, struct ieee_maxrate *);
 int (*ieee_setmaxrate) (struct net_device *, struct ieee_maxrate *);
 int (*ieee_getqcn) (struct net_device *, struct ieee_qcn *);
 int (*ieee_setqcn) (struct net_device *, struct ieee_qcn *);
 int (*ieee_getqcnstats) (struct net_device *, struct ieee_qcn_stats *);
 int (*ieee_getpfc) (struct net_device *, struct ieee_pfc *);
 int (*ieee_setpfc) (struct net_device *, struct ieee_pfc *);
 int (*ieee_getapp) (struct net_device *, struct dcb_app *);
 int (*ieee_setapp) (struct net_device *, struct dcb_app *);
 int (*ieee_delapp) (struct net_device *, struct dcb_app *);
 int (*ieee_peer_getets) (struct net_device *, struct ieee_ets *);
 int (*ieee_peer_getpfc) (struct net_device *, struct ieee_pfc *);


 u8 (*getstate)(struct net_device *);
 u8 (*setstate)(struct net_device *, u8);
 void (*getpermhwaddr)(struct net_device *, u8 *);
 void (*setpgtccfgtx)(struct net_device *, int, u8, u8, u8, u8);
 void (*setpgbwgcfgtx)(struct net_device *, int, u8);
 void (*setpgtccfgrx)(struct net_device *, int, u8, u8, u8, u8);
 void (*setpgbwgcfgrx)(struct net_device *, int, u8);
 void (*getpgtccfgtx)(struct net_device *, int, u8 *, u8 *, u8 *, u8 *);
 void (*getpgbwgcfgtx)(struct net_device *, int, u8 *);
 void (*getpgtccfgrx)(struct net_device *, int, u8 *, u8 *, u8 *, u8 *);
 void (*getpgbwgcfgrx)(struct net_device *, int, u8 *);
 void (*setpfccfg)(struct net_device *, int, u8);
 void (*getpfccfg)(struct net_device *, int, u8 *);
 u8 (*setall)(struct net_device *);
 u8 (*getcap)(struct net_device *, int, u8 *);
 int (*getnumtcs)(struct net_device *, int, u8 *);
 int (*setnumtcs)(struct net_device *, int, u8);
 u8 (*getpfcstate)(struct net_device *);
 void (*setpfcstate)(struct net_device *, u8);
 void (*getbcncfg)(struct net_device *, int, u32 *);
 void (*setbcncfg)(struct net_device *, int, u32);
 void (*getbcnrp)(struct net_device *, int, u8 *);
 void (*setbcnrp)(struct net_device *, int, u8);
 int (*setapp)(struct net_device *, u8, u16, u8);
 int (*getapp)(struct net_device *, u8, u16);
 u8 (*getfeatcfg)(struct net_device *, int, u8 *);
 u8 (*setfeatcfg)(struct net_device *, int, u8);


 u8 (*getdcbx)(struct net_device *);
 u8 (*setdcbx)(struct net_device *, u8);


 int (*peer_getappinfo)(struct net_device *, struct dcb_peer_app_info *,
          u16 *);
 int (*peer_getapptable)(struct net_device *, struct dcb_app *);


 int (*cee_peer_getpg) (struct net_device *, struct cee_pg *);
 int (*cee_peer_getpfc) (struct net_device *, struct cee_pfc *);


 int (*dcbnl_getbuffer)(struct net_device *, struct dcbnl_buffer *);
 int (*dcbnl_setbuffer)(struct net_device *, struct dcbnl_buffer *);


 int (*dcbnl_setapptrust)(struct net_device *, u8 *, int);
 int (*dcbnl_getapptrust)(struct net_device *, u8 *, int *);


 int (*dcbnl_setrewr)(struct net_device *dev, struct dcb_app *app);
 int (*dcbnl_delrewr)(struct net_device *dev, struct dcb_app *app);
};
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
extern char _data[], _sdata[], _edata[];
struct device;
struct irq_affinity_notify {
 unsigned int irq;
 struct kref kref;
 struct work_struct work;
 void (*notify)(struct irq_affinity_notify *, const cpumask_t *mask);
 void (*release)(struct kref *ref);
};
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
static inline    u64 cgroup_id(const struct cgroup *cgrp)
;
void css_rstat_flush(struct cgroup_subsys_state *css);
struct netprio_map {
 struct callback_head rcu;
 u32 priomap_len;
 u32 priomap[1];
};
typedef struct {
 union {
  void *kernel;
  void *user;
 };
 bool is_kernel : 1;
} sockptr_t;
typedef enum {
 SS_FREE = 0,
 SS_UNCONNECTED,
 SS_CONNECTING,
 SS_CONNECTED,
 SS_DISCONNECTING
} socket_state;
struct poll_table_struct;
struct pipe_inode_info;
struct inode;
struct file;
struct net;
struct socket_wq {

 wait_queue_head_t wait;
 struct fasync_struct *fasync_list;
 unsigned long flags;
 struct callback_head rcu;
} ;
struct socket {
 socket_state state;

 short type;

 unsigned long flags;

 struct file *file;
 struct sock *sk;
 const struct proto_ops *ops;

 struct socket_wq wq;
};
typedef struct {
 size_t written;
 size_t count;
 union {
  char *buf;
  void *data;
 } arg;
 int error;
} read_descriptor_t;
struct vm_area_struct;
struct page;
struct sockaddr;
struct msghdr;
struct module;
struct sk_buff;
struct proto_accept_arg;
typedef int (*sk_read_actor_t)(read_descriptor_t *, struct sk_buff *,
          unsigned int, size_t);
typedef int (*skb_read_actor_t)(struct sock *, struct sk_buff *);
struct proto_ops {
 int family;
 struct module *owner;
 int (*release) (struct socket *sock);
 int (*bind) (struct socket *sock,
          struct sockaddr_unsized *myaddr,
          int sockaddr_len);
 int (*connect) (struct socket *sock,
          struct sockaddr *vaddr,
          int sockaddr_len, int flags);
 int (*socketpair)(struct socket *sock1,
          struct socket *sock2);
 int (*accept) (struct socket *sock,
          struct socket *newsock,
          struct proto_accept_arg *arg);
 int (*getname) (struct socket *sock,
          struct sockaddr *addr,
          int peer);
 __poll_t (*poll) (struct file *file, struct socket *sock,
          struct poll_table_struct *wait);
 int (*ioctl) (struct socket *sock, unsigned int cmd,
          unsigned long arg);

 int (*compat_ioctl) (struct socket *sock, unsigned int cmd,
          unsigned long arg);

 int (*gettstamp) (struct socket *sock, void *userstamp,
          bool timeval, bool time32);
 int (*listen) (struct socket *sock, int len);
 int (*shutdown) (struct socket *sock, int flags);
 int (*setsockopt)(struct socket *sock, int level,
          int optname, sockptr_t optval,
          unsigned int optlen);
 int (*getsockopt)(struct socket *sock, int level,
          int optname, char *optval, int *optlen);
 void (*show_fdinfo)(struct seq_file *m, struct socket *sock);
 int (*sendmsg) (struct socket *sock, struct msghdr *m,
          size_t total_len);
 int (*recvmsg) (struct socket *sock, struct msghdr *m,
          size_t total_len, int flags);
 int (*mmap) (struct file *file, struct socket *sock,
          struct vm_area_struct * vma);
 ssize_t (*splice_read)(struct socket *sock, loff_t *ppos,
           struct pipe_inode_info *pipe, size_t len, unsigned int flags);
 void (*splice_eof)(struct socket *sock);
 int (*set_peek_off)(struct sock *sk, int val);
 int (*peek_len)(struct socket *sock);




 int (*read_sock)(struct sock *sk, read_descriptor_t *desc,
         sk_read_actor_t recv_actor);

 int (*read_skb)(struct sock *sk, skb_read_actor_t recv_actor);
 int (*sendmsg_locked)(struct sock *sk, struct msghdr *msg,
       size_t size);
 int (*set_rcvlowat)(struct sock *sk, int val);
};
struct iovec;
struct kvec;
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct fd {
 unsigned long word;
};
struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};
enum bpf_cgroup_iter_order {
 BPF_CGROUP_ITER_ORDER_UNSPEC = 0,
 BPF_CGROUP_ITER_SELF_ONLY,
 BPF_CGROUP_ITER_DESCENDANTS_PRE,
 BPF_CGROUP_ITER_DESCENDANTS_POST,
 BPF_CGROUP_ITER_ANCESTORS_UP,
};
enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 __MAX_BPF_MAP_TYPE
};
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};
enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 __MAX_BPF_ATTACH_TYPE
};
enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};
union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64  excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64  key;
  union {
   __u64  value;
   __u64  next_key;
  };
  __u64 flags;
 };

 struct {
  __u64  in_batch;


  __u64  out_batch;
  __u64  keys;
  __u64  values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64  insns;
  __u64  license;
  __u32 log_level;
  __u32 log_size;
  __u64  log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64  func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64  line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64  fd_array;
  __u64  core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
  __u32 fd_array_cnt;



  __u64  signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64  pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64  data_in;
  __u64  data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64  ctx_in;
  __u64  ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64  info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64  prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64  prog_attach_flags;
  __u64  link_ids;
  __u64  link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64  cookie;
 } raw_tracepoint;

 struct {
  __u64  btf;
  __u64  btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64  buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64  iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64  syms;
    __u64  addrs;
    __u64  cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64  path;
    __u64  offsets;
    __u64  ref_ctr_offsets;
    __u64  cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64  stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

} ;
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};
struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64  tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64  target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64  addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64  cookies;
  } kprobe_multi;
  struct {
   __u64  path;
   __u64  offsets;
   __u64  ref_ctr_offsets;
   __u64  cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64  file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64  func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64  tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} ;
struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};
struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};
struct sock_filter {
 __u16 code;
 __u8 jt;
 __u8 jf;
 __u32 k;
};
struct cred;
struct module;
static inline    int is_kernel(unsigned long addr)
;
struct btf_type {
 __u32 name_off;
 __u32 info;







 union {
  __u32 size;
  __u32 type;
 };
};
struct btf_member {
 __u32 name_off;
 __u32 type;






 __u32 offset;
};
struct btf;
struct btf_member;
struct btf_type;
union bpf_attr;
struct bpf_prog;
struct bpf_verifier_log;
struct bpf_struct_ops;
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct qspinlock;
struct bpf_verifier_env;
struct bpf_verifier_log;
struct perf_event;
struct bpf_prog;
struct bpf_prog_aux;
struct bpf_map;
struct bpf_arena;
struct sock;
struct seq_file;
struct btf;
struct btf_type;
struct exception_table_entry;
struct seq_operations;
struct bpf_iter_aux_info;
struct bpf_local_storage;
struct bpf_local_storage_map;
struct kobject;
struct mem_cgroup;
struct module;
struct bpf_func_state;
struct ftrace_ops;
struct cgroup;
struct bpf_token;
struct user_namespace;
struct super_block;
struct inode;
typedef u64 (*bpf_callback_t)(u64, u64, u64, u64, u64);
typedef int (*bpf_iter_init_seq_priv_t)(void *private_data,
     struct bpf_iter_aux_info *aux);
typedef void (*bpf_iter_fini_seq_priv_t)(void *private_data);
struct bpf_iter_seq_info {
 const struct seq_operations *seq_ops;
 bpf_iter_init_seq_priv_t init_seq_private;
 bpf_iter_fini_seq_priv_t fini_seq_private;
 u32 seq_priv_size;
};
struct bpf_map_ops {

 int (*map_alloc_check)(union bpf_attr *attr);
 struct bpf_map *(*map_alloc)(union bpf_attr *attr);
 void (*map_release)(struct bpf_map *map, struct file *map_file);
 void (*map_free)(struct bpf_map *map);
 int (*map_get_next_key)(struct bpf_map *map, void *key, void *next_key);
 void (*map_release_uref)(struct bpf_map *map);
 void *(*map_lookup_elem_sys_only)(struct bpf_map *map, void *key);
 int (*map_lookup_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_lookup_and_delete_elem)(struct bpf_map *map, void *key,
       void *value, u64 flags);
 int (*map_lookup_and_delete_batch)(struct bpf_map *map,
        const union bpf_attr *attr,
        union bpf_attr *uattr);
 int (*map_update_batch)(struct bpf_map *map, struct file *map_file,
    const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_delete_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);


 void *(*map_lookup_elem)(struct bpf_map *map, void *key);
 long (*map_update_elem)(struct bpf_map *map, void *key, void *value, u64 flags);
 long (*map_delete_elem)(struct bpf_map *map, void *key);
 long (*map_push_elem)(struct bpf_map *map, void *value, u64 flags);
 long (*map_pop_elem)(struct bpf_map *map, void *value);
 long (*map_peek_elem)(struct bpf_map *map, void *value);
 void *(*map_lookup_percpu_elem)(struct bpf_map *map, void *key, u32 cpu);
 int (*map_get_hash)(struct bpf_map *map, u32 hash_buf_size, void *hash_buf);


 void *(*map_fd_get_ptr)(struct bpf_map *map, struct file *map_file,
    int fd);




 void (*map_fd_put_ptr)(struct bpf_map *map, void *ptr, bool need_defer);
 int (*map_gen_lookup)(struct bpf_map *map, struct bpf_insn *insn_buf);
 u32 (*map_fd_sys_lookup_elem)(void *ptr);
 void (*map_seq_show_elem)(struct bpf_map *map, void *key,
      struct seq_file *m);
 int (*map_check_btf)(const struct bpf_map *map,
        const struct btf *btf,
        const struct btf_type *key_type,
        const struct btf_type *value_type);


 int (*map_poke_track)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_untrack)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_run)(struct bpf_map *map, u32 key, struct bpf_prog *old,
        struct bpf_prog *new);


 int (*map_direct_value_addr)(const struct bpf_map *map,
         u64 *imm, u32 off);
 int (*map_direct_value_meta)(const struct bpf_map *map,
         u64 imm, u32 *off);
 int (*map_mmap)(struct bpf_map *map, struct vm_area_struct *vma);
 __poll_t (*map_poll)(struct bpf_map *map, struct file *filp,
        struct poll_table_struct *pts);
 unsigned long (*map_get_unmapped_area)(struct file *filep, unsigned long addr,
            unsigned long len, unsigned long pgoff,
            unsigned long flags);


 int (*map_local_storage_charge)(struct bpf_local_storage_map *smap,
     void *owner, u32 size);
 void (*map_local_storage_uncharge)(struct bpf_local_storage_map *smap,
        void *owner, u32 size);
 struct bpf_local_storage ** (*map_owner_storage_ptr)(void *owner);


 long (*map_redirect)(struct bpf_map *map, u64 key, u64 flags);
 bool (*map_meta_equal)(const struct bpf_map *meta0,
          const struct bpf_map *meta1);


 int (*map_set_for_each_callback_args)(struct bpf_verifier_env *env,
           struct bpf_func_state *caller,
           struct bpf_func_state *callee);
 long (*map_for_each_callback)(struct bpf_map *map,
         bpf_callback_t callback_fn,
         void *callback_ctx, u64 flags);

 u64 (*map_mem_usage)(const struct bpf_map *map);


 int *map_btf_id;


 const struct bpf_iter_seq_info *iter_seq_info;
};
enum btf_field_type {
 BPF_SPIN_LOCK = (1 << 0),
 BPF_TIMER = (1 << 1),
 BPF_KPTR_UNREF = (1 << 2),
 BPF_KPTR_REF = (1 << 3),
 BPF_KPTR_PERCPU = (1 << 4),
 BPF_KPTR = BPF_KPTR_UNREF | BPF_KPTR_REF | BPF_KPTR_PERCPU,
 BPF_LIST_HEAD = (1 << 5),
 BPF_LIST_NODE = (1 << 6),
 BPF_RB_ROOT = (1 << 7),
 BPF_RB_NODE = (1 << 8),
 BPF_GRAPH_NODE = BPF_RB_NODE | BPF_LIST_NODE,
 BPF_GRAPH_ROOT = BPF_RB_ROOT | BPF_LIST_HEAD,
 BPF_REFCOUNT = (1 << 9),
 BPF_WORKQUEUE = (1 << 10),
 BPF_UPTR = (1 << 11),
 BPF_RES_SPIN_LOCK = (1 << 12),
 BPF_TASK_WORK = (1 << 13),
};
enum bpf_cgroup_storage_type {
 BPF_CGROUP_STORAGE_SHARED,
 BPF_CGROUP_STORAGE_PERCPU,
 __BPF_CGROUP_STORAGE_MAX
};
typedef void (*btf_dtor_kfunc_t)(void *);
struct btf_field_kptr {
 struct btf *btf;
 struct module *module;



 btf_dtor_kfunc_t dtor;
 u32 btf_id;
};
struct btf_field_graph_root {
 struct btf *btf;
 u32 value_btf_id;
 u32 node_offset;
 struct btf_record *value_rec;
};
struct btf_field {
 u32 offset;
 u32 size;
 enum btf_field_type type;
 union {
  struct btf_field_kptr kptr;
  struct btf_field_graph_root graph_root;
 };
};
struct btf_record {
 u32 cnt;
 u32 field_mask;
 int spin_lock_off;
 int res_spin_lock_off;
 int timer_off;
 int wq_off;
 int refcount_off;
 int task_work_off;
 struct btf_field fields[1];
};
struct bpf_map_owner {
 enum bpf_prog_type type;
 bool jited;
 bool xdp_has_frags;
 u64 storage_cookie[__BPF_CGROUP_STORAGE_MAX];
 const struct btf_type *attach_func_proto;
 enum bpf_attach_type expected_attach_type;
};
struct bpf_map {
 u8 sha[32];
 u32 excl;
 const struct bpf_map_ops *ops;
 struct bpf_map *inner_map_meta;

 void *security;

 enum bpf_map_type map_type;
 u32 key_size;
 u32 value_size;
 u32 max_entries;
 u64 map_extra;
 u32 map_flags;
 u32 id;
 struct btf_record *record;
 int numa_node;
 u32 btf_key_type_id;
 u32 btf_value_type_id;
 u32 btf_vmlinux_value_type_id;
 struct btf *btf;

 struct obj_cgroup *objcg;

 char name[16U];
 struct mutex freeze_mutex;
 atomic64_t refcnt;
 atomic64_t usercnt;

 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 atomic64_t writecnt;
 spinlock_t owner_lock;
 struct bpf_map_owner *owner;
 bool bypass_spec_v1;
 bool frozen;
 bool free_after_mult_rcu_gp;
 bool free_after_rcu_gp;
 atomic64_t sleepable_refcnt;
 s64 *elem_count;
 u64 cookie;
 char *excl_prog_sha;
};
struct bpf_offload_dev;
struct bpf_offloaded_map;
struct bpf_map_dev_ops {
 int (*map_get_next_key)(struct bpf_offloaded_map *map,
    void *key, void *next_key);
 int (*map_lookup_elem)(struct bpf_offloaded_map *map,
          void *key, void *value);
 int (*map_update_elem)(struct bpf_offloaded_map *map,
          void *key, void *value, u64 flags);
 int (*map_delete_elem)(struct bpf_offloaded_map *map, void *key);
};
struct bpf_offloaded_map {
 struct bpf_map map;
 struct net_device *netdev;
 const struct bpf_map_dev_ops *dev_ops;
 void *dev_priv;
 struct list_head offloads;
};
enum bpf_type_flag {

 PTR_MAYBE_NULL = ((((1UL))) << (0 + 8)),




 MEM_RDONLY = ((((1UL))) << (1 + 8)),


 MEM_RINGBUF = ((((1UL))) << (2 + 8)),


 MEM_USER = ((((1UL))) << (3 + 8)),







 MEM_PERCPU = ((((1UL))) << (4 + 8)),


 OBJ_RELEASE = ((((1UL))) << (5 + 8)),







 PTR_UNTRUSTED = ((((1UL))) << (6 + 8)),


 MEM_UNINIT = ((((1UL))) << (7 + 8)),


 DYNPTR_TYPE_LOCAL = ((((1UL))) << (8 + 8)),


 DYNPTR_TYPE_RINGBUF = ((((1UL))) << (9 + 8)),


 MEM_FIXED_SIZE = ((((1UL))) << (10 + 8)),




 MEM_ALLOC = ((((1UL))) << (11 + 8)),
 PTR_TRUSTED = ((((1UL))) << (12 + 8)),


 MEM_RCU = ((((1UL))) << (13 + 8)),





 NON_OWN_REF = ((((1UL))) << (14 + 8)),


 DYNPTR_TYPE_SKB = ((((1UL))) << (15 + 8)),


 DYNPTR_TYPE_XDP = ((((1UL))) << (16 + 8)),




 MEM_ALIGNED = ((((1UL))) << (17 + 8)),






 MEM_WRITE = ((((1UL))) << (18 + 8)),


 DYNPTR_TYPE_SKB_META = ((((1UL))) << (19 + 8)),

 __BPF_TYPE_FLAG_MAX,
 __BPF_TYPE_LAST_FLAG = __BPF_TYPE_FLAG_MAX - 1,
};
enum bpf_arg_type {
 ARG_DONTCARE = 0,




 ARG_CONST_MAP_PTR,
 ARG_PTR_TO_MAP_KEY,
 ARG_PTR_TO_MAP_VALUE,




 ARG_PTR_TO_MEM,
 ARG_PTR_TO_ARENA,

 ARG_CONST_SIZE,
 ARG_CONST_SIZE_OR_ZERO,

 ARG_PTR_TO_CTX,
 ARG_ANYTHING,
 ARG_SCALAR,
 ARG_PTR_TO_SPIN_LOCK,
 ARG_PTR_TO_SOCK_COMMON,
 ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_BTF_ID,
 ARG_PTR_TO_RINGBUF_MEM,
 ARG_CONST_ALLOC_SIZE_OR_ZERO,
 ARG_PTR_TO_BTF_ID_SOCK_COMMON,
 ARG_PTR_TO_PERCPU_BTF_ID,
 ARG_PTR_TO_FUNC,
 ARG_PTR_TO_STACK,
 ARG_PTR_TO_CONST_STR,
 ARG_PTR_TO_TIMER,
 ARG_KPTR_XCHG_DEST,
 ARG_PTR_TO_DYNPTR,
 __BPF_ARG_TYPE_MAX,


 ARG_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MAP_VALUE,
 ARG_PTR_TO_MEM_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MEM,
 ARG_PTR_TO_CTX_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_CTX,
 ARG_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_STACK_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_STACK,
 ARG_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_BTF_ID,



 ARG_PTR_TO_UNINIT_MEM = MEM_UNINIT | MEM_WRITE | ARG_PTR_TO_MEM,

 ARG_PTR_TO_FIXED_SIZE_MEM = MEM_FIXED_SIZE | ARG_PTR_TO_MEM,




 __BPF_ARG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
_Static_assert(__BPF_ARG_TYPE_MAX <= (1UL << 8), "__BPF_ARG_TYPE_MAX <= BPF_BASE_TYPE_LIMIT");
enum bpf_return_type {
 RET_INTEGER,
 RET_VOID,
 RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_MEM,
 RET_PTR_TO_MEM_OR_BTF_ID,
 RET_PTR_TO_BTF_ID,
 __BPF_RET_TYPE_MAX,


 RET_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_RINGBUF_MEM_OR_NULL = PTR_MAYBE_NULL | MEM_RINGBUF | RET_PTR_TO_MEM,
 RET_PTR_TO_DYNPTR_MEM_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MEM,
 RET_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_BTF_ID,
 RET_PTR_TO_BTF_ID_TRUSTED = PTR_TRUSTED | RET_PTR_TO_BTF_ID,




 __BPF_RET_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
_Static_assert(__BPF_RET_TYPE_MAX <= (1UL << 8), "__BPF_RET_TYPE_MAX <= BPF_BASE_TYPE_LIMIT");
struct bpf_func_proto {
 u64 (*func)(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5);
 bool gpl_only;
 bool pkt_access;
 bool might_sleep;





 bool allow_fastcall;
 enum bpf_return_type ret_type;
 union {
  struct {
   enum bpf_arg_type arg1_type;
   enum bpf_arg_type arg2_type;
   enum bpf_arg_type arg3_type;
   enum bpf_arg_type arg4_type;
   enum bpf_arg_type arg5_type;
  };
  enum bpf_arg_type arg_type[5];
 };
 union {
  struct {
   u32 *arg1_btf_id;
   u32 *arg2_btf_id;
   u32 *arg3_btf_id;
   u32 *arg4_btf_id;
   u32 *arg5_btf_id;
  };
  u32 *arg_btf_id[5];
  struct {
   size_t arg1_size;
   size_t arg2_size;
   size_t arg3_size;
   size_t arg4_size;
   size_t arg5_size;
  };
  size_t arg_size[5];
 };
 int *ret_btf_id;
 bool (*allowed)(const struct bpf_prog *prog);
};
enum bpf_access_type {
 BPF_READ = 1,
 BPF_WRITE = 2
};
enum bpf_reg_type {
 NOT_INIT = 0,
 SCALAR_VALUE,
 PTR_TO_CTX,
 CONST_PTR_TO_MAP,
 PTR_TO_MAP_VALUE,
 PTR_TO_MAP_KEY,
 PTR_TO_STACK,
 PTR_TO_PACKET_META,
 PTR_TO_PACKET,
 PTR_TO_PACKET_END,
 PTR_TO_FLOW_KEYS,
 PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK,
 PTR_TO_TP_BUFFER,
 PTR_TO_XDP_SOCK,
 PTR_TO_BTF_ID,
 PTR_TO_MEM,
 PTR_TO_ARENA,
 PTR_TO_BUF,
 PTR_TO_FUNC,
 CONST_PTR_TO_DYNPTR,
 __BPF_REG_TYPE_MAX,


 PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | PTR_TO_MAP_VALUE,
 PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | PTR_TO_TCP_SOCK,




 PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | PTR_TO_BTF_ID,




 __BPF_REG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
_Static_assert(__BPF_REG_TYPE_MAX <= (1UL << 8), "__BPF_REG_TYPE_MAX <= BPF_BASE_TYPE_LIMIT");
struct bpf_insn_access_aux {
 enum bpf_reg_type reg_type;
 bool is_ldsx;
 union {
  int ctx_field_size;
  struct {
   struct btf *btf;
   u32 btf_id;
   u32 ref_obj_id;
  };
 };
 struct bpf_verifier_log *log;
 bool is_retval;
};
struct bpf_prog_ops {
 int (*test_run)(struct bpf_prog *prog, const union bpf_attr *kattr,
   union bpf_attr *uattr);
};
struct bpf_reg_state;
struct bpf_verifier_ops {

 const struct bpf_func_proto *
 (*get_func_proto)(enum bpf_func_id func_id,
     const struct bpf_prog *prog);




 bool (*is_valid_access)(int off, int size, enum bpf_access_type type,
    const struct bpf_prog *prog,
    struct bpf_insn_access_aux *info);
 int (*gen_prologue)(struct bpf_insn *insn, bool direct_write,
       const struct bpf_prog *prog);
 int (*gen_epilogue)(struct bpf_insn *insn, const struct bpf_prog *prog,
       s16 ctx_stack_off);
 int (*gen_ld_abs)(const struct bpf_insn *orig,
     struct bpf_insn *insn_buf);
 u32 (*convert_ctx_access)(enum bpf_access_type type,
      const struct bpf_insn *src,
      struct bpf_insn *dst,
      struct bpf_prog *prog, u32 *target_size);
 int (*btf_struct_access)(struct bpf_verifier_log *log,
     const struct bpf_reg_state *reg,
     int off, int size);
};
struct bpf_prog_offload {
 struct bpf_prog *prog;
 struct net_device *netdev;
 struct bpf_offload_dev *offdev;
 void *dev_priv;
 struct list_head offloads;
 bool dev_state;
 bool opt_failed;
 void *jited_image;
 u32 jited_len;
};
struct btf_func_model {
 u8 ret_size;
 u8 ret_flags;
 u8 nr_args;
 u8 arg_size[12];
 u8 arg_flags[12];
};
struct bpf_tramp_image;
struct bpf_ksym {
 unsigned long start;
 unsigned long end;
 char name[512];
 struct list_head lnode;
 struct latch_tree_node tnode;
 bool prog;
};
enum bpf_tramp_prog_type {
 BPF_TRAMP_FENTRY,
 BPF_TRAMP_FEXIT,
 BPF_TRAMP_MODIFY_RETURN,
 BPF_TRAMP_MAX,
 BPF_TRAMP_REPLACE,
};
struct bpf_tramp_image {
 void *image;
 int size;
 struct bpf_ksym ksym;
 struct percpu_ref pcref;
 void *ip_after_call;
 void *ip_epilogue;
 union {
  struct callback_head rcu;
  struct work_struct work;
 };
};
struct bpf_trampoline {

 struct hlist_node hlist;
 struct ftrace_ops *fops;

 struct mutex mutex;
 refcount_t refcnt;
 u32 flags;
 u64 key;
 struct {
  struct btf_func_model model;
  void *addr;
  bool ftrace_managed;
 } func;




 struct bpf_prog *extension_prog;

 struct hlist_head progs_hlist[BPF_TRAMP_MAX];

 int progs_cnt[BPF_TRAMP_MAX];

 struct bpf_tramp_image *cur_image;
};
struct bpf_func_info_aux {
 u16 linkage;
 bool unreliable;
 bool called : 1;
 bool verified : 1;
};
struct bpf_jit_poke_descriptor {
 void *tailcall_target;
 void *tailcall_bypass;
 void *bypass_addr;
 void *aux;
 union {
  struct {
   struct bpf_map *map;
   u32 key;
  } tail_call;
 };
 bool tailcall_target_stable;
 u8 adj_off;
 u16 reason;
 u32 insn_idx;
};
struct bpf_ctx_arg_aux {
 u32 offset;
 enum bpf_reg_type reg_type;
 struct btf *btf;
 u32 btf_id;
 u32 ref_obj_id;
 bool refcounted;
};
struct btf_mod_pair {
 struct btf *btf;
 struct module *module;
};
struct bpf_kfunc_desc_tab;
struct bpf_stream {
 atomic_t capacity;
 struct llist_head log;

 struct mutex lock;
 struct llist_node *backlog_head;
 struct llist_node *backlog_tail;
};
struct bpf_prog_aux {
 atomic64_t refcnt;
 u32 used_map_cnt;
 u32 used_btf_cnt;
 u32 max_ctx_offset;
 u32 max_pkt_offset;
 u32 max_tp_access;
 u32 stack_depth;
 u32 id;
 u32 func_cnt;
 u32 real_func_cnt;
 u32 func_idx;
 u32 attach_btf_id;
 u32 attach_st_ops_member_off;
 u32 ctx_arg_info_size;
 u32 max_rdonly_access;
 u32 max_rdwr_access;
 struct btf *attach_btf;
 struct bpf_ctx_arg_aux *ctx_arg_info;
 void *priv_stack_ptr;
 struct mutex dst_mutex;
 struct bpf_prog *dst_prog;
 struct bpf_trampoline *dst_trampoline;
 enum bpf_prog_type saved_dst_prog_type;
 enum bpf_attach_type saved_dst_attach_type;
 bool verifier_zext;
 bool dev_bound;
 bool offload_requested;
 bool attach_btf_trace;
 bool attach_tracing_prog;
 bool func_proto_unreliable;
 bool tail_call_reachable;
 bool xdp_has_frags;
 bool exception_cb;
 bool exception_boundary;
 bool is_extended;
 bool jits_use_priv_stack;
 bool priv_stack_requested;
 bool changes_pkt_data;
 bool might_sleep;
 bool kprobe_write_ctx;
 u64 prog_array_member_cnt;
 struct mutex ext_mutex;
 struct bpf_arena *arena;
 void (*recursion_detected)(struct bpf_prog *prog);

 const struct btf_type *attach_func_proto;

 const char *attach_func_name;
 struct bpf_prog **func;
 struct bpf_prog_aux *main_prog_aux;
 void *jit_data;
 struct bpf_jit_poke_descriptor *poke_tab;
 struct bpf_kfunc_desc_tab *kfunc_tab;
 struct bpf_kfunc_btf_tab *kfunc_btf_tab;
 u32 size_poke_tab;



 struct bpf_ksym ksym;
 const struct bpf_prog_ops *ops;
 const struct bpf_struct_ops *st_ops;
 struct bpf_map **used_maps;
 struct mutex used_maps_mutex;
 struct btf_mod_pair *used_btfs;
 struct bpf_prog *prog;
 struct user_struct *user;
 u64 load_time;
 u32 verified_insns;
 int cgroup_atype;
 struct bpf_map *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
 char name[16U];
 u64 (*bpf_exception_cb)(u64 cookie, u64 sp, u64 bp, u64, u64);

 void *security;

 struct bpf_token *token;
 struct bpf_prog_offload *offload;
 struct btf *btf;
 struct bpf_func_info *func_info;
 struct bpf_func_info_aux *func_info_aux;






 struct bpf_line_info *linfo;







 void **jited_linfo;
 u32 func_info_cnt;
 u32 nr_linfo;




 u32 linfo_idx;
 struct module *mod;
 u32 num_exentries;
 struct exception_table_entry *extable;
 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 struct bpf_stream stream[2];
};
struct bpf_prog {
 u16 pages;
 u16 jited:1,
    jit_requested:1,
    gpl_compatible:1,
    cb_access:1,
    dst_needed:1,
    blinding_requested:1,
    blinded:1,
    is_func:1,
    kprobe_override:1,
    has_callchain_buf:1,
    enforce_expected_attach_type:1,
    call_get_stack:1,
    call_get_func_ip:1,
    tstamp_type_access:1,
    sleepable:1;
 enum bpf_prog_type type;
 enum bpf_attach_type expected_attach_type;
 u32 len;
 u32 jited_len;
 union {
  u8 digest[32];
  u8 tag[8];
 };
 struct bpf_prog_stats *stats;
 int *active;
 unsigned int (*bpf_func)(const void *ctx,
         const struct bpf_insn *insn);
 struct bpf_prog_aux *aux;
 struct sock_fprog_kern *orig_prog;

 union {
  struct { struct { } __empty_insns; struct sock_filter insns[1]; };
  struct { struct { } __empty_insnsi; struct bpf_insn insnsi[1]; };
 };
};
struct bpf_link {
 atomic64_t refcnt;
 u32 id;
 enum bpf_link_type type;
 const struct bpf_link_ops *ops;
 struct bpf_prog *prog;

 u32 flags;
 enum bpf_attach_type attach_type;




 union {
  struct callback_head rcu;
  struct work_struct work;
 };




 bool sleepable;
};
struct bpf_link_ops {
 void (*release)(struct bpf_link *link);



 void (*dealloc)(struct bpf_link *link);






 void (*dealloc_deferred)(struct bpf_link *link);
 int (*detach)(struct bpf_link *link);
 int (*update_prog)(struct bpf_link *link, struct bpf_prog *new_prog,
      struct bpf_prog *old_prog);
 void (*show_fdinfo)(const struct bpf_link *link, struct seq_file *seq);
 int (*fill_link_info)(const struct bpf_link *link,
         struct bpf_link_info *info);
 int (*update_map)(struct bpf_link *link, struct bpf_map *new_map,
     struct bpf_map *old_map);
 __poll_t (*poll)(struct file *file, struct poll_table_struct *pts);
};
struct bpf_token {
 struct work_struct work;
 atomic64_t refcnt;
 struct user_namespace *userns;
 u64 allowed_cmds;
 u64 allowed_maps;
 u64 allowed_progs;
 u64 allowed_attachs;

 void *security;

};
struct btf_member;
struct bpf_struct_ops {
 const struct bpf_verifier_ops *verifier_ops;
 int (*init)(struct btf *btf);
 int (*check_member)(const struct btf_type *t,
       const struct btf_member *member,
       const struct bpf_prog *prog);
 int (*init_member)(const struct btf_type *t,
      const struct btf_member *member,
      void *kdata, const void *udata);
 int (*reg)(void *kdata, struct bpf_link *link);
 void (*unreg)(void *kdata, struct bpf_link *link);
 int (*update)(void *kdata, void *old_kdata, struct bpf_link *link);
 int (*validate)(void *kdata);
 void *cfi_stubs;
 struct module *owner;
 const char *name;
 struct btf_func_model func_models[64];
};
struct bpf_prog_array_item {
 struct bpf_prog *prog;
 union {
  struct bpf_cgroup_storage *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
  u64 bpf_cookie;
 };
};
struct bpf_prog_array {
 struct callback_head rcu;
 struct bpf_prog_array_item items[1];
};
struct bpf_run_ctx {};
enum bpf_iter_task_type {
 BPF_TASK_ITER_ALL = 0,
 BPF_TASK_ITER_TID,
 BPF_TASK_ITER_TGID,
};
struct bpf_iter_aux_info {

 struct bpf_map *map;


 struct {
  struct cgroup *start;
  enum bpf_cgroup_iter_order order;
 } cgroup;
 struct {
  enum bpf_iter_task_type type;
  u32 pid;
 } task;
};
int map_set_for_each_callback_args(struct bpf_verifier_env *env,
       struct bpf_func_state *caller,
       struct bpf_func_state *callee);
struct xdp_frame;
struct sk_buff;
int btf_struct_access(struct bpf_verifier_log *log,
        const struct bpf_reg_state *reg,
        int off, int size, enum bpf_access_type atype,
        u32 *next_btf_id, enum bpf_type_flag *flag, const char **field_name);
struct bpf_reg_state;
struct key;
struct cred;
struct rlimit;
struct kernel_siginfo;
struct audit_context;
struct super_block;
struct inode;
struct dentry;
struct file;
struct vfsmount;
struct path;
struct qstr;
struct iattr;
struct fown_struct;
struct file_operations;
struct kernfs_node;
struct mm_struct;
struct fs_context;
struct ctl_table;
struct user_namespace;
struct msghdr;
struct sk_buff;
struct sock;
struct sockaddr;
struct socket;
struct dst_entry;
struct xfrm_policy;
struct xfrm_state;
struct seq_file;
union bpf_attr;
struct bpf_map;
struct bpf_prog;
struct bpf_token;
struct perf_event;
struct sock;
struct nlmsghdr {
 __u32 nlmsg_len;
 __u16 nlmsg_type;
 __u16 nlmsg_flags;
 __u32 nlmsg_seq;
 __u32 nlmsg_pid;
};
struct nlattr {
 __u16 nla_len;
 __u16 nla_type;
};
struct net;
struct netlink_ext_ack {
 const char *_msg;
 const struct nlattr *bad_attr;
 const struct nla_policy *policy;
 const struct nlattr *miss_nest;
 u16 miss_type;
 u8 cookie[8];
 u8 cookie_len;
 char _msg_buf[80];
};
struct netlink_callback {
 struct sk_buff *skb;
 const struct nlmsghdr *nlh;
 int (*dump)(struct sk_buff * skb,
     struct netlink_callback *cb);
 int (*done)(struct netlink_callback *cb);
 void *data;

 struct module *module;
 struct netlink_ext_ack *extack;
 u16 family;
 u16 answer_flags;
 u32 min_dump_alloc;
 unsigned int prev_seq, seq;
 int flags;
 bool strict_check;
 union {
  u8 ctx[48];




  long args[6];
 };
};
struct ndmsg {
 __u8 ndm_family;
 __u8 ndm_pad1;
 __u16 ndm_pad2;
 __s32 ndm_ifindex;
 __u16 ndm_state;
 __u8 ndm_flags;
 __u8 ndm_type;
};
struct rtnl_link_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
 __u64 collisions;


 __u64 rx_length_errors;
 __u64 rx_over_errors;
 __u64 rx_crc_errors;
 __u64 rx_frame_errors;
 __u64 rx_fifo_errors;
 __u64 rx_missed_errors;


 __u64 tx_aborted_errors;
 __u64 tx_carrier_errors;
 __u64 tx_fifo_errors;
 __u64 tx_heartbeat_errors;
 __u64 tx_window_errors;


 __u64 rx_compressed;
 __u64 tx_compressed;
 __u64 rx_nohandler;

 __u64 rx_otherhost_dropped;
};
struct rtnl_hw_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
};
struct ifla_vf_guid {
 __u32 vf;
 __u64 guid;
};
struct ifla_vf_stats {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 broadcast;
 __u64 multicast;
 __u64 rx_dropped;
 __u64 tx_dropped;
};
struct ifla_vf_info {
 __u32 vf;
 __u8 mac[32];
 __u32 vlan;
 __u32 qos;
 __u32 spoofchk;
 __u32 linkstate;
 __u32 min_tx_rate;
 __u32 max_tx_rate;
 __u32 rss_query_en;
 __u32 trusted;
 __be16 vlan_proto;
};
enum {
 NEIGH_ARP_TABLE = 0,
 NEIGH_ND_TABLE = 1,
 NEIGH_NR_TABLES,
 NEIGH_LINK_TABLE = NEIGH_NR_TABLES
};
struct netpoll_info;
struct device;
struct ethtool_ops;
struct kernel_hwtstamp_config;
struct phy_device;
struct dsa_port;
struct ip_tunnel_parm_kern;
struct macsec_ops;
struct netdev_config;
struct netdev_name_node;
struct sfp_bus;
struct wireless_dev;
struct wpan_dev;
struct mpls_dev;
struct udp_tunnel_nic_info;
struct udp_tunnel_nic;
struct bpf_prog;
struct xdp_buff;
struct xdp_frame;
struct xdp_metadata_ops;
struct ethtool_netdev_state;
struct phy_link_topology;
struct hwtstamp_provider;
typedef u32 xdp_features_t;
enum netdev_tx {
 __NETDEV_TX_MIN = (-((int)(~0U >> 1)) - 1),
 NETDEV_TX_OK = 0x00,
 NETDEV_TX_BUSY = 0x10,
};
typedef enum netdev_tx netdev_tx_t;
struct net_device_stats {
 union { unsigned long rx_packets; atomic_long_t __rx_packets; };
 union { unsigned long tx_packets; atomic_long_t __tx_packets; };
 union { unsigned long rx_bytes; atomic_long_t __rx_bytes; };
 union { unsigned long tx_bytes; atomic_long_t __tx_bytes; };
 union { unsigned long rx_errors; atomic_long_t __rx_errors; };
 union { unsigned long tx_errors; atomic_long_t __tx_errors; };
 union { unsigned long rx_dropped; atomic_long_t __rx_dropped; };
 union { unsigned long tx_dropped; atomic_long_t __tx_dropped; };
 union { unsigned long multicast; atomic_long_t __multicast; };
 union { unsigned long collisions; atomic_long_t __collisions; };
 union { unsigned long rx_length_errors; atomic_long_t __rx_length_errors; };
 union { unsigned long rx_over_errors; atomic_long_t __rx_over_errors; };
 union { unsigned long rx_crc_errors; atomic_long_t __rx_crc_errors; };
 union { unsigned long rx_frame_errors; atomic_long_t __rx_frame_errors; };
 union { unsigned long rx_fifo_errors; atomic_long_t __rx_fifo_errors; };
 union { unsigned long rx_missed_errors; atomic_long_t __rx_missed_errors; };
 union { unsigned long tx_aborted_errors; atomic_long_t __tx_aborted_errors; };
 union { unsigned long tx_carrier_errors; atomic_long_t __tx_carrier_errors; };
 union { unsigned long tx_fifo_errors; atomic_long_t __tx_fifo_errors; };
 union { unsigned long tx_heartbeat_errors; atomic_long_t __tx_heartbeat_errors; };
 union { unsigned long tx_window_errors; atomic_long_t __tx_window_errors; };
 union { unsigned long rx_compressed; atomic_long_t __rx_compressed; };
 union { unsigned long tx_compressed; atomic_long_t __tx_compressed; };
};
struct net_device_core_stats {
 unsigned long rx_dropped;
 unsigned long tx_dropped;
 unsigned long rx_nohandler;
 unsigned long rx_otherhost_dropped;
} ;
struct neighbour;
struct neigh_parms;
struct sk_buff;
struct netdev_hw_addr_list {
 struct list_head list;
 int count;


 struct rb_root tree;
};
struct hh_cache {
 unsigned int hh_len;
 seqlock_t hh_lock;




 unsigned long hh_data[(((128)+(16 -1))&~(16 - 1)) / sizeof(long)];
};
struct header_ops {
 int (*create) (struct sk_buff *skb, struct net_device *dev,
      unsigned short type, const void *daddr,
      const void *saddr, unsigned int len);
 int (*parse)(const struct sk_buff *skb,
    const struct net_device *dev,
    unsigned char *haddr);
 int (*cache)(const struct neighbour *neigh, struct hh_cache *hh, __be16 type);
 void (*cache_update)(struct hh_cache *hh,
    const struct net_device *dev,
    const unsigned char *haddr);
 bool (*validate)(const char *ll_header, unsigned int len);
 __be16 (*parse_protocol)(const struct sk_buff *skb);
};
struct gro_list {
 struct list_head list;
 int count;
};
struct gro_node {
 unsigned long bitmask;
 struct gro_list hash[8];
 struct list_head rx_list;
 u32 rx_count;
 u32 cached_napi_id;
};
struct napi_config {
 u64 gro_flush_timeout;
 u64 irq_suspend_timeout;
 u32 defer_hard_irqs;
 cpumask_t affinity_mask;
 u8 threaded;
 unsigned int napi_id;
};
struct napi_struct {






 struct list_head poll_list;

 unsigned long state;
 int weight;
 u32 defer_hard_irqs_count;
 int (*poll)(struct napi_struct *, int);


 int poll_owner;


 int list_owner;
 struct net_device *dev;
 struct sk_buff *skb;
 struct gro_node gro;
 struct hrtimer timer;

 struct task_struct *thread;
 unsigned long gro_flush_timeout;
 unsigned long irq_suspend_timeout;
 u32 defer_hard_irqs;

 u32 napi_id;
 struct list_head dev_list;
 struct hlist_node napi_hash_node;
 int irq;
 struct irq_affinity_notify notify;
 int napi_rmap_idx;
 int index;
 struct napi_config *config;
};
enum rx_handler_result {
 RX_HANDLER_CONSUMED,
 RX_HANDLER_ANOTHER,
 RX_HANDLER_EXACT,
 RX_HANDLER_PASS,
};
typedef enum rx_handler_result rx_handler_result_t;
typedef rx_handler_result_t rx_handler_func_t(struct sk_buff **pskb);
struct netdev_queue {



 struct net_device *dev;
 netdevice_tracker dev_tracker;

 struct Qdisc *qdisc;
 struct Qdisc *qdisc_sleeping;

 struct kobject kobj;
 const struct attribute_group **groups;

 unsigned long tx_maxrate;




 atomic_long_t trans_timeout;


 struct net_device *sb_dev;


 struct xsk_buff_pool *pool;






 struct dql dql;

 spinlock_t _xmit_lock ;
 int xmit_lock_owner;



 unsigned long trans_start;

 unsigned long state;







 struct napi_struct *napi;


 int numa_node;

} ;
enum xps_map_type {
 XPS_CPUS = 0,
 XPS_RXQS,
 XPS_MAPS_MAX,
};
struct xps_map {
 unsigned int len;
 unsigned int alloc_len;
 struct callback_head rcu;
 u16 queues[1];
};
struct xps_dev_maps {
 struct callback_head rcu;
 unsigned int nr_ids;
 s16 num_tc;
 struct xps_map *attr_map[1];
};
struct netdev_tc_txq {
 u16 count;
 u16 offset;
};
struct netdev_fcoe_hbainfo {
 char manufacturer[64];
 char serial_number[64];
 char hardware_version[64];
 char driver_version[64];
 char optionrom_version[64];
 char firmware_version[64];
 char model[256];
 char model_description[256];
};
struct netdev_phys_item_id {
 unsigned char id[32];
 unsigned char id_len;
};
enum net_device_path_type {
 DEV_PATH_ETHERNET = 0,
 DEV_PATH_VLAN,
 DEV_PATH_BRIDGE,
 DEV_PATH_PPPOE,
 DEV_PATH_DSA,
 DEV_PATH_MTK_WDMA,
};
struct net_device_path {
 enum net_device_path_type type;
 const struct net_device *dev;
 union {
  struct {
   u16 id;
   __be16 proto;
   u8 h_dest[6];
  } encap;
  struct {
   enum {
    DEV_PATH_BR_VLAN_KEEP,
    DEV_PATH_BR_VLAN_TAG,
    DEV_PATH_BR_VLAN_UNTAG,
    DEV_PATH_BR_VLAN_UNTAG_HW,
   } vlan_mode;
   u16 vlan_id;
   __be16 vlan_proto;
  } bridge;
  struct {
   int port;
   u16 proto;
  } dsa;
  struct {
   u8 wdma_idx;
   u8 queue;
   u16 wcid;
   u8 bss;
   u8 amsdu;
  } mtk_wdma;
 };
};
struct net_device_path_ctx {
 const struct net_device *dev;
 u8 daddr[6];

 int num_vlans;
 struct {
  u16 id;
  __be16 proto;
 } vlan[2];
};
enum tc_setup_type {
 TC_QUERY_CAPS,
 TC_SETUP_QDISC_MQPRIO,
 TC_SETUP_CLSU32,
 TC_SETUP_CLSFLOWER,
 TC_SETUP_CLSMATCHALL,
 TC_SETUP_CLSBPF,
 TC_SETUP_BLOCK,
 TC_SETUP_QDISC_CBS,
 TC_SETUP_QDISC_RED,
 TC_SETUP_QDISC_PRIO,
 TC_SETUP_QDISC_MQ,
 TC_SETUP_QDISC_ETF,
 TC_SETUP_ROOT_QDISC,
 TC_SETUP_QDISC_GRED,
 TC_SETUP_QDISC_TAPRIO,
 TC_SETUP_FT,
 TC_SETUP_QDISC_ETS,
 TC_SETUP_QDISC_TBF,
 TC_SETUP_QDISC_FIFO,
 TC_SETUP_QDISC_HTB,
 TC_SETUP_ACT,
};
enum bpf_netdev_command {







 XDP_SETUP_PROG,
 XDP_SETUP_PROG_HW,

 BPF_OFFLOAD_MAP_ALLOC,
 BPF_OFFLOAD_MAP_FREE,
 XDP_SETUP_XSK_POOL,
};
struct netlink_ext_ack;
struct xdp_dev_bulk_queue;
struct bpf_xdp_link;
enum bpf_xdp_mode {
 XDP_MODE_SKB = 0,
 XDP_MODE_DRV = 1,
 XDP_MODE_HW = 2,
 __MAX_XDP_MODE
};
struct bpf_xdp_entity {
 struct bpf_prog *prog;
 struct bpf_xdp_link *link;
};
struct netdev_bpf {
 enum bpf_netdev_command command;
 union {

  struct {
   u32 flags;
   struct bpf_prog *prog;
   struct netlink_ext_ack *extack;
  };

  struct {
   struct bpf_offloaded_map *offmap;
  };

  struct {
   struct xsk_buff_pool *pool;
   u16 queue_id;
  } xsk;
 };
};
struct xfrmdev_ops {
 int (*xdo_dev_state_add)(struct net_device *dev,
         struct xfrm_state *x,
         struct netlink_ext_ack *extack);
 void (*xdo_dev_state_delete)(struct net_device *dev,
     struct xfrm_state *x);
 void (*xdo_dev_state_free)(struct net_device *dev,
          struct xfrm_state *x);
 bool (*xdo_dev_offload_ok) (struct sk_buff *skb,
           struct xfrm_state *x);
 void (*xdo_dev_state_advance_esn) (struct xfrm_state *x);
 void (*xdo_dev_state_update_stats) (struct xfrm_state *x);
 int (*xdo_dev_policy_add) (struct xfrm_policy *x, struct netlink_ext_ack *extack);
 void (*xdo_dev_policy_delete) (struct xfrm_policy *x);
 void (*xdo_dev_policy_free) (struct xfrm_policy *x);
};
struct dev_ifalias {
 struct callback_head rcuhead;
 char ifalias[1];
};
struct tlsdev_ops;
struct net_device_ops {
 int (*ndo_init)(struct net_device *dev);
 void (*ndo_uninit)(struct net_device *dev);
 int (*ndo_open)(struct net_device *dev);
 int (*ndo_stop)(struct net_device *dev);
 netdev_tx_t (*ndo_start_xmit)(struct sk_buff *skb,
        struct net_device *dev);
 netdev_features_t (*ndo_features_check)(struct sk_buff *skb,
            struct net_device *dev,
            netdev_features_t features);
 u16 (*ndo_select_queue)(struct net_device *dev,
          struct sk_buff *skb,
          struct net_device *sb_dev);
 void (*ndo_change_rx_flags)(struct net_device *dev,
             int flags);
 void (*ndo_set_rx_mode)(struct net_device *dev);
 int (*ndo_set_mac_address)(struct net_device *dev,
             void *addr);
 int (*ndo_validate_addr)(struct net_device *dev);
 int (*ndo_do_ioctl)(struct net_device *dev,
             struct ifreq *ifr, int cmd);
 int (*ndo_eth_ioctl)(struct net_device *dev,
       struct ifreq *ifr, int cmd);
 int (*ndo_siocbond)(struct net_device *dev,
      struct ifreq *ifr, int cmd);
 int (*ndo_siocwandev)(struct net_device *dev,
        struct if_settings *ifs);
 int (*ndo_siocdevprivate)(struct net_device *dev,
            struct ifreq *ifr,
            void *data, int cmd);
 int (*ndo_set_config)(struct net_device *dev,
               struct ifmap *map);
 int (*ndo_change_mtu)(struct net_device *dev,
        int new_mtu);
 int (*ndo_neigh_setup)(struct net_device *dev,
         struct neigh_parms *);
 void (*ndo_tx_timeout) (struct net_device *dev,
         unsigned int txqueue);

 void (*ndo_get_stats64)(struct net_device *dev,
         struct rtnl_link_stats64 *storage);
 bool (*ndo_has_offload_stats)(const struct net_device *dev, int attr_id);
 int (*ndo_get_offload_stats)(int attr_id,
        const struct net_device *dev,
        void *attr_data);
 struct net_device_stats* (*ndo_get_stats)(struct net_device *dev);

 int (*ndo_vlan_rx_add_vid)(struct net_device *dev,
             __be16 proto, u16 vid);
 int (*ndo_vlan_rx_kill_vid)(struct net_device *dev,
              __be16 proto, u16 vid);

 void (*ndo_poll_controller)(struct net_device *dev);
 int (*ndo_netpoll_setup)(struct net_device *dev);
 void (*ndo_netpoll_cleanup)(struct net_device *dev);

 int (*ndo_set_vf_mac)(struct net_device *dev,
        int queue, u8 *mac);
 int (*ndo_set_vf_vlan)(struct net_device *dev,
         int queue, u16 vlan,
         u8 qos, __be16 proto);
 int (*ndo_set_vf_rate)(struct net_device *dev,
         int vf, int min_tx_rate,
         int max_tx_rate);
 int (*ndo_set_vf_spoofchk)(struct net_device *dev,
             int vf, bool setting);
 int (*ndo_set_vf_trust)(struct net_device *dev,
          int vf, bool setting);
 int (*ndo_get_vf_config)(struct net_device *dev,
           int vf,
           struct ifla_vf_info *ivf);
 int (*ndo_set_vf_link_state)(struct net_device *dev,
        int vf, int link_state);
 int (*ndo_get_vf_stats)(struct net_device *dev,
          int vf,
          struct ifla_vf_stats
          *vf_stats);
 int (*ndo_set_vf_port)(struct net_device *dev,
         int vf,
         struct nlattr *port[]);
 int (*ndo_get_vf_port)(struct net_device *dev,
         int vf, struct sk_buff *skb);
 int (*ndo_get_vf_guid)(struct net_device *dev,
         int vf,
         struct ifla_vf_guid *node_guid,
         struct ifla_vf_guid *port_guid);
 int (*ndo_set_vf_guid)(struct net_device *dev,
         int vf, u64 guid,
         int guid_type);
 int (*ndo_set_vf_rss_query_en)(
         struct net_device *dev,
         int vf, bool setting);
 int (*ndo_setup_tc)(struct net_device *dev,
      enum tc_setup_type type,
      void *type_data);

 int (*ndo_fcoe_enable)(struct net_device *dev);
 int (*ndo_fcoe_disable)(struct net_device *dev);
 int (*ndo_fcoe_ddp_setup)(struct net_device *dev,
            u16 xid,
            struct scatterlist *sgl,
            unsigned int sgc);
 int (*ndo_fcoe_ddp_done)(struct net_device *dev,
           u16 xid);
 int (*ndo_fcoe_ddp_target)(struct net_device *dev,
             u16 xid,
             struct scatterlist *sgl,
             unsigned int sgc);
 int (*ndo_fcoe_get_hbainfo)(struct net_device *dev,
       struct netdev_fcoe_hbainfo *hbainfo);



 int (*ndo_fcoe_get_wwn)(struct net_device *dev,
          u64 *wwn, int type);



 int (*ndo_rx_flow_steer)(struct net_device *dev,
           const struct sk_buff *skb,
           u16 rxq_index,
           u32 flow_id);

 int (*ndo_add_slave)(struct net_device *dev,
       struct net_device *slave_dev,
       struct netlink_ext_ack *extack);
 int (*ndo_del_slave)(struct net_device *dev,
       struct net_device *slave_dev);
 struct net_device* (*ndo_get_xmit_slave)(struct net_device *dev,
            struct sk_buff *skb,
            bool all_slaves);
 struct net_device* (*ndo_sk_get_lower_dev)(struct net_device *dev,
       struct sock *sk);
 netdev_features_t (*ndo_fix_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_set_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_neigh_construct)(struct net_device *dev,
             struct neighbour *n);
 void (*ndo_neigh_destroy)(struct net_device *dev,
           struct neighbour *n);

 int (*ndo_fdb_add)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            u16 flags,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del_bulk)(struct nlmsghdr *nlh,
          struct net_device *dev,
          struct netlink_ext_ack *extack);
 int (*ndo_fdb_dump)(struct sk_buff *skb,
      struct netlink_callback *cb,
      struct net_device *dev,
      struct net_device *filter_dev,
      int *idx);
 int (*ndo_fdb_get)(struct sk_buff *skb,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid, u32 portid, u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_add)(struct net_device *dev,
            struct nlattr *tb[],
            u16 nlmsg_flags,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del)(struct net_device *dev,
            struct nlattr *tb[],
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del_bulk)(struct net_device *dev,
          struct nlattr *tb[],
          struct netlink_ext_ack *extack);
 int (*ndo_mdb_dump)(struct net_device *dev,
      struct sk_buff *skb,
      struct netlink_callback *cb);
 int (*ndo_mdb_get)(struct net_device *dev,
            struct nlattr *tb[], u32 portid,
            u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_setlink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_getlink)(struct sk_buff *skb,
            u32 pid, u32 seq,
            struct net_device *dev,
            u32 filter_mask,
            int nlflags);
 int (*ndo_bridge_dellink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags);
 int (*ndo_change_carrier)(struct net_device *dev,
            bool new_carrier);
 int (*ndo_get_phys_port_id)(struct net_device *dev,
       struct netdev_phys_item_id *ppid);
 int (*ndo_get_port_parent_id)(struct net_device *dev,
         struct netdev_phys_item_id *ppid);
 int (*ndo_get_phys_port_name)(struct net_device *dev,
         char *name, size_t len);
 void* (*ndo_dfwd_add_station)(struct net_device *pdev,
       struct net_device *dev);
 void (*ndo_dfwd_del_station)(struct net_device *pdev,
       void *priv);

 int (*ndo_set_tx_maxrate)(struct net_device *dev,
            int queue_index,
            u32 maxrate);
 int (*ndo_get_iflink)(const struct net_device *dev);
 int (*ndo_fill_metadata_dst)(struct net_device *dev,
             struct sk_buff *skb);
 void (*ndo_set_rx_headroom)(struct net_device *dev,
             int needed_headroom);
 int (*ndo_bpf)(struct net_device *dev,
        struct netdev_bpf *bpf);
 int (*ndo_xdp_xmit)(struct net_device *dev, int n,
      struct xdp_frame **xdp,
      u32 flags);
 struct net_device * (*ndo_xdp_get_xmit_slave)(struct net_device *dev,
         struct xdp_buff *xdp);
 int (*ndo_xsk_wakeup)(struct net_device *dev,
        u32 queue_id, u32 flags);
 int (*ndo_tunnel_ctl)(struct net_device *dev,
        struct ip_tunnel_parm_kern *p,
        int cmd);
 struct net_device * (*ndo_get_peer_dev)(struct net_device *dev);
 int (*ndo_fill_forward_path)(struct net_device_path_ctx *ctx,
                                                         struct net_device_path *path);
 ktime_t (*ndo_get_tstamp)(struct net_device *dev,
        const struct skb_shared_hwtstamps *hwtstamps,
        bool cycles);
 int (*ndo_hwtstamp_get)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config);
 int (*ndo_hwtstamp_set)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config,
          struct netlink_ext_ack *extack);






 const struct net_shaper_ops *net_shaper_ops;

};
enum netdev_ml_priv_type {
 ML_PRIV_NONE,
 ML_PRIV_CAN,
};
enum netdev_stat_type {
 NETDEV_PCPU_STAT_NONE,
 NETDEV_PCPU_STAT_LSTATS,
 NETDEV_PCPU_STAT_TSTATS,
 NETDEV_PCPU_STAT_DSTATS,
};
struct net_device {






 __u8 __cacheline_group_begin__net_device_read_tx[1];
 union { struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } ; struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } priv_flags_fast; }



  ;
 const struct net_device_ops *netdev_ops;
 const struct header_ops *header_ops;
 struct netdev_queue *_tx;
 netdev_features_t gso_partial_features;
 unsigned int real_num_tx_queues;
 unsigned int gso_max_size;
 unsigned int gso_ipv4_max_size;
 u16 gso_max_segs;
 s16 num_tc;





 unsigned int mtu;
 unsigned short needed_headroom;
 struct netdev_tc_txq tc_to_txq[16];

 struct xps_dev_maps *xps_maps[XPS_MAPS_MAX];


 struct nf_hook_entries *nf_hooks_egress;


 struct bpf_mprog_entry *tcx_egress;

 __u8 __cacheline_group_end__net_device_read_tx[1];


 __u8 __cacheline_group_begin__net_device_read_txrx[1];
 union {
  struct pcpu_lstats *lstats;
  struct pcpu_sw_netstats *tstats;
  struct pcpu_dstats *dstats;
 };
 unsigned long state;
 unsigned int flags;
 unsigned short hard_header_len;
 enum netdev_stat_type pcpu_stat_type:8;
 netdev_features_t features;
 struct inet6_dev *ip6_ptr;
 __u8 __cacheline_group_end__net_device_read_txrx[1];


 __u8 __cacheline_group_begin__net_device_read_rx[1];
 struct bpf_prog *xdp_prog;
 struct list_head ptype_specific;
 int ifindex;
 unsigned int real_num_rx_queues;
 struct netdev_rx_queue *_rx;
 unsigned int gro_max_size;
 unsigned int gro_ipv4_max_size;
 rx_handler_func_t *rx_handler;
 void *rx_handler_data;
 possible_net_t nd_net;

 struct netpoll_info *npinfo;


 struct bpf_mprog_entry *tcx_ingress;

 __u8 __cacheline_group_end__net_device_read_rx[1];

 char name[16];
 struct netdev_name_node *name_node;
 struct dev_ifalias *ifalias;




 unsigned long mem_end;
 unsigned long mem_start;
 unsigned long base_addr;
 struct list_head dev_list;
 struct list_head napi_list;
 struct list_head unreg_list;
 struct list_head close_list;
 struct list_head ptype_all;

 struct {
  struct list_head upper;
  struct list_head lower;
 } adj_list;


 xdp_features_t xdp_features;
 const struct xdp_metadata_ops *xdp_metadata_ops;
 const struct xsk_tx_metadata_ops *xsk_tx_metadata_ops;
 unsigned short gflags;

 unsigned short needed_tailroom;

 netdev_features_t hw_features;
 netdev_features_t wanted_features;
 netdev_features_t vlan_features;
 netdev_features_t hw_enc_features;
 netdev_features_t mpls_features;
 netdev_features_t mangleid_features;

 unsigned int min_mtu;
 unsigned int max_mtu;
 unsigned short type;
 unsigned char min_header_len;
 unsigned char name_assign_type;

 int group;

 struct net_device_stats stats;

 struct net_device_core_stats *core_stats;


 atomic_t carrier_up_count;
 atomic_t carrier_down_count;


 const struct iw_handler_def *wireless_handlers;

 const struct ethtool_ops *ethtool_ops;

 const struct l3mdev_ops *l3mdev_ops;


 const struct ndisc_ops *ndisc_ops;



 const struct xfrmdev_ops *xfrmdev_ops;



 const struct tlsdev_ops *tlsdev_ops;


 unsigned int operstate;
 unsigned char link_mode;

 unsigned char if_port;
 unsigned char dma;


 unsigned char perm_addr[32];
 unsigned char addr_assign_type;
 unsigned char addr_len;
 unsigned char upper_level;
 unsigned char lower_level;
 u8 threaded;

 unsigned short neigh_priv_len;
 unsigned short dev_id;
 unsigned short dev_port;
 int irq;
 u32 priv_len;

 spinlock_t addr_list_lock;

 struct netdev_hw_addr_list uc;
 struct netdev_hw_addr_list mc;
 struct netdev_hw_addr_list dev_addrs;


 struct kset *queues_kset;


 struct list_head unlink_list;

 unsigned int promiscuity;
 unsigned int allmulti;
 bool uc_promisc;

 unsigned char nested_level;




 struct in_device *ip_ptr;

 struct hlist_head fib_nh_head;


 struct vlan_info *vlan_info;


 struct dsa_port *dsa_ptr;


 struct tipc_bearer *tipc_ptr;


 void *atalk_ptr;


 struct ax25_dev *ax25_ptr;


 struct wireless_dev *ieee80211_ptr;


 struct wpan_dev *ieee802154_ptr;


 struct mpls_dev *mpls_ptr;


 struct mctp_dev *mctp_ptr;


 struct psp_dev *psp_dev;






 const unsigned char *dev_addr;

 unsigned int num_rx_queues;



 unsigned int xdp_zc_max_segs;
 struct netdev_queue *ingress_queue;

 struct nf_hook_entries *nf_hooks_ingress;


 unsigned char broadcast[32];

 struct cpu_rmap *rx_cpu_rmap;

 struct hlist_node index_hlist;




 unsigned int num_tx_queues;
 struct Qdisc *qdisc;
 unsigned int tx_queue_len;
 spinlock_t tx_global_lock;

 struct xdp_dev_bulk_queue *xdp_bulkq;


 struct hlist_head qdisc_hash[1 << (4)];


 struct timer_list watchdog_timer;
 int watchdog_timeo;
 spinlock_t watchdog_lock;
 bool watchdog_ref_held;

 u32 proto_down_reason;

 struct list_head todo_list;


 int *pcpu_refcnt;



 struct ref_tracker_dir refcnt_tracker;

 struct list_head link_watch_list;

 u8 reg_state;

 bool dismantle;


 bool moving_ns;

 bool rtnl_link_initializing;

 bool needs_free_netdev;
 void (*priv_destructor)(struct net_device *dev);


 void *ml_priv;
 enum netdev_ml_priv_type ml_priv_type;


 struct garp_port *garp_port;


 struct mrp_port *mrp_port;


 struct dm_hw_stat_delta *dm_private;

 struct device dev;
 const struct attribute_group *sysfs_groups[5];
 const struct attribute_group *sysfs_rx_queue_group;

 const struct rtnl_link_ops *rtnl_link_ops;

 const struct netdev_stat_ops *stat_ops;

 const struct netdev_queue_mgmt_ops *queue_mgmt_ops;






 unsigned int tso_max_size;
 u16 tso_max_segs;


 const struct dcbnl_rtnl_ops *dcbnl_ops;

 u8 prio_tc_map[15 + 1];


 unsigned int fcoe_ddp_xid;


 struct netprio_map *priomap;

 struct phy_link_topology *link_topo;
 struct phy_device *phydev;
 struct sfp_bus *sfp_bus;
 struct lock_class_key *qdisc_tx_busylock;
 bool proto_down;
 bool irq_affinity_auto;
 bool rx_cpu_rmap_auto;


 unsigned long see_all_hwtstamp_requests:1;
 unsigned long change_proto_down:1;
 unsigned long netns_immutable:1;
 unsigned long fcoe_mtu:1;

 struct list_head net_notifier_list;



 const struct macsec_ops *macsec_ops;

 const struct udp_tunnel_nic_info *udp_tunnel_nic_info;
 struct udp_tunnel_nic *udp_tunnel_nic;


 struct netdev_config *cfg;





 struct netdev_config *cfg_pending;
 struct ethtool_netdev_state *ethtool;


 struct bpf_xdp_entity xdp_state[__MAX_XDP_MODE];

 u8 dev_addr_shadow[32];
 netdevice_tracker linkwatch_dev_tracker;
 netdevice_tracker watchdog_dev_tracker;
 netdevice_tracker dev_registered_tracker;
 struct rtnl_hw_stats64 *offload_xstats_l3;

 struct devlink_port *devlink_port;


 struct dpll_pin *dpll_pin;



 struct hlist_head page_pools;



 struct dim_irq_moder *irq_moder;

 u64 max_pacing_offload_horizon;
 struct napi_config *napi_config;
 u32 num_napi_configs;
 u32 napi_defer_hard_irqs;
 unsigned long gro_flush_timeout;






 bool up;





 bool request_ops_lock;
 struct mutex lock;






 struct net_shaper_hierarchy *net_shaper_hierarchy;


 struct hlist_head neighbours[NEIGH_NR_TABLES];

 struct hwtstamp_provider *hwprov;

 u8 priv[1] 
           ;
} ;
struct pcpu_sw_netstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 struct u64_stats_sync syncp;
} ;
struct pcpu_dstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 u64_stats_t rx_drops;
 u64_stats_t tx_drops;
 struct u64_stats_sync syncp;
} ;
struct pcpu_lstats {
 u64_stats_t packets;
 u64_stats_t bytes;
 struct u64_stats_sync syncp;
} ;
enum {
 NETIF_MSG_DRV_BIT,
 NETIF_MSG_PROBE_BIT,
 NETIF_MSG_LINK_BIT,
 NETIF_MSG_TIMER_BIT,
 NETIF_MSG_IFDOWN_BIT,
 NETIF_MSG_IFUP_BIT,
 NETIF_MSG_RX_ERR_BIT,
 NETIF_MSG_TX_ERR_BIT,
 NETIF_MSG_TX_QUEUED_BIT,
 NETIF_MSG_INTR_BIT,
 NETIF_MSG_TX_DONE_BIT,
 NETIF_MSG_RX_STATUS_BIT,
 NETIF_MSG_PKTDATA_BIT,
 NETIF_MSG_HW_BIT,
 NETIF_MSG_WOL_BIT,




 NETIF_MSG_CLASS_COUNT,
};
_Static_assert(NETIF_MSG_CLASS_COUNT <= 32, "NETIF_MSG_CLASS_COUNT <= 32");
struct device;
struct fwnode_handle;
struct ieee80211_p2p_noa_desc {
 u8 count;
 __le32 duration;
 __le32 interval;
 __le32 start_time;
} __attribute__((__packed__));
struct ieee80211_p2p_noa_attr {
 u8 index;
 u8 oppps_ctwindow;
 struct ieee80211_p2p_noa_desc desc[4];
} __attribute__((__packed__));
struct element {
 u8 id;
 u8 datalen;
 u8 data[1];
} __attribute__((__packed__));
struct ieee80211_mcs_info {
 u8 rx_mask[10];
 __le16 rx_highest;
 u8 tx_params;
 u8 reserved[3];
} __attribute__((__packed__));
struct ieee80211_ht_cap {
 __le16 cap_info;
 u8 ampdu_params_info;


 struct ieee80211_mcs_info mcs;

 __le16 extended_ht_cap_info;
 __le32 tx_BF_cap_info;
 u8 antenna_selection_info;
} __attribute__((__packed__));
struct ieee80211_vht_mcs_info {
 __le16 rx_mcs_map;
 __le16 rx_highest;
 __le16 tx_mcs_map;
 __le16 tx_highest;
} __attribute__((__packed__));
struct ieee80211_vht_cap {
 __le32 vht_cap_info;
 struct ieee80211_vht_mcs_info supp_mcs;
} __attribute__((__packed__));
struct ieee80211_twt_setup {
 u8 dialog_token;
 u8 element_id;
 u8 length;
 u8 control;
 u8 params[1];
} __attribute__((__packed__));
struct ieee80211_he_cap_elem {
 u8 mac_cap_info[6];
 u8 phy_cap_info[11];
} __attribute__((__packed__));
struct ieee80211_he_mcs_nss_supp {
 __le16 rx_mcs_80;
 __le16 tx_mcs_80;
 __le16 rx_mcs_160;
 __le16 tx_mcs_160;
 __le16 rx_mcs_80p80;
 __le16 tx_mcs_80p80;
} __attribute__((__packed__));
struct ieee80211_he_mu_edca_param_ac_rec {
 u8 aifsn;
 u8 ecw_min_max;
 u8 mu_edca_timer;
} __attribute__((__packed__));
struct ieee80211_he_6ghz_capa {

 __le16 capa;
} __attribute__((__packed__));
struct ieee80211_eht_mcs_nss_supp_20mhz_only {
 union {
  struct {
   u8 rx_tx_mcs7_max_nss;
   u8 rx_tx_mcs9_max_nss;
   u8 rx_tx_mcs11_max_nss;
   u8 rx_tx_mcs13_max_nss;
  };
  u8 rx_tx_max_nss[4];
 };
};
struct ieee80211_eht_mcs_nss_supp_bw {
 union {
  struct {
   u8 rx_tx_mcs9_max_nss;
   u8 rx_tx_mcs11_max_nss;
   u8 rx_tx_mcs13_max_nss;
  };
  u8 rx_tx_max_nss[3];
 };
};
struct ieee80211_eht_cap_elem_fixed {
 u8 mac_cap_info[2];
 u8 phy_cap_info[9];
} __attribute__((__packed__));
struct ieee80211_uhr_cap_mac {
 u8 mac_cap[5];
} __attribute__((__packed__));
struct ieee80211_uhr_cap_phy {
 u8 cap;
} __attribute__((__packed__));
struct ethtool_drvinfo {
 __u32 cmd;
 char driver[32];
 char version[32];
 char fw_version[32];
 char bus_info[32];
 char erom_version[32];
 char reserved2[12];
 __u32 n_priv_flags;
 __u32 n_stats;
 __u32 testinfo_len;
 __u32 eedump_len;
 __u32 regdump_len;
};
struct ethtool_wolinfo {
 __u32 cmd;
 __u32 supported;
 __u32 wolopts;
 __u8 sopass[6];
};
struct ethtool_tunable {
 __u32 cmd;
 __u32 id;
 __u32 type_id;
 __u32 len;
 void *data[1];
};
struct ethtool_regs {
 __u32 cmd;
 __u32 version;
 __u32 len;
 __u8 data[1];
};
struct ethtool_eeprom {
 __u32 cmd;
 __u32 magic;
 __u32 offset;
 __u32 len;
 __u8 data[1];
};
struct ethtool_modinfo {
 __u32 cmd;
 __u32 type;
 __u32 eeprom_len;
 __u32 reserved[8];
};
struct ethtool_coalesce {
 __u32 cmd;
 __u32 rx_coalesce_usecs;
 __u32 rx_max_coalesced_frames;
 __u32 rx_coalesce_usecs_irq;
 __u32 rx_max_coalesced_frames_irq;
 __u32 tx_coalesce_usecs;
 __u32 tx_max_coalesced_frames;
 __u32 tx_coalesce_usecs_irq;
 __u32 tx_max_coalesced_frames_irq;
 __u32 stats_block_coalesce_usecs;
 __u32 use_adaptive_rx_coalesce;
 __u32 use_adaptive_tx_coalesce;
 __u32 pkt_rate_low;
 __u32 rx_coalesce_usecs_low;
 __u32 rx_max_coalesced_frames_low;
 __u32 tx_coalesce_usecs_low;
 __u32 tx_max_coalesced_frames_low;
 __u32 pkt_rate_high;
 __u32 rx_coalesce_usecs_high;
 __u32 rx_max_coalesced_frames_high;
 __u32 tx_coalesce_usecs_high;
 __u32 tx_max_coalesced_frames_high;
 __u32 rate_sample_interval;
};
struct ethtool_ringparam {
 __u32 cmd;
 __u32 rx_max_pending;
 __u32 rx_mini_max_pending;
 __u32 rx_jumbo_max_pending;
 __u32 tx_max_pending;
 __u32 rx_pending;
 __u32 rx_mini_pending;
 __u32 rx_jumbo_pending;
 __u32 tx_pending;
};
struct ethtool_channels {
 __u32 cmd;
 __u32 max_rx;
 __u32 max_tx;
 __u32 max_other;
 __u32 max_combined;
 __u32 rx_count;
 __u32 tx_count;
 __u32 other_count;
 __u32 combined_count;
};
struct ethtool_pauseparam {
 __u32 cmd;
 __u32 autoneg;
 __u32 rx_pause;
 __u32 tx_pause;
};
enum ethtool_link_ext_state {
 ETHTOOL_LINK_EXT_STATE_AUTONEG,
 ETHTOOL_LINK_EXT_STATE_LINK_TRAINING_FAILURE,
 ETHTOOL_LINK_EXT_STATE_LINK_LOGICAL_MISMATCH,
 ETHTOOL_LINK_EXT_STATE_BAD_SIGNAL_INTEGRITY,
 ETHTOOL_LINK_EXT_STATE_NO_CABLE,
 ETHTOOL_LINK_EXT_STATE_CABLE_ISSUE,
 ETHTOOL_LINK_EXT_STATE_EEPROM_ISSUE,
 ETHTOOL_LINK_EXT_STATE_CALIBRATION_FAILURE,
 ETHTOOL_LINK_EXT_STATE_POWER_BUDGET_EXCEEDED,
 ETHTOOL_LINK_EXT_STATE_OVERHEAT,
 ETHTOOL_LINK_EXT_STATE_MODULE,
};
enum ethtool_link_ext_substate_autoneg {
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_PARTNER_DETECTED = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_ACK_NOT_RECEIVED,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NEXT_PAGE_EXCHANGE_FAILED,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_PARTNER_DETECTED_FORCE_MODE,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_FEC_MISMATCH_DURING_OVERRIDE,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_HCD,
};
enum ethtool_link_ext_substate_link_training {
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_FRAME_LOCK_NOT_ACQUIRED = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_LINK_INHIBIT_TIMEOUT,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_LINK_PARTNER_DID_NOT_SET_RECEIVER_READY,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_REMOTE_FAULT,
};
enum ethtool_link_ext_substate_link_logical_mismatch {
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_ACQUIRE_BLOCK_LOCK = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_ACQUIRE_AM_LOCK,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_GET_ALIGN_STATUS,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_FC_FEC_IS_NOT_LOCKED,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_RS_FEC_IS_NOT_LOCKED,
};
enum ethtool_link_ext_substate_bad_signal_integrity {
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_LARGE_NUMBER_OF_PHYSICAL_ERRORS = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_UNSUPPORTED_RATE,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_SERDES_REFERENCE_CLOCK_LOST,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_SERDES_ALOS,
};
enum ethtool_link_ext_substate_cable_issue {
 ETHTOOL_LINK_EXT_SUBSTATE_CI_UNSUPPORTED_CABLE = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_CI_CABLE_TEST_FAILURE,
};
enum ethtool_link_ext_substate_module {
 ETHTOOL_LINK_EXT_SUBSTATE_MODULE_CMIS_NOT_READY = 1,
};
enum ethtool_mac_stats_src {
 ETHTOOL_MAC_STATS_SRC_AGGREGATE,
 ETHTOOL_MAC_STATS_SRC_EMAC,
 ETHTOOL_MAC_STATS_SRC_PMAC,
};
enum ethtool_module_power_mode_policy {
 ETHTOOL_MODULE_POWER_MODE_POLICY_HIGH = 1,
 ETHTOOL_MODULE_POWER_MODE_POLICY_AUTO,
};
enum ethtool_module_power_mode {
 ETHTOOL_MODULE_POWER_MODE_LOW = 1,
 ETHTOOL_MODULE_POWER_MODE_HIGH,
};
enum ethtool_mm_verify_status {
 ETHTOOL_MM_VERIFY_STATUS_UNKNOWN,
 ETHTOOL_MM_VERIFY_STATUS_INITIAL,
 ETHTOOL_MM_VERIFY_STATUS_VERIFYING,
 ETHTOOL_MM_VERIFY_STATUS_SUCCEEDED,
 ETHTOOL_MM_VERIFY_STATUS_FAILED,
 ETHTOOL_MM_VERIFY_STATUS_DISABLED,
};
struct ethtool_test {
 __u32 cmd;
 __u32 flags;
 __u32 reserved;
 __u32 len;
 __u64 data[1];
};
struct ethtool_stats {
 __u32 cmd;
 __u32 n_stats;
 __u64 data[1];
};
struct ethtool_tcpip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be16 psrc;
 __be16 pdst;
 __u8 tos;
};
struct ethtool_ah_espip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be32 spi;
 __u8 tos;
};
struct ethtool_usrip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be32 l4_4_bytes;
 __u8 tos;
 __u8 ip_ver;
 __u8 proto;
};
struct ethtool_tcpip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be16 psrc;
 __be16 pdst;
 __u8 tclass;
};
struct ethtool_ah_espip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be32 spi;
 __u8 tclass;
};
struct ethtool_usrip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be32 l4_4_bytes;
 __u8 tclass;
 __u8 l4_proto;
};
union ethtool_flow_union {
 struct ethtool_tcpip4_spec tcp_ip4_spec;
 struct ethtool_tcpip4_spec udp_ip4_spec;
 struct ethtool_tcpip4_spec sctp_ip4_spec;
 struct ethtool_ah_espip4_spec ah_ip4_spec;
 struct ethtool_ah_espip4_spec esp_ip4_spec;
 struct ethtool_usrip4_spec usr_ip4_spec;
 struct ethtool_tcpip6_spec tcp_ip6_spec;
 struct ethtool_tcpip6_spec udp_ip6_spec;
 struct ethtool_tcpip6_spec sctp_ip6_spec;
 struct ethtool_ah_espip6_spec ah_ip6_spec;
 struct ethtool_ah_espip6_spec esp_ip6_spec;
 struct ethtool_usrip6_spec usr_ip6_spec;
 struct ethhdr ether_spec;
 __u8 hdata[52];
};
struct ethtool_flow_ext {
 __u8 padding[2];
 unsigned char h_dest[6];
 __be16 vlan_etype;
 __be16 vlan_tci;
 __be32 data[2];
};
struct ethtool_rx_flow_spec {
 __u32 flow_type;
 union ethtool_flow_union h_u;
 struct ethtool_flow_ext h_ext;
 union ethtool_flow_union m_u;
 struct ethtool_flow_ext m_ext;
 __u64 ring_cookie;
 __u32 location;
};
struct ethtool_rxnfc {
 __u32 cmd;
 __u32 flow_type;
 __u64 data;
 struct ethtool_rx_flow_spec fs;
 union {
  __u32 rule_cnt;
  __u32 rss_context;
 };
 __u32 rule_locs[1];
};
struct ethtool_flash {
 __u32 cmd;
 __u32 region;
 char data[128];
};
struct ethtool_dump {
 __u32 cmd;
 __u32 version;
 __u32 flag;
 __u32 len;
 __u8 data[1];
};
struct ethtool_fecparam {
 __u32 cmd;

 __u32 active_fec;
 __u32 fec;
 __u32 reserved;
};
enum ethtool_link_mode_bit_indices {
 ETHTOOL_LINK_MODE_10baseT_Half_BIT = 0,
 ETHTOOL_LINK_MODE_10baseT_Full_BIT = 1,
 ETHTOOL_LINK_MODE_100baseT_Half_BIT = 2,
 ETHTOOL_LINK_MODE_100baseT_Full_BIT = 3,
 ETHTOOL_LINK_MODE_1000baseT_Half_BIT = 4,
 ETHTOOL_LINK_MODE_1000baseT_Full_BIT = 5,
 ETHTOOL_LINK_MODE_Autoneg_BIT = 6,
 ETHTOOL_LINK_MODE_TP_BIT = 7,
 ETHTOOL_LINK_MODE_AUI_BIT = 8,
 ETHTOOL_LINK_MODE_MII_BIT = 9,
 ETHTOOL_LINK_MODE_FIBRE_BIT = 10,
 ETHTOOL_LINK_MODE_BNC_BIT = 11,
 ETHTOOL_LINK_MODE_10000baseT_Full_BIT = 12,
 ETHTOOL_LINK_MODE_Pause_BIT = 13,
 ETHTOOL_LINK_MODE_Asym_Pause_BIT = 14,
 ETHTOOL_LINK_MODE_2500baseX_Full_BIT = 15,
 ETHTOOL_LINK_MODE_Backplane_BIT = 16,
 ETHTOOL_LINK_MODE_1000baseKX_Full_BIT = 17,
 ETHTOOL_LINK_MODE_10000baseKX4_Full_BIT = 18,
 ETHTOOL_LINK_MODE_10000baseKR_Full_BIT = 19,
 ETHTOOL_LINK_MODE_10000baseR_FEC_BIT = 20,
 ETHTOOL_LINK_MODE_20000baseMLD2_Full_BIT = 21,
 ETHTOOL_LINK_MODE_20000baseKR2_Full_BIT = 22,
 ETHTOOL_LINK_MODE_40000baseKR4_Full_BIT = 23,
 ETHTOOL_LINK_MODE_40000baseCR4_Full_BIT = 24,
 ETHTOOL_LINK_MODE_40000baseSR4_Full_BIT = 25,
 ETHTOOL_LINK_MODE_40000baseLR4_Full_BIT = 26,
 ETHTOOL_LINK_MODE_56000baseKR4_Full_BIT = 27,
 ETHTOOL_LINK_MODE_56000baseCR4_Full_BIT = 28,
 ETHTOOL_LINK_MODE_56000baseSR4_Full_BIT = 29,
 ETHTOOL_LINK_MODE_56000baseLR4_Full_BIT = 30,
 ETHTOOL_LINK_MODE_25000baseCR_Full_BIT = 31,







 ETHTOOL_LINK_MODE_25000baseKR_Full_BIT = 32,
 ETHTOOL_LINK_MODE_25000baseSR_Full_BIT = 33,
 ETHTOOL_LINK_MODE_50000baseCR2_Full_BIT = 34,
 ETHTOOL_LINK_MODE_50000baseKR2_Full_BIT = 35,
 ETHTOOL_LINK_MODE_100000baseKR4_Full_BIT = 36,
 ETHTOOL_LINK_MODE_100000baseSR4_Full_BIT = 37,
 ETHTOOL_LINK_MODE_100000baseCR4_Full_BIT = 38,
 ETHTOOL_LINK_MODE_100000baseLR4_ER4_Full_BIT = 39,
 ETHTOOL_LINK_MODE_50000baseSR2_Full_BIT = 40,
 ETHTOOL_LINK_MODE_1000baseX_Full_BIT = 41,
 ETHTOOL_LINK_MODE_10000baseCR_Full_BIT = 42,
 ETHTOOL_LINK_MODE_10000baseSR_Full_BIT = 43,
 ETHTOOL_LINK_MODE_10000baseLR_Full_BIT = 44,
 ETHTOOL_LINK_MODE_10000baseLRM_Full_BIT = 45,
 ETHTOOL_LINK_MODE_10000baseER_Full_BIT = 46,
 ETHTOOL_LINK_MODE_2500baseT_Full_BIT = 47,
 ETHTOOL_LINK_MODE_5000baseT_Full_BIT = 48,

 ETHTOOL_LINK_MODE_FEC_NONE_BIT = 49,
 ETHTOOL_LINK_MODE_FEC_RS_BIT = 50,
 ETHTOOL_LINK_MODE_FEC_BASER_BIT = 51,
 ETHTOOL_LINK_MODE_50000baseKR_Full_BIT = 52,
 ETHTOOL_LINK_MODE_50000baseSR_Full_BIT = 53,
 ETHTOOL_LINK_MODE_50000baseCR_Full_BIT = 54,
 ETHTOOL_LINK_MODE_50000baseLR_ER_FR_Full_BIT = 55,
 ETHTOOL_LINK_MODE_50000baseDR_Full_BIT = 56,
 ETHTOOL_LINK_MODE_100000baseKR2_Full_BIT = 57,
 ETHTOOL_LINK_MODE_100000baseSR2_Full_BIT = 58,
 ETHTOOL_LINK_MODE_100000baseCR2_Full_BIT = 59,
 ETHTOOL_LINK_MODE_100000baseLR2_ER2_FR2_Full_BIT = 60,
 ETHTOOL_LINK_MODE_100000baseDR2_Full_BIT = 61,
 ETHTOOL_LINK_MODE_200000baseKR4_Full_BIT = 62,
 ETHTOOL_LINK_MODE_200000baseSR4_Full_BIT = 63,
 ETHTOOL_LINK_MODE_200000baseLR4_ER4_FR4_Full_BIT = 64,
 ETHTOOL_LINK_MODE_200000baseDR4_Full_BIT = 65,
 ETHTOOL_LINK_MODE_200000baseCR4_Full_BIT = 66,
 ETHTOOL_LINK_MODE_100baseT1_Full_BIT = 67,
 ETHTOOL_LINK_MODE_1000baseT1_Full_BIT = 68,
 ETHTOOL_LINK_MODE_400000baseKR8_Full_BIT = 69,
 ETHTOOL_LINK_MODE_400000baseSR8_Full_BIT = 70,
 ETHTOOL_LINK_MODE_400000baseLR8_ER8_FR8_Full_BIT = 71,
 ETHTOOL_LINK_MODE_400000baseDR8_Full_BIT = 72,
 ETHTOOL_LINK_MODE_400000baseCR8_Full_BIT = 73,
 ETHTOOL_LINK_MODE_FEC_LLRS_BIT = 74,
 ETHTOOL_LINK_MODE_100000baseKR_Full_BIT = 75,
 ETHTOOL_LINK_MODE_100000baseSR_Full_BIT = 76,
 ETHTOOL_LINK_MODE_100000baseLR_ER_FR_Full_BIT = 77,
 ETHTOOL_LINK_MODE_100000baseCR_Full_BIT = 78,
 ETHTOOL_LINK_MODE_100000baseDR_Full_BIT = 79,
 ETHTOOL_LINK_MODE_200000baseKR2_Full_BIT = 80,
 ETHTOOL_LINK_MODE_200000baseSR2_Full_BIT = 81,
 ETHTOOL_LINK_MODE_200000baseLR2_ER2_FR2_Full_BIT = 82,
 ETHTOOL_LINK_MODE_200000baseDR2_Full_BIT = 83,
 ETHTOOL_LINK_MODE_200000baseCR2_Full_BIT = 84,
 ETHTOOL_LINK_MODE_400000baseKR4_Full_BIT = 85,
 ETHTOOL_LINK_MODE_400000baseSR4_Full_BIT = 86,
 ETHTOOL_LINK_MODE_400000baseLR4_ER4_FR4_Full_BIT = 87,
 ETHTOOL_LINK_MODE_400000baseDR4_Full_BIT = 88,
 ETHTOOL_LINK_MODE_400000baseCR4_Full_BIT = 89,
 ETHTOOL_LINK_MODE_100baseFX_Half_BIT = 90,
 ETHTOOL_LINK_MODE_100baseFX_Full_BIT = 91,
 ETHTOOL_LINK_MODE_10baseT1L_Full_BIT = 92,
 ETHTOOL_LINK_MODE_800000baseCR8_Full_BIT = 93,
 ETHTOOL_LINK_MODE_800000baseKR8_Full_BIT = 94,
 ETHTOOL_LINK_MODE_800000baseDR8_Full_BIT = 95,
 ETHTOOL_LINK_MODE_800000baseDR8_2_Full_BIT = 96,
 ETHTOOL_LINK_MODE_800000baseSR8_Full_BIT = 97,
 ETHTOOL_LINK_MODE_800000baseVR8_Full_BIT = 98,
 ETHTOOL_LINK_MODE_10baseT1S_Full_BIT = 99,
 ETHTOOL_LINK_MODE_10baseT1S_Half_BIT = 100,
 ETHTOOL_LINK_MODE_10baseT1S_P2MP_Half_BIT = 101,
 ETHTOOL_LINK_MODE_10baseT1BRR_Full_BIT = 102,
 ETHTOOL_LINK_MODE_200000baseCR_Full_BIT = 103,
 ETHTOOL_LINK_MODE_200000baseKR_Full_BIT = 104,
 ETHTOOL_LINK_MODE_200000baseDR_Full_BIT = 105,
 ETHTOOL_LINK_MODE_200000baseDR_2_Full_BIT = 106,
 ETHTOOL_LINK_MODE_200000baseSR_Full_BIT = 107,
 ETHTOOL_LINK_MODE_200000baseVR_Full_BIT = 108,
 ETHTOOL_LINK_MODE_400000baseCR2_Full_BIT = 109,
 ETHTOOL_LINK_MODE_400000baseKR2_Full_BIT = 110,
 ETHTOOL_LINK_MODE_400000baseDR2_Full_BIT = 111,
 ETHTOOL_LINK_MODE_400000baseDR2_2_Full_BIT = 112,
 ETHTOOL_LINK_MODE_400000baseSR2_Full_BIT = 113,
 ETHTOOL_LINK_MODE_400000baseVR2_Full_BIT = 114,
 ETHTOOL_LINK_MODE_800000baseCR4_Full_BIT = 115,
 ETHTOOL_LINK_MODE_800000baseKR4_Full_BIT = 116,
 ETHTOOL_LINK_MODE_800000baseDR4_Full_BIT = 117,
 ETHTOOL_LINK_MODE_800000baseDR4_2_Full_BIT = 118,
 ETHTOOL_LINK_MODE_800000baseSR4_Full_BIT = 119,
 ETHTOOL_LINK_MODE_800000baseVR4_Full_BIT = 120,


 __ETHTOOL_LINK_MODE_MASK_NBITS
};
struct ethtool_link_settings {
 __u32 cmd;
 __u32 speed;
 __u8 duplex;
 __u8 port;
 __u8 phy_address;
 __u8 autoneg;
 __u8 mdio_support;
 __u8 eth_tp_mdix;
 __u8 eth_tp_mdix_ctrl;
 __s8 link_mode_masks_nwords;
 __u8 transceiver;
 __u8 master_slave_cfg;
 __u8 master_slave_state;
 __u8 rate_matching;
 __u32 reserved[7];
};
enum hwtstamp_source {
 HWTSTAMP_SOURCE_NETDEV = 1,
 HWTSTAMP_SOURCE_PHYLIB,
};
enum hwtstamp_provider_qualifier {
 HWTSTAMP_PROVIDER_QUALIFIER_PRECISE,
 HWTSTAMP_PROVIDER_QUALIFIER_APPROX,

 HWTSTAMP_PROVIDER_QUALIFIER_CNT,
};
struct so_timestamping {
 int flags;
 int bind_phc;
};
enum ethtool_phys_id_state {
 ETHTOOL_ID_INACTIVE,
 ETHTOOL_ID_ACTIVE,
 ETHTOOL_ID_ON,
 ETHTOOL_ID_OFF
};
struct kernel_ethtool_ringparam {
 u32 rx_buf_len;
 u8 tcp_data_split;
 u8 tx_push;
 u8 rx_push;
 u32 cqe_size;
 u32 tx_push_buf_len;
 u32 tx_push_buf_max_len;
 u32 hds_thresh;
 u32 hds_thresh_max;
};
struct net_device;
struct netlink_ext_ack;
struct ethtool_link_ext_state_info {
 enum ethtool_link_ext_state link_ext_state;
 union {
  enum ethtool_link_ext_substate_autoneg autoneg;
  enum ethtool_link_ext_substate_link_training link_training;
  enum ethtool_link_ext_substate_link_logical_mismatch link_logical_mismatch;
  enum ethtool_link_ext_substate_bad_signal_integrity bad_signal_integrity;
  enum ethtool_link_ext_substate_cable_issue cable_issue;
  enum ethtool_link_ext_substate_module module;
  u32 __link_ext_substate;
 };
};
struct ethtool_link_ext_stats {
 u64 link_down_events;
};
struct ethtool_rxfh_context {
 u32 indir_size;
 u32 key_size;
 u16 priv_size;
 u8 hfunc;
 u8 input_xfrm;
 u8 indir_configured:1;
 u8 key_configured:1;



 u32 key_off;
 u8 data[1] ;
};
struct ethtool_link_ksettings {
 struct ethtool_link_settings base;
 struct {
  unsigned long supported[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
  unsigned long advertising[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
  unsigned long lp_advertising[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 } link_modes;
 u32 lanes;
};
struct ethtool_keee {
 unsigned long supported[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long advertised[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long lp_advertised[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 u32 tx_lpi_timer;
 bool tx_lpi_enabled;
 bool eee_active;
 bool eee_enabled;
};
struct kernel_ethtool_coalesce {
 u8 use_cqe_mode_tx;
 u8 use_cqe_mode_rx;
 u32 tx_aggr_max_bytes;
 u32 tx_aggr_max_frames;
 u32 tx_aggr_time_usecs;
};
struct ethtool_eth_mac_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 FramesTransmittedOK; u64 SingleCollisionFrames; u64 MultipleCollisionFrames; u64 FramesReceivedOK; u64 FrameCheckSequenceErrors; u64 AlignmentErrors; u64 OctetsTransmittedOK; u64 FramesWithDeferredXmissions; u64 LateCollisions; u64 FramesAbortedDueToXSColls; u64 FramesLostDueToIntMACXmitError; u64 CarrierSenseErrors; u64 OctetsReceivedOK; u64 FramesLostDueToIntMACRcvError; u64 MulticastFramesXmittedOK; u64 BroadcastFramesXmittedOK; u64 FramesWithExcessiveDeferral; u64 MulticastFramesReceivedOK; u64 BroadcastFramesReceivedOK; u64 InRangeLengthErrors; u64 OutOfRangeLengthField; u64 FrameTooLongErrors; } ; struct { u64 FramesTransmittedOK; u64 SingleCollisionFrames; u64 MultipleCollisionFrames; u64 FramesReceivedOK; u64 FrameCheckSequenceErrors; u64 AlignmentErrors; u64 OctetsTransmittedOK; u64 FramesWithDeferredXmissions; u64 LateCollisions; u64 FramesAbortedDueToXSColls; u64 FramesLostDueToIntMACXmitError; u64 CarrierSenseErrors; u64 OctetsReceivedOK; u64 FramesLostDueToIntMACRcvError; u64 MulticastFramesXmittedOK; u64 BroadcastFramesXmittedOK; u64 FramesWithExcessiveDeferral; u64 MulticastFramesReceivedOK; u64 BroadcastFramesReceivedOK; u64 InRangeLengthErrors; u64 OutOfRangeLengthField; u64 FrameTooLongErrors; } stats; }
  ;
};
struct ethtool_eth_phy_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 SymbolErrorDuringCarrier; } ; struct { u64 SymbolErrorDuringCarrier; } stats; }

  ;
};
struct ethtool_eth_ctrl_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 MACControlFramesTransmitted; u64 MACControlFramesReceived; u64 UnsupportedOpcodesReceived; } ; struct { u64 MACControlFramesTransmitted; u64 MACControlFramesReceived; u64 UnsupportedOpcodesReceived; } stats; }



  ;
};
struct ethtool_pause_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 tx_pause_frames; u64 rx_pause_frames; } ; struct { u64 tx_pause_frames; u64 rx_pause_frames; } stats; }


  ;
};
struct ethtool_fec_hist_range {
 u16 low;
 u16 high;
};
struct ethtool_fec_hist {
 struct ethtool_fec_hist_value {
  u64 sum;
  u64 per_lane[8];
 } values[17];
 const struct ethtool_fec_hist_range *ranges;
};
struct ethtool_fec_stats {
 struct ethtool_fec_stat {
  u64 total;
  u64 lanes[8];
 } corrected_blocks, uncorrectable_blocks, corrected_bits;
};
struct ethtool_rmon_hist_range {
 u16 low;
 u16 high;
};
struct ethtool_rmon_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 undersize_pkts; u64 oversize_pkts; u64 fragments; u64 jabbers; u64 hist[11]; u64 hist_tx[11]; } ; struct { u64 undersize_pkts; u64 oversize_pkts; u64 fragments; u64 jabbers; u64 hist[11]; u64 hist_tx[11]; } stats; }







  ;
};
struct ethtool_ts_stats {
 union { struct { u64 pkts; u64 onestep_pkts_unconfirmed; u64 lost; u64 err; } ; struct { u64 pkts; u64 onestep_pkts_unconfirmed; u64 lost; u64 err; } tx_stats; }




  ;
};
struct ethtool_module_eeprom {
 u32 offset;
 u32 length;
 u8 page;
 u8 bank;
 u8 i2c_address;
 u8 *data;
};
struct ethtool_module_power_mode_params {
 enum ethtool_module_power_mode_policy policy;
 enum ethtool_module_power_mode mode;
};
struct ethtool_mm_state {
 u32 verify_time;
 u32 max_verify_time;
 enum ethtool_mm_verify_status verify_status;
 bool tx_enabled;
 bool tx_active;
 bool pmac_enabled;
 bool verify_enabled;
 u32 tx_min_frag_size;
 u32 rx_min_frag_size;
};
struct ethtool_mm_cfg {
 u32 verify_time;
 bool verify_enabled;
 bool tx_enabled;
 bool pmac_enabled;
 u32 tx_min_frag_size;
};
struct ethtool_mm_stats {
 u64 MACMergeFrameAssErrorCount;
 u64 MACMergeFrameSmdErrorCount;
 u64 MACMergeFrameAssOkCount;
 u64 MACMergeFragCountRx;
 u64 MACMergeFragCountTx;
 u64 MACMergeHoldCount;
};
struct ethtool_rxfh_param {
 u8 hfunc;
 u32 indir_size;
 u32 *indir;
 u32 key_size;
 u8 *key;
 u32 rss_context;
 u8 rss_delete;
 u8 input_xfrm;
};
struct ethtool_rxfh_fields {
 u32 data;
 u32 flow_type;
 u32 rss_context;
};
struct kernel_ethtool_ts_info {
 u32 cmd;
 u32 so_timestamping;
 int phc_index;
 enum hwtstamp_provider_qualifier phc_qualifier;
 enum hwtstamp_source phc_source;
 int phc_phyindex;
 u32 tx_types;
 u32 rx_filters;
};
struct ethtool_ops {
 u32 supported_input_xfrm:8;
 u32 cap_link_lanes_supported:1;
 u32 rxfh_per_ctx_fields:1;
 u32 rxfh_per_ctx_key:1;
 u32 cap_rss_rxnfc_adds:1;
 u32 rxfh_indir_space;
 u16 rxfh_key_space;
 u16 rxfh_priv_size;
 u32 rxfh_max_num_contexts;
 u32 supported_coalesce_params;
 u32 supported_ring_params;
 u32 supported_hwtstamp_qualifiers;
 void (*get_drvinfo)(struct net_device *, struct ethtool_drvinfo *);
 int (*get_regs_len)(struct net_device *);
 void (*get_regs)(struct net_device *, struct ethtool_regs *, void *);
 void (*get_wol)(struct net_device *, struct ethtool_wolinfo *);
 int (*set_wol)(struct net_device *, struct ethtool_wolinfo *);
 u32 (*get_msglevel)(struct net_device *);
 void (*set_msglevel)(struct net_device *, u32);
 int (*nway_reset)(struct net_device *);
 u32 (*get_link)(struct net_device *);
 int (*get_link_ext_state)(struct net_device *,
          struct ethtool_link_ext_state_info *);
 void (*get_link_ext_stats)(struct net_device *dev,
          struct ethtool_link_ext_stats *stats);
 int (*get_eeprom_len)(struct net_device *);
 int (*get_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*set_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*get_coalesce)(struct net_device *,
    struct ethtool_coalesce *,
    struct kernel_ethtool_coalesce *,
    struct netlink_ext_ack *);
 int (*set_coalesce)(struct net_device *,
    struct ethtool_coalesce *,
    struct kernel_ethtool_coalesce *,
    struct netlink_ext_ack *);
 void (*get_ringparam)(struct net_device *,
     struct ethtool_ringparam *,
     struct kernel_ethtool_ringparam *,
     struct netlink_ext_ack *);
 int (*set_ringparam)(struct net_device *,
     struct ethtool_ringparam *,
     struct kernel_ethtool_ringparam *,
     struct netlink_ext_ack *);
 void (*get_pause_stats)(struct net_device *dev,
       struct ethtool_pause_stats *pause_stats);
 void (*get_pauseparam)(struct net_device *,
      struct ethtool_pauseparam*);
 int (*set_pauseparam)(struct net_device *,
      struct ethtool_pauseparam*);
 void (*self_test)(struct net_device *, struct ethtool_test *, u64 *);
 void (*get_strings)(struct net_device *, u32 stringset, u8 *);
 int (*set_phys_id)(struct net_device *, enum ethtool_phys_id_state);
 void (*get_ethtool_stats)(struct net_device *,
         struct ethtool_stats *, u64 *);
 int (*begin)(struct net_device *);
 void (*complete)(struct net_device *);
 u32 (*get_priv_flags)(struct net_device *);
 int (*set_priv_flags)(struct net_device *, u32);
 int (*get_sset_count)(struct net_device *, int);
 int (*get_rxnfc)(struct net_device *,
        struct ethtool_rxnfc *, u32 *rule_locs);
 int (*set_rxnfc)(struct net_device *, struct ethtool_rxnfc *);
 int (*flash_device)(struct net_device *, struct ethtool_flash *);
 int (*reset)(struct net_device *, u32 *);
 u32 (*get_rx_ring_count)(struct net_device *dev);
 u32 (*get_rxfh_key_size)(struct net_device *);
 u32 (*get_rxfh_indir_size)(struct net_device *);
 int (*get_rxfh)(struct net_device *, struct ethtool_rxfh_param *);
 int (*set_rxfh)(struct net_device *, struct ethtool_rxfh_param *,
       struct netlink_ext_ack *extack);
 int (*get_rxfh_fields)(struct net_device *,
       struct ethtool_rxfh_fields *);
 int (*set_rxfh_fields)(struct net_device *,
       const struct ethtool_rxfh_fields *,
       struct netlink_ext_ack *extack);
 int (*create_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           const struct ethtool_rxfh_param *rxfh,
           struct netlink_ext_ack *extack);
 int (*modify_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           const struct ethtool_rxfh_param *rxfh,
           struct netlink_ext_ack *extack);
 int (*remove_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           u32 rss_context,
           struct netlink_ext_ack *extack);
 void (*get_channels)(struct net_device *, struct ethtool_channels *);
 int (*set_channels)(struct net_device *, struct ethtool_channels *);
 int (*get_dump_flag)(struct net_device *, struct ethtool_dump *);
 int (*get_dump_data)(struct net_device *,
     struct ethtool_dump *, void *);
 int (*set_dump)(struct net_device *, struct ethtool_dump *);
 int (*get_ts_info)(struct net_device *, struct kernel_ethtool_ts_info *);
 void (*get_ts_stats)(struct net_device *dev,
    struct ethtool_ts_stats *ts_stats);
 int (*get_module_info)(struct net_device *,
       struct ethtool_modinfo *);
 int (*get_module_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*get_eee)(struct net_device *dev, struct ethtool_keee *eee);
 int (*set_eee)(struct net_device *dev, struct ethtool_keee *eee);
 int (*get_tunable)(struct net_device *,
          const struct ethtool_tunable *, void *);
 int (*set_tunable)(struct net_device *,
          const struct ethtool_tunable *, const void *);
 int (*get_per_queue_coalesce)(struct net_device *, u32,
       struct ethtool_coalesce *);
 int (*set_per_queue_coalesce)(struct net_device *, u32,
       struct ethtool_coalesce *);
 int (*get_link_ksettings)(struct net_device *,
          struct ethtool_link_ksettings *);
 int (*set_link_ksettings)(struct net_device *,
          const struct ethtool_link_ksettings *);
 void (*get_fec_stats)(struct net_device *dev,
     struct ethtool_fec_stats *fec_stats,
     struct ethtool_fec_hist *hist);
 int (*get_fecparam)(struct net_device *,
          struct ethtool_fecparam *);
 int (*set_fecparam)(struct net_device *,
          struct ethtool_fecparam *);
 void (*get_ethtool_phy_stats)(struct net_device *,
      struct ethtool_stats *, u64 *);
 int (*get_phy_tunable)(struct net_device *,
       const struct ethtool_tunable *, void *);
 int (*set_phy_tunable)(struct net_device *,
       const struct ethtool_tunable *, const void *);
 int (*get_module_eeprom_by_page)(struct net_device *dev,
          const struct ethtool_module_eeprom *page,
          struct netlink_ext_ack *extack);
 int (*set_module_eeprom_by_page)(struct net_device *dev,
          const struct ethtool_module_eeprom *page,
          struct netlink_ext_ack *extack);
 void (*get_eth_phy_stats)(struct net_device *dev,
         struct ethtool_eth_phy_stats *phy_stats);
 void (*get_eth_mac_stats)(struct net_device *dev,
         struct ethtool_eth_mac_stats *mac_stats);
 void (*get_eth_ctrl_stats)(struct net_device *dev,
          struct ethtool_eth_ctrl_stats *ctrl_stats);
 void (*get_rmon_stats)(struct net_device *dev,
      struct ethtool_rmon_stats *rmon_stats,
      const struct ethtool_rmon_hist_range **ranges);
 int (*get_module_power_mode)(struct net_device *dev,
      struct ethtool_module_power_mode_params *params,
      struct netlink_ext_ack *extack);
 int (*set_module_power_mode)(struct net_device *dev,
      const struct ethtool_module_power_mode_params *params,
      struct netlink_ext_ack *extack);
 int (*get_mm)(struct net_device *dev, struct ethtool_mm_state *state);
 int (*set_mm)(struct net_device *dev, struct ethtool_mm_cfg *cfg,
     struct netlink_ext_ack *extack);
 void (*get_mm_stats)(struct net_device *dev, struct ethtool_mm_stats *stats);
};
struct ethtool_netdev_state {
 struct xarray rss_ctx;
 struct mutex rss_lock;
 unsigned wol_enabled:1;
 unsigned module_fw_flash_in_progress:1;
};
struct phy_device;
struct device;
struct file_operations;
enum nl80211_iftype {
 NL80211_IFTYPE_UNSPECIFIED,
 NL80211_IFTYPE_ADHOC,
 NL80211_IFTYPE_STATION,
 NL80211_IFTYPE_AP,
 NL80211_IFTYPE_AP_VLAN,
 NL80211_IFTYPE_WDS,
 NL80211_IFTYPE_MONITOR,
 NL80211_IFTYPE_MESH_POINT,
 NL80211_IFTYPE_P2P_CLIENT,
 NL80211_IFTYPE_P2P_GO,
 NL80211_IFTYPE_P2P_DEVICE,
 NL80211_IFTYPE_OCB,
 NL80211_IFTYPE_NAN,


 NUM_NL80211_IFTYPES,
 NL80211_IFTYPE_MAX = NUM_NL80211_IFTYPES - 1
};
struct nl80211_sta_flag_update {
 __u32 mask;
 __u32 set;
} __attribute__((packed));
enum nl80211_he_gi {
 NL80211_RATE_INFO_HE_GI_0_8,
 NL80211_RATE_INFO_HE_GI_1_6,
 NL80211_RATE_INFO_HE_GI_3_2,
};
enum nl80211_he_ltf {
 NL80211_RATE_INFO_HE_1XLTF,
 NL80211_RATE_INFO_HE_2XLTF,
 NL80211_RATE_INFO_HE_4XLTF,
};
enum nl80211_eht_gi {
 NL80211_RATE_INFO_EHT_GI_0_8,
 NL80211_RATE_INFO_EHT_GI_1_6,
 NL80211_RATE_INFO_EHT_GI_3_2,
};
enum nl80211_eht_ltf {
 NL80211_RATE_INFO_EHT_1XLTF,
 NL80211_RATE_INFO_EHT_2XLTF,
 NL80211_RATE_INFO_EHT_4XLTF,
 NL80211_RATE_INFO_EHT_6XLTF,
 NL80211_RATE_INFO_EHT_8XLTF,
};
enum nl80211_reg_initiator {
 NL80211_REGDOM_SET_BY_CORE,
 NL80211_REGDOM_SET_BY_USER,
 NL80211_REGDOM_SET_BY_DRIVER,
 NL80211_REGDOM_SET_BY_COUNTRY_IE,
};
enum nl80211_dfs_regions {
 NL80211_DFS_UNSET = 0,
 NL80211_DFS_FCC = 1,
 NL80211_DFS_ETSI = 2,
 NL80211_DFS_JP = 3,
};
enum nl80211_user_reg_hint_type {
 NL80211_USER_REG_HINT_USER = 0,
 NL80211_USER_REG_HINT_CELL_BASE = 1,
 NL80211_USER_REG_HINT_INDOOR = 2,
};
enum nl80211_mesh_power_mode {
 NL80211_MESH_POWER_UNKNOWN,
 NL80211_MESH_POWER_ACTIVE,
 NL80211_MESH_POWER_LIGHT_SLEEP,
 NL80211_MESH_POWER_DEEP_SLEEP,

 __NL80211_MESH_POWER_AFTER_LAST,
 NL80211_MESH_POWER_MAX = __NL80211_MESH_POWER_AFTER_LAST - 1
};
enum nl80211_key_mode {
 NL80211_KEY_RX_TX,
 NL80211_KEY_NO_TX,
 NL80211_KEY_SET_TX
};
enum nl80211_chan_width {
 NL80211_CHAN_WIDTH_20_NOHT,
 NL80211_CHAN_WIDTH_20,
 NL80211_CHAN_WIDTH_40,
 NL80211_CHAN_WIDTH_80,
 NL80211_CHAN_WIDTH_80P80,
 NL80211_CHAN_WIDTH_160,
 NL80211_CHAN_WIDTH_5,
 NL80211_CHAN_WIDTH_10,
 NL80211_CHAN_WIDTH_1,
 NL80211_CHAN_WIDTH_2,
 NL80211_CHAN_WIDTH_4,
 NL80211_CHAN_WIDTH_8,
 NL80211_CHAN_WIDTH_16,
 NL80211_CHAN_WIDTH_320,
};
enum nl80211_auth_type {
 NL80211_AUTHTYPE_OPEN_SYSTEM,
 NL80211_AUTHTYPE_SHARED_KEY,
 NL80211_AUTHTYPE_FT,
 NL80211_AUTHTYPE_NETWORK_EAP,
 NL80211_AUTHTYPE_SAE,
 NL80211_AUTHTYPE_FILS_SK,
 NL80211_AUTHTYPE_FILS_SK_PFS,
 NL80211_AUTHTYPE_FILS_PK,


 __NL80211_AUTHTYPE_NUM,
 NL80211_AUTHTYPE_MAX = __NL80211_AUTHTYPE_NUM - 1,
 NL80211_AUTHTYPE_AUTOMATIC
};
enum nl80211_mfp {
 NL80211_MFP_NO,
 NL80211_MFP_REQUIRED,
 NL80211_MFP_OPTIONAL,
};
enum nl80211_txrate_gi {
 NL80211_TXRATE_DEFAULT_GI,
 NL80211_TXRATE_FORCE_SGI,
 NL80211_TXRATE_FORCE_LGI,
};
enum nl80211_band {
 NL80211_BAND_2GHZ,
 NL80211_BAND_5GHZ,
 NL80211_BAND_60GHZ,
 NL80211_BAND_6GHZ,
 NL80211_BAND_S1GHZ,
 NL80211_BAND_LC,

 NUM_NL80211_BANDS,
};
enum nl80211_tx_power_setting {
 NL80211_TX_POWER_AUTOMATIC,
 NL80211_TX_POWER_LIMITED,
 NL80211_TX_POWER_FIXED,
};
enum nl80211_tid_config {
 NL80211_TID_CONFIG_ENABLE,
 NL80211_TID_CONFIG_DISABLE,
};
enum nl80211_tx_rate_setting {
 NL80211_TX_RATE_AUTOMATIC,
 NL80211_TX_RATE_LIMITED,
 NL80211_TX_RATE_FIXED,
};
struct nl80211_wowlan_tcp_data_seq {
 __u32 start, offset, len;
};
struct nl80211_wowlan_tcp_data_token {
 __u32 offset, len;
 __u8 token_stream[1];
};
struct nl80211_wowlan_tcp_data_token_feature {
 __u32 min_len, max_len, bufsize;
};
enum nl80211_ext_feature_index {
 NL80211_EXT_FEATURE_VHT_IBSS,
 NL80211_EXT_FEATURE_RRM,
 NL80211_EXT_FEATURE_MU_MIMO_AIR_SNIFFER,
 NL80211_EXT_FEATURE_SCAN_START_TIME,
 NL80211_EXT_FEATURE_BSS_PARENT_TSF,
 NL80211_EXT_FEATURE_SET_SCAN_DWELL,
 NL80211_EXT_FEATURE_BEACON_RATE_LEGACY,
 NL80211_EXT_FEATURE_BEACON_RATE_HT,
 NL80211_EXT_FEATURE_BEACON_RATE_VHT,
 NL80211_EXT_FEATURE_FILS_STA,
 NL80211_EXT_FEATURE_MGMT_TX_RANDOM_TA,
 NL80211_EXT_FEATURE_MGMT_TX_RANDOM_TA_CONNECTED,
 NL80211_EXT_FEATURE_SCHED_SCAN_RELATIVE_RSSI,
 NL80211_EXT_FEATURE_CQM_RSSI_LIST,
 NL80211_EXT_FEATURE_FILS_SK_OFFLOAD,
 NL80211_EXT_FEATURE_4WAY_HANDSHAKE_STA_PSK,
 NL80211_EXT_FEATURE_4WAY_HANDSHAKE_STA_1X,
 NL80211_EXT_FEATURE_FILS_MAX_CHANNEL_TIME,
 NL80211_EXT_FEATURE_ACCEPT_BCAST_PROBE_RESP,
 NL80211_EXT_FEATURE_OCE_PROBE_REQ_HIGH_TX_RATE,
 NL80211_EXT_FEATURE_OCE_PROBE_REQ_DEFERRAL_SUPPRESSION,
 NL80211_EXT_FEATURE_MFP_OPTIONAL,
 NL80211_EXT_FEATURE_LOW_SPAN_SCAN,
 NL80211_EXT_FEATURE_LOW_POWER_SCAN,
 NL80211_EXT_FEATURE_HIGH_ACCURACY_SCAN,
 NL80211_EXT_FEATURE_DFS_OFFLOAD,
 NL80211_EXT_FEATURE_CONTROL_PORT_OVER_NL80211,
 NL80211_EXT_FEATURE_ACK_SIGNAL_SUPPORT,

 NL80211_EXT_FEATURE_DATA_ACK_SIGNAL_SUPPORT = NL80211_EXT_FEATURE_ACK_SIGNAL_SUPPORT,
 NL80211_EXT_FEATURE_TXQS,
 NL80211_EXT_FEATURE_SCAN_RANDOM_SN,
 NL80211_EXT_FEATURE_SCAN_MIN_PREQ_CONTENT,
 NL80211_EXT_FEATURE_CAN_REPLACE_PTK0,
 NL80211_EXT_FEATURE_ENABLE_FTM_RESPONDER,
 NL80211_EXT_FEATURE_AIRTIME_FAIRNESS,
 NL80211_EXT_FEATURE_AP_PMKSA_CACHING,
 NL80211_EXT_FEATURE_SCHED_SCAN_BAND_SPECIFIC_RSSI_THOLD,
 NL80211_EXT_FEATURE_EXT_KEY_ID,
 NL80211_EXT_FEATURE_STA_TX_PWR,
 NL80211_EXT_FEATURE_SAE_OFFLOAD,
 NL80211_EXT_FEATURE_VLAN_OFFLOAD,
 NL80211_EXT_FEATURE_AQL,
 NL80211_EXT_FEATURE_BEACON_PROTECTION,
 NL80211_EXT_FEATURE_CONTROL_PORT_NO_PREAUTH,
 NL80211_EXT_FEATURE_PROTECTED_TWT,
 NL80211_EXT_FEATURE_DEL_IBSS_STA,
 NL80211_EXT_FEATURE_MULTICAST_REGISTRATIONS,
 NL80211_EXT_FEATURE_BEACON_PROTECTION_CLIENT,
 NL80211_EXT_FEATURE_SCAN_FREQ_KHZ,
 NL80211_EXT_FEATURE_CONTROL_PORT_OVER_NL80211_TX_STATUS,
 NL80211_EXT_FEATURE_OPERATING_CHANNEL_VALIDATION,
 NL80211_EXT_FEATURE_4WAY_HANDSHAKE_AP_PSK,
 NL80211_EXT_FEATURE_SAE_OFFLOAD_AP,
 NL80211_EXT_FEATURE_FILS_DISCOVERY,
 NL80211_EXT_FEATURE_UNSOL_BCAST_PROBE_RESP,
 NL80211_EXT_FEATURE_BEACON_RATE_HE,
 NL80211_EXT_FEATURE_SECURE_LTF,
 NL80211_EXT_FEATURE_SECURE_RTT,
 NL80211_EXT_FEATURE_PROT_RANGE_NEGO_AND_MEASURE,
 NL80211_EXT_FEATURE_BSS_COLOR,
 NL80211_EXT_FEATURE_FILS_CRYPTO_OFFLOAD,
 NL80211_EXT_FEATURE_RADAR_BACKGROUND,
 NL80211_EXT_FEATURE_POWERED_ADDR_CHANGE,
 NL80211_EXT_FEATURE_PUNCT,
 NL80211_EXT_FEATURE_SECURE_NAN,
 NL80211_EXT_FEATURE_AUTH_AND_DEAUTH_RANDOM_TA,
 NL80211_EXT_FEATURE_OWE_OFFLOAD,
 NL80211_EXT_FEATURE_OWE_OFFLOAD_AP,
 NL80211_EXT_FEATURE_DFS_CONCURRENT,
 NL80211_EXT_FEATURE_SPP_AMSDU_SUPPORT,
 NL80211_EXT_FEATURE_BEACON_RATE_EHT,


 NUM_NL80211_EXT_FEATURES,
 MAX_NL80211_EXT_FEATURES = NUM_NL80211_EXT_FEATURES - 1
};
enum nl80211_dfs_state {
 NL80211_DFS_USABLE,
 NL80211_DFS_UNAVAILABLE,
 NL80211_DFS_AVAILABLE,
};
struct nl80211_vendor_cmd_info {
 __u32 vendor_id;
 __u32 subcmd;
};
enum nl80211_bss_select_attr {
 __NL80211_BSS_SELECT_ATTR_INVALID,
 NL80211_BSS_SELECT_ATTR_RSSI,
 NL80211_BSS_SELECT_ATTR_BAND_PREF,
 NL80211_BSS_SELECT_ATTR_RSSI_ADJUST,


 __NL80211_BSS_SELECT_ATTR_AFTER_LAST,
 NL80211_BSS_SELECT_ATTR_MAX = __NL80211_BSS_SELECT_ATTR_AFTER_LAST - 1
};
enum nl80211_nan_function_type {
 NL80211_NAN_FUNC_PUBLISH,
 NL80211_NAN_FUNC_SUBSCRIBE,
 NL80211_NAN_FUNC_FOLLOW_UP,


 __NL80211_NAN_FUNC_TYPE_AFTER_LAST,
 NL80211_NAN_FUNC_MAX_TYPE = __NL80211_NAN_FUNC_TYPE_AFTER_LAST - 1,
};
enum nl80211_preamble {
 NL80211_PREAMBLE_LEGACY,
 NL80211_PREAMBLE_HT,
 NL80211_PREAMBLE_VHT,
 NL80211_PREAMBLE_DMG,
 NL80211_PREAMBLE_HE,
};
enum nl80211_sae_pwe_mechanism {
 NL80211_SAE_PWE_UNSPECIFIED,
 NL80211_SAE_PWE_HUNT_AND_PECK,
 NL80211_SAE_PWE_HASH_TO_ELEMENT,
 NL80211_SAE_PWE_BOTH,
};
enum nl80211_sar_type {
 NL80211_SAR_TYPE_POWER,




 NUM_NL80211_SAR_TYPE,
};
struct attribute_group;
struct device_node;
struct fwnode_handle;
struct kernfs_node;
struct device;
struct rfkill;
enum environment_cap {
 ENVIRON_ANY,
 ENVIRON_INDOOR,
 ENVIRON_OUTDOOR,
};
struct regulatory_request {
 struct callback_head callback_head;
 int wiphy_idx;
 enum nl80211_reg_initiator initiator;
 enum nl80211_user_reg_hint_type user_reg_hint_type;
 char alpha2[3];
 enum nl80211_dfs_regions dfs_region;
 bool intersect;
 bool processed;
 enum environment_cap country_ie_env;
 struct list_head list;
};
struct ieee80211_freq_range {
 u32 start_freq_khz;
 u32 end_freq_khz;
 u32 max_bandwidth_khz;
};
struct ieee80211_power_rule {
 u32 max_antenna_gain;
 u32 max_eirp;
};
struct ieee80211_wmm_ac {
 u16 cw_min;
 u16 cw_max;
 u16 cot;
 u8 aifsn;
};
struct ieee80211_wmm_rule {
 struct ieee80211_wmm_ac client[4];
 struct ieee80211_wmm_ac ap[4];
};
struct ieee80211_reg_rule {
 struct ieee80211_freq_range freq_range;
 struct ieee80211_power_rule power_rule;
 struct ieee80211_wmm_rule wmm_rule;
 u32 flags;
 u32 dfs_cac_ms;
 bool has_wmm;
 s8 psd;
};
struct ieee80211_regdomain {
 struct callback_head callback_head;
 u32 n_reg_rules;
 char alpha2[3];
 enum nl80211_dfs_regions dfs_region;
 struct ieee80211_reg_rule reg_rules[1];
};
struct wiphy;
struct ieee80211_channel {
 enum nl80211_band band;
 u32 center_freq;
 u16 freq_offset;
 u16 hw_value;
 u32 flags;
 int max_antenna_gain;
 int max_power;
 int max_reg_power;
 bool beacon_found;
 u32 orig_flags;
 int orig_mag, orig_mpwr;
 enum nl80211_dfs_state dfs_state;
 unsigned long dfs_state_entered;
 unsigned int dfs_cac_ms;
 s8 psd;
};
enum ieee80211_bss_type {
 IEEE80211_BSS_TYPE_ESS,
 IEEE80211_BSS_TYPE_PBSS,
 IEEE80211_BSS_TYPE_IBSS,
 IEEE80211_BSS_TYPE_MBSS,
 IEEE80211_BSS_TYPE_ANY
};
struct ieee80211_rate {
 u32 flags;
 u16 bitrate;
 u16 hw_value, hw_value_short;
};
struct ieee80211_he_obss_pd {
 bool enable;
 u8 sr_ctrl;
 u8 non_srg_max_offset;
 u8 min_offset;
 u8 max_offset;
 u8 bss_color_bitmap[8];
 u8 partial_bssid_bitmap[8];
};
struct cfg80211_he_bss_color {
 u8 color;
 bool enabled;
 bool partial;
};
struct ieee80211_sta_ht_cap {
 u16 cap;
 bool ht_supported;
 u8 ampdu_factor;
 u8 ampdu_density;
 struct ieee80211_mcs_info mcs;
};
struct ieee80211_sta_vht_cap {
 bool vht_supported;
 u32 cap;
 struct ieee80211_vht_mcs_info vht_mcs;
};
struct ieee80211_sta_he_cap {
 bool has_he;
 struct ieee80211_he_cap_elem he_cap_elem;
 struct ieee80211_he_mcs_nss_supp he_mcs_nss_supp;
 u8 ppe_thres[25];
};
struct ieee80211_eht_mcs_nss_supp {
 union {
  struct ieee80211_eht_mcs_nss_supp_20mhz_only only_20mhz;
  struct {
   struct ieee80211_eht_mcs_nss_supp_bw _80;
   struct ieee80211_eht_mcs_nss_supp_bw _160;
   struct ieee80211_eht_mcs_nss_supp_bw _320;
  } __attribute__((__packed__)) bw;
 } __attribute__((__packed__));
} __attribute__((__packed__));
struct ieee80211_sta_eht_cap {
 bool has_eht;
 struct ieee80211_eht_cap_elem_fixed eht_cap_elem;
 struct ieee80211_eht_mcs_nss_supp eht_mcs_nss_supp;
 u8 eht_ppe_thres[32];
};
struct ieee80211_sta_uhr_cap {
 bool has_uhr;
 struct ieee80211_uhr_cap_mac mac;
 struct ieee80211_uhr_cap_phy phy;
};
struct ieee80211_sband_iftype_data {
 u16 types_mask;
 struct ieee80211_sta_he_cap he_cap;
 struct ieee80211_he_6ghz_capa he_6ghz_capa;
 struct ieee80211_sta_eht_cap eht_cap;
 struct ieee80211_sta_uhr_cap uhr_cap;
 struct {
  const u8 *data;
  unsigned int len;
 } vendor_elems;
};
enum ieee80211_edmg_bw_config {
 IEEE80211_EDMG_BW_CONFIG_4 = 4,
 IEEE80211_EDMG_BW_CONFIG_5 = 5,
 IEEE80211_EDMG_BW_CONFIG_6 = 6,
 IEEE80211_EDMG_BW_CONFIG_7 = 7,
 IEEE80211_EDMG_BW_CONFIG_8 = 8,
 IEEE80211_EDMG_BW_CONFIG_9 = 9,
 IEEE80211_EDMG_BW_CONFIG_10 = 10,
 IEEE80211_EDMG_BW_CONFIG_11 = 11,
 IEEE80211_EDMG_BW_CONFIG_12 = 12,
 IEEE80211_EDMG_BW_CONFIG_13 = 13,
 IEEE80211_EDMG_BW_CONFIG_14 = 14,
 IEEE80211_EDMG_BW_CONFIG_15 = 15,
};
struct ieee80211_edmg {
 u8 channels;
 enum ieee80211_edmg_bw_config bw_config;
};
struct ieee80211_sta_s1g_cap {
 bool s1g;
 u8 cap[10];
 u8 nss_mcs[5];
};
struct ieee80211_supported_band {
 struct ieee80211_channel *channels;
 struct ieee80211_rate *bitrates;
 enum nl80211_band band;
 int n_channels;
 int n_bitrates;
 struct ieee80211_sta_ht_cap ht_cap;
 struct ieee80211_sta_vht_cap vht_cap;
 struct ieee80211_sta_s1g_cap s1g_cap;
 struct ieee80211_edmg edmg_cap;
 u16 n_iftype_data;
 const struct ieee80211_sband_iftype_data *iftype_data;
};
struct key_params {
 const u8 *key;
 const u8 *seq;
 int key_len;
 int seq_len;
 u16 vlan_id;
 u32 cipher;
 enum nl80211_key_mode mode;
};
struct cfg80211_chan_def {
 struct ieee80211_channel *chan;
 enum nl80211_chan_width width;
 u32 center_freq1;
 u32 center_freq2;
 struct ieee80211_edmg edmg;
 u16 freq1_offset;
 u16 punctured;
 bool s1g_primary_2mhz;
};
struct cfg80211_bitrate_mask {
 struct {
  u32 legacy;
  u8 ht_mcs[10];
  u16 vht_mcs[8];
  u16 he_mcs[8];
  u16 eht_mcs[16];
  enum nl80211_txrate_gi gi;
  enum nl80211_he_gi he_gi;
  enum nl80211_eht_gi eht_gi;
  enum nl80211_he_ltf he_ltf;
  enum nl80211_eht_ltf eht_ltf;
 } control[NUM_NL80211_BANDS];
};
struct cfg80211_tid_cfg {
 bool config_override;
 u8 tids;
 u64 mask;
 enum nl80211_tid_config noack;
 u8 retry_long, retry_short;
 enum nl80211_tid_config ampdu;
 enum nl80211_tid_config rtscts;
 enum nl80211_tid_config amsdu;
 enum nl80211_tx_rate_setting txrate_type;
 struct cfg80211_bitrate_mask txrate_mask;
};
struct cfg80211_tid_config {
 const u8 *peer;
 u32 n_tid_conf;
 struct cfg80211_tid_cfg tid_conf[1] ;
};
struct cfg80211_set_hw_timestamp {
 const u8 *macaddr;
 bool enable;
};
struct survey_info {
 struct ieee80211_channel *channel;
 u64 time;
 u64 time_busy;
 u64 time_ext_busy;
 u64 time_rx;
 u64 time_tx;
 u64 time_scan;
 u64 time_bss_rx;
 u32 filled;
 s8 noise;
};
struct cfg80211_crypto_settings {
 u32 wpa_versions;
 u32 cipher_group;
 int n_ciphers_pairwise;
 u32 ciphers_pairwise[5];
 int n_akm_suites;
 u32 akm_suites[10];
 bool control_port;
 __be16 control_port_ethertype;
 bool control_port_no_encrypt;
 bool control_port_over_nl80211;
 bool control_port_no_preauth;
 const u8 *psk;
 const u8 *sae_pwd;
 u8 sae_pwd_len;
 enum nl80211_sae_pwe_mechanism sae_pwe;
};
struct mac_address {
 u8 addr[6];
};
struct rate_info {
 u16 flags;
 u16 legacy;
 u8 mcs;
 u8 nss;
 u8 bw;
 u8 he_gi;
 u8 he_dcm;
 u8 he_ru_alloc;
 u8 n_bonded_ch;
 u8 eht_gi;
 u8 eht_ru_alloc;
};
struct sta_bss_parameters {
 u8 flags;
 u8 dtim_period;
 u16 beacon_interval;
};
struct cfg80211_txq_stats {
 u32 filled;
 u32 backlog_bytes;
 u32 backlog_packets;
 u32 flows;
 u32 drops;
 u32 ecn_marks;
 u32 overlimit;
 u32 overmemory;
 u32 collisions;
 u32 tx_bytes;
 u32 tx_packets;
 u32 max_flows;
};
struct cfg80211_tid_stats {
 u32 filled;
 u64 rx_msdu;
 u64 tx_msdu;
 u64 tx_msdu_retries;
 u64 tx_msdu_failed;
 struct cfg80211_txq_stats txq_stats;
};
struct link_station_info {
 u64 filled;
 u32 connected_time;
 u32 inactive_time;
 u64 assoc_at;
 u64 rx_bytes;
 u64 tx_bytes;
 s8 signal;
 s8 signal_avg;

 u8 chains;
 s8 chain_signal[4];
 s8 chain_signal_avg[4];

 struct rate_info txrate;
 struct rate_info rxrate;
 u32 rx_packets;
 u32 tx_packets;
 u32 tx_retries;
 u32 tx_failed;
 u32 rx_dropped_misc;
 struct sta_bss_parameters bss_param;

 u32 beacon_loss_count;

 u32 expected_throughput;

 u64 tx_duration;
 u64 rx_duration;
 u64 rx_beacon;
 u8 rx_beacon_signal_avg;

 u16 airtime_weight;

 s8 ack_signal;
 s8 avg_ack_signal;
 struct cfg80211_tid_stats *pertid;

 u32 rx_mpdu_count;
 u32 fcs_err_count;

 u8 addr[6] ;
};
struct station_info {
 u64 filled;
 u32 connected_time;
 u32 inactive_time;
 u64 assoc_at;
 u64 rx_bytes;
 u64 tx_bytes;
 s8 signal;
 s8 signal_avg;

 u8 chains;
 s8 chain_signal[4];
 s8 chain_signal_avg[4];

 struct rate_info txrate;
 struct rate_info rxrate;
 u32 rx_packets;
 u32 tx_packets;
 u32 tx_retries;
 u32 tx_failed;
 u32 rx_dropped_misc;
 struct sta_bss_parameters bss_param;
 struct nl80211_sta_flag_update sta_flags;

 int generation;

 u32 beacon_loss_count;

 const u8 *assoc_req_ies;
 size_t assoc_req_ies_len;

 s64 t_offset;
 u16 llid;
 u16 plid;
 u8 plink_state;
 u8 connected_to_gate;
 u8 connected_to_as;
 u32 airtime_link_metric;
 enum nl80211_mesh_power_mode local_pm;
 enum nl80211_mesh_power_mode peer_pm;
 enum nl80211_mesh_power_mode nonpeer_pm;

 u32 expected_throughput;

 u16 airtime_weight;

 s8 ack_signal;
 s8 avg_ack_signal;
 struct cfg80211_tid_stats *pertid;

 u64 tx_duration;
 u64 rx_duration;
 u64 rx_beacon;
 u8 rx_beacon_signal_avg;

 u32 rx_mpdu_count;
 u32 fcs_err_count;

 bool mlo_params_valid;
 u8 assoc_link_id;
 u8 mld_addr[6] ;
 const u8 *assoc_resp_ies;
 size_t assoc_resp_ies_len;

 u16 valid_links;
 struct link_station_info *links[15];
};
struct cfg80211_sar_sub_specs {
 s32 power;
 u32 freq_range_index;
};
struct cfg80211_sar_specs {
 enum nl80211_sar_type type;
 u32 num_sub_specs;
 struct cfg80211_sar_sub_specs sub_specs[1] ;
};
struct cfg80211_sar_freq_ranges {
 u32 start_freq;
 u32 end_freq;
};
struct cfg80211_sar_capa {
 enum nl80211_sar_type type;
 u32 num_freq_ranges;
 const struct cfg80211_sar_freq_ranges *freq_ranges;
};
struct cfg80211_ssid {
 u8 ssid[32];
 u8 ssid_len;
};
struct cfg80211_scan_6ghz_params {
 u32 short_ssid;
 u32 channel_idx;
 u8 bssid[6];
 bool unsolicited_probe;
 bool short_ssid_valid;
 bool psc_no_listen;
 s8 psd_20;
};
struct cfg80211_scan_request {
 struct cfg80211_ssid *ssids;
 int n_ssids;
 u32 n_channels;
 const u8 *ie;
 size_t ie_len;
 u16 duration;
 bool duration_mandatory;
 u32 flags;

 u32 rates[NUM_NL80211_BANDS];

 struct wireless_dev *wdev;

 u8 mac_addr[6] ;
 u8 mac_addr_mask[6] ;
 u8 bssid[6] ;
 struct wiphy *wiphy;
 unsigned long scan_start;
 bool no_cck;
 bool scan_6ghz;
 bool first_part;
 u32 n_6ghz_params;
 struct cfg80211_scan_6ghz_params *scan_6ghz_params;
 s8 tsf_report_link_id;


 struct ieee80211_channel *channels[1];
};
struct cfg80211_match_set {
 struct cfg80211_ssid ssid;
 u8 bssid[6];
 s32 rssi_thold;
};
struct cfg80211_sched_scan_plan {
 u32 interval;
 u32 iterations;
};
struct cfg80211_bss_select_adjust {
 enum nl80211_band band;
 s8 delta;
};
struct cfg80211_sched_scan_request {
 u64 reqid;
 struct cfg80211_ssid *ssids;
 int n_ssids;
 u32 n_channels;
 const u8 *ie;
 size_t ie_len;
 u32 flags;
 struct cfg80211_match_set *match_sets;
 int n_match_sets;
 s32 min_rssi_thold;
 u32 delay;
 struct cfg80211_sched_scan_plan *scan_plans;
 int n_scan_plans;

 u8 mac_addr[6] ;
 u8 mac_addr_mask[6] ;

 bool relative_rssi_set;
 s8 relative_rssi;
 struct cfg80211_bss_select_adjust rssi_adjust;


 struct wiphy *wiphy;
 struct net_device *dev;
 unsigned long scan_start;
 bool report_results;
 struct callback_head callback_head;
 u32 owner_nlportid;
 bool nl_owner_dead;
 struct list_head list;


 struct ieee80211_channel *channels[1] ;
};
enum cfg80211_signal_type {
 CFG80211_SIGNAL_TYPE_NONE,
 CFG80211_SIGNAL_TYPE_MBM,
 CFG80211_SIGNAL_TYPE_UNSPEC,
};
struct cfg80211_bss_ies {
 u64 tsf;
 struct callback_head callback_head;
 int len;
 bool from_beacon;
 u8 data[1];
};
struct cfg80211_bss {
 struct ieee80211_channel *channel;

 const struct cfg80211_bss_ies *ies;
 const struct cfg80211_bss_ies *beacon_ies;
 const struct cfg80211_bss_ies *proberesp_ies;

 struct cfg80211_bss *hidden_beacon_bss;
 struct cfg80211_bss *transmitted_bss;
 struct list_head nontrans_list;

 s32 signal;

 u64 ts_boottime;

 u16 beacon_interval;
 u16 capability;

 u8 bssid[6];
 u8 chains;
 s8 chain_signal[4];

 u8 proberesp_ecsa_stuck:1;

 u8 bssid_index;
 u8 max_bssid_indicator;

 u8 use_for;
 u8 cannot_use_reasons;

 u8 priv[1] ;
};
struct cfg80211_ibss_params {
 const u8 *ssid;
 const u8 *bssid;
 struct cfg80211_chan_def chandef;
 const u8 *ie;
 u8 ssid_len, ie_len;
 u16 beacon_interval;
 u32 basic_rates;
 bool channel_fixed;
 bool privacy;
 bool control_port;
 bool control_port_over_nl80211;
 bool userspace_handles_dfs;
 int mcast_rate[NUM_NL80211_BANDS];
 struct ieee80211_ht_cap ht_capa;
 struct ieee80211_ht_cap ht_capa_mask;
 struct key_params *wep_keys;
 int wep_tx_key;
};
struct cfg80211_bss_selection {
 enum nl80211_bss_select_attr behaviour;
 union {
  enum nl80211_band band_pref;
  struct cfg80211_bss_select_adjust adjust;
 } param;
};
struct cfg80211_connect_params {
 struct ieee80211_channel *channel;
 struct ieee80211_channel *channel_hint;
 const u8 *bssid;
 const u8 *bssid_hint;
 const u8 *ssid;
 size_t ssid_len;
 enum nl80211_auth_type auth_type;
 const u8 *ie;
 size_t ie_len;
 bool privacy;
 enum nl80211_mfp mfp;
 struct cfg80211_crypto_settings crypto;
 const u8 *key;
 u8 key_len, key_idx;
 u32 flags;
 int bg_scan_period;
 struct ieee80211_ht_cap ht_capa;
 struct ieee80211_ht_cap ht_capa_mask;
 struct ieee80211_vht_cap vht_capa;
 struct ieee80211_vht_cap vht_capa_mask;
 bool pbss;
 struct cfg80211_bss_selection bss_select;
 const u8 *prev_bssid;
 const u8 *fils_erp_username;
 size_t fils_erp_username_len;
 const u8 *fils_erp_realm;
 size_t fils_erp_realm_len;
 u16 fils_erp_next_seq_num;
 const u8 *fils_erp_rrk;
 size_t fils_erp_rrk_len;
 bool want_1x;
 struct ieee80211_edmg edmg;
};
struct cfg80211_pkt_pattern {
 const u8 *mask, *pattern;
 int pattern_len;
 int pkt_offset;
};
struct cfg80211_wowlan_tcp {
 struct socket *sock;
 __be32 src, dst;
 u16 src_port, dst_port;
 u8 dst_mac[6];
 int payload_len;
 const u8 *payload;
 struct nl80211_wowlan_tcp_data_seq payload_seq;
 u32 data_interval;
 u32 wake_len;
 const u8 *wake_data, *wake_mask;
 u32 tokens_size;

 struct nl80211_wowlan_tcp_data_token payload_tok;
};
struct cfg80211_wowlan {
 bool any, disconnect, magic_pkt, gtk_rekey_failure,
      eap_identity_req, four_way_handshake,
      rfkill_release;
 struct cfg80211_pkt_pattern *patterns;
 struct cfg80211_wowlan_tcp *tcp;
 int n_patterns;
 struct cfg80211_sched_scan_request *nd_config;
};
struct cfg80211_gtk_rekey_data {
 const u8 *kek, *kck, *replay_ctr;
 u32 akm;
 u8 kek_len, kck_len;
};
struct cfg80211_nan_band_config {
 struct ieee80211_channel *chan;
 s8 rssi_close;
 s8 rssi_middle;
 u8 awake_dw_interval;
 bool disable_scan;
};
struct cfg80211_nan_conf {
 u8 master_pref;
 u8 bands;
 const u8 *cluster_id;
 u16 scan_period;
 u16 scan_dwell_time;
 u8 discovery_beacon_interval;
 bool enable_dw_notification;
 struct cfg80211_nan_band_config band_cfgs[NUM_NL80211_BANDS];
 const u8 *extra_nan_attrs;
 u16 extra_nan_attrs_len;
 const u8 *vendor_elems;
 u16 vendor_elems_len;
};
struct cfg80211_nan_func_filter {
 const u8 *filter;
 u8 len;
};
struct cfg80211_nan_func {
 enum nl80211_nan_function_type type;
 u8 service_id[6];
 u8 publish_type;
 bool close_range;
 bool publish_bcast;
 bool subscribe_active;
 u8 followup_id;
 u8 followup_reqid;
 struct mac_address followup_dest;
 u32 ttl;
 const u8 *serv_spec_info;
 u8 serv_spec_info_len;
 bool srf_include;
 const u8 *srf_bf;
 u8 srf_bf_len;
 u8 srf_bf_idx;
 struct mac_address *srf_macs;
 int srf_num_macs;
 struct cfg80211_nan_func_filter *rx_filters;
 struct cfg80211_nan_func_filter *tx_filters;
 u8 num_tx_filters;
 u8 num_rx_filters;
 u8 instance_id;
 u64 cookie;
};
struct cfg80211_ftm_responder_stats {
 u32 filled;
 u32 success_num;
 u32 partial_num;
 u32 failed_num;
 u32 asap_num;
 u32 non_asap_num;
 u64 total_duration_ms;
 u32 unknown_triggers_num;
 u32 reschedule_requests_num;
 u32 out_of_window_triggers_num;
};
struct cfg80211_pmsr_ftm_request_peer {
 enum nl80211_preamble preamble;
 u16 burst_period;
 u8 requested:1,
    asap:1,
    request_lci:1,
    request_civicloc:1,
    trigger_based:1,
    non_trigger_based:1,
    lmr_feedback:1;
 u8 num_bursts_exp;
 u8 burst_duration;
 u8 ftms_per_burst;
 u8 ftmr_retries;
 u8 bss_color;
};
struct cfg80211_pmsr_request_peer {
 u8 addr[6];
 struct cfg80211_chan_def chandef;
 u8 report_ap_tsf:1;
 struct cfg80211_pmsr_ftm_request_peer ftm;
};
struct cfg80211_pmsr_request {
 u64 cookie;
 void *drv_data;
 u32 n_peers;
 u32 nl_portid;

 u32 timeout;

 u8 mac_addr[6] ;
 u8 mac_addr_mask[6] ;

 struct list_head list;

 struct cfg80211_pmsr_request_peer peers[1] ;
};
struct ieee80211_iface_limit {
 u16 max;
 u16 types;
};
struct ieee80211_iface_combination {




 const struct ieee80211_iface_limit *limits;





 u32 num_different_channels;





 u16 max_interfaces;





 u8 n_limits;






 bool beacon_int_infra_match;





 u8 radar_detect_widths;





 u8 radar_detect_regions;
 u32 beacon_int_min_gcd;
};
struct ieee80211_txrx_stypes {
 u16 tx, rx;
};
struct wiphy_wowlan_tcp_support {
 const struct nl80211_wowlan_tcp_data_token_feature *tok;
 u32 data_payload_max;
 u32 data_interval_max;
 u32 wake_payload_max;
 bool seq;
};
struct wiphy_wowlan_support {
 u32 flags;
 int n_patterns;
 int pattern_max_len;
 int pattern_min_len;
 int max_pkt_offset;
 int max_nd_match_sets;
 const struct wiphy_wowlan_tcp_support *tcp;
};
struct wiphy_coalesce_support {
 int n_rules;
 int max_delay;
 int n_patterns;
 int pattern_max_len;
 int pattern_min_len;
 int max_pkt_offset;
};
struct wiphy_vendor_command {
 struct nl80211_vendor_cmd_info info;
 u32 flags;
 int (*doit)(struct wiphy *wiphy, struct wireless_dev *wdev,
      const void *data, int data_len);
 int (*dumpit)(struct wiphy *wiphy, struct wireless_dev *wdev,
        struct sk_buff *skb, const void *data, int data_len,
        unsigned long *storage);
 const struct nla_policy *policy;
 unsigned int maxattr;
};
struct wiphy_iftype_ext_capab {
 enum nl80211_iftype iftype;
 const u8 *extended_capabilities;
 const u8 *extended_capabilities_mask;
 u8 extended_capabilities_len;
 u16 eml_capabilities;
 u16 mld_capa_and_ops;
};
struct cfg80211_pmsr_capabilities {
 unsigned int max_peers;
 u8 report_ap_tsf:1,
    randomize_mac_addr:1;

 struct {
  u32 preambles;
  u32 bandwidths;
  s8 max_bursts_exponent;
  u8 max_ftms_per_burst;
  u8 supported:1,
     asap:1,
     non_asap:1,
     request_lci:1,
     request_civicloc:1,
     trigger_based:1,
     non_trigger_based:1;
 } ftm;
};
struct wiphy_iftype_akm_suites {
 u16 iftypes_mask;
 const u32 *akm_suites;
 int n_akm_suites;
};
struct wiphy_radio_cfg {
 u32 rts_threshold;
};
struct wiphy_radio_freq_range {
 u32 start_freq;
 u32 end_freq;
};
struct wiphy_radio {
 const struct wiphy_radio_freq_range *freq_range;
 int n_freq_range;

 const struct ieee80211_iface_combination *iface_combinations;
 int n_iface_combinations;

 u32 antenna_mask;
};
struct wiphy_nan_capa {
 u32 flags;
 u8 op_mode;
 u8 n_antennas;
 u16 max_channel_switch_time;
 u8 dev_capabilities;
};
struct wiphy {
 struct mutex mtx;



 u8 perm_addr[6];
 u8 addr_mask[6];

 struct mac_address *addresses;

 const struct ieee80211_txrx_stypes *mgmt_stypes;

 const struct ieee80211_iface_combination *iface_combinations;
 int n_iface_combinations;
 u16 software_iftypes;

 u16 n_addresses;


 u16 interface_modes;

 u16 max_acl_mac_addrs;

 u32 flags, regulatory_flags, features;
 u8 ext_features[(((NUM_NL80211_EXT_FEATURES) + (8) - 1) / (8))];

 u32 ap_sme_capa;

 enum cfg80211_signal_type signal_type;

 int bss_priv_size;
 u8 max_scan_ssids;
 u8 max_sched_scan_reqs;
 u8 max_sched_scan_ssids;
 u8 max_match_sets;
 u16 max_scan_ie_len;
 u16 max_sched_scan_ie_len;
 u32 max_sched_scan_plans;
 u32 max_sched_scan_plan_interval;
 u32 max_sched_scan_plan_iterations;

 int n_cipher_suites;
 const u32 *cipher_suites;

 int n_akm_suites;
 const u32 *akm_suites;

 const struct wiphy_iftype_akm_suites *iftype_akm_suites;
 unsigned int num_iftype_akm_suites;

 u8 retry_short;
 u8 retry_long;
 u32 frag_threshold;
 u32 rts_threshold;
 u8 coverage_class;

 char fw_version[32];
 u32 hw_version;


 const struct wiphy_wowlan_support *wowlan;
 struct cfg80211_wowlan *wowlan_config;


 u16 max_remain_on_channel_duration;

 u8 max_num_pmkids;

 u32 available_antennas_tx;
 u32 available_antennas_rx;

 u32 probe_resp_offload;

 const u8 *extended_capabilities, *extended_capabilities_mask;
 u8 extended_capabilities_len;

 const struct wiphy_iftype_ext_capab *iftype_ext_capab;
 unsigned int num_iftype_ext_capab;

 const void *privid;

 struct ieee80211_supported_band *bands[NUM_NL80211_BANDS];

 void (*reg_notifier)(struct wiphy *wiphy,
        struct regulatory_request *request);

 struct wiphy_radio_cfg *radio_cfg;



 const struct ieee80211_regdomain *regd;

 struct device dev;

 bool registered;

 struct dentry *debugfsdir;

 const struct ieee80211_ht_cap *ht_capa_mod_mask;
 const struct ieee80211_vht_cap *vht_capa_mod_mask;

 struct list_head wdev_list;

 possible_net_t _net;


 const struct iw_handler_def *wext;


 const struct wiphy_coalesce_support *coalesce;

 const struct wiphy_vendor_command *vendor_commands;
 const struct nl80211_vendor_cmd_info *vendor_events;
 int n_vendor_commands, n_vendor_events;

 u16 max_ap_assoc_sta;

 u8 max_num_csa_counters;

 u32 bss_param_support;
 u32 bss_select_support;

 u8 nan_supported_bands;
 struct wiphy_nan_capa nan_capa;

 u32 txq_limit;
 u32 txq_memory_limit;
 u32 txq_quantum;

 unsigned long tx_queue_len;

 u8 support_mbssid:1,
    support_only_he_mbssid:1;

 const struct cfg80211_pmsr_capabilities *pmsr_capa;

 struct {
  u64 peer, vif;
  u8 max_retry;
 } tid_config_support;

 u8 max_data_retry_count;

 const struct cfg80211_sar_capa *sar_capa;

 struct rfkill *rfkill;

 u8 mbssid_max_interfaces;
 u8 ema_max_profile_periodicity;
 u16 max_num_akm_suites;

 u16 hw_timestamp_max_peers;

 int n_radio;
 const struct wiphy_radio *radio;

 char priv[1] ;
};
struct cfg80211_conn;
struct cfg80211_internal_bss;
struct cfg80211_cached_keys;
struct cfg80211_cqm_config;
struct wiphy_work;
typedef void (*wiphy_work_func_t)(struct wiphy *, struct wiphy_work *);
struct wiphy_work {
 struct list_head entry;
 wiphy_work_func_t func;
};
struct wiphy_delayed_work {
 struct wiphy_work work;
 struct wiphy *wiphy;
 struct timer_list timer;
};
enum ieee80211_ap_reg_power {
 IEEE80211_REG_UNSET_AP,
 IEEE80211_REG_LPI_AP,
 IEEE80211_REG_SP_AP,
 IEEE80211_REG_VLP_AP,
};
struct wireless_dev {
 struct wiphy *wiphy;
 enum nl80211_iftype iftype;


 struct list_head list;
 struct net_device *netdev;

 u32 identifier;

 struct list_head mgmt_registrations;
 u8 mgmt_registrations_need_update:1;

 bool use_4addr, is_running, registered, registering;

 u8 address[6] ;


 struct cfg80211_conn *conn;
 struct cfg80211_cached_keys *connect_keys;
 enum ieee80211_bss_type conn_bss_type;
 u32 conn_owner_nlportid;

 struct wiphy_work disconnect_wk;
 u8 disconnect_bssid[6];

 struct list_head event_list;
 spinlock_t event_lock;

 u8 connected:1;

 bool ps;
 int ps_timeout;

 u32 ap_unexpected_nlportid;

 u32 owner_nlportid;
 bool nl_owner_dead;



 struct {
  struct cfg80211_ibss_params ibss;
  struct cfg80211_connect_params connect;
  struct cfg80211_cached_keys *keys;
  const u8 *ie;
  size_t ie_len;
  u8 bssid[6];
  u8 prev_bssid[6];
  u8 ssid[32];
  s8 default_key, default_mgmt_key;
  bool prev_bssid_valid;
 } wext;


 struct wiphy_work cqm_rssi_work;
 struct cfg80211_cqm_config *cqm_config;

 struct list_head pmsr_list;
 spinlock_t pmsr_lock;
 struct wiphy_work pmsr_free_wk;

 unsigned long unprot_beacon_reported;

 union {
  struct {
   u8 connected_addr[6] ;
   u8 ssid[32];
   u8 ssid_len;
  } client;
  struct {
   int beacon_interval;
   struct cfg80211_chan_def preset_chandef;
   struct cfg80211_chan_def chandef;
   u8 id[32];
   u8 id_len, id_up_len;
  } mesh;
  struct {
   struct cfg80211_chan_def preset_chandef;
   u8 ssid[32];
   u8 ssid_len;
  } ap;
  struct {
   struct cfg80211_internal_bss *current_bss;
   struct cfg80211_chan_def chandef;
   int beacon_interval;
   u8 ssid[32];
   u8 ssid_len;
  } ibss;
  struct {
   struct cfg80211_chan_def chandef;
  } ocb;
  struct {
   u8 cluster_id[6] ;
   u8 n_channels;
   struct cfg80211_chan_def *chandefs;
   bool sched_update_pending;
  } nan;
 } u;

 struct {
  u8 addr[6] ;
  union {
   struct {
    unsigned int beacon_interval;
    struct cfg80211_chan_def chandef;
   } ap;
   struct {
    struct cfg80211_internal_bss *current_bss;
   } client;
  };

  bool cac_started;
  unsigned long cac_start_time;
  unsigned int cac_time_ms;
 } links[15];
 u16 valid_links;

 u32 radio_mask;
};
struct ieee80211_radiotap_header {
 union { struct { uint8_t it_version; uint8_t it_pad; __le16 it_len; __le32 it_present; } __attribute__((__packed__)); struct ieee80211_radiotap_header_fixed { uint8_t it_version; uint8_t it_pad; __le16 it_len; __le32 it_present; } __attribute__((__packed__)) hdr; } __attribute__((__packed__))
  ;




 __le32 it_optional[1];
} __attribute__((__packed__));
_Static_assert(__builtin_offsetof(struct ieee80211_radiotap_header, it_optional) == sizeof(struct ieee80211_radiotap_header_fixed), "struct member likely outside of __struct_group()")
                                                          ;
struct device;
struct ieee80211_tx_queue_params {
 u16 txop;
 u16 cw_min;
 u16 cw_max;
 u8 aifs;
 bool acm;
 bool uapsd;
 bool mu_edca;
 struct ieee80211_he_mu_edca_param_ac_rec mu_edca_param_rec;
};
struct ieee80211_low_level_stats {
 unsigned int dot11ACKFailureCount;
 unsigned int dot11RTSFailureCount;
 unsigned int dot11FCSErrorCount;
 unsigned int dot11RTSSuccessCount;
};
struct ieee80211_chan_req {
 struct cfg80211_chan_def oper;
 struct cfg80211_chan_def ap;
};
struct ieee80211_chanctx_conf {
 struct cfg80211_chan_def def;
 struct cfg80211_chan_def min_def;
 struct cfg80211_chan_def ap;

 int radio_idx;
 u8 rx_chains_static, rx_chains_dynamic;

 bool radar_enabled;

 u8 drv_priv[1] ;
};
enum ieee80211_chanctx_switch_mode {
 CHANCTX_SWMODE_REASSIGN_VIF,
 CHANCTX_SWMODE_SWAP_CONTEXTS,
};
struct ieee80211_vif_chanctx_switch {
 struct ieee80211_vif *vif;
 struct ieee80211_bss_conf *link_conf;
 struct ieee80211_chanctx_conf *old_ctx;
 struct ieee80211_chanctx_conf *new_ctx;
};
enum ieee80211_event_type {
 RSSI_EVENT,
 MLME_EVENT,
 BAR_RX_EVENT,
 BA_FRAME_TIMEOUT,
};
enum ieee80211_rssi_event_data {
 RSSI_EVENT_HIGH,
 RSSI_EVENT_LOW,
};
struct ieee80211_rssi_event {
 enum ieee80211_rssi_event_data data;
};
enum ieee80211_mlme_event_data {
 AUTH_EVENT,
 ASSOC_EVENT,
 DEAUTH_RX_EVENT,
 DEAUTH_TX_EVENT,
};
enum ieee80211_mlme_event_status {
 MLME_SUCCESS,
 MLME_DENIED,
 MLME_TIMEOUT,
};
struct ieee80211_mlme_event {
 enum ieee80211_mlme_event_data data;
 enum ieee80211_mlme_event_status status;
 u16 reason;
};
struct ieee80211_ba_event {
 struct ieee80211_sta *sta;
 u16 tid;
 u16 ssn;
};
struct ieee80211_event {
 enum ieee80211_event_type type;
 union {
  struct ieee80211_rssi_event rssi;
  struct ieee80211_mlme_event mlme;
  struct ieee80211_ba_event ba;
 } u;
};
struct ieee80211_mu_group_data {
 u8 membership[8];
 u8 position[16];
};
struct ieee80211_ftm_responder_params {
 const u8 *lci;
 const u8 *civicloc;
 size_t lci_len;
 size_t civicloc_len;
};
struct ieee80211_fils_discovery {
 u32 min_interval;
 u32 max_interval;
};
struct ieee80211_parsed_tpe_eirp {
 bool valid;
 s8 power[5];
 u8 count;
};
struct ieee80211_parsed_tpe_psd {
 bool valid;
 s8 power[16];
 u8 count, n;
};
struct ieee80211_parsed_tpe {
 struct ieee80211_parsed_tpe_eirp max_local[2], max_reg_client[2];
 struct ieee80211_parsed_tpe_psd psd_local[2], psd_reg_client[2];
};
struct ieee80211_bss_conf {
 struct ieee80211_vif *vif;
 struct cfg80211_bss *bss;

 const u8 *bssid;
 unsigned int link_id;
 u8 addr[6] ;
 u8 htc_trig_based_pkt_ext;
 bool uora_exists;
 u8 uora_ocw_range;
 u16 frame_time_rts_th;
 bool he_support;
 bool twt_requester;
 bool twt_responder;
 bool twt_protected;
 bool twt_broadcast;

 bool use_cts_prot;
 bool use_short_preamble;
 bool use_short_slot;
 bool enable_beacon;
 u8 dtim_period;
 u16 beacon_int;
 u16 assoc_capability;
 u64 sync_tsf;
 u32 sync_device_ts;
 u8 sync_dtim_count;
 u32 basic_rates;
 struct ieee80211_rate *beacon_rate;
 int mcast_rate[NUM_NL80211_BANDS];
 u16 ht_operation_mode;
 s32 cqm_rssi_thold;
 u32 cqm_rssi_hyst;
 s32 cqm_rssi_low;
 s32 cqm_rssi_high;
 struct ieee80211_chan_req chanreq;
 struct ieee80211_mu_group_data mu_group;
 bool qos;
 bool hidden_ssid;
 int txpower;
 enum nl80211_tx_power_setting txpower_type;
 struct ieee80211_p2p_noa_attr p2p_noa_attr;
 bool allow_p2p_go_ps;
 u16 max_idle_period;
 bool protected_keep_alive;
 bool ftm_responder;
 struct ieee80211_ftm_responder_params *ftmr_params;

 bool nontransmitted;
 struct ieee80211_bss_conf *tx_bss_conf;
 u8 transmitter_bssid[6];
 u8 bssid_index;
 u8 bssid_indicator;
 bool ema_ap;
 u8 profile_periodicity;
 struct {
  u32 params;
  u16 nss_set;
 } he_oper;
 struct ieee80211_he_obss_pd he_obss_pd;
 struct cfg80211_he_bss_color he_bss_color;
 struct ieee80211_fils_discovery fils_discovery;
 u32 unsol_bcast_probe_resp_interval;
 struct cfg80211_bitrate_mask beacon_tx_rate;
 enum ieee80211_ap_reg_power power_type;

 struct ieee80211_parsed_tpe tpe;

 u8 pwr_reduction;
 bool eht_support;
 bool epcs_support;
 bool csa_active;

 bool mu_mimo_owner;
 struct ieee80211_chanctx_conf *chanctx_conf;

 bool color_change_active;
 u8 color_change_color;

 bool ht_ldpc;
 bool vht_ldpc;
 bool he_ldpc;
 bool vht_su_beamformer;
 bool vht_su_beamformee;
 bool vht_mu_beamformer;
 bool vht_mu_beamformee;
 bool he_su_beamformer;
 bool he_su_beamformee;
 bool he_mu_beamformer;
 bool he_full_ul_mumimo;
 bool eht_su_beamformer;
 bool eht_su_beamformee;
 bool eht_mu_beamformer;
 bool eht_80mhz_full_bw_ul_mumimo;
 bool eht_disable_mcs15;

 u8 bss_param_ch_cnt;
 u8 bss_param_ch_cnt_link_id;

 u8 s1g_long_beacon_period;
};
struct ieee80211_scan_ies {
 const u8 *ies[NUM_NL80211_BANDS];
 size_t len[NUM_NL80211_BANDS];
 const u8 *common_ies;
 size_t common_ie_len;
};
struct ieee80211_rx_status {
 u64 mactime;
 union {
  u64 boottime_ns;
  ktime_t ack_tx_hwtstamp;
 };
 u32 device_timestamp;
 u32 ampdu_reference;
 u32 flag;
 u16 freq: 13, freq_offset: 1;
 u8 enc_flags;
 u8 encoding:3, bw:4;
 union {
  struct {
   u8 he_ru:3;
   u8 he_gi:2;
   u8 he_dcm:1;
  };
  struct {
   u8 ru:4;
   u8 gi:2;
  } eht;
 };
 u8 rate_idx;
 u8 nss;
 u8 rx_flags;
 u8 band;
 u8 antenna;
 s8 signal;
 u8 chains;
 s8 chain_signal[4];
 u8 zero_length_psdu_type;
 u8 link_valid:1, link_id:4;
};
enum ieee80211_smps_mode {
 IEEE80211_SMPS_AUTOMATIC,
 IEEE80211_SMPS_OFF,
 IEEE80211_SMPS_STATIC,
 IEEE80211_SMPS_DYNAMIC,


 IEEE80211_SMPS_NUM_MODES,
};
struct ieee80211_conf {
 u32 flags;
 int power_level, dynamic_ps_timeout;

 u16 listen_interval;
 u8 ps_dtim_period;

 u8 long_frame_max_tx_count, short_frame_max_tx_count;

 struct cfg80211_chan_def chandef;
 bool radar_enabled;
 enum ieee80211_smps_mode smps_mode;
};
struct ieee80211_channel_switch {
 u64 timestamp;
 u32 device_timestamp;
 bool block_tx;
 struct cfg80211_chan_def chandef;
 u8 count;
 u8 link_id;
 u32 delay;
};
struct ieee80211_vif_cfg {

 bool assoc, ibss_joined;
 bool ibss_creator;
 bool ps;
 u16 aid;
 u16 eml_cap;
 u16 eml_med_sync_delay;
 u16 mld_capa_op;

 __be32 arp_addr_list[4];
 int arp_addr_cnt;
 u8 ssid[32];
 size_t ssid_len;
 bool s1g;
 bool idle;
 u8 ap_addr[6] ;
};
struct ieee80211_neg_ttlm {
 u16 downlink[8];
 u16 uplink[8];
 bool valid;
};
enum ieee80211_neg_ttlm_res {
 NEG_TTLM_RES_ACCEPT,
 NEG_TTLM_RES_REJECT,
 NEG_TTLM_RES_SUGGEST_PREFERRED
};
struct ieee80211_vif {
 enum nl80211_iftype type;
 struct ieee80211_vif_cfg cfg;
 struct ieee80211_bss_conf bss_conf;
 struct ieee80211_bss_conf *link_conf[15];
 u16 valid_links, active_links, dormant_links, suspended_links;
 struct ieee80211_neg_ttlm neg_ttlm;
 u8 addr[6] ;
 bool addr_valid;
 bool p2p;

 u8 cab_queue;
 u8 hw_queue[4];

 struct ieee80211_txq *txq;

 netdev_features_t netdev_features;
 u32 driver_flags;
 u32 offload_flags;


 struct dentry *debugfs_dir;


 bool probe_req_reg;
 bool rx_mcast_action_reg;


 u8 drv_priv[1] ;
};
struct ieee80211_key_conf {
 atomic64_t tx_pn;
 u32 cipher;
 u8 icv_len;
 u8 iv_len;
 u8 hw_key_idx;
 s8 keyidx;
 u16 flags;
 s8 link_id;
 u8 keylen;
 u8 key[1];
};
struct ieee80211_key_seq {
 union {
  struct {
   u32 iv32;
   u16 iv16;
  } tkip;
  struct {
   u8 pn[6];
  } ccmp;
  struct {
   u8 pn[6];
  } aes_cmac;
  struct {
   u8 pn[6];
  } aes_gmac;
  struct {
   u8 pn[6];
  } gcmp;
  struct {
   u8 seq[16];
   u8 seq_len;
  } hw;
 };
};
enum set_key_cmd {
 SET_KEY, DISABLE_KEY,
};
enum ieee80211_sta_state {

 IEEE80211_STA_NOTEXIST,
 IEEE80211_STA_NONE,
 IEEE80211_STA_AUTH,
 IEEE80211_STA_ASSOC,
 IEEE80211_STA_AUTHORIZED,
};
enum ieee80211_sta_rx_bandwidth {
 IEEE80211_STA_RX_BW_20 = 0,
 IEEE80211_STA_RX_BW_40,
 IEEE80211_STA_RX_BW_80,
 IEEE80211_STA_RX_BW_160,
 IEEE80211_STA_RX_BW_320,
};
struct ieee80211_sta_rates {
 struct callback_head callback_head;
 struct {
  s8 idx;
  u8 count;
  u8 count_cts;
  u8 count_rts;
  u16 flags;
 } rate[4];
};
struct ieee80211_sta_txpwr {
 s16 power;
 enum nl80211_tx_power_setting type;
};
struct ieee80211_sta_aggregates {
 u16 max_amsdu_len;

 u16 max_rc_amsdu_len;
 u16 max_tid_amsdu_len[16];
};
struct ieee80211_link_sta {
 struct ieee80211_sta *sta;

 u8 addr[6];
 u8 link_id;
 enum ieee80211_smps_mode smps_mode;

 u32 supp_rates[NUM_NL80211_BANDS];
 struct ieee80211_sta_ht_cap ht_cap;
 struct ieee80211_sta_vht_cap vht_cap;
 struct ieee80211_sta_he_cap he_cap;
 struct ieee80211_he_6ghz_capa he_6ghz_capa;
 struct ieee80211_sta_eht_cap eht_cap;
 struct ieee80211_sta_s1g_cap s1g_cap;

 struct ieee80211_sta_aggregates agg;

 u8 rx_nss;
 enum ieee80211_sta_rx_bandwidth bandwidth;
 struct ieee80211_sta_txpwr txpwr;
};
struct ieee80211_sta {
 u8 addr[6] ;
 u16 aid;
 u16 max_rx_aggregation_subframes;
 bool wme;
 u8 uapsd_queues;
 u8 max_sp;
 struct ieee80211_sta_rates *rates;
 bool tdls;
 bool tdls_initiator;
 bool mfp;
 bool mlo;
 bool spp_amsdu;
 u8 max_amsdu_subframes;
 u16 eml_cap;

 struct ieee80211_sta_aggregates *cur;

 bool support_p2p_ps;

 struct ieee80211_txq *txq[16 + 1];

 u16 valid_links;
 struct ieee80211_link_sta deflink;
 struct ieee80211_link_sta *link[15];


 u8 drv_priv[1] ;
};
enum sta_notify_cmd {
 STA_NOTIFY_SLEEP, STA_NOTIFY_AWAKE,
};
struct ieee80211_tx_control {
 struct ieee80211_sta *sta;
};
struct ieee80211_txq {
 struct ieee80211_vif *vif;
 struct ieee80211_sta *sta;
 u8 tid;
 u8 ac;


 u8 drv_priv[1] ;
};
enum ieee80211_hw_flags {
 IEEE80211_HW_HAS_RATE_CONTROL,
 IEEE80211_HW_RX_INCLUDES_FCS,
 IEEE80211_HW_HOST_BROADCAST_PS_BUFFERING,
 IEEE80211_HW_SIGNAL_UNSPEC,
 IEEE80211_HW_SIGNAL_DBM,
 IEEE80211_HW_NEED_DTIM_BEFORE_ASSOC,
 IEEE80211_HW_SPECTRUM_MGMT,
 IEEE80211_HW_AMPDU_AGGREGATION,
 IEEE80211_HW_SUPPORTS_PS,
 IEEE80211_HW_PS_NULLFUNC_STACK,
 IEEE80211_HW_SUPPORTS_DYNAMIC_PS,
 IEEE80211_HW_MFP_CAPABLE,
 IEEE80211_HW_WANT_MONITOR_VIF,
 IEEE80211_HW_NO_VIRTUAL_MONITOR,
 IEEE80211_HW_NO_AUTO_VIF,
 IEEE80211_HW_SW_CRYPTO_CONTROL,
 IEEE80211_HW_SUPPORT_FAST_XMIT,
 IEEE80211_HW_REPORTS_TX_ACK_STATUS,
 IEEE80211_HW_CONNECTION_MONITOR,
 IEEE80211_HW_QUEUE_CONTROL,
 IEEE80211_HW_SUPPORTS_PER_STA_GTK,
 IEEE80211_HW_AP_LINK_PS,
 IEEE80211_HW_TX_AMPDU_SETUP_IN_HW,
 IEEE80211_HW_SUPPORTS_RC_TABLE,
 IEEE80211_HW_P2P_DEV_ADDR_FOR_INTF,
 IEEE80211_HW_TIMING_BEACON_ONLY,
 IEEE80211_HW_SUPPORTS_HT_CCK_RATES,
 IEEE80211_HW_CHANCTX_STA_CSA,
 IEEE80211_HW_SUPPORTS_CLONED_SKBS,
 IEEE80211_HW_SINGLE_SCAN_ON_ALL_BANDS,
 IEEE80211_HW_TDLS_WIDER_BW,
 IEEE80211_HW_SUPPORTS_AMSDU_IN_AMPDU,
 IEEE80211_HW_BEACON_TX_STATUS,
 IEEE80211_HW_NEEDS_UNIQUE_STA_ADDR,
 IEEE80211_HW_SUPPORTS_REORDERING_BUFFER,
 IEEE80211_HW_USES_RSS,
 IEEE80211_HW_TX_AMSDU,
 IEEE80211_HW_TX_FRAG_LIST,
 IEEE80211_HW_REPORTS_LOW_ACK,
 IEEE80211_HW_SUPPORTS_TX_FRAG,
 IEEE80211_HW_SUPPORTS_TDLS_BUFFER_STA,
 IEEE80211_HW_DOESNT_SUPPORT_QOS_NDP,
 IEEE80211_HW_BUFF_MMPDU_TXQ,
 IEEE80211_HW_SUPPORTS_VHT_EXT_NSS_BW,
 IEEE80211_HW_STA_MMPDU_TXQ,
 IEEE80211_HW_TX_STATUS_NO_AMPDU_LEN,
 IEEE80211_HW_SUPPORTS_MULTI_BSSID,
 IEEE80211_HW_SUPPORTS_ONLY_HE_MULTI_BSSID,
 IEEE80211_HW_AMPDU_KEYBORDER_SUPPORT,
 IEEE80211_HW_SUPPORTS_TX_ENCAP_OFFLOAD,
 IEEE80211_HW_SUPPORTS_RX_DECAP_OFFLOAD,
 IEEE80211_HW_SUPPORTS_CONC_MON_RX_DECAP,
 IEEE80211_HW_DETECTS_COLOR_COLLISION,
 IEEE80211_HW_MLO_MCAST_MULTI_LINK_TX,
 IEEE80211_HW_DISALLOW_PUNCTURING,
 IEEE80211_HW_HANDLES_QUIET_CSA,
 IEEE80211_HW_STRICT,


 NUM_IEEE80211_HW_FLAGS
};
struct ieee80211_hw {
 struct ieee80211_conf conf;
 struct wiphy *wiphy;
 const char *rate_control_algorithm;
 void *priv;
 unsigned long flags[(((NUM_IEEE80211_HW_FLAGS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned int extra_tx_headroom;
 unsigned int extra_beacon_tailroom;
 int vif_data_size;
 int sta_data_size;
 int chanctx_data_size;
 int txq_data_size;
 u16 queues;
 u16 max_listen_interval;
 s8 max_signal;
 u8 max_rates;
 u8 max_report_rates;
 u8 max_rate_tries;
 u16 max_rx_aggregation_subframes;
 u16 max_tx_aggregation_subframes;
 u8 max_tx_fragments;
 u8 offchannel_tx_hw_queue;
 u8 radiotap_mcs_details;
 u16 radiotap_vht_details;
 struct {
  int units_pos;
  s16 accuracy;
 } radiotap_timestamp;
 netdev_features_t netdev_features;
 u8 uapsd_queues;
 u8 uapsd_max_sp_len;
 u8 max_nan_de_entries;
 u8 tx_sk_pacing_shift;
 u8 weight_multiplier;
 u32 max_mtu;
 const s8 *tx_power_levels;
 u8 max_txpwr_levels_idx;
};
struct ieee80211_scan_request {
 struct ieee80211_scan_ies ies;


 struct cfg80211_scan_request req;
};
struct ieee80211_tdls_ch_sw_params {
 struct ieee80211_sta *sta;
 struct cfg80211_chan_def *chandef;
 u8 action_code;
 u32 status;
 u32 timestamp;
 u16 switch_time;
 u16 switch_timeout;
 struct sk_buff *tmpl_skb;
 u32 ch_sw_tm_ie;
};
enum ieee80211_ampdu_mlme_action {
 IEEE80211_AMPDU_RX_START,
 IEEE80211_AMPDU_RX_STOP,
 IEEE80211_AMPDU_TX_START,
 IEEE80211_AMPDU_TX_STOP_CONT,
 IEEE80211_AMPDU_TX_STOP_FLUSH,
 IEEE80211_AMPDU_TX_STOP_FLUSH_CONT,
 IEEE80211_AMPDU_TX_OPERATIONAL,
};
struct ieee80211_ampdu_params {
 enum ieee80211_ampdu_mlme_action action;
 struct ieee80211_sta *sta;
 u16 tid;
 u16 ssn;
 u16 buf_size;
 bool amsdu;
 u16 timeout;
};
enum ieee80211_frame_release_type {
 IEEE80211_FRAME_RELEASE_PSPOLL,
 IEEE80211_FRAME_RELEASE_UAPSD,
};
enum ieee80211_roc_type {
 IEEE80211_ROC_TYPE_NORMAL = 0,
 IEEE80211_ROC_TYPE_MGMT_TX,
};
enum ieee80211_reconfig_type {
 IEEE80211_RECONFIG_TYPE_RESTART,
 IEEE80211_RECONFIG_TYPE_SUSPEND,
};
struct ieee80211_prep_tx_info {
 u16 duration;
 u16 subtype;
 u8 success:1, was_assoc:1;
 int link_id;
};
struct ieee80211_ops {
 void (*tx)(struct ieee80211_hw *hw,
     struct ieee80211_tx_control *control,
     struct sk_buff *skb);
 int (*start)(struct ieee80211_hw *hw);
 void (*stop)(struct ieee80211_hw *hw, bool suspend);

 int (*suspend)(struct ieee80211_hw *hw, struct cfg80211_wowlan *wowlan);
 int (*resume)(struct ieee80211_hw *hw);
 void (*set_wakeup)(struct ieee80211_hw *hw, bool enabled);

 int (*add_interface)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif);
 int (*change_interface)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    enum nl80211_iftype new_type, bool p2p);
 void (*remove_interface)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif);
 int (*config)(struct ieee80211_hw *hw, int radio_idx, u32 changed);
 void (*bss_info_changed)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif,
     struct ieee80211_bss_conf *info,
     u64 changed);
 void (*vif_cfg_changed)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    u64 changed);
 void (*link_info_changed)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_bss_conf *info,
      u64 changed);

 int (*start_ap)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
   struct ieee80211_bss_conf *link_conf);
 void (*stop_ap)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
   struct ieee80211_bss_conf *link_conf);

 u64 (*prepare_multicast)(struct ieee80211_hw *hw,
     struct netdev_hw_addr_list *mc_list);
 void (*configure_filter)(struct ieee80211_hw *hw,
     unsigned int changed_flags,
     unsigned int *total_flags,
     u64 multicast);
 void (*config_iface_filter)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif,
        unsigned int filter_flags,
        unsigned int changed_flags);
 int (*set_tim)(struct ieee80211_hw *hw, struct ieee80211_sta *sta,
         bool set);
 int (*set_key)(struct ieee80211_hw *hw, enum set_key_cmd cmd,
         struct ieee80211_vif *vif, struct ieee80211_sta *sta,
         struct ieee80211_key_conf *key);
 void (*update_tkip_key)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct ieee80211_key_conf *conf,
    struct ieee80211_sta *sta,
    u32 iv32, u16 *phase1key);
 void (*set_rekey_data)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct cfg80211_gtk_rekey_data *data);
 void (*set_default_unicast_key)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif, int idx);
 int (*hw_scan)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
         struct ieee80211_scan_request *req);
 void (*cancel_hw_scan)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif);
 int (*sched_scan_start)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct cfg80211_sched_scan_request *req,
    struct ieee80211_scan_ies *ies);
 int (*sched_scan_stop)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif);
 void (*sw_scan_start)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         const u8 *mac_addr);
 void (*sw_scan_complete)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif);
 int (*get_stats)(struct ieee80211_hw *hw,
    struct ieee80211_low_level_stats *stats);
 void (*get_key_seq)(struct ieee80211_hw *hw,
       struct ieee80211_key_conf *key,
       struct ieee80211_key_seq *seq);
 int (*set_frag_threshold)(struct ieee80211_hw *hw, int radio_idx,
      u32 value);
 int (*set_rts_threshold)(struct ieee80211_hw *hw, int radio_idx,
     u32 value);
 int (*sta_add)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
         struct ieee80211_sta *sta);
 int (*sta_remove)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
     struct ieee80211_sta *sta);

 void (*vif_add_debugfs)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif);
 void (*link_add_debugfs)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif,
     struct ieee80211_bss_conf *link_conf,
     struct dentry *dir);
 void (*sta_add_debugfs)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct ieee80211_sta *sta,
    struct dentry *dir);
 void (*link_sta_add_debugfs)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         struct ieee80211_link_sta *link_sta,
         struct dentry *dir);

 void (*sta_notify)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
   enum sta_notify_cmd, struct ieee80211_sta *sta);
 int (*sta_set_txpwr)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif,
        struct ieee80211_sta *sta);
 int (*sta_state)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
    struct ieee80211_sta *sta,
    enum ieee80211_sta_state old_state,
    enum ieee80211_sta_state new_state);
 void (*sta_pre_rcu_remove)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_sta *sta);
 void (*link_sta_rc_update)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_link_sta *link_sta,
       u32 changed);
 void (*sta_rate_tbl_update)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif,
        struct ieee80211_sta *sta);
 void (*sta_statistics)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct ieee80211_sta *sta,
          struct station_info *sinfo);
 int (*conf_tx)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         unsigned int link_id, u16 ac,
         const struct ieee80211_tx_queue_params *params);
 u64 (*get_tsf)(struct ieee80211_hw *hw, struct ieee80211_vif *vif);
 void (*set_tsf)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
   u64 tsf);
 void (*offset_tsf)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
      s64 offset);
 void (*reset_tsf)(struct ieee80211_hw *hw, struct ieee80211_vif *vif);
 int (*tx_last_beacon)(struct ieee80211_hw *hw);
 void (*link_sta_statistics)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif,
        struct ieee80211_link_sta *link_sta,
        struct link_station_info *link_sinfo);
 int (*ampdu_action)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_ampdu_params *params);
 int (*get_survey)(struct ieee80211_hw *hw, int idx,
  struct survey_info *survey);
 void (*rfkill_poll)(struct ieee80211_hw *hw);
 void (*set_coverage_class)(struct ieee80211_hw *hw, int radio_idx,
       s16 coverage_class);

 int (*testmode_cmd)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
       void *data, int len);
 int (*testmode_dump)(struct ieee80211_hw *hw, struct sk_buff *skb,
        struct netlink_callback *cb,
        void *data, int len);

 void (*flush)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
        u32 queues, bool drop);
 void (*flush_sta)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
     struct ieee80211_sta *sta);
 void (*channel_switch)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct ieee80211_channel_switch *ch_switch);
 int (*set_antenna)(struct ieee80211_hw *hw, int radio_idx,
      u32 tx_ant, u32 rx_ant);
 int (*get_antenna)(struct ieee80211_hw *hw, int radio_idx,
      u32 *tx_ant, u32 *rx_ant);

 int (*remain_on_channel)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif,
     struct ieee80211_channel *chan,
     int duration,
     enum ieee80211_roc_type type);
 int (*cancel_remain_on_channel)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif);
 int (*set_ringparam)(struct ieee80211_hw *hw, u32 tx, u32 rx);
 void (*get_ringparam)(struct ieee80211_hw *hw,
         u32 *tx, u32 *tx_max, u32 *rx, u32 *rx_max);
 bool (*tx_frames_pending)(struct ieee80211_hw *hw);
 int (*set_bitrate_mask)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
    const struct cfg80211_bitrate_mask *mask);
 void (*event_callback)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          const struct ieee80211_event *event);

 void (*allow_buffered_frames)(struct ieee80211_hw *hw,
          struct ieee80211_sta *sta,
          u16 tids, int num_frames,
          enum ieee80211_frame_release_type reason,
          bool more_data);
 void (*release_buffered_frames)(struct ieee80211_hw *hw,
     struct ieee80211_sta *sta,
     u16 tids, int num_frames,
     enum ieee80211_frame_release_type reason,
     bool more_data);

 int (*get_et_sset_count)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif, int sset);
 void (*get_et_stats)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct ethtool_stats *stats, u64 *data);
 void (*get_et_strings)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      u32 sset, u8 *data);

 void (*mgd_prepare_tx)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_prep_tx_info *info);
 void (*mgd_complete_tx)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_prep_tx_info *info);

 void (*mgd_protect_tdls_discover)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          unsigned int link_id);

 int (*add_chanctx)(struct ieee80211_hw *hw,
      struct ieee80211_chanctx_conf *ctx);
 void (*remove_chanctx)(struct ieee80211_hw *hw,
          struct ieee80211_chanctx_conf *ctx);
 void (*change_chanctx)(struct ieee80211_hw *hw,
          struct ieee80211_chanctx_conf *ctx,
          u32 changed);
 int (*assign_vif_chanctx)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_bss_conf *link_conf,
      struct ieee80211_chanctx_conf *ctx);
 void (*unassign_vif_chanctx)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         struct ieee80211_bss_conf *link_conf,
         struct ieee80211_chanctx_conf *ctx);
 int (*switch_vif_chanctx)(struct ieee80211_hw *hw,
      struct ieee80211_vif_chanctx_switch *vifs,
      int n_vifs,
      enum ieee80211_chanctx_switch_mode mode);

 void (*reconfig_complete)(struct ieee80211_hw *hw,
      enum ieee80211_reconfig_type reconfig_type);


 void (*ipv6_addr_change)(struct ieee80211_hw *hw,
     struct ieee80211_vif *vif,
     struct inet6_dev *idev);

 void (*channel_switch_beacon)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct cfg80211_chan_def *chandef);
 int (*pre_channel_switch)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_channel_switch *ch_switch);

 int (*post_channel_switch)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_bss_conf *link_conf);
 void (*abort_channel_switch)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         struct ieee80211_bss_conf *link_conf);
 void (*channel_switch_rx_beacon)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_channel_switch *ch_switch);

 int (*join_ibss)(struct ieee80211_hw *hw, struct ieee80211_vif *vif);
 void (*leave_ibss)(struct ieee80211_hw *hw, struct ieee80211_vif *vif);
 u32 (*get_expected_throughput)(struct ieee80211_hw *hw,
           struct ieee80211_sta *sta);
 int (*get_txpower)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
      unsigned int link_id, int *dbm);

 int (*tdls_channel_switch)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct ieee80211_sta *sta, u8 oper_class,
       struct cfg80211_chan_def *chandef,
       struct sk_buff *tmpl_skb, u32 ch_sw_tm_ie);
 void (*tdls_cancel_channel_switch)(struct ieee80211_hw *hw,
        struct ieee80211_vif *vif,
        struct ieee80211_sta *sta);
 void (*tdls_recv_channel_switch)(struct ieee80211_hw *hw,
      struct ieee80211_vif *vif,
      struct ieee80211_tdls_ch_sw_params *params);

 void (*wake_tx_queue)(struct ieee80211_hw *hw,
         struct ieee80211_txq *txq);
 void (*sync_rx_queues)(struct ieee80211_hw *hw);

 int (*start_nan)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct cfg80211_nan_conf *conf);
 int (*stop_nan)(struct ieee80211_hw *hw,
   struct ieee80211_vif *vif);
 int (*nan_change_conf)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct cfg80211_nan_conf *conf, u32 changes);
 int (*add_nan_func)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       const struct cfg80211_nan_func *nan_func);
 void (*del_nan_func)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       u8 instance_id);
 bool (*can_aggregate_in_amsdu)(struct ieee80211_hw *hw,
           struct sk_buff *head,
           struct sk_buff *skb);
 int (*get_ftm_responder_stats)(struct ieee80211_hw *hw,
           struct ieee80211_vif *vif,
           struct cfg80211_ftm_responder_stats *ftm_stats);
 int (*start_pmsr)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
     struct cfg80211_pmsr_request *request);
 void (*abort_pmsr)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
      struct cfg80211_pmsr_request *request);
 int (*set_tid_config)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         struct ieee80211_sta *sta,
         struct cfg80211_tid_config *tid_conf);
 int (*reset_tid_config)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct ieee80211_sta *sta, u8 tids);
 void (*update_vif_offload)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif);
 void (*sta_set_4addr)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
         struct ieee80211_sta *sta, bool enabled);
 int (*set_sar_specs)(struct ieee80211_hw *hw,
        const struct cfg80211_sar_specs *sar);
 void (*sta_set_decap_offload)(struct ieee80211_hw *hw,
          struct ieee80211_vif *vif,
          struct ieee80211_sta *sta, bool enabled);
 void (*add_twt_setup)(struct ieee80211_hw *hw,
         struct ieee80211_sta *sta,
         struct ieee80211_twt_setup *twt);
 void (*twt_teardown_request)(struct ieee80211_hw *hw,
         struct ieee80211_sta *sta, u8 flowid);
 int (*set_radar_background)(struct ieee80211_hw *hw,
        struct cfg80211_chan_def *chandef);
 int (*net_fill_forward_path)(struct ieee80211_hw *hw,
         struct ieee80211_vif *vif,
         struct ieee80211_sta *sta,
         struct net_device_path_ctx *ctx,
         struct net_device_path *path);
 bool (*can_activate_links)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       u16 active_links);
 int (*change_vif_links)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    u16 old_links, u16 new_links,
    struct ieee80211_bss_conf *old[15]);
 int (*change_sta_links)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct ieee80211_sta *sta,
    u16 old_links, u16 new_links);
 int (*set_hw_timestamp)(struct ieee80211_hw *hw,
    struct ieee80211_vif *vif,
    struct cfg80211_set_hw_timestamp *hwts);
 int (*net_setup_tc)(struct ieee80211_hw *hw,
       struct ieee80211_vif *vif,
       struct net_device *dev,
       enum tc_setup_type type,
       void *type_data);
 enum ieee80211_neg_ttlm_res
 (*can_neg_ttlm)(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
   struct ieee80211_neg_ttlm *ttlm);
 void (*prep_add_interface)(struct ieee80211_hw *hw,
       enum nl80211_iftype type);
};
struct rtw89_dev;
struct rtw89_pci_info;
struct rtw89_mac_gen_def;
struct rtw89_phy_gen_def;
struct rtw89_fw_blacklist;
struct rtw89_efuse_block_cfg;
struct rtw89_fw_txpwr_track_cfg;
struct rtw89_phy_rfk_log_fmt;
struct rtw89_debugfs;
struct rtw89_regd_data;
enum rtw89_subband {
 RTW89_CH_2G = 0,
 RTW89_CH_5G_BAND_1 = 1,

 RTW89_CH_5G_BAND_3 = 3,
 RTW89_CH_5G_BAND_4 = 4,

 RTW89_CH_6G_BAND_IDX0,
 RTW89_CH_6G_BAND_IDX1,
 RTW89_CH_6G_BAND_IDX2,
 RTW89_CH_6G_BAND_IDX3,
 RTW89_CH_6G_BAND_IDX4,
 RTW89_CH_6G_BAND_IDX5,
 RTW89_CH_6G_BAND_IDX6,
 RTW89_CH_6G_BAND_IDX7,

 RTW89_SUBBAND_NR,
 RTW89_SUBBAND_2GHZ_5GHZ_NR = RTW89_CH_5G_BAND_4 + 1,
};
enum rtw89_gain_offset {
 RTW89_GAIN_OFFSET_2G_CCK,
 RTW89_GAIN_OFFSET_2G_OFDM,
 RTW89_GAIN_OFFSET_5G_LOW,
 RTW89_GAIN_OFFSET_5G_MID,
 RTW89_GAIN_OFFSET_5G_HIGH,
 RTW89_GAIN_OFFSET_6G_L0,
 RTW89_GAIN_OFFSET_6G_L1,
 RTW89_GAIN_OFFSET_6G_M0,
 RTW89_GAIN_OFFSET_6G_M1,
 RTW89_GAIN_OFFSET_6G_H0,
 RTW89_GAIN_OFFSET_6G_H1,
 RTW89_GAIN_OFFSET_6G_UH0,
 RTW89_GAIN_OFFSET_6G_UH1,

 RTW89_GAIN_OFFSET_NR,
};
enum rtw89_hci_type {
 RTW89_HCI_TYPE_PCIE,
 RTW89_HCI_TYPE_USB,
 RTW89_HCI_TYPE_SDIO,

 RTW89_HCI_TYPE_NUM,
};
enum rtw89_hci_dle_type {
 RTW89_HCI_DLE_TYPE_PCIE,
 RTW89_HCI_DLE_TYPE_USB2,
 RTW89_HCI_DLE_TYPE_USB3,
 RTW89_HCI_DLE_TYPE_SDIO,

 RTW89_HCI_DLE_TYPE_NUM,
};
enum rtw89_core_chip_id {
 RTL8852A,
 RTL8852B,
 RTL8852BT,
 RTL8852C,
 RTL8851B,
 RTL8922A,
};
enum rtw89_chip_gen {
 RTW89_CHIP_AX,
 RTW89_CHIP_BE,

 RTW89_CHIP_GEN_NUM,
};
enum rtw89_bacam_ver {
 RTW89_BACAM_V0,
 RTW89_BACAM_V1,

 RTW89_BACAM_V0_EXT = 99,
};
enum rtw89_core_tx_type {
 RTW89_CORE_TX_TYPE_DATA,
 RTW89_CORE_TX_TYPE_MGMT,
 RTW89_CORE_TX_TYPE_FWCMD,
};
enum rtw89_wifi_role {
 RTW89_WIFI_ROLE_NONE,
 RTW89_WIFI_ROLE_STATION,
 RTW89_WIFI_ROLE_AP,
 RTW89_WIFI_ROLE_AP_VLAN,
 RTW89_WIFI_ROLE_ADHOC,
 RTW89_WIFI_ROLE_ADHOC_MASTER,
 RTW89_WIFI_ROLE_MESH_POINT,
 RTW89_WIFI_ROLE_MONITOR,
 RTW89_WIFI_ROLE_P2P_DEVICE,
 RTW89_WIFI_ROLE_P2P_CLIENT,
 RTW89_WIFI_ROLE_P2P_GO,
 RTW89_WIFI_ROLE_NAN,
 RTW89_WIFI_ROLE_MLME_MAX
};
enum rtw89_sch_tx_sel {
 RTW89_SCH_TX_SEL_ALL,
 RTW89_SCH_TX_SEL_HIQ,
 RTW89_SCH_TX_SEL_MG0,
 RTW89_SCH_TX_SEL_MACID,
};
enum rtw89_port {
 RTW89_PORT_0 = 0,
 RTW89_PORT_1 = 1,
 RTW89_PORT_2 = 2,
 RTW89_PORT_3 = 3,
 RTW89_PORT_4 = 4,
 RTW89_PORT_NUM
};
enum rtw89_band {
 RTW89_BAND_2G = 0,
 RTW89_BAND_5G = 1,
 RTW89_BAND_6G = 2,
 RTW89_BAND_NUM,
};
enum rtw89_hw_rate {
 RTW89_HW_RATE_CCK1 = 0x0,
 RTW89_HW_RATE_CCK2 = 0x1,
 RTW89_HW_RATE_CCK5_5 = 0x2,
 RTW89_HW_RATE_CCK11 = 0x3,
 RTW89_HW_RATE_OFDM6 = 0x4,
 RTW89_HW_RATE_OFDM9 = 0x5,
 RTW89_HW_RATE_OFDM12 = 0x6,
 RTW89_HW_RATE_OFDM18 = 0x7,
 RTW89_HW_RATE_OFDM24 = 0x8,
 RTW89_HW_RATE_OFDM36 = 0x9,
 RTW89_HW_RATE_OFDM48 = 0xA,
 RTW89_HW_RATE_OFDM54 = 0xB,
 RTW89_HW_RATE_MCS0 = 0x80,
 RTW89_HW_RATE_MCS1 = 0x81,
 RTW89_HW_RATE_MCS2 = 0x82,
 RTW89_HW_RATE_MCS3 = 0x83,
 RTW89_HW_RATE_MCS4 = 0x84,
 RTW89_HW_RATE_MCS5 = 0x85,
 RTW89_HW_RATE_MCS6 = 0x86,
 RTW89_HW_RATE_MCS7 = 0x87,
 RTW89_HW_RATE_MCS8 = 0x88,
 RTW89_HW_RATE_MCS9 = 0x89,
 RTW89_HW_RATE_MCS10 = 0x8A,
 RTW89_HW_RATE_MCS11 = 0x8B,
 RTW89_HW_RATE_MCS12 = 0x8C,
 RTW89_HW_RATE_MCS13 = 0x8D,
 RTW89_HW_RATE_MCS14 = 0x8E,
 RTW89_HW_RATE_MCS15 = 0x8F,
 RTW89_HW_RATE_MCS16 = 0x90,
 RTW89_HW_RATE_MCS17 = 0x91,
 RTW89_HW_RATE_MCS18 = 0x92,
 RTW89_HW_RATE_MCS19 = 0x93,
 RTW89_HW_RATE_MCS20 = 0x94,
 RTW89_HW_RATE_MCS21 = 0x95,
 RTW89_HW_RATE_MCS22 = 0x96,
 RTW89_HW_RATE_MCS23 = 0x97,
 RTW89_HW_RATE_MCS24 = 0x98,
 RTW89_HW_RATE_MCS25 = 0x99,
 RTW89_HW_RATE_MCS26 = 0x9A,
 RTW89_HW_RATE_MCS27 = 0x9B,
 RTW89_HW_RATE_MCS28 = 0x9C,
 RTW89_HW_RATE_MCS29 = 0x9D,
 RTW89_HW_RATE_MCS30 = 0x9E,
 RTW89_HW_RATE_MCS31 = 0x9F,
 RTW89_HW_RATE_VHT_NSS1_MCS0 = 0x100,
 RTW89_HW_RATE_VHT_NSS1_MCS1 = 0x101,
 RTW89_HW_RATE_VHT_NSS1_MCS2 = 0x102,
 RTW89_HW_RATE_VHT_NSS1_MCS3 = 0x103,
 RTW89_HW_RATE_VHT_NSS1_MCS4 = 0x104,
 RTW89_HW_RATE_VHT_NSS1_MCS5 = 0x105,
 RTW89_HW_RATE_VHT_NSS1_MCS6 = 0x106,
 RTW89_HW_RATE_VHT_NSS1_MCS7 = 0x107,
 RTW89_HW_RATE_VHT_NSS1_MCS8 = 0x108,
 RTW89_HW_RATE_VHT_NSS1_MCS9 = 0x109,
 RTW89_HW_RATE_VHT_NSS2_MCS0 = 0x110,
 RTW89_HW_RATE_VHT_NSS2_MCS1 = 0x111,
 RTW89_HW_RATE_VHT_NSS2_MCS2 = 0x112,
 RTW89_HW_RATE_VHT_NSS2_MCS3 = 0x113,
 RTW89_HW_RATE_VHT_NSS2_MCS4 = 0x114,
 RTW89_HW_RATE_VHT_NSS2_MCS5 = 0x115,
 RTW89_HW_RATE_VHT_NSS2_MCS6 = 0x116,
 RTW89_HW_RATE_VHT_NSS2_MCS7 = 0x117,
 RTW89_HW_RATE_VHT_NSS2_MCS8 = 0x118,
 RTW89_HW_RATE_VHT_NSS2_MCS9 = 0x119,
 RTW89_HW_RATE_VHT_NSS3_MCS0 = 0x120,
 RTW89_HW_RATE_VHT_NSS3_MCS1 = 0x121,
 RTW89_HW_RATE_VHT_NSS3_MCS2 = 0x122,
 RTW89_HW_RATE_VHT_NSS3_MCS3 = 0x123,
 RTW89_HW_RATE_VHT_NSS3_MCS4 = 0x124,
 RTW89_HW_RATE_VHT_NSS3_MCS5 = 0x125,
 RTW89_HW_RATE_VHT_NSS3_MCS6 = 0x126,
 RTW89_HW_RATE_VHT_NSS3_MCS7 = 0x127,
 RTW89_HW_RATE_VHT_NSS3_MCS8 = 0x128,
 RTW89_HW_RATE_VHT_NSS3_MCS9 = 0x129,
 RTW89_HW_RATE_VHT_NSS4_MCS0 = 0x130,
 RTW89_HW_RATE_VHT_NSS4_MCS1 = 0x131,
 RTW89_HW_RATE_VHT_NSS4_MCS2 = 0x132,
 RTW89_HW_RATE_VHT_NSS4_MCS3 = 0x133,
 RTW89_HW_RATE_VHT_NSS4_MCS4 = 0x134,
 RTW89_HW_RATE_VHT_NSS4_MCS5 = 0x135,
 RTW89_HW_RATE_VHT_NSS4_MCS6 = 0x136,
 RTW89_HW_RATE_VHT_NSS4_MCS7 = 0x137,
 RTW89_HW_RATE_VHT_NSS4_MCS8 = 0x138,
 RTW89_HW_RATE_VHT_NSS4_MCS9 = 0x139,
 RTW89_HW_RATE_HE_NSS1_MCS0 = 0x180,
 RTW89_HW_RATE_HE_NSS1_MCS1 = 0x181,
 RTW89_HW_RATE_HE_NSS1_MCS2 = 0x182,
 RTW89_HW_RATE_HE_NSS1_MCS3 = 0x183,
 RTW89_HW_RATE_HE_NSS1_MCS4 = 0x184,
 RTW89_HW_RATE_HE_NSS1_MCS5 = 0x185,
 RTW89_HW_RATE_HE_NSS1_MCS6 = 0x186,
 RTW89_HW_RATE_HE_NSS1_MCS7 = 0x187,
 RTW89_HW_RATE_HE_NSS1_MCS8 = 0x188,
 RTW89_HW_RATE_HE_NSS1_MCS9 = 0x189,
 RTW89_HW_RATE_HE_NSS1_MCS10 = 0x18A,
 RTW89_HW_RATE_HE_NSS1_MCS11 = 0x18B,
 RTW89_HW_RATE_HE_NSS2_MCS0 = 0x190,
 RTW89_HW_RATE_HE_NSS2_MCS1 = 0x191,
 RTW89_HW_RATE_HE_NSS2_MCS2 = 0x192,
 RTW89_HW_RATE_HE_NSS2_MCS3 = 0x193,
 RTW89_HW_RATE_HE_NSS2_MCS4 = 0x194,
 RTW89_HW_RATE_HE_NSS2_MCS5 = 0x195,
 RTW89_HW_RATE_HE_NSS2_MCS6 = 0x196,
 RTW89_HW_RATE_HE_NSS2_MCS7 = 0x197,
 RTW89_HW_RATE_HE_NSS2_MCS8 = 0x198,
 RTW89_HW_RATE_HE_NSS2_MCS9 = 0x199,
 RTW89_HW_RATE_HE_NSS2_MCS10 = 0x19A,
 RTW89_HW_RATE_HE_NSS2_MCS11 = 0x19B,
 RTW89_HW_RATE_HE_NSS3_MCS0 = 0x1A0,
 RTW89_HW_RATE_HE_NSS3_MCS1 = 0x1A1,
 RTW89_HW_RATE_HE_NSS3_MCS2 = 0x1A2,
 RTW89_HW_RATE_HE_NSS3_MCS3 = 0x1A3,
 RTW89_HW_RATE_HE_NSS3_MCS4 = 0x1A4,
 RTW89_HW_RATE_HE_NSS3_MCS5 = 0x1A5,
 RTW89_HW_RATE_HE_NSS3_MCS6 = 0x1A6,
 RTW89_HW_RATE_HE_NSS3_MCS7 = 0x1A7,
 RTW89_HW_RATE_HE_NSS3_MCS8 = 0x1A8,
 RTW89_HW_RATE_HE_NSS3_MCS9 = 0x1A9,
 RTW89_HW_RATE_HE_NSS3_MCS10 = 0x1AA,
 RTW89_HW_RATE_HE_NSS3_MCS11 = 0x1AB,
 RTW89_HW_RATE_HE_NSS4_MCS0 = 0x1B0,
 RTW89_HW_RATE_HE_NSS4_MCS1 = 0x1B1,
 RTW89_HW_RATE_HE_NSS4_MCS2 = 0x1B2,
 RTW89_HW_RATE_HE_NSS4_MCS3 = 0x1B3,
 RTW89_HW_RATE_HE_NSS4_MCS4 = 0x1B4,
 RTW89_HW_RATE_HE_NSS4_MCS5 = 0x1B5,
 RTW89_HW_RATE_HE_NSS4_MCS6 = 0x1B6,
 RTW89_HW_RATE_HE_NSS4_MCS7 = 0x1B7,
 RTW89_HW_RATE_HE_NSS4_MCS8 = 0x1B8,
 RTW89_HW_RATE_HE_NSS4_MCS9 = 0x1B9,
 RTW89_HW_RATE_HE_NSS4_MCS10 = 0x1BA,
 RTW89_HW_RATE_HE_NSS4_MCS11 = 0x1BB,

 RTW89_HW_RATE_V1_MCS0 = 0x100,
 RTW89_HW_RATE_V1_MCS1 = 0x101,
 RTW89_HW_RATE_V1_MCS2 = 0x102,
 RTW89_HW_RATE_V1_MCS3 = 0x103,
 RTW89_HW_RATE_V1_MCS4 = 0x104,
 RTW89_HW_RATE_V1_MCS5 = 0x105,
 RTW89_HW_RATE_V1_MCS6 = 0x106,
 RTW89_HW_RATE_V1_MCS7 = 0x107,
 RTW89_HW_RATE_V1_MCS8 = 0x108,
 RTW89_HW_RATE_V1_MCS9 = 0x109,
 RTW89_HW_RATE_V1_MCS10 = 0x10A,
 RTW89_HW_RATE_V1_MCS11 = 0x10B,
 RTW89_HW_RATE_V1_MCS12 = 0x10C,
 RTW89_HW_RATE_V1_MCS13 = 0x10D,
 RTW89_HW_RATE_V1_MCS14 = 0x10E,
 RTW89_HW_RATE_V1_MCS15 = 0x10F,
 RTW89_HW_RATE_V1_MCS16 = 0x110,
 RTW89_HW_RATE_V1_MCS17 = 0x111,
 RTW89_HW_RATE_V1_MCS18 = 0x112,
 RTW89_HW_RATE_V1_MCS19 = 0x113,
 RTW89_HW_RATE_V1_MCS20 = 0x114,
 RTW89_HW_RATE_V1_MCS21 = 0x115,
 RTW89_HW_RATE_V1_MCS22 = 0x116,
 RTW89_HW_RATE_V1_MCS23 = 0x117,
 RTW89_HW_RATE_V1_MCS24 = 0x118,
 RTW89_HW_RATE_V1_MCS25 = 0x119,
 RTW89_HW_RATE_V1_MCS26 = 0x11A,
 RTW89_HW_RATE_V1_MCS27 = 0x11B,
 RTW89_HW_RATE_V1_MCS28 = 0x11C,
 RTW89_HW_RATE_V1_MCS29 = 0x11D,
 RTW89_HW_RATE_V1_MCS30 = 0x11E,
 RTW89_HW_RATE_V1_MCS31 = 0x11F,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS0 = 0x200,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS1 = 0x201,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS2 = 0x202,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS3 = 0x203,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS4 = 0x204,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS5 = 0x205,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS6 = 0x206,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS7 = 0x207,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS8 = 0x208,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS9 = 0x209,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS10 = 0x20A,
 RTW89_HW_RATE_V1_VHT_NSS1_MCS11 = 0x20B,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS0 = 0x220,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS1 = 0x221,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS2 = 0x222,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS3 = 0x223,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS4 = 0x224,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS5 = 0x225,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS6 = 0x226,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS7 = 0x227,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS8 = 0x228,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS9 = 0x229,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS10 = 0x22A,
 RTW89_HW_RATE_V1_VHT_NSS2_MCS11 = 0x22B,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS0 = 0x240,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS1 = 0x241,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS2 = 0x242,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS3 = 0x243,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS4 = 0x244,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS5 = 0x245,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS6 = 0x246,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS7 = 0x247,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS8 = 0x248,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS9 = 0x249,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS10 = 0x24A,
 RTW89_HW_RATE_V1_VHT_NSS3_MCS11 = 0x24B,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS0 = 0x260,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS1 = 0x261,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS2 = 0x262,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS3 = 0x263,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS4 = 0x264,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS5 = 0x265,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS6 = 0x266,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS7 = 0x267,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS8 = 0x268,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS9 = 0x269,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS10 = 0x26A,
 RTW89_HW_RATE_V1_VHT_NSS4_MCS11 = 0x26B,
 RTW89_HW_RATE_V1_HE_NSS1_MCS0 = 0x300,
 RTW89_HW_RATE_V1_HE_NSS1_MCS1 = 0x301,
 RTW89_HW_RATE_V1_HE_NSS1_MCS2 = 0x302,
 RTW89_HW_RATE_V1_HE_NSS1_MCS3 = 0x303,
 RTW89_HW_RATE_V1_HE_NSS1_MCS4 = 0x304,
 RTW89_HW_RATE_V1_HE_NSS1_MCS5 = 0x305,
 RTW89_HW_RATE_V1_HE_NSS1_MCS6 = 0x306,
 RTW89_HW_RATE_V1_HE_NSS1_MCS7 = 0x307,
 RTW89_HW_RATE_V1_HE_NSS1_MCS8 = 0x308,
 RTW89_HW_RATE_V1_HE_NSS1_MCS9 = 0x309,
 RTW89_HW_RATE_V1_HE_NSS1_MCS10 = 0x30A,
 RTW89_HW_RATE_V1_HE_NSS1_MCS11 = 0x30B,
 RTW89_HW_RATE_V1_HE_NSS2_MCS0 = 0x320,
 RTW89_HW_RATE_V1_HE_NSS2_MCS1 = 0x321,
 RTW89_HW_RATE_V1_HE_NSS2_MCS2 = 0x322,
 RTW89_HW_RATE_V1_HE_NSS2_MCS3 = 0x323,
 RTW89_HW_RATE_V1_HE_NSS2_MCS4 = 0x324,
 RTW89_HW_RATE_V1_HE_NSS2_MCS5 = 0x325,
 RTW89_HW_RATE_V1_HE_NSS2_MCS6 = 0x326,
 RTW89_HW_RATE_V1_HE_NSS2_MCS7 = 0x327,
 RTW89_HW_RATE_V1_HE_NSS2_MCS8 = 0x328,
 RTW89_HW_RATE_V1_HE_NSS2_MCS9 = 0x329,
 RTW89_HW_RATE_V1_HE_NSS2_MCS10 = 0x32A,
 RTW89_HW_RATE_V1_HE_NSS2_MCS11 = 0x32B,
 RTW89_HW_RATE_V1_HE_NSS3_MCS0 = 0x340,
 RTW89_HW_RATE_V1_HE_NSS3_MCS1 = 0x341,
 RTW89_HW_RATE_V1_HE_NSS3_MCS2 = 0x342,
 RTW89_HW_RATE_V1_HE_NSS3_MCS3 = 0x343,
 RTW89_HW_RATE_V1_HE_NSS3_MCS4 = 0x344,
 RTW89_HW_RATE_V1_HE_NSS3_MCS5 = 0x345,
 RTW89_HW_RATE_V1_HE_NSS3_MCS6 = 0x346,
 RTW89_HW_RATE_V1_HE_NSS3_MCS7 = 0x347,
 RTW89_HW_RATE_V1_HE_NSS3_MCS8 = 0x348,
 RTW89_HW_RATE_V1_HE_NSS3_MCS9 = 0x349,
 RTW89_HW_RATE_V1_HE_NSS3_MCS10 = 0x34A,
 RTW89_HW_RATE_V1_HE_NSS3_MCS11 = 0x34B,
 RTW89_HW_RATE_V1_HE_NSS4_MCS0 = 0x360,
 RTW89_HW_RATE_V1_HE_NSS4_MCS1 = 0x361,
 RTW89_HW_RATE_V1_HE_NSS4_MCS2 = 0x362,
 RTW89_HW_RATE_V1_HE_NSS4_MCS3 = 0x363,
 RTW89_HW_RATE_V1_HE_NSS4_MCS4 = 0x364,
 RTW89_HW_RATE_V1_HE_NSS4_MCS5 = 0x365,
 RTW89_HW_RATE_V1_HE_NSS4_MCS6 = 0x366,
 RTW89_HW_RATE_V1_HE_NSS4_MCS7 = 0x367,
 RTW89_HW_RATE_V1_HE_NSS4_MCS8 = 0x368,
 RTW89_HW_RATE_V1_HE_NSS4_MCS9 = 0x369,
 RTW89_HW_RATE_V1_HE_NSS4_MCS10 = 0x36A,
 RTW89_HW_RATE_V1_HE_NSS4_MCS11 = 0x36B,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS0 = 0x400,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS1 = 0x401,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS2 = 0x402,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS3 = 0x403,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS4 = 0x404,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS5 = 0x405,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS6 = 0x406,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS7 = 0x407,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS8 = 0x408,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS9 = 0x409,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS10 = 0x40A,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS11 = 0x40B,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS12 = 0x40C,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS13 = 0x40D,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS14 = 0x40E,
 RTW89_HW_RATE_V1_EHT_NSS1_MCS15 = 0x40F,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS0 = 0x420,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS1 = 0x421,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS2 = 0x422,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS3 = 0x423,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS4 = 0x424,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS5 = 0x425,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS6 = 0x426,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS7 = 0x427,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS8 = 0x428,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS9 = 0x429,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS10 = 0x42A,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS11 = 0x42B,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS12 = 0x42C,
 RTW89_HW_RATE_V1_EHT_NSS2_MCS13 = 0x42D,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS0 = 0x440,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS1 = 0x441,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS2 = 0x442,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS3 = 0x443,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS4 = 0x444,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS5 = 0x445,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS6 = 0x446,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS7 = 0x447,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS8 = 0x448,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS9 = 0x449,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS10 = 0x44A,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS11 = 0x44B,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS12 = 0x44C,
 RTW89_HW_RATE_V1_EHT_NSS3_MCS13 = 0x44D,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS0 = 0x460,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS1 = 0x461,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS2 = 0x462,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS3 = 0x463,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS4 = 0x464,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS5 = 0x465,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS6 = 0x466,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS7 = 0x467,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS8 = 0x468,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS9 = 0x469,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS10 = 0x46A,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS11 = 0x46B,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS12 = 0x46C,
 RTW89_HW_RATE_V1_EHT_NSS4_MCS13 = 0x46D,

 RTW89_HW_RATE_NR,
 RTW89_HW_RATE_INVAL,

 RTW89_HW_RATE_MASK_MOD = ((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((7) > (8)) * 0l)) : (int *)8))), (7) > (8), false)), "const_true((7) > (8))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (7) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (8))))),
 RTW89_HW_RATE_MASK_VAL = ((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((0) > (6)) * 0l)) : (int *)8))), (0) > (6), false)), "const_true((0) > (6))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (0) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (6))))),
 RTW89_HW_RATE_V1_MASK_MOD = ((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (10)) * 0l)) : (int *)8))), (8) > (10), false)), "const_true((8) > (10))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (10))))),
 RTW89_HW_RATE_V1_MASK_VAL = ((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((0) > (7)) * 0l)) : (int *)8))), (0) > (7), false)), "const_true((0) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (0) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))),
};
enum rtw89_rate_section {
 RTW89_RS_CCK,
 RTW89_RS_OFDM,
 RTW89_RS_MCS,
 RTW89_RS_HEDCM,
 RTW89_RS_OFFSET,
 RTW89_RS_NUM,
 RTW89_RS_LMT_NUM = RTW89_RS_MCS + 1,
 RTW89_RS_TX_SHAPE_NUM = RTW89_RS_OFDM + 1,
};
enum rtw89_rate_offset_indexes {
 RTW89_RATE_OFFSET_HE,
 RTW89_RATE_OFFSET_VHT,
 RTW89_RATE_OFFSET_HT,
 RTW89_RATE_OFFSET_OFDM,
 RTW89_RATE_OFFSET_CCK,
 RTW89_RATE_OFFSET_DLRU_EHT,
 RTW89_RATE_OFFSET_DLRU_HE,
 RTW89_RATE_OFFSET_EHT,
 __RTW89_RATE_OFFSET_NUM,

 RTW89_RATE_OFFSET_NUM_AX = RTW89_RATE_OFFSET_CCK + 1,
 RTW89_RATE_OFFSET_NUM_BE = RTW89_RATE_OFFSET_EHT + 1,
};
enum rtw89_rate_num {
 RTW89_RATE_CCK_NUM = 4,
 RTW89_RATE_OFDM_NUM = 8,
 RTW89_RATE_HEDCM_NUM = 4,

 RTW89_RATE_MCS_NUM_AX = 12,
 RTW89_RATE_MCS_NUM_BE = 16,
 __RTW89_RATE_MCS_NUM = 16,
};
enum rtw89_nss {
 RTW89_NSS_1 = 0,
 RTW89_NSS_2 = 1,

 RTW89_NSS_HEDCM_NUM = RTW89_NSS_2 + 1,
 RTW89_NSS_3 = 2,
 RTW89_NSS_4 = 3,
 RTW89_NSS_NUM,
};
enum rtw89_ntx {
 RTW89_1TX = 0,
 RTW89_2TX = 1,
 RTW89_NTX_NUM,
};
enum rtw89_beamforming_type {
 RTW89_NONBF = 0,
 RTW89_BF = 1,
 RTW89_BF_NUM,
};
enum rtw89_ofdma_type {
 RTW89_NON_OFDMA = 0,
 RTW89_OFDMA = 1,
 RTW89_OFDMA_NUM,
};
enum rtw89_regulation_type {
 RTW89_WW = 0,
 RTW89_ETSI = 1,
 RTW89_FCC = 2,
 RTW89_MKK = 3,
 RTW89_NA = 4,
 RTW89_IC = 5,
 RTW89_KCC = 6,
 RTW89_ACMA = 7,
 RTW89_NCC = 8,
 RTW89_MEXICO = 9,
 RTW89_CHILE = 10,
 RTW89_UKRAINE = 11,
 RTW89_CN = 12,
 RTW89_QATAR = 13,
 RTW89_UK = 14,
 RTW89_THAILAND = 15,
 RTW89_REGD_NUM,
};
enum rtw89_reg_6ghz_power {
 RTW89_REG_6GHZ_POWER_VLP = 0,
 RTW89_REG_6GHZ_POWER_LPI = 1,
 RTW89_REG_6GHZ_POWER_STD = 2,

 NUM_OF_RTW89_REG_6GHZ_POWER,
 RTW89_REG_6GHZ_POWER_DFLT = RTW89_REG_6GHZ_POWER_VLP,
};
struct rtw89_reg_6ghz_tpe {
 bool valid;
 s8 constraint;
};
struct rtw89_txpwr_byrate {
 s8 cck[RTW89_RATE_CCK_NUM];
 s8 ofdm[RTW89_RATE_OFDM_NUM];
 s8 mcs[RTW89_OFDMA_NUM][RTW89_NSS_NUM][__RTW89_RATE_MCS_NUM];
 s8 hedcm[RTW89_OFDMA_NUM][RTW89_NSS_HEDCM_NUM][RTW89_RATE_HEDCM_NUM];
 s8 offset[__RTW89_RATE_OFFSET_NUM];
 s8 trap;
};
struct rtw89_rx_phy_ppdu {
 void *buf;
 u32 len;
 u8 rssi_avg;
 u8 rssi[4];
 u8 mac_id;
 u8 chan_idx;
 u8 phy_idx;
 u8 ie;
 u16 rate;
 u8 rpl_avg;
 u8 rpl_path[4];
 u8 rpl_fd[4];
 u8 bw_idx;
 u8 rx_path_en;
 struct {
  bool has;
  u8 avg_snr;
  u8 evm_max;
  u8 evm_min;
 } ofdm;
 bool has_data;
 bool has_bcn;
 bool ldpc;
 bool stbc;
 bool to_self;
 bool valid;
 bool hdr_2_en;
};
enum rtw89_mac_idx {
 RTW89_MAC_0 = 0,
 RTW89_MAC_1 = 1,
 RTW89_MAC_NUM,
};
enum rtw89_phy_idx {
 RTW89_PHY_0 = 0,
 RTW89_PHY_1 = 1,
 RTW89_PHY_NUM,
};
enum rtw89_chanctx_idx {
 RTW89_CHANCTX_0 = 0,
 RTW89_CHANCTX_1 = 1,

 NUM_OF_RTW89_CHANCTX,
 RTW89_CHANCTX_IDLE = NUM_OF_RTW89_CHANCTX,
};
enum rtw89_rf_path {
 RF_PATH_A = 0,
 RF_PATH_B = 1,
 RF_PATH_C = 2,
 RF_PATH_D = 3,
 RF_PATH_AB,
 RF_PATH_AC,
 RF_PATH_AD,
 RF_PATH_BC,
 RF_PATH_BD,
 RF_PATH_CD,
 RF_PATH_ABC,
 RF_PATH_ABD,
 RF_PATH_ACD,
 RF_PATH_BCD,
 RF_PATH_ABCD,
};
enum rtw89_bandwidth {
 RTW89_CHANNEL_WIDTH_20 = 0,
 RTW89_CHANNEL_WIDTH_40 = 1,
 RTW89_CHANNEL_WIDTH_80 = 2,
 RTW89_CHANNEL_WIDTH_160 = 3,
 RTW89_CHANNEL_WIDTH_320 = 4,


 RTW89_CHANNEL_WIDTH_ORDINARY_NUM = 5,

 RTW89_CHANNEL_WIDTH_80_80 = 5,
 RTW89_CHANNEL_WIDTH_5 = 6,
 RTW89_CHANNEL_WIDTH_10 = 7,
};
enum rtw89_ps_mode {
 RTW89_PS_MODE_NONE = 0,
 RTW89_PS_MODE_RFOFF = 1,
 RTW89_PS_MODE_CLK_GATED = 2,
 RTW89_PS_MODE_PWR_GATED = 3,
};
enum rtw89_ru_bandwidth {
 RTW89_RU26 = 0,
 RTW89_RU52 = 1,
 RTW89_RU106 = 2,
 RTW89_RU52_26 = 3,
 RTW89_RU106_26 = 4,
 RTW89_RU_NUM,
};
enum rtw89_sc_offset {
 RTW89_SC_DONT_CARE = 0,
 RTW89_SC_20_UPPER = 1,
 RTW89_SC_20_LOWER = 2,
 RTW89_SC_20_UPMOST = 3,
 RTW89_SC_20_LOWEST = 4,
 RTW89_SC_20_UP2X = 5,
 RTW89_SC_20_LOW2X = 6,
 RTW89_SC_20_UP3X = 7,
 RTW89_SC_20_LOW3X = 8,
 RTW89_SC_40_UPPER = 9,
 RTW89_SC_40_LOWER = 10,
};
enum rtw89_wow_flags {
 RTW89_WOW_FLAG_EN_MAGIC_PKT,
 RTW89_WOW_FLAG_EN_REKEY_PKT,
 RTW89_WOW_FLAG_EN_DISCONNECT,
 RTW89_WOW_FLAG_EN_PATTERN,
 RTW89_WOW_FLAG_NUM,
};
struct rtw89_chan {
 u8 channel;
 u8 primary_channel;
 enum rtw89_band band_type;
 enum rtw89_bandwidth band_width;




 u32 freq;
 enum rtw89_subband subband_type;
 enum rtw89_sc_offset pri_ch_idx;
 u8 pri_sb_idx;
};
struct rtw89_chan_rcd {
 u8 prev_primary_channel;
 enum rtw89_band prev_band_type;
 bool band_changed;
};
struct rtw89_channel_help_params {
 u32 tx_en;
};
struct rtw89_port_reg {
 u32 port_cfg;
 u32 tbtt_prohib;
 u32 bcn_area;
 u32 bcn_early;
 u32 tbtt_early;
 u32 tbtt_agg;
 u32 bcn_space;
 u32 bcn_forcetx;
 u32 bcn_err_cnt;
 u32 bcn_err_flag;
 u32 dtim_ctrl;
 u32 tbtt_shift;
 u32 bcn_cnt_tmr;
 u32 tsftr_l;
 u32 tsftr_h;
 u32 md_tsft;
 u32 bss_color;
 u32 mbssid;
 u32 mbssid_drop;
 u32 tsf_sync;
 u32 ptcl_dbg;
 u32 ptcl_dbg_info;
 u32 bcn_drop_all;
 u32 bcn_psr_rpt;
 u32 hiq_win[RTW89_PORT_NUM];
};
struct rtw89_rx_desc_info {
 u16 pkt_size;
 u8 pkt_type;
 u8 drv_info_size;
 u8 phy_rpt_size;
 u8 hdr_cnv_size;
 u8 shift;
 u8 wl_hd_iv_len;
 bool long_rxdesc;
 bool bb_sel;
 bool mac_info_valid;
 u16 data_rate;
 u8 gi_ltf;
 u8 bw;
 u32 free_run_cnt;
 u8 user_id;
 bool sr_en;
 u8 ppdu_cnt;
 u8 ppdu_type;
 bool icv_err;
 bool crc32_err;
 bool hw_dec;
 bool sw_dec;
 bool addr1_match;
 u8 frag;
 u16 seq;
 u8 frame_type;
 u8 rx_pl_id;
 bool addr_cam_valid;
 u8 addr_cam_id;
 u8 sec_cam_id;
 u8 mac_id;
 u16 offset;
 u16 rxd_len;
 bool ready;
 u16 rssi;
};
struct rtw89_tx_desc_info {
 u16 pkt_size;
 u8 wp_offset;
 u8 mac_id;
 u8 qsel;
 u8 ch_dma;
 u8 hdr_llc_len;
 bool is_bmc;
 bool en_wd_info;
 bool wd_page;
 bool use_rate;
 bool dis_data_fb;
 bool tid_indicate;
 bool agg_en;
 bool bk;
 u8 ampdu_density;
 u8 ampdu_num;
 bool sec_en;
 u8 addr_info_nr;
 u8 sec_keyid;
 u8 sec_type;
 u8 sec_cam_idx;
 u8 sec_seq[6];
 u16 data_rate;
 u16 data_retry_lowest_rate;
 bool fw_dl;
 u16 seq;
 bool a_ctrl_bsr;
 u8 hw_ssn_sel;
 u8 hw_seq_mode;
 bool hiq;
 u8 port;
 bool er_cap;
 bool stbc;
 bool ldpc;
 bool upd_wlan_hdr;
 bool mlo;
 bool sw_mld;
};
struct rtw89_core_tx_request {
 enum rtw89_core_tx_type tx_type;

 struct sk_buff *skb;
 struct ieee80211_vif *vif;
 struct ieee80211_sta *sta;
 struct rtw89_vif_link *rtwvif_link;
 struct rtw89_sta_link *rtwsta_link;
 struct rtw89_tx_desc_info desc_info;
};
struct rtw89_mac_ax_gnt {
 u8 gnt_bt_sw_en;
 u8 gnt_bt;
 u8 gnt_wl_sw_en;
 u8 gnt_wl;
} __attribute__((__packed__));
struct rtw89_mac_ax_wl_act {
 u8 wlan_act_en;
 u8 wlan_act;
} __attribute__((__packed__));
struct rtw89_mac_ax_coex_gnt {
 struct rtw89_mac_ax_gnt band[2];
 struct rtw89_mac_ax_wl_act bt[2];
};
enum rtw89_btc_ncnt {
 BTC_NCNT_POWER_ON = 0x0,
 BTC_NCNT_POWER_OFF,
 BTC_NCNT_INIT_COEX,
 BTC_NCNT_SCAN_START,
 BTC_NCNT_SCAN_FINISH,
 BTC_NCNT_SPECIAL_PACKET,
 BTC_NCNT_SWITCH_BAND,
 BTC_NCNT_RFK_TIMEOUT,
 BTC_NCNT_SHOW_COEX_INFO,
 BTC_NCNT_ROLE_INFO,
 BTC_NCNT_CONTROL,
 BTC_NCNT_RADIO_STATE,
 BTC_NCNT_CUSTOMERIZE,
 BTC_NCNT_WL_RFK,
 BTC_NCNT_WL_STA,
 BTC_NCNT_WL_STA_LAST,
 BTC_NCNT_FWINFO,
 BTC_NCNT_TIMER,
 BTC_NCNT_SWITCH_CHBW,
 BTC_NCNT_RESUME_DL_FW,
 BTC_NCNT_COUNTRYCODE,
 BTC_NCNT_NUM,
};
enum rtw89_btc_btinfo {
 BTC_BTINFO_L0 = 0,
 BTC_BTINFO_L1,
 BTC_BTINFO_L2,
 BTC_BTINFO_L3,
 BTC_BTINFO_H0,
 BTC_BTINFO_H1,
 BTC_BTINFO_H2,
 BTC_BTINFO_H3,
 BTC_BTINFO_MAX
};
enum rtw89_btc_dcnt {
 BTC_DCNT_RUN = 0x0,
 BTC_DCNT_CX_RUNINFO,
 BTC_DCNT_RPT,
 BTC_DCNT_RPT_HANG,
 BTC_DCNT_CYCLE,
 BTC_DCNT_CYCLE_HANG,
 BTC_DCNT_W1,
 BTC_DCNT_W1_HANG,
 BTC_DCNT_B1,
 BTC_DCNT_B1_HANG,
 BTC_DCNT_TDMA_NONSYNC,
 BTC_DCNT_SLOT_NONSYNC,
 BTC_DCNT_BTCNT_HANG,
 BTC_DCNT_BTTX_HANG,
 BTC_DCNT_WL_SLOT_DRIFT,
 BTC_DCNT_WL_STA_LAST,
 BTC_DCNT_BT_SLOT_DRIFT,
 BTC_DCNT_BT_SLOT_FLOOD,
 BTC_DCNT_FDDT_TRIG,
 BTC_DCNT_E2G,
 BTC_DCNT_E2G_HANG,
 BTC_DCNT_WL_FW_VER_MATCH,
 BTC_DCNT_NULL_TX_FAIL,
 BTC_DCNT_WL_STA_NTFY,
 BTC_DCNT_NUM,
};
enum rtw89_btc_wl_state_cnt {
 BTC_WCNT_SCANAP = 0x0,
 BTC_WCNT_DHCP,
 BTC_WCNT_EAPOL,
 BTC_WCNT_ARP,
 BTC_WCNT_SCBDUPDATE,
 BTC_WCNT_RFK_REQ,
 BTC_WCNT_RFK_GO,
 BTC_WCNT_RFK_REJECT,
 BTC_WCNT_RFK_TIMEOUT,
 BTC_WCNT_CH_UPDATE,
 BTC_WCNT_DBCC_ALL_2G,
 BTC_WCNT_DBCC_CHG,
 BTC_WCNT_RX_OK_LAST,
 BTC_WCNT_RX_OK_LAST2S,
 BTC_WCNT_RX_ERR_LAST,
 BTC_WCNT_RX_ERR_LAST2S,
 BTC_WCNT_RX_LAST,
 BTC_WCNT_NUM
};
enum rtw89_btc_bt_state_cnt {
 BTC_BCNT_RETRY = 0x0,
 BTC_BCNT_REINIT,
 BTC_BCNT_REENABLE,
 BTC_BCNT_SCBDREAD,
 BTC_BCNT_RELINK,
 BTC_BCNT_IGNOWL,
 BTC_BCNT_INQPAG,
 BTC_BCNT_INQ,
 BTC_BCNT_PAGE,
 BTC_BCNT_ROLESW,
 BTC_BCNT_AFH,
 BTC_BCNT_INFOUPDATE,
 BTC_BCNT_INFOSAME,
 BTC_BCNT_SCBDUPDATE,
 BTC_BCNT_HIPRI_TX,
 BTC_BCNT_HIPRI_RX,
 BTC_BCNT_LOPRI_TX,
 BTC_BCNT_LOPRI_RX,
 BTC_BCNT_POLUT,
 BTC_BCNT_POLUT_NOW,
 BTC_BCNT_POLUT_DIFF,
 BTC_BCNT_RATECHG,
 BTC_BCNT_BTTXPWR_UPDATE,
 BTC_BCNT_NUM,
};
enum rtw89_btc_bt_profile {
 BTC_BT_NOPROFILE = 0,
 BTC_BT_HFP = ((((1UL))) << (0)),
 BTC_BT_HID = ((((1UL))) << (1)),
 BTC_BT_A2DP = ((((1UL))) << (2)),
 BTC_BT_PAN = ((((1UL))) << (3)),
 BTC_PROFILE_MAX = 4,
};
struct rtw89_btc_ant_info {
 u8 type;
 u8 num;
 u8 isolation;

 u8 single_pos: 1;
 u8 diversity: 1;
 u8 btg_pos: 2;
 u8 stream_cnt: 4;
};
struct rtw89_btc_ant_info_v7 {
 u8 type;
 u8 num;
 u8 isolation;
 u8 single_pos;

 u8 diversity;
 u8 btg_pos;
 u8 stream_cnt;
 u8 rsvd;
} __attribute__((__packed__));
enum rtw89_tfc_dir {
 RTW89_TFC_UL,
 RTW89_TFC_DL,
};
struct rtw89_btc_wl_smap {
 u32 busy: 1;
 u32 scan: 1;
 u32 connecting: 1;
 u32 roaming: 1;
 u32 dbccing: 1;
 u32 _4way: 1;
 u32 rf_off: 1;
 u32 lps: 2;
 u32 ips: 1;
 u32 init_ok: 1;
 u32 traffic_dir : 2;
 u32 rf_off_pre: 1;
 u32 lps_pre: 2;
 u32 lps_exiting: 1;
 u32 emlsr: 1;
};
enum rtw89_tfc_lv {
 RTW89_TFC_IDLE,
 RTW89_TFC_ULTRA_LOW,
 RTW89_TFC_LOW,
 RTW89_TFC_MID,
 RTW89_TFC_HIGH,
};
struct ewma_tp { unsigned long internal; };
struct rtw89_traffic_stats {

 u64 tx_unicast;
 u64 rx_unicast;
 u32 tx_avg_len;
 u32 rx_avg_len;


 u64 tx_cnt;
 u64 rx_cnt;


 u32 tx_throughput;
 u32 rx_throughput;
 u32 tx_throughput_raw;
 u32 rx_throughput_raw;

 u32 rx_tf_acc;
 u32 rx_tf_periodic;

 enum rtw89_tfc_lv tx_tfc_lv;
 enum rtw89_tfc_lv rx_tfc_lv;
 struct ewma_tp tx_ewma_tp;
 struct ewma_tp rx_ewma_tp;

 u16 tx_rate;
 u16 rx_rate;
};
struct rtw89_btc_chdef {
 u8 center_ch;
 u8 band;
 u8 chan;
 enum rtw89_sc_offset offset;
 enum rtw89_bandwidth bw;
};
struct rtw89_btc_statistic {
 u8 rssi;
 struct rtw89_traffic_stats traffic;
};
struct rtw89_btc_wl_link_info {
 struct rtw89_btc_chdef chdef;
 struct rtw89_btc_statistic stat;
 enum rtw89_tfc_dir dir;
 u8 rssi_state[4];
 u8 mac_addr[6];
 u8 busy;
 u8 ch;
 u8 bw;
 u8 band;
 u8 role;
 u8 pid;
 u8 phy;
 u8 dtim_period;
 u8 mode;
 u8 tx_1ss_limit;

 u8 mac_id;
 u8 tx_retry;

 u32 bcn_period;
 u32 busy_t;
 u32 tx_time;
 u32 client_cnt;
 u32 rx_rate_drop_cnt;
 u32 noa_duration;

 u32 active: 1;
 u32 noa: 1;
 u32 client_ps: 1;
 u32 connected: 2;
};
union rtw89_btc_wl_state_map {
 u32 val;
 struct rtw89_btc_wl_smap map;
};
struct rtw89_btc_bt_hfp_desc {
 u32 exist: 1;
 u32 type: 2;
 u32 rsvd: 29;
};
struct rtw89_btc_bt_hid_desc {
 u32 exist: 1;
 u32 slot_info: 2;
 u32 pair_cnt: 2;
 u32 type: 8;
 u32 rsvd: 19;
};
struct rtw89_btc_bt_a2dp_desc {
 u8 exist: 1;
 u8 exist_last: 1;
 u8 play_latency: 1;
 u8 type: 3;
 u8 active: 1;
 u8 sink: 1;
 u32 handle_update: 1;
 u32 devinfo_query: 1;
 u32 no_empty_streak_2s: 8;
 u32 no_empty_streak_max: 8;
 u32 rsvd: 6;

 u8 bitpool;
 u16 vendor_id;
 u32 device_name;
 u32 flush_time;
};
struct rtw89_btc_bt_pan_desc {
 u32 exist: 1;
 u32 type: 1;
 u32 active: 1;
 u32 rsvd: 29;
};
struct rtw89_btc_bt_rfk_info {
 u32 run: 1;
 u32 req: 1;
 u32 timeout: 1;
 u32 rsvd: 29;
};
union rtw89_btc_bt_rfk_info_map {
 u32 val;
 struct rtw89_btc_bt_rfk_info map;
};
struct rtw89_btc_bt_ver_info {
 u32 fw_coex;
 u32 fw;
};
struct rtw89_btc_bool_sta_chg {
 u32 now: 1;
 u32 last: 1;
 u32 remain: 1;
 u32 srvd: 29;
};
struct rtw89_btc_u8_sta_chg {
 u8 now;
 u8 last;
 u8 remain;
 u8 rsvd;
};
struct rtw89_btc_wl_scan_info {
 u8 band[RTW89_PHY_NUM];
 u8 phy_map;
 u8 rsvd;
};
struct rtw89_btc_wl_dbcc_info {
 u8 op_band[RTW89_PHY_NUM];
 u8 scan_band[RTW89_PHY_NUM];
 u8 real_band[RTW89_PHY_NUM];
 u8 role[RTW89_PHY_NUM];
};
struct rtw89_btc_wl_mlo_info {
 u8 wmode[RTW89_PHY_NUM];
 u8 ch_type[RTW89_PHY_NUM];
 u8 hwb_rf_band[RTW89_PHY_NUM];
 u8 path_rf_band[RTW89_PHY_NUM];

 u8 wtype;
 u8 mrcx_mode;
 u8 mrcx_act_hwb_map;
 u8 mrcx_bt_slot_rsp;

 u8 rf_combination;
 u8 mlo_en;
 u8 mlo_adie;
 u8 dual_hw_band_en;

 u32 link_status;
};
struct rtw89_btc_wl_active_role {
 u8 connected: 1;
 u8 pid: 3;
 u8 phy: 1;
 u8 noa: 1;
 u8 band: 2;

 u8 client_ps: 1;
 u8 bw: 7;

 u8 role;
 u8 ch;

 u16 tx_lvl;
 u16 rx_lvl;
 u16 tx_rate;
 u16 rx_rate;
};
struct rtw89_btc_wl_active_role_v1 {
 u8 connected: 1;
 u8 pid: 3;
 u8 phy: 1;
 u8 noa: 1;
 u8 band: 2;

 u8 client_ps: 1;
 u8 bw: 7;

 u8 role;
 u8 ch;

 u16 tx_lvl;
 u16 rx_lvl;
 u16 tx_rate;
 u16 rx_rate;

 u32 noa_duration;
};
struct rtw89_btc_wl_active_role_v2 {
 u8 connected: 1;
 u8 pid: 3;
 u8 phy: 1;
 u8 noa: 1;
 u8 band: 2;

 u8 client_ps: 1;
 u8 bw: 7;

 u8 role;
 u8 ch;

 u32 noa_duration;
};
struct rtw89_btc_wl_active_role_v7 {
 u8 connected;
 u8 pid;
 u8 phy;
 u8 noa;

 u8 band;
 u8 client_ps;
 u8 bw;
 u8 role;

 u8 ch;
 u8 noa_dur;
 u8 client_cnt;
 u8 rsvd2;
} __attribute__((__packed__));
struct rtw89_btc_wl_role_info_bpos {
 u16 none: 1;
 u16 station: 1;
 u16 ap: 1;
 u16 vap: 1;
 u16 adhoc: 1;
 u16 adhoc_master: 1;
 u16 mesh: 1;
 u16 moniter: 1;
 u16 p2p_device: 1;
 u16 p2p_gc: 1;
 u16 p2p_go: 1;
 u16 nan: 1;
};
struct rtw89_btc_wl_scc_ctrl {
 u8 null_role1;
 u8 null_role2;
 u8 ebt_null;
};
union rtw89_btc_wl_role_info_map {
 u16 val;
 struct rtw89_btc_wl_role_info_bpos role;
};
struct rtw89_btc_wl_role_info {
 u8 connect_cnt;
 u8 link_mode;
 union rtw89_btc_wl_role_info_map role_map;
 struct rtw89_btc_wl_active_role active_role[RTW89_PORT_NUM];
};
struct rtw89_btc_wl_role_info_v1 {
 u8 connect_cnt;
 u8 link_mode;
 union rtw89_btc_wl_role_info_map role_map;
 struct rtw89_btc_wl_active_role_v1 active_role_v1[RTW89_PORT_NUM];
 u32 mrole_type;
 u32 mrole_noa_duration;

 u32 dbcc_en: 1;
 u32 dbcc_chg: 1;
 u32 dbcc_2g_phy: 2;
 u32 link_mode_chg: 1;
 u32 rsvd: 27;
};
struct rtw89_btc_wl_role_info_v2 {
 u8 connect_cnt;
 u8 link_mode;
 union rtw89_btc_wl_role_info_map role_map;
 struct rtw89_btc_wl_active_role_v2 active_role_v2[RTW89_PORT_NUM];
 u32 mrole_type;
 u32 mrole_noa_duration;

 u32 dbcc_en: 1;
 u32 dbcc_chg: 1;
 u32 dbcc_2g_phy: 2;
 u32 link_mode_chg: 1;
 u32 rsvd: 27;
};
struct rtw89_btc_wl_rlink {
 u8 connected;
 u8 pid;
 u8 phy;
 u8 noa;

 u8 rf_band;
 u8 active;
 u8 bw;
 u8 role;

 u8 ch;
 u8 noa_dur;
 u8 client_cnt;
 u8 mode;
} __attribute__((__packed__));
struct rtw89_btc_wl_role_info_v7 {
 u8 connect_cnt;
 u8 link_mode;
 u8 link_mode_chg;
 u8 p2p_2g;

 struct rtw89_btc_wl_active_role_v7 active_role[6];

 u32 role_map;
 u32 mrole_type;
 u32 mrole_noa_duration;
 u32 dbcc_en;
 u32 dbcc_chg;
 u32 dbcc_2g_phy;
} __attribute__((__packed__));
struct rtw89_btc_wl_role_info_v8 {
 u8 connect_cnt;
 u8 link_mode;
 u8 link_mode_chg;
 u8 p2p_2g;

 u8 pta_req_band;
 u8 dbcc_en;
 u8 dbcc_chg;
 u8 dbcc_2g_phy;

 struct rtw89_btc_wl_rlink rlink[6][RTW89_MAC_NUM];

 u32 role_map;
 u32 mrole_type;
 u32 mrole_noa_duration;
} __attribute__((__packed__));
struct rtw89_btc_wl_ver_info {
 u32 fw_coex;
 u32 fw;
 u32 mac;
 u32 bb;
 u32 rf;
};
struct rtw89_btc_wl_afh_info {
 u8 en;
 u8 ch;
 u8 bw;
 u8 rsvd;
} __attribute__((__packed__));
struct rtw89_btc_wl_rfk_info {
 u32 state: 2;
 u32 path_map: 4;
 u32 phy_map: 2;
 u32 band: 2;
 u32 type: 8;
 u32 con_rfk: 1;
 u32 rsvd: 13;

 u32 start_time;
 u32 proc_time;
};
struct rtw89_btc_bt_smap {
 u32 connect: 1;
 u32 ble_connect: 1;
 u32 acl_busy: 1;
 u32 sco_busy: 1;
 u32 mesh_busy: 1;
 u32 inq_pag: 1;
};
union rtw89_btc_bt_state_map {
 u32 val;
 struct rtw89_btc_bt_smap map;
};
struct rtw89_btc_bt_txpwr_desc {
 s8 br_dbm;
 s8 le_dbm;
 u8 br_gain_index;
 u8 le_gain_index;
};
struct rtw89_btc_bt_link_info {
 struct rtw89_btc_u8_sta_chg profile_cnt;
 struct rtw89_btc_bool_sta_chg multi_link;
 struct rtw89_btc_bool_sta_chg relink;
 struct rtw89_btc_bt_hfp_desc hfp_desc;
 struct rtw89_btc_bt_hid_desc hid_desc;
 struct rtw89_btc_bt_a2dp_desc a2dp_desc;
 struct rtw89_btc_bt_pan_desc pan_desc;
 union rtw89_btc_bt_state_map status;
 struct rtw89_btc_bt_txpwr_desc bt_txpwr_desc;

 u8 sut_pwr_level[BTC_PROFILE_MAX];
 u8 golden_rx_shift[BTC_PROFILE_MAX];
 u8 rssi_state[4];
 u8 afh_map[12];
 u8 afh_map_le[5];

 u32 role_sw: 1;
 u32 slave_role: 1;
 u32 afh_update: 1;
 u32 cqddr: 1;
 u32 rssi: 8;
 u32 tx_3m: 1;
 u32 rsvd: 19;
};
struct rtw89_btc_3rdcx_info {
 u8 type;
 u8 hw_coex;
 u16 rsvd;
};
struct rtw89_btc_dm_emap {
 u32 init: 1;
 u32 pta_owner: 1;
 u32 wl_rfk_timeout: 1;
 u32 bt_rfk_timeout: 1;
 u32 wl_fw_hang: 1;
 u32 cycle_hang: 1;
 u32 w1_hang: 1;
 u32 b1_hang: 1;
 u32 tdma_no_sync: 1;
 u32 slot_no_sync: 1;
 u32 wl_slot_drift: 1;
 u32 bt_slot_drift: 1;
 u32 role_num_mismatch: 1;
 u32 null1_tx_late: 1;
 u32 bt_afh_conflict: 1;
 u32 bt_leafh_conflict: 1;
 u32 bt_slot_flood: 1;
 u32 wl_e2g_hang: 1;
 u32 wl_ver_mismatch: 1;
 u32 bt_ver_mismatch: 1;
 u32 rfe_type0: 1;
 u32 h2c_buffer_over: 1;
 u32 bt_tx_hang: 1;
 u32 wl_no_sta_ntfy: 1;

 u32 h2c_bmap_mismatch: 1;
 u32 c2h_bmap_mismatch: 1;
 u32 h2c_struct_invalid: 1;
 u32 c2h_struct_invalid: 1;
 u32 h2c_c2h_buffer_mismatch: 1;
};
union rtw89_btc_dm_error_map {
 u32 val;
 struct rtw89_btc_dm_emap map;
};
struct rtw89_btc_rf_para {
 u32 tx_pwr_freerun;
 u32 rx_gain_freerun;
 u32 tx_pwr_perpkt;
 u32 rx_gain_perpkt;
};
struct rtw89_btc_wl_nhm {
 u8 instant_wl_nhm_dbm;
 u8 instant_wl_nhm_per_mhz;
 u16 valid_record_times;
 s8 record_pwr[16];
 u8 record_ratio[16];
 s8 pwr;
 u8 ratio;
 u8 current_status;
 u8 refresh;
 bool start_flag;
 s8 pwr_max;
 s8 pwr_min;
};
struct rtw89_btc_wl_info {
 struct rtw89_btc_wl_link_info link_info[RTW89_PORT_NUM];
 struct rtw89_btc_wl_link_info rlink_info[6][RTW89_MAC_NUM];
 struct rtw89_btc_wl_rfk_info rfk_info;
 struct rtw89_btc_wl_ver_info ver_info;
 struct rtw89_btc_wl_afh_info afh_info;
 struct rtw89_btc_wl_role_info role_info;
 struct rtw89_btc_wl_role_info_v1 role_info_v1;
 struct rtw89_btc_wl_role_info_v2 role_info_v2;
 struct rtw89_btc_wl_role_info_v7 role_info_v7;
 struct rtw89_btc_wl_role_info_v8 role_info_v8;
 struct rtw89_btc_wl_scan_info scan_info;
 struct rtw89_btc_wl_dbcc_info dbcc_info;
 struct rtw89_btc_wl_mlo_info mlo_info;
 struct rtw89_btc_rf_para rf_para;
 struct rtw89_btc_wl_nhm nhm;
 union rtw89_btc_wl_state_map status;

 u8 port_id[RTW89_WIFI_ROLE_MLME_MAX];
 u8 rssi_level;
 u8 cn_report;
 u8 coex_mode;
 u8 pta_req_mac;
 u8 bt_polut_type[RTW89_PHY_NUM];

 bool is_5g_hi_channel;
 bool go_client_exist;
 bool noa_exist;
 bool pta_reg_mac_chg;
 bool bg_mode;
 bool he_mode;
 bool scbd_change;
 bool fw_ver_mismatch;
 bool client_cnt_inc_2g;
 bool link_mode_chg;
 bool dbcc_chg;
 u32 scbd;
};
struct rtw89_btc_module {
 struct rtw89_btc_ant_info ant;
 u8 rfe_type;
 u8 cv;

 u8 bt_solo: 1;
 u8 bt_pos: 1;
 u8 switch_type: 1;
 u8 wa_type: 3;

 u8 kt_ver_adie;
};
struct rtw89_btc_module_v7 {
 u8 rfe_type;
 u8 kt_ver;
 u8 bt_solo;
 u8 bt_pos;

 u8 switch_type;
 u8 wa_type;
 u8 kt_ver_adie;
 u8 rsvd;

 struct rtw89_btc_ant_info_v7 ant;
} __attribute__((__packed__));
union rtw89_btc_module_info {
 struct rtw89_btc_module md;
 struct rtw89_btc_module_v7 md_v7;
};
struct rtw89_btc_dm_step {
 u16 step[30];
 u8 step_pos;
 bool step_ov;
};
struct rtw89_btc_init_info {
 struct rtw89_btc_module module;
 u8 wl_guard_ch;

 u8 wl_only: 1;
 u8 wl_init_ok: 1;
 u8 dbcc_en: 1;
 u8 cx_other: 1;
 u8 bt_only: 1;

 u16 rsvd;
};
struct rtw89_btc_init_info_v7 {
 u8 wl_guard_ch;
 u8 wl_only;
 u8 wl_init_ok;
 u8 rsvd3;

 u8 cx_other;
 u8 bt_only;
 u8 pta_mode;
 u8 pta_direction;

 struct rtw89_btc_module_v7 module;
} __attribute__((__packed__));
union rtw89_btc_init_info_u {
 struct rtw89_btc_init_info init;
 struct rtw89_btc_init_info_v7 init_v7;
};
struct rtw89_btc_wl_tx_limit_para {
 u16 enable;
 u32 tx_time;
 u16 tx_retry;
};
enum rtw89_btc_bt_scan_type {
 BTC_SCAN_INQ = 0,
 BTC_SCAN_PAGE,
 BTC_SCAN_BLE,
 BTC_SCAN_INIT,
 BTC_SCAN_TV,
 BTC_SCAN_ADV,
 BTC_SCAN_MAX1,
};
enum rtw89_btc_ble_scan_type {
 CXSCAN_BG = 0,
 CXSCAN_INIT,
 CXSCAN_LE,
 CXSCAN_MAX
};
struct rtw89_btc_bt_scan_info_v1 {
 __le16 win;
 __le16 intvl;
 __le32 flags;
} __attribute__((__packed__));
struct rtw89_btc_bt_scan_info_v2 {
 __le16 win;
 __le16 intvl;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btscan_v1 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 struct rtw89_btc_bt_scan_info_v1 scan[BTC_SCAN_MAX1];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btscan_v2 {
 u8 fver;
 u8 type;
 __le16 rsvd2;
 struct rtw89_btc_bt_scan_info_v2 para[CXSCAN_MAX];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btscan_v7 {
 u8 fver;
 u8 type;
 u8 rsvd0;
 u8 rsvd1;
 struct rtw89_btc_bt_scan_info_v2 para[CXSCAN_MAX];
} __attribute__((__packed__));
union rtw89_btc_fbtc_btscan {
 struct rtw89_btc_fbtc_btscan_v1 v1;
 struct rtw89_btc_fbtc_btscan_v2 v2;
 struct rtw89_btc_fbtc_btscan_v7 v7;
};
struct rtw89_btc_bt_info {
 struct rtw89_btc_bt_link_info link_info;
 struct rtw89_btc_bt_scan_info_v1 scan_info_v1[BTC_SCAN_MAX1];
 struct rtw89_btc_bt_scan_info_v2 scan_info_v2[CXSCAN_MAX];
 struct rtw89_btc_bt_ver_info ver_info;
 struct rtw89_btc_bool_sta_chg enable;
 struct rtw89_btc_bool_sta_chg inq_pag;
 struct rtw89_btc_rf_para rf_para;
 union rtw89_btc_bt_rfk_info_map rfk_info;

 u8 raw_info[BTC_BTINFO_MAX];
 u8 txpwr_info[BTC_BTINFO_MAX];
 u8 rssi_level;

 u32 scbd;
 u32 feature;

 u32 mbx_avl: 1;
 u32 whql_test: 1;
 u32 igno_wl: 1;
 u32 reinit: 1;
 u32 ble_scan_en: 1;
 u32 btg_type: 1;
 u32 inq: 1;
 u32 pag: 1;
 u32 run_patch_code: 1;
 u32 hi_lna_rx: 1;
 u32 scan_rx_low_pri: 1;
 u32 scan_info_update: 1;
 u32 lna_constrain: 3;
 u32 rsvd: 17;
};
struct rtw89_btc_cx {
 struct rtw89_btc_wl_info wl;
 struct rtw89_btc_bt_info bt;
 struct rtw89_btc_3rdcx_info other;
 u32 state_map;
 u32 cnt_bt[BTC_BCNT_NUM];
 u32 cnt_wl[BTC_WCNT_NUM];
};
struct rtw89_btc_fbtc_tdma {
 u8 type;
 u8 rxflctrl;
 u8 txpause;
 u8 wtgle_n;
 u8 leak_n;
 u8 ext_ctrl;
 u8 rxflctrl_role;
 u8 option_ctrl;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_tdma_v3 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd1;
 struct rtw89_btc_fbtc_tdma tdma;
} __attribute__((__packed__));
union rtw89_btc_fbtc_tdma_le32 {
 struct rtw89_btc_fbtc_tdma v1;
 struct rtw89_btc_fbtc_tdma_v3 v3;
};
enum rtw89_btc_bt_sta_counter {
 BTC_BCNT_RFK_REQ = 0,
 BTC_BCNT_RFK_GO = 1,
 BTC_BCNT_RFK_REJECT = 2,
 BTC_BCNT_RFK_FAIL = 3,
 BTC_BCNT_RFK_TIMEOUT = 4,
 BTC_BCNT_HI_TX = 5,
 BTC_BCNT_HI_RX = 6,
 BTC_BCNT_LO_TX = 7,
 BTC_BCNT_LO_RX = 8,
 BTC_BCNT_POLLUTED = 9,
 BTC_BCNT_STA_MAX
};
enum rtw89_btc_bt_sta_counter_v105 {
 BTC_BCNT_RFK_REQ_V105 = 0,
 BTC_BCNT_HI_TX_V105 = 1,
 BTC_BCNT_HI_RX_V105 = 2,
 BTC_BCNT_LO_TX_V105 = 3,
 BTC_BCNT_LO_RX_V105 = 4,
 BTC_BCNT_POLLUTED_V105 = 5,
 BTC_BCNT_STA_MAX_V105
};
struct rtw89_btc_fbtc_rpt_ctrl_v1 {
 u16 fver;
 u16 rpt_cnt;
 u32 wl_fw_coex_ver;
 u32 wl_fw_cx_offload;
 u32 wl_fw_ver;
 u32 rpt_enable;
 u32 rpt_para;
 u32 mb_send_fail_cnt;
 u32 mb_send_ok_cnt;
 u32 mb_recv_cnt;
 u32 mb_a2dp_empty_cnt;
 u32 mb_a2dp_flct_cnt;
 u32 mb_a2dp_full_cnt;
 u32 bt_rfk_cnt[BTC_BCNT_HI_TX];
 u32 c2h_cnt;
 u32 h2c_cnt;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_info {
 __le32 cnt;
 __le32 en;
 __le32 para;

 __le32 cnt_c2h;
 __le32 cnt_h2c;
 __le32 len_c2h;

 __le32 cnt_aoac_rf_on;
 __le32 cnt_aoac_rf_off;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_info_v5 {
 __le32 cx_ver;
 __le32 fw_ver;
 __le32 en;

 __le16 cnt;
 __le16 cnt_c2h;
 __le16 cnt_h2c;
 __le16 len_c2h;

 __le16 cnt_aoac_rf_on;
 __le16 cnt_aoac_rf_off;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_info_v8 {
 __le16 cnt;
 __le16 cnt_c2h;
 __le16 cnt_h2c;
 __le16 len_c2h;

 __le16 cnt_aoac_rf_on;
 __le16 cnt_aoac_rf_off;

 __le32 cx_ver;
 __le32 fw_ver;
 __le32 en;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_wl_fw_info {
 __le32 cx_ver;
 __le32 cx_offload;
 __le32 fw_ver;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_a2dp_empty {
 __le32 cnt_empty;
 __le32 cnt_flowctrl;
 __le32 cnt_tx;
 __le32 cnt_ack;
 __le32 cnt_nack;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox {
 __le32 cnt_send_ok;
 __le32 cnt_send_fail;
 __le32 cnt_recv;
 struct rtw89_btc_fbtc_rpt_ctrl_a2dp_empty a2dp;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_v4 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd1;
 struct rtw89_btc_fbtc_rpt_ctrl_info rpt_info;
 struct rtw89_btc_fbtc_rpt_ctrl_wl_fw_info wl_fw_info;
 struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox bt_mbx_info;
 __le32 bt_cnt[BTC_BCNT_STA_MAX];
 struct rtw89_mac_ax_gnt gnt_val[RTW89_PHY_NUM];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_v5 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd1;

 u8 gnt_val[RTW89_PHY_NUM][4];
 __le16 bt_cnt[BTC_BCNT_STA_MAX];

 struct rtw89_btc_fbtc_rpt_ctrl_info_v5 rpt_info;
 struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox bt_mbx_info;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_v105 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd1;

 u8 gnt_val[RTW89_PHY_NUM][4];
 __le16 bt_cnt[BTC_BCNT_STA_MAX_V105];

 struct rtw89_btc_fbtc_rpt_ctrl_info_v5 rpt_info;
 struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox bt_mbx_info;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_v7 {
 u8 fver;
 u8 rsvd0;
 u8 rsvd1;
 u8 rsvd2;

 u8 gnt_val[RTW89_PHY_NUM][4];
 __le16 bt_cnt[BTC_BCNT_STA_MAX_V105];

 struct rtw89_btc_fbtc_rpt_ctrl_info_v8 rpt_info;
 struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox bt_mbx_info;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_rpt_ctrl_v8 {
 u8 fver;
 u8 rsvd0;
 u8 rpt_len_max_l;
 u8 rpt_len_max_h;

 u8 gnt_val[RTW89_PHY_NUM][4];
 __le16 bt_cnt[BTC_BCNT_STA_MAX_V105];

 struct rtw89_btc_fbtc_rpt_ctrl_info_v8 rpt_info;
 struct rtw89_btc_fbtc_rpt_ctrl_bt_mailbox bt_mbx_info;
} __attribute__((__packed__));
union rtw89_btc_fbtc_rpt_ctrl_ver_info {
 struct rtw89_btc_fbtc_rpt_ctrl_v1 v1;
 struct rtw89_btc_fbtc_rpt_ctrl_v4 v4;
 struct rtw89_btc_fbtc_rpt_ctrl_v5 v5;
 struct rtw89_btc_fbtc_rpt_ctrl_v105 v105;
 struct rtw89_btc_fbtc_rpt_ctrl_v7 v7;
 struct rtw89_btc_fbtc_rpt_ctrl_v8 v8;
};
enum rtw89_btc_cxst_state {
 CXST_OFF = 0x0,
 CXST_B2W = 0x1,
 CXST_W1 = 0x2,
 CXST_W2 = 0x3,
 CXST_W2B = 0x4,
 CXST_B1 = 0x5,
 CXST_B2 = 0x6,
 CXST_B3 = 0x7,
 CXST_B4 = 0x8,
 CXST_LK = 0x9,
 CXST_BLK = 0xa,
 CXST_E2G = 0xb,
 CXST_E5G = 0xc,
 CXST_EBT = 0xd,
 CXST_ENULL = 0xe,
 CXST_WLK = 0xf,
 CXST_W1FDD = 0x10,
 CXST_B1FDD = 0x11,
 CXST_MAX = 0x12,
};
enum {
 CXBCN_ALL = 0x0,
 CXBCN_ALL_OK,
 CXBCN_BT_SLOT,
 CXBCN_BT_OK,
 CXBCN_MAX
};
enum {
 CXT_BT = 0x0,
 CXT_WL = 0x1,
 CXT_MAX
};
enum {
 CXT_FLCTRL_OFF = 0x0,
 CXT_FLCTRL_ON = 0x1,
 CXT_FLCTRL_MAX
};
struct rtw89_btc_fbtc_gpio_dbg_v1 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 __le32 en_map;
 __le32 pre_state;
 u8 gpio_map[32];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_gpio_dbg_v7 {
 u8 fver;
 u8 rsvd0;
 u8 rsvd1;
 u8 rsvd2;

 u8 gpio_map[32];

 __le32 en_map;
 __le32 pre_state;
} __attribute__((__packed__));
union rtw89_btc_fbtc_gpio_dbg {
 struct rtw89_btc_fbtc_gpio_dbg_v1 v1;
 struct rtw89_btc_fbtc_gpio_dbg_v7 v7;
};
struct rtw89_btc_fbtc_mreg_val_v1 {
 u8 fver;
 u8 reg_num;
 __le16 rsvd;
 __le32 mreg_val[30];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_mreg_val_v2 {
 u8 fver;
 u8 reg_num;
 __le16 rsvd;
 __le32 mreg_val[20];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_mreg_val_v7 {
 u8 fver;
 u8 reg_num;
 u8 rsvd0;
 u8 rsvd1;
 __le32 mreg_val[20];
} __attribute__((__packed__));
union rtw89_btc_fbtc_mreg_val {
 struct rtw89_btc_fbtc_mreg_val_v1 v1;
 struct rtw89_btc_fbtc_mreg_val_v2 v2;
 struct rtw89_btc_fbtc_mreg_val_v7 v7;
};
struct rtw89_btc_fbtc_mreg {
 __le16 type;
 __le16 bytes;
 __le32 offset;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_slot {
 __le16 dur;
 __le32 cxtbl;
 __le16 cxtype;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_slots {
 u8 fver;
 u8 tbl_num;
 __le16 rsvd;
 __le32 update_map;
 struct rtw89_btc_fbtc_slot slot[CXST_MAX];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_slot_v7 {
 __le16 dur;
 __le16 cxtype;
 __le32 cxtbl;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_slot_u16 {
 __le16 dur;
 __le16 cxtype;
 __le16 cxtbl_l16;
 __le16 cxtbl_h16;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_slots_v7 {
 u8 fver;
 u8 slot_cnt;
 u8 rsvd0;
 u8 rsvd1;
 struct rtw89_btc_fbtc_slot_u16 slot[CXST_MAX];
 __le32 update_map;
} __attribute__((__packed__));
union rtw89_btc_fbtc_slots_info {
 struct rtw89_btc_fbtc_slots v1;
 struct rtw89_btc_fbtc_slots_v7 v7;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_step {
 u8 type;
 u8 val;
 __le16 difft;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_steps_v2 {
 u8 fver;
 u8 rsvd;
 __le16 cnt;
 __le16 pos_old;
 __le16 pos_new;
 struct rtw89_btc_fbtc_step step[255];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_steps_v3 {
 u8 fver;
 u8 en;
 __le16 rsvd;
 __le32 cnt;
 struct rtw89_btc_fbtc_step step[255];
} __attribute__((__packed__));
union rtw89_btc_fbtc_steps_info {
 struct rtw89_btc_fbtc_steps_v2 v2;
 struct rtw89_btc_fbtc_steps_v3 v3;
};
struct rtw89_btc_fbtc_cysta_v2 {
 u8 fver;
 u8 rsvd;
 __le16 cycles;
 __le16 cycles_a2dp[CXT_FLCTRL_MAX];
 __le16 a2dpept;
 __le16 a2dpeptto;
 __le16 tavg_cycle[CXT_MAX];
 __le16 tmax_cycle[CXT_MAX];
 __le16 tmaxdiff_cycle[CXT_MAX];
 __le16 tavg_a2dp[CXT_FLCTRL_MAX];
 __le16 tmax_a2dp[CXT_FLCTRL_MAX];
 __le16 tavg_a2dpept;
 __le16 tmax_a2dpept;
 __le16 tavg_lk;
 __le16 tmax_lk;
 __le32 slot_cnt[CXST_MAX];
 __le32 bcn_cnt[CXBCN_MAX];
 __le32 leakrx_cnt;
 __le32 collision_cnt;
 __le32 skip_cnt;
 __le32 exception;
 __le32 except_cnt;
 __le16 tslot_cycle[48];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_fdd_try_info {
 __le16 cycles[CXT_FLCTRL_MAX];
 __le16 tavg[CXT_FLCTRL_MAX];
 __le16 tmax[CXT_FLCTRL_MAX];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_time_info {
 __le16 tavg[CXT_MAX];
 __le16 tmax[CXT_MAX];
 __le16 tmaxdiff[CXT_MAX];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_time_info_v5 {
 __le16 tavg[CXT_MAX];
 __le16 tmax[CXT_MAX];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_a2dp_trx_stat {
 u8 empty_cnt;
 u8 retry_cnt;
 u8 tx_rate;
 u8 tx_cnt;
 u8 ack_cnt;
 u8 nack_cnt;
 u8 rsvd1;
 u8 rsvd2;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_a2dp_trx_stat_v4 {
 u8 empty_cnt;
 u8 retry_cnt;
 u8 tx_rate;
 u8 tx_cnt;
 u8 ack_cnt;
 u8 nack_cnt;
 u8 no_empty_cnt;
 u8 rsvd;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_a2dp_empty_info {
 __le16 cnt;
 __le16 cnt_timeout;
 __le16 tavg;
 __le16 tmax;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_leak_info {
 __le32 cnt_rximr;
 __le16 tavg;
 __le16 tmax;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_leak_info_v7 {
 __le16 tavg;
 __le16 tamx;
 __le32 cnt_rximr;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_fddt_info {
 __le16 train_cycle;
 __le16 tp;

 s8 tx_power;
 s8 bt_tx_power;
 s8 bt_rx_gain;
 u8 no_empty_cnt;

 u8 rssi;
 u8 cn;
 u8 train_status;
 u8 train_result;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cycle_fddt_info_v5 {
 __le16 train_cycle;
 __le16 tp;

 s8 tx_power;
 s8 bt_tx_power;
 s8 bt_rx_gain;
 u8 no_empty_cnt;

 u8 rssi;
 u8 cn;
 u8 train_status;
 u8 train_result;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_fddt_cell_status {
 s8 wl_tx_pwr;
 s8 bt_tx_pwr;
 s8 bt_rx_gain;
 u8 state_phase;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cysta_v3 {
 u8 fver;
 u8 rsvd;
 __le16 cycles;
 __le16 slot_step_time[48];
 struct rtw89_btc_fbtc_cycle_time_info cycle_time;
 struct rtw89_btc_fbtc_fdd_try_info fdd_try;
 struct rtw89_btc_fbtc_cycle_a2dp_empty_info a2dp_ept;
 struct rtw89_btc_fbtc_a2dp_trx_stat a2dp_trx[48];
 struct rtw89_btc_fbtc_cycle_leak_info leak_slot;
 __le32 slot_cnt[CXST_MAX];
 __le32 bcn_cnt[CXBCN_MAX];
 __le32 collision_cnt;
 __le32 skip_cnt;
 __le32 except_cnt;
 __le32 except_map;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cysta_v4 {
 u8 fver;
 u8 rsvd;
 u8 collision_cnt;
 u8 except_cnt;

 __le16 skip_cnt;
 __le16 cycles;

 __le16 slot_step_time[48];
 __le16 slot_cnt[CXST_MAX];
 __le16 bcn_cnt[CXBCN_MAX];
 struct rtw89_btc_fbtc_cycle_time_info cycle_time;
 struct rtw89_btc_fbtc_cycle_leak_info leak_slot;
 struct rtw89_btc_fbtc_cycle_a2dp_empty_info a2dp_ept;
 struct rtw89_btc_fbtc_a2dp_trx_stat_v4 a2dp_trx[48];
 struct rtw89_btc_fbtc_cycle_fddt_info fddt_trx[48];
 struct rtw89_btc_fbtc_fddt_cell_status fddt_cells[2]
        [5]
        [5];
 __le32 except_map;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cysta_v5 {
 u8 fver;
 u8 rsvd;
 u8 collision_cnt;
 u8 except_cnt;
 u8 wl_rx_err_ratio[48];

 __le16 skip_cnt;
 __le16 cycles;

 __le16 slot_step_time[48];
 __le16 slot_cnt[CXST_MAX];
 __le16 bcn_cnt[CXBCN_MAX];
 struct rtw89_btc_fbtc_cycle_time_info_v5 cycle_time;
 struct rtw89_btc_fbtc_cycle_leak_info leak_slot;
 struct rtw89_btc_fbtc_cycle_a2dp_empty_info a2dp_ept;
 struct rtw89_btc_fbtc_a2dp_trx_stat_v4 a2dp_trx[48];
 struct rtw89_btc_fbtc_cycle_fddt_info_v5 fddt_trx[48];
 struct rtw89_btc_fbtc_fddt_cell_status fddt_cells[2]
        [5]
        [5];
 __le32 except_map;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cysta_v7 {
 u8 fver;
 u8 rsvd;
 u8 collision_cnt;
 u8 except_cnt;

 u8 wl_rx_err_ratio[48];

 struct rtw89_btc_fbtc_a2dp_trx_stat_v4 a2dp_trx[48];

 __le16 skip_cnt;
 __le16 cycles;

 __le16 slot_step_time[48];
 __le16 slot_cnt[CXST_MAX];
 __le16 bcn_cnt[CXBCN_MAX];

 struct rtw89_btc_fbtc_cycle_time_info_v5 cycle_time;
 struct rtw89_btc_fbtc_cycle_a2dp_empty_info a2dp_ept;
 struct rtw89_btc_fbtc_cycle_leak_info_v7 leak_slot;

 __le32 except_map;
} __attribute__((__packed__));
union rtw89_btc_fbtc_cysta_info {
 struct rtw89_btc_fbtc_cysta_v2 v2;
 struct rtw89_btc_fbtc_cysta_v3 v3;
 struct rtw89_btc_fbtc_cysta_v4 v4;
 struct rtw89_btc_fbtc_cysta_v5 v5;
 struct rtw89_btc_fbtc_cysta_v7 v7;
};
struct rtw89_btc_fbtc_cynullsta_v1 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 __le32 max_t[2];
 __le32 avg_t[2];
 __le32 result[2][4];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cynullsta_v2 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 __le32 max_t[2];
 __le32 avg_t[2];
 __le32 result[2][5];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_cynullsta_v7 {
 u8 fver;
 u8 rsvd0;
 u8 rsvd1;
 u8 rsvd2;

 __le32 tmax[2];
 __le32 tavg[2];
 __le32 result[2][5];
} __attribute__((__packed__));
union rtw89_btc_fbtc_cynullsta_info {
 struct rtw89_btc_fbtc_cynullsta_v1 v1;
 struct rtw89_btc_fbtc_cynullsta_v2 v2;
 struct rtw89_btc_fbtc_cynullsta_v7 v7;
};
struct rtw89_btc_fbtc_btver_v1 {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 __le32 coex_ver;
 __le32 fw_ver;
 __le32 feature;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btver_v7 {
 u8 fver;
 u8 rsvd0;
 u8 rsvd1;
 u8 rsvd2;

 __le32 coex_ver;
 __le32 fw_ver;
 __le32 feature;
} __attribute__((__packed__));
union rtw89_btc_fbtc_btver {
 struct rtw89_btc_fbtc_btver_v1 v1;
 struct rtw89_btc_fbtc_btver_v7 v7;
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btafh {
 u8 fver;
 u8 rsvd;
 __le16 rsvd2;
 u8 afh_l[4];
 u8 afh_m[4];
 u8 afh_h[4];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btafh_v2 {
 u8 fver;
 u8 rsvd;
 u8 rsvd2;
 u8 map_type;
 u8 afh_l[4];
 u8 afh_m[4];
 u8 afh_h[4];
 u8 afh_le_a[4];
 u8 afh_le_b[4];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btafh_v7 {
 u8 fver;
 u8 map_type;
 u8 rsvd0;
 u8 rsvd1;
 u8 afh_l[4];
 u8 afh_m[4];
 u8 afh_h[4];
 u8 afh_le_a[4];
 u8 afh_le_b[4];
} __attribute__((__packed__));
struct rtw89_btc_fbtc_btdevinfo {
 u8 fver;
 u8 rsvd;
 __le16 vendor_id;
 __le32 dev_name;
 __le32 flush_time;
} __attribute__((__packed__));
struct rtw89_btc_rf_trx_para {
 u32 wl_tx_power;
 u32 wl_rx_gain;
 u8 bt_tx_power;
 u8 bt_rx_gain;
};
struct rtw89_btc_trx_info {
 u8 tx_lvl;
 u8 rx_lvl;
 u8 wl_rssi;
 u8 bt_rssi;

 s8 tx_power;
 s8 rx_gain;
 s8 bt_tx_power;
 s8 bt_rx_gain;

 u8 cn;
 s8 nhm;
 u8 bt_profile;
 u8 rsvd2;

 u16 tx_rate;
 u16 rx_rate;

 u32 tx_tp;
 u32 rx_tp;
 u32 rx_err_ratio;
};
enum btc_rf_path {
 BTC_RF_S0 = 0,
 BTC_RF_S1 = 1,
 BTC_RF_NUM,
};
struct rtw89_btc_fbtc_outsrc_set_info {
 u8 rf_band[BTC_RF_NUM];
 u8 btg_rx[BTC_RF_NUM];
 u8 nbtg_tx[BTC_RF_NUM];

 struct rtw89_mac_ax_gnt gnt_set[BTC_RF_NUM];
 struct rtw89_mac_ax_wl_act wlact_set[BTC_RF_NUM];

 u8 pta_req_hw_band;
 u8 rf_gbt_source;
} __attribute__((__packed__));
union rtw89_btc_fbtc_slot_u {
 struct rtw89_btc_fbtc_slot v1[CXST_MAX];
 struct rtw89_btc_fbtc_slot_v7 v7[CXST_MAX];
};
struct rtw89_btc_dm {
 struct rtw89_btc_fbtc_outsrc_set_info ost_info_last;
 struct rtw89_btc_fbtc_outsrc_set_info ost_info;
 union rtw89_btc_fbtc_slot_u slot;
 union rtw89_btc_fbtc_slot_u slot_now;
 struct rtw89_btc_fbtc_tdma tdma;
 struct rtw89_btc_fbtc_tdma tdma_now;
 struct rtw89_mac_ax_coex_gnt gnt;
 union rtw89_btc_init_info_u init_info;
 struct rtw89_btc_rf_trx_para rf_trx_para;
 struct rtw89_btc_wl_tx_limit_para wl_tx_limit;
 struct rtw89_btc_dm_step dm_step;
 struct rtw89_btc_wl_scc_ctrl wl_scc;
 struct rtw89_btc_trx_info trx_info;
 union rtw89_btc_dm_error_map error;
 u32 cnt_dm[BTC_DCNT_NUM];
 u32 cnt_notify[BTC_NCNT_NUM];

 u32 update_slot_map;
 u32 set_ant_path;
 u32 e2g_slot_limit;
 u32 e2g_slot_nulltx_time;

 u32 wl_only: 1;
 u32 wl_fw_cx_offload: 1;
 u32 freerun: 1;
 u32 fddt_train: 1;
 u32 wl_ps_ctrl: 2;
 u32 wl_mimo_ps: 1;
 u32 leak_ap: 1;
 u32 noisy_level: 3;
 u32 coex_info_map: 8;
 u32 bt_only: 1;
 u32 wl_btg_rx: 2;
 u32 trx_para_level: 8;
 u32 wl_stb_chg: 1;
 u32 pta_owner: 1;

 u32 tdma_instant_excute: 1;
 u32 wl_btg_rx_rb: 2;

 u16 slot_dur[CXST_MAX];
 u16 bt_slot_flood;

 u8 run_reason;
 u8 run_action;

 u8 wl_pre_agc: 2;
 u8 wl_lna2: 1;
 u8 freerun_chk: 1;
 u8 wl_pre_agc_rb: 2;
 u8 bt_select: 2;
 u8 slot_req_more: 1;
};
struct rtw89_btc_ctrl {
 u32 manual: 1;
 u32 igno_bt: 1;
 u32 always_freerun: 1;
 u32 trace_step: 16;
 u32 rsvd: 12;
};
struct rtw89_btc_ctrl_v7 {
 u8 manual;
 u8 igno_bt;
 u8 always_freerun;
 u8 rsvd;
} __attribute__((__packed__));
union rtw89_btc_ctrl_list {
 struct rtw89_btc_ctrl ctrl;
 struct rtw89_btc_ctrl_v7 ctrl_v7;
};
struct rtw89_btc_dbg {

 bool rb_done;
 u32 rb_val;
};
enum rtw89_btc_btf_fw_event {
 BTF_EVNT_RPT = 0,
 BTF_EVNT_BT_INFO = 1,
 BTF_EVNT_BT_SCBD = 2,
 BTF_EVNT_BT_REG = 3,
 BTF_EVNT_CX_RUNINFO = 4,
 BTF_EVNT_BT_PSD = 5,
 BTF_EVNT_BT_DEV_INFO = 6,
 BTF_EVNT_BT_LEAUDIO_INFO = 7,
 BTF_EVNT_BUF_OVERFLOW,
 BTF_EVNT_C2H_LOOPBACK,
 BTF_EVNT_BT_QUERY_TXPWR,
 BTF_EVNT_MAX,
};
struct rtw89_btc_rpt_cmn_info {
 u32 rx_cnt;
 u32 rx_len;
 u32 req_len;
 u8 req_fver;
 u8 rsp_fver;
 u8 valid;
} __attribute__((__packed__));
union rtw89_btc_fbtc_btafh_info {
 struct rtw89_btc_fbtc_btafh v1;
 struct rtw89_btc_fbtc_btafh_v2 v2;
 struct rtw89_btc_fbtc_btafh_v7 v7;
};
struct rtw89_btc_report_ctrl_state {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_rpt_ctrl_ver_info finfo;
};
struct rtw89_btc_rpt_fbtc_tdma {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_tdma_le32 finfo;
};
struct rtw89_btc_rpt_fbtc_slots {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_slots_info finfo;
};
struct rtw89_btc_rpt_fbtc_cysta {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_cysta_info finfo;
};
struct rtw89_btc_rpt_fbtc_step {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_steps_info finfo;
};
struct rtw89_btc_rpt_fbtc_nullsta {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_cynullsta_info finfo;
};
struct rtw89_btc_rpt_fbtc_mreg {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_mreg_val finfo;
};
struct rtw89_btc_rpt_fbtc_gpio_dbg {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_gpio_dbg finfo;
};
struct rtw89_btc_rpt_fbtc_btver {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_btver finfo;
};
struct rtw89_btc_rpt_fbtc_btscan {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_btscan finfo;
};
struct rtw89_btc_rpt_fbtc_btafh {
 struct rtw89_btc_rpt_cmn_info cinfo;
 union rtw89_btc_fbtc_btafh_info finfo;
};
struct rtw89_btc_rpt_fbtc_btdev {
 struct rtw89_btc_rpt_cmn_info cinfo;
 struct rtw89_btc_fbtc_btdevinfo finfo;
};
enum rtw89_btc_btfre_type {
 BTFRE_INVALID_INPUT = 0x0,
 BTFRE_UNDEF_TYPE,
 BTFRE_EXCEPTION,
 BTFRE_MAX,
};
struct rtw89_btc_ver {
 enum rtw89_core_chip_id chip_id;
 u32 fw_ver_code;

 u8 fcxbtcrpt;
 u8 fcxtdma;
 u8 fcxslots;
 u8 fcxcysta;
 u8 fcxstep;
 u8 fcxnullsta;
 u8 fcxmreg;
 u8 fcxgpiodbg;
 u8 fcxbtver;
 u8 fcxbtscan;
 u8 fcxbtafh;
 u8 fcxbtdevinfo;
 u8 fwlrole;
 u8 frptmap;
 u8 fcxctrl;
 u8 fcxinit;

 u8 fwevntrptl;
 u8 fwc2hfunc;
 u8 drvinfo_type;
 u16 info_buf;
 u8 max_role_num;
 u8 fcxosi;
 u8 fcxmlo;
 u8 bt_desired;
};
struct rtw89_btc_btf_fwinfo {
 u32 cnt_c2h;
 u32 cnt_h2c;
 u32 cnt_h2c_fail;
 u32 event[BTF_EVNT_MAX];

 u32 err[BTFRE_MAX];
 u32 len_mismch;
 u32 fver_mismch;
 u32 rpt_en_map;

 struct rtw89_btc_ver fw_subver;
 struct rtw89_btc_report_ctrl_state rpt_ctrl;
 struct rtw89_btc_rpt_fbtc_tdma rpt_fbtc_tdma;
 struct rtw89_btc_rpt_fbtc_slots rpt_fbtc_slots;
 struct rtw89_btc_rpt_fbtc_cysta rpt_fbtc_cysta;
 struct rtw89_btc_rpt_fbtc_step rpt_fbtc_step;
 struct rtw89_btc_rpt_fbtc_nullsta rpt_fbtc_nullsta;
 struct rtw89_btc_rpt_fbtc_mreg rpt_fbtc_mregval;
 struct rtw89_btc_rpt_fbtc_gpio_dbg rpt_fbtc_gpio_dbg;
 struct rtw89_btc_rpt_fbtc_btver rpt_fbtc_btver;
 struct rtw89_btc_rpt_fbtc_btscan rpt_fbtc_btscan;
 struct rtw89_btc_rpt_fbtc_btafh rpt_fbtc_btafh;
 struct rtw89_btc_rpt_fbtc_btdev rpt_fbtc_btdev;
};
struct rtw89_btc {
 const struct rtw89_btc_ver *ver;

 struct rtw89_btc_cx cx;
 struct rtw89_btc_dm dm;
 union rtw89_btc_ctrl_list ctrl;
 union rtw89_btc_module_info mdinfo;
 struct rtw89_btc_btf_fwinfo fwinfo;
 struct rtw89_btc_dbg dbg;

 struct wiphy_work eapol_notify_work;
 struct wiphy_work arp_notify_work;
 struct wiphy_work dhcp_notify_work;
 struct wiphy_work icmp_notify_work;

 u32 bt_req_len;

 u8 policy[512];
 u8 ant_type;
 u8 btg_pos;
 u16 policy_len;
 u16 policy_type;
 u32 hubmsg_cnt;
 bool bt_req_en;
 bool update_policy_force;
 bool lps;
 bool manual_ctrl;
};
enum rtw89_efuse_block {
 RTW89_EFUSE_BLOCK_SYS = 0,
 RTW89_EFUSE_BLOCK_RF = 1,
 RTW89_EFUSE_BLOCK_HCI_DIG_PCIE_SDIO = 2,
 RTW89_EFUSE_BLOCK_HCI_DIG_USB = 3,
 RTW89_EFUSE_BLOCK_HCI_PHY_PCIE = 4,
 RTW89_EFUSE_BLOCK_HCI_PHY_USB3 = 5,
 RTW89_EFUSE_BLOCK_HCI_PHY_USB2 = 6,
 RTW89_EFUSE_BLOCK_ADIE = 7,

 RTW89_EFUSE_BLOCK_NUM,
 RTW89_EFUSE_BLOCK_IGNORE,
};
struct rtw89_ra_info {
 u8 is_dis_ra:1;







 u8 mode_ctrl:6;
 u8 bw_cap:3;
 u8 macid;
 u8 dcm_cap:1;
 u8 er_cap:1;
 u8 init_rate_lv:2;
 u8 upd_all:1;
 u8 en_sgi:1;
 u8 ldpc_cap:1;
 u8 stbc_cap:1;
 u8 ss_num:3;
 u8 giltf:3;
 u8 upd_bw_nss_mask:1;
 u8 upd_mask:1;
 u64 ra_mask;

 u8 band_num;
 u8 ra_csi_rate_en:1;
 u8 fixed_csi_rate_en:1;
 u8 cr_tbl_sel:1;
 u8 fix_giltf_en:1;
 u8 fix_giltf:3;
 u8 rsvd2:1;
 u8 csi_mcs_ss_idx;
 u8 csi_mode:2;
 u8 csi_gi_ltf:3;
 u8 csi_bw:3;
};
struct rtw89_ampdu_params {
 u16 agg_num;
 bool amsdu;
};
struct rtw89_ra_report {
 struct rate_info txrate;
 u32 bit_rate;
 u16 hw_rate;
 bool might_fallback_legacy;
};
struct ewma_rssi { unsigned long internal; };
struct ewma_evm { unsigned long internal; };
struct ewma_snr { unsigned long internal; };
struct rtw89_ba_cam_entry {
 struct list_head list;
 u8 tid;
};
struct rtw89_addr_cam_entry {
 u8 addr_cam_idx;
 u8 offset;
 u8 len;
 u8 valid : 1;
 u8 addr_mask : 6;
 u8 wapi : 1;
 u8 mask_sel : 2;
 u8 bssid_cam_idx: 6;

 u8 sec_ent_mode;
 unsigned long sec_cam_map[(((7) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 u8 sec_ent_keyid[7];
 u8 sec_ent[7];
};
struct rtw89_bssid_cam_entry {
 u8 bssid[6];
 u8 phy_idx;
 u8 bssid_cam_idx;
 u8 offset;
 u8 len;
 u8 valid : 1;
 u8 num;
};
struct rtw89_sec_cam_entry {
 u8 sec_cam_idx;
 u8 offset;
 u8 len;
 u8 type : 4;
 u8 ext_key : 1;
 u8 spp_mode : 1;

 u8 key[32];

 struct ieee80211_key_conf *key_conf;
};
struct rtw89_sta_link {
 struct rtw89_sta *rtwsta;
 struct list_head dlink_schd;
 unsigned int link_id;

 u8 mac_id;
 u8 tx_retry;
 bool er_cap;
 struct rtw89_vif_link *rtwvif_link;
 struct rtw89_ra_info ra;
 struct rtw89_ra_report ra_report;
 int max_agg_wait;
 u8 prev_rssi;
 struct ewma_rssi avg_rssi;
 struct ewma_rssi rssi[4];
 struct ewma_snr avg_snr;
 struct ewma_evm evm_1ss;
 struct ewma_evm evm_min[4];
 struct ewma_evm evm_max[4];
 struct ieee80211_rx_status rx_status;
 u16 rx_hw_rate;
 __le32 htc_template;
 struct rtw89_addr_cam_entry addr_cam;
 struct rtw89_bssid_cam_entry bssid_cam;
 struct list_head ba_cam_list;

 bool use_cfg_mask;
 struct cfg80211_bitrate_mask mask;

 bool cctl_tx_time;
 u32 ampdu_max_time:4;
 bool cctl_tx_retry_limit;
 u32 data_tx_cnt_lmt:6;
};
struct rtw89_efuse {
 bool valid;
 bool power_k_valid;
 u8 xtal_cap;
 u8 addr[6];
 u8 rfe_type;
 char country_code[2];
 u8 adc_td;
};
struct rtw89_phy_rate_pattern {
 u64 ra_mask;
 u16 rate;
 u8 ra_mode;
 bool enable;
};
enum rtw89_roc_state {
 RTW89_ROC_IDLE,
 RTW89_ROC_NORMAL,
 RTW89_ROC_MGMT,
};
struct rtw89_roc {
 struct ieee80211_channel chan;
 struct wiphy_delayed_work roc_work;
 enum ieee80211_roc_type type;
 enum rtw89_roc_state state;
 int duration;
 unsigned int link_id;
};
struct rtw89_p2p_ie_head {
 u8 eid;
 u8 ie_len;
 u8 oui[3];
 u8 oui_type;
} __attribute__((__packed__));
struct rtw89_noa_attr_head {
 u8 attr_type;
 __le16 attr_len;
 u8 index;
 u8 oppps_ctwindow;
} __attribute__((__packed__));
struct rtw89_p2p_noa_ie {
 struct rtw89_p2p_ie_head p2p_head;
 struct rtw89_noa_attr_head noa_head;
 struct ieee80211_p2p_noa_desc noa_desc[2];
} __attribute__((__packed__));
struct rtw89_p2p_noa_setter {
 struct rtw89_p2p_noa_ie ie;
 u8 noa_count;
 u8 noa_index;
};
struct rtw89_ps_noa_once_handler {
 bool in_duration;
 u64 tsf_begin;
 u64 tsf_end;
 struct wiphy_delayed_work set_work;
 struct wiphy_delayed_work clr_work;
};
struct rtw89_vif_link {
 struct rtw89_vif *rtwvif;
 struct list_head dlink_schd;
 unsigned int link_id;

 bool chanctx_assigned;
 enum rtw89_chanctx_idx chanctx_idx;
 enum rtw89_reg_6ghz_power reg_6ghz_power;
 struct rtw89_reg_6ghz_tpe reg_6ghz_tpe;

 u8 mac_id;
 u8 port;
 u8 mac_addr[6];
 u8 bssid[6];
 u8 phy_idx;
 u8 mac_idx;
 u8 net_type;
 u8 wifi_role;
 u8 self_role;
 u8 wmm;
 u8 bcn_hit_cond;
 u8 bcn_bw_idx;
 u8 hit_rule;
 u8 last_noa_nr;
 u64 sync_bcn_tsf;
 u64 last_sync_bcn_tsf;
 bool rand_tsf_done;
 bool trigger;
 bool lsig_txop;
 u8 tgt_ind;
 u8 frm_tgt_ind;
 bool wowlan_pattern;
 bool wowlan_uc;
 bool wowlan_magic;
 bool is_hesta;
 bool last_a_ctrl;
 bool dyn_tb_bedge_en;
 bool pre_pwr_diff_en;
 bool pwr_diff_en;
 u8 def_tri_idx;
 struct wiphy_work update_beacon_work;
 struct wiphy_delayed_work csa_beacon_work;
 struct rtw89_addr_cam_entry addr_cam;
 struct rtw89_bssid_cam_entry bssid_cam;
 struct ieee80211_tx_queue_params tx_params[4];
 struct rtw89_phy_rate_pattern rate_pattern;
 struct list_head general_pkt_list;
 struct rtw89_p2p_noa_setter p2p_noa;
 struct rtw89_ps_noa_once_handler noa_once;
 struct wiphy_delayed_work mcc_gc_detect_beacon_work;
 u8 detect_bcn_count;
};
enum rtw89_lv1_rcvy_step {
 RTW89_LV1_RCVY_STEP_1,
 RTW89_LV1_RCVY_STEP_2,
};
struct rtw89_hci_ops {
 int (*tx_write)(struct rtw89_dev *rtwdev, struct rtw89_core_tx_request *tx_req);
 void (*tx_kick_off)(struct rtw89_dev *rtwdev, u8 txch);
 void (*flush_queues)(struct rtw89_dev *rtwdev, u32 queues, bool drop);
 void (*reset)(struct rtw89_dev *rtwdev);
 int (*start)(struct rtw89_dev *rtwdev);
 void (*stop)(struct rtw89_dev *rtwdev);
 void (*pause)(struct rtw89_dev *rtwdev, bool pause);
 void (*switch_mode)(struct rtw89_dev *rtwdev, bool low_power);
 void (*recalc_int_mit)(struct rtw89_dev *rtwdev);

 u8 (*read8)(struct rtw89_dev *rtwdev, u32 addr);
 u16 (*read16)(struct rtw89_dev *rtwdev, u32 addr);
 u32 (*read32)(struct rtw89_dev *rtwdev, u32 addr);
 void (*write8)(struct rtw89_dev *rtwdev, u32 addr, u8 data);
 void (*write16)(struct rtw89_dev *rtwdev, u32 addr, u16 data);
 void (*write32)(struct rtw89_dev *rtwdev, u32 addr, u32 data);

 u32 (*read32_pci_cfg)(struct rtw89_dev *rtwdev, u32 addr);

 int (*mac_pre_init)(struct rtw89_dev *rtwdev);
 int (*mac_pre_deinit)(struct rtw89_dev *rtwdev);
 int (*mac_post_init)(struct rtw89_dev *rtwdev);
 int (*deinit)(struct rtw89_dev *rtwdev);

 u32 (*check_and_reclaim_tx_resource)(struct rtw89_dev *rtwdev, u8 txch);
 int (*mac_lv1_rcvy)(struct rtw89_dev *rtwdev, enum rtw89_lv1_rcvy_step step);
 void (*dump_err_status)(struct rtw89_dev *rtwdev);
 int (*napi_poll)(struct napi_struct *napi, int budget);





 void (*recovery_start)(struct rtw89_dev *rtwdev);
 void (*recovery_complete)(struct rtw89_dev *rtwdev);

 void (*ctrl_txdma_ch)(struct rtw89_dev *rtwdev, bool enable);
 void (*ctrl_txdma_fw_ch)(struct rtw89_dev *rtwdev, bool enable);
 void (*ctrl_trxhci)(struct rtw89_dev *rtwdev, bool enable);
 int (*poll_txdma_ch_idle)(struct rtw89_dev *rtwdev);
 void (*clr_idx_all)(struct rtw89_dev *rtwdev);
 void (*clear)(struct rtw89_dev *rtwdev, struct pci_dev *pdev);
 void (*disable_intr)(struct rtw89_dev *rtwdev);
 void (*enable_intr)(struct rtw89_dev *rtwdev);
 int (*rst_bdram)(struct rtw89_dev *rtwdev);
};
struct rtw89_hci_info {
 const struct rtw89_hci_ops *ops;
 enum rtw89_hci_type type;
 enum rtw89_hci_dle_type dle_type;
 u32 rpwm_addr;
 u32 cpwm_addr;
 bool paused;
};
struct rtw89_chip_ops {
 int (*enable_bb_rf)(struct rtw89_dev *rtwdev);
 int (*disable_bb_rf)(struct rtw89_dev *rtwdev);
 void (*bb_preinit)(struct rtw89_dev *rtwdev, enum rtw89_phy_idx phy_idx);
 void (*bb_postinit)(struct rtw89_dev *rtwdev, enum rtw89_phy_idx phy_idx);
 void (*bb_reset)(struct rtw89_dev *rtwdev,
    enum rtw89_phy_idx phy_idx);
 void (*bb_sethw)(struct rtw89_dev *rtwdev);
 u32 (*read_rf)(struct rtw89_dev *rtwdev, enum rtw89_rf_path rf_path,
         u32 addr, u32 mask);
 bool (*write_rf)(struct rtw89_dev *rtwdev, enum rtw89_rf_path rf_path,
    u32 addr, u32 mask, u32 data);
 void (*set_channel)(struct rtw89_dev *rtwdev,
       const struct rtw89_chan *chan,
       enum rtw89_mac_idx mac_idx,
       enum rtw89_phy_idx phy_idx);
 void (*set_channel_help)(struct rtw89_dev *rtwdev, bool enter,
     struct rtw89_channel_help_params *p,
     const struct rtw89_chan *chan,
     enum rtw89_mac_idx mac_idx,
     enum rtw89_phy_idx phy_idx);
 int (*read_efuse)(struct rtw89_dev *rtwdev, u8 *log_map,
     enum rtw89_efuse_block block);
 int (*read_phycap)(struct rtw89_dev *rtwdev, u8 *phycap_map);
 void (*fem_setup)(struct rtw89_dev *rtwdev);
 void (*rfe_gpio)(struct rtw89_dev *rtwdev);
 void (*rfk_hw_init)(struct rtw89_dev *rtwdev);
 void (*rfk_init)(struct rtw89_dev *rtwdev);
 void (*rfk_init_late)(struct rtw89_dev *rtwdev);
 void (*rfk_channel)(struct rtw89_dev *rtwdev, struct rtw89_vif_link *rtwvif_link);
 void (*rfk_band_changed)(struct rtw89_dev *rtwdev,
     enum rtw89_phy_idx phy_idx,
     const struct rtw89_chan *chan);
 void (*rfk_scan)(struct rtw89_dev *rtwdev, struct rtw89_vif_link *rtwvif_link,
    bool start);
 void (*rfk_track)(struct rtw89_dev *rtwdev);
 void (*power_trim)(struct rtw89_dev *rtwdev);
 void (*set_txpwr)(struct rtw89_dev *rtwdev,
     const struct rtw89_chan *chan,
     enum rtw89_phy_idx phy_idx);
 void (*set_txpwr_ctrl)(struct rtw89_dev *rtwdev,
          enum rtw89_phy_idx phy_idx);
 int (*init_txpwr_unit)(struct rtw89_dev *rtwdev, enum rtw89_phy_idx phy_idx);
 u8 (*get_thermal)(struct rtw89_dev *rtwdev, enum rtw89_rf_path rf_path);
 u32 (*chan_to_rf18_val)(struct rtw89_dev *rtwdev,
    const struct rtw89_chan *chan);
 void (*ctrl_btg_bt_rx)(struct rtw89_dev *rtwdev, bool en,
          enum rtw89_phy_idx phy_idx);
 void (*query_ppdu)(struct rtw89_dev *rtwdev,
      struct rtw89_rx_phy_ppdu *phy_ppdu,
      struct ieee80211_rx_status *status);
 void (*convert_rpl_to_rssi)(struct rtw89_dev *rtwdev,
        struct rtw89_rx_phy_ppdu *phy_ppdu);
 void (*phy_rpt_to_rssi)(struct rtw89_dev *rtwdev,
    struct rtw89_rx_desc_info *desc_info,
    struct ieee80211_rx_status *rx_status);
 void (*ctrl_nbtg_bt_tx)(struct rtw89_dev *rtwdev, bool en,
    enum rtw89_phy_idx phy_idx);
 void (*cfg_txrx_path)(struct rtw89_dev *rtwdev);
 void (*set_txpwr_ul_tb_offset)(struct rtw89_dev *rtwdev,
           s8 pw_ofst, enum rtw89_mac_idx mac_idx);
 void (*digital_pwr_comp)(struct rtw89_dev *rtwdev,
     enum rtw89_phy_idx phy_idx);
 int (*pwr_on_func)(struct rtw89_dev *rtwdev);
 int (*pwr_off_func)(struct rtw89_dev *rtwdev);
 void (*query_rxdesc)(struct rtw89_dev *rtwdev,
        struct rtw89_rx_desc_info *desc_info,
        u8 *data, u32 data_offset);
 void (*fill_txdesc)(struct rtw89_dev *rtwdev,
       struct rtw89_tx_desc_info *desc_info,
       void *txdesc);
 void (*fill_txdesc_fwcmd)(struct rtw89_dev *rtwdev,
      struct rtw89_tx_desc_info *desc_info,
      void *txdesc);
 u8 (*get_ch_dma)(struct rtw89_dev *rtwdev, u8 qsel);
 int (*cfg_ctrl_path)(struct rtw89_dev *rtwdev, bool wl);
 int (*mac_cfg_gnt)(struct rtw89_dev *rtwdev,
      const struct rtw89_mac_ax_coex_gnt *gnt_cfg);
 int (*stop_sch_tx)(struct rtw89_dev *rtwdev, u8 mac_idx,
      u32 *tx_en, enum rtw89_sch_tx_sel sel);
 int (*resume_sch_tx)(struct rtw89_dev *rtwdev, u8 mac_idx, u32 tx_en);
 int (*h2c_dctl_sec_cam)(struct rtw89_dev *rtwdev,
    struct rtw89_vif_link *rtwvif_link,
    struct rtw89_sta_link *rtwsta_link);
 int (*h2c_default_cmac_tbl)(struct rtw89_dev *rtwdev,
        struct rtw89_vif_link *rtwvif_link,
        struct rtw89_sta_link *rtwsta_link);
 int (*h2c_assoc_cmac_tbl)(struct rtw89_dev *rtwdev,
      struct rtw89_vif_link *rtwvif_link,
      struct rtw89_sta_link *rtwsta_link);
 int (*h2c_ampdu_cmac_tbl)(struct rtw89_dev *rtwdev,
      struct rtw89_vif_link *rtwvif_link,
      struct rtw89_sta_link *rtwsta_link);
 int (*h2c_txtime_cmac_tbl)(struct rtw89_dev *rtwdev,
       struct rtw89_sta_link *rtwsta_link);
 int (*h2c_punctured_cmac_tbl)(struct rtw89_dev *rtwdev,
          struct rtw89_vif_link *rtwvif_link,
          u16 punctured);
 int (*h2c_default_dmac_tbl)(struct rtw89_dev *rtwdev,
        struct rtw89_vif_link *rtwvif_link,
        struct rtw89_sta_link *rtwsta_link);
 int (*h2c_update_beacon)(struct rtw89_dev *rtwdev,
     struct rtw89_vif_link *rtwvif_link);
 int (*h2c_ba_cam)(struct rtw89_dev *rtwdev,
     struct rtw89_vif_link *rtwvif_link,
     struct rtw89_sta_link *rtwsta_link,
     bool valid, struct ieee80211_ampdu_params *params);

 void (*btc_set_rfe)(struct rtw89_dev *rtwdev);
 void (*btc_init_cfg)(struct rtw89_dev *rtwdev);
 void (*btc_set_wl_pri)(struct rtw89_dev *rtwdev, u8 map, bool state);
 void (*btc_set_wl_txpwr_ctrl)(struct rtw89_dev *rtwdev, u32 txpwr_val);
 s8 (*btc_get_bt_rssi)(struct rtw89_dev *rtwdev, s8 val);
 void (*btc_update_bt_cnt)(struct rtw89_dev *rtwdev);
 void (*btc_wl_s1_standby)(struct rtw89_dev *rtwdev, bool state);
 void (*btc_set_policy)(struct rtw89_dev *rtwdev, u16 policy_type);
 void (*btc_set_wl_rx_gain)(struct rtw89_dev *rtwdev, u32 level);
};
enum rtw89_dma_ch {
 RTW89_DMA_ACH0 = 0,
 RTW89_DMA_ACH1 = 1,
 RTW89_DMA_ACH2 = 2,
 RTW89_DMA_ACH3 = 3,
 RTW89_DMA_ACH4 = 4,
 RTW89_DMA_ACH5 = 5,
 RTW89_DMA_ACH6 = 6,
 RTW89_DMA_ACH7 = 7,
 RTW89_DMA_B0MG = 8,
 RTW89_DMA_B0HI = 9,
 RTW89_DMA_B1MG = 10,
 RTW89_DMA_B1HI = 11,
 RTW89_DMA_H2C = 12,
 RTW89_DMA_CH_NUM = 13
};
enum rtw89_mlo_dbcc_mode {
 MLO_DBCC_NOT_SUPPORT = 1,
 MLO_0_PLUS_2_1RF = ((1) << 12 | (2) << 4 | (0)),
 MLO_0_PLUS_2_2RF = ((2) << 12 | (2) << 4 | (0)),
 MLO_1_PLUS_1_1RF = ((1) << 12 | (1) << 4 | (1)),
 MLO_1_PLUS_1_2RF = ((2) << 12 | (1) << 4 | (1)),
 MLO_2_PLUS_0_1RF = ((1) << 12 | (0) << 4 | (2)),
 MLO_2_PLUS_0_2RF = ((2) << 12 | (0) << 4 | (2)),
 MLO_2_PLUS_2_2RF = ((2) << 12 | (2) << 4 | (2)),
 DBCC_LEGACY = 0xffffffff,
};
enum rtw89_scan_be_operation {
 RTW89_SCAN_OP_STOP,
 RTW89_SCAN_OP_START,
 RTW89_SCAN_OP_SETPARM,
 RTW89_SCAN_OP_GETRPT,
 RTW89_SCAN_OP_NUM
};
enum rtw89_scan_be_mode {
 RTW89_SCAN_MODE_SA,
 RTW89_SCAN_MODE_MACC,
 RTW89_SCAN_MODE_NUM
};
struct rtw89_scan_option {
 bool enable;
 bool target_ch_mode;
 u8 num_macc_role;
 u8 num_opch;
 u8 repeat;
 u16 norm_pd;
 u16 slow_pd;
 u16 norm_cy;
 u8 opch_end;
 u16 delay;
 u64 prohib_chan;
 enum rtw89_phy_idx band;
 enum rtw89_scan_be_operation operation;
 enum rtw89_scan_be_mode scan_mode;
 enum rtw89_mlo_dbcc_mode mlo_mode;
};
enum rtw89_qta_mode {
 RTW89_QTA_SCC,
 RTW89_QTA_DBCC,
 RTW89_QTA_DLFW,
 RTW89_QTA_WOW,


 RTW89_QTA_INVALID,
};
struct rtw89_hfc_ch_cfg {
 u16 min;
 u16 max;
 u8 grp;
};
struct rtw89_hfc_ch_info {
 u16 aval;
 u16 used;
};
struct rtw89_hfc_pub_cfg {
 u16 grp0;
 u16 grp1;
 u16 pub_max;
 u16 wp_thrd;
};
struct rtw89_hfc_pub_info {
 u16 g0_used;
 u16 g1_used;
 u16 g0_aval;
 u16 g1_aval;
 u16 pub_aval;
 u16 wp_aval;
};
struct rtw89_hfc_prec_cfg {
 u16 ch011_prec;
 u16 h2c_prec;
 u16 wp_ch07_prec;
 u16 wp_ch811_prec;
 u8 ch011_full_cond;
 u8 h2c_full_cond;
 u8 wp_ch07_full_cond;
 u8 wp_ch811_full_cond;
};
struct rtw89_hfc_param {
 bool en;
 bool h2c_en;
 u8 mode;
 const struct rtw89_hfc_ch_cfg *ch_cfg;
 struct rtw89_hfc_ch_info ch_info[RTW89_DMA_CH_NUM];
 struct rtw89_hfc_pub_cfg pub_cfg;
 struct rtw89_hfc_pub_info pub_info;
 struct rtw89_hfc_prec_cfg prec_cfg;
};
struct rtw89_hfc_param_ini {
 const struct rtw89_hfc_ch_cfg *ch_cfg;
 const struct rtw89_hfc_pub_cfg *pub_cfg;
 const struct rtw89_hfc_prec_cfg *prec_cfg;
 u8 mode;
};
struct rtw89_dle_size {
 u16 pge_size;
 u16 lnk_pge_num;
 u16 unlnk_pge_num;

 u32 srt_ofst;
};
struct rtw89_wde_quota {
 u16 hif;
 u16 wcpu;
 u16 pkt_in;
 u16 cpu_io;
};
struct rtw89_ple_quota {
 u16 cma0_tx;
 u16 cma1_tx;
 u16 c2h;
 u16 h2c;
 u16 wcpu;
 u16 mpdu_proc;
 u16 cma0_dma;
 u16 cma1_dma;
 u16 bb_rpt;
 u16 wd_rel;
 u16 cpu_io;
 u16 tx_rpt;

 u16 h2d;
};
struct rtw89_rsvd_quota {
 u16 mpdu_info_tbl;
 u16 b0_csi;
 u16 b1_csi;
 u16 b0_lmr;
 u16 b1_lmr;
 u16 b0_ftm;
 u16 b1_ftm;
 u16 b0_smr;
 u16 b1_smr;
 u16 others;
};
struct rtw89_dle_rsvd_size {
 u32 srt_ofst;
 u32 size;
};
struct rtw89_dle_mem {
 enum rtw89_qta_mode mode;
 const struct rtw89_dle_size *wde_size;
 const struct rtw89_dle_size *ple_size;
 const struct rtw89_wde_quota *wde_min_qt;
 const struct rtw89_wde_quota *wde_max_qt;
 const struct rtw89_ple_quota *ple_min_qt;
 const struct rtw89_ple_quota *ple_max_qt;

 const struct rtw89_rsvd_quota *rsvd_qt;
 const struct rtw89_dle_rsvd_size *rsvd0_size;
 const struct rtw89_dle_rsvd_size *rsvd1_size;
};
struct rtw89_reg_def {
 u32 addr;
 u32 mask;
};
struct rtw89_reg2_def {
 u32 addr;
 u32 data;
};
struct rtw89_reg3_def {
 u32 addr;
 u32 mask;
 u32 data;
};
struct rtw89_reg5_def {
 u8 flag;
 u8 path;
 u32 addr;
 u32 mask;
 u32 data;
};
struct rtw89_reg_imr {
 u32 addr;
 u32 clr;
 u32 set;
};
struct rtw89_phy_table {
 const struct rtw89_reg2_def *regs;
 u32 n_regs;
 enum rtw89_rf_path rf_path;
 void (*config)(struct rtw89_dev *rtwdev, const struct rtw89_reg2_def *reg,
         enum rtw89_rf_path rf_path, void *data);
};
struct rtw89_txpwr_table {
 const void *data;
 u32 size;
 void (*load)(struct rtw89_dev *rtwdev,
       const struct rtw89_txpwr_table *tbl);
};
struct rtw89_txpwr_rule_2ghz {
 const s8 (*lmt)[(RTW89_CHANNEL_WIDTH_40 + 1)][RTW89_NTX_NUM]
         [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
         [RTW89_REGD_NUM][14];
 const s8 (*lmt_ru)[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][14];
};
struct rtw89_txpwr_rule_5ghz {
 const s8 (*lmt)[(RTW89_CHANNEL_WIDTH_160 + 1)][RTW89_NTX_NUM]
         [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
         [RTW89_REGD_NUM][53];
 const s8 (*lmt_ru)[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][53];
};
struct rtw89_txpwr_rule_6ghz {
 const s8 (*lmt)[(RTW89_CHANNEL_WIDTH_320 + 1)][RTW89_NTX_NUM]
         [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
         [RTW89_REGD_NUM][NUM_OF_RTW89_REG_6GHZ_POWER]
         [120];
 const s8 (*lmt_ru)[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][NUM_OF_RTW89_REG_6GHZ_POWER]
     [120];
};
struct rtw89_tx_shape {
 const u8 (*lmt)[RTW89_BAND_NUM][RTW89_RS_TX_SHAPE_NUM][RTW89_REGD_NUM];
 const u8 (*lmt_ru)[RTW89_BAND_NUM][RTW89_REGD_NUM];
};
struct rtw89_rfe_parms {
 const struct rtw89_txpwr_table *byr_tbl;
 struct rtw89_txpwr_rule_2ghz rule_2ghz;
 struct rtw89_txpwr_rule_5ghz rule_5ghz;
 struct rtw89_txpwr_rule_6ghz rule_6ghz;
 struct rtw89_txpwr_rule_2ghz rule_da_2ghz;
 struct rtw89_txpwr_rule_5ghz rule_da_5ghz;
 struct rtw89_txpwr_rule_6ghz rule_da_6ghz;
 struct rtw89_tx_shape tx_shape;
 bool has_da;
};
struct rtw89_rfe_parms_conf {
 const struct rtw89_rfe_parms *rfe_parms;
 u8 rfe_type;
};
struct rtw89_txpwr_conf {
 u8 rfe_type;
 u8 ent_sz;
 u32 num_ents;
 const void *data;
};
struct rtw89_txpwr_byrate_data {
 struct rtw89_txpwr_conf conf;
 struct rtw89_txpwr_table tbl;
};
struct rtw89_txpwr_lmt_2ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[(RTW89_CHANNEL_WIDTH_40 + 1)][RTW89_NTX_NUM]
     [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
     [RTW89_REGD_NUM][14];
};
struct rtw89_txpwr_lmt_5ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[(RTW89_CHANNEL_WIDTH_160 + 1)][RTW89_NTX_NUM]
     [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
     [RTW89_REGD_NUM][53];
};
struct rtw89_txpwr_lmt_6ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[(RTW89_CHANNEL_WIDTH_320 + 1)][RTW89_NTX_NUM]
     [RTW89_RS_LMT_NUM][RTW89_BF_NUM]
     [RTW89_REGD_NUM][NUM_OF_RTW89_REG_6GHZ_POWER]
     [120];
};
struct rtw89_txpwr_lmt_ru_2ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][14];
};
struct rtw89_txpwr_lmt_ru_5ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][53];
};
struct rtw89_txpwr_lmt_ru_6ghz_data {
 struct rtw89_txpwr_conf conf;
 s8 v[RTW89_RU_NUM][RTW89_NTX_NUM]
     [RTW89_REGD_NUM][NUM_OF_RTW89_REG_6GHZ_POWER]
     [120];
};
struct rtw89_tx_shape_lmt_data {
 struct rtw89_txpwr_conf conf;
 u8 v[RTW89_BAND_NUM][RTW89_RS_TX_SHAPE_NUM][RTW89_REGD_NUM];
};
struct rtw89_tx_shape_lmt_ru_data {
 struct rtw89_txpwr_conf conf;
 u8 v[RTW89_BAND_NUM][RTW89_REGD_NUM];
};
struct rtw89_rfe_data {
 struct rtw89_txpwr_byrate_data byrate;
 struct rtw89_txpwr_lmt_2ghz_data lmt_2ghz;
 struct rtw89_txpwr_lmt_5ghz_data lmt_5ghz;
 struct rtw89_txpwr_lmt_6ghz_data lmt_6ghz;
 struct rtw89_txpwr_lmt_2ghz_data da_lmt_2ghz;
 struct rtw89_txpwr_lmt_5ghz_data da_lmt_5ghz;
 struct rtw89_txpwr_lmt_6ghz_data da_lmt_6ghz;
 struct rtw89_txpwr_lmt_ru_2ghz_data lmt_ru_2ghz;
 struct rtw89_txpwr_lmt_ru_5ghz_data lmt_ru_5ghz;
 struct rtw89_txpwr_lmt_ru_6ghz_data lmt_ru_6ghz;
 struct rtw89_txpwr_lmt_ru_2ghz_data da_lmt_ru_2ghz;
 struct rtw89_txpwr_lmt_ru_5ghz_data da_lmt_ru_5ghz;
 struct rtw89_txpwr_lmt_ru_6ghz_data da_lmt_ru_6ghz;
 struct rtw89_tx_shape_lmt_data tx_shape_lmt;
 struct rtw89_tx_shape_lmt_ru_data tx_shape_lmt_ru;
 struct rtw89_rfe_parms rfe_parms;
};
struct rtw89_page_regs {
 u32 hci_fc_ctrl;
 u32 ch_page_ctrl;
 u32 ach_page_ctrl;
 u32 ach_page_info;
 u32 pub_page_info3;
 u32 pub_page_ctrl1;
 u32 pub_page_ctrl2;
 u32 pub_page_info1;
 u32 pub_page_info2;
 u32 wp_page_ctrl1;
 u32 wp_page_ctrl2;
 u32 wp_page_info1;
};
struct rtw89_imr_info {
 u32 wdrls_imr_set;
 u32 wsec_imr_reg;
 u32 wsec_imr_set;
 u32 mpdu_tx_imr_set;
 u32 mpdu_rx_imr_set;
 u32 sta_sch_imr_set;
 u32 txpktctl_imr_b0_reg;
 u32 txpktctl_imr_b0_clr;
 u32 txpktctl_imr_b0_set;
 u32 txpktctl_imr_b1_reg;
 u32 txpktctl_imr_b1_clr;
 u32 txpktctl_imr_b1_set;
 u32 wde_imr_clr;
 u32 wde_imr_set;
 u32 ple_imr_clr;
 u32 ple_imr_set;
 u32 host_disp_imr_clr;
 u32 host_disp_imr_set;
 u32 cpu_disp_imr_clr;
 u32 cpu_disp_imr_set;
 u32 other_disp_imr_clr;
 u32 other_disp_imr_set;
 u32 bbrpt_com_err_imr_reg;
 u32 bbrpt_chinfo_err_imr_reg;
 u32 bbrpt_err_imr_set;
 u32 bbrpt_dfs_err_imr_reg;
 u32 ptcl_imr_clr;
 u32 ptcl_imr_set;
 u32 cdma_imr_0_reg;
 u32 cdma_imr_0_clr;
 u32 cdma_imr_0_set;
 u32 cdma_imr_1_reg;
 u32 cdma_imr_1_clr;
 u32 cdma_imr_1_set;
 u32 phy_intf_imr_reg;
 u32 phy_intf_imr_clr;
 u32 phy_intf_imr_set;
 u32 rmac_imr_reg;
 u32 rmac_imr_clr;
 u32 rmac_imr_set;
 u32 tmac_imr_reg;
 u32 tmac_imr_clr;
 u32 tmac_imr_set;
};
struct rtw89_imr_table {
 const struct rtw89_reg_imr *regs;
 u32 n_regs;
};
struct rtw89_xtal_info {
 u32 xcap_reg;
 u32 sc_xo_mask;
 u32 sc_xi_mask;
};
struct rtw89_rrsr_cfgs {
 struct rtw89_reg3_def ref_rate;
 struct rtw89_reg3_def rsc;
};
struct rtw89_rfkill_regs {
 struct rtw89_reg3_def pinmux;
 struct rtw89_reg3_def mode;
};
struct rtw89_dig_regs {
 u32 seg0_pd_reg;
 u32 pd_lower_bound_mask;
 u32 pd_spatial_reuse_en;
 u32 bmode_pd_reg;
 u32 bmode_cca_rssi_limit_en;
 u32 bmode_pd_lower_bound_reg;
 u32 bmode_rssi_nocca_low_th_mask;
 struct rtw89_reg_def p0_lna_init;
 struct rtw89_reg_def p1_lna_init;
 struct rtw89_reg_def p0_tia_init;
 struct rtw89_reg_def p1_tia_init;
 struct rtw89_reg_def p0_rxb_init;
 struct rtw89_reg_def p1_rxb_init;
 struct rtw89_reg_def p0_p20_pagcugc_en;
 struct rtw89_reg_def p0_s20_pagcugc_en;
 struct rtw89_reg_def p1_p20_pagcugc_en;
 struct rtw89_reg_def p1_s20_pagcugc_en;
};
struct rtw89_edcca_regs {
 u32 edcca_level;
 u32 edcca_mask;
 u32 edcca_p_mask;
 u32 ppdu_level;
 u32 ppdu_mask;
 struct rtw89_edcca_p_regs {
  u32 rpt_a;
  u32 rpt_b;
  u32 rpt_sel;
  u32 rpt_sel_mask;
 } p[RTW89_PHY_NUM];
 u32 rpt_sel_be;
 u32 rpt_sel_be_mask;
 u32 tx_collision_t2r_st;
 u32 tx_collision_t2r_st_mask;
};
struct rtw89_phy_ul_tb_info {
 bool dyn_tb_tri_en;
 u8 def_if_bandedge;
};
struct rtw89_antdiv_stats {
 struct ewma_rssi cck_rssi_avg;
 struct ewma_rssi ofdm_rssi_avg;
 struct ewma_rssi non_legacy_rssi_avg;
 u16 pkt_cnt_cck;
 u16 pkt_cnt_ofdm;
 u16 pkt_cnt_non_legacy;
 u32 evm;
};
struct rtw89_antdiv_info {
 struct rtw89_antdiv_stats target_stats;
 struct rtw89_antdiv_stats main_stats;
 struct rtw89_antdiv_stats aux_stats;
 u8 training_count;
 u8 rssi_pre;
 bool get_stats;
};
enum rtw89_chanctx_state {
 RTW89_CHANCTX_STATE_MCC_START,
 RTW89_CHANCTX_STATE_MCC_STOP,
};
enum rtw89_chanctx_callbacks {
 RTW89_CHANCTX_CALLBACK_PLACEHOLDER,
 RTW89_CHANCTX_CALLBACK_RFK,
 RTW89_CHANCTX_CALLBACK_TAS,

 NUM_OF_RTW89_CHANCTX_CALLBACKS,
};
struct rtw89_chanctx_listener {
 void (*callbacks[NUM_OF_RTW89_CHANCTX_CALLBACKS])
  (struct rtw89_dev *rtwdev, enum rtw89_chanctx_state state);
};
struct rtw89_chip_info {
 enum rtw89_core_chip_id chip_id;
 enum rtw89_chip_gen chip_gen;
 const struct rtw89_chip_ops *ops;
 const struct rtw89_mac_gen_def *mac_def;
 const struct rtw89_phy_gen_def *phy_def;
 const char *fw_basename;
 u8 fw_format_max;
 bool try_ce_fw;
 u8 bbmcu_nr;
 u32 needed_fw_elms;
 const struct rtw89_fw_blacklist *fw_blacklist;
 u32 fifo_size;
 bool small_fifo_size;
 u32 dle_scc_rsvd_size;
 u16 max_amsdu_limit;
 bool dis_2g_40m_ul_ofdma;
 u32 rsvd_ple_ofst;
 const struct rtw89_hfc_param_ini *hfc_param_ini[RTW89_HCI_TYPE_NUM];
 const struct rtw89_dle_mem *dle_mem[RTW89_HCI_DLE_TYPE_NUM];
 u8 wde_qempty_acq_grpnum;
 u8 wde_qempty_mgq_grpsel;
 u32 rf_base_addr[2];
 u8 thermal_th[2];
 u8 support_macid_num;
 u8 support_link_num;
 u8 support_chanctx_num;
 u8 support_bands;
 u16 support_bandwidths;
 bool support_unii4;
 bool support_rnr;
 bool support_ant_gain;
 bool support_tas;
 bool support_sar_by_ant;
 bool support_noise;
 bool ul_tb_waveform_ctrl;
 bool ul_tb_pwr_diff;
 bool rx_freq_frome_ie;
 bool hw_sec_hdr;
 bool hw_mgmt_tx_encrypt;
 bool hw_tkip_crypto;
 bool hw_mlo_bmc_crypto;
 u8 rf_path_num;
 u8 tx_nss;
 u8 rx_nss;
 u8 acam_num;
 u8 bcam_num;
 u8 scam_num;
 u8 bacam_num;
 u8 bacam_dynamic_num;
 enum rtw89_bacam_ver bacam_ver;
 u8 ppdu_max_usr;

 u8 sec_ctrl_efuse_size;
 u32 physical_efuse_size;
 u32 logical_efuse_size;
 u32 limit_efuse_size;
 u32 dav_phy_efuse_size;
 u32 dav_log_efuse_size;
 u32 phycap_addr;
 u32 phycap_size;
 const struct rtw89_efuse_block_cfg *efuse_blocks;

 const struct rtw89_pwr_cfg * const *pwr_on_seq;
 const struct rtw89_pwr_cfg * const *pwr_off_seq;
 const struct rtw89_phy_table *bb_table;
 const struct rtw89_phy_table *bb_gain_table;
 const struct rtw89_phy_table *rf_table[4];
 const struct rtw89_phy_table *nctl_table;
 const struct rtw89_rfk_tbl *nctl_post_table;
 const struct rtw89_phy_dig_gain_table *dig_table;
 const struct rtw89_dig_regs *dig_regs;
 const struct rtw89_phy_tssi_dbw_table *tssi_dbw_table;


 const struct rtw89_rfe_parms_conf *rfe_parms_conf;
 const struct rtw89_rfe_parms *dflt_parms;
 const struct rtw89_chanctx_listener *chanctx_listener;

 u8 txpwr_factor_bb;
 u8 txpwr_factor_rf;
 u8 txpwr_factor_mac;

 u32 para_ver;
 u32 wlcx_desired;
 u8 scbd;
 u8 mailbox;

 u8 afh_guard_ch;
 const u8 *wl_rssi_thres;
 const u8 *bt_rssi_thres;
 u8 rssi_tol;

 u8 mon_reg_num;
 const struct rtw89_btc_fbtc_mreg *mon_reg;
 u8 rf_para_ulink_num;
 const struct rtw89_btc_rf_trx_para *rf_para_ulink;
 u8 rf_para_dlink_num;
 const struct rtw89_btc_rf_trx_para *rf_para_dlink;
 u8 ps_mode_supported;
 u8 low_power_hci_modes;

 u32 h2c_cctl_func_id;
 u32 hci_func_en_addr;
 u32 h2c_desc_size;
 u32 txwd_body_size;
 u32 txwd_info_size;
 u32 h2c_ctrl_reg;
 const u32 *h2c_regs;
 struct rtw89_reg_def h2c_counter_reg;
 u32 c2h_ctrl_reg;
 const u32 *c2h_regs;
 struct rtw89_reg_def c2h_counter_reg;
 const struct rtw89_page_regs *page_regs;
 const u32 *wow_reason_reg;
 bool cfo_src_fd;
 bool cfo_hw_comp;
 const struct rtw89_reg_def *dcfo_comp;
 u8 dcfo_comp_sft;
 const struct rtw89_reg_def (*nhm_report)[12];
 const struct rtw89_reg_def (*nhm_th)[11];
 const struct rtw89_imr_info *imr_info;
 const struct rtw89_imr_table *imr_dmac_table;
 const struct rtw89_imr_table *imr_cmac_table;
 const struct rtw89_rrsr_cfgs *rrsr_cfgs;
 struct rtw89_reg_def bss_clr_vld;
 u32 bss_clr_map_reg;
 const struct rtw89_rfkill_regs *rfkill_init;
 struct rtw89_reg_def rfkill_get;
 u32 dma_ch_mask;
 const struct rtw89_edcca_regs *edcca_regs;
 const struct wiphy_wowlan_support *wowlan_stub;
 const struct rtw89_xtal_info *xtal_info;
};
struct rtw89_chip_variant {
 bool no_mcs_12_13: 1;
 u32 fw_min_ver_code;
};
struct rtw89_dle_info {
 const struct rtw89_rsvd_quota *rsvd_qt;
 enum rtw89_qta_mode qta_mode;
 u16 ple_pg_size;
 u16 ple_free_pg;
 u16 c0_rx_qta;
 u16 c1_rx_qta;
};
struct rtw89_completion_data {
 bool err;
 u8 buf[40];
};
struct rtw89_wait_response {
 struct callback_head callback_head;
 struct completion completion;
 struct rtw89_completion_data data;
};
struct rtw89_wait_info {
 atomic_t cond;
 struct rtw89_completion_data data;
 struct rtw89_wait_response *resp;
};
struct rtw89_mac_info {
 struct rtw89_dle_info dle_info;
 struct rtw89_hfc_param hfc_param;
 enum rtw89_qta_mode qta_mode;
 u8 rpwm_seq_num;
 u8 cpwm_seq_num;


 struct rtw89_wait_info fw_ofld_wait;

 struct rtw89_wait_info ps_wait;
};
enum rtw89_fwdl_check_type {
 RTW89_FWDL_CHECK_FREERTOS_DONE,
 RTW89_FWDL_CHECK_WCPU_FWDL_DONE,
 RTW89_FWDL_CHECK_DCPU_FWDL_DONE,
 RTW89_FWDL_CHECK_BB0_FWDL_DONE,
 RTW89_FWDL_CHECK_BB1_FWDL_DONE,
};
enum rtw89_fw_type {
 RTW89_FW_NORMAL = 1,
 RTW89_FW_WOWLAN = 3,
 RTW89_FW_NORMAL_CE = 5,
 RTW89_FW_BBMCU0 = 64,
 RTW89_FW_BBMCU1 = 65,
 RTW89_FW_LOGFMT = 255,
};
struct rtw89_fw_suit {
 enum rtw89_fw_type type;
 const u8 *data;
 u32 size;
 u8 major_ver;
 u8 minor_ver;
 u8 sub_ver;
 u8 sub_idex;
 u16 build_year;
 u16 build_mon;
 u16 build_date;
 u16 build_hour;
 u16 build_min;
 u8 cmd_ver;
 u8 hdr_ver;
 u32 commitid;
};
struct rtw89_fw_req_info {
 const struct firmware *firmware;
 struct completion completion;
};
struct rtw89_fw_log {
 struct rtw89_fw_suit suit;
 bool enable;
 u32 last_fmt_id;
 u32 fmt_count;
 const __le32 *fmt_ids;
 const char *(*fmts)[1];
};
struct rtw89_fw_elm_info {
 struct rtw89_phy_table *bb_tbl;
 struct rtw89_phy_table *bb_gain;
 struct rtw89_phy_table *rf_radio[4];
 struct rtw89_phy_table *rf_nctl;
 struct rtw89_fw_txpwr_track_cfg *txpwr_trk;
 struct rtw89_phy_rfk_log_fmt *rfk_log_fmt;
 const struct rtw89_regd_data *regd;
 const struct rtw89_fw_element_hdr *afe;
 const struct rtw89_fw_element_hdr *diag_mac;
};
struct rtw89_fw_secure {
 bool secure_boot: 1;
 bool can_mss_v1: 1;
 bool can_mss_v0: 1;
 u32 sb_sel_mgn;
 u8 mss_dev_type;
 u8 mss_cust_idx;
 u8 mss_key_num;
 u8 mss_idx;
};
struct rtw89_fw_info {
 struct rtw89_fw_req_info req;
 int fw_format;
 u8 h2c_seq;
 u8 rec_seq;
 u8 h2c_counter;
 u8 c2h_counter;
 struct rtw89_fw_suit normal;
 struct rtw89_fw_suit wowlan;
 struct rtw89_fw_suit bbmcu0;
 struct rtw89_fw_suit bbmcu1;
 struct rtw89_fw_log log;
 u32 feature_map;
 struct rtw89_fw_elm_info elm_info;
 struct rtw89_fw_secure sec;
};
struct rtw89_cam_info {
 unsigned long addr_cam_map[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long bssid_cam_map[(((20) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long sec_cam_map[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long ba_cam_map[(((24) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct rtw89_ba_cam_entry ba_cam_entry[24];
 const struct rtw89_sec_cam_entry *sec_entries[128];
};
enum rtw89_sar_sources {
 RTW89_SAR_SOURCE_NONE,
 RTW89_SAR_SOURCE_COMMON,
 RTW89_SAR_SOURCE_ACPI,

 RTW89_SAR_SOURCE_NR,
};
enum rtw89_sar_subband {
 RTW89_SAR_2GHZ_SUBBAND,
 RTW89_SAR_5GHZ_SUBBAND_1_2,
 RTW89_SAR_5GHZ_SUBBAND_2_E,
 RTW89_SAR_5GHZ_SUBBAND_3_4,
 RTW89_SAR_6GHZ_SUBBAND_5_L,
 RTW89_SAR_6GHZ_SUBBAND_5_H,
 RTW89_SAR_6GHZ_SUBBAND_6,
 RTW89_SAR_6GHZ_SUBBAND_7_L,
 RTW89_SAR_6GHZ_SUBBAND_7_H,
 RTW89_SAR_6GHZ_SUBBAND_8,

 RTW89_SAR_SUBBAND_NR,
};
struct rtw89_sar_cfg_common {
 bool set[RTW89_SAR_SUBBAND_NR];
 s32 cfg[RTW89_SAR_SUBBAND_NR];
};
enum rtw89_acpi_sar_subband {
 RTW89_ACPI_SAR_2GHZ_SUBBAND,
 RTW89_ACPI_SAR_5GHZ_SUBBAND_1,
 RTW89_ACPI_SAR_5GHZ_SUBBAND_2,
 RTW89_ACPI_SAR_5GHZ_SUBBAND_2E,
 RTW89_ACPI_SAR_5GHZ_SUBBAND_3_4,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_5_L,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_5_H,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_6,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_7_L,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_7_H,
 RTW89_ACPI_SAR_6GHZ_SUBBAND_8,

 NUM_OF_RTW89_ACPI_SAR_SUBBAND,
 RTW89_ACPI_SAR_SUBBAND_NR_LEGACY = RTW89_ACPI_SAR_5GHZ_SUBBAND_3_4 + 1,
 RTW89_ACPI_SAR_SUBBAND_NR_HAS_6GHZ = RTW89_ACPI_SAR_6GHZ_SUBBAND_8 + 1,
};
struct rtw89_sar_entry_from_acpi {
 s16 v[NUM_OF_RTW89_ACPI_SAR_SUBBAND][(RF_PATH_B + 1)];
};
struct rtw89_sar_table_from_acpi {



 struct rtw89_sar_entry_from_acpi entries[RTW89_REGD_NUM];
};
struct rtw89_sar_indicator_from_acpi {
 bool enable_sync;
 unsigned int fields;
 u8 (*rfpath_to_antidx)(enum rtw89_rf_path rfpath);





 u8 tblsel[(RF_PATH_B + 1)];
};
struct rtw89_sar_cfg_acpi {
 u8 downgrade_2tx;
 unsigned int valid_num;
 struct rtw89_sar_table_from_acpi tables[6];
 struct rtw89_sar_indicator_from_acpi indicator;
};
struct rtw89_sar_info {

 enum rtw89_sar_sources src;




 union {
  struct rtw89_sar_cfg_common cfg_common;
  struct rtw89_sar_cfg_acpi cfg_acpi;
 };
};
enum rtw89_ant_gain_subband {
 RTW89_ANT_GAIN_2GHZ_SUBBAND,
 RTW89_ANT_GAIN_5GHZ_SUBBAND_1,
 RTW89_ANT_GAIN_5GHZ_SUBBAND_2,
 RTW89_ANT_GAIN_5GHZ_SUBBAND_2E,
 RTW89_ANT_GAIN_5GHZ_SUBBAND_3_4,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_5_L,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_5_H,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_6,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_7_L,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_7_H,
 RTW89_ANT_GAIN_6GHZ_SUBBAND_8,

 RTW89_ANT_GAIN_SUBBAND_NR,
};
struct rtw89_ant_gain_info {
 s8 offset[2][RTW89_ANT_GAIN_SUBBAND_NR];
 u32 regd_enabled;
 bool block_country;
};
enum rtw89_tas_state {
 RTW89_TAS_STATE_DPR_OFF,
 RTW89_TAS_STATE_DPR_ON,
 RTW89_TAS_STATE_STATIC_SAR,
};
struct rtw89_tas_info {
 u16 tx_ratio_history[6];
 u64 txpwr_history[180];
 u8 enabled_countries;
 u8 txpwr_head_idx;
 u8 txpwr_tail_idx;
 u8 tx_ratio_idx;
 u16 total_tx_ratio;
 u64 total_txpwr;
 u64 instant_txpwr;
 u32 window_size;
 s8 dpr_on_threshold;
 s8 dpr_off_threshold;
 enum rtw89_tas_state backup_state;
 enum rtw89_tas_state state;
 bool keep_history;
 bool block_regd;
 bool enable;
 bool pause;
};
struct rtw89_chanctx_cfg {
 enum rtw89_chanctx_idx idx;
 int ref_count;
};
enum rtw89_chanctx_changes {
 RTW89_CHANCTX_REMOTE_STA_CHANGE,
 RTW89_CHANCTX_BCN_OFFSET_CHANGE,
 RTW89_CHANCTX_P2P_PS_CHANGE,
 RTW89_CHANCTX_BT_SLOT_CHANGE,
 RTW89_CHANCTX_TSF32_TOGGLE_CHANGE,

 NUM_OF_RTW89_CHANCTX_CHANGES,
 RTW89_CHANCTX_CHANGE_DFLT = NUM_OF_RTW89_CHANCTX_CHANGES,
};
enum rtw89_entity_mode {
 RTW89_ENTITY_MODE_SCC_OR_SMLD,
 RTW89_ENTITY_MODE_MCC_PREPARE,
 RTW89_ENTITY_MODE_MCC,

 NUM_OF_RTW89_ENTITY_MODE,
 RTW89_ENTITY_MODE_INVALID = -22,
 RTW89_ENTITY_MODE_UNHANDLED = -3,
};
struct rtw89_entity_mgnt {
 struct list_head active_list;
 struct rtw89_vif *active_roles[2];
 enum rtw89_chanctx_idx chanctx_tbl[2]
       [2];
};
struct rtw89_chanctx {
 struct cfg80211_chan_def chandef;
 struct rtw89_chan chan;
 struct rtw89_chan_rcd rcd;


 struct rtw89_chanctx_cfg *cfg;
};
struct rtw89_edcca_bak {
 u8 a;
 u8 p;
 u8 ppdu;
 u8 th_old;
};
struct rtw89_hal {
 u32 rx_fltr;
 u8 cv;
 u8 acv;
 u32 antenna_tx;
 u32 antenna_rx;
 u8 tx_nss;
 u8 rx_nss;
 bool tx_path_diversity;
 bool ant_diversity;
 bool ant_diversity_fixed;
 bool support_cckpd;
 bool support_igi;
 bool no_mcs_12_13;
 bool no_eht;

 atomic_t roc_chanctx_idx;
 u8 roc_link_index;

 unsigned long changes[(((NUM_OF_RTW89_CHANCTX_CHANGES) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long entity_map[(((NUM_OF_RTW89_CHANCTX) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct rtw89_chanctx chanctx[NUM_OF_RTW89_CHANCTX];
 struct cfg80211_chan_def roc_chandef;

 bool entity_active[RTW89_PHY_NUM];
 bool entity_pause;
 enum rtw89_entity_mode entity_mode;
 struct rtw89_entity_mgnt entity_mgnt;

 u32 disabled_dm_bitmap;

 u8 thermal_prot_th;
 u8 thermal_prot_lv;
};
enum rtw89_flags {
 RTW89_FLAG_POWERON,
 RTW89_FLAG_DMAC_FUNC,
 RTW89_FLAG_CMAC0_FUNC,
 RTW89_FLAG_CMAC1_FUNC,
 RTW89_FLAG_FW_RDY,
 RTW89_FLAG_RUNNING,
 RTW89_FLAG_PROBE_DONE,
 RTW89_FLAG_BFEE_MON,
 RTW89_FLAG_BFEE_EN,
 RTW89_FLAG_BFEE_TIMER_KEEP,
 RTW89_FLAG_NAPI_RUNNING,
 RTW89_FLAG_LEISURE_PS,
 RTW89_FLAG_LOW_POWER_MODE,
 RTW89_FLAG_INACTIVE_PS,
 RTW89_FLAG_CRASH_SIMULATING,
 RTW89_FLAG_SER_HANDLING,
 RTW89_FLAG_WOWLAN,
 RTW89_FLAG_FORBIDDEN_TRACK_WORK,
 RTW89_FLAG_CHANGING_INTERFACE,
 RTW89_FLAG_HW_RFKILL_STATE,
 RTW89_FLAG_UNPLUGGED,
 RTW89_FLAG_SHUTDOWN,

 NUM_OF_RTW89_FLAGS,
};
enum rtw89_quirks {
 RTW89_QUIRK_PCI_BER,
 RTW89_QUIRK_THERMAL_PROT_120C,
 RTW89_QUIRK_THERMAL_PROT_110C,

 NUM_OF_RTW89_QUIRKS,
};
enum rtw89_custid {
 RTW89_CUSTID_NONE,
 RTW89_CUSTID_ACER,
 RTW89_CUSTID_AMD,
 RTW89_CUSTID_ASUS,
 RTW89_CUSTID_DELL,
 RTW89_CUSTID_HP,
 RTW89_CUSTID_LENOVO,
};
struct rtw89_pkt_stat {
 u16 beacon_nr;
 u8 beacon_rate;
 u32 beacon_len;
 u32 rx_rate_cnt[RTW89_HW_RATE_NR];
};
struct rtw89_beacon_dist {
 u16 min;
 u16 max;
 u16 outlier_count;
 u16 lower_bound;
 u16 upper_bound;
 u16 bins[6];
};
struct rtw89_beacon_stat {
 u8 num;
 u8 wp;
 u16 tbtt_tu_min;
 u16 tbtt_tu_max;
 u16 drift[32];
 u32 tbtt_us[32];
 u16 tbtt_tu[32];
 struct rtw89_beacon_dist bcn_dist;
};
struct ewma_thermal { unsigned long internal; };
struct rtw89_phy_stat {
 struct ewma_thermal avg_thermal[4];
 u8 last_thermal_max;
 struct rtw89_beacon_stat bcn_stat;
};
enum rtw89_rfk_report_state {
 RTW89_RFK_STATE_START = 0x0,
 RTW89_RFK_STATE_OK = 0x1,
 RTW89_RFK_STATE_FAIL = 0x2,
 RTW89_RFK_STATE_TIMEOUT = 0x3,
 RTW89_RFK_STATE_H2C_CMD_ERR = 0x4,
};
struct rtw89_rfk_wait_info {
 struct completion completion;
 ktime_t start_time;
 enum rtw89_rfk_report_state state;
 u8 version;
};
struct rtw89_dack_info {
 bool dack_done;
 u8 msbk_d[2][2][16];
 u8 dadck_d[2][2];
 u16 addck_d[2][2];
 u16 biask_d[2][2];
 u32 dack_cnt;
 bool addck_timeout[2];
 bool dadck_timeout[2];
 bool msbk_timeout[2];
};
enum rtw89_rfk_chs_nrs {
 __RTW89_RFK_CHS_NR_V0 = 2,
 __RTW89_RFK_CHS_NR_V1 = 3,

 RTW89_RFK_CHS_NR = __RTW89_RFK_CHS_NR_V1,
};
struct rtw89_rfk_mcc_info_data {
 u8 ch[RTW89_RFK_CHS_NR];
 u8 band[RTW89_RFK_CHS_NR];
 u8 bw[RTW89_RFK_CHS_NR];
 u8 table_idx;
};
struct rtw89_rfk_mcc_info {
 struct rtw89_rfk_mcc_info_data data[2];
};
struct rtw89_lck_info {
 u8 thermal[4];
};
struct rtw89_rx_dck_info {
 u8 thermal[4];
};
struct rtw89_iqk_info {
 bool lok_cor_fail[2][4];
 bool lok_fin_fail[2][4];
 bool lok_fail[4];
 bool iqk_tx_fail[2][4];
 bool iqk_rx_fail[2][4];
 u32 iqk_fail_cnt;
 bool is_iqk_init;
 u32 iqk_channel[2];
 u8 iqk_band[4];
 u8 iqk_ch[4];
 u8 iqk_bw[4];
 u8 iqk_times;
 u8 version;
 u32 nb_txcfir[4];
 u32 nb_rxcfir[4];
 u32 bp_txkresult[4];
 u32 bp_rxkresult[4];
 u32 bp_iqkenable[4];
 bool is_wb_txiqk[4];
 bool is_wb_rxiqk[4];
 bool is_nbiqk;
 bool iqk_fft_en;
 bool iqk_xym_en;
 bool iqk_sram_en;
 bool iqk_cfir_en;
 u32 syn1to2;
 u8 iqk_mcc_ch[2][4];
 u8 iqk_table_idx[4];
 u32 lok_idac[2][4];
 u32 lok_vbuf[2][4];
};
struct rtw89_dpk_bkup_para {
 enum rtw89_band band;
 enum rtw89_bandwidth bw;
 u8 ch;
 u8 path_ok;
 u8 mdpd_en;
 u8 txagc_dpk;
 u8 ther_dpk;
 u8 gs;
 u16 pwsf;
};
struct rtw89_dpk_info {
 bool is_dpk_enable;
 bool is_dpk_reload_en;
 u8 dpk_gs[RTW89_PHY_NUM];
 u16 dc_i[2][2];
 u16 dc_q[2][2];
 u8 corr_val[2][2];
 u8 corr_idx[2][2];
 u8 cur_idx[2];
 u8 cur_k_set;
 struct rtw89_dpk_bkup_para bp[2][2];
 u8 max_dpk_txagc[2];
 u32 dpk_order[2];
};
struct rtw89_fem_info {
 bool elna_2g;
 bool elna_5g;
 bool epa_2g;
 bool epa_5g;
 bool epa_6g;
};
struct rtw89_phy_ch_info {
 u8 rssi_min;
 u16 rssi_min_macid;
 u8 pre_rssi_min;
 u8 rssi_max;
 u16 rssi_max_macid;
 u8 rxsc_160;
 u8 rxsc_80;
 u8 rxsc_40;
 u8 rxsc_20;
 u8 rxsc_l;
 u8 is_noisy;
};
struct rtw89_agc_gaincode_set {
 u8 lna_idx;
 u8 tia_idx;
 u8 rxb_idx;
};
struct rtw89_dig_info {
 struct rtw89_agc_gaincode_set cur_gaincode;
 bool force_gaincode_idx_en;
 struct rtw89_agc_gaincode_set force_gaincode;
 u8 igi_rssi_th[5];
 u16 fa_th[4];
 u8 igi_rssi;
 u8 igi_fa_rssi;
 u8 fa_rssi_ofst;
 u8 dyn_igi_max;
 u8 dyn_igi_min;
 bool dyn_pd_th_en;
 u8 dyn_pd_th_max;
 u8 pd_low_th_ofst;
 u8 ib_pbk;
 s8 ib_pkpwr;
 s8 lna_gain_a[7];
 s8 lna_gain_g[7];
 s8 *lna_gain;
 s8 tia_gain_a[2];
 s8 tia_gain_g[2];
 s8 *tia_gain;
 u32 bak_dig;
 bool is_linked_pre;
 bool bypass_dig;
 bool pause_dig;
};
enum rtw89_multi_cfo_mode {
 RTW89_PKT_BASED_AVG_MODE = 0,
 RTW89_ENTRY_BASED_AVG_MODE = 1,
 RTW89_TP_BASED_AVG_MODE = 2,
};
enum rtw89_phy_cfo_status {
 RTW89_PHY_DCFO_STATE_NORMAL = 0,
 RTW89_PHY_DCFO_STATE_ENHANCE = 1,
 RTW89_PHY_DCFO_STATE_HOLD = 2,
 RTW89_PHY_DCFO_STATE_MAX
};
enum rtw89_phy_cfo_ul_ofdma_acc_mode {
 RTW89_CFO_UL_OFDMA_ACC_DISABLE = 0,
 RTW89_CFO_UL_OFDMA_ACC_ENABLE = 1
};
struct rtw89_cfo_tracking_info {
 u16 cfo_timer_ms;
 bool cfo_trig_by_timer_en;
 enum rtw89_phy_cfo_status phy_cfo_status;
 enum rtw89_phy_cfo_ul_ofdma_acc_mode cfo_ul_ofdma_acc_mode;
 u8 phy_cfo_trk_cnt;
 bool is_adjust;
 enum rtw89_multi_cfo_mode rtw89_multi_cfo_mode;
 bool apply_compensation;
 u8 crystal_cap;
 u8 crystal_cap_default;
 u8 def_x_cap;
 s8 x_cap_ofst;
 u32 sta_cfo_tolerance;
 s32 cfo_tail[64];
 u16 cfo_cnt[64];
 s32 cfo_avg_pre;
 s32 cfo_avg[64];
 s32 pre_cfo_avg[64];
 s32 dcfo_avg;
 s32 dcfo_avg_pre;
 u32 packet_count;
 u32 packet_count_pre;
 s32 residual_cfo_acc;
 u8 phy_cfotrk_state;
 u8 phy_cfotrk_cnt;
 bool divergence_lock_en;
 u8 x_cap_lb;
 u8 x_cap_ub;
 u8 lock_cnt;
};
enum rtw89_tssi_alimk_band {
 TSSI_ALIMK_2G = 0,
 TSSI_ALIMK_5GL,
 TSSI_ALIMK_5GM,
 TSSI_ALIMK_5GH,
 TSSI_ALIMK_MAX
};
struct rtw89_tssi_info {
 u8 thermal[4];
 s8 tssi_trim[4][8];
 s8 tssi_trim_6g[4][16];
 s8 tssi_cck[4][6];
 s8 tssi_mcs[4][(5 + 14)];
 s8 tssi_6g_mcs[4][32];
 s8 extra_ofst[4];
 bool tssi_tracking_check[4];
 u8 default_txagc_offset[4];
 u32 base_thermal[4];
 bool check_backup_aligmk[4][67];
 u32 alignment_backup_by_ch[4][67][8];
 u32 alignment_value[4][TSSI_ALIMK_MAX][8];
 bool alignment_done[4][TSSI_ALIMK_MAX];
 u64 tssi_alimk_time;
};
struct rtw89_power_trim_info {
 bool pg_thermal_trim;
 bool pg_pa_bias_trim;
 u8 thermal_trim[4];
 u8 pa_bias_trim[4];
 u8 pad_bias_trim[4];
};
enum rtw89_regd_func {
 RTW89_REGD_FUNC_TAS = 0,
 RTW89_REGD_FUNC_DAG = 1,

 NUM_OF_RTW89_REGD_FUNC,
};
struct rtw89_regd {
 char alpha2[3];
 u8 txpwr_regd[RTW89_BAND_NUM];
 unsigned long func_bitmap[(((NUM_OF_RTW89_REGD_FUNC) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct rtw89_regd_data {
 unsigned int nr;
 struct rtw89_regd map[1] ;
};
struct rtw89_regd_ctrl {
 unsigned int nr;
 const struct rtw89_regd *map;
};
struct rtw89_regulatory_info {
 struct rtw89_regd_ctrl ctrl;
 const struct rtw89_regd *regd;
 enum rtw89_reg_6ghz_power reg_6ghz_power;
 struct rtw89_reg_6ghz_tpe reg_6ghz_tpe;
 bool txpwr_uk_follow_etsi;

 unsigned long block_unii4[(((((u8)~0U)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long block_6ghz[(((((u8)~0U)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long block_6ghz_sp[(((((u8)~0U)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long block_6ghz_vlp[(((((u8)~0U)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
enum rtw89_ifs_clm_application {
 RTW89_IFS_CLM_INIT = 0,
 RTW89_IFS_CLM_BACKGROUND = 1,
 RTW89_IFS_CLM_ACS = 2,
 RTW89_IFS_CLM_DIG = 3,
 RTW89_IFS_CLM_TDMA_DIG = 4,
 RTW89_IFS_CLM_DBG = 5,
 RTW89_IFS_CLM_DBG_MANUAL = 6
};
struct rtw89_nhm_report {
 struct list_head list;
 struct ieee80211_channel *channel;
 u8 noise;
};
struct rtw89_env_monitor_info {
 u8 ccx_watchdog_result;
 bool ccx_ongoing;
 u8 ccx_rac_lv;
 bool ccx_manual_ctrl;
 u16 ifs_clm_mntr_time;
 enum rtw89_ifs_clm_application ifs_clm_app;
 u16 ccx_period;
 u8 ccx_unit_idx;
 u16 ifs_clm_th_l[4];
 u16 ifs_clm_th_h[4];
 u16 ifs_clm_tx;
 u16 ifs_clm_edcca_excl_cca;
 u16 ifs_clm_ofdmfa;
 u16 ifs_clm_ofdmcca_excl_fa;
 u16 ifs_clm_cckfa;
 u16 ifs_clm_cckcca_excl_fa;
 u16 ifs_clm_total_ifs;
 u8 ifs_clm_his[4];
 u16 ifs_clm_avg[4];
 u16 ifs_clm_cca[4];
 u8 ifs_clm_tx_ratio;
 u8 ifs_clm_edcca_excl_cca_ratio;
 u8 ifs_clm_cck_fa_ratio;
 u8 ifs_clm_ofdm_fa_ratio;
 u8 ifs_clm_cck_cca_excl_fa_ratio;
 u8 ifs_clm_ofdm_cca_excl_fa_ratio;
 u16 ifs_clm_cck_fa_permil;
 u16 ifs_clm_ofdm_fa_permil;
 u32 ifs_clm_ifs_avg[4];
 u32 ifs_clm_cca_avg[4];
 bool nhm_include_cca;
 u32 nhm_sum;
 u32 nhm_mntr_time;
 u16 nhm_result[12];
 u8 nhm_th[12];
 struct rtw89_nhm_report *nhm_his[RTW89_BAND_NUM];
 struct list_head nhm_rpt_list;
};
enum rtw89_ser_rcvy_step {
 RTW89_SER_DRV_STOP_TX,
 RTW89_SER_DRV_STOP_RX,
 RTW89_SER_DRV_STOP_RUN,
 RTW89_SER_HAL_STOP_DMA,
 RTW89_SER_SUPPRESS_LOG,
 RTW89_NUM_OF_SER_FLAGS
};
struct rtw89_ser {
 u8 state;
 u8 alarm_event;
 bool prehandle_l1;

 struct work_struct ser_hdl_work;
 struct delayed_work ser_alarm_work;
 const struct state_ent *st_tbl;
 const struct event_ent *ev_tbl;
 struct list_head msg_q;
 spinlock_t msg_q_lock;
 unsigned long flags[(((RTW89_NUM_OF_SER_FLAGS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct rtw89_ppdu_sts_info {
 struct sk_buff_head rx_queue[RTW89_PHY_NUM];
 u8 curr_rx_ppdu_cnt[RTW89_PHY_NUM];
};
struct rtw89_hw_scan_extra_op {
 bool set;
 u8 macid;
 u8 port;
 struct rtw89_chan chan;
 struct rtw89_vif_link *rtwvif_link;
};
struct rtw89_hw_scan_info {
 struct rtw89_vif_link *scanning_vif;
 struct list_head pkt_list[NUM_NL80211_BANDS];
 struct list_head chan_list;
 struct rtw89_chan op_chan;
 struct rtw89_hw_scan_extra_op extra_op;
 bool connected;
 bool abort;
 u16 delay;
 u8 seq: 2;
};
enum rtw89_phy_bb_gain_band {
 RTW89_BB_GAIN_BAND_2G = 0,
 RTW89_BB_GAIN_BAND_5G_L = 1,
 RTW89_BB_GAIN_BAND_5G_M = 2,
 RTW89_BB_GAIN_BAND_5G_H = 3,
 RTW89_BB_GAIN_BAND_6G_L = 4,
 RTW89_BB_GAIN_BAND_6G_M = 5,
 RTW89_BB_GAIN_BAND_6G_H = 6,
 RTW89_BB_GAIN_BAND_6G_UH = 7,

 RTW89_BB_GAIN_BAND_NR,
};
enum rtw89_phy_gain_band_be {
 RTW89_BB_GAIN_BAND_2G_BE = 0,
 RTW89_BB_GAIN_BAND_5G_L_BE = 1,
 RTW89_BB_GAIN_BAND_5G_M_BE = 2,
 RTW89_BB_GAIN_BAND_5G_H_BE = 3,
 RTW89_BB_GAIN_BAND_6G_L0_BE = 4,
 RTW89_BB_GAIN_BAND_6G_L1_BE = 5,
 RTW89_BB_GAIN_BAND_6G_M0_BE = 6,
 RTW89_BB_GAIN_BAND_6G_M1_BE = 7,
 RTW89_BB_GAIN_BAND_6G_H0_BE = 8,
 RTW89_BB_GAIN_BAND_6G_H1_BE = 9,
 RTW89_BB_GAIN_BAND_6G_UH0_BE = 10,
 RTW89_BB_GAIN_BAND_6G_UH1_BE = 11,

 RTW89_BB_GAIN_BAND_NR_BE,
};
enum rtw89_phy_bb_bw_be {
 RTW89_BB_BW_20_40 = 0,
 RTW89_BB_BW_80_160_320 = 1,

 RTW89_BB_BW_NR_BE,
};
enum rtw89_bw20_sc {
 RTW89_BW20_SC_20M = 1,
 RTW89_BW20_SC_40M = 2,
 RTW89_BW20_SC_80M = 4,
 RTW89_BW20_SC_160M = 8,
 RTW89_BW20_SC_320M = 16,
};
enum rtw89_phy_bb_rxsc_num {
 RTW89_BB_RXSC_NUM_40 = 9,
 RTW89_BB_RXSC_NUM_80 = 13,
 RTW89_BB_RXSC_NUM_160 = 15,
};
struct rtw89_phy_bb_gain_info {
 s8 lna_gain[RTW89_BB_GAIN_BAND_NR][4][7];
 s8 tia_gain[RTW89_BB_GAIN_BAND_NR][4][2];
 s8 lna_gain_bypass[RTW89_BB_GAIN_BAND_NR][4][7];
 s8 lna_op1db[RTW89_BB_GAIN_BAND_NR][4][7];
 s8 tia_lna_op1db[RTW89_BB_GAIN_BAND_NR][4]
   [7 + 1];
 s8 rpl_ofst_20[RTW89_BB_GAIN_BAND_NR][4];
 s8 rpl_ofst_40[RTW89_BB_GAIN_BAND_NR][4]
        [RTW89_BB_RXSC_NUM_40];
 s8 rpl_ofst_80[RTW89_BB_GAIN_BAND_NR][4]
        [RTW89_BB_RXSC_NUM_80];
 s8 rpl_ofst_160[RTW89_BB_GAIN_BAND_NR][4]
         [RTW89_BB_RXSC_NUM_160];
};
struct rtw89_phy_bb_gain_info_be {
 s8 lna_gain[RTW89_BB_GAIN_BAND_NR_BE][RTW89_BB_BW_NR_BE][4]
     [7];
 s8 tia_gain[RTW89_BB_GAIN_BAND_NR_BE][RTW89_BB_BW_NR_BE][4]
     [2];
 s8 lna_gain_bypass[RTW89_BB_GAIN_BAND_NR_BE][RTW89_BB_BW_NR_BE]
     [4][7];
 s8 lna_op1db[RTW89_BB_GAIN_BAND_NR_BE][RTW89_BB_BW_NR_BE]
      [4][7];
 s8 tia_lna_op1db[RTW89_BB_GAIN_BAND_NR_BE][RTW89_BB_BW_NR_BE]
   [4][7 + 1];
 s8 rpl_ofst_20[RTW89_BB_GAIN_BAND_NR_BE][4]
        [RTW89_BW20_SC_20M];
 s8 rpl_ofst_40[RTW89_BB_GAIN_BAND_NR_BE][4]
        [RTW89_BW20_SC_40M];
 s8 rpl_ofst_80[RTW89_BB_GAIN_BAND_NR_BE][4]
        [RTW89_BW20_SC_80M];
 s8 rpl_ofst_160[RTW89_BB_GAIN_BAND_NR_BE][4]
         [RTW89_BW20_SC_160M];
};
struct rtw89_phy_efuse_gain {
 bool offset_valid;
 bool comp_valid;
 s8 offset[4][RTW89_GAIN_OFFSET_NR];
 s8 offset_base[RTW89_PHY_NUM];
 s8 rssi_base[RTW89_PHY_NUM];
 s8 comp[4][RTW89_SUBBAND_NR];
};
struct rtw89_wow_cam_info {
 bool r_w;
 u8 idx;
 u32 mask[4];
 u16 crc;
 bool negative_pattern_match;
 bool skip_mac_hdr;
 bool uc;
 bool mc;
 bool bc;
 bool valid;
};
struct rtw89_wow_key_info {
 u8 ptk_tx_iv[8];
 u8 valid_check;
 u8 symbol_check_en;
 u8 gtk_keyidx;
 u8 rsvd[5];
 u8 ptk_rx_iv[8];
 u8 gtk_rx_iv[4][8];
} __attribute__((__packed__));
struct rtw89_wow_gtk_info {
 u8 kck[32];
 u8 kek[32];
 u8 tk1[16];
 u8 rxmickey[8];
 u8 txmickey[8];
 __le32 igtk_keyid;
 __le64 ipn;
 u8 igtk[2][32];
 u8 psk[32];
} __attribute__((__packed__));
struct rtw89_wow_aoac_report {
 u8 rpt_ver;
 u8 sec_type;
 u8 key_idx;
 u8 pattern_idx;
 u8 rekey_ok;
 u8 ptk_tx_iv[8];
 u8 eapol_key_replay_count[8];
 u8 gtk[32];
 u8 ptk_rx_iv[8];
 u8 gtk_rx_iv[4][8];
 u64 igtk_key_id;
 u64 igtk_ipn;
 u8 igtk[32];
 u8 csa_pri_ch;
 u8 csa_bw;
 u8 csa_ch_offset;
 u8 csa_chsw_failed;
 u8 csa_ch_band;
};
struct rtw89_wow_param {
 struct rtw89_vif_link *rtwvif_link;
 unsigned long flags[(((RTW89_WOW_FLAG_NUM) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct rtw89_wow_cam_info patterns[18];
 struct rtw89_wow_key_info key_info;
 struct rtw89_wow_gtk_info gtk_info;
 struct rtw89_wow_aoac_report aoac_rpt;
 u8 pattern_cnt;
 u8 ptk_alg;
 u8 gtk_alg;
 u8 ptk_keyidx;
 u8 akm;


 struct rtw89_wait_info wait;

 bool pno_inited;
 struct list_head pno_pkt_list;
 struct cfg80211_sched_scan_request *nd_config;
};
struct rtw89_mcc_limit {
 bool enable;
 u16 max_tob;
 u16 max_toa;
 u16 max_dur;
};
struct rtw89_mcc_policy {
 u8 c2h_rpt;
 u8 tx_null_early;
 u8 dis_tx_null;
 u8 in_curr_ch;
 u8 dis_sw_retry;
 u8 sw_retry_count;
};
struct rtw89_mcc_role {
 struct rtw89_vif_link *rtwvif_link;
 struct rtw89_mcc_policy policy;
 struct rtw89_mcc_limit limit;

 const struct rtw89_mcc_courtesy_cfg *crtz;


 u8 slot_idx;


 u8 macid_bitmap[(((128) + ((sizeof(char) * 8)) - 1) / ((sizeof(char) * 8)))];
 u8 probe_count;

 u16 duration;
 u16 beacon_interval;
 bool is_2ghz;
 bool is_go;
 bool is_gc;
 bool ignore_bcn;
};
struct rtw89_mcc_bt_role {
 u16 duration;
};
struct rtw89_mcc_courtesy_cfg {
 u8 slot_num;
 u8 macid_tgt;
};
struct rtw89_mcc_courtesy {
 struct rtw89_mcc_courtesy_cfg ref;
 struct rtw89_mcc_courtesy_cfg aux;
};
enum rtw89_mcc_plan {
 RTW89_MCC_PLAN_TAIL_BT,
 RTW89_MCC_PLAN_MID_BT,
 RTW89_MCC_PLAN_NO_BT,

 NUM_OF_RTW89_MCC_PLAN,
};
struct rtw89_mcc_pattern {
 s16 tob_ref;
 s16 toa_ref;
 s16 tob_aux;
 s16 toa_aux;

 enum rtw89_mcc_plan plan;
 struct rtw89_mcc_courtesy courtesy;
};
struct rtw89_mcc_sync {
 bool enable;
 u16 offset;
 u8 macid_src;
 u8 band_src;
 u8 port_src;
 u8 macid_tgt;
 u8 band_tgt;
 u8 port_tgt;
};
struct rtw89_mcc_config {
 struct rtw89_mcc_pattern pattern;
 struct rtw89_mcc_sync sync;
 u64 start_tsf;
 u64 start_tsf_in_aux_domain;
 u64 prepare_delay;
 u16 mcc_interval;
 u16 beacon_offset;
};
enum rtw89_mcc_mode {
 RTW89_MCC_MODE_GO_STA,
 RTW89_MCC_MODE_GC_STA,
};
struct rtw89_mcc_info {
 struct rtw89_wait_info wait;

 u8 group;
 enum rtw89_mcc_mode mode;
 struct rtw89_mcc_role role_ref;
 struct rtw89_mcc_role role_aux;
 struct rtw89_mcc_bt_role bt_role;
 struct rtw89_mcc_config config;
};
enum rtw89_mlo_mode {
 RTW89_MLO_MODE_MLSR = 0,

 NUM_OF_RTW89_MLO_MODE,
};
struct rtw89_mlo_info {
 struct rtw89_wait_info wait;
};
struct rtw89_beacon_track_info {
 bool is_data_ready;
 u32 tbtt_offset;
 u16 bcn_timeout;


 u8 dtim;
 u16 beacon_int;
 u16 low_bcn_th;
 u16 med_bcn_th;
 u16 high_bcn_th;
 u16 target_bcn_th;
 u16 outlier_low_bcn_th;
 u16 outlier_high_bcn_th;
 u32 close_bcn_intvl_th;
 u32 tbtt_diff_th;
};
struct rtw89_dev {
 struct ieee80211_hw *hw;
 struct device *dev;
 const struct ieee80211_ops *ops;

 bool dbcc_en;
 bool support_mlo;
 enum rtw89_mlo_dbcc_mode mlo_dbcc_mode;
 struct rtw89_hw_scan_info scan_info;
 const struct rtw89_chip_info *chip;
 const struct rtw89_chip_variant *variant;
 const struct rtw89_pci_info *pci_info;
 const struct rtw89_rfe_parms *rfe_parms;
 struct rtw89_hal hal;
 struct rtw89_beacon_track_info bcn_track;
 struct rtw89_mcc_info mcc;
 struct rtw89_mlo_info mlo;
 struct rtw89_mac_info mac;
 struct rtw89_fw_info fw;
 struct rtw89_hci_info hci;
 struct rtw89_efuse efuse;
 struct rtw89_traffic_stats stats;
 struct rtw89_rfe_data *rfe_data;
 enum rtw89_custid custid;

 struct rtw89_sta_link *assoc_link_on_macid[128];
 refcount_t refcount_ap_info;

 struct list_head rtwvifs_list;

 struct mutex rf_mutex;
 struct workqueue_struct *txq_wq;
 struct work_struct txq_work;
 struct delayed_work txq_reinvoke_work;

 spinlock_t ba_lock;

 struct list_head ba_list;

 struct list_head forbid_ba_list;
 struct work_struct ba_work;

 spinlock_t rpwm_lock;

 struct list_head tx_waits;
 struct wiphy_delayed_work tx_wait_work;

 struct rtw89_cam_info cam_info;

 struct sk_buff_head c2h_queue;
 struct wiphy_work c2h_work;
 struct wiphy_work ips_work;
 struct wiphy_work cancel_6ghz_probe_work;
 struct work_struct load_firmware_work;

 struct list_head early_h2c_list;

 struct rtw89_ser ser;

 unsigned long hw_port[(((RTW89_PORT_NUM) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long mac_id_map[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long flags[(((NUM_OF_RTW89_FLAGS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long pkt_offload[(((255) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long quirks[(((NUM_OF_RTW89_QUIRKS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];

 struct rtw89_phy_stat phystat;
 struct rtw89_rfk_wait_info rfk_wait;
 struct rtw89_dack_info dack;
 struct rtw89_iqk_info iqk;
 struct rtw89_dpk_info dpk;
 struct rtw89_rfk_mcc_info rfk_mcc;
 struct rtw89_lck_info lck;
 struct rtw89_rx_dck_info rx_dck;
 bool is_tssi_mode[4];
 bool is_bt_iqk_timeout;

 struct rtw89_fem_info fem;
 struct rtw89_txpwr_byrate byr[RTW89_BAND_NUM][(RTW89_CHANNEL_WIDTH_320 + 1)];
 struct rtw89_tssi_info tssi;
 struct rtw89_power_trim_info pwr_trim;

 struct rtw89_cfo_tracking_info cfo_tracking;
 union {
  struct rtw89_phy_bb_gain_info ax;
  struct rtw89_phy_bb_gain_info_be be;
 } bb_gain;
 struct rtw89_phy_efuse_gain efuse_gain;
 struct rtw89_phy_ul_tb_info ul_tb_info;
 struct rtw89_antdiv_info antdiv;

 struct rtw89_bb_ctx {
  enum rtw89_phy_idx phy_idx;
  struct rtw89_env_monitor_info env_monitor;
  struct rtw89_dig_info dig;
  struct rtw89_phy_ch_info ch_info;
  struct rtw89_edcca_bak edcca_bak;
  struct ewma_rssi bcn_rssi;
  struct rtw89_pkt_stat cur_pkt_stat;
  struct rtw89_pkt_stat last_pkt_stat;
 } bbs[RTW89_PHY_NUM];

 struct wiphy_delayed_work track_work;
 struct wiphy_delayed_work track_ps_work;
 struct wiphy_delayed_work chanctx_work;
 struct wiphy_delayed_work coex_act1_work;
 struct wiphy_delayed_work coex_bt_devinfo_work;
 struct wiphy_delayed_work coex_rfk_chk_work;
 struct wiphy_delayed_work cfo_track_work;
 struct wiphy_delayed_work mcc_prepare_done_work;
 struct delayed_work forbid_ba_work;
 struct wiphy_delayed_work antdiv_work;
 struct rtw89_ppdu_sts_info ppdu_sts;
 u8 total_sta_assoc;
 bool scanning;

 struct rtw89_regulatory_info regulatory;
 struct rtw89_sar_info sar;
 struct rtw89_tas_info tas;
 struct rtw89_ant_gain_info ant_gain;

 struct rtw89_btc btc;
 enum rtw89_ps_mode ps_mode;
 bool lps_enabled;

 struct rtw89_wow_param wow;


 struct net_device *netdev;
 struct napi_struct napi;
 int napi_budget_countdown;

 struct rtw89_debugfs *debugfs;


 u8 priv[1] ;
};
struct rtw89_link_conf_container {
 struct ieee80211_bss_conf *link_conf[15];
};
struct rtw89_vif {
 struct rtw89_dev *rtwdev;
 struct list_head list;
 struct list_head mgnt_entry;
 struct rtw89_link_conf_container *snap_link_confs;

 u8 mac_addr[6];
 __be32 ip_addr;

 struct rtw89_traffic_stats stats;
 struct rtw89_traffic_stats stats_ps;
 u32 tdls_peer;

 struct ieee80211_scan_ies *scan_ies;
 struct cfg80211_scan_request *scan_req;

 struct rtw89_roc roc;
 bool offchan;

 enum rtw89_mlo_mode mlo_mode;

 struct list_head dlink_pool;
 u8 links_inst_valid_num;
 unsigned long links_inst_map[(((2) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct rtw89_vif_link *links[15];
 struct rtw89_vif_link links_inst[1] ;
};
enum rtw89_sta_flags {
 RTW89_REMOTE_STA_IN_PS,

 NUM_OF_RTW89_STA_FLAGS,
};
struct rtw89_sta {
 struct rtw89_dev *rtwdev;
 struct rtw89_vif *rtwvif;

 unsigned long flags[(((NUM_OF_RTW89_STA_FLAGS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];

 bool disassoc;

 struct sk_buff_head roc_queue;

 struct rtw89_ampdu_params ampdu_params[16];
 unsigned long ampdu_map[(((16) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];

 unsigned long pairwise_sec_cam_map[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];

 struct list_head dlink_pool;
 u8 links_inst_valid_num;
 unsigned long links_inst_map[(((2) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct rtw89_sta_link *links[15];
 struct rtw89_sta_link links_inst[1] ;
};
struct rtw89_fw_blacklist {
 u8 ver;
 u8 list[32];
};
struct rtw89_mac_mcc_tsf_rpt {
 u32 macid_x;
 u32 macid_y;
 u32 tsf_x_low;
 u32 tsf_x_high;
 u32 tsf_y_low;
 u32 tsf_y_high;
};
_Static_assert(sizeof(struct rtw89_mac_mcc_tsf_rpt) <= 40, "sizeof(struct rtw89_mac_mcc_tsf_rpt) <= RTW89_COMPLETION_BUF_SIZE");
struct rtw89_mac_mrc_tsf_rpt {
 unsigned int num;
 u64 tsfs[2];
};
_Static_assert(sizeof(struct rtw89_mac_mrc_tsf_rpt) <= 40, "sizeof(struct rtw89_mac_mrc_tsf_rpt) <= RTW89_COMPLETION_BUF_SIZE");
struct __rtw89_fw_txpwr_element {
 u8 rsvd0;
 u8 rsvd1;
 u8 rfe_type;
 u8 ent_sz;
 __le32 num_ents;
 u8 content[1];
} __attribute__((__packed__));
struct __rtw89_fw_regd_element {
 u8 rsvd0;
 u8 rsvd1;
 u8 rsvd2;
 u8 ent_sz;
 __le32 num_ents;
 u8 content[1];
} __attribute__((__packed__));
enum rtw89_fw_txpwr_trk_type {
 __RTW89_FW_TXPWR_TRK_TYPE_6GHZ_START = 0,
 RTW89_FW_TXPWR_TRK_TYPE_6GB_N = 0,
 RTW89_FW_TXPWR_TRK_TYPE_6GB_P = 1,
 RTW89_FW_TXPWR_TRK_TYPE_6GA_N = 2,
 RTW89_FW_TXPWR_TRK_TYPE_6GA_P = 3,
 __RTW89_FW_TXPWR_TRK_TYPE_6GHZ_MAX = 3,

 __RTW89_FW_TXPWR_TRK_TYPE_5GHZ_START = 4,
 RTW89_FW_TXPWR_TRK_TYPE_5GB_N = 4,
 RTW89_FW_TXPWR_TRK_TYPE_5GB_P = 5,
 RTW89_FW_TXPWR_TRK_TYPE_5GA_N = 6,
 RTW89_FW_TXPWR_TRK_TYPE_5GA_P = 7,
 __RTW89_FW_TXPWR_TRK_TYPE_5GHZ_MAX = 7,

 __RTW89_FW_TXPWR_TRK_TYPE_2GHZ_START = 8,
 RTW89_FW_TXPWR_TRK_TYPE_2GB_N = 8,
 RTW89_FW_TXPWR_TRK_TYPE_2GB_P = 9,
 RTW89_FW_TXPWR_TRK_TYPE_2GA_N = 10,
 RTW89_FW_TXPWR_TRK_TYPE_2GA_P = 11,
 RTW89_FW_TXPWR_TRK_TYPE_2G_CCK_B_N = 12,
 RTW89_FW_TXPWR_TRK_TYPE_2G_CCK_B_P = 13,
 RTW89_FW_TXPWR_TRK_TYPE_2G_CCK_A_N = 14,
 RTW89_FW_TXPWR_TRK_TYPE_2G_CCK_A_P = 15,
 __RTW89_FW_TXPWR_TRK_TYPE_2GHZ_MAX = 15,

 RTW89_FW_TXPWR_TRK_TYPE_NR,
};
struct rtw89_fw_txpwr_track_cfg {
 const s8 (*delta[RTW89_FW_TXPWR_TRK_TYPE_NR])[30];
};
struct rtw89_fw_element_hdr {
 __le32 id;
 __le32 size;
 u8 ver[4];
 __le32 rsvd0;
 __le32 rsvd1;
 __le32 rsvd2;
 union {
  struct {
   u8 priv[8];
   u8 contents[1];
  } __attribute__((__packed__)) common;
  struct {
   u8 idx;
   u8 rsvd[7];
   struct {
    __le32 addr;
    __le32 data;
   } __attribute__((__packed__)) regs[1];
  } __attribute__((__packed__)) reg2;
  struct {
   u8 cv;
   u8 priv[7];
   u8 contents[1];
  } __attribute__((__packed__)) bbmcu;
  struct {
   __le32 bitmap;
   __le32 rsvd;
   s8 contents[1][30];
  } __attribute__((__packed__)) txpwr_trk;
  struct {
   u8 nr;
   u8 rsvd[3];
   u8 rfk_id;
   u8 rsvd1[3];
   __le16 offset[1];
  } __attribute__((__packed__)) rfk_log_fmt;
  struct {
   u8 rsvd[8];
   struct rtw89_phy_afe_info {
    __le32 action;
    __le32 cat;
    __le32 class;
    __le32 addr;
    __le32 mask;
    __le32 val;
   } __attribute__((__packed__)) infos[1];
  } __attribute__((__packed__)) afe;
  struct {
   __le32 rule_size;
   u8 rsvd[4];
   u8 rules_and_msgs[1];
  } __attribute__((__packed__)) diag_mac;
  struct __rtw89_fw_txpwr_element txpwr;
  struct __rtw89_fw_regd_element regd;
 } __attribute__((__packed__)) u;
} __attribute__((__packed__));
enum rtw89_mac_hwmod_sel {
 RTW89_DMAC_SEL = 0,
 RTW89_CMAC_SEL = 1,

 RTW89_MAC_INVALID,
};
enum rtw89_mac_fwd_target {
 RTW89_FWD_DONT_CARE = 0,
 RTW89_FWD_TO_HOST = 1,
 RTW89_FWD_TO_WLAN_CPU = 2
};
enum rtw89_machdr_frame_type {
 RTW89_MGNT = 0,
 RTW89_CTRL = 1,
 RTW89_DATA = 2,
};
struct rtw89_pwr_cfg {
 u16 addr;
 u8 cv_msk;
 u8 intf_msk;
 u8 base:4;
 u8 cmd:4;
 u8 msk;
 u8 val;
};
struct rtw89_mac_ax_plt {
 u8 band;
 u8 tx;
 u8 rx;
};
struct rtw89_cpuio_ctrl {
 u16 pkt_num;
 u16 start_pktid;
 u16 end_pktid;
 u8 cmd_type;
 u8 macid;
 u8 src_pid;
 u8 src_qid;
 u8 dst_pid;
 u8 dst_qid;
 u16 pktid;
};
enum mac_ax_err_info {



 MAC_AX_ERR_L0_ERR_CMAC0 = 0x0001,
 MAC_AX_ERR_L0_ERR_CMAC1 = 0x0002,
 MAC_AX_ERR_L0_RESET_DONE = 0x0003,
 MAC_AX_ERR_L0_PROMOTE_TO_L1 = 0x0010,


 MAC_AX_ERR_L1_PREERR_DMAC = 0x999,
 MAC_AX_ERR_L1_ERR_DMAC = 0x1000,
 MAC_AX_ERR_L1_RESET_DISABLE_DMAC_DONE = 0x1001,
 MAC_AX_ERR_L1_RESET_RECOVERY_DONE = 0x1002,
 MAC_AX_ERR_L1_PROMOTE_TO_L2 = 0x1010,
 MAC_AX_ERR_L1_RCVY_STOP_DONE = 0x1011,



 MAC_AX_ERR_L2_ERR_AH_DMA = 0x2000,
 MAC_AX_ERR_L2_ERR_AH_HCI = 0x2010,
 MAC_AX_ERR_L2_ERR_AH_RLX4081 = 0x2020,
 MAC_AX_ERR_L2_ERR_AH_IDDMA = 0x2030,
 MAC_AX_ERR_L2_ERR_AH_HIOE = 0x2040,
 MAC_AX_ERR_L2_ERR_AH_IPSEC = 0x2050,
 MAC_AX_ERR_L2_ERR_AH_RX4281 = 0x2060,
 MAC_AX_ERR_L2_ERR_AH_OTHERS = 0x2070,


 MAC_AX_ERR_L2_ERR_AHB_TO_DMA = 0x2100,
 MAC_AX_ERR_L2_ERR_AHB_TO_HCI = 0x2110,
 MAC_AX_ERR_L2_ERR_AHB_TO_RLX4081 = 0x2120,
 MAC_AX_ERR_L2_ERR_AHB_TO_IDDMA = 0x2130,
 MAC_AX_ERR_L2_ERR_AHB_TO_HIOE = 0x2140,
 MAC_AX_ERR_L2_ERR_AHB_TO_IPSEC = 0x2150,
 MAC_AX_ERR_L2_ERR_AHB_TO_RX4281 = 0x2160,
 MAC_AX_ERR_L2_ERR_AHB_TO_OTHERS = 0x2170,


 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_WVA = 0x2200,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_UART = 0x2201,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_CPULOCAL = 0x2202,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_AXIDMA = 0x2203,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_HIOE = 0x2204,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_IDDMA = 0x2205,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_IPSEC = 0x2206,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_WON = 0x2207,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_WDMAC = 0x2208,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_WCMAC = 0x2209,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_DMA_OTHERS = 0x220A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_WVA = 0x2210,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_UART = 0x2211,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_CPULOCAL = 0x2212,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_AXIDMA = 0x2213,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_HIOE = 0x2214,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_IDDMA = 0x2215,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_IPSEC = 0x2216,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_WDMAC = 0x2218,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_WCMAC = 0x2219,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HCI_OTHERS = 0x221A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_WVA = 0x2220,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_UART = 0x2221,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_CPULOCAL = 0x2222,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_AXIDMA = 0x2223,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_HIOE = 0x2224,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_IDDMA = 0x2225,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_IPSEC = 0x2226,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_WON = 0x2227,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_WDMAC = 0x2228,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_WCMAC = 0x2229,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RLX4081_OTHERS = 0x222A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_WVA = 0x2230,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_UART = 0x2231,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_CPULOCAL = 0x2232,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_AXIDMA = 0x2233,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_HIOE = 0x2234,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_IDDMA = 0x2235,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_IPSEC = 0x2236,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_WON = 0x2237,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_WDMAC = 0x2238,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_WCMAC = 0x2239,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IDDMA_OTHERS = 0x223A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_WVA = 0x2240,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_UART = 0x2241,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_CPULOCAL = 0x2242,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_AXIDMA = 0x2243,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_HIOE = 0x2244,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_IDDMA = 0x2245,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_IPSEC = 0x2246,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_WON = 0x2247,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_WDMAC = 0x2248,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_WCMAC = 0x2249,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_HIOE_OTHERS = 0x224A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_WVA = 0x2250,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_UART = 0x2251,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_CPULOCAL = 0x2252,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_AXIDMA = 0x2253,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_HIOE = 0x2254,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_IDDMA = 0x2255,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_IPSEC = 0x2256,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_WON = 0x2257,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_WDMAC = 0x2258,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_WCMAC = 0x2259,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_IPSEC_OTHERS = 0x225A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_WVA = 0x2260,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_UART = 0x2261,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_CPULOCAL = 0x2262,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_AXIDMA = 0x2263,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_HIOE = 0x2264,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_IDDMA = 0x2265,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_IPSEC = 0x2266,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_WON = 0x2267,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_WDMAC = 0x2268,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_WCMAC = 0x2269,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_RX4281_OTHERS = 0x226A,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_WVA = 0x2270,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_UART = 0x2271,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_CPULOCAL = 0x2272,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_AXIDMA = 0x2273,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_HIOE = 0x2274,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_IDDMA = 0x2275,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_IPSEC = 0x2276,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_WON = 0x2277,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_WDMAC = 0x2278,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_WCMAC = 0x2279,
 MAC_AX_ERR_L2_ERR_APB_SA_TO_OTHERS_OTHERS = 0x227A,


 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_DMA = 0x2300,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_HCI = 0x2310,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_RLX4081 = 0x2320,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_IDDMA = 0x2330,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_HIOE = 0x2340,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_IPSEC = 0x2350,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_RX4281 = 0x2360,
 MAC_AX_ERR_L2_ERR_APB_BBRF_TO_OTHERS = 0x2370,
 MAC_AX_ERR_L2_RESET_DONE = 0x2400,
 MAC_AX_ERR_L2_ERR_WDT_TIMEOUT_INT = 0x2599,
 MAC_AX_ERR_CPU_EXCEPTION = 0x3000,
 MAC_AX_ERR_ASSERTION = 0x4000,
 MAC_AX_ERR_RXI300 = 0x5000,
 MAC_AX_GET_ERR_MAX,
 MAC_AX_DUMP_SHAREBUFF_INDICATOR = 0x80000000,


 MAC_AX_ERR_L1_DISABLE_EN = 0x0001,
 MAC_AX_ERR_L1_RCVY_EN = 0x0002,
 MAC_AX_ERR_L1_RCVY_STOP_REQ = 0x0003,
 MAC_AX_ERR_L1_RCVY_START_REQ = 0x0004,
 MAC_AX_ERR_L1_RESET_START_DMAC = 0x000A,
 MAC_AX_ERR_L0_CFG_NOTIFY = 0x0010,
 MAC_AX_ERR_L0_CFG_DIS_NOTIFY = 0x0011,
 MAC_AX_ERR_L0_CFG_HANDSHAKE = 0x0012,
 MAC_AX_ERR_L0_RCVY_EN = 0x0013,
 MAC_AX_SET_ERR_MAX,
};
struct rtw89_mac_gen_def {
 u32 band1_offset;
 u32 filter_model_addr;
 u32 indir_access_addr;
 const u32 *mem_base_addrs;
 u32 mem_page_size;
 u32 rx_fltr;
 const struct rtw89_port_reg *port_base;
 u32 agg_len_ht;
 u32 ps_status;

 struct rtw89_reg_def muedca_ctrl;
 struct rtw89_reg_def bfee_ctrl;
 struct rtw89_reg_def narrow_bw_ru_dis;
 struct rtw89_reg_def wow_ctrl;
 struct rtw89_reg_def agg_limit;
 struct rtw89_reg_def txcnt_limit;

 int (*check_mac_en)(struct rtw89_dev *rtwdev, u8 band,
       enum rtw89_mac_hwmod_sel sel);
 int (*sys_init)(struct rtw89_dev *rtwdev);
 int (*trx_init)(struct rtw89_dev *rtwdev);
 void (*err_imr_ctrl)(struct rtw89_dev *rtwdev, bool en);
 void (*hci_func_en)(struct rtw89_dev *rtwdev);
 void (*dmac_func_pre_en)(struct rtw89_dev *rtwdev);
 void (*dle_func_en)(struct rtw89_dev *rtwdev, bool enable);
 void (*dle_clk_en)(struct rtw89_dev *rtwdev, bool enable);
 void (*bf_assoc)(struct rtw89_dev *rtwdev,
    struct rtw89_vif_link *rtwvif_link,
    struct rtw89_sta_link *rtwsta_link);

 int (*typ_fltr_opt)(struct rtw89_dev *rtwdev,
       enum rtw89_machdr_frame_type type,
       enum rtw89_mac_fwd_target fwd_target,
       u8 mac_idx);
 int (*cfg_ppdu_status)(struct rtw89_dev *rtwdev, u8 mac_idx, bool enable);
 void (*cfg_phy_rpt)(struct rtw89_dev *rtwdev, u8 mac_idx, bool enable);

 int (*dle_mix_cfg)(struct rtw89_dev *rtwdev, const struct rtw89_dle_mem *cfg);
 int (*chk_dle_rdy)(struct rtw89_dev *rtwdev, bool wde_or_ple);
 int (*dle_buf_req)(struct rtw89_dev *rtwdev, u16 buf_len, bool wd, u16 *pkt_id);
 void (*hfc_func_en)(struct rtw89_dev *rtwdev, bool en, bool h2c_en);
 void (*hfc_h2c_cfg)(struct rtw89_dev *rtwdev);
 void (*hfc_mix_cfg)(struct rtw89_dev *rtwdev);
 void (*hfc_get_mix_info)(struct rtw89_dev *rtwdev);
 void (*wde_quota_cfg)(struct rtw89_dev *rtwdev,
         const struct rtw89_wde_quota *min_cfg,
         const struct rtw89_wde_quota *max_cfg,
         u16 ext_wde_min_qt_wcpu);
 void (*ple_quota_cfg)(struct rtw89_dev *rtwdev,
         const struct rtw89_ple_quota *min_cfg,
         const struct rtw89_ple_quota *max_cfg);
 int (*set_cpuio)(struct rtw89_dev *rtwdev,
    struct rtw89_cpuio_ctrl *ctrl_para, bool wd);
 int (*dle_quota_change)(struct rtw89_dev *rtwdev, bool band1_en);

 void (*disable_cpu)(struct rtw89_dev *rtwdev);
 int (*fwdl_enable_wcpu)(struct rtw89_dev *rtwdev, u8 boot_reason,
    bool dlfw, bool include_bb);
 u8 (*fwdl_get_status)(struct rtw89_dev *rtwdev, enum rtw89_fwdl_check_type type);
 int (*fwdl_check_path_ready)(struct rtw89_dev *rtwdev, bool h2c_or_fwdl);
 void (*fwdl_secure_idmem_share_mode)(struct rtw89_dev *rtwdev, u8 mode);
 int (*parse_efuse_map)(struct rtw89_dev *rtwdev);
 int (*parse_phycap_map)(struct rtw89_dev *rtwdev);
 int (*cnv_efuse_state)(struct rtw89_dev *rtwdev, bool idle);
 int (*efuse_read_fw_secure)(struct rtw89_dev *rtwdev);

 int (*cfg_plt)(struct rtw89_dev *rtwdev, struct rtw89_mac_ax_plt *plt);
 u16 (*get_plt_cnt)(struct rtw89_dev *rtwdev, u8 band);

 bool (*get_txpwr_cr)(struct rtw89_dev *rtwdev,
        enum rtw89_phy_idx phy_idx,
        u32 reg_base, u32 *cr);

 int (*write_xtal_si)(struct rtw89_dev *rtwdev, u8 offset, u8 val, u8 mask);
 int (*read_xtal_si)(struct rtw89_dev *rtwdev, u8 offset, u8 *val);

 void (*dump_qta_lost)(struct rtw89_dev *rtwdev);
 void (*dump_err_status)(struct rtw89_dev *rtwdev,
    enum mac_ax_err_info err);

 bool (*is_txq_empty)(struct rtw89_dev *rtwdev);

 int (*prep_chan_list)(struct rtw89_dev *rtwdev,
         struct rtw89_vif_link *rtwvif_link);
 void (*free_chan_list)(struct rtw89_dev *rtwdev);
 int (*add_chan_list)(struct rtw89_dev *rtwdev,
        struct rtw89_vif_link *rtwvif_link);
 int (*add_chan_list_pno)(struct rtw89_dev *rtwdev,
     struct rtw89_vif_link *rtwvif_link);
 int (*scan_offload)(struct rtw89_dev *rtwdev,
       struct rtw89_scan_option *option,
       struct rtw89_vif_link *rtwvif_link,
       bool wowlan);

 int (*wow_config_mac)(struct rtw89_dev *rtwdev, bool enable_wow);
};
enum rtw89_phy_c2h_rfk_log_func {
 RTW89_PHY_C2H_RFK_LOG_FUNC_IQK = 0,
 RTW89_PHY_C2H_RFK_LOG_FUNC_DPK = 1,
 RTW89_PHY_C2H_RFK_LOG_FUNC_DACK = 2,
 RTW89_PHY_C2H_RFK_LOG_FUNC_RXDCK = 3,
 RTW89_PHY_C2H_RFK_LOG_FUNC_TSSI = 4,
 RTW89_PHY_C2H_RFK_LOG_FUNC_TXGAPK = 5,
 RTW89_PHY_C2H_RFK_LOG_FUNC_TAS_PWR = 9,

 RTW89_PHY_C2H_RFK_LOG_FUNC_NUM,
};
enum rtw89_tssi_bandedge_cfg {
 RTW89_TSSI_BANDEDGE_FLAT,
 RTW89_TSSI_BANDEDGE_LOW,
 RTW89_TSSI_BANDEDGE_MID,
 RTW89_TSSI_BANDEDGE_HIGH,

 RTW89_TSSI_CFG_NUM,
};
enum rtw89_tssi_sbw_idx {
 RTW89_TSSI_SBW20,
 RTW89_TSSI_SBW40_0,
 RTW89_TSSI_SBW40_1,
 RTW89_TSSI_SBW80_0,
 RTW89_TSSI_SBW80_1,
 RTW89_TSSI_SBW80_2,
 RTW89_TSSI_SBW80_3,
 RTW89_TSSI_SBW160_0,
 RTW89_TSSI_SBW160_1,
 RTW89_TSSI_SBW160_2,
 RTW89_TSSI_SBW160_3,
 RTW89_TSSI_SBW160_4,
 RTW89_TSSI_SBW160_5,
 RTW89_TSSI_SBW160_6,
 RTW89_TSSI_SBW160_7,

 RTW89_TSSI_SBW_NUM,
};
struct rtw89_phy_dig_gain_cfg {
 const struct rtw89_reg_def *table;
 u8 size;
};
struct rtw89_phy_dig_gain_table {
 const struct rtw89_phy_dig_gain_cfg *cfg_lna_g;
 const struct rtw89_phy_dig_gain_cfg *cfg_tia_g;
 const struct rtw89_phy_dig_gain_cfg *cfg_lna_a;
 const struct rtw89_phy_dig_gain_cfg *cfg_tia_a;
};
struct rtw89_phy_tssi_dbw_table {
 u32 data[RTW89_TSSI_CFG_NUM][RTW89_TSSI_SBW_NUM];
};
struct rtw89_ccx_regs {
 u32 setting_addr;
 u32 edcca_opt_mask;
 u32 measurement_trig_mask;
 u32 trig_opt_mask;
 u32 en_mask;
 u32 ifs_cnt_addr;
 u32 ifs_clm_period_mask;
 u32 ifs_clm_cnt_unit_mask;
 u32 ifs_clm_cnt_clear_mask;
 u32 ifs_collect_en_mask;
 u32 ifs_t1_addr;
 u32 ifs_t1_th_h_mask;
 u32 ifs_t1_en_mask;
 u32 ifs_t1_th_l_mask;
 u32 ifs_t2_addr;
 u32 ifs_t2_th_h_mask;
 u32 ifs_t2_en_mask;
 u32 ifs_t2_th_l_mask;
 u32 ifs_t3_addr;
 u32 ifs_t3_th_h_mask;
 u32 ifs_t3_en_mask;
 u32 ifs_t3_th_l_mask;
 u32 ifs_t4_addr;
 u32 ifs_t4_th_h_mask;
 u32 ifs_t4_en_mask;
 u32 ifs_t4_th_l_mask;
 u32 ifs_clm_tx_cnt_addr;
 u32 ifs_clm_edcca_excl_cca_fa_mask;
 u32 ifs_clm_tx_cnt_msk;
 u32 ifs_clm_cca_addr;
 u32 ifs_clm_ofdmcca_excl_fa_mask;
 u32 ifs_clm_cckcca_excl_fa_mask;
 u32 ifs_clm_fa_addr;
 u32 ifs_clm_ofdm_fa_mask;
 u32 ifs_clm_cck_fa_mask;
 u32 ifs_his_addr;
 u32 ifs_t4_his_mask;
 u32 ifs_t3_his_mask;
 u32 ifs_t2_his_mask;
 u32 ifs_t1_his_mask;
 u32 ifs_avg_l_addr;
 u32 ifs_t2_avg_mask;
 u32 ifs_t1_avg_mask;
 u32 ifs_avg_h_addr;
 u32 ifs_t4_avg_mask;
 u32 ifs_t3_avg_mask;
 u32 ifs_cca_l_addr;
 u32 ifs_t2_cca_mask;
 u32 ifs_t1_cca_mask;
 u32 ifs_cca_h_addr;
 u32 ifs_t4_cca_mask;
 u32 ifs_t3_cca_mask;
 u32 ifs_total_addr;
 u32 ifs_cnt_done_mask;
 u32 ifs_total_mask;
 u32 nhm;
 u32 nhm_ready;
 u32 nhm_config;
 u32 nhm_period_mask;
 u32 nhm_unit_mask;
 u32 nhm_include_cca_mask;
 u32 nhm_en_mask;
 u32 nhm_method;
 u32 nhm_pwr_method_msk;
};
struct rtw89_physts_regs {
 u32 setting_addr;
 u32 dis_trigger_fail_mask;
 u32 dis_trigger_brk_mask;
};
struct rtw89_cfo_regs {
 u32 comp;
 u32 weighting_mask;
 u32 comp_seg0;
 u32 valid_0_mask;
};
struct rtw89_phy_rfk_log_fmt {
 const struct rtw89_fw_element_hdr *elm[RTW89_PHY_C2H_RFK_LOG_FUNC_NUM];
};
struct rtw89_phy_gen_def {
 u32 cr_base;
 const struct rtw89_ccx_regs *ccx;
 const struct rtw89_physts_regs *physts;
 const struct rtw89_cfo_regs *cfo;
 u32 (*phy0_phy1_offset)(struct rtw89_dev *rtwdev, u32 addr);
 void (*config_bb_gain)(struct rtw89_dev *rtwdev,
          const struct rtw89_reg2_def *reg,
          enum rtw89_rf_path rf_path,
          void *extra_data);
 void (*preinit_rf_nctl)(struct rtw89_dev *rtwdev);
 void (*bb_wrap_init)(struct rtw89_dev *rtwdev);
 void (*ch_info_init)(struct rtw89_dev *rtwdev);

 void (*set_txpwr_byrate)(struct rtw89_dev *rtwdev,
     const struct rtw89_chan *chan,
     enum rtw89_phy_idx phy_idx);
 void (*set_txpwr_offset)(struct rtw89_dev *rtwdev,
     const struct rtw89_chan *chan,
     enum rtw89_phy_idx phy_idx);
 void (*set_txpwr_limit)(struct rtw89_dev *rtwdev,
    const struct rtw89_chan *chan,
    enum rtw89_phy_idx phy_idx);
 void (*set_txpwr_limit_ru)(struct rtw89_dev *rtwdev,
       const struct rtw89_chan *chan,
       enum rtw89_phy_idx phy_idx);
};
enum rtw89_rfk_flag {
 RTW89_RFK_F_WRF = 0,
 RTW89_RFK_F_WM = 1,
 RTW89_RFK_F_WS = 2,
 RTW89_RFK_F_WC = 3,
 RTW89_RFK_F_DELAY = 4,
 RTW89_RFK_F_NUM,
};
struct rtw89_rfk_tbl {
 const struct rtw89_reg5_def *defs;
 u32 size;
};
/*@ requires env->nhm_sum > 0; ensures \result <= ((u8)~0U); */

static u8 rtw89_nhm_weighted_avg(struct rtw89_dev *rtwdev, struct rtw89_bb_ctx *bb)
{
 struct rtw89_env_monitor_info *env = &bb->env_monitor;
 u8 nhm_weight[12];
 u32 nhm_weighted_sum = 0;
 u8 weight_zero;
 u8 i;

 if (env->nhm_sum == 0)
  return 0;

 weight_zero = ({ u16 __UNIQUE_ID_v_2104 = (env->nhm_th[0] - 2); u16 __UNIQUE_ID_l_2105 = (0); u16 __UNIQUE_ID_h_2106 = (((u8)~0U)); do { __attribute__((__noreturn__)) extern void __compiletime_assert_2107(void) ; if (!(!((__builtin_constant_p(__UNIQUE_ID_l_2105 > __UNIQUE_ID_h_2106) && (__UNIQUE_ID_l_2105 > __UNIQUE_ID_h_2106))))) __compiletime_assert_2107(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_2108(void) ; if (!(!(!(((((typeof(__UNIQUE_ID_v_2104))(-1)) < ( typeof(__UNIQUE_ID_v_2104))1) ? (2 + (__builtin_constant_p((long long)(__UNIQUE_ID_v_2104) >= 0) && ((long long)(__UNIQUE_ID_v_2104) >= 0))) : (1 + 2 * (sizeof(__UNIQUE_ID_v_2104) < 4))) & ((((typeof(__UNIQUE_ID_l_2105))(-1)) < ( typeof(__UNIQUE_ID_l_2105))1) ? (2 + (__builtin_constant_p((long long)(__UNIQUE_ID_l_2105) >= 0) && ((long long)(__UNIQUE_ID_l_2105) >= 0))) : (1 + 2 * (sizeof(__UNIQUE_ID_l_2105) < 4))) & ((((typeof(__UNIQUE_ID_h_2106))(-1)) < ( typeof(__UNIQUE_ID_h_2106))1) ? (2 + (__builtin_constant_p((long long)(__UNIQUE_ID_h_2106) >= 0) && ((long long)(__UNIQUE_ID_h_2106) >= 0))) : (1 + 2 * (sizeof(__UNIQUE_ID_h_2106) < 4))))))) __compiletime_assert_2108(); } while (0); ((__UNIQUE_ID_v_2104) >= (__UNIQUE_ID_h_2106) ? (__UNIQUE_ID_h_2106) : ((__UNIQUE_ID_v_2104) <= (__UNIQUE_ID_l_2105) ? (__UNIQUE_ID_l_2105) : (__UNIQUE_ID_v_2104))); });

 for (i = 0; i < 12; i++) {
  if (i == 0)
   nhm_weight[i] = weight_zero;
  else if (i == (12 - 1))
   nhm_weight[i] = env->nhm_th[i - 1] + 2;
  else
   nhm_weight[i] = (env->nhm_th[i - 1] + env->nhm_th[i]) / 2;
 }

 if (rtwdev->chip->chip_id == RTL8852A || rtwdev->chip->chip_id == RTL8852B ||
     rtwdev->chip->chip_id == RTL8852C) {
  if (env->nhm_th[11 - 1] == (109 << 1)) {
   nhm_weight[12 - 1] =
    env->nhm_th[11 - 2] +
    2;
   nhm_weight[12 - 2] =
    nhm_weight[12 - 1];
  }

  env->nhm_result[0] += env->nhm_result[12 - 1];
  env->nhm_result[12 - 1] = 0;
 }

 for (i = 0; i < 12; i++)
  nhm_weighted_sum += env->nhm_result[i] * nhm_weight[i];

 return (nhm_weighted_sum / env->nhm_sum) >> 1;
}
static const u8 igi_rssi_th[5] = {68, 84, 90, 98, 104};
static void
_rfk_write_rf(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def)
;
static void
_rfk_write32_mask(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def)
;
static void
_rfk_write32_set(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def)
;
static void
_rfk_write32_clr(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def)
;
static void
_rfk_delay(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def)
;
static void
(*_rfk_handler[])(struct rtw89_dev *rtwdev, const struct rtw89_reg5_def *def) = {
 [RTW89_RFK_F_WRF] = _rfk_write_rf,
 [RTW89_RFK_F_WM] = _rfk_write32_mask,
 [RTW89_RFK_F_WS] = _rfk_write32_set,
 [RTW89_RFK_F_WC] = _rfk_write32_clr,
 [RTW89_RFK_F_DELAY] = _rfk_delay,
};
_Static_assert((sizeof(_rfk_handler) / sizeof((_rfk_handler)[0]) + ((int)sizeof(struct {_Static_assert(!(!(!__builtin_types_compatible_p(typeof((_rfk_handler)), typeof(&(_rfk_handler)[0])))), "must be array");}))) == RTW89_RFK_F_NUM, "ARRAY_SIZE(_rfk_handler) == RTW89_RFK_F_NUM");
