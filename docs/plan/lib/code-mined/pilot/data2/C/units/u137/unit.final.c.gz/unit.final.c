typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __size_t;
typedef __uint32_t uint32_t;
typedef __size_t size_t;
typedef __vm_offset_t vm_offset_t;
struct gve_tx_fifo {
 vm_offset_t base;
 uint32_t size;
 volatile int available;
 uint32_t head;
};
/*@ requires fifo->head <= fifo->size; ensures (fifo->head + bytes < fifo->size) ? \result == 0 : \result == fifo->size - fifo->head; */

static int
gve_tx_fifo_pad_alloc_one_frag(struct gve_tx_fifo *fifo, size_t bytes)
{
 return (fifo->head + bytes < fifo->size) ? 0 : fifo->size - fifo->head;
}
