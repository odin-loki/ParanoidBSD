typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
enum fe_status {
 FE_NONE = 0x00,
 FE_HAS_SIGNAL = 0x01,
 FE_HAS_CARRIER = 0x02,
 FE_HAS_VITERBI = 0x04,
 FE_HAS_SYNC = 0x08,
 FE_HAS_LOCK = 0x10,
 FE_TIMEDOUT = 0x20,
 FE_REINIT = 0x40,
};
/*@ requires true; ensures (is_demod_locked != 0) ? \result == (FE_HAS_SIGNAL | FE_HAS_CARRIER | FE_HAS_VITERBI | FE_HAS_SYNC | FE_HAS_LOCK) : ((is_rf_locked != 0) ? \result == (FE_HAS_SIGNAL | FE_HAS_CARRIER) : \result == 0); */

static inline    int sms_to_status(u32 is_demod_locked, u32 is_rf_locked)
{
 if (is_demod_locked)
  return FE_HAS_SIGNAL | FE_HAS_CARRIER | FE_HAS_VITERBI |
         FE_HAS_SYNC | FE_HAS_LOCK;

 if (is_rf_locked)
  return FE_HAS_SIGNAL | FE_HAS_CARRIER;

 return 0;
}
