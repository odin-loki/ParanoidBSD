static inline uint8_t pcg_output_xsh_rr_16_8(uint16_t state)
;
struct pcg_state_16 {
    uint16_t state;
};
static inline void pcg_mcg_16_step_r(struct pcg_state_16* rng)
;
/*@ requires \valid_read(rng); ensures 0 <= \result <= 255; */

static inline uint8_t pcg_mcg_16_xsh_rr_8_random_r(struct pcg_state_16* rng)
{
    uint16_t oldstate = rng->state;
    pcg_mcg_16_step_r(rng);
    return pcg_output_xsh_rr_16_8(oldstate);
}
