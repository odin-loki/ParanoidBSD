typedef unsigned long __uint64_t;
typedef __uint64_t uint64_t;
struct cap_rights;
typedef struct cap_rights cap_rights_t;
typedef _Bool bool;
struct cap_rights {
 uint64_t cr_rights[0 + 2];
};
struct filedesc;
/*@ requires \valid_read(big) && \valid_read(little); ensures \result == ((big->cr_rights[0] & little->cr_rights[0]) == little->cr_rights[0] && (big->cr_rights[1] & little->cr_rights[1]) == little->cr_rights[1]); */

static inline bool
cap_rights_contains_transient(const cap_rights_t *big, const cap_rights_t *little)
{

        if (__builtin_expect(((big->cr_rights[0] & little->cr_rights[0]) == little->cr_rights[0] && (big->cr_rights[1] & little->cr_rights[1]) == little->cr_rights[1]), 1)

                                                                               )
                return (1);
        return (0);
}
struct filedesc;
const cap_rights_t *cap_rights(struct filedesc *fdp, int fd);
