typedef unsigned int __u32;
typedef __u32 u32;
typedef _Bool bool;
/*@ requires 0 <= quadlet <= 4294967295; ensures \result == ((quadlet / 4194304) % 2 == 1); */

static inline    bool phy_packet_phy_config_get_gap_count_optimization(u32 quadlet)
{
 return (quadlet & 0x00400000) >> 22;
}
