typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef __u16 __be16;
typedef __u32 __be32;
typedef __u64 __be64;
typedef __u32 __wsum;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s32 int32_t;
typedef u32 uint32_t;
typedef u64 uint64_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int slab_flags_t;
typedef unsigned int fmode_t;
typedef u64 phys_addr_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct net_device;
struct ib_device;
struct kernel_param;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
struct cacheline_padding {
 char x[1];
} ;
typedef __s64 time64_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
struct task_struct;
struct mm_struct;
static inline     u64 field_mask(u64 field)
;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct static_key;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct module;
struct task_struct;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct page;
struct vm_area_struct;
struct mm_struct;
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct optimistic_spin_queue {




 atomic_t tail;
};
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct inode;
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct task_struct;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct device;
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct user_namespace;
struct uid_gid_map;
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct mutex;
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
struct page;
struct kref {
 refcount_t refcount;
};
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct blocking_notifier_head {
 struct rw_semaphore rwsem;
 struct notifier_block *head;
};
struct raw_notifier_head {
 struct notifier_block *head;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;


 unsigned long last_holder;

};
extern void up(struct semaphore *sem);
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline     unsigned long 
copy_to_user(void *to, const void *from, unsigned long n)
;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct slab;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
struct fasync_struct {
 rwlock_t fa_lock;
 int magic;
 int fa_fd;
 struct fasync_struct *fa_next;
 struct file *fa_file;
 struct callback_head fa_rcu;
};
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
static inline    struct filename *getname(const char *name)
;
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct pglist_data;
struct file;
struct device;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct kobject;
static inline    unsigned long page_size(const struct page *page)
;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
struct sg_table;
typedef unsigned short __kernel_sa_family_t;
struct file;
struct pid;
struct cred;
struct socket;
struct sock;
struct sk_buff;
struct proto_accept_arg;
struct seq_file;
typedef __kernel_sa_family_t sa_family_t;
struct sockaddr {
 sa_family_t sa_family;
 union {
  char sa_data_min[14];
  struct { struct { } __empty_sa_data; char sa_data[1]; };
 };
};
struct sockaddr_unsized {
 __kernel_sa_family_t sa_family;
 char sa_data[1];
};
struct linger {
 int l_onoff;
 int l_linger;
};
struct msghdr {
 void *msg_name;
 int msg_namelen;

 int msg_inq;

 struct iov_iter msg_iter;






 union {
  void *msg_control;
  void *msg_control_user;
 };
 bool msg_control_is_user : 1;
 bool msg_get_inq : 1;
 unsigned int msg_flags;
 __kernel_size_t msg_controllen;
 struct kiocb *msg_iocb;
 struct ubuf_info *msg_ubuf;
 int (*sg_from_iter)(struct sk_buff *skb,
       struct iov_iter *from, size_t length);
};
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct in6_addr;
struct sk_buff;
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct vm_area_struct;
struct file;
struct cred;
struct file;
struct rhash_head {
 struct rhash_head *next;
};
struct bucket_table;
struct rhashtable_compare_arg {
 struct rhashtable *ht;
 const void *key;
};
typedef u32 (*rht_hashfn_t)(const void *data, u32 len, u32 seed);
typedef u32 (*rht_obj_hashfn_t)(const void *data, u32 len, u32 seed);
typedef int (*rht_obj_cmpfn_t)(struct rhashtable_compare_arg *arg,
          const void *obj);
struct rhashtable_params {
 u16 nelem_hint;
 u16 key_len;
 u16 key_offset;
 u16 head_offset;
 unsigned int max_size;
 u16 min_size;
 bool automatic_shrinking;
 rht_hashfn_t hashfn;
 rht_obj_hashfn_t obj_hashfn;
 rht_obj_cmpfn_t obj_cmpfn;
};
struct rhashtable {
 struct bucket_table *tbl;
 unsigned int key_len;
 unsigned int max_elems;
 struct rhashtable_params p;
 bool rhlist;
 struct work_struct run_work;
 struct mutex mutex;
 spinlock_t lock;
 atomic_t nelems;



};
struct task_struct;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
} sync_serial_settings;
typedef struct {
 unsigned int clock_rate;
 unsigned int clock_type;
 unsigned short loopback;
 unsigned int slot_map;
} te1_settings;
typedef struct {
 unsigned short encoding;
 unsigned short parity;
} raw_hdlc_proto;
typedef struct {
 unsigned int t391;
 unsigned int t392;
 unsigned int n391;
 unsigned int n392;
 unsigned int n393;
 unsigned short lmi;
 unsigned short dce;
} fr_proto;
typedef struct {
 unsigned int dlci;
} fr_proto_pvc;
typedef struct {
 unsigned int dlci;
 char master[16];
}fr_proto_pvc_info;
typedef struct {
    unsigned int interval;
    unsigned int timeout;
} cisco_proto;
typedef struct {
 unsigned short dce;
 unsigned int modulo;
 unsigned int window;
 unsigned int t1;
 unsigned int t2;
 unsigned int n2;
} x25_hdlc_proto;
struct ifmap {
 unsigned long mem_start;
 unsigned long mem_end;
 unsigned short base_addr;
 unsigned char irq;
 unsigned char dma;
 unsigned char port;

};
struct if_settings {
 unsigned int type;
 unsigned int size;
 union {

  raw_hdlc_proto *raw_hdlc;
  cisco_proto *cisco;
  fr_proto *fr;
  fr_proto_pvc *fr_pvc;
  fr_proto_pvc_info *fr_pvc_info;
  x25_hdlc_proto *x25;


  sync_serial_settings *sync;
  te1_settings *te1;
 } ifs_ifsu;
};
struct ifreq {
 union
 {
  char ifrn_name[16];
 } ifr_ifrn;

 union {
  struct sockaddr ifru_addr;
  struct sockaddr ifru_dstaddr;
  struct sockaddr ifru_broadaddr;
  struct sockaddr ifru_netmask;
  struct sockaddr ifru_hwaddr;
  short ifru_flags;
  int ifru_ivalue;
  int ifru_mtu;
  struct ifmap ifru_map;
  char ifru_slave[16];
  char ifru_newname[16];
  void * ifru_data;
  struct if_settings ifru_settings;
 } ifr_ifru;
};
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct sg_table {
 struct scatterlist *sgl;
 unsigned int nents;
 unsigned int orig_nents;
};
int sg_nents(struct scatterlist *sg);
typedef u64 netdev_features_t;
struct in6_addr {
 union {
  __u8 u6_addr8[16];

  __be16 u6_addr16[8];
  __be32 u6_addr32[4];

 } in6_u;


};
typedef struct {
 u64 key[2];
} siphash_key_t;
struct ethhdr {
 unsigned char h_dest[6];
 unsigned char h_source[6];
 __be16 h_proto;
} __attribute__((packed));
struct tc_stats {
 __u64 bytes;
 __u32 packets;
 __u32 drops;
 __u32 overlimits;

 __u32 bps;
 __u32 pps;
 __u32 qlen;
 __u32 backlog;
};
struct tc_sizespec {
 unsigned char cell_log;
 unsigned char size_log;
 short cell_align;
 int overhead;
 unsigned int linklayer;
 unsigned int mpu;
 unsigned int mtu;
 unsigned int tsize;
};
struct bpf_prog;
struct net;
struct sk_buff;
typedef u8 dscp_t;
struct flowi_tunnel {
 __be64 tun_id;
};
struct flowi_common {
 int flowic_oif;
 int flowic_iif;
 int flowic_l3mdev;
 __u32 flowic_mark;
 dscp_t flowic_dscp;
 __u8 flowic_scope;
 __u8 flowic_proto;
 __u8 flowic_flags;
 __u32 flowic_secid;
 kuid_t flowic_uid;
 __u32 flowic_multipath_hash;
 struct flowi_tunnel flowic_tun_key;
};
union flowi_uli {
 struct {
  __be16 dport;
  __be16 sport;
 } ports;

 struct {
  __u8 type;
  __u8 code;
 } icmpt;

 __be32 gre_key;

 struct {
  __u8 type;
 } mht;
};
struct flowi4 {
 struct flowi_common __fl_common;


 __be32 saddr;
 __be32 daddr;

 union flowi_uli uli;
} ;
struct flowi6 {
 struct flowi_common __fl_common;
 struct in6_addr daddr;
 struct in6_addr saddr;

 __be32 flowlabel;
 union flowi_uli uli;
 __u32 mp_hash;
} ;
struct flowi {
 union {
  struct flowi_common __fl_common;
  struct flowi4 ip4;
  struct flowi6 ip6;
 } u;
} ;
struct ip_conntrack_stat {
 unsigned int found;
 unsigned int invalid;
 unsigned int insert;
 unsigned int insert_failed;
 unsigned int clash_resolve;
 unsigned int drop;
 unsigned int early_drop;
 unsigned int error;
 unsigned int expect_new;
 unsigned int expect_create;
 unsigned int expect_delete;
 unsigned int search_restart;
 unsigned int chaintoolong;
};
struct net_device;
struct net_device;
struct scatterlist;
struct pipe_inode_info;
struct iov_iter;
struct napi_struct;
struct bpf_prog;
union bpf_attr;
struct skb_ext;
struct sk_buff_head {

 union { struct { struct sk_buff *next; struct sk_buff *prev; } ; struct sk_buff_list { struct sk_buff *next; struct sk_buff *prev; } list; }


  ;

 __u32 qlen;
 spinlock_t lock;
};
struct sk_buff;
struct skb_shared_hwtstamps {
 union {
  ktime_t hwtstamp;
  void *netdev_data;
 };
};
struct ubuf_info_ops {
 void (*complete)(struct sk_buff *, struct ubuf_info *,
    bool zerocopy_success);

 int (*link_skb)(struct sk_buff *skb, struct ubuf_info *uarg);
};
struct ubuf_info {
 const struct ubuf_info_ops *ops;
 refcount_t refcnt;
 u8 flags;
};
typedef unsigned int sk_buff_data_t;
struct sk_buff {
 union {
  struct {

   struct sk_buff *next;
   struct sk_buff *prev;

   union {
    struct net_device *dev;




    unsigned long dev_scratch;
   };
  };
  struct rb_node rbnode;
  struct list_head list;
  struct llist_node ll_node;
 };

 struct sock *sk;

 union {
  ktime_t tstamp;
  u64 skb_mstamp_ns;
 };






 char cb[48] ;

 union {
  struct {
   unsigned long _skb_refdst;
   void (*destructor)(struct sk_buff *skb);
  };
  struct list_head tcp_tsorted_anchor;

  unsigned long _sk_redir;

 };


 unsigned long _nfct;

 unsigned int len,
    data_len;
 __u16 mac_len,
    hdr_len;




 __u16 queue_mapping;








 __u8 __cloned_offset[1];

 __u8 cloned:1,
    nohdr:1,
    fclone:2,
    peeked:1,
    head_frag:1,
    pfmemalloc:1,
    pp_recycle:1;

 __u8 active_extensions;





 union { struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 ipvs_property:1; __u8 nf_trace:1; __u8 offload_fwd_mark:1; __u8 offload_l3_fwd_mark:1; __u8 redirected:1; __u8 from_ingress:1; __u8 nf_skip_egress:1; __u8 decrypted:1; __u8 slow_gro:1; __u8 csum_not_inet:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } ; struct { __u8 __pkt_type_offset[1]; __u8 pkt_type:3; __u8 ignore_df:1; __u8 dst_pending_confirm:1; __u8 ip_summed:2; __u8 ooo_okay:1; __u8 __mono_tc_offset[1]; __u8 tstamp_type:2; __u8 tc_at_ingress:1; __u8 tc_skip_classify:1; __u8 remcsum_offload:1; __u8 csum_complete_sw:1; __u8 csum_level:2; __u8 inner_protocol_type:1; __u8 l4_hash:1; __u8 sw_hash:1; __u8 wifi_acked_valid:1; __u8 wifi_acked:1; __u8 no_fcs:1; __u8 encapsulation:1; __u8 encap_hdr_csum:1; __u8 csum_valid:1; __u8 ndisc_nodetype:2; __u8 ipvs_property:1; __u8 nf_trace:1; __u8 offload_fwd_mark:1; __u8 offload_l3_fwd_mark:1; __u8 redirected:1; __u8 from_ingress:1; __u8 nf_skip_egress:1; __u8 decrypted:1; __u8 slow_gro:1; __u8 csum_not_inet:1; __u8 unreadable:1; __u8 tc_depth:2; __u16 tc_index; u16 alloc_cpu; union { __wsum csum; struct { __u16 csum_start; __u16 csum_offset; }; }; __u32 priority; int skb_iif; __u32 hash; union { u32 vlan_all; struct { __be16 vlan_proto; __u16 vlan_tci; }; }; union { unsigned int napi_id; unsigned int sender_cpu; }; __u32 secmark; union { __u32 mark; __u32 reserved_tailroom; }; union { __be16 inner_protocol; __u8 inner_ipproto; }; __u16 inner_transport_header; __u16 inner_network_header; __u16 inner_mac_header; __be16 protocol; __u16 transport_header; __u16 network_header; __u16 mac_header; } headers; }
  ;


 sk_buff_data_t tail;
 sk_buff_data_t end;
 unsigned char *head,
    *data;
 unsigned int truesize;
 refcount_t users;



 struct skb_ext *extensions;

};
enum skb_ext_id {

 SKB_EXT_BRIDGE_NF,


 SKB_EXT_SEC_PATH,


 TC_SKB_EXT,


 SKB_EXT_MPTCP,


 SKB_EXT_MCTP,


 SKB_EXT_PSP,

 SKB_EXT_NUM,
};
struct skb_ext {
 refcount_t refcnt;
 u8 offset[SKB_EXT_NUM];
 u8 chunks;
 char data[1] ;
};
struct page;
typedef struct {
 atomic_long_t a;
} local_t;
struct dql {

 unsigned int num_queued;
 unsigned int adj_limit;
 unsigned int last_obj_cnt;


 unsigned short stall_thrs;

 unsigned long history_head;

 unsigned long history[4];



 unsigned int limit ;
 unsigned int num_completed;

 unsigned int prev_ovlimit;
 unsigned int prev_num_queued;
 unsigned int prev_last_obj_cnt;

 unsigned int lowest_slack;
 unsigned long slack_start_time;


 unsigned int max_limit;
 unsigned int min_limit;
 unsigned int slack_hold_time;


 unsigned short stall_max;
 unsigned long last_reap;
 unsigned long stall_cnt;
};
struct ctl_table_header;
struct prot_inuse;
struct cpumask;
struct netns_core {

 struct ctl_table_header *sysctl_hdr;

 int sysctl_somaxconn;
 int sysctl_optmem_max;
 u8 sysctl_txrehash;
 u8 sysctl_tstamp_allow_data;


 struct prot_inuse *prot_inuse;



 struct cpumask *rps_default_mask;

};
enum
{
 IPSTATS_MIB_NUM = 0,

 IPSTATS_MIB_INPKTS,
 IPSTATS_MIB_INOCTETS,
 IPSTATS_MIB_INDELIVERS,
 IPSTATS_MIB_NOECTPKTS,
 IPSTATS_MIB_ECT1PKTS,
 IPSTATS_MIB_ECT0PKTS,
 IPSTATS_MIB_CEPKTS,
 IPSTATS_MIB_OUTREQUESTS,
 IPSTATS_MIB_OUTPKTS,
 IPSTATS_MIB_OUTOCTETS,
 IPSTATS_MIB_OUTFORWDATAGRAMS,

 IPSTATS_MIB_INHDRERRORS,
 IPSTATS_MIB_INTOOBIGERRORS,
 IPSTATS_MIB_INNOROUTES,
 IPSTATS_MIB_INADDRERRORS,
 IPSTATS_MIB_INUNKNOWNPROTOS,
 IPSTATS_MIB_INTRUNCATEDPKTS,
 IPSTATS_MIB_INDISCARDS,
 IPSTATS_MIB_OUTDISCARDS,
 IPSTATS_MIB_OUTNOROUTES,
 IPSTATS_MIB_REASMTIMEOUT,
 IPSTATS_MIB_REASMREQDS,
 IPSTATS_MIB_REASMOKS,
 IPSTATS_MIB_REASMFAILS,
 IPSTATS_MIB_FRAGOKS,
 IPSTATS_MIB_FRAGFAILS,
 IPSTATS_MIB_FRAGCREATES,
 IPSTATS_MIB_INMCASTPKTS,
 IPSTATS_MIB_OUTMCASTPKTS,
 IPSTATS_MIB_INBCASTPKTS,
 IPSTATS_MIB_OUTBCASTPKTS,
 IPSTATS_MIB_INMCASTOCTETS,
 IPSTATS_MIB_OUTMCASTOCTETS,
 IPSTATS_MIB_INBCASTOCTETS,
 IPSTATS_MIB_OUTBCASTOCTETS,
 IPSTATS_MIB_CSUMERRORS,
 IPSTATS_MIB_REASM_OVERLAPS,
 __IPSTATS_MIB_MAX
};
enum
{
 ICMP_MIB_NUM = 0,
 ICMP_MIB_INMSGS,
 ICMP_MIB_INERRORS,
 ICMP_MIB_INDESTUNREACHS,
 ICMP_MIB_INTIMEEXCDS,
 ICMP_MIB_INPARMPROBS,
 ICMP_MIB_INSRCQUENCHS,
 ICMP_MIB_INREDIRECTS,
 ICMP_MIB_INECHOS,
 ICMP_MIB_INECHOREPS,
 ICMP_MIB_INTIMESTAMPS,
 ICMP_MIB_INTIMESTAMPREPS,
 ICMP_MIB_INADDRMASKS,
 ICMP_MIB_INADDRMASKREPS,
 ICMP_MIB_OUTMSGS,
 ICMP_MIB_OUTERRORS,
 ICMP_MIB_OUTDESTUNREACHS,
 ICMP_MIB_OUTTIMEEXCDS,
 ICMP_MIB_OUTPARMPROBS,
 ICMP_MIB_OUTSRCQUENCHS,
 ICMP_MIB_OUTREDIRECTS,
 ICMP_MIB_OUTECHOS,
 ICMP_MIB_OUTECHOREPS,
 ICMP_MIB_OUTTIMESTAMPS,
 ICMP_MIB_OUTTIMESTAMPREPS,
 ICMP_MIB_OUTADDRMASKS,
 ICMP_MIB_OUTADDRMASKREPS,
 ICMP_MIB_CSUMERRORS,
 ICMP_MIB_RATELIMITGLOBAL,
 ICMP_MIB_RATELIMITHOST,
 __ICMP_MIB_MAX
};
enum
{
 ICMP6_MIB_NUM = 0,
 ICMP6_MIB_INMSGS,
 ICMP6_MIB_INERRORS,
 ICMP6_MIB_OUTMSGS,
 ICMP6_MIB_OUTERRORS,
 ICMP6_MIB_CSUMERRORS,
 ICMP6_MIB_RATELIMITHOST,
 __ICMP6_MIB_MAX
};
enum
{
 TCP_MIB_NUM = 0,
 TCP_MIB_RTOALGORITHM,
 TCP_MIB_RTOMIN,
 TCP_MIB_RTOMAX,
 TCP_MIB_MAXCONN,
 TCP_MIB_ACTIVEOPENS,
 TCP_MIB_PASSIVEOPENS,
 TCP_MIB_ATTEMPTFAILS,
 TCP_MIB_ESTABRESETS,
 TCP_MIB_CURRESTAB,
 TCP_MIB_INSEGS,
 TCP_MIB_OUTSEGS,
 TCP_MIB_RETRANSSEGS,
 TCP_MIB_INERRS,
 TCP_MIB_OUTRSTS,
 TCP_MIB_CSUMERRORS,
 __TCP_MIB_MAX
};
enum
{
 UDP_MIB_NUM = 0,
 UDP_MIB_INDATAGRAMS,
 UDP_MIB_NOPORTS,
 UDP_MIB_INERRORS,
 UDP_MIB_OUTDATAGRAMS,
 UDP_MIB_RCVBUFERRORS,
 UDP_MIB_SNDBUFERRORS,
 UDP_MIB_CSUMERRORS,
 UDP_MIB_IGNOREDMULTI,
 UDP_MIB_MEMERRORS,
 __UDP_MIB_MAX
};
enum
{
 LINUX_MIB_NUM = 0,
 LINUX_MIB_SYNCOOKIESSENT,
 LINUX_MIB_SYNCOOKIESRECV,
 LINUX_MIB_SYNCOOKIESFAILED,
 LINUX_MIB_EMBRYONICRSTS,
 LINUX_MIB_PRUNECALLED,
 LINUX_MIB_RCVPRUNED,
 LINUX_MIB_OFOPRUNED,
 LINUX_MIB_OUTOFWINDOWICMPS,
 LINUX_MIB_LOCKDROPPEDICMPS,
 LINUX_MIB_ARPFILTER,
 LINUX_MIB_TIMEWAITED,
 LINUX_MIB_TIMEWAITRECYCLED,
 LINUX_MIB_TIMEWAITKILLED,
 LINUX_MIB_PAWSACTIVEREJECTED,
 LINUX_MIB_PAWSESTABREJECTED,
 LINUX_MIB_BEYOND_WINDOW,
 LINUX_MIB_TSECRREJECTED,
 LINUX_MIB_PAWS_OLD_ACK,
 LINUX_MIB_PAWS_TW_REJECTED,
 LINUX_MIB_DELAYEDACKS,
 LINUX_MIB_DELAYEDACKLOCKED,
 LINUX_MIB_DELAYEDACKLOST,
 LINUX_MIB_LISTENOVERFLOWS,
 LINUX_MIB_LISTENDROPS,
 LINUX_MIB_TCPHPHITS,
 LINUX_MIB_TCPPUREACKS,
 LINUX_MIB_TCPHPACKS,
 LINUX_MIB_TCPRENORECOVERY,
 LINUX_MIB_TCPSACKRECOVERY,
 LINUX_MIB_TCPSACKRENEGING,
 LINUX_MIB_TCPSACKREORDER,
 LINUX_MIB_TCPRENOREORDER,
 LINUX_MIB_TCPTSREORDER,
 LINUX_MIB_TCPFULLUNDO,
 LINUX_MIB_TCPPARTIALUNDO,
 LINUX_MIB_TCPDSACKUNDO,
 LINUX_MIB_TCPLOSSUNDO,
 LINUX_MIB_TCPLOSTRETRANSMIT,
 LINUX_MIB_TCPRENOFAILURES,
 LINUX_MIB_TCPSACKFAILURES,
 LINUX_MIB_TCPLOSSFAILURES,
 LINUX_MIB_TCPFASTRETRANS,
 LINUX_MIB_TCPSLOWSTARTRETRANS,
 LINUX_MIB_TCPTIMEOUTS,
 LINUX_MIB_TCPLOSSPROBES,
 LINUX_MIB_TCPLOSSPROBERECOVERY,
 LINUX_MIB_TCPRENORECOVERYFAIL,
 LINUX_MIB_TCPSACKRECOVERYFAIL,
 LINUX_MIB_TCPRCVCOLLAPSED,
 LINUX_MIB_TCPDSACKOLDSENT,
 LINUX_MIB_TCPDSACKOFOSENT,
 LINUX_MIB_TCPDSACKRECV,
 LINUX_MIB_TCPDSACKOFORECV,
 LINUX_MIB_TCPABORTONDATA,
 LINUX_MIB_TCPABORTONCLOSE,
 LINUX_MIB_TCPABORTONMEMORY,
 LINUX_MIB_TCPABORTONTIMEOUT,
 LINUX_MIB_TCPABORTONLINGER,
 LINUX_MIB_TCPABORTFAILED,
 LINUX_MIB_TCPMEMORYPRESSURES,
 LINUX_MIB_TCPMEMORYPRESSURESCHRONO,
 LINUX_MIB_TCPSACKDISCARD,
 LINUX_MIB_TCPDSACKIGNOREDOLD,
 LINUX_MIB_TCPDSACKIGNOREDNOUNDO,
 LINUX_MIB_TCPSPURIOUSRTOS,
 LINUX_MIB_TCPMD5NOTFOUND,
 LINUX_MIB_TCPMD5UNEXPECTED,
 LINUX_MIB_TCPMD5FAILURE,
 LINUX_MIB_SACKSHIFTED,
 LINUX_MIB_SACKMERGED,
 LINUX_MIB_SACKSHIFTFALLBACK,
 LINUX_MIB_TCPBACKLOGDROP,
 LINUX_MIB_PFMEMALLOCDROP,
 LINUX_MIB_TCPMINTTLDROP,
 LINUX_MIB_TCPDEFERACCEPTDROP,
 LINUX_MIB_IPRPFILTER,
 LINUX_MIB_TCPTIMEWAITOVERFLOW,
 LINUX_MIB_TCPREQQFULLDOCOOKIES,
 LINUX_MIB_TCPREQQFULLDROP,
 LINUX_MIB_TCPRETRANSFAIL,
 LINUX_MIB_TCPRCVCOALESCE,
 LINUX_MIB_TCPBACKLOGCOALESCE,
 LINUX_MIB_TCPOFOQUEUE,
 LINUX_MIB_TCPOFODROP,
 LINUX_MIB_TCPOFOMERGE,
 LINUX_MIB_TCPCHALLENGEACK,
 LINUX_MIB_TCPSYNCHALLENGE,
 LINUX_MIB_TCPFASTOPENACTIVE,
 LINUX_MIB_TCPFASTOPENACTIVEFAIL,
 LINUX_MIB_TCPFASTOPENPASSIVE,
 LINUX_MIB_TCPFASTOPENPASSIVEFAIL,
 LINUX_MIB_TCPFASTOPENLISTENOVERFLOW,
 LINUX_MIB_TCPFASTOPENCOOKIEREQD,
 LINUX_MIB_TCPFASTOPENBLACKHOLE,
 LINUX_MIB_TCPSPURIOUS_RTX_HOSTQUEUES,
 LINUX_MIB_BUSYPOLLRXPACKETS,
 LINUX_MIB_TCPAUTOCORKING,
 LINUX_MIB_TCPFROMZEROWINDOWADV,
 LINUX_MIB_TCPTOZEROWINDOWADV,
 LINUX_MIB_TCPWANTZEROWINDOWADV,
 LINUX_MIB_TCPSYNRETRANS,
 LINUX_MIB_TCPORIGDATASENT,
 LINUX_MIB_TCPHYSTARTTRAINDETECT,
 LINUX_MIB_TCPHYSTARTTRAINCWND,
 LINUX_MIB_TCPHYSTARTDELAYDETECT,
 LINUX_MIB_TCPHYSTARTDELAYCWND,
 LINUX_MIB_TCPACKSKIPPEDSYNRECV,
 LINUX_MIB_TCPACKSKIPPEDPAWS,
 LINUX_MIB_TCPACKSKIPPEDSEQ,
 LINUX_MIB_TCPACKSKIPPEDFINWAIT2,
 LINUX_MIB_TCPACKSKIPPEDTIMEWAIT,
 LINUX_MIB_TCPACKSKIPPEDCHALLENGE,
 LINUX_MIB_TCPWINPROBE,
 LINUX_MIB_TCPKEEPALIVE,
 LINUX_MIB_TCPMTUPFAIL,
 LINUX_MIB_TCPMTUPSUCCESS,
 LINUX_MIB_TCPDELIVERED,
 LINUX_MIB_TCPDELIVEREDCE,
 LINUX_MIB_TCPACKCOMPRESSED,
 LINUX_MIB_TCPZEROWINDOWDROP,
 LINUX_MIB_TCPRCVQDROP,
 LINUX_MIB_TCPWQUEUETOOBIG,
 LINUX_MIB_TCPFASTOPENPASSIVEALTKEY,
 LINUX_MIB_TCPTIMEOUTREHASH,
 LINUX_MIB_TCPDUPLICATEDATAREHASH,
 LINUX_MIB_TCPDSACKRECVSEGS,
 LINUX_MIB_TCPDSACKIGNOREDDUBIOUS,
 LINUX_MIB_TCPMIGRATEREQSUCCESS,
 LINUX_MIB_TCPMIGRATEREQFAILURE,
 LINUX_MIB_TCPPLBREHASH,
 LINUX_MIB_TCPAOREQUIRED,
 LINUX_MIB_TCPAOBAD,
 LINUX_MIB_TCPAOKEYNOTFOUND,
 LINUX_MIB_TCPAOGOOD,
 LINUX_MIB_TCPAODROPPEDICMPS,
 __LINUX_MIB_MAX
};
enum
{
 LINUX_MIB_XFRMNUM = 0,
 LINUX_MIB_XFRMINERROR,
 LINUX_MIB_XFRMINBUFFERERROR,
 LINUX_MIB_XFRMINHDRERROR,
 LINUX_MIB_XFRMINNOSTATES,
 LINUX_MIB_XFRMINSTATEPROTOERROR,
 LINUX_MIB_XFRMINSTATEMODEERROR,
 LINUX_MIB_XFRMINSTATESEQERROR,
 LINUX_MIB_XFRMINSTATEEXPIRED,
 LINUX_MIB_XFRMINSTATEMISMATCH,
 LINUX_MIB_XFRMINSTATEINVALID,
 LINUX_MIB_XFRMINTMPLMISMATCH,
 LINUX_MIB_XFRMINNOPOLS,
 LINUX_MIB_XFRMINPOLBLOCK,
 LINUX_MIB_XFRMINPOLERROR,
 LINUX_MIB_XFRMOUTERROR,
 LINUX_MIB_XFRMOUTBUNDLEGENERROR,
 LINUX_MIB_XFRMOUTBUNDLECHECKERROR,
 LINUX_MIB_XFRMOUTNOSTATES,
 LINUX_MIB_XFRMOUTSTATEPROTOERROR,
 LINUX_MIB_XFRMOUTSTATEMODEERROR,
 LINUX_MIB_XFRMOUTSTATESEQERROR,
 LINUX_MIB_XFRMOUTSTATEEXPIRED,
 LINUX_MIB_XFRMOUTPOLBLOCK,
 LINUX_MIB_XFRMOUTPOLDEAD,
 LINUX_MIB_XFRMOUTPOLERROR,
 LINUX_MIB_XFRMFWDHDRERROR,
 LINUX_MIB_XFRMOUTSTATEINVALID,
 LINUX_MIB_XFRMACQUIREERROR,
 LINUX_MIB_XFRMOUTSTATEDIRERROR,
 LINUX_MIB_XFRMINSTATEDIRERROR,
 LINUX_MIB_XFRMINIPTFSERROR,
 LINUX_MIB_XFRMOUTNOQSPACE,
 __LINUX_MIB_XFRMMAX
};
enum
{
 LINUX_MIB_TLSNUM = 0,
 LINUX_MIB_TLSCURRTXSW,
 LINUX_MIB_TLSCURRRXSW,
 LINUX_MIB_TLSCURRTXDEVICE,
 LINUX_MIB_TLSCURRRXDEVICE,
 LINUX_MIB_TLSTXSW,
 LINUX_MIB_TLSRXSW,
 LINUX_MIB_TLSTXDEVICE,
 LINUX_MIB_TLSRXDEVICE,
 LINUX_MIB_TLSDECRYPTERROR,
 LINUX_MIB_TLSRXDEVICERESYNC,
 LINUX_MIB_TLSDECRYPTRETRY,
 LINUX_MIB_TLSRXNOPADVIOL,
 LINUX_MIB_TLSRXREKEYOK,
 LINUX_MIB_TLSRXREKEYERROR,
 LINUX_MIB_TLSTXREKEYOK,
 LINUX_MIB_TLSTXREKEYERROR,
 LINUX_MIB_TLSRXREKEYRECEIVED,
 __LINUX_MIB_TLSMAX
};
struct u64_stats_sync {



};
typedef struct {
 local_t a;
} local64_t;
typedef struct {
 local64_t v;
} u64_stats_t ;
struct ipstats_mib {

 u64 mibs[__IPSTATS_MIB_MAX];
 struct u64_stats_sync syncp;
};
struct icmp_mib {
 unsigned long mibs[__ICMP_MIB_MAX];
};
struct icmpmsg_mib {
 atomic_long_t mibs[512];
};
struct icmpv6_mib {
 unsigned long mibs[__ICMP6_MIB_MAX];
};
struct icmpv6_mib_device {
 atomic_long_t mibs[__ICMP6_MIB_MAX];
};
struct icmpv6msg_mib {
 atomic_long_t mibs[512];
};
struct icmpv6msg_mib_device {
 atomic_long_t mibs[512];
};
struct tcp_mib {
 unsigned long mibs[__TCP_MIB_MAX];
};
struct udp_mib {
 unsigned long mibs[__UDP_MIB_MAX];
};
struct linux_mib {
 unsigned long mibs[__LINUX_MIB_MAX];
};
struct linux_xfrm_mib {
 unsigned long mibs[__LINUX_MIB_XFRMMAX];
};
struct linux_tls_mib {
 unsigned long mibs[__LINUX_MIB_TLSMAX];
};
struct netns_mib {
 __typeof__(struct ipstats_mib) *ip_statistics;

 __typeof__(struct ipstats_mib) *ipv6_statistics;


 __typeof__(struct tcp_mib) *tcp_statistics;
 __typeof__(struct linux_mib) *net_statistics;

 __typeof__(struct udp_mib) *udp_statistics;

 __typeof__(struct udp_mib) *udp_stats_in6;



 __typeof__(struct linux_xfrm_mib) *xfrm_statistics;


 __typeof__(struct linux_tls_mib) *tls_statistics;


 __typeof__(struct mptcp_mib) *mptcp_statistics;


 __typeof__(struct udp_mib) *udplite_statistics;

 __typeof__(struct udp_mib) *udplite_stats_in6;


 __typeof__(struct icmp_mib) *icmp_statistics;
 __typeof__(struct icmpmsg_mib) *icmpmsg_statistics;

 __typeof__(struct icmpv6_mib) *icmpv6_statistics;
 __typeof__(struct icmpv6msg_mib) *icmpv6msg_statistics;
 struct proc_dir_entry *proc_net_devsnmp6;

};
struct unix_table {
 spinlock_t *locks;
 struct hlist_head *buckets;
};
struct ctl_table_header;
struct netns_unix {
 struct unix_table table;
 int sysctl_max_dgram_qlen;
 struct ctl_table_header *ctl;
};
struct netns_packet {
 struct mutex sklist_lock;
 struct hlist_head sklist;
};
struct fqdir {

 long high_thresh;
 long low_thresh;
 int timeout;
 int max_dist;
 struct inet_frags *f;
 struct net *net;
 bool dead;

 struct rhashtable rhashtable ;


 atomic_long_t mem ;
 struct work_struct destroy_work;
 struct llist_node free_list;
};
struct frag_v4_compare_key {
 __be32 saddr;
 __be32 daddr;
 u32 user;
 u32 vif;
 __be16 id;
 u16 protocol;
};
struct frag_v6_compare_key {
 struct in6_addr saddr;
 struct in6_addr daddr;
 u32 user;
 __be32 id;
 u32 iif;
};
struct inet_frag_queue {
 struct rhash_head node;
 union {
  struct frag_v4_compare_key v4;
  struct frag_v6_compare_key v6;
 } key;
 struct timer_list timer;
 spinlock_t lock;
 refcount_t refcnt;
 struct rb_root rb_fragments;
 struct sk_buff *fragments_tail;
 struct sk_buff *last_run_head;
 ktime_t stamp;
 int len;
 int meat;
 u8 tstamp_type;
 __u8 flags;
 u16 max_size;
 struct fqdir *fqdir;
 struct callback_head rcu;
};
struct inet_frags {
 unsigned int qsize;

 void (*constructor)(struct inet_frag_queue *q,
            const void *arg);
 void (*destructor)(struct inet_frag_queue *);
 void (*frag_expire)(struct timer_list *t);
 struct kmem_cache *frags_cachep;
 const char *frags_cache_name;
 struct rhashtable_params rhash_params;
 refcount_t refcnt;
 struct completion completion;
};
struct ctl_table_header;
struct ipv4_devconf;
struct fib_rules_ops;
struct hlist_head;
struct fib_table;
struct sock;
struct local_ports {
 u32 range;
 bool warned;
};
struct ping_group_range {
 seqlock_t lock;
 kgid_t range[2];
};
struct inet_hashinfo;
struct inet_timewait_death_row {
 refcount_t tw_refcount;


 struct inet_hashinfo *hashinfo ;
 int sysctl_max_tw_buckets;
};
struct tcp_fastopen_context;
struct sysctl_fib_multipath_hash_seed {
 u32 user_seed;
 u32 mp_seed;
};
struct udp_tunnel_gro {
 struct sock *sk;
 struct hlist_head list;
};
struct netns_ipv4 {






 __u8 __cacheline_group_begin__netns_ipv4_read_tx[1];
 u8 sysctl_tcp_early_retrans;
 u8 sysctl_tcp_tso_win_divisor;
 u8 sysctl_tcp_tso_rtt_log;
 u8 sysctl_tcp_autocorking;
 int sysctl_tcp_min_snd_mss;
 unsigned int sysctl_tcp_notsent_lowat;
 int sysctl_tcp_limit_output_bytes;
 int sysctl_tcp_min_rtt_wlen;
 int sysctl_tcp_wmem[3];
 u8 sysctl_ip_fwd_use_pmtu;
 __u8 __cacheline_group_end__netns_ipv4_read_tx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_txrx[1];
 u8 sysctl_tcp_moderate_rcvbuf;
 __u8 __cacheline_group_end__netns_ipv4_read_txrx[1];


 __u8 __cacheline_group_begin__netns_ipv4_read_rx[1];
 u8 sysctl_ip_early_demux;
 u8 sysctl_tcp_early_demux;
 u8 sysctl_tcp_l3mdev_accept;

 int sysctl_tcp_reordering;
 int sysctl_tcp_rmem[3];
 __u8 __cacheline_group_end__netns_ipv4_read_rx[1];


 __u8 __cacheline_group_begin__icmp[1] ;
 atomic_t icmp_global_credit;
 u32 icmp_global_stamp;
 __u8 __cacheline_group_end__icmp[1] ; struct { } __cacheline_group_pad__icmp ;

 struct inet_timewait_death_row tcp_death_row;
 struct udp_table *udp_table;



 struct udp_tunnel_gro udp_tunnel_gro[2];



 struct ctl_table_header *forw_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *ipv4_hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *xfrm4_hdr;

 struct ipv4_devconf *devconf_all;
 struct ipv4_devconf *devconf_dflt;
 struct ip_ra_chain *ra_chain;
 struct mutex ra_mutex;

 struct fib_rules_ops *rules_ops;
 struct fib_table *fib_main;
 struct fib_table *fib_default;
 unsigned int fib_rules_require_fldissect;
 bool fib_has_custom_rules;

 bool fib_has_custom_local_routes;
 bool fib_offload_disabled;
 u8 sysctl_tcp_shrink_window;

 atomic_t fib_num_tclassid_users;

 struct hlist_head *fib_table_hash;
 struct sock *fibnl;
 struct hlist_head *fib_info_hash;
 unsigned int fib_info_hash_bits;
 unsigned int fib_info_cnt;

 struct sock *mc_autojoin_sk;

 struct inet_peer_base *peers;
 struct fqdir *fqdir;

 u8 sysctl_icmp_echo_ignore_all;
 u8 sysctl_icmp_echo_enable_probe;
 u8 sysctl_icmp_echo_ignore_broadcasts;
 u8 sysctl_icmp_ignore_bogus_error_responses;
 u8 sysctl_icmp_errors_use_inbound_ifaddr;
 int sysctl_icmp_ratelimit;
 int sysctl_icmp_ratemask;
 int sysctl_icmp_msgs_per_sec;
 int sysctl_icmp_msgs_burst;

 u32 ip_rt_min_pmtu;
 int ip_rt_mtu_expires;
 int ip_rt_min_advmss;

 struct local_ports ip_local_ports;

 u8 sysctl_tcp_ecn;
 u8 sysctl_tcp_ecn_option;
 u8 sysctl_tcp_ecn_option_beacon;
 u8 sysctl_tcp_ecn_fallback;

 u8 sysctl_ip_default_ttl;
 u8 sysctl_ip_no_pmtu_disc;
 u8 sysctl_ip_fwd_update_priority;
 u8 sysctl_ip_nonlocal_bind;
 u8 sysctl_ip_autobind_reuse;

 u8 sysctl_ip_dynaddr;

 u8 sysctl_raw_l3mdev_accept;

 u8 sysctl_udp_early_demux;

 u8 sysctl_nexthop_compat_mode;

 u8 sysctl_fwmark_reflect;
 u8 sysctl_tcp_fwmark_accept;
 u8 sysctl_tcp_mtu_probing;
 int sysctl_tcp_mtu_probe_floor;
 int sysctl_tcp_base_mss;
 int sysctl_tcp_probe_threshold;
 u32 sysctl_tcp_probe_interval;

 int sysctl_tcp_keepalive_time;
 int sysctl_tcp_keepalive_intvl;
 u8 sysctl_tcp_keepalive_probes;

 u8 sysctl_tcp_syn_retries;
 u8 sysctl_tcp_synack_retries;
 u8 sysctl_tcp_syncookies;
 u8 sysctl_tcp_migrate_req;
 u8 sysctl_tcp_comp_sack_nr;
 u8 sysctl_tcp_backlog_ack_defer;
 u8 sysctl_tcp_pingpong_thresh;

 u8 sysctl_tcp_retries1;
 u8 sysctl_tcp_retries2;
 u8 sysctl_tcp_orphan_retries;
 u8 sysctl_tcp_tw_reuse;
 unsigned int sysctl_tcp_tw_reuse_delay;
 int sysctl_tcp_fin_timeout;
 u8 sysctl_tcp_sack;
 u8 sysctl_tcp_window_scaling;
 u8 sysctl_tcp_timestamps;
 int sysctl_tcp_rto_min_us;
 int sysctl_tcp_rto_max_ms;
 u8 sysctl_tcp_recovery;
 u8 sysctl_tcp_thin_linear_timeouts;
 u8 sysctl_tcp_slow_start_after_idle;
 u8 sysctl_tcp_retrans_collapse;
 u8 sysctl_tcp_stdurg;
 u8 sysctl_tcp_rfc1337;
 u8 sysctl_tcp_abort_on_overflow;
 u8 sysctl_tcp_fack;
 int sysctl_tcp_max_reordering;
 int sysctl_tcp_adv_win_scale;
 u8 sysctl_tcp_dsack;
 u8 sysctl_tcp_app_win;
 u8 sysctl_tcp_frto;
 u8 sysctl_tcp_nometrics_save;
 u8 sysctl_tcp_no_ssthresh_metrics_save;
 u8 sysctl_tcp_workaround_signed_windows;
 int sysctl_tcp_challenge_ack_limit;
 u8 sysctl_tcp_min_tso_segs;
 u8 sysctl_tcp_reflect_tos;
 int sysctl_tcp_invalid_ratelimit;
 int sysctl_tcp_pacing_ss_ratio;
 int sysctl_tcp_pacing_ca_ratio;
 unsigned int sysctl_tcp_child_ehash_entries;
 unsigned long sysctl_tcp_comp_sack_delay_ns;
 unsigned long sysctl_tcp_comp_sack_slack_ns;
 int sysctl_max_syn_backlog;
 int sysctl_tcp_fastopen;
 const struct tcp_congestion_ops *tcp_congestion_control;
 struct tcp_fastopen_context *tcp_fastopen_ctx;
 unsigned int sysctl_tcp_fastopen_blackhole_timeout;
 atomic_t tfo_active_disable_times;
 unsigned long tfo_active_disable_stamp;
 u32 tcp_challenge_timestamp;
 u32 tcp_challenge_count;
 u8 sysctl_tcp_plb_enabled;
 u8 sysctl_tcp_plb_idle_rehash_rounds;
 u8 sysctl_tcp_plb_rehash_rounds;
 u8 sysctl_tcp_plb_suspend_rto_sec;
 int sysctl_tcp_plb_cong_thresh;

 int sysctl_udp_wmem_min;
 int sysctl_udp_rmem_min;

 u8 sysctl_fib_notify_on_flag_change;
 u8 sysctl_tcp_syn_linear_timeouts;


 u8 sysctl_udp_l3mdev_accept;


 u8 sysctl_igmp_llm_reports;
 int sysctl_igmp_max_memberships;
 int sysctl_igmp_max_msf;
 int sysctl_igmp_qrv;

 struct ping_group_range ping_group_range;
 u16 ping_port_rover;

 atomic_t dev_addr_genid;

 unsigned int sysctl_udp_child_hash_entries;


 unsigned long *sysctl_local_reserved_ports;
 int sysctl_ip_prot_sock;






 struct list_head mr_tables;
 struct fib_rules_ops *mr_rules_ops;



 struct sysctl_fib_multipath_hash_seed sysctl_fib_multipath_hash_seed;
 u32 sysctl_fib_multipath_hash_fields;
 u8 sysctl_fib_multipath_use_neigh;
 u8 sysctl_fib_multipath_hash_policy;


 struct fib_notifier_ops *notifier_ops;
 unsigned int fib_seq;

 struct fib_notifier_ops *ipmr_notifier_ops;
 unsigned int ipmr_seq;

 atomic_t rt_genid;
 siphash_key_t ip_id_key;
 struct hlist_head *inet_addr_lst;
 struct delayed_work addr_chk_work;
};
struct dst_entry;
struct kmem_cachep;
struct net_device;
struct sk_buff;
struct sock;
struct net;
struct dst_ops {
 unsigned short family;
 unsigned int gc_thresh;

 void (*gc)(struct dst_ops *ops);
 struct dst_entry * (*check)(struct dst_entry *, __u32 cookie);
 unsigned int (*default_advmss)(const struct dst_entry *);
 unsigned int (*mtu)(const struct dst_entry *);
 u32 * (*cow_metrics)(struct dst_entry *, unsigned long);
 void (*destroy)(struct dst_entry *);
 void (*ifdown)(struct dst_entry *,
       struct net_device *dev);
 void (*negative_advice)(struct sock *sk, struct dst_entry *);
 void (*link_failure)(struct sk_buff *);
 void (*update_pmtu)(struct dst_entry *dst, struct sock *sk,
            struct sk_buff *skb, u32 mtu,
            bool confirm_neigh);
 void (*redirect)(struct dst_entry *dst, struct sock *sk,
         struct sk_buff *skb);
 int (*local_out)(struct net *net, struct sock *sk, struct sk_buff *skb);
 struct neighbour * (*neigh_lookup)(const struct dst_entry *dst,
      struct sk_buff *skb,
      const void *daddr);
 void (*confirm_neigh)(const struct dst_entry *dst,
       const void *daddr);

 struct kmem_cache *kmem_cachep;

 struct percpu_counter pcpuc_entries ;
};
struct ctl_table_header;
struct netns_sysctl_ipv6 {

 struct ctl_table_header *hdr;
 struct ctl_table_header *route_hdr;
 struct ctl_table_header *icmp_hdr;
 struct ctl_table_header *frags_hdr;
 struct ctl_table_header *xfrm6_hdr;

 int flush_delay;
 int ip6_rt_max_size;
 int ip6_rt_gc_min_interval;
 int ip6_rt_gc_timeout;
 int ip6_rt_gc_interval;
 int ip6_rt_gc_elasticity;
 int ip6_rt_mtu_expires;
 int ip6_rt_min_advmss;
 u32 multipath_hash_fields;
 u8 multipath_hash_policy;
 u8 bindv6only;
 u8 flowlabel_consistency;
 u8 auto_flowlabels;
 int icmpv6_time;
 u8 icmpv6_echo_ignore_all;
 u8 icmpv6_echo_ignore_multicast;
 u8 icmpv6_echo_ignore_anycast;
 unsigned long icmpv6_ratemask[(((255 + 1) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long *icmpv6_ratemask_ptr;
 u8 anycast_src_echo_reply;
 u8 ip_nonlocal_bind;
 u8 fwmark_reflect;
 u8 flowlabel_state_ranges;
 int idgen_retries;
 int idgen_delay;
 int flowlabel_reflect;
 int max_dst_opts_cnt;
 int max_hbh_opts_cnt;
 int max_dst_opts_len;
 int max_hbh_opts_len;
 int seg6_flowlabel;
 u32 ioam6_id;
 u64 ioam6_id_wide;
 u8 skip_notify_on_dev_down;
 u8 fib_notify_on_flag_change;
 u8 icmpv6_error_anycast_as_unicast;
};
struct netns_ipv6 {

 struct dst_ops ip6_dst_ops;

 struct netns_sysctl_ipv6 sysctl;
 struct ipv6_devconf *devconf_all;
 struct ipv6_devconf *devconf_dflt;
 struct inet_peer_base *peers;
 struct fqdir *fqdir;
 struct fib6_info *fib6_null_entry;
 struct rt6_info *ip6_null_entry;
 struct rt6_statistics *rt6_stats;
 struct timer_list ip6_fib_timer;
 struct hlist_head *fib_table_hash;
 spinlock_t fib_table_hash_lock;
 struct fib6_table *fib6_main_tbl;
 struct list_head fib6_walkers;
 rwlock_t fib6_walker_lock;
 spinlock_t fib6_gc_lock;
 atomic_t ip6_rt_gc_expire;
 unsigned long ip6_rt_last_gc;
 unsigned char flowlabel_has_excl;

 bool fib6_has_custom_rules;
 unsigned int fib6_rules_require_fldissect;

 unsigned int fib6_routes_require_src;

 struct rt6_info *ip6_prohibit_entry;
 struct rt6_info *ip6_blk_hole_entry;
 struct fib6_table *fib6_local_tbl;
 struct fib_rules_ops *fib6_rules_ops;

 struct sock *ndisc_sk;
 struct sock *tcp_sk;
 struct sock *igmp_sk;
 struct sock *mc_autojoin_sk;

 struct hlist_head *inet6_addr_lst;
 spinlock_t addrconf_hash_lock;
 struct delayed_work addr_chk_work;





 struct list_head mr6_tables;
 struct fib_rules_ops *mr6_rules_ops;


 atomic_t dev_addr_genid;
 atomic_t fib6_sernum;
 struct seg6_pernet_data *seg6_data;
 struct fib_notifier_ops *notifier_ops;
 struct fib_notifier_ops *ip6mr_notifier_ops;
 unsigned int ipmr_seq;
 struct {
  struct hlist_head head;
  spinlock_t lock;
  u32 seq;
 } ip6addrlbl_table;
 struct ioam6_pernet_data *ioam6_data;
};
struct netns_nexthop {
 struct rb_root rb_root;
 struct hlist_head *devhash;

 unsigned int seq;
 u32 last_id_allocated;
 struct blocking_notifier_head notifier_chain;
};
struct netns_sysctl_lowpan {

 struct ctl_table_header *frags_hdr;

};
struct netns_ieee802154_lowpan {
 struct netns_sysctl_lowpan sysctl;
 struct fqdir *fqdir;
};
struct sock;
struct proc_dir_entry;
struct sctp_mib;
struct ctl_table_header;
struct netns_sctp {
 __typeof__(struct sctp_mib) *sctp_statistics;


 struct proc_dir_entry *proc_net_sctp;


 struct ctl_table_header *sysctl_header;





 struct sock *ctl_sock;


 struct sock *udp4_sock;
 struct sock *udp6_sock;

 int udp_port;

 int encap_port;







 struct list_head local_addr_list;
 struct list_head addr_waitq;
 struct timer_list addr_wq_timer;
 struct list_head auto_asconf_splist;

 spinlock_t addr_wq_lock;


 spinlock_t local_addr_lock;
 unsigned int rto_initial;
 unsigned int rto_min;
 unsigned int rto_max;




 int rto_alpha;
 int rto_beta;


 int max_burst;


 int cookie_preserve_enable;


 int cookie_auth_enable;


 unsigned int valid_cookie_life;


 unsigned int sack_timeout;


 unsigned int hb_interval;


 unsigned int probe_interval;





 int max_retrans_association;
 int max_retrans_path;
 int max_retrans_init;




 int pf_retrans;





 int ps_retrans;






 int pf_enable;







 int pf_expose;






 int sndbuf_policy;






 int rcvbuf_policy;

 int default_auto_asconf;


 int addip_enable;
 int addip_noauth;


 int prsctp_enable;


 int reconf_enable;


 int auth_enable;


 int intl_enable;


 int ecn_enable;
 int scope_policy;




 int rwnd_upd_shift;


 unsigned long max_autoclose;


 int l3mdev_accept;

};
enum nf_inet_hooks {
 NF_INET_PRE_ROUTING,
 NF_INET_LOCAL_IN,
 NF_INET_FORWARD,
 NF_INET_LOCAL_OUT,
 NF_INET_POST_ROUTING,
 NF_INET_NUMHOOKS,
 NF_INET_INGRESS = NF_INET_NUMHOOKS,
};
enum {
 NFPROTO_UNSPEC = 0,
 NFPROTO_INET = 1,
 NFPROTO_IPV4 = 2,
 NFPROTO_ARP = 3,
 NFPROTO_NETDEV = 5,
 NFPROTO_BRIDGE = 7,
 NFPROTO_IPV6 = 10,



 NFPROTO_NUMPROTO,
};
struct proc_dir_entry;
struct nf_logger;
struct netns_nf {

 struct proc_dir_entry *proc_netfilter;

 const struct nf_logger *nf_loggers[NFPROTO_NUMPROTO];

 struct ctl_table_header *nf_log_dir_header;

 struct ctl_table_header *nf_lwtnl_dir_header;


 struct nf_hook_entries *hooks_ipv4[NF_INET_NUMHOOKS];
 struct nf_hook_entries *hooks_ipv6[NF_INET_NUMHOOKS];

 struct nf_hook_entries *hooks_arp[3];


 struct nf_hook_entries *hooks_bridge[NF_INET_NUMHOOKS];


 unsigned int defrag_ipv4_users;


 unsigned int defrag_ipv6_users;

};
enum tcp_conntrack {
 TCP_CONNTRACK_NONE,
 TCP_CONNTRACK_SYN_SENT,
 TCP_CONNTRACK_SYN_RECV,
 TCP_CONNTRACK_ESTABLISHED,
 TCP_CONNTRACK_FIN_WAIT,
 TCP_CONNTRACK_CLOSE_WAIT,
 TCP_CONNTRACK_LAST_ACK,
 TCP_CONNTRACK_TIME_WAIT,
 TCP_CONNTRACK_CLOSE,
 TCP_CONNTRACK_LISTEN,
 TCP_CONNTRACK_MAX,
 TCP_CONNTRACK_IGNORE,
 TCP_CONNTRACK_RETRANS,
 TCP_CONNTRACK_UNACK,
 TCP_CONNTRACK_TIMEOUT_MAX
};
enum sctp_conntrack {
 SCTP_CONNTRACK_NONE,
 SCTP_CONNTRACK_CLOSED,
 SCTP_CONNTRACK_COOKIE_WAIT,
 SCTP_CONNTRACK_COOKIE_ECHOED,
 SCTP_CONNTRACK_ESTABLISHED,
 SCTP_CONNTRACK_SHUTDOWN_SENT,
 SCTP_CONNTRACK_SHUTDOWN_RECD,
 SCTP_CONNTRACK_SHUTDOWN_ACK_SENT,
 SCTP_CONNTRACK_HEARTBEAT_SENT,
 SCTP_CONNTRACK_HEARTBEAT_ACKED,
 SCTP_CONNTRACK_MAX
};
struct ctl_table_header;
struct nf_generic_net {
 unsigned int timeout;
};
struct nf_tcp_net {
 unsigned int timeouts[TCP_CONNTRACK_TIMEOUT_MAX];
 u8 tcp_loose;
 u8 tcp_be_liberal;
 u8 tcp_max_retrans;
 u8 tcp_ignore_invalid_rst;

 unsigned int offload_timeout;

};
enum udp_conntrack {
 UDP_CT_UNREPLIED,
 UDP_CT_REPLIED,
 UDP_CT_MAX
};
struct nf_udp_net {
 unsigned int timeouts[UDP_CT_MAX];

 unsigned int offload_timeout;

};
struct nf_icmp_net {
 unsigned int timeout;
};
struct nf_sctp_net {
 unsigned int timeouts[SCTP_CONNTRACK_MAX];
};
enum gre_conntrack {
 GRE_CT_UNREPLIED,
 GRE_CT_REPLIED,
 GRE_CT_MAX
};
struct nf_gre_net {
 struct list_head keymap_list;
 unsigned int timeouts[GRE_CT_MAX];
};
struct nf_ip_net {
 struct nf_generic_net generic;
 struct nf_tcp_net tcp;
 struct nf_udp_net udp;
 struct nf_icmp_net icmp;
 struct nf_icmp_net icmpv6;

 struct nf_sctp_net sctp;


 struct nf_gre_net gre;

};
struct netns_ct {

 bool ecache_dwork_pending;

 u8 sysctl_log_invalid;
 u8 sysctl_events;
 u8 sysctl_acct;
 u8 sysctl_tstamp;
 u8 sysctl_checksum;

 struct ip_conntrack_stat *stat;
 struct nf_ct_event_notifier *nf_conntrack_event_cb;
 struct nf_ip_net nf_ct_proto;

 atomic_t labels_used;

};
struct nf_flow_table_stat {
 unsigned int count_wq_add;
 unsigned int count_wq_del;
 unsigned int count_wq_stats;
};
struct netns_ft {
 struct nf_flow_table_stat *stat;
};
struct netns_nftables {
 unsigned int base_seq;
 u8 gencursor;
};
typedef union {
 __be32 a4;
 __be32 a6[4];
 struct in6_addr in6;
} xfrm_address_t;
struct xfrm_id {
 xfrm_address_t daddr;
 __be32 spi;
 __u8 proto;
};
struct xfrm_sec_ctx {
 __u8 ctx_doi;
 __u8 ctx_alg;
 __u16 ctx_len;
 __u32 ctx_sid;
 char ctx_str[1] ;
};
struct xfrm_selector {
 xfrm_address_t daddr;
 xfrm_address_t saddr;
 __be16 dport;
 __be16 dport_mask;
 __be16 sport;
 __be16 sport_mask;
 __u16 family;
 __u8 prefixlen_d;
 __u8 prefixlen_s;
 __u8 proto;
 int ifindex;
 __kernel_uid32_t user;
};
struct xfrm_lifetime_cfg {
 __u64 soft_byte_limit;
 __u64 hard_byte_limit;
 __u64 soft_packet_limit;
 __u64 hard_packet_limit;
 __u64 soft_add_expires_seconds;
 __u64 hard_add_expires_seconds;
 __u64 soft_use_expires_seconds;
 __u64 hard_use_expires_seconds;
};
struct xfrm_lifetime_cur {
 __u64 bytes;
 __u64 packets;
 __u64 add_time;
 __u64 use_time;
};
struct xfrm_replay_state {
 __u32 oseq;
 __u32 seq;
 __u32 bitmap;
};
struct xfrm_replay_state_esn {
 unsigned int bmp_len;
 __u32 oseq;
 __u32 seq;
 __u32 oseq_hi;
 __u32 seq_hi;
 __u32 replay_window;
 __u32 bmp[1];
};
struct xfrm_algo {
 char alg_name[64];
 unsigned int alg_key_len;
 char alg_key[1];
};
struct xfrm_algo_auth {
 char alg_name[64];
 unsigned int alg_key_len;
 unsigned int alg_trunc_len;
 char alg_key[1];
};
struct xfrm_algo_aead {
 char alg_name[64];
 unsigned int alg_key_len;
 unsigned int alg_icv_len;
 char alg_key[1];
};
struct xfrm_stats {
 __u32 replay_window;
 __u32 replay;
 __u32 integrity_failed;
};
enum {
 XFRM_POLICY_IN = 0,
 XFRM_POLICY_OUT = 1,
 XFRM_POLICY_FWD = 2,
 XFRM_POLICY_MASK = 3,
 XFRM_POLICY_MAX = 3
};
struct xfrm_encap_tmpl {
 __u16 encap_type;
 __be16 encap_sport;
 __be16 encap_dport;
 xfrm_address_t encap_oa;
};
struct xfrm_mark {
 __u32 v;
 __u32 m;
};
struct xfrm_address_filter {
 xfrm_address_t saddr;
 xfrm_address_t daddr;
 __u16 family;
 __u8 splen;
 __u8 dplen;
};
struct ctl_table_header;
struct xfrm_policy_hash {
 struct hlist_head *table;
 unsigned int hmask;
 u8 dbits4;
 u8 sbits4;
 u8 dbits6;
 u8 sbits6;
};
struct xfrm_policy_hthresh {
 struct work_struct work;
 seqlock_t lock;
 u8 lbits4;
 u8 rbits4;
 u8 lbits6;
 u8 rbits6;
};
struct netns_xfrm {
 struct list_head state_all;
 struct hlist_head *state_bydst;
 struct hlist_head *state_bysrc;
 struct hlist_head *state_byspi;
 struct hlist_head *state_byseq;
 struct hlist_head *state_cache_input;
 unsigned int state_hmask;
 unsigned int state_num;
 struct work_struct state_hash_work;

 struct list_head policy_all;
 struct hlist_head *policy_byidx;
 unsigned int policy_idx_hmask;
 unsigned int idx_generator;
 struct xfrm_policy_hash policy_bydst[XFRM_POLICY_MAX];
 unsigned int policy_count[XFRM_POLICY_MAX * 2];
 struct work_struct policy_hash_work;
 struct xfrm_policy_hthresh policy_hthresh;
 struct list_head inexact_bins;


 struct sock *nlsk;
 struct sock *nlsk_stash;

 u32 sysctl_aevent_etime;
 u32 sysctl_aevent_rseqth;
 int sysctl_larval_drop;
 u32 sysctl_acq_expires;

 u8 policy_default[XFRM_POLICY_MAX];


 struct ctl_table_header *sysctl_hdr;


 struct dst_ops xfrm4_dst_ops;

 struct dst_ops xfrm6_dst_ops;

 spinlock_t xfrm_state_lock;
 seqcount_spinlock_t xfrm_state_hash_generation;
 seqcount_spinlock_t xfrm_policy_hash_generation;

 spinlock_t xfrm_policy_lock;
 struct mutex xfrm_cfg_mutex;
 struct delayed_work nat_keepalive_work;
};
struct mpls_route;
struct ctl_table_header;
struct netns_mpls {
 int ip_ttl_propagate;
 int default_ttl;
 size_t platform_labels;
 struct mpls_route * *platform_label;

 struct ctl_table_header *ctl;
};
struct can_dev_rcv_lists;
struct can_pkg_stats;
struct can_rcv_lists_stats;
struct netns_can {

 struct proc_dir_entry *proc_dir;
 struct proc_dir_entry *pde_stats;
 struct proc_dir_entry *pde_reset_stats;
 struct proc_dir_entry *pde_rcvlist_all;
 struct proc_dir_entry *pde_rcvlist_fil;
 struct proc_dir_entry *pde_rcvlist_inv;
 struct proc_dir_entry *pde_rcvlist_sff;
 struct proc_dir_entry *pde_rcvlist_eff;
 struct proc_dir_entry *pde_rcvlist_err;
 struct proc_dir_entry *bcmproc_dir;



 struct can_dev_rcv_lists *rx_alldev_list;
 spinlock_t rcvlists_lock;
 struct timer_list stattimer;
 struct can_pkg_stats *pkg_stats;
 struct can_rcv_lists_stats *rcv_lists_stats;


 struct hlist_head cgw_list;
};
struct netns_xdp {
 struct mutex lock;
 struct hlist_head list;
};
struct smc_stats_rsn;
struct smc_stats;
struct netns_smc {

 struct smc_stats *smc_stats;

 struct mutex mutex_fback_rsn;
 struct smc_stats_rsn *fback_rsn;

 bool limit_smc_hs;

 struct ctl_table_header *smc_hdr;

 unsigned int sysctl_autocorking_size;
 unsigned int sysctl_smcr_buf_type;
 int sysctl_smcr_testlink_time;
 int sysctl_wmem;
 int sysctl_rmem;
 int sysctl_max_links_per_lgr;
 int sysctl_max_conns_per_lgr;
};
struct bpf_prog;
struct bpf_prog_array;
enum netns_bpf_attach_type {
 NETNS_BPF_INVALID = -1,
 NETNS_BPF_FLOW_DISSECTOR = 0,
 NETNS_BPF_SK_LOOKUP,
 MAX_NETNS_BPF_ATTACH_TYPE
};
struct netns_bpf {

 struct bpf_prog_array *run_array[MAX_NETNS_BPF_ATTACH_TYPE];
 struct bpf_prog *progs[MAX_NETNS_BPF_ATTACH_TYPE];
 struct list_head links[MAX_NETNS_BPF_ATTACH_TYPE];
};
struct netns_mctp {

 struct list_head routes;







 struct mutex bind_lock;
 struct hlist_head binds[1 << (7)];




 spinlock_t keys_lock;
 struct hlist_head keys;


 unsigned int default_net;


 struct mutex neigh_lock;
 struct list_head neighbours;
};
struct ref_tracker;
struct ref_tracker_dir {

 spinlock_t lock;
 unsigned int quarantine_avail;
 refcount_t untracked;
 refcount_t no_tracker;
 bool dead;
 struct list_head list;
 struct list_head quarantine;
 const char *class;

};
typedef struct ref_tracker *netdevice_tracker;
typedef struct ref_tracker *netns_tracker;
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct user_namespace;
struct proc_dir_entry;
struct net_device;
struct sock;
struct ctl_table_header;
struct net_generic;
struct uevent_sock;
struct netns_ipvs;
struct bpf_prog;
struct net {



 refcount_t passive;


 spinlock_t rules_mod_lock;

 unsigned int dev_base_seq;
 u32 ifindex;

 spinlock_t nsid_lock;
 atomic_t fnhe_genid;

 struct list_head list;
 struct list_head exit_list;





 struct llist_node defer_free_list;
 struct llist_node cleanup_list;

 struct list_head ptype_all;
 struct list_head ptype_specific;


 struct key_tag *key_domain;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct idr netns_ids;

 struct ns_common ns;
 struct ref_tracker_dir refcnt_tracker;
 struct ref_tracker_dir notrefcnt_tracker;


 struct list_head dev_base_head;
 struct proc_dir_entry *proc_net;
 struct proc_dir_entry *proc_net_stat;


 struct ctl_table_set sysctls;


 struct sock *rtnl;
 struct sock *genl_sock;

 struct uevent_sock *uevent_sock;

 struct hlist_head *dev_name_head;
 struct hlist_head *dev_index_head;
 struct xarray dev_by_index;
 struct raw_notifier_head netdev_chain;




 u32 hash_mix;

 struct net_device *loopback_dev;


 struct list_head rules_ops;

 struct netns_core core;
 struct netns_mib mib;
 struct netns_packet packet;

 struct netns_unix unx;

 struct netns_nexthop nexthop;
 struct netns_ipv4 ipv4;

 struct netns_ipv6 ipv6;


 struct netns_ieee802154_lowpan ieee802154_lowpan;


 struct netns_sctp sctp;


 struct netns_nf nf;

 struct netns_ct ct;


 struct netns_nftables nft;


 struct netns_ft ft;



 struct sk_buff_head wext_nlevents;

 struct net_generic *gen;


 struct netns_bpf bpf;



 struct netns_xfrm xfrm;


 u64 net_cookie;


 struct netns_ipvs *ipvs;


 struct netns_mpls mpls;


 struct netns_can can;


 struct netns_xdp xdp;


 struct netns_mctp mctp;


 struct sock *crypto_nlsk;

 struct sock *diag_nlsk;

 struct netns_smc smc;



 struct mutex rtnl_mutex;

} ;
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct net;
typedef struct {

 struct net *net;

} possible_net_t;
struct ctl_table;
static inline    int fnhe_genid(const struct net *net)
;
struct ieee_ets {
 __u8 willing;
 __u8 ets_cap;
 __u8 cbs;
 __u8 tc_tx_bw[8];
 __u8 tc_rx_bw[8];
 __u8 tc_tsa[8];
 __u8 prio_tc[8];
 __u8 tc_reco_bw[8];
 __u8 tc_reco_tsa[8];
 __u8 reco_prio_tc[8];
};
struct ieee_maxrate {
 __u64 tc_maxrate[8];
};
struct ieee_qcn {
 __u8 rpg_enable[8];
 __u32 rppp_max_rps[8];
 __u32 rpg_time_reset[8];
 __u32 rpg_byte_reset[8];
 __u32 rpg_threshold[8];
 __u32 rpg_max_rate[8];
 __u32 rpg_ai_rate[8];
 __u32 rpg_hai_rate[8];
 __u32 rpg_gd[8];
 __u32 rpg_min_dec_fac[8];
 __u32 rpg_min_rate[8];
 __u32 cndd_state_machine[8];
};
struct ieee_qcn_stats {
 __u64 rppp_rp_centiseconds[8];
 __u32 rppp_created_rps[8];
};
struct ieee_pfc {
 __u8 pfc_cap;
 __u8 pfc_en;
 __u8 mbc;
 __u16 delay;
 __u64 requests[8];
 __u64 indications[8];
};
struct dcbnl_buffer {

 __u8 prio2buffer[8];

 __u32 buffer_size[8];
 __u32 total_size;
};
struct cee_pg {
 __u8 willing;
 __u8 error;
 __u8 pg_en;
 __u8 tcs_supported;
 __u8 pg_bw[8];
 __u8 prio_pg[8];
};
struct cee_pfc {
 __u8 willing;
 __u8 error;
 __u8 pfc_en;
 __u8 tcs_supported;
};
struct dcb_app {
 __u8 selector;
 __u8 priority;
 __u16 protocol;
};
struct dcb_peer_app_info {
 __u8 willing;
 __u8 error;
};
struct net_device;
struct dcbnl_rtnl_ops {

 int (*ieee_getets) (struct net_device *, struct ieee_ets *);
 int (*ieee_setets) (struct net_device *, struct ieee_ets *);
 int (*ieee_getmaxrate) (struct net_device *, struct ieee_maxrate *);
 int (*ieee_setmaxrate) (struct net_device *, struct ieee_maxrate *);
 int (*ieee_getqcn) (struct net_device *, struct ieee_qcn *);
 int (*ieee_setqcn) (struct net_device *, struct ieee_qcn *);
 int (*ieee_getqcnstats) (struct net_device *, struct ieee_qcn_stats *);
 int (*ieee_getpfc) (struct net_device *, struct ieee_pfc *);
 int (*ieee_setpfc) (struct net_device *, struct ieee_pfc *);
 int (*ieee_getapp) (struct net_device *, struct dcb_app *);
 int (*ieee_setapp) (struct net_device *, struct dcb_app *);
 int (*ieee_delapp) (struct net_device *, struct dcb_app *);
 int (*ieee_peer_getets) (struct net_device *, struct ieee_ets *);
 int (*ieee_peer_getpfc) (struct net_device *, struct ieee_pfc *);


 u8 (*getstate)(struct net_device *);
 u8 (*setstate)(struct net_device *, u8);
 void (*getpermhwaddr)(struct net_device *, u8 *);
 void (*setpgtccfgtx)(struct net_device *, int, u8, u8, u8, u8);
 void (*setpgbwgcfgtx)(struct net_device *, int, u8);
 void (*setpgtccfgrx)(struct net_device *, int, u8, u8, u8, u8);
 void (*setpgbwgcfgrx)(struct net_device *, int, u8);
 void (*getpgtccfgtx)(struct net_device *, int, u8 *, u8 *, u8 *, u8 *);
 void (*getpgbwgcfgtx)(struct net_device *, int, u8 *);
 void (*getpgtccfgrx)(struct net_device *, int, u8 *, u8 *, u8 *, u8 *);
 void (*getpgbwgcfgrx)(struct net_device *, int, u8 *);
 void (*setpfccfg)(struct net_device *, int, u8);
 void (*getpfccfg)(struct net_device *, int, u8 *);
 u8 (*setall)(struct net_device *);
 u8 (*getcap)(struct net_device *, int, u8 *);
 int (*getnumtcs)(struct net_device *, int, u8 *);
 int (*setnumtcs)(struct net_device *, int, u8);
 u8 (*getpfcstate)(struct net_device *);
 void (*setpfcstate)(struct net_device *, u8);
 void (*getbcncfg)(struct net_device *, int, u32 *);
 void (*setbcncfg)(struct net_device *, int, u32);
 void (*getbcnrp)(struct net_device *, int, u8 *);
 void (*setbcnrp)(struct net_device *, int, u8);
 int (*setapp)(struct net_device *, u8, u16, u8);
 int (*getapp)(struct net_device *, u8, u16);
 u8 (*getfeatcfg)(struct net_device *, int, u8 *);
 u8 (*setfeatcfg)(struct net_device *, int, u8);


 u8 (*getdcbx)(struct net_device *);
 u8 (*setdcbx)(struct net_device *, u8);


 int (*peer_getappinfo)(struct net_device *, struct dcb_peer_app_info *,
          u16 *);
 int (*peer_getapptable)(struct net_device *, struct dcb_app *);


 int (*cee_peer_getpg) (struct net_device *, struct cee_pg *);
 int (*cee_peer_getpfc) (struct net_device *, struct cee_pfc *);


 int (*dcbnl_getbuffer)(struct net_device *, struct dcbnl_buffer *);
 int (*dcbnl_setbuffer)(struct net_device *, struct dcbnl_buffer *);


 int (*dcbnl_setapptrust)(struct net_device *, u8 *, int);
 int (*dcbnl_getapptrust)(struct net_device *, u8 *, int *);


 int (*dcbnl_setrewr)(struct net_device *dev, struct dcb_app *app);
 int (*dcbnl_delrewr)(struct net_device *dev, struct dcb_app *app);
};
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
extern char _data[], _sdata[], _edata[];
struct device;
struct irq_affinity_notify {
 unsigned int irq;
 struct kref kref;
 struct work_struct work;
 void (*notify)(struct irq_affinity_notify *, const cpumask_t *mask);
 void (*release)(struct kref *ref);
};
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct tasklet_struct
{
 struct tasklet_struct *next;
 unsigned long state;
 atomic_t count;
 bool use_callback;
 union {
  void (*func)(unsigned long data);
  void (*callback)(struct tasklet_struct *t);
 };
 unsigned long data;
};
struct seq_file;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct sock_cgroup_data {
 struct cgroup *cgroup;

 u32 classid;


 u16 prioidx;

};
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
static inline    u64 cgroup_id(const struct cgroup *cgrp)
;
void css_rstat_flush(struct cgroup_subsys_state *css);
struct netprio_map {
 struct callback_head rcu;
 u32 priomap_len;
 u32 priomap[1];
};
typedef struct {
 union {
  void *kernel;
  void *user;
 };
 bool is_kernel : 1;
} sockptr_t;
typedef enum {
 SS_FREE = 0,
 SS_UNCONNECTED,
 SS_CONNECTING,
 SS_CONNECTED,
 SS_DISCONNECTING
} socket_state;
struct poll_table_struct;
struct pipe_inode_info;
struct inode;
struct file;
struct net;
struct socket_wq {

 wait_queue_head_t wait;
 struct fasync_struct *fasync_list;
 unsigned long flags;
 struct callback_head rcu;
} ;
struct socket {
 socket_state state;

 short type;

 unsigned long flags;

 struct file *file;
 struct sock *sk;
 const struct proto_ops *ops;

 struct socket_wq wq;
};
typedef struct {
 size_t written;
 size_t count;
 union {
  char *buf;
  void *data;
 } arg;
 int error;
} read_descriptor_t;
struct vm_area_struct;
struct page;
struct sockaddr;
struct msghdr;
struct module;
struct sk_buff;
struct proto_accept_arg;
typedef int (*sk_read_actor_t)(read_descriptor_t *, struct sk_buff *,
          unsigned int, size_t);
typedef int (*skb_read_actor_t)(struct sock *, struct sk_buff *);
struct proto_ops {
 int family;
 struct module *owner;
 int (*release) (struct socket *sock);
 int (*bind) (struct socket *sock,
          struct sockaddr_unsized *myaddr,
          int sockaddr_len);
 int (*connect) (struct socket *sock,
          struct sockaddr *vaddr,
          int sockaddr_len, int flags);
 int (*socketpair)(struct socket *sock1,
          struct socket *sock2);
 int (*accept) (struct socket *sock,
          struct socket *newsock,
          struct proto_accept_arg *arg);
 int (*getname) (struct socket *sock,
          struct sockaddr *addr,
          int peer);
 __poll_t (*poll) (struct file *file, struct socket *sock,
          struct poll_table_struct *wait);
 int (*ioctl) (struct socket *sock, unsigned int cmd,
          unsigned long arg);

 int (*compat_ioctl) (struct socket *sock, unsigned int cmd,
          unsigned long arg);

 int (*gettstamp) (struct socket *sock, void *userstamp,
          bool timeval, bool time32);
 int (*listen) (struct socket *sock, int len);
 int (*shutdown) (struct socket *sock, int flags);
 int (*setsockopt)(struct socket *sock, int level,
          int optname, sockptr_t optval,
          unsigned int optlen);
 int (*getsockopt)(struct socket *sock, int level,
          int optname, char *optval, int *optlen);
 void (*show_fdinfo)(struct seq_file *m, struct socket *sock);
 int (*sendmsg) (struct socket *sock, struct msghdr *m,
          size_t total_len);
 int (*recvmsg) (struct socket *sock, struct msghdr *m,
          size_t total_len, int flags);
 int (*mmap) (struct file *file, struct socket *sock,
          struct vm_area_struct * vma);
 ssize_t (*splice_read)(struct socket *sock, loff_t *ppos,
           struct pipe_inode_info *pipe, size_t len, unsigned int flags);
 void (*splice_eof)(struct socket *sock);
 int (*set_peek_off)(struct sock *sk, int val);
 int (*peek_len)(struct socket *sock);




 int (*read_sock)(struct sock *sk, read_descriptor_t *desc,
         sk_read_actor_t recv_actor);

 int (*read_skb)(struct sock *sk, skb_read_actor_t recv_actor);
 int (*sendmsg_locked)(struct sock *sk, struct msghdr *msg,
       size_t size);
 int (*set_rcvlowat)(struct sock *sk, int val);
};
struct iovec;
struct kvec;
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct fd {
 unsigned long word;
};
struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};
struct bpf_cgroup_storage_key {
 __u64 cgroup_inode_id;
 __u32 attach_type;
};
enum bpf_cgroup_iter_order {
 BPF_CGROUP_ITER_ORDER_UNSPEC = 0,
 BPF_CGROUP_ITER_SELF_ONLY,
 BPF_CGROUP_ITER_DESCENDANTS_PRE,
 BPF_CGROUP_ITER_DESCENDANTS_POST,
 BPF_CGROUP_ITER_ANCESTORS_UP,
};
enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 __MAX_BPF_MAP_TYPE
};
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};
enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 __MAX_BPF_ATTACH_TYPE
};
enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};
union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64  excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64  key;
  union {
   __u64  value;
   __u64  next_key;
  };
  __u64 flags;
 };

 struct {
  __u64  in_batch;


  __u64  out_batch;
  __u64  keys;
  __u64  values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64  insns;
  __u64  license;
  __u32 log_level;
  __u32 log_size;
  __u64  log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64  func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64  line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64  fd_array;
  __u64  core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
  __u32 fd_array_cnt;



  __u64  signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64  pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64  data_in;
  __u64  data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64  ctx_in;
  __u64  ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64  info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64  prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64  prog_attach_flags;
  __u64  link_ids;
  __u64  link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64  cookie;
 } raw_tracepoint;

 struct {
  __u64  btf;
  __u64  btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64  buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64  iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64  syms;
    __u64  addrs;
    __u64  cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64  path;
    __u64  offsets;
    __u64  ref_ctr_offsets;
    __u64  cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64  stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

} ;
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};
struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64  tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64  target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64  addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64  cookies;
  } kprobe_multi;
  struct {
   __u64  path;
   __u64  offsets;
   __u64  ref_ctr_offsets;
   __u64  cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64  file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64  func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64  tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} ;
struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};
struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};
struct sock_filter {
 __u16 code;
 __u8 jt;
 __u8 jf;
 __u32 k;
};
struct cred;
struct module;
static inline    int is_kernel(unsigned long addr)
;
struct btf_type {
 __u32 name_off;
 __u32 info;







 union {
  __u32 size;
  __u32 type;
 };
};
struct btf_member {
 __u32 name_off;
 __u32 type;






 __u32 offset;
};
struct btf;
struct btf_member;
struct btf_type;
union bpf_attr;
struct bpf_prog;
struct bpf_verifier_log;
struct bpf_struct_ops;
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct qspinlock;
struct bpf_verifier_env;
struct bpf_verifier_log;
struct perf_event;
struct bpf_prog;
struct bpf_prog_aux;
struct bpf_map;
struct bpf_arena;
struct sock;
struct seq_file;
struct btf;
struct btf_type;
struct exception_table_entry;
struct seq_operations;
struct bpf_iter_aux_info;
struct bpf_local_storage;
struct bpf_local_storage_map;
struct kobject;
struct mem_cgroup;
struct module;
struct bpf_func_state;
struct ftrace_ops;
struct cgroup;
struct bpf_token;
struct user_namespace;
struct super_block;
struct inode;
typedef u64 (*bpf_callback_t)(u64, u64, u64, u64, u64);
typedef int (*bpf_iter_init_seq_priv_t)(void *private_data,
     struct bpf_iter_aux_info *aux);
typedef void (*bpf_iter_fini_seq_priv_t)(void *private_data);
struct bpf_iter_seq_info {
 const struct seq_operations *seq_ops;
 bpf_iter_init_seq_priv_t init_seq_private;
 bpf_iter_fini_seq_priv_t fini_seq_private;
 u32 seq_priv_size;
};
struct bpf_map_ops {

 int (*map_alloc_check)(union bpf_attr *attr);
 struct bpf_map *(*map_alloc)(union bpf_attr *attr);
 void (*map_release)(struct bpf_map *map, struct file *map_file);
 void (*map_free)(struct bpf_map *map);
 int (*map_get_next_key)(struct bpf_map *map, void *key, void *next_key);
 void (*map_release_uref)(struct bpf_map *map);
 void *(*map_lookup_elem_sys_only)(struct bpf_map *map, void *key);
 int (*map_lookup_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_lookup_and_delete_elem)(struct bpf_map *map, void *key,
       void *value, u64 flags);
 int (*map_lookup_and_delete_batch)(struct bpf_map *map,
        const union bpf_attr *attr,
        union bpf_attr *uattr);
 int (*map_update_batch)(struct bpf_map *map, struct file *map_file,
    const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_delete_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);


 void *(*map_lookup_elem)(struct bpf_map *map, void *key);
 long (*map_update_elem)(struct bpf_map *map, void *key, void *value, u64 flags);
 long (*map_delete_elem)(struct bpf_map *map, void *key);
 long (*map_push_elem)(struct bpf_map *map, void *value, u64 flags);
 long (*map_pop_elem)(struct bpf_map *map, void *value);
 long (*map_peek_elem)(struct bpf_map *map, void *value);
 void *(*map_lookup_percpu_elem)(struct bpf_map *map, void *key, u32 cpu);
 int (*map_get_hash)(struct bpf_map *map, u32 hash_buf_size, void *hash_buf);


 void *(*map_fd_get_ptr)(struct bpf_map *map, struct file *map_file,
    int fd);




 void (*map_fd_put_ptr)(struct bpf_map *map, void *ptr, bool need_defer);
 int (*map_gen_lookup)(struct bpf_map *map, struct bpf_insn *insn_buf);
 u32 (*map_fd_sys_lookup_elem)(void *ptr);
 void (*map_seq_show_elem)(struct bpf_map *map, void *key,
      struct seq_file *m);
 int (*map_check_btf)(const struct bpf_map *map,
        const struct btf *btf,
        const struct btf_type *key_type,
        const struct btf_type *value_type);


 int (*map_poke_track)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_untrack)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_run)(struct bpf_map *map, u32 key, struct bpf_prog *old,
        struct bpf_prog *new);


 int (*map_direct_value_addr)(const struct bpf_map *map,
         u64 *imm, u32 off);
 int (*map_direct_value_meta)(const struct bpf_map *map,
         u64 imm, u32 *off);
 int (*map_mmap)(struct bpf_map *map, struct vm_area_struct *vma);
 __poll_t (*map_poll)(struct bpf_map *map, struct file *filp,
        struct poll_table_struct *pts);
 unsigned long (*map_get_unmapped_area)(struct file *filep, unsigned long addr,
            unsigned long len, unsigned long pgoff,
            unsigned long flags);


 int (*map_local_storage_charge)(struct bpf_local_storage_map *smap,
     void *owner, u32 size);
 void (*map_local_storage_uncharge)(struct bpf_local_storage_map *smap,
        void *owner, u32 size);
 struct bpf_local_storage ** (*map_owner_storage_ptr)(void *owner);


 long (*map_redirect)(struct bpf_map *map, u64 key, u64 flags);
 bool (*map_meta_equal)(const struct bpf_map *meta0,
          const struct bpf_map *meta1);


 int (*map_set_for_each_callback_args)(struct bpf_verifier_env *env,
           struct bpf_func_state *caller,
           struct bpf_func_state *callee);
 long (*map_for_each_callback)(struct bpf_map *map,
         bpf_callback_t callback_fn,
         void *callback_ctx, u64 flags);

 u64 (*map_mem_usage)(const struct bpf_map *map);


 int *map_btf_id;


 const struct bpf_iter_seq_info *iter_seq_info;
};
enum btf_field_type {
 BPF_SPIN_LOCK = (1 << 0),
 BPF_TIMER = (1 << 1),
 BPF_KPTR_UNREF = (1 << 2),
 BPF_KPTR_REF = (1 << 3),
 BPF_KPTR_PERCPU = (1 << 4),
 BPF_KPTR = BPF_KPTR_UNREF | BPF_KPTR_REF | BPF_KPTR_PERCPU,
 BPF_LIST_HEAD = (1 << 5),
 BPF_LIST_NODE = (1 << 6),
 BPF_RB_ROOT = (1 << 7),
 BPF_RB_NODE = (1 << 8),
 BPF_GRAPH_NODE = BPF_RB_NODE | BPF_LIST_NODE,
 BPF_GRAPH_ROOT = BPF_RB_ROOT | BPF_LIST_HEAD,
 BPF_REFCOUNT = (1 << 9),
 BPF_WORKQUEUE = (1 << 10),
 BPF_UPTR = (1 << 11),
 BPF_RES_SPIN_LOCK = (1 << 12),
 BPF_TASK_WORK = (1 << 13),
};
enum bpf_cgroup_storage_type {
 BPF_CGROUP_STORAGE_SHARED,
 BPF_CGROUP_STORAGE_PERCPU,
 __BPF_CGROUP_STORAGE_MAX
};
typedef void (*btf_dtor_kfunc_t)(void *);
struct btf_field_kptr {
 struct btf *btf;
 struct module *module;



 btf_dtor_kfunc_t dtor;
 u32 btf_id;
};
struct btf_field_graph_root {
 struct btf *btf;
 u32 value_btf_id;
 u32 node_offset;
 struct btf_record *value_rec;
};
struct btf_field {
 u32 offset;
 u32 size;
 enum btf_field_type type;
 union {
  struct btf_field_kptr kptr;
  struct btf_field_graph_root graph_root;
 };
};
struct btf_record {
 u32 cnt;
 u32 field_mask;
 int spin_lock_off;
 int res_spin_lock_off;
 int timer_off;
 int wq_off;
 int refcount_off;
 int task_work_off;
 struct btf_field fields[1];
};
struct bpf_map_owner {
 enum bpf_prog_type type;
 bool jited;
 bool xdp_has_frags;
 u64 storage_cookie[__BPF_CGROUP_STORAGE_MAX];
 const struct btf_type *attach_func_proto;
 enum bpf_attach_type expected_attach_type;
};
struct bpf_map {
 u8 sha[32];
 u32 excl;
 const struct bpf_map_ops *ops;
 struct bpf_map *inner_map_meta;

 void *security;

 enum bpf_map_type map_type;
 u32 key_size;
 u32 value_size;
 u32 max_entries;
 u64 map_extra;
 u32 map_flags;
 u32 id;
 struct btf_record *record;
 int numa_node;
 u32 btf_key_type_id;
 u32 btf_value_type_id;
 u32 btf_vmlinux_value_type_id;
 struct btf *btf;

 struct obj_cgroup *objcg;

 char name[16U];
 struct mutex freeze_mutex;
 atomic64_t refcnt;
 atomic64_t usercnt;

 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 atomic64_t writecnt;
 spinlock_t owner_lock;
 struct bpf_map_owner *owner;
 bool bypass_spec_v1;
 bool frozen;
 bool free_after_mult_rcu_gp;
 bool free_after_rcu_gp;
 atomic64_t sleepable_refcnt;
 s64 *elem_count;
 u64 cookie;
 char *excl_prog_sha;
};
struct bpf_offload_dev;
struct bpf_offloaded_map;
struct bpf_map_dev_ops {
 int (*map_get_next_key)(struct bpf_offloaded_map *map,
    void *key, void *next_key);
 int (*map_lookup_elem)(struct bpf_offloaded_map *map,
          void *key, void *value);
 int (*map_update_elem)(struct bpf_offloaded_map *map,
          void *key, void *value, u64 flags);
 int (*map_delete_elem)(struct bpf_offloaded_map *map, void *key);
};
struct bpf_offloaded_map {
 struct bpf_map map;
 struct net_device *netdev;
 const struct bpf_map_dev_ops *dev_ops;
 void *dev_priv;
 struct list_head offloads;
};
enum bpf_type_flag {

 PTR_MAYBE_NULL = ((((1UL))) << (0 + 8)),




 MEM_RDONLY = ((((1UL))) << (1 + 8)),


 MEM_RINGBUF = ((((1UL))) << (2 + 8)),


 MEM_USER = ((((1UL))) << (3 + 8)),







 MEM_PERCPU = ((((1UL))) << (4 + 8)),


 OBJ_RELEASE = ((((1UL))) << (5 + 8)),







 PTR_UNTRUSTED = ((((1UL))) << (6 + 8)),


 MEM_UNINIT = ((((1UL))) << (7 + 8)),


 DYNPTR_TYPE_LOCAL = ((((1UL))) << (8 + 8)),


 DYNPTR_TYPE_RINGBUF = ((((1UL))) << (9 + 8)),


 MEM_FIXED_SIZE = ((((1UL))) << (10 + 8)),




 MEM_ALLOC = ((((1UL))) << (11 + 8)),
 PTR_TRUSTED = ((((1UL))) << (12 + 8)),


 MEM_RCU = ((((1UL))) << (13 + 8)),





 NON_OWN_REF = ((((1UL))) << (14 + 8)),


 DYNPTR_TYPE_SKB = ((((1UL))) << (15 + 8)),


 DYNPTR_TYPE_XDP = ((((1UL))) << (16 + 8)),




 MEM_ALIGNED = ((((1UL))) << (17 + 8)),






 MEM_WRITE = ((((1UL))) << (18 + 8)),


 DYNPTR_TYPE_SKB_META = ((((1UL))) << (19 + 8)),

 __BPF_TYPE_FLAG_MAX,
 __BPF_TYPE_LAST_FLAG = __BPF_TYPE_FLAG_MAX - 1,
};
enum bpf_arg_type {
 ARG_DONTCARE = 0,




 ARG_CONST_MAP_PTR,
 ARG_PTR_TO_MAP_KEY,
 ARG_PTR_TO_MAP_VALUE,




 ARG_PTR_TO_MEM,
 ARG_PTR_TO_ARENA,

 ARG_CONST_SIZE,
 ARG_CONST_SIZE_OR_ZERO,

 ARG_PTR_TO_CTX,
 ARG_ANYTHING,
 ARG_SCALAR,
 ARG_PTR_TO_SPIN_LOCK,
 ARG_PTR_TO_SOCK_COMMON,
 ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_BTF_ID,
 ARG_PTR_TO_RINGBUF_MEM,
 ARG_CONST_ALLOC_SIZE_OR_ZERO,
 ARG_PTR_TO_BTF_ID_SOCK_COMMON,
 ARG_PTR_TO_PERCPU_BTF_ID,
 ARG_PTR_TO_FUNC,
 ARG_PTR_TO_STACK,
 ARG_PTR_TO_CONST_STR,
 ARG_PTR_TO_TIMER,
 ARG_KPTR_XCHG_DEST,
 ARG_PTR_TO_DYNPTR,
 __BPF_ARG_TYPE_MAX,


 ARG_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MAP_VALUE,
 ARG_PTR_TO_MEM_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MEM,
 ARG_PTR_TO_CTX_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_CTX,
 ARG_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_STACK_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_STACK,
 ARG_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_BTF_ID,



 ARG_PTR_TO_UNINIT_MEM = MEM_UNINIT | MEM_WRITE | ARG_PTR_TO_MEM,

 ARG_PTR_TO_FIXED_SIZE_MEM = MEM_FIXED_SIZE | ARG_PTR_TO_MEM,




 __BPF_ARG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
enum bpf_return_type {
 RET_INTEGER,
 RET_VOID,
 RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_MEM,
 RET_PTR_TO_MEM_OR_BTF_ID,
 RET_PTR_TO_BTF_ID,
 __BPF_RET_TYPE_MAX,


 RET_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_RINGBUF_MEM_OR_NULL = PTR_MAYBE_NULL | MEM_RINGBUF | RET_PTR_TO_MEM,
 RET_PTR_TO_DYNPTR_MEM_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MEM,
 RET_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_BTF_ID,
 RET_PTR_TO_BTF_ID_TRUSTED = PTR_TRUSTED | RET_PTR_TO_BTF_ID,




 __BPF_RET_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_func_proto {
 u64 (*func)(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5);
 bool gpl_only;
 bool pkt_access;
 bool might_sleep;





 bool allow_fastcall;
 enum bpf_return_type ret_type;
 union {
  struct {
   enum bpf_arg_type arg1_type;
   enum bpf_arg_type arg2_type;
   enum bpf_arg_type arg3_type;
   enum bpf_arg_type arg4_type;
   enum bpf_arg_type arg5_type;
  };
  enum bpf_arg_type arg_type[5];
 };
 union {
  struct {
   u32 *arg1_btf_id;
   u32 *arg2_btf_id;
   u32 *arg3_btf_id;
   u32 *arg4_btf_id;
   u32 *arg5_btf_id;
  };
  u32 *arg_btf_id[5];
  struct {
   size_t arg1_size;
   size_t arg2_size;
   size_t arg3_size;
   size_t arg4_size;
   size_t arg5_size;
  };
  size_t arg_size[5];
 };
 int *ret_btf_id;
 bool (*allowed)(const struct bpf_prog *prog);
};
enum bpf_access_type {
 BPF_READ = 1,
 BPF_WRITE = 2
};
enum bpf_reg_type {
 NOT_INIT = 0,
 SCALAR_VALUE,
 PTR_TO_CTX,
 CONST_PTR_TO_MAP,
 PTR_TO_MAP_VALUE,
 PTR_TO_MAP_KEY,
 PTR_TO_STACK,
 PTR_TO_PACKET_META,
 PTR_TO_PACKET,
 PTR_TO_PACKET_END,
 PTR_TO_FLOW_KEYS,
 PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK,
 PTR_TO_TP_BUFFER,
 PTR_TO_XDP_SOCK,
 PTR_TO_BTF_ID,
 PTR_TO_MEM,
 PTR_TO_ARENA,
 PTR_TO_BUF,
 PTR_TO_FUNC,
 CONST_PTR_TO_DYNPTR,
 __BPF_REG_TYPE_MAX,


 PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | PTR_TO_MAP_VALUE,
 PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | PTR_TO_TCP_SOCK,




 PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | PTR_TO_BTF_ID,




 __BPF_REG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_insn_access_aux {
 enum bpf_reg_type reg_type;
 bool is_ldsx;
 union {
  int ctx_field_size;
  struct {
   struct btf *btf;
   u32 btf_id;
   u32 ref_obj_id;
  };
 };
 struct bpf_verifier_log *log;
 bool is_retval;
};
struct bpf_prog_ops {
 int (*test_run)(struct bpf_prog *prog, const union bpf_attr *kattr,
   union bpf_attr *uattr);
};
struct bpf_reg_state;
struct bpf_verifier_ops {

 const struct bpf_func_proto *
 (*get_func_proto)(enum bpf_func_id func_id,
     const struct bpf_prog *prog);




 bool (*is_valid_access)(int off, int size, enum bpf_access_type type,
    const struct bpf_prog *prog,
    struct bpf_insn_access_aux *info);
 int (*gen_prologue)(struct bpf_insn *insn, bool direct_write,
       const struct bpf_prog *prog);
 int (*gen_epilogue)(struct bpf_insn *insn, const struct bpf_prog *prog,
       s16 ctx_stack_off);
 int (*gen_ld_abs)(const struct bpf_insn *orig,
     struct bpf_insn *insn_buf);
 u32 (*convert_ctx_access)(enum bpf_access_type type,
      const struct bpf_insn *src,
      struct bpf_insn *dst,
      struct bpf_prog *prog, u32 *target_size);
 int (*btf_struct_access)(struct bpf_verifier_log *log,
     const struct bpf_reg_state *reg,
     int off, int size);
};
struct bpf_prog_offload {
 struct bpf_prog *prog;
 struct net_device *netdev;
 struct bpf_offload_dev *offdev;
 void *dev_priv;
 struct list_head offloads;
 bool dev_state;
 bool opt_failed;
 void *jited_image;
 u32 jited_len;
};
struct btf_func_model {
 u8 ret_size;
 u8 ret_flags;
 u8 nr_args;
 u8 arg_size[12];
 u8 arg_flags[12];
};
struct bpf_tramp_image;
struct bpf_ksym {
 unsigned long start;
 unsigned long end;
 char name[512];
 struct list_head lnode;
 struct latch_tree_node tnode;
 bool prog;
};
enum bpf_tramp_prog_type {
 BPF_TRAMP_FENTRY,
 BPF_TRAMP_FEXIT,
 BPF_TRAMP_MODIFY_RETURN,
 BPF_TRAMP_MAX,
 BPF_TRAMP_REPLACE,
};
struct bpf_tramp_image {
 void *image;
 int size;
 struct bpf_ksym ksym;
 struct percpu_ref pcref;
 void *ip_after_call;
 void *ip_epilogue;
 union {
  struct callback_head rcu;
  struct work_struct work;
 };
};
struct bpf_trampoline {

 struct hlist_node hlist;
 struct ftrace_ops *fops;

 struct mutex mutex;
 refcount_t refcnt;
 u32 flags;
 u64 key;
 struct {
  struct btf_func_model model;
  void *addr;
  bool ftrace_managed;
 } func;




 struct bpf_prog *extension_prog;

 struct hlist_head progs_hlist[BPF_TRAMP_MAX];

 int progs_cnt[BPF_TRAMP_MAX];

 struct bpf_tramp_image *cur_image;
};
struct bpf_func_info_aux {
 u16 linkage;
 bool unreliable;
 bool called : 1;
 bool verified : 1;
};
struct bpf_jit_poke_descriptor {
 void *tailcall_target;
 void *tailcall_bypass;
 void *bypass_addr;
 void *aux;
 union {
  struct {
   struct bpf_map *map;
   u32 key;
  } tail_call;
 };
 bool tailcall_target_stable;
 u8 adj_off;
 u16 reason;
 u32 insn_idx;
};
struct bpf_ctx_arg_aux {
 u32 offset;
 enum bpf_reg_type reg_type;
 struct btf *btf;
 u32 btf_id;
 u32 ref_obj_id;
 bool refcounted;
};
struct btf_mod_pair {
 struct btf *btf;
 struct module *module;
};
struct bpf_kfunc_desc_tab;
struct bpf_stream {
 atomic_t capacity;
 struct llist_head log;

 struct mutex lock;
 struct llist_node *backlog_head;
 struct llist_node *backlog_tail;
};
struct bpf_prog_aux {
 atomic64_t refcnt;
 u32 used_map_cnt;
 u32 used_btf_cnt;
 u32 max_ctx_offset;
 u32 max_pkt_offset;
 u32 max_tp_access;
 u32 stack_depth;
 u32 id;
 u32 func_cnt;
 u32 real_func_cnt;
 u32 func_idx;
 u32 attach_btf_id;
 u32 attach_st_ops_member_off;
 u32 ctx_arg_info_size;
 u32 max_rdonly_access;
 u32 max_rdwr_access;
 struct btf *attach_btf;
 struct bpf_ctx_arg_aux *ctx_arg_info;
 void *priv_stack_ptr;
 struct mutex dst_mutex;
 struct bpf_prog *dst_prog;
 struct bpf_trampoline *dst_trampoline;
 enum bpf_prog_type saved_dst_prog_type;
 enum bpf_attach_type saved_dst_attach_type;
 bool verifier_zext;
 bool dev_bound;
 bool offload_requested;
 bool attach_btf_trace;
 bool attach_tracing_prog;
 bool func_proto_unreliable;
 bool tail_call_reachable;
 bool xdp_has_frags;
 bool exception_cb;
 bool exception_boundary;
 bool is_extended;
 bool jits_use_priv_stack;
 bool priv_stack_requested;
 bool changes_pkt_data;
 bool might_sleep;
 bool kprobe_write_ctx;
 u64 prog_array_member_cnt;
 struct mutex ext_mutex;
 struct bpf_arena *arena;
 void (*recursion_detected)(struct bpf_prog *prog);

 const struct btf_type *attach_func_proto;

 const char *attach_func_name;
 struct bpf_prog **func;
 struct bpf_prog_aux *main_prog_aux;
 void *jit_data;
 struct bpf_jit_poke_descriptor *poke_tab;
 struct bpf_kfunc_desc_tab *kfunc_tab;
 struct bpf_kfunc_btf_tab *kfunc_btf_tab;
 u32 size_poke_tab;



 struct bpf_ksym ksym;
 const struct bpf_prog_ops *ops;
 const struct bpf_struct_ops *st_ops;
 struct bpf_map **used_maps;
 struct mutex used_maps_mutex;
 struct btf_mod_pair *used_btfs;
 struct bpf_prog *prog;
 struct user_struct *user;
 u64 load_time;
 u32 verified_insns;
 int cgroup_atype;
 struct bpf_map *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
 char name[16U];
 u64 (*bpf_exception_cb)(u64 cookie, u64 sp, u64 bp, u64, u64);

 void *security;

 struct bpf_token *token;
 struct bpf_prog_offload *offload;
 struct btf *btf;
 struct bpf_func_info *func_info;
 struct bpf_func_info_aux *func_info_aux;






 struct bpf_line_info *linfo;







 void **jited_linfo;
 u32 func_info_cnt;
 u32 nr_linfo;




 u32 linfo_idx;
 struct module *mod;
 u32 num_exentries;
 struct exception_table_entry *extable;
 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 struct bpf_stream stream[2];
};
struct bpf_prog {
 u16 pages;
 u16 jited:1,
    jit_requested:1,
    gpl_compatible:1,
    cb_access:1,
    dst_needed:1,
    blinding_requested:1,
    blinded:1,
    is_func:1,
    kprobe_override:1,
    has_callchain_buf:1,
    enforce_expected_attach_type:1,
    call_get_stack:1,
    call_get_func_ip:1,
    tstamp_type_access:1,
    sleepable:1;
 enum bpf_prog_type type;
 enum bpf_attach_type expected_attach_type;
 u32 len;
 u32 jited_len;
 union {
  u8 digest[32];
  u8 tag[8];
 };
 struct bpf_prog_stats *stats;
 int *active;
 unsigned int (*bpf_func)(const void *ctx,
         const struct bpf_insn *insn);
 struct bpf_prog_aux *aux;
 struct sock_fprog_kern *orig_prog;

 union {
  struct { struct { } __empty_insns; struct sock_filter insns[1]; };
  struct { struct { } __empty_insnsi; struct bpf_insn insnsi[1]; };
 };
};
struct bpf_link {
 atomic64_t refcnt;
 u32 id;
 enum bpf_link_type type;
 const struct bpf_link_ops *ops;
 struct bpf_prog *prog;

 u32 flags;
 enum bpf_attach_type attach_type;




 union {
  struct callback_head rcu;
  struct work_struct work;
 };




 bool sleepable;
};
struct bpf_link_ops {
 void (*release)(struct bpf_link *link);



 void (*dealloc)(struct bpf_link *link);






 void (*dealloc_deferred)(struct bpf_link *link);
 int (*detach)(struct bpf_link *link);
 int (*update_prog)(struct bpf_link *link, struct bpf_prog *new_prog,
      struct bpf_prog *old_prog);
 void (*show_fdinfo)(const struct bpf_link *link, struct seq_file *seq);
 int (*fill_link_info)(const struct bpf_link *link,
         struct bpf_link_info *info);
 int (*update_map)(struct bpf_link *link, struct bpf_map *new_map,
     struct bpf_map *old_map);
 __poll_t (*poll)(struct file *file, struct poll_table_struct *pts);
};
struct bpf_token {
 struct work_struct work;
 atomic64_t refcnt;
 struct user_namespace *userns;
 u64 allowed_cmds;
 u64 allowed_maps;
 u64 allowed_progs;
 u64 allowed_attachs;

 void *security;

};
struct btf_member;
struct bpf_struct_ops {
 const struct bpf_verifier_ops *verifier_ops;
 int (*init)(struct btf *btf);
 int (*check_member)(const struct btf_type *t,
       const struct btf_member *member,
       const struct bpf_prog *prog);
 int (*init_member)(const struct btf_type *t,
      const struct btf_member *member,
      void *kdata, const void *udata);
 int (*reg)(void *kdata, struct bpf_link *link);
 void (*unreg)(void *kdata, struct bpf_link *link);
 int (*update)(void *kdata, void *old_kdata, struct bpf_link *link);
 int (*validate)(void *kdata);
 void *cfi_stubs;
 struct module *owner;
 const char *name;
 struct btf_func_model func_models[64];
};
struct bpf_prog_array_item {
 struct bpf_prog *prog;
 union {
  struct bpf_cgroup_storage *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
  u64 bpf_cookie;
 };
};
struct bpf_prog_array {
 struct callback_head rcu;
 struct bpf_prog_array_item items[1];
};
struct bpf_run_ctx {};
enum bpf_iter_task_type {
 BPF_TASK_ITER_ALL = 0,
 BPF_TASK_ITER_TID,
 BPF_TASK_ITER_TGID,
};
struct bpf_iter_aux_info {

 struct bpf_map *map;


 struct {
  struct cgroup *start;
  enum bpf_cgroup_iter_order order;
 } cgroup;
 struct {
  enum bpf_iter_task_type type;
  u32 pid;
 } task;
};
int map_set_for_each_callback_args(struct bpf_verifier_env *env,
       struct bpf_func_state *caller,
       struct bpf_func_state *callee);
struct xdp_frame;
struct sk_buff;
int btf_struct_access(struct bpf_verifier_log *log,
        const struct bpf_reg_state *reg,
        int off, int size, enum bpf_access_type atype,
        u32 *next_btf_id, enum bpf_type_flag *flag, const char **field_name);
struct bpf_reg_state;
struct key;
struct cred;
struct rlimit;
struct kernel_siginfo;
struct audit_context;
struct super_block;
struct inode;
struct dentry;
struct file;
struct vfsmount;
struct path;
struct qstr;
struct iattr;
struct fown_struct;
struct file_operations;
struct kernfs_node;
struct xfrm_sec_ctx;
struct mm_struct;
struct fs_context;
struct ctl_table;
struct user_namespace;
struct msghdr;
struct sk_buff;
struct sock;
struct sockaddr;
struct socket;
struct flowi_common;
struct dst_entry;
struct xfrm_selector;
struct xfrm_policy;
struct xfrm_state;
struct seq_file;
struct request_sock;
union bpf_attr;
struct bpf_map;
struct bpf_prog;
struct bpf_token;
struct perf_event;
struct sock;
struct nlmsghdr {
 __u32 nlmsg_len;
 __u16 nlmsg_type;
 __u16 nlmsg_flags;
 __u32 nlmsg_seq;
 __u32 nlmsg_pid;
};
struct nlattr {
 __u16 nla_len;
 __u16 nla_type;
};
struct net;
struct netlink_ext_ack {
 const char *_msg;
 const struct nlattr *bad_attr;
 const struct nla_policy *policy;
 const struct nlattr *miss_nest;
 u16 miss_type;
 u8 cookie[8];
 u8 cookie_len;
 char _msg_buf[80];
};
struct netlink_callback {
 struct sk_buff *skb;
 const struct nlmsghdr *nlh;
 int (*dump)(struct sk_buff * skb,
     struct netlink_callback *cb);
 int (*done)(struct netlink_callback *cb);
 void *data;

 struct module *module;
 struct netlink_ext_ack *extack;
 u16 family;
 u16 answer_flags;
 u32 min_dump_alloc;
 unsigned int prev_seq, seq;
 int flags;
 bool strict_check;
 union {
  u8 ctx[48];




  long args[6];
 };
};
struct ndmsg {
 __u8 ndm_family;
 __u8 ndm_pad1;
 __u16 ndm_pad2;
 __s32 ndm_ifindex;
 __u16 ndm_state;
 __u8 ndm_flags;
 __u8 ndm_type;
};
struct rtnl_link_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
 __u64 collisions;


 __u64 rx_length_errors;
 __u64 rx_over_errors;
 __u64 rx_crc_errors;
 __u64 rx_frame_errors;
 __u64 rx_fifo_errors;
 __u64 rx_missed_errors;


 __u64 tx_aborted_errors;
 __u64 tx_carrier_errors;
 __u64 tx_fifo_errors;
 __u64 tx_heartbeat_errors;
 __u64 tx_window_errors;


 __u64 rx_compressed;
 __u64 tx_compressed;
 __u64 rx_nohandler;

 __u64 rx_otherhost_dropped;
};
struct rtnl_hw_stats64 {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 rx_errors;
 __u64 tx_errors;
 __u64 rx_dropped;
 __u64 tx_dropped;
 __u64 multicast;
};
struct ifla_vf_guid {
 __u32 vf;
 __u64 guid;
};
struct ifla_vf_stats {
 __u64 rx_packets;
 __u64 tx_packets;
 __u64 rx_bytes;
 __u64 tx_bytes;
 __u64 broadcast;
 __u64 multicast;
 __u64 rx_dropped;
 __u64 tx_dropped;
};
struct ifla_vf_info {
 __u32 vf;
 __u8 mac[32];
 __u32 vlan;
 __u32 qos;
 __u32 spoofchk;
 __u32 linkstate;
 __u32 min_tx_rate;
 __u32 max_tx_rate;
 __u32 rss_query_en;
 __u32 trusted;
 __be16 vlan_proto;
};
enum {
 NEIGH_ARP_TABLE = 0,
 NEIGH_ND_TABLE = 1,
 NEIGH_NR_TABLES,
 NEIGH_LINK_TABLE = NEIGH_NR_TABLES
};
struct netpoll_info;
struct device;
struct ethtool_ops;
struct kernel_hwtstamp_config;
struct phy_device;
struct dsa_port;
struct ip_tunnel_parm_kern;
struct macsec_ops;
struct netdev_config;
struct netdev_name_node;
struct sfp_bus;
struct wireless_dev;
struct wpan_dev;
struct mpls_dev;
struct udp_tunnel_nic_info;
struct udp_tunnel_nic;
struct bpf_prog;
struct xdp_buff;
struct xdp_frame;
struct xdp_metadata_ops;
struct ethtool_netdev_state;
struct phy_link_topology;
struct hwtstamp_provider;
typedef u32 xdp_features_t;
enum netdev_tx {
 __NETDEV_TX_MIN = (-((int)(~0U >> 1)) - 1),
 NETDEV_TX_OK = 0x00,
 NETDEV_TX_BUSY = 0x10,
};
typedef enum netdev_tx netdev_tx_t;
struct net_device_stats {
 union { unsigned long rx_packets; atomic_long_t __rx_packets; };
 union { unsigned long tx_packets; atomic_long_t __tx_packets; };
 union { unsigned long rx_bytes; atomic_long_t __rx_bytes; };
 union { unsigned long tx_bytes; atomic_long_t __tx_bytes; };
 union { unsigned long rx_errors; atomic_long_t __rx_errors; };
 union { unsigned long tx_errors; atomic_long_t __tx_errors; };
 union { unsigned long rx_dropped; atomic_long_t __rx_dropped; };
 union { unsigned long tx_dropped; atomic_long_t __tx_dropped; };
 union { unsigned long multicast; atomic_long_t __multicast; };
 union { unsigned long collisions; atomic_long_t __collisions; };
 union { unsigned long rx_length_errors; atomic_long_t __rx_length_errors; };
 union { unsigned long rx_over_errors; atomic_long_t __rx_over_errors; };
 union { unsigned long rx_crc_errors; atomic_long_t __rx_crc_errors; };
 union { unsigned long rx_frame_errors; atomic_long_t __rx_frame_errors; };
 union { unsigned long rx_fifo_errors; atomic_long_t __rx_fifo_errors; };
 union { unsigned long rx_missed_errors; atomic_long_t __rx_missed_errors; };
 union { unsigned long tx_aborted_errors; atomic_long_t __tx_aborted_errors; };
 union { unsigned long tx_carrier_errors; atomic_long_t __tx_carrier_errors; };
 union { unsigned long tx_fifo_errors; atomic_long_t __tx_fifo_errors; };
 union { unsigned long tx_heartbeat_errors; atomic_long_t __tx_heartbeat_errors; };
 union { unsigned long tx_window_errors; atomic_long_t __tx_window_errors; };
 union { unsigned long rx_compressed; atomic_long_t __rx_compressed; };
 union { unsigned long tx_compressed; atomic_long_t __tx_compressed; };
};
struct net_device_core_stats {
 unsigned long rx_dropped;
 unsigned long tx_dropped;
 unsigned long rx_nohandler;
 unsigned long rx_otherhost_dropped;
} ;
struct neighbour;
struct neigh_parms;
struct sk_buff;
struct netdev_hw_addr_list {
 struct list_head list;
 int count;


 struct rb_root tree;
};
struct hh_cache {
 unsigned int hh_len;
 seqlock_t hh_lock;




 unsigned long hh_data[(((128)+(16 -1))&~(16 - 1)) / sizeof(long)];
};
struct header_ops {
 int (*create) (struct sk_buff *skb, struct net_device *dev,
      unsigned short type, const void *daddr,
      const void *saddr, unsigned int len);
 int (*parse)(const struct sk_buff *skb,
    const struct net_device *dev,
    unsigned char *haddr);
 int (*cache)(const struct neighbour *neigh, struct hh_cache *hh, __be16 type);
 void (*cache_update)(struct hh_cache *hh,
    const struct net_device *dev,
    const unsigned char *haddr);
 bool (*validate)(const char *ll_header, unsigned int len);
 __be16 (*parse_protocol)(const struct sk_buff *skb);
};
struct gro_list {
 struct list_head list;
 int count;
};
struct gro_node {
 unsigned long bitmask;
 struct gro_list hash[8];
 struct list_head rx_list;
 u32 rx_count;
 u32 cached_napi_id;
};
struct napi_config {
 u64 gro_flush_timeout;
 u64 irq_suspend_timeout;
 u32 defer_hard_irqs;
 cpumask_t affinity_mask;
 u8 threaded;
 unsigned int napi_id;
};
struct napi_struct {






 struct list_head poll_list;

 unsigned long state;
 int weight;
 u32 defer_hard_irqs_count;
 int (*poll)(struct napi_struct *, int);


 int poll_owner;


 int list_owner;
 struct net_device *dev;
 struct sk_buff *skb;
 struct gro_node gro;
 struct hrtimer timer;

 struct task_struct *thread;
 unsigned long gro_flush_timeout;
 unsigned long irq_suspend_timeout;
 u32 defer_hard_irqs;

 u32 napi_id;
 struct list_head dev_list;
 struct hlist_node napi_hash_node;
 int irq;
 struct irq_affinity_notify notify;
 int napi_rmap_idx;
 int index;
 struct napi_config *config;
};
enum rx_handler_result {
 RX_HANDLER_CONSUMED,
 RX_HANDLER_ANOTHER,
 RX_HANDLER_EXACT,
 RX_HANDLER_PASS,
};
typedef enum rx_handler_result rx_handler_result_t;
typedef rx_handler_result_t rx_handler_func_t(struct sk_buff **pskb);
struct netdev_queue {



 struct net_device *dev;
 netdevice_tracker dev_tracker;

 struct Qdisc *qdisc;
 struct Qdisc *qdisc_sleeping;

 struct kobject kobj;
 const struct attribute_group **groups;

 unsigned long tx_maxrate;




 atomic_long_t trans_timeout;


 struct net_device *sb_dev;


 struct xsk_buff_pool *pool;






 struct dql dql;

 spinlock_t _xmit_lock ;
 int xmit_lock_owner;



 unsigned long trans_start;

 unsigned long state;







 struct napi_struct *napi;


 int numa_node;

} ;
enum xps_map_type {
 XPS_CPUS = 0,
 XPS_RXQS,
 XPS_MAPS_MAX,
};
struct xps_map {
 unsigned int len;
 unsigned int alloc_len;
 struct callback_head rcu;
 u16 queues[1];
};
struct xps_dev_maps {
 struct callback_head rcu;
 unsigned int nr_ids;
 s16 num_tc;
 struct xps_map *attr_map[1];
};
struct netdev_tc_txq {
 u16 count;
 u16 offset;
};
struct netdev_fcoe_hbainfo {
 char manufacturer[64];
 char serial_number[64];
 char hardware_version[64];
 char driver_version[64];
 char optionrom_version[64];
 char firmware_version[64];
 char model[256];
 char model_description[256];
};
struct netdev_phys_item_id {
 unsigned char id[32];
 unsigned char id_len;
};
enum net_device_path_type {
 DEV_PATH_ETHERNET = 0,
 DEV_PATH_VLAN,
 DEV_PATH_BRIDGE,
 DEV_PATH_PPPOE,
 DEV_PATH_DSA,
 DEV_PATH_MTK_WDMA,
};
struct net_device_path {
 enum net_device_path_type type;
 const struct net_device *dev;
 union {
  struct {
   u16 id;
   __be16 proto;
   u8 h_dest[6];
  } encap;
  struct {
   enum {
    DEV_PATH_BR_VLAN_KEEP,
    DEV_PATH_BR_VLAN_TAG,
    DEV_PATH_BR_VLAN_UNTAG,
    DEV_PATH_BR_VLAN_UNTAG_HW,
   } vlan_mode;
   u16 vlan_id;
   __be16 vlan_proto;
  } bridge;
  struct {
   int port;
   u16 proto;
  } dsa;
  struct {
   u8 wdma_idx;
   u8 queue;
   u16 wcid;
   u8 bss;
   u8 amsdu;
  } mtk_wdma;
 };
};
struct net_device_path_ctx {
 const struct net_device *dev;
 u8 daddr[6];

 int num_vlans;
 struct {
  u16 id;
  __be16 proto;
 } vlan[2];
};
enum tc_setup_type {
 TC_QUERY_CAPS,
 TC_SETUP_QDISC_MQPRIO,
 TC_SETUP_CLSU32,
 TC_SETUP_CLSFLOWER,
 TC_SETUP_CLSMATCHALL,
 TC_SETUP_CLSBPF,
 TC_SETUP_BLOCK,
 TC_SETUP_QDISC_CBS,
 TC_SETUP_QDISC_RED,
 TC_SETUP_QDISC_PRIO,
 TC_SETUP_QDISC_MQ,
 TC_SETUP_QDISC_ETF,
 TC_SETUP_ROOT_QDISC,
 TC_SETUP_QDISC_GRED,
 TC_SETUP_QDISC_TAPRIO,
 TC_SETUP_FT,
 TC_SETUP_QDISC_ETS,
 TC_SETUP_QDISC_TBF,
 TC_SETUP_QDISC_FIFO,
 TC_SETUP_QDISC_HTB,
 TC_SETUP_ACT,
};
enum bpf_netdev_command {







 XDP_SETUP_PROG,
 XDP_SETUP_PROG_HW,

 BPF_OFFLOAD_MAP_ALLOC,
 BPF_OFFLOAD_MAP_FREE,
 XDP_SETUP_XSK_POOL,
};
struct netlink_ext_ack;
struct xdp_dev_bulk_queue;
struct bpf_xdp_link;
enum bpf_xdp_mode {
 XDP_MODE_SKB = 0,
 XDP_MODE_DRV = 1,
 XDP_MODE_HW = 2,
 __MAX_XDP_MODE
};
struct bpf_xdp_entity {
 struct bpf_prog *prog;
 struct bpf_xdp_link *link;
};
struct netdev_bpf {
 enum bpf_netdev_command command;
 union {

  struct {
   u32 flags;
   struct bpf_prog *prog;
   struct netlink_ext_ack *extack;
  };

  struct {
   struct bpf_offloaded_map *offmap;
  };

  struct {
   struct xsk_buff_pool *pool;
   u16 queue_id;
  } xsk;
 };
};
struct xfrmdev_ops {
 int (*xdo_dev_state_add)(struct net_device *dev,
         struct xfrm_state *x,
         struct netlink_ext_ack *extack);
 void (*xdo_dev_state_delete)(struct net_device *dev,
     struct xfrm_state *x);
 void (*xdo_dev_state_free)(struct net_device *dev,
          struct xfrm_state *x);
 bool (*xdo_dev_offload_ok) (struct sk_buff *skb,
           struct xfrm_state *x);
 void (*xdo_dev_state_advance_esn) (struct xfrm_state *x);
 void (*xdo_dev_state_update_stats) (struct xfrm_state *x);
 int (*xdo_dev_policy_add) (struct xfrm_policy *x, struct netlink_ext_ack *extack);
 void (*xdo_dev_policy_delete) (struct xfrm_policy *x);
 void (*xdo_dev_policy_free) (struct xfrm_policy *x);
};
struct dev_ifalias {
 struct callback_head rcuhead;
 char ifalias[1];
};
struct tlsdev_ops;
struct net_device_ops {
 int (*ndo_init)(struct net_device *dev);
 void (*ndo_uninit)(struct net_device *dev);
 int (*ndo_open)(struct net_device *dev);
 int (*ndo_stop)(struct net_device *dev);
 netdev_tx_t (*ndo_start_xmit)(struct sk_buff *skb,
        struct net_device *dev);
 netdev_features_t (*ndo_features_check)(struct sk_buff *skb,
            struct net_device *dev,
            netdev_features_t features);
 u16 (*ndo_select_queue)(struct net_device *dev,
          struct sk_buff *skb,
          struct net_device *sb_dev);
 void (*ndo_change_rx_flags)(struct net_device *dev,
             int flags);
 void (*ndo_set_rx_mode)(struct net_device *dev);
 int (*ndo_set_mac_address)(struct net_device *dev,
             void *addr);
 int (*ndo_validate_addr)(struct net_device *dev);
 int (*ndo_do_ioctl)(struct net_device *dev,
             struct ifreq *ifr, int cmd);
 int (*ndo_eth_ioctl)(struct net_device *dev,
       struct ifreq *ifr, int cmd);
 int (*ndo_siocbond)(struct net_device *dev,
      struct ifreq *ifr, int cmd);
 int (*ndo_siocwandev)(struct net_device *dev,
        struct if_settings *ifs);
 int (*ndo_siocdevprivate)(struct net_device *dev,
            struct ifreq *ifr,
            void *data, int cmd);
 int (*ndo_set_config)(struct net_device *dev,
               struct ifmap *map);
 int (*ndo_change_mtu)(struct net_device *dev,
        int new_mtu);
 int (*ndo_neigh_setup)(struct net_device *dev,
         struct neigh_parms *);
 void (*ndo_tx_timeout) (struct net_device *dev,
         unsigned int txqueue);

 void (*ndo_get_stats64)(struct net_device *dev,
         struct rtnl_link_stats64 *storage);
 bool (*ndo_has_offload_stats)(const struct net_device *dev, int attr_id);
 int (*ndo_get_offload_stats)(int attr_id,
        const struct net_device *dev,
        void *attr_data);
 struct net_device_stats* (*ndo_get_stats)(struct net_device *dev);

 int (*ndo_vlan_rx_add_vid)(struct net_device *dev,
             __be16 proto, u16 vid);
 int (*ndo_vlan_rx_kill_vid)(struct net_device *dev,
              __be16 proto, u16 vid);

 void (*ndo_poll_controller)(struct net_device *dev);
 int (*ndo_netpoll_setup)(struct net_device *dev);
 void (*ndo_netpoll_cleanup)(struct net_device *dev);

 int (*ndo_set_vf_mac)(struct net_device *dev,
        int queue, u8 *mac);
 int (*ndo_set_vf_vlan)(struct net_device *dev,
         int queue, u16 vlan,
         u8 qos, __be16 proto);
 int (*ndo_set_vf_rate)(struct net_device *dev,
         int vf, int min_tx_rate,
         int max_tx_rate);
 int (*ndo_set_vf_spoofchk)(struct net_device *dev,
             int vf, bool setting);
 int (*ndo_set_vf_trust)(struct net_device *dev,
          int vf, bool setting);
 int (*ndo_get_vf_config)(struct net_device *dev,
           int vf,
           struct ifla_vf_info *ivf);
 int (*ndo_set_vf_link_state)(struct net_device *dev,
        int vf, int link_state);
 int (*ndo_get_vf_stats)(struct net_device *dev,
          int vf,
          struct ifla_vf_stats
          *vf_stats);
 int (*ndo_set_vf_port)(struct net_device *dev,
         int vf,
         struct nlattr *port[]);
 int (*ndo_get_vf_port)(struct net_device *dev,
         int vf, struct sk_buff *skb);
 int (*ndo_get_vf_guid)(struct net_device *dev,
         int vf,
         struct ifla_vf_guid *node_guid,
         struct ifla_vf_guid *port_guid);
 int (*ndo_set_vf_guid)(struct net_device *dev,
         int vf, u64 guid,
         int guid_type);
 int (*ndo_set_vf_rss_query_en)(
         struct net_device *dev,
         int vf, bool setting);
 int (*ndo_setup_tc)(struct net_device *dev,
      enum tc_setup_type type,
      void *type_data);

 int (*ndo_fcoe_enable)(struct net_device *dev);
 int (*ndo_fcoe_disable)(struct net_device *dev);
 int (*ndo_fcoe_ddp_setup)(struct net_device *dev,
            u16 xid,
            struct scatterlist *sgl,
            unsigned int sgc);
 int (*ndo_fcoe_ddp_done)(struct net_device *dev,
           u16 xid);
 int (*ndo_fcoe_ddp_target)(struct net_device *dev,
             u16 xid,
             struct scatterlist *sgl,
             unsigned int sgc);
 int (*ndo_fcoe_get_hbainfo)(struct net_device *dev,
       struct netdev_fcoe_hbainfo *hbainfo);



 int (*ndo_fcoe_get_wwn)(struct net_device *dev,
          u64 *wwn, int type);



 int (*ndo_rx_flow_steer)(struct net_device *dev,
           const struct sk_buff *skb,
           u16 rxq_index,
           u32 flow_id);

 int (*ndo_add_slave)(struct net_device *dev,
       struct net_device *slave_dev,
       struct netlink_ext_ack *extack);
 int (*ndo_del_slave)(struct net_device *dev,
       struct net_device *slave_dev);
 struct net_device* (*ndo_get_xmit_slave)(struct net_device *dev,
            struct sk_buff *skb,
            bool all_slaves);
 struct net_device* (*ndo_sk_get_lower_dev)(struct net_device *dev,
       struct sock *sk);
 netdev_features_t (*ndo_fix_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_set_features)(struct net_device *dev,
          netdev_features_t features);
 int (*ndo_neigh_construct)(struct net_device *dev,
             struct neighbour *n);
 void (*ndo_neigh_destroy)(struct net_device *dev,
           struct neighbour *n);

 int (*ndo_fdb_add)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            u16 flags,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del)(struct ndmsg *ndm,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid,
            bool *notified,
            struct netlink_ext_ack *extack);
 int (*ndo_fdb_del_bulk)(struct nlmsghdr *nlh,
          struct net_device *dev,
          struct netlink_ext_ack *extack);
 int (*ndo_fdb_dump)(struct sk_buff *skb,
      struct netlink_callback *cb,
      struct net_device *dev,
      struct net_device *filter_dev,
      int *idx);
 int (*ndo_fdb_get)(struct sk_buff *skb,
            struct nlattr *tb[],
            struct net_device *dev,
            const unsigned char *addr,
            u16 vid, u32 portid, u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_add)(struct net_device *dev,
            struct nlattr *tb[],
            u16 nlmsg_flags,
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del)(struct net_device *dev,
            struct nlattr *tb[],
            struct netlink_ext_ack *extack);
 int (*ndo_mdb_del_bulk)(struct net_device *dev,
          struct nlattr *tb[],
          struct netlink_ext_ack *extack);
 int (*ndo_mdb_dump)(struct net_device *dev,
      struct sk_buff *skb,
      struct netlink_callback *cb);
 int (*ndo_mdb_get)(struct net_device *dev,
            struct nlattr *tb[], u32 portid,
            u32 seq,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_setlink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags,
            struct netlink_ext_ack *extack);
 int (*ndo_bridge_getlink)(struct sk_buff *skb,
            u32 pid, u32 seq,
            struct net_device *dev,
            u32 filter_mask,
            int nlflags);
 int (*ndo_bridge_dellink)(struct net_device *dev,
            struct nlmsghdr *nlh,
            u16 flags);
 int (*ndo_change_carrier)(struct net_device *dev,
            bool new_carrier);
 int (*ndo_get_phys_port_id)(struct net_device *dev,
       struct netdev_phys_item_id *ppid);
 int (*ndo_get_port_parent_id)(struct net_device *dev,
         struct netdev_phys_item_id *ppid);
 int (*ndo_get_phys_port_name)(struct net_device *dev,
         char *name, size_t len);
 void* (*ndo_dfwd_add_station)(struct net_device *pdev,
       struct net_device *dev);
 void (*ndo_dfwd_del_station)(struct net_device *pdev,
       void *priv);

 int (*ndo_set_tx_maxrate)(struct net_device *dev,
            int queue_index,
            u32 maxrate);
 int (*ndo_get_iflink)(const struct net_device *dev);
 int (*ndo_fill_metadata_dst)(struct net_device *dev,
             struct sk_buff *skb);
 void (*ndo_set_rx_headroom)(struct net_device *dev,
             int needed_headroom);
 int (*ndo_bpf)(struct net_device *dev,
        struct netdev_bpf *bpf);
 int (*ndo_xdp_xmit)(struct net_device *dev, int n,
      struct xdp_frame **xdp,
      u32 flags);
 struct net_device * (*ndo_xdp_get_xmit_slave)(struct net_device *dev,
         struct xdp_buff *xdp);
 int (*ndo_xsk_wakeup)(struct net_device *dev,
        u32 queue_id, u32 flags);
 int (*ndo_tunnel_ctl)(struct net_device *dev,
        struct ip_tunnel_parm_kern *p,
        int cmd);
 struct net_device * (*ndo_get_peer_dev)(struct net_device *dev);
 int (*ndo_fill_forward_path)(struct net_device_path_ctx *ctx,
                                                         struct net_device_path *path);
 ktime_t (*ndo_get_tstamp)(struct net_device *dev,
        const struct skb_shared_hwtstamps *hwtstamps,
        bool cycles);
 int (*ndo_hwtstamp_get)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config);
 int (*ndo_hwtstamp_set)(struct net_device *dev,
          struct kernel_hwtstamp_config *kernel_config,
          struct netlink_ext_ack *extack);






 const struct net_shaper_ops *net_shaper_ops;

};
enum netdev_ml_priv_type {
 ML_PRIV_NONE,
 ML_PRIV_CAN,
};
enum netdev_stat_type {
 NETDEV_PCPU_STAT_NONE,
 NETDEV_PCPU_STAT_LSTATS,
 NETDEV_PCPU_STAT_TSTATS,
 NETDEV_PCPU_STAT_DSTATS,
};
struct net_device {






 __u8 __cacheline_group_begin__net_device_read_tx[1];
 union { struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } ; struct { unsigned long priv_flags:32; unsigned long lltx:1; unsigned long netmem_tx:1; } priv_flags_fast; }



  ;
 const struct net_device_ops *netdev_ops;
 const struct header_ops *header_ops;
 struct netdev_queue *_tx;
 netdev_features_t gso_partial_features;
 unsigned int real_num_tx_queues;
 unsigned int gso_max_size;
 unsigned int gso_ipv4_max_size;
 u16 gso_max_segs;
 s16 num_tc;





 unsigned int mtu;
 unsigned short needed_headroom;
 struct netdev_tc_txq tc_to_txq[16];

 struct xps_dev_maps *xps_maps[XPS_MAPS_MAX];


 struct nf_hook_entries *nf_hooks_egress;


 struct bpf_mprog_entry *tcx_egress;

 __u8 __cacheline_group_end__net_device_read_tx[1];


 __u8 __cacheline_group_begin__net_device_read_txrx[1];
 union {
  struct pcpu_lstats *lstats;
  struct pcpu_sw_netstats *tstats;
  struct pcpu_dstats *dstats;
 };
 unsigned long state;
 unsigned int flags;
 unsigned short hard_header_len;
 enum netdev_stat_type pcpu_stat_type:8;
 netdev_features_t features;
 struct inet6_dev *ip6_ptr;
 __u8 __cacheline_group_end__net_device_read_txrx[1];


 __u8 __cacheline_group_begin__net_device_read_rx[1];
 struct bpf_prog *xdp_prog;
 struct list_head ptype_specific;
 int ifindex;
 unsigned int real_num_rx_queues;
 struct netdev_rx_queue *_rx;
 unsigned int gro_max_size;
 unsigned int gro_ipv4_max_size;
 rx_handler_func_t *rx_handler;
 void *rx_handler_data;
 possible_net_t nd_net;

 struct netpoll_info *npinfo;


 struct bpf_mprog_entry *tcx_ingress;

 __u8 __cacheline_group_end__net_device_read_rx[1];

 char name[16];
 struct netdev_name_node *name_node;
 struct dev_ifalias *ifalias;




 unsigned long mem_end;
 unsigned long mem_start;
 unsigned long base_addr;
 struct list_head dev_list;
 struct list_head napi_list;
 struct list_head unreg_list;
 struct list_head close_list;
 struct list_head ptype_all;

 struct {
  struct list_head upper;
  struct list_head lower;
 } adj_list;


 xdp_features_t xdp_features;
 const struct xdp_metadata_ops *xdp_metadata_ops;
 const struct xsk_tx_metadata_ops *xsk_tx_metadata_ops;
 unsigned short gflags;

 unsigned short needed_tailroom;

 netdev_features_t hw_features;
 netdev_features_t wanted_features;
 netdev_features_t vlan_features;
 netdev_features_t hw_enc_features;
 netdev_features_t mpls_features;
 netdev_features_t mangleid_features;

 unsigned int min_mtu;
 unsigned int max_mtu;
 unsigned short type;
 unsigned char min_header_len;
 unsigned char name_assign_type;

 int group;

 struct net_device_stats stats;

 struct net_device_core_stats *core_stats;


 atomic_t carrier_up_count;
 atomic_t carrier_down_count;


 const struct iw_handler_def *wireless_handlers;

 const struct ethtool_ops *ethtool_ops;

 const struct l3mdev_ops *l3mdev_ops;


 const struct ndisc_ops *ndisc_ops;



 const struct xfrmdev_ops *xfrmdev_ops;



 const struct tlsdev_ops *tlsdev_ops;


 unsigned int operstate;
 unsigned char link_mode;

 unsigned char if_port;
 unsigned char dma;


 unsigned char perm_addr[32];
 unsigned char addr_assign_type;
 unsigned char addr_len;
 unsigned char upper_level;
 unsigned char lower_level;
 u8 threaded;

 unsigned short neigh_priv_len;
 unsigned short dev_id;
 unsigned short dev_port;
 int irq;
 u32 priv_len;

 spinlock_t addr_list_lock;

 struct netdev_hw_addr_list uc;
 struct netdev_hw_addr_list mc;
 struct netdev_hw_addr_list dev_addrs;


 struct kset *queues_kset;


 struct list_head unlink_list;

 unsigned int promiscuity;
 unsigned int allmulti;
 bool uc_promisc;

 unsigned char nested_level;




 struct in_device *ip_ptr;

 struct hlist_head fib_nh_head;


 struct vlan_info *vlan_info;


 struct dsa_port *dsa_ptr;


 struct tipc_bearer *tipc_ptr;


 void *atalk_ptr;


 struct ax25_dev *ax25_ptr;


 struct wireless_dev *ieee80211_ptr;


 struct wpan_dev *ieee802154_ptr;


 struct mpls_dev *mpls_ptr;


 struct mctp_dev *mctp_ptr;


 struct psp_dev *psp_dev;






 const unsigned char *dev_addr;

 unsigned int num_rx_queues;



 unsigned int xdp_zc_max_segs;
 struct netdev_queue *ingress_queue;

 struct nf_hook_entries *nf_hooks_ingress;


 unsigned char broadcast[32];

 struct cpu_rmap *rx_cpu_rmap;

 struct hlist_node index_hlist;




 unsigned int num_tx_queues;
 struct Qdisc *qdisc;
 unsigned int tx_queue_len;
 spinlock_t tx_global_lock;

 struct xdp_dev_bulk_queue *xdp_bulkq;


 struct hlist_head qdisc_hash[1 << (4)];


 struct timer_list watchdog_timer;
 int watchdog_timeo;
 spinlock_t watchdog_lock;
 bool watchdog_ref_held;

 u32 proto_down_reason;

 struct list_head todo_list;


 int *pcpu_refcnt;



 struct ref_tracker_dir refcnt_tracker;

 struct list_head link_watch_list;

 u8 reg_state;

 bool dismantle;


 bool moving_ns;

 bool rtnl_link_initializing;

 bool needs_free_netdev;
 void (*priv_destructor)(struct net_device *dev);


 void *ml_priv;
 enum netdev_ml_priv_type ml_priv_type;


 struct garp_port *garp_port;


 struct mrp_port *mrp_port;


 struct dm_hw_stat_delta *dm_private;

 struct device dev;
 const struct attribute_group *sysfs_groups[5];
 const struct attribute_group *sysfs_rx_queue_group;

 const struct rtnl_link_ops *rtnl_link_ops;

 const struct netdev_stat_ops *stat_ops;

 const struct netdev_queue_mgmt_ops *queue_mgmt_ops;






 unsigned int tso_max_size;
 u16 tso_max_segs;


 const struct dcbnl_rtnl_ops *dcbnl_ops;

 u8 prio_tc_map[15 + 1];


 unsigned int fcoe_ddp_xid;


 struct netprio_map *priomap;

 struct phy_link_topology *link_topo;
 struct phy_device *phydev;
 struct sfp_bus *sfp_bus;
 struct lock_class_key *qdisc_tx_busylock;
 bool proto_down;
 bool irq_affinity_auto;
 bool rx_cpu_rmap_auto;


 unsigned long see_all_hwtstamp_requests:1;
 unsigned long change_proto_down:1;
 unsigned long netns_immutable:1;
 unsigned long fcoe_mtu:1;

 struct list_head net_notifier_list;



 const struct macsec_ops *macsec_ops;

 const struct udp_tunnel_nic_info *udp_tunnel_nic_info;
 struct udp_tunnel_nic *udp_tunnel_nic;


 struct netdev_config *cfg;





 struct netdev_config *cfg_pending;
 struct ethtool_netdev_state *ethtool;


 struct bpf_xdp_entity xdp_state[__MAX_XDP_MODE];

 u8 dev_addr_shadow[32];
 netdevice_tracker linkwatch_dev_tracker;
 netdevice_tracker watchdog_dev_tracker;
 netdevice_tracker dev_registered_tracker;
 struct rtnl_hw_stats64 *offload_xstats_l3;

 struct devlink_port *devlink_port;


 struct dpll_pin *dpll_pin;



 struct hlist_head page_pools;



 struct dim_irq_moder *irq_moder;

 u64 max_pacing_offload_horizon;
 struct napi_config *napi_config;
 u32 num_napi_configs;
 u32 napi_defer_hard_irqs;
 unsigned long gro_flush_timeout;






 bool up;





 bool request_ops_lock;
 struct mutex lock;






 struct net_shaper_hierarchy *net_shaper_hierarchy;


 struct hlist_head neighbours[NEIGH_NR_TABLES];

 struct hwtstamp_provider *hwprov;

 u8 priv[1] 
           ;
} ;
static inline    void netdev_lock(struct net_device *dev)
;
struct pcpu_sw_netstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 struct u64_stats_sync syncp;
} ;
struct pcpu_dstats {
 u64_stats_t rx_packets;
 u64_stats_t rx_bytes;
 u64_stats_t tx_packets;
 u64_stats_t tx_bytes;
 u64_stats_t rx_drops;
 u64_stats_t tx_drops;
 struct u64_stats_sync syncp;
} ;
struct pcpu_lstats {
 u64_stats_t packets;
 u64_stats_t bytes;
 struct u64_stats_sync syncp;
} ;
struct numa_drop_counters {
 atomic_t drops0 ;
 atomic_t drops1 ;
};
struct pollfd {
 int fd;
 short events;
 short revents;
};
struct poll_table_struct;
typedef void (*poll_queue_proc)(struct file *, wait_queue_head_t *, struct poll_table_struct *);
typedef struct poll_table_struct {
 poll_queue_proc _qproc;
 __poll_t _key;
} poll_table;
enum {
 RTAX_UNSPEC,
 RTAX_LOCK,
 RTAX_MTU,
 RTAX_WINDOW,
 RTAX_RTT,
 RTAX_RTTVAR,
 RTAX_SSTHRESH,
 RTAX_CWND,
 RTAX_ADVMSS,
 RTAX_REORDERING,
 RTAX_HOPLIMIT,
 RTAX_INITCWND,
 RTAX_FEATURES,
 RTAX_RTO_MIN,
 RTAX_INITRWND,
 RTAX_QUICKACK,
 RTAX_CC_ALGO,
 RTAX_FASTOPEN_NO_COOKIE,
 __RTAX_MAX
};
struct tcmsg {
 unsigned char tcm_family;
 unsigned char tcm__pad1;
 unsigned short tcm__pad2;
 int tcm_ifindex;
 __u32 tcm_handle;
 __u32 tcm_parent;



 __u32 tcm_info;
};
struct netlink_range_validation {
 u64 min, max;
};
struct netlink_range_validation_signed {
 s64 min, max;
};
struct nla_policy {
 u8 type;
 u8 validation_type;
 u16 len;
 union {
  u16 strict_start_type;


  const u32 bitfield32_valid;
  const u32 mask;
  const char *reject_message;
  const struct nla_policy *nested_policy;
  const struct netlink_range_validation *range;
  const struct netlink_range_validation_signed *range_signed;
  struct {
   s16 min, max;
  };
  int (*validate)(const struct nlattr *attr,
    struct netlink_ext_ack *extack);
 };
};
static inline    int nlmsg_len(const struct nlmsghdr *nlh)
;
static inline    void *nlmsg_payload(const struct nlmsghdr *nlh, size_t len)
;
static inline    u32 nlmsg_seq(const struct nlmsghdr *nlh)
;
static inline    int nla_type(const struct nlattr *nla)
;
static inline    u16 nla_len(const struct nlattr *nla)
;
struct rtnl_newlink_params {
 struct net *src_net;
 struct net *link_net;
 struct net *peer_net;
 struct nlattr **tb;
 struct nlattr **data;
};
struct rtnl_link_ops {
 struct list_head list;
 struct srcu_struct srcu;

 const char *kind;

 size_t priv_size;
 struct net_device *(*alloc)(struct nlattr *tb[],
       const char *ifname,
       unsigned char name_assign_type,
       unsigned int num_tx_queues,
       unsigned int num_rx_queues);
 void (*setup)(struct net_device *dev);

 bool netns_refund;
 const u16 peer_type;
 unsigned int maxtype;
 const struct nla_policy *policy;
 int (*validate)(struct nlattr *tb[],
         struct nlattr *data[],
         struct netlink_ext_ack *extack);

 int (*newlink)(struct net_device *dev,
        struct rtnl_newlink_params *params,
        struct netlink_ext_ack *extack);
 int (*changelink)(struct net_device *dev,
           struct nlattr *tb[],
           struct nlattr *data[],
           struct netlink_ext_ack *extack);
 void (*dellink)(struct net_device *dev,
        struct list_head *head);

 size_t (*get_size)(const struct net_device *dev);
 int (*fill_info)(struct sk_buff *skb,
          const struct net_device *dev);

 size_t (*get_xstats_size)(const struct net_device *dev);
 int (*fill_xstats)(struct sk_buff *skb,
            const struct net_device *dev);
 unsigned int (*get_num_tx_queues)(void);
 unsigned int (*get_num_rx_queues)(void);

 unsigned int slave_maxtype;
 const struct nla_policy *slave_policy;
 int (*slave_changelink)(struct net_device *dev,
          struct net_device *slave_dev,
          struct nlattr *tb[],
          struct nlattr *data[],
          struct netlink_ext_ack *extack);
 size_t (*get_slave_size)(const struct net_device *dev,
        const struct net_device *slave_dev);
 int (*fill_slave_info)(struct sk_buff *skb,
         const struct net_device *dev,
         const struct net_device *slave_dev);
 struct net *(*get_link_net)(const struct net_device *dev);
 size_t (*get_linkxstats_size)(const struct net_device *dev,
             int attr);
 int (*fill_linkxstats)(struct sk_buff *skb,
         const struct net_device *dev,
         int *prividx, int attr);
};
struct neighbour;
enum {
 NEIGH_VAR_MCAST_PROBES,
 NEIGH_VAR_UCAST_PROBES,
 NEIGH_VAR_APP_PROBES,
 NEIGH_VAR_MCAST_REPROBES,
 NEIGH_VAR_RETRANS_TIME,
 NEIGH_VAR_BASE_REACHABLE_TIME,
 NEIGH_VAR_DELAY_PROBE_TIME,
 NEIGH_VAR_INTERVAL_PROBE_TIME_MS,
 NEIGH_VAR_GC_STALETIME,
 NEIGH_VAR_QUEUE_LEN_BYTES,
 NEIGH_VAR_PROXY_QLEN,
 NEIGH_VAR_ANYCAST_DELAY,
 NEIGH_VAR_PROXY_DELAY,
 NEIGH_VAR_LOCKTIME,

 NEIGH_VAR_QUEUE_LEN,
 NEIGH_VAR_RETRANS_TIME_MS,
 NEIGH_VAR_BASE_REACHABLE_TIME_MS,

 NEIGH_VAR_GC_INTERVAL,
 NEIGH_VAR_GC_THRESH1,
 NEIGH_VAR_GC_THRESH2,
 NEIGH_VAR_GC_THRESH3,
 NEIGH_VAR_MAX
};
struct neigh_parms {
 possible_net_t net;
 struct net_device *dev;
 netdevice_tracker dev_tracker;
 struct list_head list;
 int (*neigh_setup)(struct neighbour *);
 struct neigh_table *tbl;

 void *sysctl_table;

 int dead;
 refcount_t refcnt;
 struct callback_head callback_head;

 int reachable_time;
 u32 qlen;
 int data[(NEIGH_VAR_LOCKTIME + 1)];
 unsigned long data_state[((((NEIGH_VAR_LOCKTIME + 1)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct neigh_statistics {
 unsigned long allocs;
 unsigned long destroys;
 unsigned long hash_grows;

 unsigned long res_failed;

 unsigned long lookups;
 unsigned long hits;

 unsigned long rcv_probes_mcast;
 unsigned long rcv_probes_ucast;

 unsigned long periodic_gc_runs;
 unsigned long forced_gc_runs;

 unsigned long unres_discards;
 unsigned long table_fulls;
};
struct neighbour {
 struct hlist_node hash;
 struct hlist_node dev_list;
 struct neigh_table *tbl;
 struct neigh_parms *parms;
 unsigned long confirmed;
 unsigned long updated;
 rwlock_t lock;
 refcount_t refcnt;
 unsigned int arp_queue_len_bytes;
 struct sk_buff_head arp_queue;
 struct timer_list timer;
 unsigned long used;
 atomic_t probes;
 u8 nud_state;
 u8 type;
 u8 dead;
 u8 protocol;
 u32 flags;
 seqlock_t ha_lock;
 unsigned char ha[((((32)) + ((__typeof__((32)))((sizeof(unsigned long))) - 1)) & ~((__typeof__((32)))((sizeof(unsigned long))) - 1))] ;
 struct hh_cache hh;
 int (*output)(struct neighbour *, struct sk_buff *);
 const struct neigh_ops *ops;
 struct list_head gc_list;
 struct list_head managed_list;
 struct callback_head rcu;
 struct net_device *dev;
 netdevice_tracker dev_tracker;
 u8 primary_key[1];
} ;
struct neigh_ops {
 int family;
 void (*solicit)(struct neighbour *, struct sk_buff *);
 void (*error_report)(struct neighbour *, struct sk_buff *);
 int (*output)(struct neighbour *, struct sk_buff *);
 int (*connected_output)(struct neighbour *, struct sk_buff *);
};
struct pneigh_entry {
 struct pneigh_entry *next;
 possible_net_t net;
 struct net_device *dev;
 netdevice_tracker dev_tracker;
 union {
  struct list_head free_node;
  struct callback_head rcu;
 };
 u32 flags;
 u8 protocol;
 bool permanent;
 u32 key[1];
};
struct neigh_hash_table {
 struct hlist_head *hash_heads;
 unsigned int hash_shift;
 __u32 hash_rnd[4];
 struct callback_head rcu;
};
struct neigh_table {
 int family;
 unsigned int entry_size;
 unsigned int key_len;
 __be16 protocol;
 __u32 (*hash)(const void *pkey,
     const struct net_device *dev,
     __u32 *hash_rnd);
 bool (*key_eq)(const struct neighbour *, const void *pkey);
 int (*constructor)(struct neighbour *);
 int (*pconstructor)(struct pneigh_entry *);
 void (*pdestructor)(struct pneigh_entry *);
 void (*proxy_redo)(struct sk_buff *skb);
 int (*is_multicast)(const void *pkey);
 bool (*allow_add)(const struct net_device *dev,
          struct netlink_ext_ack *extack);
 char *id;
 struct neigh_parms parms;
 struct list_head parms_list;
 int gc_interval;
 int gc_thresh1;
 int gc_thresh2;
 int gc_thresh3;
 unsigned long last_flush;
 struct delayed_work gc_work;
 struct delayed_work managed_work;
 struct timer_list proxy_timer;
 struct sk_buff_head proxy_queue;
 atomic_t entries;
 atomic_t gc_entries;
 struct list_head gc_list;
 struct list_head managed_list;
 rwlock_t lock;
 unsigned long last_rand;
 struct neigh_statistics *stats;
 struct neigh_hash_table *nht;
 struct mutex phash_lock;
 struct pneigh_entry **phash_buckets;
};
struct neighbour *neigh_lookup(struct neigh_table *tbl, const void *pkey,
          struct net_device *dev);
struct sk_buff;
struct dst_entry {
 union {
  struct net_device *dev;
  struct net_device *dev_rcu;
 };
 struct dst_ops *ops;
 unsigned long _metrics;
 unsigned long expires;

 struct xfrm_state *xfrm;



 int (*input)(struct sk_buff *);
 int (*output)(struct net *net, struct sock *sk, struct sk_buff *skb);

 unsigned short flags;
 short obsolete;
 unsigned short header_len;
 unsigned short trailer_len;






 rcuref_t __rcuref;

 int __use;
 unsigned long lastuse;
 struct callback_head callback_head;
 short error;
 short __pad;
 __u32 tclassid;




 netdevice_tracker dev_tracker;
 struct list_head rt_uncached;
 struct uncached_list *rt_uncached_list;

 struct lwtunnel_state *lwtstate;

};
struct dst_metrics {
 u32 metrics[(__RTAX_MAX - 1)];
 refcount_t refcnt;
} ;
struct flowi;
enum hwtstamp_provider_qualifier {
 HWTSTAMP_PROVIDER_QUALIFIER_PRECISE,
 HWTSTAMP_PROVIDER_QUALIFIER_APPROX,

 HWTSTAMP_PROVIDER_QUALIFIER_CNT,
};
struct so_timestamping {
 int flags;
 int bind_phc;
};
enum hwtstamp_source {
 HWTSTAMP_SOURCE_NETDEV = 1,
 HWTSTAMP_SOURCE_PHYLIB,
};
struct hwtstamp_provider_desc {
 int index;
 enum hwtstamp_provider_qualifier qualifier;
};
struct hwtstamp_provider {
 struct callback_head callback_head;
 enum hwtstamp_source source;
 struct phy_device *phydev;
 struct hwtstamp_provider_desc desc;
};
struct kernel_hwtstamp_config {
 int flags;
 int tx_type;
 int rx_filter;
 struct ifreq *ifr;
 bool copied_to_user;
 enum hwtstamp_source source;
 enum hwtstamp_provider_qualifier qualifier;
};
struct fib_rule_hdr {
 __u8 family;
 __u8 dst_len;
 __u8 src_len;
 __u8 tos;

 __u8 table;
 __u8 res1;
 __u8 res2;
 __u8 action;

 __u32 flags;
};
struct fib_rule_port_range {
 __u16 start;
 __u16 end;
};
struct module;
struct fib_notifier_ops {
 int family;
 struct list_head list;
 unsigned int (*fib_seq_read)(const struct net *net);
 int (*fib_dump)(struct net *net, struct notifier_block *nb,
   struct netlink_ext_ack *extack);
 struct module *owner;
 struct callback_head rcu;
};
struct fib_kuid_range {
 kuid_t start;
 kuid_t end;
};
struct fib_rule {
 struct list_head list;
 int iifindex;
 int oifindex;
 u32 mark;
 u32 mark_mask;
 u32 flags;
 u32 table;
 u8 action;
 u8 l3mdev;
 u8 proto;
 u8 ip_proto;
 u32 target;
 __be64 tun_id;
 struct fib_rule *ctarget;
 struct net *fr_net;

 refcount_t refcnt;
 u32 pref;
 int suppress_ifgroup;
 int suppress_prefixlen;
 char iifname[16];
 char oifname[16];
 struct fib_kuid_range uid_range;
 struct fib_rule_port_range sport_range;
 struct fib_rule_port_range dport_range;
 u16 sport_mask;
 u16 dport_mask;
 u8 iif_is_l3_master;
 u8 oif_is_l3_master;
 struct callback_head rcu;
};
struct fib_lookup_arg {
 void *lookup_ptr;
 const void *lookup_data;
 void *result;
 struct fib_rule *rule;
 u32 table;
 int flags;
};
struct fib_rules_ops {
 int family;
 struct list_head list;
 int rule_size;
 int addr_size;
 int unresolved_rules;
 int nr_goto_rules;
 unsigned int fib_rules_seq;

 int (*action)(struct fib_rule *,
       struct flowi *, int,
       struct fib_lookup_arg *);
 bool (*suppress)(struct fib_rule *, int,
         struct fib_lookup_arg *);
 int (*match)(struct fib_rule *,
      struct flowi *, int);
 int (*configure)(struct fib_rule *,
          struct sk_buff *,
          struct fib_rule_hdr *,
          struct nlattr **,
          struct netlink_ext_ack *);
 int (*delete)(struct fib_rule *);
 int (*compare)(struct fib_rule *,
        struct fib_rule_hdr *,
        struct nlattr **);
 int (*fill)(struct fib_rule *, struct sk_buff *,
     struct fib_rule_hdr *);
 size_t (*nlmsg_payload)(struct fib_rule *);



 void (*flush_cache)(struct fib_rules_ops *ops);

 int nlgroup;
 struct list_head rules_list;
 struct module *owner;
 struct net *fro_net;
 struct callback_head rcu;
};
struct l3mdev_ops {
 u32 (*l3mdev_fib_table)(const struct net_device *dev);
 struct sk_buff * (*l3mdev_l3_rcv)(struct net_device *dev,
       struct sk_buff *skb, u16 proto);
 struct sk_buff * (*l3mdev_l3_out)(struct net_device *dev,
       struct sock *sk, struct sk_buff *skb,
       u16 proto);


 struct dst_entry * (*l3mdev_link_scope_lookup)(const struct net_device *dev,
       struct flowi6 *fl6);
};
static inline    u32 l3mdev_fib_table(const struct net_device *dev)
;
struct dst_entry *l3mdev_link_scope_lookup(struct net *net, struct flowi6 *fl6);
static inline   
struct sk_buff *l3mdev_l3_rcv(struct sk_buff *skb, u16 proto)
;
static inline   
struct sk_buff *l3mdev_l3_out(struct sock *sk, struct sk_buff *skb, u16 proto)
;
typedef struct {
 spinlock_t slock;
 int owned;
 wait_queue_head_t wq;







 struct lockdep_map dep_map;

} socket_lock_t;
struct sock;
struct proto;
struct net;
typedef __u32 __portpair;
typedef __u64 __addrpair;
struct sock_common {
 union {
  __addrpair skc_addrpair;
  struct {
   __be32 skc_daddr;
   __be32 skc_rcv_saddr;
  };
 };
 union {
  unsigned int skc_hash;
  __u16 skc_u16hashes[2];
 };

 union {
  __portpair skc_portpair;
  struct {
   __be16 skc_dport;
   __u16 skc_num;
  };
 };

 unsigned short skc_family;
 volatile unsigned char skc_state;
 unsigned char skc_reuse:4;
 unsigned char skc_reuseport:1;
 unsigned char skc_ipv6only:1;
 unsigned char skc_net_refcnt:1;
 int skc_bound_dev_if;
 union {
  struct hlist_node skc_bind_node;
  struct hlist_node skc_portaddr_node;
 };
 struct proto *skc_prot;
 possible_net_t skc_net;


 struct in6_addr skc_v6_daddr;
 struct in6_addr skc_v6_rcv_saddr;


 atomic64_t skc_cookie;






 union {
  unsigned long skc_flags;
  struct sock *skc_listener;
  struct inet_timewait_death_row *skc_tw_dr;
 };





 int skc_dontcopy_begin[1];

 union {
  struct hlist_node skc_node;
  struct hlist_nulls_node skc_nulls_node;
 };
 unsigned short skc_tx_queue_mapping;

 unsigned short skc_rx_queue_mapping;

 union {
  int skc_incoming_cpu;
  u32 skc_rcv_wnd;
  u32 skc_tw_rcv_nxt;
 };

 refcount_t skc_refcnt;

 int skc_dontcopy_end[1];
 union {
  u32 skc_rxhash;
  u32 skc_window_clamp;
  u32 skc_tw_snd_nxt;
 };

};
struct bpf_local_storage;
struct sk_filter;
struct sock {




 struct sock_common __sk_common;




 __u8 __cacheline_group_begin__sock_write_rx[1];

 atomic_t sk_drops;
 __s32 sk_peek_off;
 struct sk_buff_head sk_error_queue;
 struct sk_buff_head sk_receive_queue;
 struct {
  atomic_t rmem_alloc;
  int len;
  struct sk_buff *head;
  struct sk_buff *tail;
 } sk_backlog;

 __u8 __cacheline_group_end__sock_write_rx[1];

 __u8 __cacheline_group_begin__sock_read_rx[1];

 struct dst_entry *sk_rx_dst;
 int sk_rx_dst_ifindex;
 u32 sk_rx_dst_cookie;


 unsigned int sk_ll_usec;
 unsigned int sk_napi_id;
 u16 sk_busy_poll_budget;
 u8 sk_prefer_busy_poll;

 u8 sk_userlocks;
 int sk_rcvbuf;

 struct sk_filter *sk_filter;
 union {
  struct socket_wq *sk_wq;

  struct socket_wq *sk_wq_raw;

 };

 void (*sk_data_ready)(struct sock *sk);
 long sk_rcvtimeo;
 int sk_rcvlowat;
 __u8 __cacheline_group_end__sock_read_rx[1];

 __u8 __cacheline_group_begin__sock_read_rxtx[1];
 int sk_err;
 struct socket *sk_socket;

 struct mem_cgroup *sk_memcg;


 struct xfrm_policy *sk_policy[2];


 struct psp_assoc *psp_assoc;

 __u8 __cacheline_group_end__sock_read_rxtx[1];

 __u8 __cacheline_group_begin__sock_write_rxtx[1];
 socket_lock_t sk_lock;
 u32 sk_reserved_mem;
 int sk_forward_alloc;
 u32 sk_tsflags;
 __u8 __cacheline_group_end__sock_write_rxtx[1];

 __u8 __cacheline_group_begin__sock_write_tx[1];
 int sk_write_pending;
 atomic_t sk_omem_alloc;
 int sk_err_soft;

 int sk_wmem_queued;
 refcount_t sk_wmem_alloc;
 unsigned long sk_tsq_flags;
 union {
  struct sk_buff *sk_send_head;
  struct rb_root tcp_rtx_queue;
 };
 struct sk_buff_head sk_write_queue;
 u32 sk_dst_pending_confirm;
 u32 sk_pacing_status;
 struct page_frag sk_frag;
 union {
  struct timer_list sk_timer;
  struct timer_list tcp_retransmit_timer;
  struct timer_list mptcp_retransmit_timer;
 };
 unsigned long sk_pacing_rate;
 atomic_t sk_zckey;
 atomic_t sk_tskey;
 __u8 __cacheline_group_end__sock_write_tx[1];

 __u8 __cacheline_group_begin__sock_read_tx[1];
 unsigned long sk_max_pacing_rate;
 long sk_sndtimeo;
 u32 sk_priority;
 u32 sk_mark;
 kuid_t sk_uid;
 u16 sk_protocol;
 u16 sk_type;
 struct dst_entry *sk_dst_cache;
 netdev_features_t sk_route_caps;

 struct sk_buff* (*sk_validate_xmit_skb)(struct sock *sk,
       struct net_device *dev,
       struct sk_buff *skb);

 u16 sk_gso_type;
 u16 sk_gso_max_segs;
 unsigned int sk_gso_max_size;
 gfp_t sk_allocation;
 u32 sk_txhash;
 int sk_sndbuf;
 u8 sk_pacing_shift;
 bool sk_use_task_frag;
 __u8 __cacheline_group_end__sock_read_tx[1];





 u8 sk_gso_disabled : 1,
    sk_kern_sock : 1,
    sk_no_check_tx : 1,
    sk_no_check_rx : 1;
 u8 sk_shutdown;
 unsigned long sk_lingertime;
 struct proto *sk_prot_creator;
 rwlock_t sk_callback_lock;
 u32 sk_ack_backlog;
 u32 sk_max_ack_backlog;
 unsigned long sk_ino;
 spinlock_t sk_peer_lock;
 int sk_bind_phc;
 struct pid *sk_peer_pid;
 const struct cred *sk_peer_cred;

 ktime_t sk_stamp;



 int sk_disconnects;

 union {
  u8 sk_txrehash;
  u8 sk_scm_recv_flags;
  struct {
   u8 sk_scm_credentials : 1,
    sk_scm_security : 1,
    sk_scm_pidfd : 1,
    sk_scm_rights : 1,
    sk_scm_unused : 4;
  };
 };
 u8 sk_clockid;
 u8 sk_txtime_deadline_mode : 1,
    sk_txtime_report_errors : 1,
    sk_txtime_unused : 6;
 u8 sk_bpf_cb_flags;

 void *sk_user_data;

 void *sk_security;

 struct sock_cgroup_data sk_cgrp_data;
 void (*sk_state_change)(struct sock *sk);
 void (*sk_write_space)(struct sock *sk);
 void (*sk_error_report)(struct sock *sk);
 int (*sk_backlog_rcv)(struct sock *sk,
        struct sk_buff *skb);
 void (*sk_destruct)(struct sock *sk);
 struct sock_reuseport *sk_reuseport_cb;

 struct bpf_local_storage *sk_bpf_storage;

 struct numa_drop_counters *sk_drop_counters;
 struct callback_head sk_rcu;
 netns_tracker ns_tracker;
 struct xarray sk_user_frags;


 struct module *sk_owner;

};
static inline    int sk_backlog_rcv(struct sock *sk, struct sk_buff *skb)
;
struct request_sock_ops;
struct timewait_sock_ops;
struct inet_hashinfo;
struct raw_hashinfo;
struct smc_hashinfo;
struct module;
struct sk_psock;
struct proto_accept_arg {
 int flags;
 int err;
 int is_empty;
 bool kern;
};
struct proto {
 void (*close)(struct sock *sk,
     long timeout);
 int (*pre_connect)(struct sock *sk,
     struct sockaddr *uaddr,
     int addr_len);
 int (*connect)(struct sock *sk,
     struct sockaddr *uaddr,
     int addr_len);
 int (*disconnect)(struct sock *sk, int flags);

 struct sock * (*accept)(struct sock *sk,
       struct proto_accept_arg *arg);

 int (*ioctl)(struct sock *sk, int cmd,
      int *karg);
 int (*init)(struct sock *sk);
 void (*destroy)(struct sock *sk);
 void (*shutdown)(struct sock *sk, int how);
 int (*setsockopt)(struct sock *sk, int level,
     int optname, sockptr_t optval,
     unsigned int optlen);
 int (*getsockopt)(struct sock *sk, int level,
     int optname, char *optval,
     int *option);
 void (*keepalive)(struct sock *sk, int valbool);

 int (*compat_ioctl)(struct sock *sk,
     unsigned int cmd, unsigned long arg);

 int (*sendmsg)(struct sock *sk, struct msghdr *msg,
        size_t len);
 int (*recvmsg)(struct sock *sk, struct msghdr *msg,
        size_t len, int flags);
 void (*splice_eof)(struct socket *sock);
 int (*bind)(struct sock *sk,
     struct sockaddr *addr, int addr_len);
 int (*bind_add)(struct sock *sk,
     struct sockaddr *addr, int addr_len);

 int (*backlog_rcv) (struct sock *sk,
      struct sk_buff *skb);
 bool (*bpf_bypass_getsockopt)(int level,
        int optname);

 void (*release_cb)(struct sock *sk);


 int (*hash)(struct sock *sk);
 void (*unhash)(struct sock *sk);
 void (*rehash)(struct sock *sk);
 int (*get_port)(struct sock *sk, unsigned short snum);
 void (*put_port)(struct sock *sk);

 int (*psock_update_sk_prot)(struct sock *sk,
       struct sk_psock *psock,
       bool restore);




 unsigned int inuse_idx;


 bool (*stream_memory_free)(const struct sock *sk, int wake);
 bool (*sock_is_readable)(struct sock *sk);

 void (*enter_memory_pressure)(struct sock *sk);
 void (*leave_memory_pressure)(struct sock *sk);
 atomic_long_t *memory_allocated;
 int *per_cpu_fw_alloc;
 struct percpu_counter *sockets_allocated;
 unsigned long *memory_pressure;
 long *sysctl_mem;

 int *sysctl_wmem;
 int *sysctl_rmem;
 u32 sysctl_wmem_offset;
 u32 sysctl_rmem_offset;

 int max_header;
 bool no_autobind;

 struct kmem_cache *slab;
 unsigned int obj_size;
 unsigned int ipv6_pinfo_offset;
 slab_flags_t slab_flags;
 unsigned int useroffset;
 unsigned int usersize;

 struct request_sock_ops *rsk_prot;
 struct timewait_sock_ops *twsk_prot;

 union {
  struct inet_hashinfo *hashinfo;
  struct udp_table *udp_table;
  struct raw_hashinfo *raw_hash;
  struct smc_hashinfo *smc_hash;
 } h;

 struct module *owner;

 char name[32];

 struct list_head node;
 int (*diag_destroy)(struct sock *sk, int err);
} ;
struct prot_inuse {
 int all;
 int val[64];
};
void sk_destruct(struct sock *sk);
static inline    kuid_t sk_uid(const struct sock *sk)
;
void sk_error_report(struct sock *sk);
enum sk_rst_reason {





 SK_RST_REASON_NOT_SPECIFIED,

 SK_RST_REASON_NO_SOCKET,





 SK_RST_REASON_TCP_INVALID_ACK_SEQUENCE,




 SK_RST_REASON_TCP_RFC7323_PAWS,

 SK_RST_REASON_TCP_TOO_OLD_ACK,




 SK_RST_REASON_TCP_ACK_UNSENT_DATA,

 SK_RST_REASON_TCP_FLAGS,

 SK_RST_REASON_TCP_OLD_ACK,




 SK_RST_REASON_TCP_ABORT_ON_DATA,



 SK_RST_REASON_TCP_TIMEWAIT_SOCKET,






 SK_RST_REASON_INVALID_SYN,




 SK_RST_REASON_TCP_ABORT_ON_CLOSE,




 SK_RST_REASON_TCP_ABORT_ON_LINGER,




 SK_RST_REASON_TCP_ABORT_ON_MEMORY,




 SK_RST_REASON_TCP_STATE,





 SK_RST_REASON_TCP_KEEPALIVE_TIMEOUT,






 SK_RST_REASON_TCP_DISCONNECT_WITH_DATA,
 SK_RST_REASON_MPTCP_RST_EUNSPEC,






 SK_RST_REASON_MPTCP_RST_EMPTCP,





 SK_RST_REASON_MPTCP_RST_ERESOURCE,





 SK_RST_REASON_MPTCP_RST_EPROHIBIT,
 SK_RST_REASON_MPTCP_RST_EWQ2BIG,






 SK_RST_REASON_MPTCP_RST_EBADPERF,






 SK_RST_REASON_MPTCP_RST_EMIDDLEBOX,


 SK_RST_REASON_ERROR,





 SK_RST_REASON_MAX,
};
struct request_sock;
struct sk_buff;
struct dst_entry;
struct proto;
struct request_sock_ops {
 int family;
 unsigned int obj_size;
 struct kmem_cache *slab;
 char *slab_name;
 void (*send_ack)(const struct sock *sk, struct sk_buff *skb,
        struct request_sock *req);
 void (*send_reset)(const struct sock *sk,
          struct sk_buff *skb,
          enum sk_rst_reason reason);
 void (*destructor)(struct request_sock *req);
 void (*syn_ack_timeout)(const struct request_sock *req);
};
struct saved_syn {
 u32 mac_hdrlen;
 u32 network_hdrlen;
 u32 tcp_hdrlen;
 u8 data[1];
};
struct request_sock {
 struct sock_common __req_common;

 struct request_sock *dl_next;
 u16 mss;
 u8 num_retrans;
 u8 syncookie:1;




 u8 num_timeout:7;
 u32 ts_recent;
 struct timer_list rsk_timer;
 const struct request_sock_ops *rsk_ops;
 struct sock *sk;
 struct saved_syn *saved_syn;
 u32 secid;
 u32 peer_secid;
 u32 timeout;
};
struct ip_options {
 __be32 faddr;
 __be32 nexthop;
 unsigned char optlen;
 unsigned char srr;
 unsigned char rr;
 unsigned char ts;
 unsigned char is_strictroute:1,
   srr_is_hit:1,
   is_changed:1,
   rr_needaddr:1,
   ts_needtime:1,
   ts_needaddr:1;
 unsigned char router_alert;
 unsigned char cipso;
 unsigned char __pad2;
 unsigned char __data[1];
};
struct ip_options_rcu {
 struct callback_head rcu;
 struct ip_options opt;
};
struct inet_cork {
 unsigned int flags;
 __be32 addr;
 struct ip_options *opt;
 unsigned int fragsize;
 int length;
 struct dst_entry *dst;
 u8 tx_flags;
 __u8 ttl;
 __s16 tos;
 u32 priority;
 __u16 gso_size;
 u32 ts_opt_id;
 u64 transmit_time;
 u32 mark;
};
struct inet_cork_full {
 struct inet_cork base;
 struct flowi fl;
};
struct ip_mc_socklist;
struct ipv6_pinfo;
struct rtable;
struct inet_sock {

 struct sock sk;

 struct ipv6_pinfo *pinet6;
 struct ipv6_fl_socklist *ipv6_fl_list;



 unsigned long inet_flags;
 __be32 inet_saddr;
 __s16 uc_ttl;
 __be16 inet_sport;
 struct ip_options_rcu *inet_opt;
 atomic_t inet_id;

 __u8 tos;
 __u8 min_ttl;
 __u8 mc_ttl;
 __u8 pmtudisc;
 __u8 rcv_tos;
 __u8 convert_csum;
 int uc_index;
 int mc_index;
 __be32 mc_addr;
 u32 local_port_range;

 struct ip_mc_socklist *mc_list;
 struct inet_cork_full cork;
};
struct tcp_congestion_ops;
struct timewait_sock_ops {
 struct kmem_cache *twsk_slab;
 char *twsk_slab_name;
 unsigned int twsk_obj_size;
};
static inline    unsigned int tcp_hdrlen(const struct sk_buff *skb)
;
struct in6_pktinfo {
 struct in6_addr ipi6_addr;
 int ipi6_ifindex;
};
struct ipv6_rt_hdr {
 __u8 nexthdr;
 __u8 hdrlen;
 __u8 type;
 __u8 segments_left;





};
struct ipv6_opt_hdr {
 __u8 nexthdr;
 __u8 hdrlen;



} __attribute__((packed));
struct ipv6hdr {

 __u8 priority:4,
    version:4;






 __u8 flow_lbl[3];

 __be16 payload_len;
 __u8 nexthdr;
 __u8 hop_limit;

 union { struct { struct in6_addr saddr; struct in6_addr daddr; } ; struct { struct in6_addr saddr; struct in6_addr daddr; } addrs; }


  ;
};
struct ipv6_devconf {

 __u8 __cacheline_group_begin__ipv6_devconf_read_txrx[1];
 __s32 disable_ipv6;
 __s32 hop_limit;
 __s32 mtu6;
 __s32 forwarding;
 __s32 force_forwarding;
 __s32 disable_policy;
 __s32 proxy_ndp;
 __u8 __cacheline_group_end__ipv6_devconf_read_txrx[1];

 __s32 accept_ra;
 __s32 accept_redirects;
 __s32 autoconf;
 __s32 dad_transmits;
 __s32 rtr_solicits;
 __s32 rtr_solicit_interval;
 __s32 rtr_solicit_max_interval;
 __s32 rtr_solicit_delay;
 __s32 force_mld_version;
 __s32 mldv1_unsolicited_report_interval;
 __s32 mldv2_unsolicited_report_interval;
 __s32 use_tempaddr;
 __s32 temp_valid_lft;
 __s32 temp_prefered_lft;
 __s32 regen_min_advance;
 __s32 regen_max_retry;
 __s32 max_desync_factor;
 __s32 max_addresses;
 __s32 accept_ra_defrtr;
 __u32 ra_defrtr_metric;
 __s32 accept_ra_min_hop_limit;
 __s32 accept_ra_min_lft;
 __s32 accept_ra_pinfo;
 __s32 ignore_routes_with_linkdown;

 __s32 accept_ra_rtr_pref;
 __s32 rtr_probe_interval;

 __s32 accept_ra_rt_info_min_plen;
 __s32 accept_ra_rt_info_max_plen;


 __s32 accept_source_route;
 __s32 accept_ra_from_local;

 __s32 optimistic_dad;
 __s32 use_optimistic;


 atomic_t mc_forwarding;

 __s32 drop_unicast_in_l2_multicast;
 __s32 accept_dad;
 __s32 force_tllao;
 __s32 ndisc_notify;
 __s32 suppress_frag_ndisc;
 __s32 accept_ra_mtu;
 __s32 drop_unsolicited_na;
 __s32 accept_untracked_na;
 struct ipv6_stable_secret {
  bool initialized;
  struct in6_addr secret;
 } stable_secret;
 __s32 use_oif_addrs_only;
 __s32 keep_addr_on_down;
 __s32 seg6_enabled;

 __s32 seg6_require_hmac;

 __u32 enhanced_dad;
 __u32 addr_gen_mode;
 __s32 ndisc_tclass;
 __s32 rpl_seg_enabled;
 __u32 ioam6_id;
 __u32 ioam6_id_wide;
 __u8 ioam6_enabled;
 __u8 ndisc_evict_nocarrier;
 __u8 ra_honor_pio_life;
 __u8 ra_honor_pio_pflag;

 struct ctl_table_header *sysctl_header;
};
struct udp_prod_queue {
 struct llist_head ll_root ;
 atomic_t rmem_alloc;
};
struct udp_sock {

 struct inet_sock inet;

 unsigned long udp_flags;

 int pending;
 __u8 encap_type;
 __u16 len;
 __u16 gso_size;



 __u16 pcslen;
 __u16 pcrlen;



 int (*encap_rcv)(struct sock *sk, struct sk_buff *skb);
 void (*encap_err_rcv)(struct sock *sk, struct sk_buff *skb, int err,
         __be16 port, u32 info, u8 *payload);
 int (*encap_err_lookup)(struct sock *sk, struct sk_buff *skb);
 void (*encap_destroy)(struct sock *sk);


 struct sk_buff * (*gro_receive)(struct sock *sk,
            struct list_head *head,
            struct sk_buff *skb);
 int (*gro_complete)(struct sock *sk,
      struct sk_buff *skb,
      int nhoff);

 struct udp_prod_queue *udp_prod_queue;


 struct sk_buff_head reader_queue ;


 int forward_deficit;


 int forward_threshold;


 bool peeking_with_offset;






 struct hlist_node tunnel_list;
 struct numa_drop_counters drop_counters;
};
struct ipv6_mc_socklist;
struct ipv6_ac_socklist;
struct ipv6_fl_socklist;
struct inet6_cork {
 struct ipv6_txoptions *opt;
 u8 hop_limit;
 u8 tclass;
 u8 dontfrag:1;
};
struct ipv6_pinfo {

 struct in6_addr saddr;
 __be32 flow_label;
 u32 dst_cookie;
 struct ipv6_txoptions *opt;
 s16 hop_limit;
 u8 pmtudisc;
 u8 tclass;

 bool saddr_cache;

 bool daddr_cache;

 u8 mcast_hops;
 u32 frag_size;

 int ucast_oif;
 int mcast_oif;


 union {
  struct {
   u16 srcrt:1,
    osrcrt:1,
           rxinfo:1,
           rxoinfo:1,
    rxhlim:1,
    rxohlim:1,
    hopopts:1,
    ohopopts:1,
    dstopts:1,
    odstopts:1,
                                rxflow:1,
    rxtclass:1,
    rxpmtu:1,
    rxorigdstaddr:1,
    recvfragsize:1;

  } bits;
  u16 all;
 } rxopt;


 u8 srcprefs;



 u8 min_hopcount;
 __be32 rcv_flowinfo;
 struct in6_pktinfo sticky_pktinfo;

 struct sk_buff *pktoptions;
 struct sk_buff *rxpmtu;
 struct inet6_cork cork;

 struct ipv6_mc_socklist *ipv6_mc_list;
 struct ipv6_ac_socklist *ipv6_ac_list;
};
struct udp6_sock {
 struct udp_sock udp;

 struct ipv6_pinfo inet6;
};
struct ip6_sf_socklist {
 unsigned int sl_max;
 unsigned int sl_count;
 struct callback_head rcu;
 struct in6_addr sl_addr[1] ;
};
struct ipv6_mc_socklist {
 struct in6_addr addr;
 int ifindex;
 unsigned int sfmode;
 struct ipv6_mc_socklist *next;
 struct ip6_sf_socklist *sflist;
 struct callback_head rcu;
};
struct ip6_sf_list {
 struct ip6_sf_list *sf_next;
 struct in6_addr sf_addr;
 unsigned long sf_count[2];
 unsigned char sf_gsresp;
 unsigned char sf_oldin;
 unsigned char sf_crcount;
 struct callback_head rcu;
};
struct ifmcaddr6 {
 struct in6_addr mca_addr;
 struct inet6_dev *idev;
 struct ifmcaddr6 *next;
 struct ip6_sf_list *mca_sources;
 struct ip6_sf_list *mca_tomb;
 unsigned int mca_sfmode;
 unsigned char mca_crcount;
 unsigned long mca_sfcount[2];
 struct delayed_work mca_work;
 unsigned int mca_flags;
 int mca_users;
 refcount_t mca_refcnt;
 unsigned long mca_cstamp;
 unsigned long mca_tstamp;
 struct callback_head rcu;
};
struct ipv6_ac_socklist {
 struct in6_addr acl_addr;
 int acl_ifindex;
 struct ipv6_ac_socklist *acl_next;
};
struct ifacaddr6 {
 struct in6_addr aca_addr;
 struct fib6_info *aca_rt;
 struct ifacaddr6 *aca_next;
 struct hlist_node aca_addr_lst;
 int aca_users;
 refcount_t aca_refcnt;
 unsigned long aca_cstamp;
 unsigned long aca_tstamp;
 struct callback_head rcu;
};
struct ipv6_devstat {
 struct proc_dir_entry *proc_dir_entry;
 __typeof__(struct ipstats_mib) *ipv6;
 __typeof__(struct icmpv6_mib_device) *icmpv6dev;
 __typeof__(struct icmpv6msg_mib_device) *icmpv6msgdev;
};
struct inet6_dev {
 struct net_device *dev;
 netdevice_tracker dev_tracker;

 struct list_head addr_list;

 struct ifmcaddr6 *mc_list;
 struct ifmcaddr6 *mc_tomb;

 unsigned char mc_qrv;
 unsigned char mc_gq_running;
 unsigned char mc_ifc_count;
 unsigned char mc_dad_count;

 unsigned long mc_v1_seen;
 unsigned long mc_qi;
 unsigned long mc_qri;
 unsigned long mc_maxdelay;

 struct delayed_work mc_gq_work;
 struct delayed_work mc_ifc_work;
 struct delayed_work mc_dad_work;
 struct delayed_work mc_query_work;
 struct delayed_work mc_report_work;

 struct sk_buff_head mc_query_queue;
 struct sk_buff_head mc_report_queue;

 spinlock_t mc_query_lock;
 spinlock_t mc_report_lock;
 struct mutex mc_lock;

 struct ifacaddr6 *ac_list;
 rwlock_t lock;
 refcount_t refcnt;
 __u32 if_flags;
 int dead;

 u32 desync_factor;
 struct list_head tempaddr_list;

 struct in6_addr token;

 struct neigh_parms *nd_parms;
 struct ipv6_devconf cnf;
 struct ipv6_devstat stats;

 struct timer_list rs_timer;
 __s32 rs_interval;
 __u8 rs_probes;

 unsigned long tstamp;
 struct callback_head rcu;

 unsigned int ra_mtu;
};
struct ipv6_txoptions {
 refcount_t refcnt;

 int tot_len;



 __u16 opt_flen;
 __u16 opt_nflen;

 struct ipv6_opt_hdr *hopopt;
 struct ipv6_opt_hdr *dst0opt;
 struct ipv6_rt_hdr *srcrt;
 struct ipv6_opt_hdr *dst1opt;
 struct callback_head rcu;

};
enum flowlabel_reflect {
 FLOWLABEL_REFLECT_ESTABLISHED = 1,
 FLOWLABEL_REFLECT_TCP_RESET = 2,
 FLOWLABEL_REFLECT_ICMPV6_ECHO_REPLIES = 4,
};
struct ip6_flowlabel {
 struct ip6_flowlabel *next;
 __be32 label;
 atomic_t users;
 struct in6_addr dst;
 struct ipv6_txoptions *opt;
 unsigned long linger;
 struct callback_head rcu;
 u8 share;
 union {
  struct pid *pid;
  kuid_t uid;
 } owner;
 unsigned long lastuse;
 unsigned long expires;
 struct net *fl_net;
};
struct ipv6_fl_socklist {
 struct ipv6_fl_socklist *next;
 struct ip6_flowlabel *fl;
 struct callback_head rcu;
};
static inline    __be32 ip6_flowlabel(const struct ipv6hdr *hdr)
;
struct inet_peer_base {
 struct rb_root rb_root;
 seqlock_t lock;
 int total;
};
struct rtable;
struct fib_nh_exception {
 struct fib_nh_exception *fnhe_next;
 int fnhe_genid;
 __be32 fnhe_daddr;
 u32 fnhe_pmtu;
 bool fnhe_mtu_locked;
 __be32 fnhe_gw;
 unsigned long fnhe_expires;
 struct rtable *fnhe_rth_input;
 struct rtable *fnhe_rth_output;
 unsigned long fnhe_stamp;
 struct callback_head rcu;
};
struct fnhe_hash_bucket {
 struct fib_nh_exception *chain;
};
struct fib_nh_common {
 struct net_device *nhc_dev;
 netdevice_tracker nhc_dev_tracker;
 int nhc_oif;
 unsigned char nhc_scope;
 u8 nhc_family;
 u8 nhc_gw_family;
 unsigned char nhc_flags;
 struct lwtunnel_state *nhc_lwtstate;

 union {
  __be32 ipv4;
  struct in6_addr ipv6;
 } nhc_gw;

 int nhc_weight;
 atomic_t nhc_upper_bound;


 struct rtable * *nhc_pcpu_rth_output;
 struct rtable *nhc_rth_input;
 struct fnhe_hash_bucket *nhc_exceptions;
};
struct nexthop;
struct fib_rule;
struct fib_table;
struct fib_table {
 struct hlist_node tb_hlist;
 u32 tb_id;
 int tb_num_default;
 struct callback_head rcu;
 unsigned long *tb_data;
 unsigned long __data[1];
};
static inline    int fib_num_tclassid_users(struct net *net)
;
struct fib6_info;
struct fib6_nh;
enum {
 __ND_OPT_PREFIX_INFO_END = 0,
 ND_OPT_SOURCE_LL_ADDR = 1,
 ND_OPT_TARGET_LL_ADDR = 2,
 ND_OPT_PREFIX_INFO = 3,
 ND_OPT_REDIRECT_HDR = 4,
 ND_OPT_MTU = 5,
 ND_OPT_NONCE = 14,
 __ND_OPT_ARRAY_MAX,
 ND_OPT_ROUTE_INFO = 24,
 ND_OPT_RDNSS = 25,
 ND_OPT_DNSSL = 31,
 ND_OPT_6CO = 34,
 ND_OPT_CAPTIVE_PORTAL = 37,
 ND_OPT_PREF64 = 38,
 __ND_OPT_MAX
};
struct flowi6;
struct in6_addr;
struct ctl_table;
struct inet6_dev;
struct net_device;
struct sk_buff;
struct prefix_info;
struct nd_opt_hdr {
 __u8 nd_opt_type;
 __u8 nd_opt_len;
} __attribute__((__packed__));
struct ndisc_options {
 struct nd_opt_hdr *nd_opt_array[__ND_OPT_ARRAY_MAX];

 struct nd_opt_hdr *nd_opts_ri;
 struct nd_opt_hdr *nd_opts_ri_end;

 struct nd_opt_hdr *nd_useropts;
 struct nd_opt_hdr *nd_useropts_end;

 struct nd_opt_hdr *nd_802154_opt_array[ND_OPT_TARGET_LL_ADDR + 1];

};
struct ndisc_ops {
 int (*parse_options)(const struct net_device *dev,
     struct nd_opt_hdr *nd_opt,
     struct ndisc_options *ndopts);
 void (*update)(const struct net_device *dev, struct neighbour *n,
     u32 flags, u8 icmp6_type,
     const struct ndisc_options *ndopts);
 int (*opt_addr_space)(const struct net_device *dev, u8 icmp6_type,
      struct neighbour *neigh, u8 *ha_buf,
      u8 **ha);
 void (*fill_addr_option)(const struct net_device *dev,
        struct sk_buff *skb, u8 icmp6_type,
        const u8 *ha);
 void (*prefix_rcv_add_addr)(struct net *net, struct net_device *dev,
           const struct prefix_info *pinfo,
           struct inet6_dev *in6_dev,
           struct in6_addr *addr,
           int addr_type, u32 addr_flags,
           bool sllao, bool tokenized,
           __u32 valid_lft, u32 prefered_lft,
           bool dev_addr_generated);
};
struct uncached_list;
struct rtable {
 struct dst_entry dst;

 int rt_genid;
 unsigned int rt_flags;
 __u16 rt_type;
 __u8 rt_is_input;
 __u8 rt_uses_gateway;

 int rt_iif;

 u8 rt_gw_family;

 union {
  __be32 rt_gw4;
  struct in6_addr rt_gw6;
 };


 u32 rt_mtu_locked:1,
    rt_pmtu:31;
};
struct in_device;
struct lwtunnel_state {
 __u16 type;
 __u16 flags;
 __u16 headroom;
 atomic_t refcnt;
 int (*orig_output)(struct net *net, struct sock *sk, struct sk_buff *skb);
 int (*orig_input)(struct sk_buff *);
 struct callback_head rcu;
 __u8 data[1];
};
struct sock;
struct ip_ra_chain {
 struct ip_ra_chain *next;
 struct sock *sk;
 union {
  void (*destructor)(struct sock *);
  struct sock *saved_sk;
 };
 struct callback_head rcu;
};
struct msghdr;
struct net_device;
struct rtable;
struct sockaddr;
struct inet_ehash_bucket {
 struct hlist_nulls_head chain;
};
struct inet_bind_hashbucket {
 spinlock_t lock;
 struct hlist_head chain;
};
struct inet_listen_hashbucket {
 spinlock_t lock;
 struct hlist_nulls_head nulls_head;
};
struct inet_hashinfo {






 struct inet_ehash_bucket *ehash;
 spinlock_t *ehash_locks;
 unsigned int ehash_mask;
 unsigned int ehash_locks_mask;




 struct kmem_cache *bind_bucket_cachep;

 struct inet_bind_hashbucket *bhash;
 struct kmem_cache *bind2_bucket_cachep;




 struct inet_bind_hashbucket *bhash2;
 unsigned int bhash_size;


 unsigned int lhash2_mask;
 struct inet_listen_hashbucket *lhash2;

 bool pernet;
} ;
static inline    struct inet_ehash_bucket *inet_ehash_bucket(
 struct inet_hashinfo *hashinfo,
 unsigned int hash)
;
struct device;
struct fwnode_handle;
struct proc_dir_entry;
struct vm_area_struct;
struct notifier_block;
struct iov_iter;
struct vm_struct {
 struct vm_struct *next;
 void *addr;
 unsigned long size;
 unsigned long flags;
 struct page **pages;

 unsigned int page_order;

 unsigned int nr_pages;
 phys_addr_t phys_addr;
 const void *caller;
 unsigned long requested_size;
};
struct gnet_stats_queue {
 __u32 qlen;
 __u32 backlog;
 __u32 drops;
 __u32 requeues;
 __u32 overlimits;
};
struct gnet_stats_basic_sync {
 u64_stats_t bytes;
 u64_stats_t packets;
 struct u64_stats_sync syncp;
} ;
struct net_rate_estimator;
struct gnet_dump {
 spinlock_t * lock;
 struct sk_buff * skb;
 struct nlattr * tail;


 int compat_tc_stats;
 int compat_xstats;
 int padattr;
 void * xstats;
 int xstats_len;
 struct tc_stats tc_stats;
};
struct flow_block {
 struct list_head cb_list;
};
struct netlink_ext_ack;
enum tc_setup_type;
typedef int flow_setup_cb_t(enum tc_setup_type type, void *type_data,
       void *cb_priv);
struct Qdisc_ops;
struct qdisc_walker;
struct tcf_walker;
struct module;
struct qdisc_size_table {
 struct callback_head rcu;
 struct list_head list;
 struct tc_sizespec szopts;
 int refcnt;
 u16 data[1];
};
struct qdisc_skb_head {
 struct sk_buff *head;
 struct sk_buff *tail;
 __u32 qlen;
 spinlock_t lock;
};
struct Qdisc {
 int (*enqueue)(struct sk_buff *skb,
        struct Qdisc *sch,
        struct sk_buff **to_free);
 struct sk_buff * (*dequeue)(struct Qdisc *sch);
 unsigned int flags;








 u32 limit;
 const struct Qdisc_ops *ops;
 struct qdisc_size_table *stab;
 struct hlist_node hash;
 u32 handle;
 u32 parent;
 int depth;

 struct netdev_queue *dev_queue;

 struct net_rate_estimator *rate_est;
 struct gnet_stats_basic_sync *cpu_bstats;
 struct gnet_stats_queue *cpu_qstats;
 int pad;
 refcount_t refcnt;




 struct sk_buff_head gso_skb ;
 struct qdisc_skb_head q;
 struct gnet_stats_basic_sync bstats;
 struct gnet_stats_queue qstats;
 int owner;
 unsigned long state;
 unsigned long state2;
 struct Qdisc *next_sched;
 struct sk_buff_head skb_bad_txq;

 spinlock_t busylock ;
 spinlock_t seqlock;

 struct callback_head rcu;
 netdevice_tracker dev_tracker;
 struct lock_class_key root_lock_key;

 long privdata[1] ;
};
struct Qdisc_class_ops {
 unsigned int flags;

 struct netdev_queue * (*select_queue)(struct Qdisc *, struct tcmsg *);
 int (*graft)(struct Qdisc *, unsigned long cl,
     struct Qdisc *, struct Qdisc **,
     struct netlink_ext_ack *extack);
 struct Qdisc * (*leaf)(struct Qdisc *, unsigned long cl);
 void (*qlen_notify)(struct Qdisc *, unsigned long);


 unsigned long (*find)(struct Qdisc *, u32 classid);
 int (*change)(struct Qdisc *, u32, u32,
     struct nlattr **, unsigned long *,
     struct netlink_ext_ack *);
 int (*delete)(struct Qdisc *, unsigned long,
       struct netlink_ext_ack *);
 void (*walk)(struct Qdisc *, struct qdisc_walker * arg);


 struct tcf_block * (*tcf_block)(struct Qdisc *sch,
          unsigned long arg,
          struct netlink_ext_ack *extack);
 unsigned long (*bind_tcf)(struct Qdisc *, unsigned long,
     u32 classid);
 void (*unbind_tcf)(struct Qdisc *, unsigned long);


 int (*dump)(struct Qdisc *, unsigned long,
     struct sk_buff *skb, struct tcmsg*);
 int (*dump_stats)(struct Qdisc *, unsigned long,
     struct gnet_dump *);
};
struct Qdisc_ops {
 struct Qdisc_ops *next;
 const struct Qdisc_class_ops *cl_ops;
 char id[16];
 int priv_size;
 unsigned int static_flags;

 int (*enqueue)(struct sk_buff *skb,
        struct Qdisc *sch,
        struct sk_buff **to_free);
 struct sk_buff * (*dequeue)(struct Qdisc *);
 struct sk_buff * (*peek)(struct Qdisc *);

 int (*init)(struct Qdisc *sch, struct nlattr *arg,
     struct netlink_ext_ack *extack);
 void (*reset)(struct Qdisc *);
 void (*destroy)(struct Qdisc *);
 int (*change)(struct Qdisc *sch,
       struct nlattr *arg,
       struct netlink_ext_ack *extack);
 void (*attach)(struct Qdisc *sch);
 int (*change_tx_queue_len)(struct Qdisc *, unsigned int);
 void (*change_real_num_tx)(struct Qdisc *sch,
            unsigned int new_real_tx);

 int (*dump)(struct Qdisc *, struct sk_buff *);
 int (*dump_stats)(struct Qdisc *, struct gnet_dump *);

 void (*ingress_block_set)(struct Qdisc *sch,
           u32 block_index);
 void (*egress_block_set)(struct Qdisc *sch,
          u32 block_index);
 u32 (*ingress_block_get)(struct Qdisc *sch);
 u32 (*egress_block_get)(struct Qdisc *sch);

 struct module *owner;
};
struct tcf_result {
 union {
  struct {
   unsigned long class;
   u32 classid;
  };
  const struct tcf_proto *goto_tp;
 };
};
struct tcf_chain;
struct tcf_proto_ops {
 struct list_head head;
 char kind[16];

 int (*classify)(struct sk_buff *,
         const struct tcf_proto *,
         struct tcf_result *);
 int (*init)(struct tcf_proto*);
 void (*destroy)(struct tcf_proto *tp, bool rtnl_held,
        struct netlink_ext_ack *extack);

 void* (*get)(struct tcf_proto*, u32 handle);
 void (*put)(struct tcf_proto *tp, void *f);
 int (*change)(struct net *net, struct sk_buff *,
     struct tcf_proto*, unsigned long,
     u32 handle, struct nlattr **,
     void **, u32,
     struct netlink_ext_ack *);
 int (*delete)(struct tcf_proto *tp, void *arg,
       bool *last, bool rtnl_held,
       struct netlink_ext_ack *);
 bool (*delete_empty)(struct tcf_proto *tp);
 void (*walk)(struct tcf_proto *tp,
     struct tcf_walker *arg, bool rtnl_held);
 int (*reoffload)(struct tcf_proto *tp, bool add,
          flow_setup_cb_t *cb, void *cb_priv,
          struct netlink_ext_ack *extack);
 void (*hw_add)(struct tcf_proto *tp,
       void *type_data);
 void (*hw_del)(struct tcf_proto *tp,
       void *type_data);
 void (*bind_class)(void *, u32, unsigned long,
           void *, unsigned long);
 void * (*tmplt_create)(struct net *net,
      struct tcf_chain *chain,
      struct nlattr **tca,
      struct netlink_ext_ack *extack);
 void (*tmplt_destroy)(void *tmplt_priv);
 void (*tmplt_reoffload)(struct tcf_chain *chain,
         bool add,
         flow_setup_cb_t *cb,
         void *cb_priv);
 struct tcf_exts * (*get_exts)(const struct tcf_proto *tp,
         u32 handle);


 int (*dump)(struct net*, struct tcf_proto*, void *,
     struct sk_buff *skb, struct tcmsg*,
     bool);
 int (*terse_dump)(struct net *net,
           struct tcf_proto *tp, void *fh,
           struct sk_buff *skb,
           struct tcmsg *t, bool rtnl_held);
 int (*tmplt_dump)(struct sk_buff *skb,
           struct net *net,
           void *tmplt_priv);

 struct module *owner;
 int flags;
};
struct tcf_proto {

 struct tcf_proto *next;
 void *root;


 int (*classify)(struct sk_buff *,
         const struct tcf_proto *,
         struct tcf_result *);
 __be16 protocol;


 u32 prio;
 void *data;
 const struct tcf_proto_ops *ops;
 struct tcf_chain *chain;



 spinlock_t lock;
 bool deleting;
 bool counted;
 bool usesw;
 refcount_t refcnt;
 struct callback_head rcu;
 struct hlist_node destroy_ht_node;
};
struct tcf_chain {

 struct mutex filter_chain_lock;
 struct tcf_proto *filter_chain;
 struct list_head list;
 struct tcf_block *block;
 u32 index;
 unsigned int refcnt;
 unsigned int action_refcnt;
 bool explicitly_created;
 bool flushing;
 const struct tcf_proto_ops *tmplt_ops;
 void *tmplt_priv;
 struct callback_head rcu;
};
struct tcf_block {
 struct xarray ports;



 struct mutex lock;
 struct list_head chain_list;
 u32 index;
 u32 classid;
 refcount_t refcnt;
 struct net *net;
 struct Qdisc *q;
 struct rw_semaphore cb_lock;
 struct flow_block flow_block;
 struct list_head owner_list;
 bool keep_dst;
 atomic_t useswcnt;
 atomic_t offloadcnt;
 unsigned int nooffloaddevcnt;
 unsigned int lockeddevcnt;
 struct {
  struct tcf_chain *chain;
  struct list_head filter_chain_list;
 } chain0;
 struct callback_head rcu;
 struct hlist_head proto_destroy_ht[1 << (7)];
 struct mutex proto_destroy_lock;
};
struct sk_buff;
struct sock;
struct bpf_prog_aux;
struct xdp_buff;
struct sock_reuseport;
struct ctl_table;
struct ctl_table_header;
struct sock_fprog_kern {
 u16 len;
 struct sock_filter *filter;
};
struct bpf_prog_stats {
 u64_stats_t cnt;
 u64_stats_t nsecs;
 u64_stats_t misses;
 struct u64_stats_sync syncp;
} ;
struct sk_filter {
 refcount_t refcnt;
 struct callback_head rcu;
 struct bpf_prog *prog;
};
struct bpf_nh_params {
 u32 nh_family;
 union {
  u32 ipv4_nh;
  struct in6_addr ipv6_nh;
 };
};
struct bpf_redirect_info {
 u64 tgt_index;
 void *tgt_value;
 struct bpf_map *map;
 u32 flags;
 u32 map_id;
 enum bpf_map_type map_type;
 struct bpf_nh_params nh;
 u32 kern_flags;
};
struct bpf_net_context {
 struct bpf_redirect_info ri;
 struct list_head cpu_map_flush_list;
 struct list_head dev_map_flush_list;
 struct list_head xskmap_map_flush_list;
};
static inline    int sk_filter(struct sock *sk, struct sk_buff *skb)
;
struct sock_reuseport {
 struct callback_head rcu;

 u16 max_socks;
 u16 num_socks;
 u16 num_closed_socks;
 u16 incoming_cpu;



 unsigned int synq_overflow_ts;

 unsigned int reuseport_id;
 unsigned int bind_inany:1;
 unsigned int has_conns:1;
 struct bpf_prog *prog;
 struct sock *socks[1] ;
};
struct ipv6hdr;
struct seq_file;
struct fs_pin;
struct pid_namespace {
 struct idr idr;
 struct callback_head rcu;
 unsigned int pid_allocated;
 struct task_struct *child_reaper;
 struct kmem_cache *pid_cachep;
 unsigned int level;
 int pid_max;
 struct pid_namespace *parent;

 struct fs_pin *bacct;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 int reboot;
 struct ns_common ns;
 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 int memfd_noexec_scope;


} ;
struct seq_file;
struct pid_namespace;
struct pid;
struct audit_context;
struct inode;
struct path;
struct sk_buff;
struct filename;
static inline    struct audit_context *audit_context(void)
;
struct rt6_info;
struct fib6_info;
struct fib6_node {
 struct fib6_node *parent;
 struct fib6_node *left;
 struct fib6_node *right;

 struct fib6_node *subtree;

 struct fib6_info *leaf;

 __u16 fn_bit;
 __u16 fn_flags;
 int fn_sernum;
 struct fib6_info *rr_ptr;
 struct callback_head rcu;
};
static inline    bool fib6_routes_require_src(const struct net *net)
;
struct rt6key {
 struct in6_addr addr;
 int plen;
};
struct fib6_table;
struct rt6_exception_bucket {
 struct hlist_head chain;
 int depth;
};
struct fib6_nh {
 struct fib_nh_common nh_common;


 unsigned long last_probe;


 struct rt6_info * *rt6i_pcpu;
 struct rt6_exception_bucket *rt6i_exception_bucket;
};
struct fib6_info {
 struct fib6_table *fib6_table;
 struct fib6_info *fib6_next;
 struct fib6_node *fib6_node;






 union {
  struct list_head fib6_siblings;
  struct list_head nh_list;
 };
 unsigned int fib6_nsiblings;

 refcount_t fib6_ref;
 unsigned long expires;

 struct hlist_node gc_link;

 struct dst_metrics *fib6_metrics;

 struct rt6key fib6_dst;
 u32 fib6_flags;
 struct rt6key fib6_src;
 struct rt6key fib6_prefsrc;

 u32 fib6_metric;
 u8 fib6_protocol;
 u8 fib6_type;

 u8 offload;
 u8 trap;
 u8 offload_failed;

 u8 should_flush:1,
     dst_nocount:1,
     dst_nopolicy:1,
     fib6_destroying:1,
     unused:4;

 struct list_head purge_link;
 struct callback_head rcu;
 struct nexthop *nh;
 struct fib6_nh fib6_nh[1];
};
struct rt6_info {
 struct dst_entry dst;
 struct fib6_info *from;
 int sernum;

 struct rt6key rt6i_dst;
 struct rt6key rt6i_src;
 struct in6_addr rt6i_gateway;
 struct inet6_dev *rt6i_idev;
 u32 rt6i_flags;


 unsigned short rt6i_nfheader_len;
};
struct rt6_statistics {
 __u32 fib_nodes;
 __u32 fib_route_nodes;
 __u32 fib_rt_entries;
 __u32 fib_rt_cache;
 __u32 fib_discarded_routes;


 atomic_t fib_rt_alloc;
};
struct fib6_table {
 struct hlist_node tb6_hlist;
 u32 tb6_id;
 spinlock_t tb6_lock;
 struct fib6_node tb6_root;
 struct inet_peer_base tb6_peers;
 unsigned int flags;
 unsigned int fib_seq;
 struct hlist_head tb6_gc_hlist;
};
static inline    bool fib6_has_custom_rules(const struct net *net)
;
struct xfrm_state_walk {
 struct list_head all;
 u8 state;
 u8 dying;
 u8 proto;
 u32 seq;
 struct xfrm_address_filter *filter;
};
struct xfrm_dev_offload {





 struct net_device *dev;
 netdevice_tracker dev_tracker;






 struct net_device *real_dev;
 unsigned long offload_handle;
 u8 dir : 2;
 u8 type : 2;
 u8 flags : 2;
};
struct xfrm_mode {
 u8 encap;
 u8 family;
 u8 flags;
};
enum xfrm_replay_mode {
 XFRM_REPLAY_MODE_LEGACY,
 XFRM_REPLAY_MODE_BMP,
 XFRM_REPLAY_MODE_ESN,
};
struct xfrm_state {
 possible_net_t xs_net;
 union {
  struct hlist_node gclist;
  struct hlist_node bydst;
 };
 union {
  struct hlist_node dev_gclist;
  struct hlist_node bysrc;
 };
 struct hlist_node byspi;
 struct hlist_node byseq;
 struct hlist_node state_cache;
 struct hlist_node state_cache_input;

 refcount_t refcnt;
 spinlock_t lock;

 u32 pcpu_num;
 struct xfrm_id id;
 struct xfrm_selector sel;
 struct xfrm_mark mark;
 u32 if_id;
 u32 tfcpad;

 u32 genid;


 struct xfrm_state_walk km;


 struct {
  u32 reqid;
  u8 mode;
  u8 replay_window;
  u8 aalgo, ealgo, calgo;
  u8 flags;
  u16 family;
  xfrm_address_t saddr;
  int header_len;
  int enc_hdr_len;
  int trailer_len;
  u32 extra_flags;
  struct xfrm_mark smark;
 } props;

 struct xfrm_lifetime_cfg lft;


 struct xfrm_algo_auth *aalg;
 struct xfrm_algo *ealg;
 struct xfrm_algo *calg;
 struct xfrm_algo_aead *aead;
 const char *geniv;


 __be16 new_mapping_sport;
 u32 new_mapping;
 u32 mapping_maxage;


 struct xfrm_encap_tmpl *encap;


 u32 nat_keepalive_interval;
 time64_t nat_keepalive_expiration;


 xfrm_address_t *coaddr;


 struct xfrm_state *tunnel;


 atomic_t tunnel_users;


 struct xfrm_replay_state replay;
 struct xfrm_replay_state_esn *replay_esn;


 struct xfrm_replay_state preplay;
 struct xfrm_replay_state_esn *preplay_esn;


 enum xfrm_replay_mode repl_mode;



 u32 xflags;


 u32 replay_maxage;
 u32 replay_maxdiff;


 struct timer_list rtimer;


 struct xfrm_stats stats;

 struct xfrm_lifetime_cur curlft;
 struct hrtimer mtimer;

 struct xfrm_dev_offload xso;


 long saved_tmo;


 time64_t lastused;

 struct page_frag xfrag;



 const struct xfrm_type *type;
 struct xfrm_mode inner_mode;
 struct xfrm_mode inner_mode_iaf;
 struct xfrm_mode outer_mode;

 const struct xfrm_type_offload *type_offload;


 struct xfrm_sec_ctx *security;



 void *data;
 u8 dir;

 const struct xfrm_mode_cbs *mode_cbs;
 void *mode_data;
};
static inline    struct net *xs_net(struct xfrm_state *x)
;
struct net_device;
struct xfrm_type;
struct xfrm_tmpl;
struct xfrm_type {
 struct module *owner;
 u8 proto;
 u8 flags;

 int (*init_state)(struct xfrm_state *x,
           struct netlink_ext_ack *extack);
 void (*destructor)(struct xfrm_state *);
 int (*input)(struct xfrm_state *, struct sk_buff *skb);
 int (*output)(struct xfrm_state *, struct sk_buff *pskb);
 int (*reject)(struct xfrm_state *, struct sk_buff *,
       const struct flowi *);
};
struct xfrm_type_offload {
 struct module *owner;
 u8 proto;
 void (*encap)(struct xfrm_state *, struct sk_buff *pskb);
 int (*input_tail)(struct xfrm_state *x, struct sk_buff *skb);
 int (*xmit)(struct xfrm_state *, struct sk_buff *pskb, netdev_features_t features);
};
struct xfrm_mode_cbs {
 struct module *owner;
 int (*init_state)(struct xfrm_state *x);
 int (*clone_state)(struct xfrm_state *x, struct xfrm_state *orig);
 void (*destroy_state)(struct xfrm_state *x);
 int (*user_init)(struct net *net, struct xfrm_state *x,
        struct nlattr **attrs,
        struct netlink_ext_ack *extack);
 int (*copy_to_user)(struct xfrm_state *x, struct sk_buff *skb);
 unsigned int (*sa_len)(const struct xfrm_state *x);
 u32 (*get_inner_mtu)(struct xfrm_state *x, int outer_mtu);
 int (*input)(struct xfrm_state *x, struct sk_buff *skb);
 int (*output)(struct net *net, struct sock *sk, struct sk_buff *skb);
 int (*prepare_output)(struct xfrm_state *x, struct sk_buff *skb);
};
struct xfrm_tmpl {






 struct xfrm_id id;


 xfrm_address_t saddr;

 unsigned short encap_family;

 u32 reqid;


 u8 mode;


 u8 share;


 u8 optional;


 u8 allalgs;


 u32 aalgos;
 u32 ealgos;
 u32 calgos;
};
struct xfrm_policy_walk_entry {
 struct list_head all;
 u8 dead;
};
struct xfrm_policy_queue {
 struct sk_buff_head hold_queue;
 struct timer_list hold_timer;
 unsigned long timeout;
};
struct xfrm_policy {
 possible_net_t xp_net;
 struct hlist_node bydst;
 struct hlist_node byidx;

 struct hlist_head state_cache_list;


 rwlock_t lock;
 refcount_t refcnt;
 u32 pos;
 struct timer_list timer;

 atomic_t genid;
 u32 priority;
 u32 index;
 u32 if_id;
 struct xfrm_mark mark;
 struct xfrm_selector selector;
 struct xfrm_lifetime_cfg lft;
 struct xfrm_lifetime_cur curlft;
 struct xfrm_policy_walk_entry walk;
 struct xfrm_policy_queue polq;
 bool bydst_reinsert;
 u8 type;
 u8 action;
 u8 flags;
 u8 xfrm_nr;
 u16 family;
 struct xfrm_sec_ctx *security;
 struct xfrm_tmpl xfrm_vec[6];
 struct callback_head rcu;

 struct xfrm_dev_offload xdo;
};
static inline    struct net *xp_net(const struct xfrm_policy *xp)
;
int xfrm_state_walk(struct net *net, struct xfrm_state_walk *walk,
      int (*func)(struct xfrm_state *, int, void*), void *);
struct net;
struct sock;
struct sockaddr;
struct cgroup;
struct sk_buff;
struct bpf_map;
struct bpf_prog;
struct bpf_cgroup_storage;
struct ctl_table;
struct ctl_table_header;
struct task_struct;
struct bpf_cgroup_storage_map;
struct bpf_storage_buffer {
 struct callback_head rcu;
 char data[1];
};
struct bpf_cgroup_storage {
 union {
  struct bpf_storage_buffer *buf;
  void *percpu_buf;
 };
 struct bpf_cgroup_storage_map *map;
 struct bpf_cgroup_storage_key key;
 struct list_head list_map;
 struct list_head list_cg;
 struct rb_node node;
 struct callback_head rcu;
};
void tcp_retransmit_timer(struct sock *sk);
enum tcp_ca_event {
 CA_EVENT_TX_START,
 CA_EVENT_CWND_RESTART,
 CA_EVENT_COMPLETE_CWR,
 CA_EVENT_LOSS,
 CA_EVENT_ECN_NO_CE,
 CA_EVENT_ECN_IS_CE,
};
union tcp_cc_info;
struct ack_sample {
 u32 pkts_acked;
 s32 rtt_us;
 u32 in_flight;
};
struct rate_sample {
 u64 prior_mstamp;
 u32 prior_delivered;
 u32 prior_delivered_ce;
 s32 delivered;
 s32 delivered_ce;
 long interval_us;
 u32 snd_interval_us;
 u32 rcv_interval_us;
 long rtt_us;
 int losses;
 u32 acked_sacked;
 u32 prior_in_flight;
 u32 last_end_seq;
 bool is_app_limited;
 bool is_retrans;
 bool is_ack_delayed;
};
struct tcp_congestion_ops {



 u32 (*ssthresh)(struct sock *sk);


 void (*cong_avoid)(struct sock *sk, u32 ack, u32 acked);


 void (*set_state)(struct sock *sk, u8 new_state);


 void (*cwnd_event)(struct sock *sk, enum tcp_ca_event ev);


 void (*in_ack_event)(struct sock *sk, u32 flags);


 void (*pkts_acked)(struct sock *sk, const struct ack_sample *sample);


 u32 (*min_tso_segs)(struct sock *sk);




 void (*cong_control)(struct sock *sk, u32 ack, int flag, const struct rate_sample *rs);



 u32 (*undo_cwnd)(struct sock *sk);

 u32 (*sndbuf_expand)(struct sock *sk);



 size_t (*get_info)(struct sock *sk, u32 ext, int *attr,
      union tcp_cc_info *info);

 char name[16];
 struct module *owner;
 struct list_head list;
 u32 key;
 u32 flags;


 void (*init)(struct sock *sk);

 void (*release)(struct sock *sk);
} ;
static inline    void tcp_ca_event(struct sock *sk, const enum tcp_ca_event event)
;
struct tcp_fastopen_context {
 siphash_key_t key[2];
 int num;
 struct callback_head rcu;
};
struct sk_psock;
struct ethtool_drvinfo {
 __u32 cmd;
 char driver[32];
 char version[32];
 char fw_version[32];
 char bus_info[32];
 char erom_version[32];
 char reserved2[12];
 __u32 n_priv_flags;
 __u32 n_stats;
 __u32 testinfo_len;
 __u32 eedump_len;
 __u32 regdump_len;
};
struct ethtool_wolinfo {
 __u32 cmd;
 __u32 supported;
 __u32 wolopts;
 __u8 sopass[6];
};
struct ethtool_tunable {
 __u32 cmd;
 __u32 id;
 __u32 type_id;
 __u32 len;
 void *data[1];
};
struct ethtool_regs {
 __u32 cmd;
 __u32 version;
 __u32 len;
 __u8 data[1];
};
struct ethtool_eeprom {
 __u32 cmd;
 __u32 magic;
 __u32 offset;
 __u32 len;
 __u8 data[1];
};
struct ethtool_modinfo {
 __u32 cmd;
 __u32 type;
 __u32 eeprom_len;
 __u32 reserved[8];
};
struct ethtool_coalesce {
 __u32 cmd;
 __u32 rx_coalesce_usecs;
 __u32 rx_max_coalesced_frames;
 __u32 rx_coalesce_usecs_irq;
 __u32 rx_max_coalesced_frames_irq;
 __u32 tx_coalesce_usecs;
 __u32 tx_max_coalesced_frames;
 __u32 tx_coalesce_usecs_irq;
 __u32 tx_max_coalesced_frames_irq;
 __u32 stats_block_coalesce_usecs;
 __u32 use_adaptive_rx_coalesce;
 __u32 use_adaptive_tx_coalesce;
 __u32 pkt_rate_low;
 __u32 rx_coalesce_usecs_low;
 __u32 rx_max_coalesced_frames_low;
 __u32 tx_coalesce_usecs_low;
 __u32 tx_max_coalesced_frames_low;
 __u32 pkt_rate_high;
 __u32 rx_coalesce_usecs_high;
 __u32 rx_max_coalesced_frames_high;
 __u32 tx_coalesce_usecs_high;
 __u32 tx_max_coalesced_frames_high;
 __u32 rate_sample_interval;
};
struct ethtool_ringparam {
 __u32 cmd;
 __u32 rx_max_pending;
 __u32 rx_mini_max_pending;
 __u32 rx_jumbo_max_pending;
 __u32 tx_max_pending;
 __u32 rx_pending;
 __u32 rx_mini_pending;
 __u32 rx_jumbo_pending;
 __u32 tx_pending;
};
struct ethtool_channels {
 __u32 cmd;
 __u32 max_rx;
 __u32 max_tx;
 __u32 max_other;
 __u32 max_combined;
 __u32 rx_count;
 __u32 tx_count;
 __u32 other_count;
 __u32 combined_count;
};
struct ethtool_pauseparam {
 __u32 cmd;
 __u32 autoneg;
 __u32 rx_pause;
 __u32 tx_pause;
};
enum ethtool_link_ext_state {
 ETHTOOL_LINK_EXT_STATE_AUTONEG,
 ETHTOOL_LINK_EXT_STATE_LINK_TRAINING_FAILURE,
 ETHTOOL_LINK_EXT_STATE_LINK_LOGICAL_MISMATCH,
 ETHTOOL_LINK_EXT_STATE_BAD_SIGNAL_INTEGRITY,
 ETHTOOL_LINK_EXT_STATE_NO_CABLE,
 ETHTOOL_LINK_EXT_STATE_CABLE_ISSUE,
 ETHTOOL_LINK_EXT_STATE_EEPROM_ISSUE,
 ETHTOOL_LINK_EXT_STATE_CALIBRATION_FAILURE,
 ETHTOOL_LINK_EXT_STATE_POWER_BUDGET_EXCEEDED,
 ETHTOOL_LINK_EXT_STATE_OVERHEAT,
 ETHTOOL_LINK_EXT_STATE_MODULE,
};
enum ethtool_link_ext_substate_autoneg {
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_PARTNER_DETECTED = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_ACK_NOT_RECEIVED,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NEXT_PAGE_EXCHANGE_FAILED,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_PARTNER_DETECTED_FORCE_MODE,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_FEC_MISMATCH_DURING_OVERRIDE,
 ETHTOOL_LINK_EXT_SUBSTATE_AN_NO_HCD,
};
enum ethtool_link_ext_substate_link_training {
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_FRAME_LOCK_NOT_ACQUIRED = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_LINK_INHIBIT_TIMEOUT,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_KR_LINK_PARTNER_DID_NOT_SET_RECEIVER_READY,
 ETHTOOL_LINK_EXT_SUBSTATE_LT_REMOTE_FAULT,
};
enum ethtool_link_ext_substate_link_logical_mismatch {
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_ACQUIRE_BLOCK_LOCK = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_ACQUIRE_AM_LOCK,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_PCS_DID_NOT_GET_ALIGN_STATUS,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_FC_FEC_IS_NOT_LOCKED,
 ETHTOOL_LINK_EXT_SUBSTATE_LLM_RS_FEC_IS_NOT_LOCKED,
};
enum ethtool_link_ext_substate_bad_signal_integrity {
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_LARGE_NUMBER_OF_PHYSICAL_ERRORS = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_UNSUPPORTED_RATE,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_SERDES_REFERENCE_CLOCK_LOST,
 ETHTOOL_LINK_EXT_SUBSTATE_BSI_SERDES_ALOS,
};
enum ethtool_link_ext_substate_cable_issue {
 ETHTOOL_LINK_EXT_SUBSTATE_CI_UNSUPPORTED_CABLE = 1,
 ETHTOOL_LINK_EXT_SUBSTATE_CI_CABLE_TEST_FAILURE,
};
enum ethtool_link_ext_substate_module {
 ETHTOOL_LINK_EXT_SUBSTATE_MODULE_CMIS_NOT_READY = 1,
};
enum ethtool_mac_stats_src {
 ETHTOOL_MAC_STATS_SRC_AGGREGATE,
 ETHTOOL_MAC_STATS_SRC_EMAC,
 ETHTOOL_MAC_STATS_SRC_PMAC,
};
enum ethtool_module_power_mode_policy {
 ETHTOOL_MODULE_POWER_MODE_POLICY_HIGH = 1,
 ETHTOOL_MODULE_POWER_MODE_POLICY_AUTO,
};
enum ethtool_module_power_mode {
 ETHTOOL_MODULE_POWER_MODE_LOW = 1,
 ETHTOOL_MODULE_POWER_MODE_HIGH,
};
enum ethtool_mm_verify_status {
 ETHTOOL_MM_VERIFY_STATUS_UNKNOWN,
 ETHTOOL_MM_VERIFY_STATUS_INITIAL,
 ETHTOOL_MM_VERIFY_STATUS_VERIFYING,
 ETHTOOL_MM_VERIFY_STATUS_SUCCEEDED,
 ETHTOOL_MM_VERIFY_STATUS_FAILED,
 ETHTOOL_MM_VERIFY_STATUS_DISABLED,
};
struct ethtool_test {
 __u32 cmd;
 __u32 flags;
 __u32 reserved;
 __u32 len;
 __u64 data[1];
};
struct ethtool_stats {
 __u32 cmd;
 __u32 n_stats;
 __u64 data[1];
};
struct ethtool_tcpip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be16 psrc;
 __be16 pdst;
 __u8 tos;
};
struct ethtool_ah_espip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be32 spi;
 __u8 tos;
};
struct ethtool_usrip4_spec {
 __be32 ip4src;
 __be32 ip4dst;
 __be32 l4_4_bytes;
 __u8 tos;
 __u8 ip_ver;
 __u8 proto;
};
struct ethtool_tcpip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be16 psrc;
 __be16 pdst;
 __u8 tclass;
};
struct ethtool_ah_espip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be32 spi;
 __u8 tclass;
};
struct ethtool_usrip6_spec {
 __be32 ip6src[4];
 __be32 ip6dst[4];
 __be32 l4_4_bytes;
 __u8 tclass;
 __u8 l4_proto;
};
union ethtool_flow_union {
 struct ethtool_tcpip4_spec tcp_ip4_spec;
 struct ethtool_tcpip4_spec udp_ip4_spec;
 struct ethtool_tcpip4_spec sctp_ip4_spec;
 struct ethtool_ah_espip4_spec ah_ip4_spec;
 struct ethtool_ah_espip4_spec esp_ip4_spec;
 struct ethtool_usrip4_spec usr_ip4_spec;
 struct ethtool_tcpip6_spec tcp_ip6_spec;
 struct ethtool_tcpip6_spec udp_ip6_spec;
 struct ethtool_tcpip6_spec sctp_ip6_spec;
 struct ethtool_ah_espip6_spec ah_ip6_spec;
 struct ethtool_ah_espip6_spec esp_ip6_spec;
 struct ethtool_usrip6_spec usr_ip6_spec;
 struct ethhdr ether_spec;
 __u8 hdata[52];
};
struct ethtool_flow_ext {
 __u8 padding[2];
 unsigned char h_dest[6];
 __be16 vlan_etype;
 __be16 vlan_tci;
 __be32 data[2];
};
struct ethtool_rx_flow_spec {
 __u32 flow_type;
 union ethtool_flow_union h_u;
 struct ethtool_flow_ext h_ext;
 union ethtool_flow_union m_u;
 struct ethtool_flow_ext m_ext;
 __u64 ring_cookie;
 __u32 location;
};
struct ethtool_rxnfc {
 __u32 cmd;
 __u32 flow_type;
 __u64 data;
 struct ethtool_rx_flow_spec fs;
 union {
  __u32 rule_cnt;
  __u32 rss_context;
 };
 __u32 rule_locs[1];
};
struct ethtool_flash {
 __u32 cmd;
 __u32 region;
 char data[128];
};
struct ethtool_dump {
 __u32 cmd;
 __u32 version;
 __u32 flag;
 __u32 len;
 __u8 data[1];
};
struct ethtool_fecparam {
 __u32 cmd;

 __u32 active_fec;
 __u32 fec;
 __u32 reserved;
};
enum ethtool_link_mode_bit_indices {
 ETHTOOL_LINK_MODE_10baseT_Half_BIT = 0,
 ETHTOOL_LINK_MODE_10baseT_Full_BIT = 1,
 ETHTOOL_LINK_MODE_100baseT_Half_BIT = 2,
 ETHTOOL_LINK_MODE_100baseT_Full_BIT = 3,
 ETHTOOL_LINK_MODE_1000baseT_Half_BIT = 4,
 ETHTOOL_LINK_MODE_1000baseT_Full_BIT = 5,
 ETHTOOL_LINK_MODE_Autoneg_BIT = 6,
 ETHTOOL_LINK_MODE_TP_BIT = 7,
 ETHTOOL_LINK_MODE_AUI_BIT = 8,
 ETHTOOL_LINK_MODE_MII_BIT = 9,
 ETHTOOL_LINK_MODE_FIBRE_BIT = 10,
 ETHTOOL_LINK_MODE_BNC_BIT = 11,
 ETHTOOL_LINK_MODE_10000baseT_Full_BIT = 12,
 ETHTOOL_LINK_MODE_Pause_BIT = 13,
 ETHTOOL_LINK_MODE_Asym_Pause_BIT = 14,
 ETHTOOL_LINK_MODE_2500baseX_Full_BIT = 15,
 ETHTOOL_LINK_MODE_Backplane_BIT = 16,
 ETHTOOL_LINK_MODE_1000baseKX_Full_BIT = 17,
 ETHTOOL_LINK_MODE_10000baseKX4_Full_BIT = 18,
 ETHTOOL_LINK_MODE_10000baseKR_Full_BIT = 19,
 ETHTOOL_LINK_MODE_10000baseR_FEC_BIT = 20,
 ETHTOOL_LINK_MODE_20000baseMLD2_Full_BIT = 21,
 ETHTOOL_LINK_MODE_20000baseKR2_Full_BIT = 22,
 ETHTOOL_LINK_MODE_40000baseKR4_Full_BIT = 23,
 ETHTOOL_LINK_MODE_40000baseCR4_Full_BIT = 24,
 ETHTOOL_LINK_MODE_40000baseSR4_Full_BIT = 25,
 ETHTOOL_LINK_MODE_40000baseLR4_Full_BIT = 26,
 ETHTOOL_LINK_MODE_56000baseKR4_Full_BIT = 27,
 ETHTOOL_LINK_MODE_56000baseCR4_Full_BIT = 28,
 ETHTOOL_LINK_MODE_56000baseSR4_Full_BIT = 29,
 ETHTOOL_LINK_MODE_56000baseLR4_Full_BIT = 30,
 ETHTOOL_LINK_MODE_25000baseCR_Full_BIT = 31,







 ETHTOOL_LINK_MODE_25000baseKR_Full_BIT = 32,
 ETHTOOL_LINK_MODE_25000baseSR_Full_BIT = 33,
 ETHTOOL_LINK_MODE_50000baseCR2_Full_BIT = 34,
 ETHTOOL_LINK_MODE_50000baseKR2_Full_BIT = 35,
 ETHTOOL_LINK_MODE_100000baseKR4_Full_BIT = 36,
 ETHTOOL_LINK_MODE_100000baseSR4_Full_BIT = 37,
 ETHTOOL_LINK_MODE_100000baseCR4_Full_BIT = 38,
 ETHTOOL_LINK_MODE_100000baseLR4_ER4_Full_BIT = 39,
 ETHTOOL_LINK_MODE_50000baseSR2_Full_BIT = 40,
 ETHTOOL_LINK_MODE_1000baseX_Full_BIT = 41,
 ETHTOOL_LINK_MODE_10000baseCR_Full_BIT = 42,
 ETHTOOL_LINK_MODE_10000baseSR_Full_BIT = 43,
 ETHTOOL_LINK_MODE_10000baseLR_Full_BIT = 44,
 ETHTOOL_LINK_MODE_10000baseLRM_Full_BIT = 45,
 ETHTOOL_LINK_MODE_10000baseER_Full_BIT = 46,
 ETHTOOL_LINK_MODE_2500baseT_Full_BIT = 47,
 ETHTOOL_LINK_MODE_5000baseT_Full_BIT = 48,

 ETHTOOL_LINK_MODE_FEC_NONE_BIT = 49,
 ETHTOOL_LINK_MODE_FEC_RS_BIT = 50,
 ETHTOOL_LINK_MODE_FEC_BASER_BIT = 51,
 ETHTOOL_LINK_MODE_50000baseKR_Full_BIT = 52,
 ETHTOOL_LINK_MODE_50000baseSR_Full_BIT = 53,
 ETHTOOL_LINK_MODE_50000baseCR_Full_BIT = 54,
 ETHTOOL_LINK_MODE_50000baseLR_ER_FR_Full_BIT = 55,
 ETHTOOL_LINK_MODE_50000baseDR_Full_BIT = 56,
 ETHTOOL_LINK_MODE_100000baseKR2_Full_BIT = 57,
 ETHTOOL_LINK_MODE_100000baseSR2_Full_BIT = 58,
 ETHTOOL_LINK_MODE_100000baseCR2_Full_BIT = 59,
 ETHTOOL_LINK_MODE_100000baseLR2_ER2_FR2_Full_BIT = 60,
 ETHTOOL_LINK_MODE_100000baseDR2_Full_BIT = 61,
 ETHTOOL_LINK_MODE_200000baseKR4_Full_BIT = 62,
 ETHTOOL_LINK_MODE_200000baseSR4_Full_BIT = 63,
 ETHTOOL_LINK_MODE_200000baseLR4_ER4_FR4_Full_BIT = 64,
 ETHTOOL_LINK_MODE_200000baseDR4_Full_BIT = 65,
 ETHTOOL_LINK_MODE_200000baseCR4_Full_BIT = 66,
 ETHTOOL_LINK_MODE_100baseT1_Full_BIT = 67,
 ETHTOOL_LINK_MODE_1000baseT1_Full_BIT = 68,
 ETHTOOL_LINK_MODE_400000baseKR8_Full_BIT = 69,
 ETHTOOL_LINK_MODE_400000baseSR8_Full_BIT = 70,
 ETHTOOL_LINK_MODE_400000baseLR8_ER8_FR8_Full_BIT = 71,
 ETHTOOL_LINK_MODE_400000baseDR8_Full_BIT = 72,
 ETHTOOL_LINK_MODE_400000baseCR8_Full_BIT = 73,
 ETHTOOL_LINK_MODE_FEC_LLRS_BIT = 74,
 ETHTOOL_LINK_MODE_100000baseKR_Full_BIT = 75,
 ETHTOOL_LINK_MODE_100000baseSR_Full_BIT = 76,
 ETHTOOL_LINK_MODE_100000baseLR_ER_FR_Full_BIT = 77,
 ETHTOOL_LINK_MODE_100000baseCR_Full_BIT = 78,
 ETHTOOL_LINK_MODE_100000baseDR_Full_BIT = 79,
 ETHTOOL_LINK_MODE_200000baseKR2_Full_BIT = 80,
 ETHTOOL_LINK_MODE_200000baseSR2_Full_BIT = 81,
 ETHTOOL_LINK_MODE_200000baseLR2_ER2_FR2_Full_BIT = 82,
 ETHTOOL_LINK_MODE_200000baseDR2_Full_BIT = 83,
 ETHTOOL_LINK_MODE_200000baseCR2_Full_BIT = 84,
 ETHTOOL_LINK_MODE_400000baseKR4_Full_BIT = 85,
 ETHTOOL_LINK_MODE_400000baseSR4_Full_BIT = 86,
 ETHTOOL_LINK_MODE_400000baseLR4_ER4_FR4_Full_BIT = 87,
 ETHTOOL_LINK_MODE_400000baseDR4_Full_BIT = 88,
 ETHTOOL_LINK_MODE_400000baseCR4_Full_BIT = 89,
 ETHTOOL_LINK_MODE_100baseFX_Half_BIT = 90,
 ETHTOOL_LINK_MODE_100baseFX_Full_BIT = 91,
 ETHTOOL_LINK_MODE_10baseT1L_Full_BIT = 92,
 ETHTOOL_LINK_MODE_800000baseCR8_Full_BIT = 93,
 ETHTOOL_LINK_MODE_800000baseKR8_Full_BIT = 94,
 ETHTOOL_LINK_MODE_800000baseDR8_Full_BIT = 95,
 ETHTOOL_LINK_MODE_800000baseDR8_2_Full_BIT = 96,
 ETHTOOL_LINK_MODE_800000baseSR8_Full_BIT = 97,
 ETHTOOL_LINK_MODE_800000baseVR8_Full_BIT = 98,
 ETHTOOL_LINK_MODE_10baseT1S_Full_BIT = 99,
 ETHTOOL_LINK_MODE_10baseT1S_Half_BIT = 100,
 ETHTOOL_LINK_MODE_10baseT1S_P2MP_Half_BIT = 101,
 ETHTOOL_LINK_MODE_10baseT1BRR_Full_BIT = 102,
 ETHTOOL_LINK_MODE_200000baseCR_Full_BIT = 103,
 ETHTOOL_LINK_MODE_200000baseKR_Full_BIT = 104,
 ETHTOOL_LINK_MODE_200000baseDR_Full_BIT = 105,
 ETHTOOL_LINK_MODE_200000baseDR_2_Full_BIT = 106,
 ETHTOOL_LINK_MODE_200000baseSR_Full_BIT = 107,
 ETHTOOL_LINK_MODE_200000baseVR_Full_BIT = 108,
 ETHTOOL_LINK_MODE_400000baseCR2_Full_BIT = 109,
 ETHTOOL_LINK_MODE_400000baseKR2_Full_BIT = 110,
 ETHTOOL_LINK_MODE_400000baseDR2_Full_BIT = 111,
 ETHTOOL_LINK_MODE_400000baseDR2_2_Full_BIT = 112,
 ETHTOOL_LINK_MODE_400000baseSR2_Full_BIT = 113,
 ETHTOOL_LINK_MODE_400000baseVR2_Full_BIT = 114,
 ETHTOOL_LINK_MODE_800000baseCR4_Full_BIT = 115,
 ETHTOOL_LINK_MODE_800000baseKR4_Full_BIT = 116,
 ETHTOOL_LINK_MODE_800000baseDR4_Full_BIT = 117,
 ETHTOOL_LINK_MODE_800000baseDR4_2_Full_BIT = 118,
 ETHTOOL_LINK_MODE_800000baseSR4_Full_BIT = 119,
 ETHTOOL_LINK_MODE_800000baseVR4_Full_BIT = 120,


 __ETHTOOL_LINK_MODE_MASK_NBITS
};
struct ethtool_link_settings {
 __u32 cmd;
 __u32 speed;
 __u8 duplex;
 __u8 port;
 __u8 phy_address;
 __u8 autoneg;
 __u8 mdio_support;
 __u8 eth_tp_mdix;
 __u8 eth_tp_mdix_ctrl;
 __s8 link_mode_masks_nwords;
 __u8 transceiver;
 __u8 master_slave_cfg;
 __u8 master_slave_state;
 __u8 rate_matching;
 __u32 reserved[7];
};
enum ethtool_phys_id_state {
 ETHTOOL_ID_INACTIVE,
 ETHTOOL_ID_ACTIVE,
 ETHTOOL_ID_ON,
 ETHTOOL_ID_OFF
};
struct kernel_ethtool_ringparam {
 u32 rx_buf_len;
 u8 tcp_data_split;
 u8 tx_push;
 u8 rx_push;
 u32 cqe_size;
 u32 tx_push_buf_len;
 u32 tx_push_buf_max_len;
 u32 hds_thresh;
 u32 hds_thresh_max;
};
struct net_device;
struct netlink_ext_ack;
struct ethtool_link_ext_state_info {
 enum ethtool_link_ext_state link_ext_state;
 union {
  enum ethtool_link_ext_substate_autoneg autoneg;
  enum ethtool_link_ext_substate_link_training link_training;
  enum ethtool_link_ext_substate_link_logical_mismatch link_logical_mismatch;
  enum ethtool_link_ext_substate_bad_signal_integrity bad_signal_integrity;
  enum ethtool_link_ext_substate_cable_issue cable_issue;
  enum ethtool_link_ext_substate_module module;
  u32 __link_ext_substate;
 };
};
struct ethtool_link_ext_stats {
 u64 link_down_events;
};
struct ethtool_rxfh_context {
 u32 indir_size;
 u32 key_size;
 u16 priv_size;
 u8 hfunc;
 u8 input_xfrm;
 u8 indir_configured:1;
 u8 key_configured:1;



 u32 key_off;
 u8 data[1] ;
};
struct ethtool_link_ksettings {
 struct ethtool_link_settings base;
 struct {
  unsigned long supported[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
  unsigned long advertising[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
  unsigned long lp_advertising[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 } link_modes;
 u32 lanes;
};
struct ethtool_keee {
 unsigned long supported[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long advertised[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long lp_advertised[(((__ETHTOOL_LINK_MODE_MASK_NBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 u32 tx_lpi_timer;
 bool tx_lpi_enabled;
 bool eee_active;
 bool eee_enabled;
};
struct kernel_ethtool_coalesce {
 u8 use_cqe_mode_tx;
 u8 use_cqe_mode_rx;
 u32 tx_aggr_max_bytes;
 u32 tx_aggr_max_frames;
 u32 tx_aggr_time_usecs;
};
struct ethtool_eth_mac_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 FramesTransmittedOK; u64 SingleCollisionFrames; u64 MultipleCollisionFrames; u64 FramesReceivedOK; u64 FrameCheckSequenceErrors; u64 AlignmentErrors; u64 OctetsTransmittedOK; u64 FramesWithDeferredXmissions; u64 LateCollisions; u64 FramesAbortedDueToXSColls; u64 FramesLostDueToIntMACXmitError; u64 CarrierSenseErrors; u64 OctetsReceivedOK; u64 FramesLostDueToIntMACRcvError; u64 MulticastFramesXmittedOK; u64 BroadcastFramesXmittedOK; u64 FramesWithExcessiveDeferral; u64 MulticastFramesReceivedOK; u64 BroadcastFramesReceivedOK; u64 InRangeLengthErrors; u64 OutOfRangeLengthField; u64 FrameTooLongErrors; } ; struct { u64 FramesTransmittedOK; u64 SingleCollisionFrames; u64 MultipleCollisionFrames; u64 FramesReceivedOK; u64 FrameCheckSequenceErrors; u64 AlignmentErrors; u64 OctetsTransmittedOK; u64 FramesWithDeferredXmissions; u64 LateCollisions; u64 FramesAbortedDueToXSColls; u64 FramesLostDueToIntMACXmitError; u64 CarrierSenseErrors; u64 OctetsReceivedOK; u64 FramesLostDueToIntMACRcvError; u64 MulticastFramesXmittedOK; u64 BroadcastFramesXmittedOK; u64 FramesWithExcessiveDeferral; u64 MulticastFramesReceivedOK; u64 BroadcastFramesReceivedOK; u64 InRangeLengthErrors; u64 OutOfRangeLengthField; u64 FrameTooLongErrors; } stats; }
  ;
};
struct ethtool_eth_phy_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 SymbolErrorDuringCarrier; } ; struct { u64 SymbolErrorDuringCarrier; } stats; }

  ;
};
struct ethtool_eth_ctrl_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 MACControlFramesTransmitted; u64 MACControlFramesReceived; u64 UnsupportedOpcodesReceived; } ; struct { u64 MACControlFramesTransmitted; u64 MACControlFramesReceived; u64 UnsupportedOpcodesReceived; } stats; }



  ;
};
struct ethtool_pause_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 tx_pause_frames; u64 rx_pause_frames; } ; struct { u64 tx_pause_frames; u64 rx_pause_frames; } stats; }


  ;
};
struct ethtool_fec_hist_range {
 u16 low;
 u16 high;
};
struct ethtool_fec_hist {
 struct ethtool_fec_hist_value {
  u64 sum;
  u64 per_lane[8];
 } values[17];
 const struct ethtool_fec_hist_range *ranges;
};
struct ethtool_fec_stats {
 struct ethtool_fec_stat {
  u64 total;
  u64 lanes[8];
 } corrected_blocks, uncorrectable_blocks, corrected_bits;
};
struct ethtool_rmon_hist_range {
 u16 low;
 u16 high;
};
struct ethtool_rmon_stats {
 enum ethtool_mac_stats_src src;
 union { struct { u64 undersize_pkts; u64 oversize_pkts; u64 fragments; u64 jabbers; u64 hist[11]; u64 hist_tx[11]; } ; struct { u64 undersize_pkts; u64 oversize_pkts; u64 fragments; u64 jabbers; u64 hist[11]; u64 hist_tx[11]; } stats; }







  ;
};
struct ethtool_ts_stats {
 union { struct { u64 pkts; u64 onestep_pkts_unconfirmed; u64 lost; u64 err; } ; struct { u64 pkts; u64 onestep_pkts_unconfirmed; u64 lost; u64 err; } tx_stats; }




  ;
};
struct ethtool_module_eeprom {
 u32 offset;
 u32 length;
 u8 page;
 u8 bank;
 u8 i2c_address;
 u8 *data;
};
struct ethtool_module_power_mode_params {
 enum ethtool_module_power_mode_policy policy;
 enum ethtool_module_power_mode mode;
};
struct ethtool_mm_state {
 u32 verify_time;
 u32 max_verify_time;
 enum ethtool_mm_verify_status verify_status;
 bool tx_enabled;
 bool tx_active;
 bool pmac_enabled;
 bool verify_enabled;
 u32 tx_min_frag_size;
 u32 rx_min_frag_size;
};
struct ethtool_mm_cfg {
 u32 verify_time;
 bool verify_enabled;
 bool tx_enabled;
 bool pmac_enabled;
 u32 tx_min_frag_size;
};
struct ethtool_mm_stats {
 u64 MACMergeFrameAssErrorCount;
 u64 MACMergeFrameSmdErrorCount;
 u64 MACMergeFrameAssOkCount;
 u64 MACMergeFragCountRx;
 u64 MACMergeFragCountTx;
 u64 MACMergeHoldCount;
};
struct ethtool_rxfh_param {
 u8 hfunc;
 u32 indir_size;
 u32 *indir;
 u32 key_size;
 u8 *key;
 u32 rss_context;
 u8 rss_delete;
 u8 input_xfrm;
};
struct ethtool_rxfh_fields {
 u32 data;
 u32 flow_type;
 u32 rss_context;
};
struct kernel_ethtool_ts_info {
 u32 cmd;
 u32 so_timestamping;
 int phc_index;
 enum hwtstamp_provider_qualifier phc_qualifier;
 enum hwtstamp_source phc_source;
 int phc_phyindex;
 u32 tx_types;
 u32 rx_filters;
};
struct ethtool_ops {
 u32 supported_input_xfrm:8;
 u32 cap_link_lanes_supported:1;
 u32 rxfh_per_ctx_fields:1;
 u32 rxfh_per_ctx_key:1;
 u32 cap_rss_rxnfc_adds:1;
 u32 rxfh_indir_space;
 u16 rxfh_key_space;
 u16 rxfh_priv_size;
 u32 rxfh_max_num_contexts;
 u32 supported_coalesce_params;
 u32 supported_ring_params;
 u32 supported_hwtstamp_qualifiers;
 void (*get_drvinfo)(struct net_device *, struct ethtool_drvinfo *);
 int (*get_regs_len)(struct net_device *);
 void (*get_regs)(struct net_device *, struct ethtool_regs *, void *);
 void (*get_wol)(struct net_device *, struct ethtool_wolinfo *);
 int (*set_wol)(struct net_device *, struct ethtool_wolinfo *);
 u32 (*get_msglevel)(struct net_device *);
 void (*set_msglevel)(struct net_device *, u32);
 int (*nway_reset)(struct net_device *);
 u32 (*get_link)(struct net_device *);
 int (*get_link_ext_state)(struct net_device *,
          struct ethtool_link_ext_state_info *);
 void (*get_link_ext_stats)(struct net_device *dev,
          struct ethtool_link_ext_stats *stats);
 int (*get_eeprom_len)(struct net_device *);
 int (*get_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*set_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*get_coalesce)(struct net_device *,
    struct ethtool_coalesce *,
    struct kernel_ethtool_coalesce *,
    struct netlink_ext_ack *);
 int (*set_coalesce)(struct net_device *,
    struct ethtool_coalesce *,
    struct kernel_ethtool_coalesce *,
    struct netlink_ext_ack *);
 void (*get_ringparam)(struct net_device *,
     struct ethtool_ringparam *,
     struct kernel_ethtool_ringparam *,
     struct netlink_ext_ack *);
 int (*set_ringparam)(struct net_device *,
     struct ethtool_ringparam *,
     struct kernel_ethtool_ringparam *,
     struct netlink_ext_ack *);
 void (*get_pause_stats)(struct net_device *dev,
       struct ethtool_pause_stats *pause_stats);
 void (*get_pauseparam)(struct net_device *,
      struct ethtool_pauseparam*);
 int (*set_pauseparam)(struct net_device *,
      struct ethtool_pauseparam*);
 void (*self_test)(struct net_device *, struct ethtool_test *, u64 *);
 void (*get_strings)(struct net_device *, u32 stringset, u8 *);
 int (*set_phys_id)(struct net_device *, enum ethtool_phys_id_state);
 void (*get_ethtool_stats)(struct net_device *,
         struct ethtool_stats *, u64 *);
 int (*begin)(struct net_device *);
 void (*complete)(struct net_device *);
 u32 (*get_priv_flags)(struct net_device *);
 int (*set_priv_flags)(struct net_device *, u32);
 int (*get_sset_count)(struct net_device *, int);
 int (*get_rxnfc)(struct net_device *,
        struct ethtool_rxnfc *, u32 *rule_locs);
 int (*set_rxnfc)(struct net_device *, struct ethtool_rxnfc *);
 int (*flash_device)(struct net_device *, struct ethtool_flash *);
 int (*reset)(struct net_device *, u32 *);
 u32 (*get_rx_ring_count)(struct net_device *dev);
 u32 (*get_rxfh_key_size)(struct net_device *);
 u32 (*get_rxfh_indir_size)(struct net_device *);
 int (*get_rxfh)(struct net_device *, struct ethtool_rxfh_param *);
 int (*set_rxfh)(struct net_device *, struct ethtool_rxfh_param *,
       struct netlink_ext_ack *extack);
 int (*get_rxfh_fields)(struct net_device *,
       struct ethtool_rxfh_fields *);
 int (*set_rxfh_fields)(struct net_device *,
       const struct ethtool_rxfh_fields *,
       struct netlink_ext_ack *extack);
 int (*create_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           const struct ethtool_rxfh_param *rxfh,
           struct netlink_ext_ack *extack);
 int (*modify_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           const struct ethtool_rxfh_param *rxfh,
           struct netlink_ext_ack *extack);
 int (*remove_rxfh_context)(struct net_device *,
           struct ethtool_rxfh_context *ctx,
           u32 rss_context,
           struct netlink_ext_ack *extack);
 void (*get_channels)(struct net_device *, struct ethtool_channels *);
 int (*set_channels)(struct net_device *, struct ethtool_channels *);
 int (*get_dump_flag)(struct net_device *, struct ethtool_dump *);
 int (*get_dump_data)(struct net_device *,
     struct ethtool_dump *, void *);
 int (*set_dump)(struct net_device *, struct ethtool_dump *);
 int (*get_ts_info)(struct net_device *, struct kernel_ethtool_ts_info *);
 void (*get_ts_stats)(struct net_device *dev,
    struct ethtool_ts_stats *ts_stats);
 int (*get_module_info)(struct net_device *,
       struct ethtool_modinfo *);
 int (*get_module_eeprom)(struct net_device *,
         struct ethtool_eeprom *, u8 *);
 int (*get_eee)(struct net_device *dev, struct ethtool_keee *eee);
 int (*set_eee)(struct net_device *dev, struct ethtool_keee *eee);
 int (*get_tunable)(struct net_device *,
          const struct ethtool_tunable *, void *);
 int (*set_tunable)(struct net_device *,
          const struct ethtool_tunable *, const void *);
 int (*get_per_queue_coalesce)(struct net_device *, u32,
       struct ethtool_coalesce *);
 int (*set_per_queue_coalesce)(struct net_device *, u32,
       struct ethtool_coalesce *);
 int (*get_link_ksettings)(struct net_device *,
          struct ethtool_link_ksettings *);
 int (*set_link_ksettings)(struct net_device *,
          const struct ethtool_link_ksettings *);
 void (*get_fec_stats)(struct net_device *dev,
     struct ethtool_fec_stats *fec_stats,
     struct ethtool_fec_hist *hist);
 int (*get_fecparam)(struct net_device *,
          struct ethtool_fecparam *);
 int (*set_fecparam)(struct net_device *,
          struct ethtool_fecparam *);
 void (*get_ethtool_phy_stats)(struct net_device *,
      struct ethtool_stats *, u64 *);
 int (*get_phy_tunable)(struct net_device *,
       const struct ethtool_tunable *, void *);
 int (*set_phy_tunable)(struct net_device *,
       const struct ethtool_tunable *, const void *);
 int (*get_module_eeprom_by_page)(struct net_device *dev,
          const struct ethtool_module_eeprom *page,
          struct netlink_ext_ack *extack);
 int (*set_module_eeprom_by_page)(struct net_device *dev,
          const struct ethtool_module_eeprom *page,
          struct netlink_ext_ack *extack);
 void (*get_eth_phy_stats)(struct net_device *dev,
         struct ethtool_eth_phy_stats *phy_stats);
 void (*get_eth_mac_stats)(struct net_device *dev,
         struct ethtool_eth_mac_stats *mac_stats);
 void (*get_eth_ctrl_stats)(struct net_device *dev,
          struct ethtool_eth_ctrl_stats *ctrl_stats);
 void (*get_rmon_stats)(struct net_device *dev,
      struct ethtool_rmon_stats *rmon_stats,
      const struct ethtool_rmon_hist_range **ranges);
 int (*get_module_power_mode)(struct net_device *dev,
      struct ethtool_module_power_mode_params *params,
      struct netlink_ext_ack *extack);
 int (*set_module_power_mode)(struct net_device *dev,
      const struct ethtool_module_power_mode_params *params,
      struct netlink_ext_ack *extack);
 int (*get_mm)(struct net_device *dev, struct ethtool_mm_state *state);
 int (*set_mm)(struct net_device *dev, struct ethtool_mm_cfg *cfg,
     struct netlink_ext_ack *extack);
 void (*get_mm_stats)(struct net_device *dev, struct ethtool_mm_stats *stats);
};
struct ethtool_netdev_state {
 struct xarray rss_ctx;
 struct mutex rss_lock;
 unsigned wol_enabled:1;
 unsigned module_fw_flash_in_progress:1;
};
struct phy_device;
struct irq_poll;
typedef int (irq_poll_fn)(struct irq_poll *, int);
struct irq_poll {
 struct list_head list;
 unsigned long state;
 int weight;
 irq_poll_fn *poll;
};
struct rdma_cgroup {
 struct cgroup_subsys_state css;





 struct list_head rpools;
};
struct rdmacg_device {
 struct list_head dev_node;
 struct list_head rpools;
 char *name;
};
struct net_device;
struct dim_cq_moder {
 u16 usec;
 u16 pkts;
 u16 comps;
 u8 cq_period_mode;
 struct callback_head rcu;
};
struct dim_irq_moder {
 u8 profile_flags;
 u8 coal_flags;
 u8 dim_rx_mode;
 u8 dim_tx_mode;
 struct dim_cq_moder *rx_profile;
 struct dim_cq_moder *tx_profile;
 void (*rx_dim_work)(struct work_struct *work);
 void (*tx_dim_work)(struct work_struct *work);
};
struct dim_sample {
 ktime_t time;
 u32 pkt_ctr;
 u32 byte_ctr;
 u16 event_ctr;
 u32 comp_ctr;
};
struct dim_stats {
 int ppms;
 int bpms;
 int epms;
 int cpms;
 int cpe_ratio;
};
struct dim {
 u8 state;
 struct dim_stats prev_stats;
 struct dim_sample start_sample;
 struct dim_sample measuring_sample;
 struct work_struct work;
 void *priv;
 u8 profile_ix;
 u8 mode;
 u8 tune_state;
 u8 steps_right;
 u8 steps_left;
 u8 tired;
};
enum ib_uverbs_wc_opcode {
 IB_UVERBS_WC_SEND = 0,
 IB_UVERBS_WC_RDMA_WRITE = 1,
 IB_UVERBS_WC_RDMA_READ = 2,
 IB_UVERBS_WC_COMP_SWAP = 3,
 IB_UVERBS_WC_FETCH_ADD = 4,
 IB_UVERBS_WC_BIND_MW = 5,
 IB_UVERBS_WC_LOCAL_INV = 6,
 IB_UVERBS_WC_TSO = 7,
 IB_UVERBS_WC_FLUSH = 8,
 IB_UVERBS_WC_ATOMIC_WRITE = 9,
};
enum ib_uverbs_wr_opcode {
 IB_UVERBS_WR_RDMA_WRITE = 0,
 IB_UVERBS_WR_RDMA_WRITE_WITH_IMM = 1,
 IB_UVERBS_WR_SEND = 2,
 IB_UVERBS_WR_SEND_WITH_IMM = 3,
 IB_UVERBS_WR_RDMA_READ = 4,
 IB_UVERBS_WR_ATOMIC_CMP_AND_SWP = 5,
 IB_UVERBS_WR_ATOMIC_FETCH_AND_ADD = 6,
 IB_UVERBS_WR_LOCAL_INV = 7,
 IB_UVERBS_WR_BIND_MW = 8,
 IB_UVERBS_WR_SEND_WITH_INV = 9,
 IB_UVERBS_WR_TSO = 10,
 IB_UVERBS_WR_RDMA_READ_WITH_INV = 11,
 IB_UVERBS_WR_MASKED_ATOMIC_CMP_AND_SWP = 12,
 IB_UVERBS_WR_MASKED_ATOMIC_FETCH_AND_ADD = 13,
 IB_UVERBS_WR_FLUSH = 14,
 IB_UVERBS_WR_ATOMIC_WRITE = 15,

};
enum rdma_nl_counter_mode {
 RDMA_COUNTER_MODE_NONE,





 RDMA_COUNTER_MODE_AUTO,





 RDMA_COUNTER_MODE_MANUAL,




 RDMA_COUNTER_MODE_MAX,
};
enum rdma_nl_counter_mask {
 RDMA_COUNTER_MASK_QP_TYPE = 1,
 RDMA_COUNTER_MASK_PID = 1 << 1,
};
enum rdma_nl_dev_type {
 RDMA_DEVICE_TYPE_SMI = 1,
};
enum rdma_nl_name_assign_type {
 RDMA_NAME_ASSIGN_TYPE_UNKNOWN = 0,
 RDMA_NAME_ASSIGN_TYPE_USER = 1,
};
struct ib_device;
struct sk_buff;
enum rdma_restrack_type {



 RDMA_RESTRACK_PD,



 RDMA_RESTRACK_CQ,



 RDMA_RESTRACK_QP,



 RDMA_RESTRACK_CM_ID,



 RDMA_RESTRACK_MR,



 RDMA_RESTRACK_CTX,



 RDMA_RESTRACK_COUNTER,



 RDMA_RESTRACK_SRQ,



 RDMA_RESTRACK_DMAH,



 RDMA_RESTRACK_MAX
};
struct rdma_restrack_entry {
 bool valid;







 u8 no_track : 1;



 struct kref kref;



 struct completion comp;
 struct task_struct *task;



 const char *kern_name;



 enum rdma_restrack_type type;



 bool user;



 u32 id;
};
struct ib_device;
struct rdma_link_ops {
 struct list_head list;
 const char *type;
 int (*newlink)(const char *ibdev_name, struct net_device *ndev);
};
struct ib_device;
struct ib_qp;
struct auto_mode_param {
 int qp_type;
};
struct rdma_counter_mode {
 enum rdma_nl_counter_mode mode;
 enum rdma_nl_counter_mask mask;
 struct auto_mode_param param;
 bool bind_opcnt;
};
struct rdma_port_counter {
 struct rdma_counter_mode mode;
 struct rdma_hw_stats *hstats;
 unsigned int num_counters;
 struct mutex lock;
};
struct rdma_counter {
 struct rdma_restrack_entry res;
 struct ib_device *device;
 uint32_t id;
 struct kref kref;
 struct rdma_counter_mode mode;
 struct mutex lock;
 struct rdma_hw_stats *stats;
 u32 port;
};
enum ib_signature_type {
 IB_SIG_TYPE_NONE,
 IB_SIG_TYPE_T10_DIF,
};
enum ib_t10_dif_bg_type {
 IB_T10DIF_CRC,
 IB_T10DIF_CSUM,
};
struct ib_t10_dif_domain {
 enum ib_t10_dif_bg_type bg_type;
 u16 pi_interval;
 u16 bg;
 u16 app_tag;
 u32 ref_tag;
 bool ref_remap;
 bool app_escape;
 bool ref_escape;
 u16 apptag_check_mask;
};
struct ib_sig_domain {
 enum ib_signature_type sig_type;
 union {
  struct ib_t10_dif_domain dif;
 } sig;
};
struct ib_sig_attrs {
 u8 check_mask;
 struct ib_sig_domain mem;
 struct ib_sig_domain wire;
 int meta_length;
};
enum ib_sig_err_type {
 IB_SIG_BAD_GUARD,
 IB_SIG_BAD_REFTAG,
 IB_SIG_BAD_APPTAG,
};
struct ib_sig_err {
 enum ib_sig_err_type err_type;
 u32 expected;
 u32 actual;
 u64 sig_err_offset;
 u32 key;
};
enum ib_uverbs_srq_type {
 IB_UVERBS_SRQT_BASIC,
 IB_UVERBS_SRQT_XRC,
 IB_UVERBS_SRQT_TM,
};
enum ib_uverbs_wq_type {
 IB_UVERBS_WQT_RQ,
};
enum ib_uverbs_qp_type {
 IB_UVERBS_QPT_RC = 2,
 IB_UVERBS_QPT_UC,
 IB_UVERBS_QPT_UD,
 IB_UVERBS_QPT_RAW_PACKET = 8,
 IB_UVERBS_QPT_XRC_INI,
 IB_UVERBS_QPT_XRC_TGT,
 IB_UVERBS_QPT_DRIVER = 0xFF,
};
enum ib_uverbs_advise_mr_advice {
 IB_UVERBS_ADVISE_MR_ADVICE_PREFETCH,
 IB_UVERBS_ADVISE_MR_ADVICE_PREFETCH_WRITE,
 IB_UVERBS_ADVISE_MR_ADVICE_PREFETCH_NO_FAULT,
};
enum rdma_driver_id {
 RDMA_DRIVER_UNKNOWN,
 RDMA_DRIVER_MLX5,
 RDMA_DRIVER_MLX4,
 RDMA_DRIVER_CXGB3,
 RDMA_DRIVER_CXGB4,
 RDMA_DRIVER_MTHCA,
 RDMA_DRIVER_BNXT_RE,
 RDMA_DRIVER_OCRDMA,
 RDMA_DRIVER_NES,
 RDMA_DRIVER_I40IW,
 RDMA_DRIVER_IRDMA = RDMA_DRIVER_I40IW,
 RDMA_DRIVER_VMW_PVRDMA,
 RDMA_DRIVER_QEDR,
 RDMA_DRIVER_HNS,
 RDMA_DRIVER_USNIC,
 RDMA_DRIVER_RXE,
 RDMA_DRIVER_HFI1,
 RDMA_DRIVER_QIB,
 RDMA_DRIVER_EFA,
 RDMA_DRIVER_SIW,
 RDMA_DRIVER_ERDMA,
 RDMA_DRIVER_MANA,
 RDMA_DRIVER_IONIC,
};
enum ib_uverbs_gid_type {
 IB_UVERBS_GID_TYPE_IB,
 IB_UVERBS_GID_TYPE_ROCE_V1,
 IB_UVERBS_GID_TYPE_ROCE_V2,
};
enum tph_mem_type {
 TPH_MEM_TYPE_VM,
 TPH_MEM_TYPE_PM
};
struct ib_uqp_object;
struct ib_usrq_object;
struct ib_uwq_object;
struct rdma_cm_id;
struct ib_port;
struct hw_stats_device_data;
extern struct workqueue_struct *ib_wq;
struct ib_ucq_object;
union ib_gid {
 u8 raw[16];
 struct {
  __be64 subnet_prefix;
  __be64 interface_id;
 } global;
};
enum ib_gid_type {
 IB_GID_TYPE_IB = IB_UVERBS_GID_TYPE_IB,
 IB_GID_TYPE_ROCE = IB_UVERBS_GID_TYPE_ROCE_V1,
 IB_GID_TYPE_ROCE_UDP_ENCAP = IB_UVERBS_GID_TYPE_ROCE_V2,
 IB_GID_TYPE_SIZE
};
struct ib_gid_attr {
 struct net_device *ndev;
 struct ib_device *device;
 union ib_gid gid;
 enum ib_gid_type gid_type;
 u16 index;
 u32 port_num;
};
enum rdma_link_layer {
 IB_LINK_LAYER_UNSPECIFIED,
 IB_LINK_LAYER_INFINIBAND,
 IB_LINK_LAYER_ETHERNET,
};
enum ib_atomic_cap {
 IB_ATOMIC_NONE,
 IB_ATOMIC_HCA,
 IB_ATOMIC_GLOB
};
struct ib_odp_caps {
 uint64_t general_caps;
 struct {
  uint32_t rc_odp_caps;
  uint32_t uc_odp_caps;
  uint32_t ud_odp_caps;
  uint32_t xrc_odp_caps;
 } per_transport_caps;
};
struct ib_rss_caps {




 u32 supported_qpts;
 u32 max_rwq_indirection_tables;
 u32 max_rwq_indirection_table_size;
};
struct ib_tm_caps {

 u32 max_rndv_hdr_size;

 u32 max_num_tags;

 u32 flags;

 u32 max_ops;

 u32 max_sge;
};
struct ib_cq_init_attr {
 unsigned int cqe;
 u32 comp_vector;
 u32 flags;
};
struct ib_cq_caps {
 u16 max_cq_moderation_count;
 u16 max_cq_moderation_period;
};
struct ib_dm_mr_attr {
 u64 length;
 u64 offset;
 u32 access_flags;
};
struct ib_dm_alloc_attr {
 u64 length;
 u32 alignment;
 u32 flags;
};
struct ib_device_attr {
 u64 fw_ver;
 __be64 sys_image_guid;
 u64 max_mr_size;
 u64 page_size_cap;
 u32 vendor_id;
 u32 vendor_part_id;
 u32 hw_ver;
 int max_qp;
 int max_qp_wr;
 u64 device_cap_flags;
 u64 kernel_cap_flags;
 int max_send_sge;
 int max_recv_sge;
 int max_sge_rd;
 int max_cq;
 int max_cqe;
 int max_mr;
 int max_pd;
 int max_qp_rd_atom;
 int max_ee_rd_atom;
 int max_res_rd_atom;
 int max_qp_init_rd_atom;
 int max_ee_init_rd_atom;
 enum ib_atomic_cap atomic_cap;
 enum ib_atomic_cap masked_atomic_cap;
 int max_ee;
 int max_rdd;
 int max_mw;
 int max_raw_ipv6_qp;
 int max_raw_ethy_qp;
 int max_mcast_grp;
 int max_mcast_qp_attach;
 int max_total_mcast_qp_attach;
 int max_ah;
 int max_srq;
 int max_srq_wr;
 int max_srq_sge;
 unsigned int max_fast_reg_page_list_len;
 unsigned int max_pi_fast_reg_page_list_len;
 u16 max_pkeys;
 u8 local_ca_ack_delay;
 int sig_prot_cap;
 int sig_guard_cap;
 struct ib_odp_caps odp_caps;
 uint64_t timestamp_mask;
 uint64_t hca_core_clock;
 struct ib_rss_caps rss_caps;
 u32 max_wq_type_rq;
 u32 raw_packet_caps;
 struct ib_tm_caps tm_caps;
 struct ib_cq_caps cq_caps;
 u64 max_dm_size;

 u32 max_sgl_rd;
};
enum ib_mtu {
 IB_MTU_256 = 1,
 IB_MTU_512 = 2,
 IB_MTU_1024 = 3,
 IB_MTU_2048 = 4,
 IB_MTU_4096 = 5
};
enum ib_port_state {
 IB_PORT_NOP = 0,
 IB_PORT_DOWN = 1,
 IB_PORT_INIT = 2,
 IB_PORT_ARMED = 3,
 IB_PORT_ACTIVE = 4,
 IB_PORT_ACTIVE_DEFER = 5
};
struct rdma_stat_desc {
 const char *name;
 unsigned int flags;
 const void *priv;
};
struct rdma_hw_stats {
 struct mutex lock;
 unsigned long timestamp;
 unsigned long lifespan;
 const struct rdma_stat_desc *descs;
 unsigned long *is_disabled;
 int num_counters;
 u64 value[1] ;
};
struct ib_port_attr {
 u64 subnet_prefix;
 enum ib_port_state state;
 enum ib_mtu max_mtu;
 enum ib_mtu active_mtu;
 u32 phys_mtu;
 int gid_tbl_len;
 unsigned int ip_gids:1;

 u32 port_cap_flags;
 u32 max_msg_sz;
 u32 bad_pkey_cntr;
 u32 qkey_viol_cntr;
 u16 pkey_tbl_len;
 u32 sm_lid;
 u32 lid;
 u8 lmc;
 u8 max_vl_num;
 u8 sm_sl;
 u8 subnet_timeout;
 u8 init_type_reply;
 u8 active_width;
 u16 active_speed;
 u8 phys_state;
 u16 port_cap_flags2;
};
struct ib_device_modify {
 u64 sys_image_guid;
 char node_desc[64];
};
struct ib_port_modify {
 u32 set_port_cap_mask;
 u32 clr_port_cap_mask;
 u8 init_type;
};
enum ib_event_type {
 IB_EVENT_CQ_ERR,
 IB_EVENT_QP_FATAL,
 IB_EVENT_QP_REQ_ERR,
 IB_EVENT_QP_ACCESS_ERR,
 IB_EVENT_COMM_EST,
 IB_EVENT_SQ_DRAINED,
 IB_EVENT_PATH_MIG,
 IB_EVENT_PATH_MIG_ERR,
 IB_EVENT_DEVICE_FATAL,
 IB_EVENT_PORT_ACTIVE,
 IB_EVENT_PORT_ERR,
 IB_EVENT_LID_CHANGE,
 IB_EVENT_PKEY_CHANGE,
 IB_EVENT_SM_CHANGE,
 IB_EVENT_SRQ_ERR,
 IB_EVENT_SRQ_LIMIT_REACHED,
 IB_EVENT_QP_LAST_WQE_REACHED,
 IB_EVENT_CLIENT_REREGISTER,
 IB_EVENT_GID_CHANGE,
 IB_EVENT_WQ_FATAL,
};
struct ib_event {
 struct ib_device *device;
 union {
  struct ib_cq *cq;
  struct ib_qp *qp;
  struct ib_srq *srq;
  struct ib_wq *wq;
  u32 port_num;
 } element;
 enum ib_event_type event;
};
struct ib_event_handler {
 struct ib_device *device;
 void (*handler)(struct ib_event_handler *, struct ib_event *);
 struct list_head list;
};
struct ib_global_route {
 const struct ib_gid_attr *sgid_attr;
 union ib_gid dgid;
 u32 flow_label;
 u8 sgid_index;
 u8 hop_limit;
 u8 traffic_class;
};
struct ib_grh {
 __be32 version_tclass_flow;
 __be16 paylen;
 u8 next_hdr;
 u8 hop_limit;
 union ib_gid sgid;
 union ib_gid dgid;
};
enum ib_mr_type {
 IB_MR_TYPE_MEM_REG,
 IB_MR_TYPE_SG_GAPS,
 IB_MR_TYPE_DM,
 IB_MR_TYPE_USER,
 IB_MR_TYPE_DMA,
 IB_MR_TYPE_INTEGRITY,
};
struct ib_mr_status {
 u32 fail_status;
 struct ib_sig_err sig_err;
};
struct rdma_ah_init_attr {
 struct rdma_ah_attr *ah_attr;
 u32 flags;
 struct net_device *xmit_slave;
};
enum rdma_ah_attr_type {
 RDMA_AH_ATTR_TYPE_UNDEFINED,
 RDMA_AH_ATTR_TYPE_IB,
 RDMA_AH_ATTR_TYPE_ROCE,
 RDMA_AH_ATTR_TYPE_OPA,
};
struct ib_ah_attr {
 u16 dlid;
 u8 src_path_bits;
};
struct roce_ah_attr {
 u8 dmac[6];
};
struct opa_ah_attr {
 u32 dlid;
 u8 src_path_bits;
 bool make_grd;
};
struct rdma_ah_attr {
 struct ib_global_route grh;
 u8 sl;
 u8 static_rate;
 u32 port_num;
 u8 ah_flags;
 enum rdma_ah_attr_type type;
 union {
  struct ib_ah_attr ib;
  struct roce_ah_attr roce;
  struct opa_ah_attr opa;
 };
};
enum ib_wc_status {
 IB_WC_SUCCESS,
 IB_WC_LOC_LEN_ERR,
 IB_WC_LOC_QP_OP_ERR,
 IB_WC_LOC_EEC_OP_ERR,
 IB_WC_LOC_PROT_ERR,
 IB_WC_WR_FLUSH_ERR,
 IB_WC_MW_BIND_ERR,
 IB_WC_BAD_RESP_ERR,
 IB_WC_LOC_ACCESS_ERR,
 IB_WC_REM_INV_REQ_ERR,
 IB_WC_REM_ACCESS_ERR,
 IB_WC_REM_OP_ERR,
 IB_WC_RETRY_EXC_ERR,
 IB_WC_RNR_RETRY_EXC_ERR,
 IB_WC_LOC_RDD_VIOL_ERR,
 IB_WC_REM_INV_RD_REQ_ERR,
 IB_WC_REM_ABORT_ERR,
 IB_WC_INV_EECN_ERR,
 IB_WC_INV_EEC_STATE_ERR,
 IB_WC_FATAL_ERR,
 IB_WC_RESP_TIMEOUT_ERR,
 IB_WC_GENERAL_ERR
};
enum ib_wc_opcode {
 IB_WC_SEND = IB_UVERBS_WC_SEND,
 IB_WC_RDMA_WRITE = IB_UVERBS_WC_RDMA_WRITE,
 IB_WC_RDMA_READ = IB_UVERBS_WC_RDMA_READ,
 IB_WC_COMP_SWAP = IB_UVERBS_WC_COMP_SWAP,
 IB_WC_FETCH_ADD = IB_UVERBS_WC_FETCH_ADD,
 IB_WC_BIND_MW = IB_UVERBS_WC_BIND_MW,
 IB_WC_LOCAL_INV = IB_UVERBS_WC_LOCAL_INV,
 IB_WC_LSO = IB_UVERBS_WC_TSO,
 IB_WC_ATOMIC_WRITE = IB_UVERBS_WC_ATOMIC_WRITE,
 IB_WC_REG_MR,
 IB_WC_MASKED_COMP_SWAP,
 IB_WC_MASKED_FETCH_ADD,
 IB_WC_FLUSH = IB_UVERBS_WC_FLUSH,




 IB_WC_RECV = 1 << 7,
 IB_WC_RECV_RDMA_WITH_IMM
};
struct ib_wc {
 union {
  u64 wr_id;
  struct ib_cqe *wr_cqe;
 };
 enum ib_wc_status status;
 enum ib_wc_opcode opcode;
 u32 vendor_err;
 u32 byte_len;
 struct ib_qp *qp;
 union {
  __be32 imm_data;
  u32 invalidate_rkey;
 } ex;
 u32 src_qp;
 u32 slid;
 int wc_flags;
 u16 pkey_index;
 u8 sl;
 u8 dlid_path_bits;
 u32 port_num;
 u8 smac[6];
 u16 vlan_id;
 u8 network_hdr_type;
};
enum ib_cq_notify_flags {
 IB_CQ_SOLICITED = 1 << 0,
 IB_CQ_NEXT_COMP = 1 << 1,
 IB_CQ_SOLICITED_MASK = IB_CQ_SOLICITED | IB_CQ_NEXT_COMP,
 IB_CQ_REPORT_MISSED_EVENTS = 1 << 2,
};
enum ib_srq_type {
 IB_SRQT_BASIC = IB_UVERBS_SRQT_BASIC,
 IB_SRQT_XRC = IB_UVERBS_SRQT_XRC,
 IB_SRQT_TM = IB_UVERBS_SRQT_TM,
};
enum ib_srq_attr_mask {
 IB_SRQ_MAX_WR = 1 << 0,
 IB_SRQ_LIMIT = 1 << 1,
};
struct ib_srq_attr {
 u32 max_wr;
 u32 max_sge;
 u32 srq_limit;
};
struct ib_srq_init_attr {
 void (*event_handler)(struct ib_event *, void *);
 void *srq_context;
 struct ib_srq_attr attr;
 enum ib_srq_type srq_type;

 struct {
  struct ib_cq *cq;
  union {
   struct {
    struct ib_xrcd *xrcd;
   } xrc;

   struct {
    u32 max_num_tags;
   } tag_matching;
  };
 } ext;
};
struct ib_qp_cap {
 u32 max_send_wr;
 u32 max_recv_wr;
 u32 max_send_sge;
 u32 max_recv_sge;
 u32 max_inline_data;






 u32 max_rdma_ctxs;
};
enum ib_sig_type {
 IB_SIGNAL_ALL_WR,
 IB_SIGNAL_REQ_WR
};
enum ib_qp_type {





 IB_QPT_SMI,
 IB_QPT_GSI,

 IB_QPT_RC = IB_UVERBS_QPT_RC,
 IB_QPT_UC = IB_UVERBS_QPT_UC,
 IB_QPT_UD = IB_UVERBS_QPT_UD,
 IB_QPT_RAW_IPV6,
 IB_QPT_RAW_ETHERTYPE,
 IB_QPT_RAW_PACKET = IB_UVERBS_QPT_RAW_PACKET,
 IB_QPT_XRC_INI = IB_UVERBS_QPT_XRC_INI,
 IB_QPT_XRC_TGT = IB_UVERBS_QPT_XRC_TGT,
 IB_QPT_MAX,
 IB_QPT_DRIVER = IB_UVERBS_QPT_DRIVER,




 IB_QPT_RESERVED1 = 0x1000,
 IB_QPT_RESERVED2,
 IB_QPT_RESERVED3,
 IB_QPT_RESERVED4,
 IB_QPT_RESERVED5,
 IB_QPT_RESERVED6,
 IB_QPT_RESERVED7,
 IB_QPT_RESERVED8,
 IB_QPT_RESERVED9,
 IB_QPT_RESERVED10,
};
struct ib_qp_init_attr {

 void (*event_handler)(struct ib_event *, void *);

 void *qp_context;
 struct ib_cq *send_cq;
 struct ib_cq *recv_cq;
 struct ib_srq *srq;
 struct ib_xrcd *xrcd;
 struct ib_qp_cap cap;
 enum ib_sig_type sq_sig_type;
 enum ib_qp_type qp_type;
 u32 create_flags;




 u32 port_num;
 struct ib_rwq_ind_table *rwq_ind_tbl;
 u32 source_qpn;
};
enum ib_qp_state {
 IB_QPS_RESET,
 IB_QPS_INIT,
 IB_QPS_RTR,
 IB_QPS_RTS,
 IB_QPS_SQD,
 IB_QPS_SQE,
 IB_QPS_ERR
};
enum ib_mig_state {
 IB_MIG_MIGRATED,
 IB_MIG_REARM,
 IB_MIG_ARMED
};
enum ib_mw_type {
 IB_MW_TYPE_1 = 1,
 IB_MW_TYPE_2 = 2
};
struct ib_qp_attr {
 enum ib_qp_state qp_state;
 enum ib_qp_state cur_qp_state;
 enum ib_mtu path_mtu;
 enum ib_mig_state path_mig_state;
 u32 qkey;
 u32 rq_psn;
 u32 sq_psn;
 u32 dest_qp_num;
 int qp_access_flags;
 struct ib_qp_cap cap;
 struct rdma_ah_attr ah_attr;
 struct rdma_ah_attr alt_ah_attr;
 u16 pkey_index;
 u16 alt_pkey_index;
 u8 en_sqd_async_notify;
 u8 sq_draining;
 u8 max_rd_atomic;
 u8 max_dest_rd_atomic;
 u8 min_rnr_timer;
 u32 port_num;
 u8 timeout;
 u8 retry_cnt;
 u8 rnr_retry;
 u32 alt_port_num;
 u8 alt_timeout;
 u32 rate_limit;
 struct net_device *xmit_slave;
};
enum ib_wr_opcode {

 IB_WR_RDMA_WRITE = IB_UVERBS_WR_RDMA_WRITE,
 IB_WR_RDMA_WRITE_WITH_IMM = IB_UVERBS_WR_RDMA_WRITE_WITH_IMM,
 IB_WR_SEND = IB_UVERBS_WR_SEND,
 IB_WR_SEND_WITH_IMM = IB_UVERBS_WR_SEND_WITH_IMM,
 IB_WR_RDMA_READ = IB_UVERBS_WR_RDMA_READ,
 IB_WR_ATOMIC_CMP_AND_SWP = IB_UVERBS_WR_ATOMIC_CMP_AND_SWP,
 IB_WR_ATOMIC_FETCH_AND_ADD = IB_UVERBS_WR_ATOMIC_FETCH_AND_ADD,
 IB_WR_BIND_MW = IB_UVERBS_WR_BIND_MW,
 IB_WR_LSO = IB_UVERBS_WR_TSO,
 IB_WR_SEND_WITH_INV = IB_UVERBS_WR_SEND_WITH_INV,
 IB_WR_RDMA_READ_WITH_INV = IB_UVERBS_WR_RDMA_READ_WITH_INV,
 IB_WR_LOCAL_INV = IB_UVERBS_WR_LOCAL_INV,
 IB_WR_MASKED_ATOMIC_CMP_AND_SWP =
  IB_UVERBS_WR_MASKED_ATOMIC_CMP_AND_SWP,
 IB_WR_MASKED_ATOMIC_FETCH_AND_ADD =
  IB_UVERBS_WR_MASKED_ATOMIC_FETCH_AND_ADD,
 IB_WR_FLUSH = IB_UVERBS_WR_FLUSH,
 IB_WR_ATOMIC_WRITE = IB_UVERBS_WR_ATOMIC_WRITE,


 IB_WR_REG_MR = 0x20,
 IB_WR_REG_MR_INTEGRITY,




 IB_WR_RESERVED1 = 0xf0,
 IB_WR_RESERVED2,
 IB_WR_RESERVED3,
 IB_WR_RESERVED4,
 IB_WR_RESERVED5,
 IB_WR_RESERVED6,
 IB_WR_RESERVED7,
 IB_WR_RESERVED8,
 IB_WR_RESERVED9,
 IB_WR_RESERVED10,
};
struct ib_sge {
 u64 addr;
 u32 length;
 u32 lkey;
};
struct ib_cqe {
 void (*done)(struct ib_cq *cq, struct ib_wc *wc);
};
struct ib_send_wr {
 struct ib_send_wr *next;
 union {
  u64 wr_id;
  struct ib_cqe *wr_cqe;
 };
 struct ib_sge *sg_list;
 int num_sge;
 enum ib_wr_opcode opcode;
 int send_flags;
 union {
  __be32 imm_data;
  u32 invalidate_rkey;
 } ex;
};
struct ib_rdma_wr {
 struct ib_send_wr wr;
 u64 remote_addr;
 u32 rkey;
};
struct ib_reg_wr {
 struct ib_send_wr wr;
 struct ib_mr *mr;
 u32 key;
 int access;
};
struct ib_recv_wr {
 struct ib_recv_wr *next;
 union {
  u64 wr_id;
  struct ib_cqe *wr_cqe;
 };
 struct ib_sge *sg_list;
 int num_sge;
};
struct ib_umem;
struct ib_rdmacg_object {

 struct rdma_cgroup *cg;

};
struct ib_ucontext {
 struct ib_device *device;
 struct ib_uverbs_file *ufile;

 struct ib_rdmacg_object cg_obj;
 u64 enabled_caps;



 struct rdma_restrack_entry res;
 struct xarray mmap_xa;
};
struct ib_uobject {
 u64 user_handle;

 struct ib_uverbs_file *ufile;

 struct ib_ucontext *context;
 void *object;
 struct list_head list;
 struct ib_rdmacg_object cg_obj;
 int id;
 struct kref ref;
 atomic_t usecnt;
 struct callback_head rcu;

 const struct uverbs_api_object *uapi_object;
};
struct ib_udata {
 const void *inbuf;
 void *outbuf;
 size_t inlen;
 size_t outlen;
};
struct ib_pd {
 u32 local_dma_lkey;
 u32 flags;
 struct ib_device *device;
 struct ib_uobject *uobject;
 atomic_t usecnt;

 u32 unsafe_global_rkey;




 struct ib_mr *__internal_mr;
 struct rdma_restrack_entry res;
};
struct ib_xrcd {
 struct ib_device *device;
 atomic_t usecnt;
 struct inode *inode;
 struct rw_semaphore tgt_qps_rwsem;
 struct xarray tgt_qps;
};
struct ib_ah {
 struct ib_device *device;
 struct ib_pd *pd;
 struct ib_uobject *uobject;
 const struct ib_gid_attr *sgid_attr;
 enum rdma_ah_attr_type type;
};
typedef void (*ib_comp_handler)(struct ib_cq *cq, void *cq_context);
enum ib_poll_context {
 IB_POLL_SOFTIRQ,
 IB_POLL_WORKQUEUE,
 IB_POLL_UNBOUND_WORKQUEUE,
 IB_POLL_LAST_POOL_TYPE = IB_POLL_UNBOUND_WORKQUEUE,

 IB_POLL_DIRECT,
};
struct ib_cq {
 struct ib_device *device;
 struct ib_ucq_object *uobject;
 ib_comp_handler comp_handler;
 void (*event_handler)(struct ib_event *, void *);
 void *cq_context;
 int cqe;
 unsigned int cqe_used;
 atomic_t usecnt;
 enum ib_poll_context poll_ctx;
 struct ib_wc *wc;
 struct list_head pool_entry;
 union {
  struct irq_poll iop;
  struct work_struct work;
 };
 struct workqueue_struct *comp_wq;
 struct dim *dim;


 ktime_t timestamp;
 u8 interrupt:1;
 u8 shared:1;
 unsigned int comp_vector;




 struct rdma_restrack_entry res;
};
struct ib_srq {
 struct ib_device *device;
 struct ib_pd *pd;
 struct ib_usrq_object *uobject;
 void (*event_handler)(struct ib_event *, void *);
 void *srq_context;
 enum ib_srq_type srq_type;
 atomic_t usecnt;

 struct {
  struct ib_cq *cq;
  union {
   struct {
    struct ib_xrcd *xrcd;
    u32 srq_num;
   } xrc;
  };
 } ext;




 struct rdma_restrack_entry res;
};
enum ib_wq_type {
 IB_WQT_RQ = IB_UVERBS_WQT_RQ,
};
enum ib_wq_state {
 IB_WQS_RESET,
 IB_WQS_RDY,
 IB_WQS_ERR
};
struct ib_wq {
 struct ib_device *device;
 struct ib_uwq_object *uobject;
 void *wq_context;
 void (*event_handler)(struct ib_event *, void *);
 struct ib_pd *pd;
 struct ib_cq *cq;
 u32 wq_num;
 enum ib_wq_state state;
 enum ib_wq_type wq_type;
 atomic_t usecnt;
};
struct ib_wq_init_attr {
 void *wq_context;
 enum ib_wq_type wq_type;
 u32 max_wr;
 u32 max_sge;
 struct ib_cq *cq;
 void (*event_handler)(struct ib_event *, void *);
 u32 create_flags;
};
struct ib_wq_attr {
 enum ib_wq_state wq_state;
 enum ib_wq_state curr_wq_state;
 u32 flags;
 u32 flags_mask;
};
struct ib_rwq_ind_table {
 struct ib_device *device;
 struct ib_uobject *uobject;
 atomic_t usecnt;
 u32 ind_tbl_num;
 u32 log_ind_tbl_size;
 struct ib_wq **ind_tbl;
};
struct ib_rwq_ind_table_init_attr {
 u32 log_ind_tbl_size;

 struct ib_wq **ind_tbl;
};
enum port_pkey_state {
 IB_PORT_PKEY_NOT_VALID = 0,
 IB_PORT_PKEY_VALID = 1,
 IB_PORT_PKEY_LISTED = 2,
};
struct ib_qp_security;
struct ib_port_pkey {
 enum port_pkey_state state;
 u16 pkey_index;
 u32 port_num;
 struct list_head qp_list;
 struct list_head to_error_list;
 struct ib_qp_security *sec;
};
struct ib_ports_pkeys {
 struct ib_port_pkey main;
 struct ib_port_pkey alt;
};
struct ib_qp_security {
 struct ib_qp *qp;
 struct ib_device *dev;

 struct mutex mutex;
 struct ib_ports_pkeys *ports_pkeys;



 struct list_head shared_qp_list;
 void *security;
 bool destroying;
 atomic_t error_list_count;
 struct completion error_complete;
 int error_comps_pending;
};
struct ib_qp {
 struct ib_device *device;
 struct ib_pd *pd;
 struct ib_cq *send_cq;
 struct ib_cq *recv_cq;
 spinlock_t mr_lock;
 int mrs_used;
 struct list_head rdma_mrs;
 struct list_head sig_mrs;
 struct ib_srq *srq;
 struct completion srq_completion;
 struct ib_xrcd *xrcd;
 struct list_head xrcd_list;


 atomic_t usecnt;
 struct list_head open_list;
 struct ib_qp *real_qp;
 struct ib_uqp_object *uobject;
 void (*event_handler)(struct ib_event *, void *);
 void (*registered_event_handler)(struct ib_event *, void *);
 void *qp_context;

 const struct ib_gid_attr *av_sgid_attr;
 const struct ib_gid_attr *alt_path_sgid_attr;
 u32 qp_num;
 u32 max_write_sge;
 u32 max_read_sge;
 enum ib_qp_type qp_type;
 struct ib_rwq_ind_table *rwq_ind_tbl;
 struct ib_qp_security *qp_sec;
 u32 port;

 bool integrity_en;



 struct rdma_restrack_entry res;


 struct rdma_counter *counter;
};
struct ib_dm {
 struct ib_device *device;
 u32 length;
 u32 flags;
 struct ib_uobject *uobject;
 atomic_t usecnt;
};
struct ib_dmah {
 struct ib_device *device;
 struct ib_uobject *uobject;



 struct rdma_restrack_entry res;
 u32 cpu_id;
 enum tph_mem_type mem_type;
 atomic_t usecnt;
 u8 ph;
 u8 valid_fields;
};
struct ib_mr {
 struct ib_device *device;





 struct ib_pd *pd;
 u32 lkey;
 u32 rkey;
 u64 iova;
 u64 length;
 unsigned int page_size;
 enum ib_mr_type type;
 bool need_inval;
 union {
  struct ib_uobject *uobject;
  struct list_head qp_entry;
 };

 struct ib_dm *dm;
 struct ib_sig_attrs *sig_attrs;
 struct ib_dmah *dmah;



 struct rdma_restrack_entry res;
};
struct ib_mw {
 struct ib_device *device;
 struct ib_pd *pd;
 struct ib_uobject *uobject;
 u32 rkey;
 enum ib_mw_type type;
};
enum ib_flow_attr_type {

 IB_FLOW_ATTR_NORMAL = 0x0,



 IB_FLOW_ATTR_ALL_DEFAULT = 0x1,



 IB_FLOW_ATTR_MC_DEFAULT = 0x2,

 IB_FLOW_ATTR_SNIFFER = 0x3
};
enum ib_flow_spec_type {

 IB_FLOW_SPEC_ETH = 0x20,
 IB_FLOW_SPEC_IB = 0x22,

 IB_FLOW_SPEC_IPV4 = 0x30,
 IB_FLOW_SPEC_IPV6 = 0x31,
 IB_FLOW_SPEC_ESP = 0x34,

 IB_FLOW_SPEC_TCP = 0x40,
 IB_FLOW_SPEC_UDP = 0x41,
 IB_FLOW_SPEC_VXLAN_TUNNEL = 0x50,
 IB_FLOW_SPEC_GRE = 0x51,
 IB_FLOW_SPEC_MPLS = 0x60,
 IB_FLOW_SPEC_INNER = 0x100,

 IB_FLOW_SPEC_ACTION_TAG = 0x1000,
 IB_FLOW_SPEC_ACTION_DROP = 0x1001,
 IB_FLOW_SPEC_ACTION_HANDLE = 0x1002,
 IB_FLOW_SPEC_ACTION_COUNT = 0x1003,
};
struct ib_flow_eth_filter {
 u8 dst_mac[6];
 u8 src_mac[6];
 __be16 ether_type;
 __be16 vlan_tag;
};
struct ib_flow_spec_eth {
 u32 type;
 u16 size;
 struct ib_flow_eth_filter val;
 struct ib_flow_eth_filter mask;
};
struct ib_flow_ib_filter {
 __be16 dlid;
 __u8 sl;
};
struct ib_flow_spec_ib {
 u32 type;
 u16 size;
 struct ib_flow_ib_filter val;
 struct ib_flow_ib_filter mask;
};
struct ib_flow_ipv4_filter {
 __be32 src_ip;
 __be32 dst_ip;
 u8 proto;
 u8 tos;
 u8 ttl;
 u8 flags;
};
struct ib_flow_spec_ipv4 {
 u32 type;
 u16 size;
 struct ib_flow_ipv4_filter val;
 struct ib_flow_ipv4_filter mask;
};
struct ib_flow_ipv6_filter {
 u8 src_ip[16];
 u8 dst_ip[16];
 __be32 flow_label;
 u8 next_hdr;
 u8 traffic_class;
 u8 hop_limit;
} __attribute__((__packed__));
struct ib_flow_spec_ipv6 {
 u32 type;
 u16 size;
 struct ib_flow_ipv6_filter val;
 struct ib_flow_ipv6_filter mask;
};
struct ib_flow_tcp_udp_filter {
 __be16 dst_port;
 __be16 src_port;
};
struct ib_flow_spec_tcp_udp {
 u32 type;
 u16 size;
 struct ib_flow_tcp_udp_filter val;
 struct ib_flow_tcp_udp_filter mask;
};
struct ib_flow_tunnel_filter {
 __be32 tunnel_id;
};
struct ib_flow_spec_tunnel {
 u32 type;
 u16 size;
 struct ib_flow_tunnel_filter val;
 struct ib_flow_tunnel_filter mask;
};
struct ib_flow_esp_filter {
 __be32 spi;
 __be32 seq;
};
struct ib_flow_spec_esp {
 u32 type;
 u16 size;
 struct ib_flow_esp_filter val;
 struct ib_flow_esp_filter mask;
};
struct ib_flow_gre_filter {
 __be16 c_ks_res0_ver;
 __be16 protocol;
 __be32 key;
};
struct ib_flow_spec_gre {
 u32 type;
 u16 size;
 struct ib_flow_gre_filter val;
 struct ib_flow_gre_filter mask;
};
struct ib_flow_mpls_filter {
 __be32 tag;
};
struct ib_flow_spec_mpls {
 u32 type;
 u16 size;
 struct ib_flow_mpls_filter val;
 struct ib_flow_mpls_filter mask;
};
struct ib_flow_spec_action_tag {
 enum ib_flow_spec_type type;
 u16 size;
 u32 tag_id;
};
struct ib_flow_spec_action_drop {
 enum ib_flow_spec_type type;
 u16 size;
};
struct ib_flow_spec_action_handle {
 enum ib_flow_spec_type type;
 u16 size;
 struct ib_flow_action *act;
};
struct ib_flow_spec_action_count {
 enum ib_flow_spec_type type;
 u16 size;
 struct ib_counters *counters;
};
union ib_flow_spec {
 struct {
  u32 type;
  u16 size;
 };
 struct ib_flow_spec_eth eth;
 struct ib_flow_spec_ib ib;
 struct ib_flow_spec_ipv4 ipv4;
 struct ib_flow_spec_tcp_udp tcp_udp;
 struct ib_flow_spec_ipv6 ipv6;
 struct ib_flow_spec_tunnel tunnel;
 struct ib_flow_spec_esp esp;
 struct ib_flow_spec_gre gre;
 struct ib_flow_spec_mpls mpls;
 struct ib_flow_spec_action_tag flow_tag;
 struct ib_flow_spec_action_drop drop;
 struct ib_flow_spec_action_handle action;
 struct ib_flow_spec_action_count flow_count;
};
struct ib_flow_attr {
 enum ib_flow_attr_type type;
 u16 size;
 u16 priority;
 u32 flags;
 u8 num_of_specs;
 u32 port;
 union ib_flow_spec flows[1];
};
struct ib_flow {
 struct ib_qp *qp;
 struct ib_device *device;
 struct ib_uobject *uobject;
};
enum ib_flow_action_type {
 IB_FLOW_ACTION_UNSPECIFIED,
 IB_FLOW_ACTION_ESP = 1,
};
struct ib_flow_action {
 struct ib_device *device;
 struct ib_uobject *uobject;
 enum ib_flow_action_type type;
 atomic_t usecnt;
};
struct ib_mad;
struct ib_port_cache {
 u64 subnet_prefix;
 struct ib_pkey_cache *pkey;
 struct ib_gid_table *gid;
 u8 lmc;
 enum ib_port_state port_state;
 enum ib_port_state last_port_state;
};
struct ib_port_immutable {
 int pkey_tbl_len;
 int gid_tbl_len;
 u32 core_cap_flags;
 u32 max_mad_size;
};
struct ib_port_data {
 struct ib_device *ib_dev;

 struct ib_port_immutable immutable;

 spinlock_t pkey_list_lock;

 spinlock_t netdev_lock;

 struct list_head pkey_list;

 struct ib_port_cache cache;

 struct net_device *netdev;
 netdevice_tracker netdev_tracker;
 struct hlist_node ndev_hash_link;
 struct rdma_port_counter port_counter;
 struct ib_port *sysfs;
};
enum rdma_netdev_t {
 RDMA_NETDEV_OPA_VNIC,
 RDMA_NETDEV_IPOIB,
};
struct rdma_netdev_alloc_params {
 size_t sizeof_priv;
 unsigned int txqs;
 unsigned int rxqs;
 void *param;

 int (*initialize_rdma_netdev)(struct ib_device *device, u32 port_num,
          struct net_device *netdev, void *param);
};
struct ib_counters {
 struct ib_device *device;
 struct ib_uobject *uobject;

 atomic_t usecnt;
};
struct ib_counters_read_attr {
 u64 *counters_buff;
 u32 ncounters;
 u32 flags;
};
struct uverbs_attr_bundle;
struct iw_cm_id;
struct iw_cm_conn_param;
struct rdma_user_mmap_entry {
 struct kref ref;
 struct ib_ucontext *ucontext;
 unsigned long start_pgoff;
 size_t npages;
 bool driver_removed;
};
struct ib_device_ops {
 struct module *owner;
 enum rdma_driver_id driver_id;
 u32 uverbs_abi_ver;
 unsigned int uverbs_no_driver_id_binding:1;






 const struct attribute_group *device_group;
 const struct attribute_group **port_groups;

 int (*post_send)(struct ib_qp *qp, const struct ib_send_wr *send_wr,
    const struct ib_send_wr **bad_send_wr);
 int (*post_recv)(struct ib_qp *qp, const struct ib_recv_wr *recv_wr,
    const struct ib_recv_wr **bad_recv_wr);
 void (*drain_rq)(struct ib_qp *qp);
 void (*drain_sq)(struct ib_qp *qp);
 int (*poll_cq)(struct ib_cq *cq, int num_entries, struct ib_wc *wc);
 int (*peek_cq)(struct ib_cq *cq, int wc_cnt);
 int (*req_notify_cq)(struct ib_cq *cq, enum ib_cq_notify_flags flags);
 int (*post_srq_recv)(struct ib_srq *srq,
        const struct ib_recv_wr *recv_wr,
        const struct ib_recv_wr **bad_recv_wr);
 int (*process_mad)(struct ib_device *device, int process_mad_flags,
      u32 port_num, const struct ib_wc *in_wc,
      const struct ib_grh *in_grh,
      const struct ib_mad *in_mad, struct ib_mad *out_mad,
      size_t *out_mad_size, u16 *out_mad_pkey_index);
 int (*query_device)(struct ib_device *device,
       struct ib_device_attr *device_attr,
       struct ib_udata *udata);
 int (*modify_device)(struct ib_device *device, int device_modify_mask,
        struct ib_device_modify *device_modify);
 void (*get_dev_fw_str)(struct ib_device *device, char *str);
 const struct cpumask *(*get_vector_affinity)(struct ib_device *ibdev,
           int comp_vector);
 int (*query_port)(struct ib_device *device, u32 port_num,
     struct ib_port_attr *port_attr);
 int (*query_port_speed)(struct ib_device *device, u32 port_num,
    u64 *speed);
 int (*modify_port)(struct ib_device *device, u32 port_num,
      int port_modify_mask,
      struct ib_port_modify *port_modify);






 int (*get_port_immutable)(struct ib_device *device, u32 port_num,
      struct ib_port_immutable *immutable);
 enum rdma_link_layer (*get_link_layer)(struct ib_device *device,
            u32 port_num);
 struct net_device *(*get_netdev)(struct ib_device *device,
      u32 port_num);






 struct net_device *(*alloc_rdma_netdev)(
  struct ib_device *device, u32 port_num, enum rdma_netdev_t type,
  const char *name, unsigned char name_assign_type,
  void (*setup)(struct net_device *));

 int (*rdma_netdev_get_params)(struct ib_device *device, u32 port_num,
          enum rdma_netdev_t type,
          struct rdma_netdev_alloc_params *params);





 int (*query_gid)(struct ib_device *device, u32 port_num, int index,
    union ib_gid *gid);
 int (*add_gid)(const struct ib_gid_attr *attr, void **context);
 int (*del_gid)(const struct ib_gid_attr *attr, void **context);
 int (*query_pkey)(struct ib_device *device, u32 port_num, u16 index,
     u16 *pkey);
 int (*alloc_ucontext)(struct ib_ucontext *context,
         struct ib_udata *udata);
 void (*dealloc_ucontext)(struct ib_ucontext *context);
 int (*mmap)(struct ib_ucontext *context, struct vm_area_struct *vma);






 void (*mmap_free)(struct rdma_user_mmap_entry *entry);
 void (*disassociate_ucontext)(struct ib_ucontext *ibcontext);
 int (*alloc_pd)(struct ib_pd *pd, struct ib_udata *udata);
 int (*dealloc_pd)(struct ib_pd *pd, struct ib_udata *udata);
 int (*create_ah)(struct ib_ah *ah, struct rdma_ah_init_attr *attr,
    struct ib_udata *udata);
 int (*create_user_ah)(struct ib_ah *ah, struct rdma_ah_init_attr *attr,
         struct ib_udata *udata);
 int (*modify_ah)(struct ib_ah *ah, struct rdma_ah_attr *ah_attr);
 int (*query_ah)(struct ib_ah *ah, struct rdma_ah_attr *ah_attr);
 int (*destroy_ah)(struct ib_ah *ah, u32 flags);
 int (*create_srq)(struct ib_srq *srq,
     struct ib_srq_init_attr *srq_init_attr,
     struct ib_udata *udata);
 int (*modify_srq)(struct ib_srq *srq, struct ib_srq_attr *srq_attr,
     enum ib_srq_attr_mask srq_attr_mask,
     struct ib_udata *udata);
 int (*query_srq)(struct ib_srq *srq, struct ib_srq_attr *srq_attr);
 int (*destroy_srq)(struct ib_srq *srq, struct ib_udata *udata);
 int (*create_qp)(struct ib_qp *qp, struct ib_qp_init_attr *qp_init_attr,
    struct ib_udata *udata);
 int (*modify_qp)(struct ib_qp *qp, struct ib_qp_attr *qp_attr,
    int qp_attr_mask, struct ib_udata *udata);
 int (*query_qp)(struct ib_qp *qp, struct ib_qp_attr *qp_attr,
   int qp_attr_mask, struct ib_qp_init_attr *qp_init_attr);
 int (*destroy_qp)(struct ib_qp *qp, struct ib_udata *udata);
 int (*create_cq)(struct ib_cq *cq, const struct ib_cq_init_attr *attr,
    struct uverbs_attr_bundle *attrs);
 int (*create_cq_umem)(struct ib_cq *cq,
         const struct ib_cq_init_attr *attr,
         struct ib_umem *umem,
         struct uverbs_attr_bundle *attrs);
 int (*modify_cq)(struct ib_cq *cq, u16 cq_count, u16 cq_period);
 int (*destroy_cq)(struct ib_cq *cq, struct ib_udata *udata);
 int (*resize_cq)(struct ib_cq *cq, int cqe, struct ib_udata *udata);




 int (*pre_destroy_cq)(struct ib_cq *cq);



 void (*post_destroy_cq)(struct ib_cq *cq);
 struct ib_mr *(*get_dma_mr)(struct ib_pd *pd, int mr_access_flags);
 struct ib_mr *(*reg_user_mr)(struct ib_pd *pd, u64 start, u64 length,
         u64 virt_addr, int mr_access_flags,
         struct ib_dmah *dmah,
         struct ib_udata *udata);
 struct ib_mr *(*reg_user_mr_dmabuf)(struct ib_pd *pd, u64 offset,
         u64 length, u64 virt_addr, int fd,
         int mr_access_flags,
         struct ib_dmah *dmah,
         struct uverbs_attr_bundle *attrs);
 struct ib_mr *(*rereg_user_mr)(struct ib_mr *mr, int flags, u64 start,
           u64 length, u64 virt_addr,
           int mr_access_flags, struct ib_pd *pd,
           struct ib_udata *udata);
 int (*dereg_mr)(struct ib_mr *mr, struct ib_udata *udata);
 struct ib_mr *(*alloc_mr)(struct ib_pd *pd, enum ib_mr_type mr_type,
      u32 max_num_sg);
 struct ib_mr *(*alloc_mr_integrity)(struct ib_pd *pd,
         u32 max_num_data_sg,
         u32 max_num_meta_sg);
 int (*advise_mr)(struct ib_pd *pd,
    enum ib_uverbs_advise_mr_advice advice, u32 flags,
    struct ib_sge *sg_list, u32 num_sge,
    struct uverbs_attr_bundle *attrs);
 int (*map_mr_sg)(struct ib_mr *mr, struct scatterlist *sg, int sg_nents,
    unsigned int *sg_offset);
 int (*check_mr_status)(struct ib_mr *mr, u32 check_mask,
          struct ib_mr_status *mr_status);
 int (*alloc_mw)(struct ib_mw *mw, struct ib_udata *udata);
 int (*dealloc_mw)(struct ib_mw *mw);
 int (*attach_mcast)(struct ib_qp *qp, union ib_gid *gid, u16 lid);
 int (*detach_mcast)(struct ib_qp *qp, union ib_gid *gid, u16 lid);
 int (*alloc_xrcd)(struct ib_xrcd *xrcd, struct ib_udata *udata);
 int (*dealloc_xrcd)(struct ib_xrcd *xrcd, struct ib_udata *udata);
 struct ib_flow *(*create_flow)(struct ib_qp *qp,
           struct ib_flow_attr *flow_attr,
           struct ib_udata *udata);
 int (*destroy_flow)(struct ib_flow *flow_id);
 int (*destroy_flow_action)(struct ib_flow_action *action);
 int (*set_vf_link_state)(struct ib_device *device, int vf, u32 port,
     int state);
 int (*get_vf_config)(struct ib_device *device, int vf, u32 port,
        struct ifla_vf_info *ivf);
 int (*get_vf_stats)(struct ib_device *device, int vf, u32 port,
       struct ifla_vf_stats *stats);
 int (*get_vf_guid)(struct ib_device *device, int vf, u32 port,
       struct ifla_vf_guid *node_guid,
       struct ifla_vf_guid *port_guid);
 int (*set_vf_guid)(struct ib_device *device, int vf, u32 port, u64 guid,
      int type);
 struct ib_wq *(*create_wq)(struct ib_pd *pd,
       struct ib_wq_init_attr *init_attr,
       struct ib_udata *udata);
 int (*destroy_wq)(struct ib_wq *wq, struct ib_udata *udata);
 int (*modify_wq)(struct ib_wq *wq, struct ib_wq_attr *attr,
    u32 wq_attr_mask, struct ib_udata *udata);
 int (*create_rwq_ind_table)(struct ib_rwq_ind_table *ib_rwq_ind_table,
        struct ib_rwq_ind_table_init_attr *init_attr,
        struct ib_udata *udata);
 int (*destroy_rwq_ind_table)(struct ib_rwq_ind_table *wq_ind_table);
 struct ib_dm *(*alloc_dm)(struct ib_device *device,
      struct ib_ucontext *context,
      struct ib_dm_alloc_attr *attr,
      struct uverbs_attr_bundle *attrs);
 int (*dealloc_dm)(struct ib_dm *dm, struct uverbs_attr_bundle *attrs);
 int (*alloc_dmah)(struct ib_dmah *ibdmah,
     struct uverbs_attr_bundle *attrs);
 int (*dealloc_dmah)(struct ib_dmah *dmah, struct uverbs_attr_bundle *attrs);
 struct ib_mr *(*reg_dm_mr)(struct ib_pd *pd, struct ib_dm *dm,
       struct ib_dm_mr_attr *attr,
       struct uverbs_attr_bundle *attrs);
 int (*create_counters)(struct ib_counters *counters,
          struct uverbs_attr_bundle *attrs);
 int (*destroy_counters)(struct ib_counters *counters);
 int (*read_counters)(struct ib_counters *counters,
        struct ib_counters_read_attr *counters_read_attr,
        struct uverbs_attr_bundle *attrs);
 int (*map_mr_sg_pi)(struct ib_mr *mr, struct scatterlist *data_sg,
       int data_sg_nents, unsigned int *data_sg_offset,
       struct scatterlist *meta_sg, int meta_sg_nents,
       unsigned int *meta_sg_offset);







 struct rdma_hw_stats *(*alloc_hw_device_stats)(struct ib_device *device);
 struct rdma_hw_stats *(*alloc_hw_port_stats)(struct ib_device *device,
           u32 port_num);
 int (*get_hw_stats)(struct ib_device *device,
       struct rdma_hw_stats *stats, u32 port, int index);






 int (*modify_hw_stat)(struct ib_device *device, u32 port,
         unsigned int counter_index, bool enable);



 int (*fill_res_mr_entry)(struct sk_buff *msg, struct ib_mr *ibmr);
 int (*fill_res_mr_entry_raw)(struct sk_buff *msg, struct ib_mr *ibmr);
 int (*fill_res_cq_entry)(struct sk_buff *msg, struct ib_cq *ibcq);
 int (*fill_res_cq_entry_raw)(struct sk_buff *msg, struct ib_cq *ibcq);
 int (*fill_res_qp_entry)(struct sk_buff *msg, struct ib_qp *ibqp);
 int (*fill_res_qp_entry_raw)(struct sk_buff *msg, struct ib_qp *ibqp);
 int (*fill_res_cm_id_entry)(struct sk_buff *msg, struct rdma_cm_id *id);
 int (*fill_res_srq_entry)(struct sk_buff *msg, struct ib_srq *ib_srq);
 int (*fill_res_srq_entry_raw)(struct sk_buff *msg, struct ib_srq *ib_srq);






 int (*enable_driver)(struct ib_device *dev);



 void (*dealloc_driver)(struct ib_device *dev);


 void (*iw_add_ref)(struct ib_qp *qp);
 void (*iw_rem_ref)(struct ib_qp *qp);
 struct ib_qp *(*iw_get_qp)(struct ib_device *device, int qpn);
 int (*iw_connect)(struct iw_cm_id *cm_id,
     struct iw_cm_conn_param *conn_param);
 int (*iw_accept)(struct iw_cm_id *cm_id,
    struct iw_cm_conn_param *conn_param);
 int (*iw_reject)(struct iw_cm_id *cm_id, const void *pdata,
    u8 pdata_len);
 int (*iw_create_listen)(struct iw_cm_id *cm_id, int backlog);
 int (*iw_destroy_listen)(struct iw_cm_id *cm_id);





 int (*counter_bind_qp)(struct rdma_counter *counter, struct ib_qp *qp,
          u32 port);




 int (*counter_unbind_qp)(struct ib_qp *qp, u32 port);



 int (*counter_dealloc)(struct rdma_counter *counter);




 struct rdma_hw_stats *(*counter_alloc_stats)(
  struct rdma_counter *counter);



 int (*counter_update_stats)(struct rdma_counter *counter);




 void (*counter_init)(struct rdma_counter *counter);





 int (*fill_stat_mr_entry)(struct sk_buff *msg, struct ib_mr *ibmr);


 int (*query_ucontext)(struct ib_ucontext *context,
         struct uverbs_attr_bundle *attrs);





 int (*get_numa_node)(struct ib_device *dev);




 struct ib_device *(*add_sub_dev)(struct ib_device *parent,
      enum rdma_nl_dev_type type,
      const char *name);




 void (*del_sub_dev)(struct ib_device *sub_dev);





 void (*ufile_hw_cleanup)(struct ib_uverbs_file *ufile);





 void (*report_port_event)(struct ib_device *ibdev,
      struct net_device *ndev, unsigned long event);

 size_t size_ib_ah;
 size_t size_ib_counters;
 size_t size_ib_cq;
 size_t size_ib_dmah;
 size_t size_ib_mw;
 size_t size_ib_pd;
 size_t size_ib_qp;
 size_t size_ib_rwq_ind_table;
 size_t size_ib_srq;
 size_t size_ib_ucontext;
 size_t size_ib_xrcd;
 size_t size_rdma_counter;
};
struct ib_core_device {



 struct device dev;
 possible_net_t rdma_net;
 struct kobject *ports_kobj;
 struct list_head port_list;
 struct ib_device *owner;
};
struct rdma_restrack_root;
struct ib_device {

 struct device *dma_device;
 struct ib_device_ops ops;
 char name[64];
 struct callback_head callback_head;

 struct list_head event_handler_list;

 struct rw_semaphore event_handler_rwsem;


 spinlock_t qp_open_list_lock;

 struct rw_semaphore client_data_rwsem;
 struct xarray client_data;
 struct mutex unregistration_lock;


 rwlock_t cache_lock;



 struct ib_port_data *port_data;

 int num_comp_vectors;

 union {
  struct device dev;
  struct ib_core_device coredev;
 };






 const struct attribute_group *groups[4];
 u8 hw_stats_attr_index;

 u64 uverbs_cmd_mask;

 char node_desc[64];
 __be64 node_guid;
 u32 local_dma_lkey;
 u16 is_switch:1;

 u16 kverbs_provider:1;

 u16 use_cq_dim:1;
 u8 node_type;
 u32 phys_port_cnt;
 struct ib_device_attr attrs;
 struct hw_stats_device_data *hw_stats_data;


 struct rdmacg_device cg_device;


 u32 index;

 spinlock_t cq_pools_lock;
 struct list_head cq_pools[IB_POLL_LAST_POOL_TYPE + 1];

 struct rdma_restrack_root *res;

 const struct uapi_definition *driver_def;





 refcount_t refcount;
 struct completion unreg_completion;
 struct work_struct unregistration_work;

 const struct rdma_link_ops *link_ops;


 struct mutex compat_devs_mutex;

 struct xarray compat_devs;


 char iw_ifname[16];
 u32 iw_driver_flags;
 u32 lag_flags;


 struct mutex subdev_lock;
 struct list_head subdev_list_head;


 enum rdma_nl_dev_type type;
 struct ib_device *parent;
 struct list_head subdev_list;

 enum rdma_nl_name_assign_type name_assign_type;
};
struct dibs_dmb {




 u64 dmb_tok;

 uuid_t rgid;

 void *cpu_addr;

 u32 dmb_len;

 u32 idx;




 u32 vlan_valid;
 u32 vlan_id;

 dma_addr_t dma_addr;
};
struct dibs_event {
 u32 type;
 u32 subtype;

 uuid_t gid;

 u64 buffer_tok;
 u64 time;

 u64 data;
};
struct dibs_dev;
struct dibs_client_ops {
 void (*add_dev)(struct dibs_dev *dev);
 void (*del_dev)(struct dibs_dev *dev);
 void (*handle_irq)(struct dibs_dev *dev, unsigned int idx,
      u16 dmbemask);







 void (*handle_event)(struct dibs_dev *dev,
        const struct dibs_event *event);
};
struct dibs_client {

 const char *name;
 const struct dibs_client_ops *ops;

 u8 id;
};
struct dibs_dev_ops {
 u16 (*get_fabric_id)(struct dibs_dev *dev);
 int (*query_remote_gid)(struct dibs_dev *dev, const uuid_t *rgid,
    u32 vid_valid, u32 vid);





 int (*max_dmbs)(void);
 int (*register_dmb)(struct dibs_dev *dev, struct dibs_dmb *dmb,
       struct dibs_client *client);
 int (*unregister_dmb)(struct dibs_dev *dev, struct dibs_dmb *dmb);
 int (*move_data)(struct dibs_dev *dev, u64 dmb_tok, unsigned int idx,
    bool sf, unsigned int offset, void *data,
    unsigned int size);
 int (*add_vlan_id)(struct dibs_dev *dev, u64 vlan_id);






 int (*del_vlan_id)(struct dibs_dev *dev, u64 vlan_id);
 int (*signal_event)(struct dibs_dev *dev, const uuid_t *rgid,
       u32 trigger_irq, u32 event_code, u64 info);
 int (*support_mmapped_rdmb)(struct dibs_dev *dev);
 int (*attach_dmb)(struct dibs_dev *dev, struct dibs_dmb *dmb);
 int (*detach_dmb)(struct dibs_dev *dev, u64 token);
};
struct dibs_dev {
 struct list_head list;
 struct device dev;

 const struct dibs_dev_ops *ops;
 uuid_t gid;

 void *drv_priv;


 void *priv[8];


 spinlock_t lock;



 u8 *dmb_clientid_arr;

 struct dibs_client *subs[8];
};
struct sock;
struct smc_hashinfo {
 rwlock_t lock;
 struct hlist_head ht;
};
struct smcd_gid {
 u64 gid;
 u64 gid_ext;
};
struct smcd_dev {
 struct dibs_dev *dibs;
 struct list_head list;
 spinlock_t lock;
 struct smc_connection **conn;
 struct list_head vlan;
 struct workqueue_struct *event_wq;
 u8 pnetid[16];
 bool pnetid_by_user;
 struct list_head lgr_list;
 spinlock_t lgr_lock;
 atomic_t lgr_cnt;
 wait_queue_head_t lgrs_deleted;
 u8 going_away : 1;
};
struct smc_ib_device {
 struct list_head list;
 struct ib_device *ibdev;
 struct ib_port_attr pattr[2];
 struct ib_event_handler event_handler;
 struct ib_cq *roce_cq_send;
 struct ib_cq *roce_cq_recv;
 struct tasklet_struct send_tasklet;
 struct tasklet_struct recv_tasklet;
 char mac[2][6];

 u8 pnetid[2][16];

 bool pnetid_by_user[2];

 u8 initialized : 1;
 struct work_struct port_event_work;
 unsigned long port_event_mask;
 unsigned long ports_going_away[(((2) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 atomic_t lnk_cnt;
 wait_queue_head_t lnks_deleted;
 struct mutex mutex;
 atomic_t lnk_cnt_by_port[2];

 int ndev_ifidx[2];
};
struct smc_buf_desc;
struct smc_link;
struct smc_link_group;
struct smc_wr_rx_hdr {
 union {
  u8 type;






  struct {
   u8 llc_type:4,
      llc_version:4;
  };

 };
} ;
struct smc_cdc_conn_state_flags {






 u8 reserved : 5;
 u8 peer_conn_abort : 1;
 u8 peer_conn_closed : 1;
 u8 peer_done_writing : 1;

};
struct smc_cdc_producer_flags {
 u8 reserved : 3;
 u8 failover_validation : 1;
 u8 cons_curs_upd_req : 1;
 u8 urg_data_present : 1;
 u8 urg_data_pending : 1;
 u8 write_blocked : 1;

};
union smc_host_cursor {
 struct {
  u16 reserved;
  u16 wrap;
  u32 count;
 };

 atomic64_t acurs;



} ;
struct smc_host_cdc_msg {
 struct smc_wr_rx_hdr common;
 u8 len;
 u16 seqno;
 u32 token;
 union smc_host_cursor prod;
 union smc_host_cursor cons;


 struct smc_cdc_producer_flags prod_flags;
 struct smc_cdc_conn_state_flags conn_state_flags;
 u8 reserved[18];
} ;
enum smc_urg_state {
 SMC_URG_VALID = 1,
 SMC_URG_NOTYET = 2,
 SMC_URG_READ = 3,
};
struct smc_connection {
 struct rb_node alert_node;
 struct smc_link_group *lgr;
 struct smc_link *lnk;
 u32 alert_token_local;
 u8 peer_rmbe_idx;
 int peer_rmbe_size;
 atomic_t peer_rmbe_space;


 int rtoken_idx;

 struct smc_buf_desc *sndbuf_desc;
 struct smc_buf_desc *rmb_desc;
 int rmbe_size_comp;
 int rmbe_update_limit;




 struct smc_host_cdc_msg local_tx_ctrl;




 union smc_host_cursor local_tx_ctrl_fin;


 union smc_host_cursor tx_curs_prep;


 union smc_host_cursor tx_curs_sent;


 union smc_host_cursor tx_curs_fin;


 atomic_t sndbuf_space;
 u16 tx_cdc_seq;
 u16 tx_cdc_seq_fin;
 spinlock_t send_lock;
 atomic_t cdc_pend_tx_wr;



 wait_queue_head_t cdc_pend_tx_wq;
 struct delayed_work tx_work;
 u32 tx_off;

 struct smc_host_cdc_msg local_rx_ctrl;



 union smc_host_cursor rx_curs_confirmed;


 union smc_host_cursor urg_curs;
 enum smc_urg_state urg_state;
 bool urg_tx_pend;
 bool urg_rx_skip_pend;




 char urg_rx_byte;
 bool tx_in_release_sock;



 atomic_t bytes_to_rcv;


 atomic_t splice_pending;





 struct work_struct close_work;
 struct work_struct abort_work;
 struct tasklet_struct rx_tsklet;
 u8 rx_off;


 u64 peer_token;
 u8 killed;
 u8 freed;
 u8 out_of_sync;
};
typedef unsigned long kernel_ulong_t;
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
struct device;
struct device;
struct module;
struct device;
struct device_node;
struct irq_domain;
struct smcd_dev;
enum smc_lgr_role {
 SMC_CLNT,
 SMC_SERV
};
enum smc_link_state {
 SMC_LNK_UNUSED,
 SMC_LNK_INACTIVE,
 SMC_LNK_ACTIVATING,
 SMC_LNK_ACTIVE,
};
struct smc_wr_buf {
 u8 raw[48];
};
struct smc_wr_v2_buf {
 u8 raw[8192];
};
enum smc_wr_reg_state {
 POSTED,
 CONFIRMED,
 FAILED
};
struct smc_rdma_sge {
 struct ib_sge wr_tx_rdma_sge[2];
};
struct smc_rdma_sges {
 struct smc_rdma_sge tx_rdma_sge[2];
};
struct smc_rdma_wr {


 struct ib_rdma_wr wr_tx_rdma[2];
};
struct smc_link {
 struct smc_ib_device *smcibdev;
 u8 ibport;
 struct ib_pd *roce_pd;


 struct ib_qp *roce_qp;
 struct ib_qp_attr qp_attr;

 struct smc_wr_buf *wr_tx_bufs;
 struct ib_send_wr *wr_tx_ibs;
 struct ib_sge *wr_tx_sges;
 struct smc_rdma_sges *wr_tx_rdma_sges;
 struct smc_rdma_wr *wr_tx_rdmas;
 struct smc_wr_tx_pend *wr_tx_pends;
 struct completion *wr_tx_compl;

 struct ib_send_wr *wr_tx_v2_ib;
 struct ib_sge *wr_tx_v2_sge;
 struct smc_wr_tx_pend *wr_tx_v2_pend;
 dma_addr_t wr_tx_dma_addr;
 dma_addr_t wr_tx_v2_dma_addr;
 atomic_long_t wr_tx_id;
 unsigned long *wr_tx_mask;
 u32 wr_tx_cnt;
 wait_queue_head_t wr_tx_wait;
 struct {
  struct percpu_ref wr_tx_refs;
 } ;
 struct completion tx_ref_comp;

 u8 *wr_rx_bufs;
 struct ib_recv_wr *wr_rx_ibs;
 struct ib_sge *wr_rx_sges;

 int wr_rx_sge_cnt;
 int wr_rx_buflen;


 dma_addr_t wr_rx_dma_addr;
 dma_addr_t wr_rx_v2_dma_addr;
 u64 wr_rx_id;
 u64 wr_rx_id_compl;
 u32 wr_rx_cnt;
 unsigned long wr_rx_tstamp;
 wait_queue_head_t wr_rx_empty_wait;

 struct ib_reg_wr wr_reg;
 wait_queue_head_t wr_reg_wait;
 struct {
  struct percpu_ref wr_reg_refs;
 } ;
 struct completion reg_ref_comp;
 enum smc_wr_reg_state wr_reg_state;

 u8 gid[sizeof(union ib_gid)];
 u8 sgid_index;
 u32 peer_qpn;
 enum ib_mtu path_mtu;
 enum ib_mtu peer_mtu;
 u32 psn_initial;
 u32 peer_psn;
 u8 peer_mac[6];
 u8 peer_gid[sizeof(union ib_gid)];
 u8 link_id;
 u8 link_uid[4];
 u8 peer_link_uid[4];
 u8 link_idx;
 u8 link_is_asym;
 u8 clearing : 1;
 refcount_t refcnt;
 struct smc_link_group *lgr;
 struct work_struct link_down_wrk;
 char ibname[64];
 int ndev_ifidx;

 enum smc_link_state state;
 struct delayed_work llc_testlink_wrk;
 struct completion llc_testlink_resp;
 int llc_testlink_time;
 atomic_t conn_cnt;
};
struct smc_buf_desc {
 struct list_head list;
 void *cpu_addr;
 struct page *pages;
 int len;
 u32 used;
 union {
  struct {
   struct sg_table sgt[3];

   struct ib_mr *mr[3];





   u32 order;

   u8 is_conf_rkey;

   u8 is_reg_mr[3];

   u8 is_map_ib[3];

   u8 is_dma_need_sync;
   u8 is_reg_err;

   u8 is_vm;

  };
  struct {

   bool is_attached;


   unsigned short sba_idx;

   u64 token;

   dma_addr_t dma_addr;

  };
 };
};
struct smc_rtoken {
 u64 dma_addr;
 u32 rkey;
};
struct smcd_dev;
enum smc_lgr_type {
 SMC_LGR_NONE,
 SMC_LGR_SINGLE,
 SMC_LGR_SYMMETRIC,
 SMC_LGR_ASYMMETRIC_PEER,
 SMC_LGR_ASYMMETRIC_LOCAL,
};
enum smcr_buf_type {
 SMCR_PHYS_CONT_BUFS = 0,
 SMCR_VIRT_CONT_BUFS = 1,
 SMCR_MIXED_BUFS = 2,
};
enum smc_llc_flowtype {
 SMC_LLC_FLOW_NONE = 0,
 SMC_LLC_FLOW_ADD_LINK = 2,
 SMC_LLC_FLOW_DEL_LINK = 4,
 SMC_LLC_FLOW_REQ_ADD_LINK = 5,
 SMC_LLC_FLOW_RKEY = 6,
};
struct smc_llc_qentry;
struct smc_llc_flow {
 enum smc_llc_flowtype type;
 struct smc_llc_qentry *qentry;
};
struct smc_link_group {
 struct list_head list;
 struct rb_root conns_all;
 rwlock_t conns_lock;
 unsigned int conns_num;
 unsigned short vlan_id;

 struct list_head sndbufs[16];
 struct rw_semaphore sndbufs_lock;
 struct list_head rmbs[16];
 struct rw_semaphore rmbs_lock;
 u64 alloc_sndbufs;
 u64 alloc_rmbs;

 u8 id[4];
 struct delayed_work free_work;
 struct work_struct terminate_work;
 struct workqueue_struct *tx_wq;
 u8 sync_err : 1;
 u8 terminating : 1;
 u8 freeing : 1;

 refcount_t refcnt;
 bool is_smcd;
 u8 smc_version;
 u8 negotiated_eid[32];
 u8 peer_os;
 u8 peer_smc_release;
 u8 peer_hostname[32];
 union {
  struct {
   enum smc_lgr_role role;

   struct smc_link lnk[3];

   struct smc_wr_v2_buf *wr_rx_buf_v2;

   struct smc_wr_v2_buf *wr_tx_buf_v2;

   char peer_systemid[8];

   struct smc_rtoken rtokens[255]
      [3];

   unsigned long rtokens_used_mask[(((255) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];

   u8 next_link_id;
   enum smc_lgr_type type;
   enum smcr_buf_type buf_type;

   u8 pnet_id[16 + 1];

   struct list_head llc_event_q;

   spinlock_t llc_event_q_lock;

   struct rw_semaphore llc_conf_mutex;

   struct work_struct llc_add_link_work;
   struct work_struct llc_del_link_work;
   struct work_struct llc_event_work;

   wait_queue_head_t llc_flow_waiter;

   wait_queue_head_t llc_msg_waiter;

   struct smc_llc_flow llc_flow_lcl;

   struct smc_llc_flow llc_flow_rmt;

   struct smc_llc_qentry *delayed_event;

   spinlock_t llc_flow_lock;

   int llc_testlink_time;

   u32 llc_termination_rsn;

   u8 nexthop_mac[6];
   u8 uses_gateway;
   __be32 saddr;

   struct net *net;
   u8 max_conns;

   u8 max_links;

  };
  struct {
   struct smcd_gid peer_gid;

   struct smcd_dev *smcd;

   u8 peer_shutdown : 1;

  };
 };
};
static inline    bool smc_link_active(struct smc_link *lnk)
;
struct smc_ib_device;
struct smcd_dev;
struct smc_link_group;
struct smc_llc_hdr {
 struct smc_wr_rx_hdr common;
 union {
  struct {
   u8 length;




   u8 add_link_rej_rsn:4,
      reserved:4;

  };
  u16 length_v2;
 };
 u8 flags;
} __attribute__((__packed__));
struct smc_llc_msg_confirm_link {
 struct smc_llc_hdr hd;
 u8 sender_mac[6];
 u8 sender_gid[sizeof(union ib_gid)];
 u8 sender_qp_num[3];
 u8 link_num;
 u8 link_uid[4];
 u8 max_links;
 u8 max_conns;
 u8 reserved[8];
};
struct smc_llc_msg_add_link {
 struct smc_llc_hdr hd;
 u8 sender_mac[6];
 u8 reserved2[2];
 u8 sender_gid[sizeof(union ib_gid)];
 u8 sender_qp_num[3];
 u8 link_num;




 u8 qp_mtu : 4,
    reserved3 : 4;

 u8 initial_psn[3];
 u8 reserved[8];
};
struct smc_llc_msg_add_link_cont_rt {
 __be32 rmb_key;
 __be32 rmb_key_new;
 __be64 rmb_vaddr_new;
};
struct smc_llc_msg_req_add_link_v2 {
 struct smc_llc_hdr hd;
 u8 reserved[20];
 u8 gid_cnt;
 u8 reserved2[3];
 u8 gid[1][sizeof(union ib_gid)];
};
struct smc_llc_msg_add_link_cont {
 struct smc_llc_hdr hd;
 u8 link_num;
 u8 num_rkeys;
 u8 reserved2[2];
 struct smc_llc_msg_add_link_cont_rt rt[2];
 u8 reserved[4];
} __attribute__((__packed__));
struct smc_llc_msg_del_link {
 struct smc_llc_hdr hd;
 u8 link_num;
 __be32 reason;
 u8 reserved[35];
} __attribute__((__packed__));
struct smc_llc_msg_test_link {
 struct smc_llc_hdr hd;
 u8 user_data[16];
 u8 reserved[24];
};
struct smc_rmb_rtoken {
 union {
  u8 num_rkeys;


  u8 link_id;
 };
 __be32 rmb_key;
 __be64 rmb_vaddr;
} __attribute__((__packed__));
struct smc_llc_msg_confirm_rkey {
 struct smc_llc_hdr hd;
 struct smc_rmb_rtoken rtoken[3];
 u8 reserved;
};
struct smc_llc_msg_delete_rkey {
 struct smc_llc_hdr hd;
 u8 num_rkeys;
 u8 err_mask;
 u8 reserved[2];
 __be32 rkey[8];
 u8 reserved2[4];
};
struct smc_llc_msg_delete_rkey_v2_inline {
 struct smc_llc_hdr hd;
 u8 num_rkeys;
 u8 num_inval_rkeys;
 u8 reserved[2];
 __be32 rkey[9];
};
union smc_llc_msg {
 struct smc_llc_msg_confirm_link confirm_link;
 struct smc_llc_msg_add_link add_link;
 struct smc_llc_msg_req_add_link_v2 req_add_link;
 struct smc_llc_msg_add_link_cont add_link_cont;
 struct smc_llc_msg_del_link delete_link;

 struct smc_llc_msg_confirm_rkey confirm_rkey;
 struct smc_llc_msg_delete_rkey delete_rkey;
 struct smc_llc_msg_delete_rkey_v2_inline delete_rkey_v2;

 struct smc_llc_msg_test_link test_link;
 struct {
  struct smc_llc_hdr hdr;
  u8 data[40];
 } raw;
};
struct smc_llc_qentry {
 struct list_head list;
 struct smc_link *link;
 u16 body_len;
 union smc_llc_msg msg;
 u8 body[1] ;
};
/*@ requires \true; ensures 0 <= \result <= 3; */

static int smc_llc_active_link_count(struct smc_link_group *lgr)
{
 int i, link_count = 0;

 for (i = 0; i < 3; i++) {
  if (!smc_link_active(&lgr->lnk[i]))
   continue;
  link_count++;
 }
 return link_count;
}

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
int main(void) {
  struct smc_link_group * lgr;
  __CPROVER_assume(((((__int128)1)) != 0));
  extern void *malloc(unsigned long);
  { int c_lgr; lgr = c_lgr ? 0 : malloc(sizeof(struct smc_link_group)); }
  int bv_r = smc_llc_active_link_count(lgr);
  __CPROVER_assert(((((__int128)((((__int128)0ULL) <= ((__int128)bv_r)) && (((__int128)bv_r) <= ((__int128)3ULL))))) != 0), "ensures");
  return 0;
}
