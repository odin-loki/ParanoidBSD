typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_size_t size_t;
typedef s64 ktime_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
static inline     bool arch_static_branch(struct static_key * const key, const bool branch)
;
static inline     bool arch_static_branch_jump(struct static_key * const key, const bool branch)
;
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
extern bool ____wrong_branch_error(void);
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
extern 
void __dynamic_pr_debug(struct _ddebug *descriptor, const char *fmt, ...);
static inline     void
generic___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
generic_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
const_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
arch___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
arch_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
_Static_assert(__builtin_types_compatible_p(typeof(arch___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(generic___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(___set_bit), typeof(generic___set_bit)), "__same_type(arch___set_bit, generic___set_bit) && __same_type(const___set_bit, generic___set_bit) && __same_type(___set_bit, generic___set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(generic___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(___clear_bit), typeof(generic___clear_bit)), "__same_type(arch___clear_bit, generic___clear_bit) && __same_type(const___clear_bit, generic___clear_bit) && __same_type(___clear_bit, generic___clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(generic___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(___change_bit), typeof(generic___change_bit)), "__same_type(arch___change_bit, generic___change_bit) && __same_type(const___change_bit, generic___change_bit) && __same_type(___change_bit, generic___change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(___test_and_set_bit), typeof(generic___test_and_set_bit)), "__same_type(arch___test_and_set_bit, generic___test_and_set_bit) && __same_type(const___test_and_set_bit, generic___test_and_set_bit) && __same_type(___test_and_set_bit, generic___test_and_set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(___test_and_clear_bit), typeof(generic___test_and_clear_bit)), "__same_type(arch___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(const___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(___test_and_clear_bit, generic___test_and_clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(___test_and_change_bit), typeof(generic___test_and_change_bit)), "__same_type(arch___test_and_change_bit, generic___test_and_change_bit) && __same_type(const___test_and_change_bit, generic___test_and_change_bit) && __same_type(___test_and_change_bit, generic___test_and_change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(const_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(_test_bit), typeof(generic_test_bit)), "__same_type(arch_test_bit, generic_test_bit) && __same_type(const_test_bit, generic_test_bit) && __same_type(_test_bit, generic_test_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(generic_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(_test_bit_acquire), typeof(generic_test_bit_acquire)), "__same_type(arch_test_bit_acquire, generic_test_bit_acquire) && __same_type(const_test_bit_acquire, generic_test_bit_acquire) && __same_type(_test_bit_acquire, generic_test_bit_acquire)");
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct completion;
struct task_struct;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
struct task_struct;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct page;
struct task_struct;
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pgdval_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct qspinlock;
struct task_struct;
struct task_struct;
enum _cache_table_type {
 CACHE_L1_INST = 1,
 CACHE_L1_DATA,
 CACHE_L2,
 CACHE_L3

} __attribute__((__packed__));
_Static_assert(sizeof(enum _cache_table_type) == 1, "sizeof(enum _cache_table_type) == 1");
enum _tlb_table_type {
 TLB_INST_4K = (CACHE_L3 + 1),
 TLB_INST_4M,
 TLB_INST_2M_4M,
 TLB_INST_ALL,

 TLB_DATA_4K,
 TLB_DATA_4M,
 TLB_DATA_2M_4M,
 TLB_DATA_4K_4M,
 TLB_DATA_1G,
 TLB_DATA_1G_2M_4M,

 TLB_DATA0_4K,
 TLB_DATA0_4M,
 TLB_DATA0_2M_4M,

 STLB_4K,
 STLB_4K_2M,
} __attribute__((__packed__));
_Static_assert(sizeof(enum _tlb_table_type) == 1, "sizeof(enum _tlb_table_type) == 1");
struct mm_struct;
struct static_key;
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
struct task_struct;
struct page;
struct mm_struct;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct hrtimer;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct task_struct;
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
struct clk;
struct page;
struct mutex;
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct uprobe;
struct mm_struct;
struct page;
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
_Static_assert(__builtin_offsetof(struct page, flags) == __builtin_offsetof(struct folio, flags), "offsetof(struct page, flags) == offsetof(struct folio, flags)");
_Static_assert(__builtin_offsetof(struct page, lru) == __builtin_offsetof(struct folio, lru), "offsetof(struct page, lru) == offsetof(struct folio, lru)");
_Static_assert(__builtin_offsetof(struct page, mapping) == __builtin_offsetof(struct folio, mapping), "offsetof(struct page, mapping) == offsetof(struct folio, mapping)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct folio, lru), "offsetof(struct page, compound_head) == offsetof(struct folio, lru)");
_Static_assert(__builtin_offsetof(struct page, __folio_index) == __builtin_offsetof(struct folio, index), "offsetof(struct page, __folio_index) == offsetof(struct folio, index)");
_Static_assert(__builtin_offsetof(struct page, private) == __builtin_offsetof(struct folio, private), "offsetof(struct page, private) == offsetof(struct folio, private)");
_Static_assert(__builtin_offsetof(struct page, _mapcount) == __builtin_offsetof(struct folio, _mapcount), "offsetof(struct page, _mapcount) == offsetof(struct folio, _mapcount)");
_Static_assert(__builtin_offsetof(struct page, _refcount) == __builtin_offsetof(struct folio, _refcount), "offsetof(struct page, _refcount) == offsetof(struct folio, _refcount)");
_Static_assert(__builtin_offsetof(struct page, memcg_data) == __builtin_offsetof(struct folio, memcg_data), "offsetof(struct page, memcg_data) == offsetof(struct folio, memcg_data)");
_Static_assert(__builtin_offsetof(struct folio, _flags_1) == __builtin_offsetof(struct page, flags) + sizeof(struct page), "offsetof(struct folio, _flags_1) == offsetof(struct page, flags) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_1) == __builtin_offsetof(struct page, compound_head) + sizeof(struct page), "offsetof(struct folio, _head_1) == offsetof(struct page, compound_head) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _mapcount_1) == __builtin_offsetof(struct page, _mapcount) + sizeof(struct page), "offsetof(struct folio, _mapcount_1) == offsetof(struct page, _mapcount) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _refcount_1) == __builtin_offsetof(struct page, _refcount) + sizeof(struct page), "offsetof(struct folio, _refcount_1) == offsetof(struct page, _refcount) + sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _flags_2) == __builtin_offsetof(struct page, flags) + 2 * sizeof(struct page), "offsetof(struct folio, _flags_2) == offsetof(struct page, flags) + 2 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_2) == __builtin_offsetof(struct page, compound_head) + 2 * sizeof(struct page), "offsetof(struct folio, _head_2) == offsetof(struct page, compound_head) + 2 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _flags_3) == __builtin_offsetof(struct page, flags) + 3 * sizeof(struct page), "offsetof(struct folio, _flags_3) == offsetof(struct page, flags) + 3 * sizeof(struct page)");
_Static_assert(__builtin_offsetof(struct folio, _head_3) == __builtin_offsetof(struct page, compound_head) + 3 * sizeof(struct page), "offsetof(struct folio, _head_3) == offsetof(struct page, compound_head) + 3 * sizeof(struct page)");
struct ptdesc {
 memdesc_flags_t pt_flags;

 union {
  struct callback_head pt_rcu_head;
  struct list_head pt_list;
  struct {
   unsigned long _pt_pad_1;
   pgtable_t pmd_huge_pte;
  };
 };
 unsigned long __page_mapping;

 union {
  unsigned long pt_index;
  struct mm_struct *pt_mm;
  atomic_t pt_frag_refcount;

  atomic_t pt_share_count;

 };

 union {
  unsigned long _pt_pad_2;

  spinlock_t *ptl;



 };
 unsigned int __page_type;
 atomic_t __page_refcount;

 unsigned long pt_memcg_data;

};
_Static_assert(__builtin_offsetof(struct page, flags) == __builtin_offsetof(struct ptdesc, pt_flags), "offsetof(struct page, flags) == offsetof(struct ptdesc, pt_flags)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct ptdesc, pt_list), "offsetof(struct page, compound_head) == offsetof(struct ptdesc, pt_list)");
_Static_assert(__builtin_offsetof(struct page, compound_head) == __builtin_offsetof(struct ptdesc, _pt_pad_1), "offsetof(struct page, compound_head) == offsetof(struct ptdesc, _pt_pad_1)");
_Static_assert(__builtin_offsetof(struct page, mapping) == __builtin_offsetof(struct ptdesc, __page_mapping), "offsetof(struct page, mapping) == offsetof(struct ptdesc, __page_mapping)");
_Static_assert(__builtin_offsetof(struct page, __folio_index) == __builtin_offsetof(struct ptdesc, pt_index), "offsetof(struct page, __folio_index) == offsetof(struct ptdesc, pt_index)");
_Static_assert(__builtin_offsetof(struct page, callback_head) == __builtin_offsetof(struct ptdesc, pt_rcu_head), "offsetof(struct page, callback_head) == offsetof(struct ptdesc, pt_rcu_head)");
_Static_assert(__builtin_offsetof(struct page, page_type) == __builtin_offsetof(struct ptdesc, __page_type), "offsetof(struct page, page_type) == offsetof(struct ptdesc, __page_type)");
_Static_assert(__builtin_offsetof(struct page, _refcount) == __builtin_offsetof(struct ptdesc, __page_refcount), "offsetof(struct page, _refcount) == offsetof(struct ptdesc, __page_refcount)");
_Static_assert(__builtin_offsetof(struct page, memcg_data) == __builtin_offsetof(struct ptdesc, pt_memcg_data), "offsetof(struct page, memcg_data) == offsetof(struct ptdesc, pt_memcg_data)");
_Static_assert(sizeof(struct ptdesc) <= sizeof(struct page), "sizeof(struct ptdesc) <= sizeof(struct page)");
typedef unsigned long vm_flags_t;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
_Static_assert((u64)((((((1UL))) << (2)) - 1) | ((((((1UL))) << (9)) - 1) << 2) | (((((1UL))) << (24)) | ((((1UL))) << (23))) | ((((1UL))) << (28)) | ((((1UL))) << (30)) | ((((1UL))) << (31))) <= (u64)(~0U), "(u64)MMF_INIT_LEGACY_MASK <= (u64)UINT_MAX");
struct page;
struct dev_pagemap;
struct page;
struct mempolicy;
struct user_namespace;
struct file;
struct dentry;
struct file;
struct address_space;
struct clk;
struct clk_hw;
struct clk_core;
struct dentry;
struct clk_rate_request {
 struct clk_core *core;
 unsigned long rate;
 unsigned long min_rate;
 unsigned long max_rate;
 unsigned long best_parent_rate;
 struct clk_hw *best_parent_hw;
};
struct clk_duty {
 unsigned int num;
 unsigned int den;
};
struct clk_ops {
 int (*prepare)(struct clk_hw *hw);
 void (*unprepare)(struct clk_hw *hw);
 int (*is_prepared)(struct clk_hw *hw);
 void (*unprepare_unused)(struct clk_hw *hw);
 int (*enable)(struct clk_hw *hw);
 void (*disable)(struct clk_hw *hw);
 int (*is_enabled)(struct clk_hw *hw);
 void (*disable_unused)(struct clk_hw *hw);
 int (*save_context)(struct clk_hw *hw);
 void (*restore_context)(struct clk_hw *hw);
 unsigned long (*recalc_rate)(struct clk_hw *hw,
     unsigned long parent_rate);
 long (*round_rate)(struct clk_hw *hw, unsigned long rate,
     unsigned long *parent_rate);
 int (*determine_rate)(struct clk_hw *hw,
       struct clk_rate_request *req);
 int (*set_parent)(struct clk_hw *hw, u8 index);
 u8 (*get_parent)(struct clk_hw *hw);
 int (*set_rate)(struct clk_hw *hw, unsigned long rate,
        unsigned long parent_rate);
 int (*set_rate_and_parent)(struct clk_hw *hw,
        unsigned long rate,
        unsigned long parent_rate, u8 index);
 unsigned long (*recalc_accuracy)(struct clk_hw *hw,
        unsigned long parent_accuracy);
 int (*get_phase)(struct clk_hw *hw);
 int (*set_phase)(struct clk_hw *hw, int degrees);
 int (*get_duty_cycle)(struct clk_hw *hw,
       struct clk_duty *duty);
 int (*set_duty_cycle)(struct clk_hw *hw,
       struct clk_duty *duty);
 int (*init)(struct clk_hw *hw);
 void (*terminate)(struct clk_hw *hw);
 void (*debug_init)(struct clk_hw *hw, struct dentry *dentry);
};
struct clk_parent_data {
 const struct clk_hw *hw;
 const char *fw_name;
 const char *name;
 int index;
};
struct clk_init_data {
 const char *name;
 const struct clk_ops *ops;

 const char * const *parent_names;
 const struct clk_parent_data *parent_data;
 const struct clk_hw **parent_hws;
 u8 num_parents;
 unsigned long flags;
};
struct clk_hw {
 struct clk_core *core;
 struct clk *clk;
 const struct clk_init_data *init;
};
struct clk;
struct regmap;
struct page;
struct vm_struct;
struct task_struct;
struct mem_cgroup;
_Static_assert(12 <= 20, "PAGE_SHIFT <= 20");
struct cpumask;
struct clk_audio_pad {
 struct clk_hw hw;
 struct regmap *regmap;
 u8 qdaudio;
 u8 div;
};
/*@ requires rate > 0; ensures \result == -22 <==> rate == 0; ensures \result == 0 ==> apad_ck->div == 2 || apad_ck->div == 3; */

static int clk_audio_pll_pad_set_rate(struct clk_hw *hw, unsigned long rate,
          unsigned long parent_rate)
{
 struct clk_audio_pad *apad_ck = ({ void *__mptr = (void *)(hw); _Static_assert(__builtin_types_compatible_p(typeof(*(hw)), typeof(((struct clk_audio_pad *)0)->hw)) || __builtin_types_compatible_p(typeof(*(hw)), typeof(void)), "pointer type mismatch in container_of()"); ((struct clk_audio_pad *)(__mptr - __builtin_offsetof(struct clk_audio_pad, hw))); });
 u8 tmp_div;

 do { static struct _ddebug   __UNIQUE_ID_ddebug819 = { .modname = "clk_audio_pll", .function = __func__, .filename = "drivers/clk/at91/clk-audio-pll.c", .format = ("A PLL/PAD: %s, rate = %lu (parent_rate = %lu)\n"), .lineno = 397, .flags = 0, .class_id = ((1 << 6) - 1), .key.dd_key_false = ((struct static_key_false){ .key = { .enabled = { 0 }, { .type = 0UL } }, }) }; do { __attribute__((__noreturn__)) extern void __compiletime_assert_820(void) ; if (!(!(((1 << 6) - 1) > ((1 << 6) - 1)))) __compiletime_assert_820(); } while (0); if (({ bool branch; if (__builtin_types_compatible_p(typeof(*&__UNIQUE_ID_ddebug819.key.dd_key_false), struct static_key_true)) branch = arch_static_branch_jump(&(&__UNIQUE_ID_ddebug819.key.dd_key_false)->key, false); else if (__builtin_types_compatible_p(typeof(*&__UNIQUE_ID_ddebug819.key.dd_key_false), struct static_key_false)) branch = arch_static_branch(&(&__UNIQUE_ID_ddebug819.key.dd_key_false)->key, false); else branch = ____wrong_branch_error(); __builtin_expect(!!(branch), 0); })) __dynamic_pr_debug(&__UNIQUE_ID_ddebug819, "A PLL/PAD: %s, rate = %lu (parent_rate = %lu)\n", __func__, rate, parent_rate); } while (0)
                     ;

 if (!rate)
  return -22;

 tmp_div = parent_rate / rate;
 if (tmp_div % 3 == 0) {
  apad_ck->qdaudio = tmp_div / 3;
  apad_ck->div = 3;
 } else {
  apad_ck->qdaudio = tmp_div / 2;
  apad_ck->div = 2;
 }

 return 0;
}
