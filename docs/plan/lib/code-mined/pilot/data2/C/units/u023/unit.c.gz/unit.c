__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
static inline    s64 div64_s64(s64 dividend, s64 divisor)
;
typedef __s64 time64_t;
struct ntp_data {
 unsigned long tick_usec;
 u64 tick_length;
 u64 tick_length_base;
 int time_state;
 int time_status;
 s64 time_offset;
 long time_constant;
 long time_maxerror;
 long time_esterror;
 s64 time_freq;
 time64_t time_reftime;
 long time_adjust;
 s64 ntp_tick_adj;
 time64_t ntp_next_leap_sec;
};
/*@ requires \true; ensures (\result == 0) <==> (secs < 256 || (!(time_status & 0x0008) && secs <= 2048)); */

static inline    s64 ntp_update_offset_fll(struct ntp_data *ntpdata, s64 offset64, long secs)
{
 ntpdata->time_status &= ~0x4000;

 if (secs < 256)
  return 0;

 if (!(ntpdata->time_status & 0x0008) && (secs <= 2048))
  return 0;

 ntpdata->time_status |= 0x4000;

 return div64_s64((offset64 << (32 - 2)), (secs));
}
