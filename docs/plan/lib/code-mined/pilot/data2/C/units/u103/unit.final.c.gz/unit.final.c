typedef unsigned char __u8;
typedef __u8 u8;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires \true; ensures (\result == true) <==> (!ctx_away_valid || new_queue || (ctx_to_valid && switch_detail == 0)); */

static inline    bool
__gen12_csb_parse(bool ctx_to_valid, bool ctx_away_valid, bool new_queue,
    u8 switch_detail)
{







 if (!ctx_away_valid || new_queue) {
  ((void)(sizeof(( long)(!ctx_to_valid))));
  return true;
 }






 ((void)(sizeof(( long)(switch_detail))));
 return false;
}
