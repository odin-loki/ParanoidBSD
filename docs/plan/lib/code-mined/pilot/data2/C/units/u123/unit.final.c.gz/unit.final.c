typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __size_t;
typedef unsigned long u_long;
typedef __int32_t int32_t;
typedef __uint32_t uint32_t;
typedef __size_t size_t;
typedef __vm_offset_t vm_offset_t;
typedef _Bool bool;
int casueword(volatile u_long *p, u_long oldval, u_long *oldvalp,
     u_long newval);
int
cp_slow0(vm_offset_t uva, size_t len, bool write,
    void (*f)(vm_offset_t, void *), void *arg)
;
struct casueword_arg0 {
 uint32_t oldval;
 uint32_t newval;
 int res;
};
static void
casueword_slow0(vm_offset_t kva, void *arg)
;
/*@ requires \valid_read(base) && \valid(oldvalp); ensures (\result == -1) || (\result == 0 && *oldvalp == oldval) || (\result == 1 && *oldvalp != oldval); */

int
casueword(volatile u_long *base, u_long oldval, u_long *oldvalp, u_long newval)
{
 struct casueword_arg0 ca;
 int res;

 ca.oldval = oldval;
 ca.newval = newval;
 res = cp_slow0((vm_offset_t)base, sizeof(int32_t), 1,
     casueword_slow0, &ca);
 if (res == 0) {
  *oldvalp = ca.oldval;
  return (ca.res);
 }
 return (-1);
}
