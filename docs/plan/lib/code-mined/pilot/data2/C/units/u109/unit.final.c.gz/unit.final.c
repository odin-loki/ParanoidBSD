__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
typedef u64 phys_addr_t;
 int sscanf(const char *, const char *, ...);
extern unsigned long long memparse(const char *ptr, char **retptr);
static phys_addr_t numa_cma_size[(1 << 10)] ;
/*@ requires p == \null || \valid_read(p); ensures \result == 0; */

static int  early_numa_cma(char *p)
{
 int nid, count = 0;
 unsigned long tmp;
 char *s = p;

 while (*s) {
  if (sscanf(s, "%lu%n", &tmp, &count) != 1)
   break;

  if (s[count] == ':') {
   if (tmp >= (1 << 10))
    break;
   nid = ({ typeof(tmp) _i = (tmp); typeof((1 << 10)) _s = ((1 << 10)); unsigned long _mask = ({ typeof((_i)+(_s)) __idx = (_i); typeof(__idx) __sz = (_s); unsigned long __mask; asm volatile ("cmp %1,%2; sbb %0,%0" :"=r" (__mask) :"g" (__sz), "r" (__idx) :"cc"); __mask; }); do { __attribute__((__noreturn__)) extern void __compiletime_assert_1140(void) ; if (!(!(sizeof(_i) > sizeof(long)))) __compiletime_assert_1140(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_1141(void) ; if (!(!(sizeof(_s) > sizeof(long)))) __compiletime_assert_1141(); } while (0); (typeof(_i)) (_i & _mask); });

   s += count + 1;
   tmp = memparse(s, &s);
   numa_cma_size[nid] = tmp;

   if (*s == ',')
    s++;
   else
    break;
  } else
   break;
 }

 return 0;
}
