typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __size_t;
typedef __uint64_t __vm_paddr_t;
typedef __int64_t __sbintime_t;
typedef unsigned int u_int;
typedef __int32_t int32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef char * caddr_t;
typedef __size_t size_t;
typedef __vm_paddr_t vm_paddr_t;
typedef struct _device *device_t;
typedef _Bool bool;
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct lock_object;
struct mtx;
struct socket;
typedef uint64_t bus_addr_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
struct resource;
struct mbuf;
struct m_tag {
 struct { struct m_tag *sle_next; } m_tag_link;
 u_int16_t m_tag_id;
 u_int16_t m_tag_len;
 u_int32_t m_tag_cookie;
 void (*m_tag_free)(struct m_tag *);
};
struct if_snd_tag_sw;
struct m_snd_tag {
 struct ifnet *ifp;
 const struct if_snd_tag_sw *sw;
 volatile u_int refcount;
};
struct pkthdr {
 union {
  struct m_snd_tag *snd_tag;
  struct ifnet *rcvif;
  struct {
   uint16_t rcvidx;
   uint16_t rcvgen;
  };
 };
 union {
  struct ifnet *leaf_rcvif;
  struct {
   uint16_t leaf_rcvidx;
   uint16_t leaf_rcvgen;
  };
 };
 struct packet_tags { struct m_tag *slh_first; } tags;
 int32_t len;


 uint32_t flowid;
 uint32_t csum_flags;
 uint16_t fibnum;
 uint8_t numa_domain;
 uint8_t rsstype;



 union {
  uint64_t rcv_tstmp;
  struct {
   uint8_t l2hlen;
   uint8_t l3hlen;
   uint8_t l4hlen;
   uint8_t l5hlen;
   uint8_t inner_l2hlen;
   uint8_t inner_l3hlen;
   uint8_t inner_l4hlen;
   uint8_t inner_l5hlen;
  };
 };
 union {
  uint8_t eight[8];
  uint16_t sixteen[4];
  uint32_t thirtytwo[2];
  uint64_t sixtyfour[1];
  uintptr_t unintptr[1];
  void *ptr;
 } PH_per;


 union {
  union {
   uint8_t eight[8];
   uint16_t sixteen[4];
   uint32_t thirtytwo[2];
   uint64_t sixtyfour[1];
   uintptr_t unintptr[1];
   void *ptr;
  } PH_loc;

  u_int memlen;
 };
};
struct ktls_session;
struct socket;
typedef void m_ext_free_t(struct mbuf *);
struct m_ext {
 union {
  volatile u_int ext_count;
  volatile u_int *ext_cnt;
 };
 uint32_t ext_size;
 uint32_t ext_type:8,
    ext_flags:24;
 union {
  struct {
   char *ext_buf;
   void *ext_arg2;
  };
  struct {







   vm_paddr_t extpg_pa[(40 / sizeof(vm_paddr_t))];
   char extpg_trail[64];
   char extpg_hdr[23];

  };
 };




 m_ext_free_t *ext_free;
 void *ext_arg1;
};
struct mbuf {







 union {
  struct mbuf *m_next;
  struct { struct mbuf *sle_next; } m_slist;
  struct { struct mbuf *stqe_next; } m_stailq;
 };
 union {
  struct mbuf *m_nextpkt;
  struct { struct mbuf *sle_next; } m_slistpkt;
  struct { struct mbuf *stqe_next; } m_stailqpkt;
 };
 caddr_t m_data;
 int32_t m_len;
 uint32_t m_type:8,
    m_flags:24;
 union {
  struct {
   union {

    struct pkthdr m_pkthdr;
    struct {


     uint8_t m_epg_npgs;
     uint8_t m_epg_nrdy;


     uint8_t m_epg_hdrlen;
     uint8_t m_epg_trllen;


     uint16_t m_epg_1st_off;
     uint16_t m_epg_last_len;
     uint8_t m_epg_flags;
     uint8_t m_epg_record_type;
     uint8_t __spare[2];
     int m_epg_enc_cnt;
     struct ktls_session *m_epg_tls;
     struct socket *m_epg_so;
     uint64_t m_epg_seqno;
     struct { struct mbuf *stqe_next; } m_epg_stailq;
    };
   };
   union {

    struct m_ext m_ext;

    char m_pktdat[1];
   };
  };
  char m_dat[1];
 };
};
static __inline void
m_tag_free(struct m_tag *t)
;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct socket;
struct ifnet;
typedef struct ifnet *if_t;
struct ifnet;
struct mbuf;
struct ifnet;
struct mbuf;
struct ifnet;
struct ifnet;
struct socket;
struct mtx;
struct ifnethead { struct ifnet *cstqh_first; struct ifnet **cstqh_last; };
struct ktls_session;
struct m_snd_tag;
struct if_snd_tag_rate_limit_params {
 uint64_t max_rate;
 uint32_t queue_level;
 uint32_t flags;
};
struct if_snd_tag_modify_tls_rx {

 uint32_t tls_hdr_tcp_sn;





 uint32_t tls_rec_length;


 uint64_t tls_seq_number;
};
union if_snd_tag_modify_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
 struct if_snd_tag_modify_tls_rx tls_rx;
};
union if_snd_tag_query_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
};
typedef int (if_snd_tag_modify_t)(struct m_snd_tag *, union if_snd_tag_modify_params *);
typedef int (if_snd_tag_query_t)(struct m_snd_tag *, union if_snd_tag_query_params *);
typedef void (if_snd_tag_free_t)(struct m_snd_tag *);
typedef struct m_snd_tag *(if_next_send_tag_t)(struct m_snd_tag *);
typedef int (if_snd_tag_status_str_t)(struct m_snd_tag *, char *buf, size_t *sz);
struct if_snd_tag_sw {
 if_snd_tag_modify_t *snd_tag_modify;
 if_snd_tag_query_t *snd_tag_query;
 if_snd_tag_free_t *snd_tag_free;
 if_next_send_tag_t *next_snd_tag;
 if_snd_tag_status_str_t *snd_tag_status_str;
 u_int type;
};
extern struct ifnethead ifnet;
struct mbuf;
typedef struct clk *clk_t;
typedef struct hwreset *hwreset_t;
typedef uint32_t phandle_t;
struct dwc_bufmap {
 bus_dmamap_t map;
 struct mbuf *mbuf;

 int last_desc_idx;
};
struct dwc_softc {
 struct resource *res[2];
 device_t dev;
 phandle_t node;
 int mii_clk;
 device_t miibus;
 struct mii_data * mii_softc;
 if_t ifp;
 int if_flags;
 struct mtx mtx;
 void * intr_cookie;
 struct callout dwc_callout;
 bool link_is_up;
 bool is_attached;
 bool is_detaching;
 int tx_watchdog_count;
 int stats_harvest_count;
 int phy_mode;


 clk_t clk_stmmaceth;
 clk_t clk_pclk;
 hwreset_t rst_stmmaceth;
 hwreset_t rst_ahb;


 uint32_t txpbl;
 uint32_t rxpbl;
 bool nopblx8;
 bool fixed_burst;
 bool mixed_burst;
 bool aal;
 bool dma_ext_desc;


 bus_dma_tag_t rxdesc_tag;
 bus_dmamap_t rxdesc_map;
 struct dwc_hwdesc *rxdesc_ring;
 bus_addr_t rxdesc_ring_paddr;
 bus_dma_tag_t rxbuf_tag;
 struct dwc_bufmap rxbuf_map[1024];
 uint32_t rx_idx;


 bus_dma_tag_t txdesc_tag;
 bus_dmamap_t txdesc_map;
 struct dwc_hwdesc *txdesc_ring;
 bus_addr_t txdesc_ring_paddr;
 bus_dma_tag_t txbuf_tag;
 struct dwc_bufmap txbuf_map[1024];
 uint32_t tx_desc_head;
 uint32_t tx_desc_tail;
 uint32_t tx_map_head;
 uint32_t tx_map_tail;
 int tx_desccount;
 int tx_mapcount;
};
struct dwc_hwdesc
{
 uint32_t desc0;
 uint32_t desc1;
 uint32_t addr1;
 uint32_t addr2;
};
/*@ requires curidx < 1024; ensures \result == (curidx + 1) % 1024; */

static inline uint32_t
next_txidx(struct dwc_softc *sc, uint32_t curidx)
{

 return ((curidx + 1) % 1024);
}
