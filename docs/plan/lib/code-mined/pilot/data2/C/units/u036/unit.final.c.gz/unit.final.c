__extension__ typedef unsigned long long __u64;
enum {
 false = 0,
 true = 1
};
typedef __u64 v4l2_std_id;
/*@ requires true; ensures (norm & (((v4l2_std_id)0x00000100) | ((v4l2_std_id)0x00000800) | (((v4l2_std_id)0x00001000) | ((v4l2_std_id)0x00002000) | ((v4l2_std_id)0x00008000)) | ((v4l2_std_id)0x00004000))) ? \result == 480 : \result == 576; */

static inline    unsigned int norm_maxh(v4l2_std_id norm)
{
 return (norm & (((v4l2_std_id)0x00000100) | ((v4l2_std_id)0x00000800) | (((v4l2_std_id)0x00001000) | ((v4l2_std_id)0x00002000) | ((v4l2_std_id)0x00008000)) | ((v4l2_std_id)0x00004000))) ? 480 : 576;
}
