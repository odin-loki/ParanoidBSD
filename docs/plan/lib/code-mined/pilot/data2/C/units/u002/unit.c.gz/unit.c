typedef enum {
    SURROGATE_MIN = 0xd800UL,
    SURROGATE_MAX = 0xdfffUL,
    UNICODE_MAX = 0x10ffffUL,
    UNICODE_LIMIT
} UNICODE_CONSTANTS;
static ossl_unused ossl_inline int is_unicode_surrogate(unsigned long value)
;
/*@ requires value <= 0xffffffffUL; ensures \result == (value <= 0x10ffffUL && !(0xd800UL <= value && value <= 0xdfffUL)); */

static ossl_unused ossl_inline int is_unicode_valid(unsigned long value)
{
    return value <= UNICODE_MAX && !is_unicode_surrogate(value);
}
