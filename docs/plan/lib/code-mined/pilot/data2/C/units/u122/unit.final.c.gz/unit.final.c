typedef unsigned int __uint32_t;
typedef __uint32_t uint32_t;
/*@ requires \valid(p); ensures *p == val; */

static __inline void
atomic_store_rel_32(volatile uint32_t *p, uint32_t val)
{

 __asm volatile("fence" ::: "memory");;

 *p = val;
}
