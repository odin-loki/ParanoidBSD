enum {
 false = 0,
 true = 1
};
enum lan969x_dsm_cal_dev {
 DSM_CAL_DEV_2G5,
 DSM_CAL_DEV_5G,
 DSM_CAL_DEV_10G,
 DSM_CAL_DEV_OTHER,
 DSM_CAL_DEV_MAX
};
/*@ requires true; ensures (dev == DSM_CAL_DEV_10G ==> \result == 10000) && (dev == DSM_CAL_DEV_5G ==> \result == 5000) && (dev == DSM_CAL_DEV_2G5 ==> \result == 2500) && (dev == DSM_CAL_DEV_OTHER ==> \result == 1000); */

static int lan969x_dsm_cal_get_speed(enum lan969x_dsm_cal_dev dev)
{
 return (dev == DSM_CAL_DEV_10G ? 10000 :
  dev == DSM_CAL_DEV_5G ? 5000 :
  dev == DSM_CAL_DEV_2G5 ? 2500 :
      1000);
}
