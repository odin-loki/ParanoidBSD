typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef s8 int8_t;
typedef s32 int32_t;
typedef u8 uint8_t;
typedef u16 uint16_t;
typedef u32 uint32_t;
typedef u64 uint64_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef u64 phys_addr_t;
typedef phys_addr_t resource_size_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
void abort(void);
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct net_device;
struct kernel_param;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct cacheline_padding {
 char x[1];
} ;
typedef __s64 time64_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
struct task_struct;
struct mm_struct;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
static inline     u64 field_mask(u64 field)
;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef struct cpumask *cpumask_var_t;
typedef atomic64_t atomic_long_t;
static inline     int
atomic_inc_return(atomic_t *v)
;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct static_key;
static inline    void cpuid(u32 op,
    u32 *eax, u32 *ebx,
    u32 *ecx, u32 *edx)
;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct module;
struct task_struct;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct page;
struct vm_area_struct;
struct mm_struct;
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct optimistic_spin_queue {




 atomic_t tail;
};
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct user_namespace;
struct uid_gid_map;
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct vm_area_struct;
struct file;
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
typedef struct wait_queue_entry wait_queue_entry_t;
typedef int (*wait_queue_func_t)(struct wait_queue_entry *wq_entry, unsigned mode, int flags, void *key);
struct wait_queue_entry {
 unsigned int flags;
 void *private;
 wait_queue_func_t func;
 struct list_head entry;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct device;
struct page;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct task_struct;
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct resource;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
struct pci_bus;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct cred;
struct file;
struct task_struct;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
struct sg_table;
struct file;
struct pid;
struct cred;
struct sock;
struct seq_file;
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;


 unsigned long last_holder;

};
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct hd_geometry;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
struct pglist_data;
struct file;
struct resource {
 resource_size_t start;
 resource_size_t end;
 const char *name;
 unsigned long flags;
 unsigned long desc;
 struct resource *parent, *sibling, *child;
};
struct device;
struct resource;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct kobject;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
enum dma_data_direction {
 DMA_BIDIRECTIONAL = 0,
 DMA_TO_DEVICE = 1,
 DMA_FROM_DEVICE = 2,
 DMA_NONE = 3,
};
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct resource;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
static inline    void device_lock(struct device *dev)
;
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
enum stat_group {
 STAT_READ,
 STAT_WRITE,
 STAT_DISCARD,
 STAT_FLUSH,

 NR_STAT_GROUPS
};
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct queue_limits;
extern struct bio *bio_split(struct bio *bio, int sectors,
        gfp_t gfp, struct bio_set *bs);
void submit_bio(struct bio *bio);
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct blk_zone {
 __u64 start;
 __u64 len;
 __u64 wp;
 __u8 type;
 __u8 cond;
 __u8 non_seq;
 __u8 reset;
 __u8 resv[4];
 __u64 capacity;
 __u8 reserved[24];
};
struct seq_file;
struct sbitmap_word {



 unsigned long word;




 unsigned long cleared ;




 raw_spinlock_t swap_lock;
} ;
struct sbitmap {



 unsigned int depth;




 unsigned int shift;




 unsigned int map_nr;




 bool round_robin;




 struct sbitmap_word *map;







 unsigned int *alloc_hint;
};
struct sbq_wait_state {



 wait_queue_head_t wait;
} ;
struct sbitmap_queue {



 struct sbitmap sb;





 unsigned int wake_batch;




 atomic_t wake_index;




 struct sbq_wait_state *ws;




 atomic_t ws_active;





 unsigned int min_shallow_depth;





 atomic_t completion_cnt;




 atomic_t wakeup_cnt;
};
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct fd {
 unsigned long word;
};
struct module;
struct request_queue;
struct elevator_queue;
struct blk_trace;
struct request;
struct blkcg_gq;
struct blk_flush_queue;
struct kiocb;
struct pr_ops;
struct rq_qos;
struct blk_queue_stats;
struct blk_crypto_profile;
struct partition_meta_info {
 char uuid[(36 + 1)];
 u8 volname[64];
};
struct disk_events;
struct badblocks;
enum blk_integrity_checksum {
 BLK_INTEGRITY_CSUM_NONE = 0,
 BLK_INTEGRITY_CSUM_IP = 1,
 BLK_INTEGRITY_CSUM_CRC = 2,
 BLK_INTEGRITY_CSUM_CRC64 = 3,
} __attribute__((__packed__)) ;
struct blk_integrity {
 unsigned char flags;
 enum blk_integrity_checksum csum_type;
 unsigned char metadata_size;
 unsigned char pi_offset;
 unsigned char interval_exp;
 unsigned char tag_size;
 unsigned char pi_tuple_size;
};
typedef unsigned int blk_mode_t;
struct gendisk {




 int major;
 int first_minor;
 int minors;

 char disk_name[32];

 unsigned short events;
 unsigned short event_flags;

 struct xarray part_tbl;
 struct block_device *part0;

 const struct block_device_operations *fops;
 struct request_queue *queue;
 void *private_data;

 struct bio_set bio_split;

 int flags;
 unsigned long state;

 struct mutex open_mutex;
 unsigned open_partitions;

 struct backing_dev_info *bdi;
 struct kobject queue_kobj;
 struct kobject *slave_dir;

 struct list_head slave_bdevs;

 struct timer_rand_state *random;
 struct disk_events *ev;
 unsigned int nr_zones;
 unsigned int zone_capacity;
 unsigned int last_zone_capacity;
 unsigned long *conv_zones_bitmap;
 unsigned int zone_wplugs_hash_bits;
 atomic_t nr_zone_wplugs;
 spinlock_t zone_wplugs_lock;
 struct mempool *zone_wplugs_pool;
 struct hlist_head *zone_wplugs_hash;
 struct workqueue_struct *zone_wplugs_wq;



 struct cdrom_device_info *cdi;

 int node_id;
 struct badblocks *bb;
 struct lockdep_map lockdep_map;
 u64 diskseq;
 blk_mode_t open_mode;





 struct blk_independent_access_ranges *ia_ranges;

 struct mutex rqos_state_mutex;
};
typedef unsigned int blk_features_t;
typedef unsigned int blk_flags_t;
struct queue_limits {
 blk_features_t features;
 blk_flags_t flags;
 unsigned long seg_boundary_mask;
 unsigned long virt_boundary_mask;

 unsigned int max_hw_sectors;
 unsigned int max_dev_sectors;
 unsigned int chunk_sectors;
 unsigned int max_sectors;
 unsigned int max_user_sectors;
 unsigned int max_segment_size;
 unsigned int min_segment_size;
 unsigned int physical_block_size;
 unsigned int logical_block_size;
 unsigned int alignment_offset;
 unsigned int io_min;
 unsigned int io_opt;
 unsigned int max_discard_sectors;
 unsigned int max_hw_discard_sectors;
 unsigned int max_user_discard_sectors;
 unsigned int max_secure_erase_sectors;
 unsigned int max_write_zeroes_sectors;
 unsigned int max_wzeroes_unmap_sectors;
 unsigned int max_hw_wzeroes_unmap_sectors;
 unsigned int max_user_wzeroes_unmap_sectors;
 unsigned int max_hw_zone_append_sectors;
 unsigned int max_zone_append_sectors;
 unsigned int discard_granularity;
 unsigned int discard_alignment;
 unsigned int zone_write_granularity;


 unsigned int atomic_write_hw_max;
 unsigned int atomic_write_max_sectors;
 unsigned int atomic_write_hw_boundary;
 unsigned int atomic_write_boundary_sectors;
 unsigned int atomic_write_hw_unit_min;
 unsigned int atomic_write_unit_min;
 unsigned int atomic_write_hw_unit_max;
 unsigned int atomic_write_unit_max;

 unsigned short max_segments;
 unsigned short max_integrity_segments;
 unsigned short max_discard_segments;

 unsigned short max_write_streams;
 unsigned int write_stream_granularity;

 unsigned int max_open_zones;
 unsigned int max_active_zones;






 unsigned int dma_alignment;
 unsigned int dma_pad_mask;

 struct blk_integrity integrity;
};
typedef int (*report_zones_cb)(struct blk_zone *zone, unsigned int idx,
          void *data);
struct blk_independent_access_range {
 struct kobject kobj;
 sector_t sector;
 sector_t nr_sectors;
};
struct blk_independent_access_ranges {
 struct kobject kobj;
 bool sysfs_registered;
 unsigned int nr_ia_ranges;
 struct blk_independent_access_range ia_range[1];
};
struct request_queue {




 void *queuedata;

 struct elevator_queue *elevator;

 const struct blk_mq_ops *mq_ops;


 struct blk_mq_ctx *queue_ctx;




 unsigned long queue_flags;

 unsigned int rq_timeout;

 unsigned int queue_depth;

 refcount_t refs;


 unsigned int nr_hw_queues;
 struct xarray hctx_table;

 struct percpu_ref q_usage_counter;
 struct lock_class_key io_lock_cls_key;
 struct lockdep_map io_lockdep_map;

 struct lock_class_key q_lock_cls_key;
 struct lockdep_map q_lockdep_map;

 struct request *last_merge;

 spinlock_t queue_lock;

 int quiesce_depth;

 struct gendisk *disk;




 struct kobject *mq_kobj;

 struct queue_limits limits;


 struct device *dev;
 enum rpm_status rpm_status;






 atomic_t pm_only;

 struct blk_queue_stats *stats;
 struct rq_qos *rq_qos;
 struct mutex rq_qos_mutex;





 int id;




 unsigned long nr_requests;


 struct blk_crypto_profile *crypto_profile;
 struct kobject *crypto_kobject;


 struct timer_list timeout;
 struct work_struct timeout_work;

 atomic_t nr_active_requests_shared_tags;

 struct blk_mq_tags *sched_shared_tags;

 struct list_head icq_list;

 unsigned long blkcg_pols[(((6) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct blkcg_gq *root_blkg;
 struct list_head blkg_list;
 struct mutex blkcg_mutex;


 int node;

 spinlock_t requeue_lock;
 struct list_head requeue_list;
 struct delayed_work requeue_work;


 struct blk_trace *blk_trace;




 struct blk_flush_queue *fq;
 struct list_head flush_list;
 struct mutex elevator_lock;

 struct mutex sysfs_lock;



 struct mutex limits_lock;





 struct list_head unused_hctx_list;
 spinlock_t unused_hctx_lock;

 int mq_freeze_depth;



 struct throtl_data *td;

 struct callback_head callback_head;

 struct task_struct *mq_freeze_owner;
 int mq_freeze_owner_depth;




 bool mq_freeze_disk_dead;
 bool mq_freeze_queue_dying;

 wait_queue_head_t mq_freeze_wq;




 struct mutex mq_freeze_lock;

 struct blk_mq_tag_set *tag_set;
 struct list_head tag_set_list;

 struct dentry *debugfs_dir;
 struct dentry *sched_debugfs_dir;
 struct dentry *rqos_debugfs_dir;



 struct mutex debugfs_mutex;
};
struct rq_list {
 struct request *head;
 struct request *tail;
};
struct blk_plug {
 struct rq_list mq_list;


 struct rq_list cached_rqs;
 u64 cur_ktime;
 unsigned short nr_ios;

 unsigned short rq_count;

 bool multiple_queues;
 bool has_elevator;

 struct list_head cb_list;
};
enum blk_unique_id {

 BLK_UID_T10 = 1,
 BLK_UID_EUI64 = 2,
 BLK_UID_NAA = 3,
};
struct block_device_operations {
 void (*submit_bio)(struct bio *bio);
 int (*poll_bio)(struct bio *bio, struct io_comp_batch *iob,
   unsigned int flags);
 int (*open)(struct gendisk *disk, blk_mode_t mode);
 void (*release)(struct gendisk *disk);
 int (*ioctl)(struct block_device *bdev, blk_mode_t mode,
   unsigned cmd, unsigned long arg);
 int (*compat_ioctl)(struct block_device *bdev, blk_mode_t mode,
   unsigned cmd, unsigned long arg);
 unsigned int (*check_events) (struct gendisk *disk,
          unsigned int clearing);
 void (*unlock_native_capacity) (struct gendisk *);
 int (*getgeo)(struct gendisk *, struct hd_geometry *);
 int (*set_read_only)(struct block_device *bdev, bool ro);
 void (*free_disk)(struct gendisk *disk);

 void (*swap_slot_free_notify) (struct block_device *, unsigned long);
 int (*report_zones)(struct gendisk *, sector_t sector,
   unsigned int nr_zones, report_zones_cb cb, void *data);
 char *(*devnode)(struct gendisk *disk, umode_t *mode);

 int (*get_unique_id)(struct gendisk *disk, u8 id[16],
   enum blk_unique_id id_type);
 struct module *owner;
 const struct pr_ops *pr_ops;






 int (*alternative_gpt_sector)(struct gendisk *disk, sector_t *sector);
};
struct blk_holder_ops {
 void (*mark_dead)(struct block_device *bdev, bool surprise);




 void (*sync)(struct block_device *bdev);




 int (*freeze)(struct block_device *bdev);




 int (*thaw)(struct block_device *bdev);
};
unsigned int block_size(struct block_device *bdev);
struct io_comp_batch {
 struct rq_list req_list;
 bool need_ts;
 void (*complete)(struct io_comp_batch *);
};
enum irqreturn {
 IRQ_NONE = (0 << 0),
 IRQ_HANDLED = (1 << 0),
 IRQ_WAKE_THREAD = (1 << 1),
};
typedef enum irqreturn irqreturn_t;
extern char _data[], _sdata[], _edata[];
typedef irqreturn_t (*irq_handler_t)(int, void *);
struct device;
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
typedef unsigned long kernel_ulong_t;
struct pci_device_id {
 __u32 vendor, device;
 __u32 subvendor, subdevice;
 __u32 class, class_mask;
 kernel_ulong_t driver_data;
 __u32 override_only;
};
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
struct pci_dev;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct device;
struct device;
struct pci_slot {
 struct pci_bus *bus;
 struct list_head list;
 struct hotplug_slot *hotplug;
 u16 number;
 unsigned int per_func_slot:1;
 struct kobject kobj;
};
enum {

 PCI_STD_RESOURCES,
 PCI_STD_RESOURCE_END = PCI_STD_RESOURCES + 6 - 1,


 PCI_ROM_RESOURCE,



 PCI_IOV_RESOURCES,
 PCI_IOV_RESOURCE_END = PCI_IOV_RESOURCES + 6 - 1,









 PCI_BRIDGE_RESOURCES,
 PCI_BRIDGE_RESOURCE_END = PCI_BRIDGE_RESOURCES +
      4 - 1,


 PCI_NUM_RESOURCES,


 DEVICE_COUNT_RESOURCE = PCI_NUM_RESOURCES,
};
typedef int pci_power_t;
typedef unsigned int pci_channel_state_t;
enum {

 pci_channel_io_normal = ( pci_channel_state_t) 1,


 pci_channel_io_frozen = ( pci_channel_state_t) 2,


 pci_channel_io_perm_failure = ( pci_channel_state_t) 3,
};
typedef unsigned short pci_dev_flags_t;
typedef unsigned short pci_bus_flags_t;
struct pci_vpd {
 struct mutex lock;
 unsigned int len;
 u8 cap;
};
struct pcie_bwctrl_data;
struct pcie_link_state;
struct pci_sriov;
struct pci_p2pdma;
struct rcec_ea;
struct pci_dev {
 struct list_head bus_list;
 struct pci_bus *bus;
 struct pci_bus *subordinate;

 void *sysdata;
 struct proc_dir_entry *procent;
 struct pci_slot *slot;

 unsigned int devfn;
 unsigned short vendor;
 unsigned short device;
 unsigned short subsystem_vendor;
 unsigned short subsystem_device;
 unsigned int class;
 u8 revision;
 u8 hdr_type;

 u16 aer_cap;
 struct aer_info *aer_info;


 struct rcec_ea *rcec_ea;
 struct pci_dev *rcec;

 u32 devcap;
 u16 rebar_cap;
 u8 pcie_cap;
 u8 msi_cap;
 u8 msix_cap;
 u8 pcie_mpss:3;
 u8 rom_base_reg;
 u8 pin;
 u16 pcie_flags_reg;
 unsigned long *dma_alias_mask;

 struct pci_driver *driver;
 u64 dma_mask;





 struct device_dma_parameters dma_parms;

 pci_power_t current_state;


 u8 pm_cap;
 unsigned int pme_support:5;

 unsigned int pme_poll:1;
 unsigned int pinned:1;
 unsigned int config_rrs_sv:1;
 unsigned int imm_ready:1;
 unsigned int d1_support:1;
 unsigned int d2_support:1;
 unsigned int no_d1d2:1;
 unsigned int no_d3cold:1;
 unsigned int bridge_d3:1;
 unsigned int d3cold_allowed:1;
 unsigned int mmio_always_on:1;

 unsigned int wakeup_prepared:1;
 unsigned int skip_bus_pm:1;
 unsigned int ignore_hotplug:1;
 unsigned int hotplug_user_indicators:1;


 unsigned int clear_retrain_link:1;

 unsigned int no_bw_notif:1;
 unsigned int d3hot_delay;
 unsigned int d3cold_delay;

 u16 l1ss;

 struct pcie_link_state *link_state;
 unsigned int aspm_l0s_support:1;
 unsigned int aspm_l1_support:1;
 unsigned int ltr_path:1;


 unsigned int pasid_no_tlp:1;
 unsigned int eetlp_prefix_max:3;

 pci_channel_state_t error_state;
 struct device dev;

 int cfg_size;





 unsigned int irq;
 struct resource resource[DEVICE_COUNT_RESOURCE];
 struct resource driver_exclusive_resource;

 unsigned int transparent:1;
 unsigned int io_window:1;
 unsigned int pref_window:1;
 unsigned int pref_64_window:1;
 unsigned int multifunction:1;

 unsigned int is_busmaster:1;
 unsigned int no_msi:1;
 unsigned int no_64bit_msi:1;
 unsigned int block_cfg_access:1;
 unsigned int broken_parity_status:1;
 unsigned int irq_reroute_variant:2;
 unsigned int msi_enabled:1;
 unsigned int msix_enabled:1;
 unsigned int ari_enabled:1;
 unsigned int ats_enabled:1;
 unsigned int pasid_enabled:1;
 unsigned int pri_enabled:1;
 unsigned int tph_enabled:1;
 unsigned int is_managed:1;
 unsigned int is_msi_managed:1;
 unsigned int needs_freset:1;
 unsigned int state_saved:1;
 unsigned int is_physfn:1;
 unsigned int is_virtfn:1;
 unsigned int is_hotplug_bridge:1;
 unsigned int is_pciehp:1;
 unsigned int shpc_managed:1;
 unsigned int is_thunderbolt:1;







 unsigned int untrusted:1;





 unsigned int external_facing:1;
 unsigned int broken_intx_masking:1;
 unsigned int io_window_1k:1;
 unsigned int irq_managed:1;
 unsigned int non_compliant_bars:1;
 unsigned int is_probed:1;
 unsigned int link_active_reporting:1;
 unsigned int no_vf_scan:1;
 unsigned int no_command_memory:1;
 unsigned int rom_bar_overlap:1;
 unsigned int rom_attr_enabled:1;
 unsigned int non_mappable_bars:1;
 pci_dev_flags_t dev_flags;
 atomic_t enable_cnt;

 spinlock_t pcie_cap_lock;
 u32 saved_config_space[16];
 struct hlist_head saved_cap_space;
 struct bin_attribute *res_attr[DEVICE_COUNT_RESOURCE];
 struct bin_attribute *res_attr_wc[DEVICE_COUNT_RESOURCE];


 unsigned int broken_cmd_compl:1;


 u16 ptm_cap;
 unsigned int ptm_root:1;
 unsigned int ptm_enabled:1;
 u8 ptm_granularity;


 void *msix_base;
 raw_spinlock_t msi_lock;

 struct pci_vpd vpd;

 u16 dpc_cap;
 unsigned int dpc_rp_extensions:1;
 u8 dpc_rp_log_size;

 struct pcie_bwctrl_data *link_bwctrl;

 union {
  struct pci_sriov *sriov;
  struct pci_dev *physfn;
 };
 u16 ats_cap;
 u8 ats_stu;


 u16 pri_cap;
 u32 pri_reqs_alloc;
 unsigned int pasid_required:1;


 u16 pasid_cap;
 u16 pasid_features;


 struct pci_p2pdma *p2pdma;


 struct xarray doe_mbs;


 struct npem *npem;

 u16 acs_cap;
 u8 supported_speeds;
 phys_addr_t rom;
 size_t romlen;
 unsigned long priv_flags;


 u8 reset_methods[8];


 u16 tph_cap;
 u8 tph_mode;
 u8 tph_req_type;

};
struct pci_bus {
 struct list_head node;
 struct pci_bus *parent;
 struct list_head children;
 struct list_head devices;
 struct pci_dev *self;
 struct list_head slots;

 struct resource *resource[4];
 struct list_head resources;
 struct resource busn_res;

 struct pci_ops *ops;
 void *sysdata;
 struct proc_dir_entry *procdir;

 unsigned char number;
 unsigned char primary;
 unsigned char max_bus_speed;
 unsigned char cur_bus_speed;




 char name[48];

 unsigned short bridge_ctl;
 pci_bus_flags_t bus_flags;
 struct device *bridge;
 struct device dev;
 struct bin_attribute *legacy_io;
 struct bin_attribute *legacy_mem;
 unsigned int is_added:1;
 unsigned int unsafe_warn:1;
 unsigned int flit_mode:1;
};
struct pci_ops {
 int (*add_bus)(struct pci_bus *bus);
 void (*remove_bus)(struct pci_bus *bus);
 void *(*map_bus)(struct pci_bus *bus, unsigned int devfn, int where);
 int (*read)(struct pci_bus *bus, unsigned int devfn, int where, int size, u32 *val);
 int (*write)(struct pci_bus *bus, unsigned int devfn, int where, int size, u32 val);
};
struct pci_dynids {
 spinlock_t lock;
 struct list_head list;
};
typedef unsigned int pci_ers_result_t;
struct pci_error_handlers {

 pci_ers_result_t (*error_detected)(struct pci_dev *dev,
        pci_channel_state_t error);


 pci_ers_result_t (*mmio_enabled)(struct pci_dev *dev);


 pci_ers_result_t (*slot_reset)(struct pci_dev *dev);


 void (*reset_prepare)(struct pci_dev *dev);
 void (*reset_done)(struct pci_dev *dev);


 void (*resume)(struct pci_dev *dev);


 void (*cor_error_detected)(struct pci_dev *dev);
};
struct module;
struct pci_driver {
 const char *name;
 const struct pci_device_id *id_table;
 int (*probe)(struct pci_dev *dev, const struct pci_device_id *id);
 void (*remove)(struct pci_dev *dev);
 int (*suspend)(struct pci_dev *dev, pm_message_t state);
 int (*resume)(struct pci_dev *dev);
 void (*shutdown)(struct pci_dev *dev);
 int (*sriov_configure)(struct pci_dev *dev, int num_vfs);
 int (*sriov_set_msix_vec_count)(struct pci_dev *vf, int msix_vec_count);
 u32 (*sriov_get_vf_total_msix)(struct pci_dev *pf);
 const struct pci_error_handlers *err_handler;
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;
 struct device_driver driver;
 struct pci_dynids dynids;
 bool driver_managed_dma;
};
extern unsigned int pci_flags;
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct sg_table {
 struct scatterlist *sgl;
 unsigned int nents;
 unsigned int orig_nents;
};
struct device;
static inline    void *pci_get_drvdata(struct pci_dev *pdev)
;
struct device_node;
struct irq_domain;
struct scsi_lun {
 __u8 scsi_lun[8];
};
struct scsi_cmnd;
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct page;
struct blk_mq_tags;
struct blk_flush_queue;
enum rq_end_io_ret {
 RQ_END_IO_NONE,
 RQ_END_IO_FREE,
};
typedef enum rq_end_io_ret (rq_end_io_fn)(struct request *, blk_status_t);
typedef __u32 req_flags_t;
enum mq_rq_state {
 MQ_RQ_IDLE = 0,
 MQ_RQ_IN_FLIGHT = 1,
 MQ_RQ_COMPLETE = 2,
};
struct request {
 struct request_queue *q;
 struct blk_mq_ctx *mq_ctx;
 struct blk_mq_hw_ctx *mq_hctx;

 blk_opf_t cmd_flags;
 req_flags_t rq_flags;

 int tag;
 int internal_tag;

 unsigned int timeout;


 unsigned int __data_len;
 sector_t __sector;

 struct bio *bio;
 struct bio *biotail;

 union {
  struct list_head queuelist;
  struct request *rq_next;
 };

 struct block_device *part;


 u64 alloc_time_ns;


 u64 start_time_ns;

 u64 io_start_time_ns;


 unsigned short wbt_flags;






 unsigned short stats_sectors;





 unsigned short nr_phys_segments;
 unsigned short nr_integrity_segments;







 unsigned char phys_gap_bit;


 struct bio_crypt_ctx *crypt_ctx;
 struct blk_crypto_keyslot *crypt_keyslot;


 enum mq_rq_state state;
 atomic_t ref;

 unsigned long deadline;
 union {
  struct hlist_node hash;
  struct llist_node ipi_list;
 };







 union {
  struct rb_node rb_node;
  struct bio_vec special_vec;
 };





 struct {
  struct io_cq *icq;
  void *priv[2];
 } elv;

 struct {
  unsigned int seq;
  rq_end_io_fn *saved_end_io;
 } flush;

 u64 fifo_time;




 rq_end_io_fn *end_io;
 void *end_io_data;
};
enum blk_eh_timer_return {
 BLK_EH_DONE,
 BLK_EH_RESET_TIMER,
};
struct blk_mq_hw_ctx {
 struct {

  spinlock_t lock;







  struct list_head dispatch;




  unsigned long state;
 } ;




 struct delayed_work run_work;

 cpumask_var_t cpumask;




 int next_cpu;




 int next_cpu_batch;


 unsigned long flags;





 void *sched_data;



 struct request_queue *queue;

 struct blk_flush_queue *fq;





 void *driver_data;





 struct sbitmap ctx_map;





 struct blk_mq_ctx *dispatch_from;





 unsigned int dispatch_busy;


 unsigned short type;

 unsigned short nr_ctx;

 struct blk_mq_ctx **ctxs;


 spinlock_t dispatch_wait_lock;




 wait_queue_entry_t dispatch_wait;





 atomic_t wait_index;





 struct blk_mq_tags *tags;





 struct blk_mq_tags *sched_tags;


 unsigned int numa_node;

 unsigned int queue_num;





 atomic_t nr_active;


 struct hlist_node cpuhp_online;

 struct hlist_node cpuhp_dead;

 struct kobject kobj;






 struct dentry *debugfs_dir;

 struct dentry *sched_debugfs_dir;






 struct list_head hctx_list;
};
struct blk_mq_queue_map {
 unsigned int *mq_map;
 unsigned int nr_queues;
 unsigned int queue_offset;
};
enum hctx_type {
 HCTX_TYPE_DEFAULT,
 HCTX_TYPE_READ,
 HCTX_TYPE_POLL,

 HCTX_MAX_TYPES,
};
struct blk_mq_tag_set {
 const struct blk_mq_ops *ops;
 struct blk_mq_queue_map map[HCTX_MAX_TYPES];
 unsigned int nr_maps;
 unsigned int nr_hw_queues;
 unsigned int queue_depth;
 unsigned int reserved_tags;
 unsigned int cmd_size;
 int numa_node;
 unsigned int timeout;
 unsigned int flags;
 void *driver_data;

 struct blk_mq_tags **tags;

 struct blk_mq_tags *shared_tags;

 struct mutex tag_list_lock;
 struct list_head tag_list;
 struct srcu_struct *srcu;
 struct srcu_struct tags_srcu;

 struct rw_semaphore update_nr_hwq_lock;
};
struct blk_mq_queue_data {
 struct request *rq;
 bool last;
};
struct blk_mq_ops {



 blk_status_t (*queue_rq)(struct blk_mq_hw_ctx *,
     const struct blk_mq_queue_data *);
 void (*commit_rqs)(struct blk_mq_hw_ctx *);







 void (*queue_rqs)(struct rq_list *rqlist);







 int (*get_budget)(struct request_queue *);




 void (*put_budget)(struct request_queue *, int);




 void (*set_rq_budget_token)(struct request *, int);



 int (*get_rq_budget_token)(struct request *);




 enum blk_eh_timer_return (*timeout)(struct request *);




 int (*poll)(struct blk_mq_hw_ctx *, struct io_comp_batch *);




 void (*complete)(struct request *);






 int (*init_hctx)(struct blk_mq_hw_ctx *, void *, unsigned int);



 void (*exit_hctx)(struct blk_mq_hw_ctx *, unsigned int);
 int (*init_request)(struct blk_mq_tag_set *set, struct request *,
       unsigned int, unsigned int);



 void (*exit_request)(struct blk_mq_tag_set *set, struct request *,
        unsigned int);





 void (*cleanup_rq)(struct request *);




 bool (*busy)(struct request_queue *);





 void (*map_queues)(struct blk_mq_tag_set *set);






 void (*show_rq)(struct seq_file *m, struct request *rq);

};
struct blk_mq_tags {
 unsigned int nr_tags;
 unsigned int nr_reserved_tags;
 unsigned int active_queues;

 struct sbitmap_queue bitmap_tags;
 struct sbitmap_queue breserved_tags;

 struct request **rqs;
 struct request **static_rqs;
 struct list_head page_list;





 spinlock_t lock;
 struct callback_head callback_head;
};
struct block_device;
struct completion;
struct module;
struct scsi_cmnd;
struct scsi_device;
struct scsi_target;
struct Scsi_Host;
struct scsi_transport_template;
enum scsi_timeout_action {
 SCSI_EH_DONE,
 SCSI_EH_RESET_TIMER,
 SCSI_EH_NOT_HANDLED,
};
struct scsi_host_template {
 unsigned int cmd_size;
 int (* queuecommand)(struct Scsi_Host *, struct scsi_cmnd *);
 void (*commit_rqs)(struct Scsi_Host *, u16);

 struct module *module;
 const char *name;
 const char *(*info)(struct Scsi_Host *);






 int (*ioctl)(struct scsi_device *dev, unsigned int cmd,
       void *arg);
 int (*compat_ioctl)(struct scsi_device *dev, unsigned int cmd,
       void *arg);


 int (*init_cmd_priv)(struct Scsi_Host *shost, struct scsi_cmnd *cmd);
 int (*exit_cmd_priv)(struct Scsi_Host *shost, struct scsi_cmnd *cmd);
 int (* eh_abort_handler)(struct scsi_cmnd *);
 int (* eh_device_reset_handler)(struct scsi_cmnd *);
 int (* eh_target_reset_handler)(struct scsi_cmnd *);
 int (* eh_bus_reset_handler)(struct scsi_cmnd *);
 int (* eh_host_reset_handler)(struct scsi_cmnd *);
 int (* sdev_init)(struct scsi_device *);
 int (* sdev_configure)(struct scsi_device *, struct queue_limits *lim);
 void (* sdev_destroy)(struct scsi_device *);
 int (* target_alloc)(struct scsi_target *);
 void (* target_destroy)(struct scsi_target *);
 int (* scan_finished)(struct Scsi_Host *, unsigned long);
 void (* scan_start)(struct Scsi_Host *);
 int (* change_queue_depth)(struct scsi_device *, int);







 void (* map_queues)(struct Scsi_Host *shost);
 int (* mq_poll)(struct Scsi_Host *shost, unsigned int queue_num);






 bool (* dma_need_drain)(struct request *rq);
 int (* bios_param)(struct scsi_device *, struct gendisk *,
   sector_t, int []);







 void (*unlock_native_capacity)(struct scsi_device *);
 int (*show_info)(struct seq_file *, struct Scsi_Host *);
 int (*write_info)(struct Scsi_Host *, char *, int);
 enum scsi_timeout_action (*eh_timed_out)(struct scsi_cmnd *);





 bool (*eh_should_retry_cmd)(struct scsi_cmnd *scmd);
 int (*host_reset)(struct Scsi_Host *shost, int reset_type);





 const char *proc_name;






 int can_queue;
 int this_id;





 unsigned short sg_tablesize;
 unsigned short sg_prot_tablesize;




 unsigned int max_sectors;




 unsigned int max_segment_size;

 unsigned int dma_alignment;





 unsigned long dma_boundary;

 unsigned long virt_boundary_mask;







 short cmd_per_lun;




 bool tag_alloc_policy_rr : 1;




 unsigned track_queue_depth:1;




 unsigned supported_mode:2;




 unsigned emulated:1;




 unsigned skip_settle_delay:1;


 unsigned no_write_same:1;


 unsigned host_tagset:1;


 unsigned queuecommand_may_block:1;




 unsigned int max_host_blocked;




 const struct attribute_group **shost_groups;





 const struct attribute_group **sdev_groups;
 u64 vendor_id;
};
enum scsi_host_state {
 SHOST_CREATED = 1,
 SHOST_RUNNING,
 SHOST_CANCEL,
 SHOST_DEL,
 SHOST_RECOVERY,
 SHOST_CANCEL_RECOVERY,
 SHOST_DEL_RECOVERY,
};
struct Scsi_Host {
 struct list_head __devices;
 struct list_head __targets;

 struct list_head starved_list;

 spinlock_t default_lock;
 spinlock_t *host_lock;

 struct mutex scan_mutex;

 struct list_head eh_abort_list;
 struct list_head eh_cmd_q;
 struct task_struct * ehandler;
 struct completion * eh_action;

 wait_queue_head_t host_wait;
 const struct scsi_host_template *hostt;
 struct scsi_transport_template *transportt;

 struct kref tagset_refcnt;
 struct completion tagset_freed;

 struct blk_mq_tag_set tag_set;

 atomic_t host_blocked;

 unsigned int host_failed;

 unsigned int host_eh_scheduled;

 unsigned int host_no;


 int eh_deadline;
 unsigned long last_reset;
 unsigned int max_channel;
 unsigned int max_id;
 u64 max_lun;
 unsigned int unique_id;
 unsigned short max_cmd_len;

 int this_id;
 int can_queue;
 short cmd_per_lun;
 short unsigned int sg_tablesize;
 short unsigned int sg_prot_tablesize;
 unsigned int max_sectors;
 unsigned int opt_sectors;
 unsigned int max_segment_size;
 unsigned int dma_alignment;
 unsigned long dma_boundary;
 unsigned long virt_boundary_mask;
 unsigned nr_hw_queues;
 unsigned nr_maps;


 bool eh_noresume;

 unsigned active_mode:2;





 unsigned host_self_blocked:1;






 unsigned reverse_ordering:1;


 unsigned tmf_in_progress:1;


 unsigned async_scan:1;


 unsigned no_write_same:1;


 unsigned host_tagset:1;


 unsigned queuecommand_may_block:1;


 unsigned short_inquiry:1;


 unsigned no_scsi2_lun_in_cdb:1;




 struct workqueue_struct *work_q;




 struct workqueue_struct *tmf_work_q;




 unsigned int max_host_blocked;


 unsigned int prot_capabilities;
 unsigned char prot_guard_type;


 unsigned long base;
 unsigned long io_port;
 unsigned char n_io_port;
 unsigned char dma_channel;
 unsigned int irq;


 enum scsi_host_state shost_state;


 struct device shost_gendev, shost_dev;





 void *shost_data;





 struct device *dma_dev;


 struct work_struct eh_work;


 int rpm_autosuspend_delay;






 unsigned long hostdata[1]
  ;
};
struct bsg_device;
struct device;
struct request_queue;
struct scsi_cmnd;
struct scsi_lun;
typedef __u64 blist_flags_t;
enum scsi_device_state {
 SDEV_CREATED = 1,

 SDEV_RUNNING,

 SDEV_CANCEL,

 SDEV_DEL,

 SDEV_QUIESCE,


 SDEV_OFFLINE,

 SDEV_TRANSPORT_OFFLINE,
 SDEV_BLOCK,



 SDEV_CREATED_BLOCK,
};
enum scsi_device_event {
 SDEV_EVT_MEDIA_CHANGE = 1,
 SDEV_EVT_INQUIRY_CHANGE_REPORTED,
 SDEV_EVT_CAPACITY_CHANGE_REPORTED,
 SDEV_EVT_SOFT_THRESHOLD_REACHED_REPORTED,
 SDEV_EVT_MODE_PARAMETER_CHANGE_REPORTED,
 SDEV_EVT_LUN_CHANGE_REPORTED,
 SDEV_EVT_ALUA_STATE_CHANGE_REPORTED,
 SDEV_EVT_POWER_ON_RESET_OCCURRED,

 SDEV_EVT_FIRST = SDEV_EVT_MEDIA_CHANGE,
 SDEV_EVT_LAST = SDEV_EVT_POWER_ON_RESET_OCCURRED,

 SDEV_EVT_MAXBITS = SDEV_EVT_LAST + 1
};
struct scsi_vpd {
 struct callback_head rcu;
 int len;
 unsigned char data[1];
};
struct scsi_device {
 struct Scsi_Host *host;
 struct request_queue *request_queue;


 struct list_head siblings;
 struct list_head same_target_siblings;

 struct sbitmap budget_map;
 atomic_t device_blocked;

 atomic_t restarts;
 spinlock_t list_lock;
 struct list_head starved_entry;
 unsigned short queue_depth;
 unsigned short max_queue_depth;
 unsigned short last_queue_full_depth;
 unsigned short last_queue_full_count;
 unsigned long last_queue_full_time;
 unsigned long queue_ramp_up_period;

 unsigned long last_queue_ramp_up;

 unsigned int id, channel;
 u64 lun;
 unsigned int manufacturer;

 unsigned sector_size;

 void *hostdata;
 unsigned char type;
 char scsi_level;
 char inq_periph_qual;
 struct mutex inquiry_mutex;
 unsigned char inquiry_len;
 unsigned char * inquiry;
 const char * vendor;
 const char * model;
 const char * rev;

 struct scsi_vpd *vpd_pg0;
 struct scsi_vpd *vpd_pg83;
 struct scsi_vpd *vpd_pg80;
 struct scsi_vpd *vpd_pg89;
 struct scsi_vpd *vpd_pgb0;
 struct scsi_vpd *vpd_pgb1;
 struct scsi_vpd *vpd_pgb2;
 struct scsi_vpd *vpd_pgb7;

 struct scsi_target *sdev_target;

 blist_flags_t sdev_bflags;



 unsigned int eh_timeout;






 unsigned manage_system_start_stop:1;





 unsigned manage_runtime_start_stop:1;





 unsigned manage_shutdown:1;





 unsigned force_runtime_start_on_system_start:1;




 unsigned is_ata:1;

 unsigned removable:1;
 unsigned changed:1;
 unsigned busy:1;
 unsigned lockable:1;
 unsigned locked:1;
 unsigned borken:1;

 unsigned disconnect:1;
 unsigned soft_reset:1;
 unsigned sdtr:1;
 unsigned wdtr:1;
 unsigned ppr:1;
 unsigned tagged_supported:1;
 unsigned simple_tags:1;
 unsigned was_reset:1;

 unsigned expecting_cc_ua:1;

 unsigned use_10_for_rw:1;
 unsigned use_10_for_ms:1;
 unsigned set_dbd_for_ms:1;
 unsigned read_before_ms:1;
 unsigned no_report_opcodes:1;
 unsigned no_write_same:1;
 unsigned use_16_for_rw:1;
 unsigned use_16_for_sync:1;
 unsigned skip_ms_page_8:1;
 unsigned skip_ms_page_3f:1;
 unsigned skip_vpd_pages:1;
 unsigned try_vpd_pages:1;
 unsigned use_192_bytes_for_3f:1;
 unsigned no_start_on_add:1;
 unsigned allow_restart:1;
 unsigned start_stop_pwr_cond:1;
 unsigned no_uld_attach:1;
 unsigned select_no_atn:1;
 unsigned fix_capacity:1;
 unsigned guess_capacity:1;
 unsigned retry_hwerror:1;
 unsigned last_sector_bug:1;

 unsigned no_read_disc_info:1;
 unsigned no_read_capacity_16:1;
 unsigned try_rc_10_first:1;
 unsigned security_supported:1;
 unsigned is_visible:1;
 unsigned wce_default_on:1;
 unsigned no_dif:1;
 unsigned broken_fua:1;
 unsigned lun_in_cdb:1;
 unsigned unmap_limit_for_ws:1;
 unsigned rpm_autosuspend:1;

 unsigned ignore_media_change:1;
 unsigned silence_suspend:1;
 unsigned no_vpd_size:1;

 unsigned cdl_supported:1;
 unsigned cdl_enable:1;

 unsigned int queue_stopped;
 bool offline_already;

 atomic_t ua_new_media_ctr;
 atomic_t ua_por_ctr;

 atomic_t disk_events_disable_depth;

 unsigned long supported_events[(((SDEV_EVT_MAXBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long pending_events[(((SDEV_EVT_MAXBITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 struct list_head event_list;
 struct work_struct event_work;

 unsigned int max_device_blocked;

 atomic_t iorequest_cnt;
 atomic_t iodone_cnt;
 atomic_t ioerr_cnt;
 atomic_t iotmo_cnt;

 struct device sdev_gendev,
    sdev_dev;

 struct work_struct requeue_work;

 struct scsi_device_handler *handler;
 void *handler_data;

 size_t dma_drain_len;
 void *dma_drain_buf;

 unsigned int sg_timeout;
 unsigned int sg_reserved_size;

 struct bsg_device *bsg_dev;
 unsigned char access_state;
 struct mutex state_mutex;
 enum scsi_device_state sdev_state;
 struct task_struct *quiesced_by;
 unsigned long sdev_data[1];
} ;
enum scsi_target_state {
 STARGET_CREATED = 1,
 STARGET_RUNNING,
 STARGET_REMOVE,
 STARGET_CREATED_REMOVE,
 STARGET_DEL,
};
struct scsi_target {
 struct scsi_device *starget_sdev_user;
 struct list_head siblings;
 struct list_head devices;
 struct device dev;
 struct kref reap_ref;
 unsigned int channel;
 unsigned int id;

 unsigned int create:1;
 unsigned int single_lun:1;


 unsigned int pdt_1f_for_no_lun:1;

 unsigned int no_report_luns:1;

 unsigned int expecting_lun_change:1;



 atomic_t target_busy;
 atomic_t target_blocked;





 unsigned int can_queue;
 unsigned int max_target_blocked;

 char scsi_level;
 enum scsi_target_state state;
 void *hostdata;
 unsigned long starget_data[1];

} ;
static inline    struct scsi_target *scsi_target(struct scsi_device *sdev)
;
struct Scsi_Host;
struct scsi_data_buffer {
 struct sg_table table;
 unsigned length;
};
enum scsi_cmnd_submitter {
 SUBMITTED_BY_BLOCK_LAYER = 0,
 SUBMITTED_BY_SCSI_ERROR_HANDLER = 1,
 SUBMITTED_BY_SCSI_RESET_IOCTL = 2,
} __attribute__((__packed__));
struct scsi_cmnd {
 struct scsi_device *device;
 struct list_head eh_entry;
 struct delayed_work abort_work;

 struct callback_head rcu;

 int eh_eflags;

 int budget_token;






 unsigned long jiffies_at_alloc;

 int retries;
 int allowed;

 unsigned char prot_op;
 unsigned char prot_type;
 unsigned char prot_flags;
 enum scsi_cmnd_submitter submitter;

 unsigned short cmd_len;
 enum dma_data_direction sc_data_direction;

 unsigned char cmnd[32];


 struct scsi_data_buffer sdb;
 struct scsi_data_buffer *prot_sdb;

 unsigned underflow;


 unsigned transfersize;




 unsigned resid_len;
 unsigned sense_len;
 unsigned char *sense_buffer;





 int flags;
 unsigned long state;

 unsigned int extra_len;






 unsigned char *host_scribble;







 int result;
};
struct firmware {
 size_t size;
 const u8 *data;


 void *priv;
};
struct module;
struct device;
struct btree_head {
 unsigned long *node;
 mempool_t *mempool;
 int height;
};
struct btree_head32 {
 struct btree_head h;
};
struct btree_head64 {
 struct btree_head h;
};
struct bsg_job;
struct request;
struct device;
struct scatterlist;
struct request_queue;
struct bsg_buffer {
 unsigned int payload_len;
 int sg_cnt;
 struct scatterlist *sg_list;
};
struct bsg_job {
 struct device *dev;

 struct kref kref;

 unsigned int timeout;


 void *request;
 void *reply;

 unsigned int request_len;
 unsigned int reply_len;
 struct bsg_buffer request_payload;
 struct bsg_buffer reply_payload;

 int result;
 unsigned int reply_payload_rcv_len;


 struct request *bidi_rq;
 struct bio *bidi_bio;

 void *dd_data;
};
struct bpf_prog;
struct net;
struct net_device;
struct net_device;
struct scatterlist;
struct pipe_inode_info;
struct iov_iter;
struct bpf_prog;
union bpf_attr;
struct poll_table_struct;
struct pipe_inode_info;
struct inode;
struct file;
struct net;
struct vm_area_struct;
struct page;
struct module;
struct iovec;
struct kvec;
struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};
enum bpf_cgroup_iter_order {
 BPF_CGROUP_ITER_ORDER_UNSPEC = 0,
 BPF_CGROUP_ITER_SELF_ONLY,
 BPF_CGROUP_ITER_DESCENDANTS_PRE,
 BPF_CGROUP_ITER_DESCENDANTS_POST,
 BPF_CGROUP_ITER_ANCESTORS_UP,
};
enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 __MAX_BPF_MAP_TYPE
};
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};
enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 __MAX_BPF_ATTACH_TYPE
};
enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};
union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64  excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64  key;
  union {
   __u64  value;
   __u64  next_key;
  };
  __u64 flags;
 };

 struct {
  __u64  in_batch;


  __u64  out_batch;
  __u64  keys;
  __u64  values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64  insns;
  __u64  license;
  __u32 log_level;
  __u32 log_size;
  __u64  log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64  func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64  line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64  fd_array;
  __u64  core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
  __u32 fd_array_cnt;



  __u64  signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64  pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64  data_in;
  __u64  data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64  ctx_in;
  __u64  ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64  info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64  prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64  prog_attach_flags;
  __u64  link_ids;
  __u64  link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64  cookie;
 } raw_tracepoint;

 struct {
  __u64  btf;
  __u64  btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64  buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64  iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64  syms;
    __u64  addrs;
    __u64  cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64  path;
    __u64  offsets;
    __u64  ref_ctr_offsets;
    __u64  cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64  stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

} ;
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};
struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64  tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64  target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64  addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64  cookies;
  } kprobe_multi;
  struct {
   __u64  path;
   __u64  offsets;
   __u64  ref_ctr_offsets;
   __u64  cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64  file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64  func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64  tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} ;
struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};
struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};
struct sock_filter {
 __u16 code;
 __u8 jt;
 __u8 jf;
 __u32 k;
};
struct cred;
struct module;
struct btf_type {
 __u32 name_off;
 __u32 info;







 union {
  __u32 size;
  __u32 type;
 };
};
struct btf_member {
 __u32 name_off;
 __u32 type;






 __u32 offset;
};
struct btf;
struct btf_member;
struct btf_type;
union bpf_attr;
struct bpf_prog;
struct bpf_verifier_log;
struct bpf_struct_ops;
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct u64_stats_sync {



};
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
static inline    u64 cgroup_id(const struct cgroup *cgrp)
;
void css_rstat_flush(struct cgroup_subsys_state *css);
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct qspinlock;
struct bpf_verifier_env;
struct bpf_verifier_log;
struct perf_event;
struct bpf_prog;
struct bpf_prog_aux;
struct bpf_map;
struct bpf_arena;
struct sock;
struct seq_file;
struct btf;
struct btf_type;
struct exception_table_entry;
struct seq_operations;
struct bpf_iter_aux_info;
struct bpf_local_storage;
struct bpf_local_storage_map;
struct kobject;
struct mem_cgroup;
struct module;
struct bpf_func_state;
struct ftrace_ops;
struct cgroup;
struct bpf_token;
struct user_namespace;
struct super_block;
struct inode;
typedef u64 (*bpf_callback_t)(u64, u64, u64, u64, u64);
typedef int (*bpf_iter_init_seq_priv_t)(void *private_data,
     struct bpf_iter_aux_info *aux);
typedef void (*bpf_iter_fini_seq_priv_t)(void *private_data);
struct bpf_iter_seq_info {
 const struct seq_operations *seq_ops;
 bpf_iter_init_seq_priv_t init_seq_private;
 bpf_iter_fini_seq_priv_t fini_seq_private;
 u32 seq_priv_size;
};
struct bpf_map_ops {

 int (*map_alloc_check)(union bpf_attr *attr);
 struct bpf_map *(*map_alloc)(union bpf_attr *attr);
 void (*map_release)(struct bpf_map *map, struct file *map_file);
 void (*map_free)(struct bpf_map *map);
 int (*map_get_next_key)(struct bpf_map *map, void *key, void *next_key);
 void (*map_release_uref)(struct bpf_map *map);
 void *(*map_lookup_elem_sys_only)(struct bpf_map *map, void *key);
 int (*map_lookup_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_lookup_and_delete_elem)(struct bpf_map *map, void *key,
       void *value, u64 flags);
 int (*map_lookup_and_delete_batch)(struct bpf_map *map,
        const union bpf_attr *attr,
        union bpf_attr *uattr);
 int (*map_update_batch)(struct bpf_map *map, struct file *map_file,
    const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_delete_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);


 void *(*map_lookup_elem)(struct bpf_map *map, void *key);
 long (*map_update_elem)(struct bpf_map *map, void *key, void *value, u64 flags);
 long (*map_delete_elem)(struct bpf_map *map, void *key);
 long (*map_push_elem)(struct bpf_map *map, void *value, u64 flags);
 long (*map_pop_elem)(struct bpf_map *map, void *value);
 long (*map_peek_elem)(struct bpf_map *map, void *value);
 void *(*map_lookup_percpu_elem)(struct bpf_map *map, void *key, u32 cpu);
 int (*map_get_hash)(struct bpf_map *map, u32 hash_buf_size, void *hash_buf);


 void *(*map_fd_get_ptr)(struct bpf_map *map, struct file *map_file,
    int fd);




 void (*map_fd_put_ptr)(struct bpf_map *map, void *ptr, bool need_defer);
 int (*map_gen_lookup)(struct bpf_map *map, struct bpf_insn *insn_buf);
 u32 (*map_fd_sys_lookup_elem)(void *ptr);
 void (*map_seq_show_elem)(struct bpf_map *map, void *key,
      struct seq_file *m);
 int (*map_check_btf)(const struct bpf_map *map,
        const struct btf *btf,
        const struct btf_type *key_type,
        const struct btf_type *value_type);


 int (*map_poke_track)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_untrack)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_run)(struct bpf_map *map, u32 key, struct bpf_prog *old,
        struct bpf_prog *new);


 int (*map_direct_value_addr)(const struct bpf_map *map,
         u64 *imm, u32 off);
 int (*map_direct_value_meta)(const struct bpf_map *map,
         u64 imm, u32 *off);
 int (*map_mmap)(struct bpf_map *map, struct vm_area_struct *vma);
 __poll_t (*map_poll)(struct bpf_map *map, struct file *filp,
        struct poll_table_struct *pts);
 unsigned long (*map_get_unmapped_area)(struct file *filep, unsigned long addr,
            unsigned long len, unsigned long pgoff,
            unsigned long flags);


 int (*map_local_storage_charge)(struct bpf_local_storage_map *smap,
     void *owner, u32 size);
 void (*map_local_storage_uncharge)(struct bpf_local_storage_map *smap,
        void *owner, u32 size);
 struct bpf_local_storage ** (*map_owner_storage_ptr)(void *owner);


 long (*map_redirect)(struct bpf_map *map, u64 key, u64 flags);
 bool (*map_meta_equal)(const struct bpf_map *meta0,
          const struct bpf_map *meta1);


 int (*map_set_for_each_callback_args)(struct bpf_verifier_env *env,
           struct bpf_func_state *caller,
           struct bpf_func_state *callee);
 long (*map_for_each_callback)(struct bpf_map *map,
         bpf_callback_t callback_fn,
         void *callback_ctx, u64 flags);

 u64 (*map_mem_usage)(const struct bpf_map *map);


 int *map_btf_id;


 const struct bpf_iter_seq_info *iter_seq_info;
};
enum btf_field_type {
 BPF_SPIN_LOCK = (1 << 0),
 BPF_TIMER = (1 << 1),
 BPF_KPTR_UNREF = (1 << 2),
 BPF_KPTR_REF = (1 << 3),
 BPF_KPTR_PERCPU = (1 << 4),
 BPF_KPTR = BPF_KPTR_UNREF | BPF_KPTR_REF | BPF_KPTR_PERCPU,
 BPF_LIST_HEAD = (1 << 5),
 BPF_LIST_NODE = (1 << 6),
 BPF_RB_ROOT = (1 << 7),
 BPF_RB_NODE = (1 << 8),
 BPF_GRAPH_NODE = BPF_RB_NODE | BPF_LIST_NODE,
 BPF_GRAPH_ROOT = BPF_RB_ROOT | BPF_LIST_HEAD,
 BPF_REFCOUNT = (1 << 9),
 BPF_WORKQUEUE = (1 << 10),
 BPF_UPTR = (1 << 11),
 BPF_RES_SPIN_LOCK = (1 << 12),
 BPF_TASK_WORK = (1 << 13),
};
enum bpf_cgroup_storage_type {
 BPF_CGROUP_STORAGE_SHARED,
 BPF_CGROUP_STORAGE_PERCPU,
 __BPF_CGROUP_STORAGE_MAX
};
typedef void (*btf_dtor_kfunc_t)(void *);
struct btf_field_kptr {
 struct btf *btf;
 struct module *module;



 btf_dtor_kfunc_t dtor;
 u32 btf_id;
};
struct btf_field_graph_root {
 struct btf *btf;
 u32 value_btf_id;
 u32 node_offset;
 struct btf_record *value_rec;
};
struct btf_field {
 u32 offset;
 u32 size;
 enum btf_field_type type;
 union {
  struct btf_field_kptr kptr;
  struct btf_field_graph_root graph_root;
 };
};
struct btf_record {
 u32 cnt;
 u32 field_mask;
 int spin_lock_off;
 int res_spin_lock_off;
 int timer_off;
 int wq_off;
 int refcount_off;
 int task_work_off;
 struct btf_field fields[1];
};
struct bpf_map_owner {
 enum bpf_prog_type type;
 bool jited;
 bool xdp_has_frags;
 u64 storage_cookie[__BPF_CGROUP_STORAGE_MAX];
 const struct btf_type *attach_func_proto;
 enum bpf_attach_type expected_attach_type;
};
struct bpf_map {
 u8 sha[32];
 u32 excl;
 const struct bpf_map_ops *ops;
 struct bpf_map *inner_map_meta;

 void *security;

 enum bpf_map_type map_type;
 u32 key_size;
 u32 value_size;
 u32 max_entries;
 u64 map_extra;
 u32 map_flags;
 u32 id;
 struct btf_record *record;
 int numa_node;
 u32 btf_key_type_id;
 u32 btf_value_type_id;
 u32 btf_vmlinux_value_type_id;
 struct btf *btf;

 struct obj_cgroup *objcg;

 char name[16U];
 struct mutex freeze_mutex;
 atomic64_t refcnt;
 atomic64_t usercnt;

 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 atomic64_t writecnt;
 spinlock_t owner_lock;
 struct bpf_map_owner *owner;
 bool bypass_spec_v1;
 bool frozen;
 bool free_after_mult_rcu_gp;
 bool free_after_rcu_gp;
 atomic64_t sleepable_refcnt;
 s64 *elem_count;
 u64 cookie;
 char *excl_prog_sha;
};
struct bpf_offload_dev;
enum bpf_type_flag {

 PTR_MAYBE_NULL = ((((1UL))) << (0 + 8)),




 MEM_RDONLY = ((((1UL))) << (1 + 8)),


 MEM_RINGBUF = ((((1UL))) << (2 + 8)),


 MEM_USER = ((((1UL))) << (3 + 8)),







 MEM_PERCPU = ((((1UL))) << (4 + 8)),


 OBJ_RELEASE = ((((1UL))) << (5 + 8)),







 PTR_UNTRUSTED = ((((1UL))) << (6 + 8)),


 MEM_UNINIT = ((((1UL))) << (7 + 8)),


 DYNPTR_TYPE_LOCAL = ((((1UL))) << (8 + 8)),


 DYNPTR_TYPE_RINGBUF = ((((1UL))) << (9 + 8)),


 MEM_FIXED_SIZE = ((((1UL))) << (10 + 8)),




 MEM_ALLOC = ((((1UL))) << (11 + 8)),
 PTR_TRUSTED = ((((1UL))) << (12 + 8)),


 MEM_RCU = ((((1UL))) << (13 + 8)),





 NON_OWN_REF = ((((1UL))) << (14 + 8)),


 DYNPTR_TYPE_SKB = ((((1UL))) << (15 + 8)),


 DYNPTR_TYPE_XDP = ((((1UL))) << (16 + 8)),




 MEM_ALIGNED = ((((1UL))) << (17 + 8)),






 MEM_WRITE = ((((1UL))) << (18 + 8)),


 DYNPTR_TYPE_SKB_META = ((((1UL))) << (19 + 8)),

 __BPF_TYPE_FLAG_MAX,
 __BPF_TYPE_LAST_FLAG = __BPF_TYPE_FLAG_MAX - 1,
};
enum bpf_arg_type {
 ARG_DONTCARE = 0,




 ARG_CONST_MAP_PTR,
 ARG_PTR_TO_MAP_KEY,
 ARG_PTR_TO_MAP_VALUE,




 ARG_PTR_TO_MEM,
 ARG_PTR_TO_ARENA,

 ARG_CONST_SIZE,
 ARG_CONST_SIZE_OR_ZERO,

 ARG_PTR_TO_CTX,
 ARG_ANYTHING,
 ARG_SCALAR,
 ARG_PTR_TO_SPIN_LOCK,
 ARG_PTR_TO_SOCK_COMMON,
 ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_BTF_ID,
 ARG_PTR_TO_RINGBUF_MEM,
 ARG_CONST_ALLOC_SIZE_OR_ZERO,
 ARG_PTR_TO_BTF_ID_SOCK_COMMON,
 ARG_PTR_TO_PERCPU_BTF_ID,
 ARG_PTR_TO_FUNC,
 ARG_PTR_TO_STACK,
 ARG_PTR_TO_CONST_STR,
 ARG_PTR_TO_TIMER,
 ARG_KPTR_XCHG_DEST,
 ARG_PTR_TO_DYNPTR,
 __BPF_ARG_TYPE_MAX,


 ARG_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MAP_VALUE,
 ARG_PTR_TO_MEM_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MEM,
 ARG_PTR_TO_CTX_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_CTX,
 ARG_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_STACK_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_STACK,
 ARG_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_BTF_ID,



 ARG_PTR_TO_UNINIT_MEM = MEM_UNINIT | MEM_WRITE | ARG_PTR_TO_MEM,

 ARG_PTR_TO_FIXED_SIZE_MEM = MEM_FIXED_SIZE | ARG_PTR_TO_MEM,




 __BPF_ARG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
enum bpf_return_type {
 RET_INTEGER,
 RET_VOID,
 RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_MEM,
 RET_PTR_TO_MEM_OR_BTF_ID,
 RET_PTR_TO_BTF_ID,
 __BPF_RET_TYPE_MAX,


 RET_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_RINGBUF_MEM_OR_NULL = PTR_MAYBE_NULL | MEM_RINGBUF | RET_PTR_TO_MEM,
 RET_PTR_TO_DYNPTR_MEM_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MEM,
 RET_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_BTF_ID,
 RET_PTR_TO_BTF_ID_TRUSTED = PTR_TRUSTED | RET_PTR_TO_BTF_ID,




 __BPF_RET_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_func_proto {
 u64 (*func)(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5);
 bool gpl_only;
 bool pkt_access;
 bool might_sleep;





 bool allow_fastcall;
 enum bpf_return_type ret_type;
 union {
  struct {
   enum bpf_arg_type arg1_type;
   enum bpf_arg_type arg2_type;
   enum bpf_arg_type arg3_type;
   enum bpf_arg_type arg4_type;
   enum bpf_arg_type arg5_type;
  };
  enum bpf_arg_type arg_type[5];
 };
 union {
  struct {
   u32 *arg1_btf_id;
   u32 *arg2_btf_id;
   u32 *arg3_btf_id;
   u32 *arg4_btf_id;
   u32 *arg5_btf_id;
  };
  u32 *arg_btf_id[5];
  struct {
   size_t arg1_size;
   size_t arg2_size;
   size_t arg3_size;
   size_t arg4_size;
   size_t arg5_size;
  };
  size_t arg_size[5];
 };
 int *ret_btf_id;
 bool (*allowed)(const struct bpf_prog *prog);
};
enum bpf_access_type {
 BPF_READ = 1,
 BPF_WRITE = 2
};
enum bpf_reg_type {
 NOT_INIT = 0,
 SCALAR_VALUE,
 PTR_TO_CTX,
 CONST_PTR_TO_MAP,
 PTR_TO_MAP_VALUE,
 PTR_TO_MAP_KEY,
 PTR_TO_STACK,
 PTR_TO_PACKET_META,
 PTR_TO_PACKET,
 PTR_TO_PACKET_END,
 PTR_TO_FLOW_KEYS,
 PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK,
 PTR_TO_TP_BUFFER,
 PTR_TO_XDP_SOCK,
 PTR_TO_BTF_ID,
 PTR_TO_MEM,
 PTR_TO_ARENA,
 PTR_TO_BUF,
 PTR_TO_FUNC,
 CONST_PTR_TO_DYNPTR,
 __BPF_REG_TYPE_MAX,


 PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | PTR_TO_MAP_VALUE,
 PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | PTR_TO_TCP_SOCK,




 PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | PTR_TO_BTF_ID,




 __BPF_REG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_insn_access_aux {
 enum bpf_reg_type reg_type;
 bool is_ldsx;
 union {
  int ctx_field_size;
  struct {
   struct btf *btf;
   u32 btf_id;
   u32 ref_obj_id;
  };
 };
 struct bpf_verifier_log *log;
 bool is_retval;
};
struct bpf_prog_ops {
 int (*test_run)(struct bpf_prog *prog, const union bpf_attr *kattr,
   union bpf_attr *uattr);
};
struct bpf_reg_state;
struct bpf_verifier_ops {

 const struct bpf_func_proto *
 (*get_func_proto)(enum bpf_func_id func_id,
     const struct bpf_prog *prog);




 bool (*is_valid_access)(int off, int size, enum bpf_access_type type,
    const struct bpf_prog *prog,
    struct bpf_insn_access_aux *info);
 int (*gen_prologue)(struct bpf_insn *insn, bool direct_write,
       const struct bpf_prog *prog);
 int (*gen_epilogue)(struct bpf_insn *insn, const struct bpf_prog *prog,
       s16 ctx_stack_off);
 int (*gen_ld_abs)(const struct bpf_insn *orig,
     struct bpf_insn *insn_buf);
 u32 (*convert_ctx_access)(enum bpf_access_type type,
      const struct bpf_insn *src,
      struct bpf_insn *dst,
      struct bpf_prog *prog, u32 *target_size);
 int (*btf_struct_access)(struct bpf_verifier_log *log,
     const struct bpf_reg_state *reg,
     int off, int size);
};
struct bpf_prog_offload {
 struct bpf_prog *prog;
 struct net_device *netdev;
 struct bpf_offload_dev *offdev;
 void *dev_priv;
 struct list_head offloads;
 bool dev_state;
 bool opt_failed;
 void *jited_image;
 u32 jited_len;
};
struct btf_func_model {
 u8 ret_size;
 u8 ret_flags;
 u8 nr_args;
 u8 arg_size[12];
 u8 arg_flags[12];
};
struct bpf_tramp_image;
struct bpf_ksym {
 unsigned long start;
 unsigned long end;
 char name[512];
 struct list_head lnode;
 struct latch_tree_node tnode;
 bool prog;
};
enum bpf_tramp_prog_type {
 BPF_TRAMP_FENTRY,
 BPF_TRAMP_FEXIT,
 BPF_TRAMP_MODIFY_RETURN,
 BPF_TRAMP_MAX,
 BPF_TRAMP_REPLACE,
};
struct bpf_tramp_image {
 void *image;
 int size;
 struct bpf_ksym ksym;
 struct percpu_ref pcref;
 void *ip_after_call;
 void *ip_epilogue;
 union {
  struct callback_head rcu;
  struct work_struct work;
 };
};
struct bpf_trampoline {

 struct hlist_node hlist;
 struct ftrace_ops *fops;

 struct mutex mutex;
 refcount_t refcnt;
 u32 flags;
 u64 key;
 struct {
  struct btf_func_model model;
  void *addr;
  bool ftrace_managed;
 } func;




 struct bpf_prog *extension_prog;

 struct hlist_head progs_hlist[BPF_TRAMP_MAX];

 int progs_cnt[BPF_TRAMP_MAX];

 struct bpf_tramp_image *cur_image;
};
struct bpf_func_info_aux {
 u16 linkage;
 bool unreliable;
 bool called : 1;
 bool verified : 1;
};
struct bpf_jit_poke_descriptor {
 void *tailcall_target;
 void *tailcall_bypass;
 void *bypass_addr;
 void *aux;
 union {
  struct {
   struct bpf_map *map;
   u32 key;
  } tail_call;
 };
 bool tailcall_target_stable;
 u8 adj_off;
 u16 reason;
 u32 insn_idx;
};
struct bpf_ctx_arg_aux {
 u32 offset;
 enum bpf_reg_type reg_type;
 struct btf *btf;
 u32 btf_id;
 u32 ref_obj_id;
 bool refcounted;
};
struct btf_mod_pair {
 struct btf *btf;
 struct module *module;
};
struct bpf_kfunc_desc_tab;
struct bpf_stream {
 atomic_t capacity;
 struct llist_head log;

 struct mutex lock;
 struct llist_node *backlog_head;
 struct llist_node *backlog_tail;
};
struct bpf_prog_aux {
 atomic64_t refcnt;
 u32 used_map_cnt;
 u32 used_btf_cnt;
 u32 max_ctx_offset;
 u32 max_pkt_offset;
 u32 max_tp_access;
 u32 stack_depth;
 u32 id;
 u32 func_cnt;
 u32 real_func_cnt;
 u32 func_idx;
 u32 attach_btf_id;
 u32 attach_st_ops_member_off;
 u32 ctx_arg_info_size;
 u32 max_rdonly_access;
 u32 max_rdwr_access;
 struct btf *attach_btf;
 struct bpf_ctx_arg_aux *ctx_arg_info;
 void *priv_stack_ptr;
 struct mutex dst_mutex;
 struct bpf_prog *dst_prog;
 struct bpf_trampoline *dst_trampoline;
 enum bpf_prog_type saved_dst_prog_type;
 enum bpf_attach_type saved_dst_attach_type;
 bool verifier_zext;
 bool dev_bound;
 bool offload_requested;
 bool attach_btf_trace;
 bool attach_tracing_prog;
 bool func_proto_unreliable;
 bool tail_call_reachable;
 bool xdp_has_frags;
 bool exception_cb;
 bool exception_boundary;
 bool is_extended;
 bool jits_use_priv_stack;
 bool priv_stack_requested;
 bool changes_pkt_data;
 bool might_sleep;
 bool kprobe_write_ctx;
 u64 prog_array_member_cnt;
 struct mutex ext_mutex;
 struct bpf_arena *arena;
 void (*recursion_detected)(struct bpf_prog *prog);

 const struct btf_type *attach_func_proto;

 const char *attach_func_name;
 struct bpf_prog **func;
 struct bpf_prog_aux *main_prog_aux;
 void *jit_data;
 struct bpf_jit_poke_descriptor *poke_tab;
 struct bpf_kfunc_desc_tab *kfunc_tab;
 struct bpf_kfunc_btf_tab *kfunc_btf_tab;
 u32 size_poke_tab;



 struct bpf_ksym ksym;
 const struct bpf_prog_ops *ops;
 const struct bpf_struct_ops *st_ops;
 struct bpf_map **used_maps;
 struct mutex used_maps_mutex;
 struct btf_mod_pair *used_btfs;
 struct bpf_prog *prog;
 struct user_struct *user;
 u64 load_time;
 u32 verified_insns;
 int cgroup_atype;
 struct bpf_map *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
 char name[16U];
 u64 (*bpf_exception_cb)(u64 cookie, u64 sp, u64 bp, u64, u64);

 void *security;

 struct bpf_token *token;
 struct bpf_prog_offload *offload;
 struct btf *btf;
 struct bpf_func_info *func_info;
 struct bpf_func_info_aux *func_info_aux;






 struct bpf_line_info *linfo;







 void **jited_linfo;
 u32 func_info_cnt;
 u32 nr_linfo;




 u32 linfo_idx;
 struct module *mod;
 u32 num_exentries;
 struct exception_table_entry *extable;
 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 struct bpf_stream stream[2];
};
struct bpf_prog {
 u16 pages;
 u16 jited:1,
    jit_requested:1,
    gpl_compatible:1,
    cb_access:1,
    dst_needed:1,
    blinding_requested:1,
    blinded:1,
    is_func:1,
    kprobe_override:1,
    has_callchain_buf:1,
    enforce_expected_attach_type:1,
    call_get_stack:1,
    call_get_func_ip:1,
    tstamp_type_access:1,
    sleepable:1;
 enum bpf_prog_type type;
 enum bpf_attach_type expected_attach_type;
 u32 len;
 u32 jited_len;
 union {
  u8 digest[32];
  u8 tag[8];
 };
 struct bpf_prog_stats *stats;
 int *active;
 unsigned int (*bpf_func)(const void *ctx,
         const struct bpf_insn *insn);
 struct bpf_prog_aux *aux;
 struct sock_fprog_kern *orig_prog;

 union {
  struct { struct { } __empty_insns; struct sock_filter insns[1]; };
  struct { struct { } __empty_insnsi; struct bpf_insn insnsi[1]; };
 };
};
struct bpf_link {
 atomic64_t refcnt;
 u32 id;
 enum bpf_link_type type;
 const struct bpf_link_ops *ops;
 struct bpf_prog *prog;

 u32 flags;
 enum bpf_attach_type attach_type;




 union {
  struct callback_head rcu;
  struct work_struct work;
 };




 bool sleepable;
};
struct bpf_link_ops {
 void (*release)(struct bpf_link *link);



 void (*dealloc)(struct bpf_link *link);






 void (*dealloc_deferred)(struct bpf_link *link);
 int (*detach)(struct bpf_link *link);
 int (*update_prog)(struct bpf_link *link, struct bpf_prog *new_prog,
      struct bpf_prog *old_prog);
 void (*show_fdinfo)(const struct bpf_link *link, struct seq_file *seq);
 int (*fill_link_info)(const struct bpf_link *link,
         struct bpf_link_info *info);
 int (*update_map)(struct bpf_link *link, struct bpf_map *new_map,
     struct bpf_map *old_map);
 __poll_t (*poll)(struct file *file, struct poll_table_struct *pts);
};
struct bpf_token {
 struct work_struct work;
 atomic64_t refcnt;
 struct user_namespace *userns;
 u64 allowed_cmds;
 u64 allowed_maps;
 u64 allowed_progs;
 u64 allowed_attachs;

 void *security;

};
struct btf_member;
struct bpf_struct_ops {
 const struct bpf_verifier_ops *verifier_ops;
 int (*init)(struct btf *btf);
 int (*check_member)(const struct btf_type *t,
       const struct btf_member *member,
       const struct bpf_prog *prog);
 int (*init_member)(const struct btf_type *t,
      const struct btf_member *member,
      void *kdata, const void *udata);
 int (*reg)(void *kdata, struct bpf_link *link);
 void (*unreg)(void *kdata, struct bpf_link *link);
 int (*update)(void *kdata, void *old_kdata, struct bpf_link *link);
 int (*validate)(void *kdata);
 void *cfi_stubs;
 struct module *owner;
 const char *name;
 struct btf_func_model func_models[64];
};
struct bpf_prog_array_item {
 struct bpf_prog *prog;
 union {
  struct bpf_cgroup_storage *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
  u64 bpf_cookie;
 };
};
struct bpf_prog_array {
 struct callback_head rcu;
 struct bpf_prog_array_item items[1];
};
struct bpf_run_ctx {};
enum bpf_iter_task_type {
 BPF_TASK_ITER_ALL = 0,
 BPF_TASK_ITER_TID,
 BPF_TASK_ITER_TGID,
};
struct bpf_iter_aux_info {

 struct bpf_map *map;


 struct {
  struct cgroup *start;
  enum bpf_cgroup_iter_order order;
 } cgroup;
 struct {
  enum bpf_iter_task_type type;
  u32 pid;
 } task;
};
int map_set_for_each_callback_args(struct bpf_verifier_env *env,
       struct bpf_func_state *caller,
       struct bpf_func_state *callee);
int btf_struct_access(struct bpf_verifier_log *log,
        const struct bpf_reg_state *reg,
        int off, int size, enum bpf_access_type atype,
        u32 *next_btf_id, enum bpf_type_flag *flag, const char **field_name);
struct bpf_reg_state;
struct key;
struct cred;
struct rlimit;
struct kernel_siginfo;
struct audit_context;
struct super_block;
struct inode;
struct dentry;
struct file;
struct vfsmount;
struct path;
struct qstr;
struct iattr;
struct fown_struct;
struct file_operations;
struct kernfs_node;
struct mm_struct;
struct fs_context;
struct ctl_table;
struct user_namespace;
struct sock;
struct seq_file;
union bpf_attr;
struct bpf_map;
struct bpf_prog;
struct bpf_token;
struct perf_event;
struct sock;
struct net;
struct scsi_transport_template;
enum fc_port_type {
 FC_PORTTYPE_UNKNOWN,
 FC_PORTTYPE_OTHER,
 FC_PORTTYPE_NOTPRESENT,
 FC_PORTTYPE_NPORT,
 FC_PORTTYPE_NLPORT,
 FC_PORTTYPE_LPORT,
 FC_PORTTYPE_PTP,
 FC_PORTTYPE_NPIV,
};
enum fc_port_state {
 FC_PORTSTATE_UNKNOWN,
 FC_PORTSTATE_NOTPRESENT,
 FC_PORTSTATE_ONLINE,
 FC_PORTSTATE_OFFLINE,
 FC_PORTSTATE_BLOCKED,
 FC_PORTSTATE_BYPASSED,
 FC_PORTSTATE_DIAGNOSTICS,
 FC_PORTSTATE_LINKDOWN,
 FC_PORTSTATE_ERROR,
 FC_PORTSTATE_LOOPBACK,
 FC_PORTSTATE_DELETED,
 FC_PORTSTATE_MARGINAL,
};
enum fc_vport_state {
 FC_VPORT_UNKNOWN,
 FC_VPORT_ACTIVE,
 FC_VPORT_DISABLED,
 FC_VPORT_LINKDOWN,
 FC_VPORT_INITIALIZING,
 FC_VPORT_NO_FABRIC_SUPP,
 FC_VPORT_NO_FABRIC_RSCS,
 FC_VPORT_FABRIC_LOGOUT,
 FC_VPORT_FABRIC_REJ_WWN,
 FC_VPORT_FAILED,
};
struct fc_vport {





 enum fc_vport_state vport_state;
 enum fc_vport_state vport_last_state;
 u64 node_name;
 u64 port_name;
 u32 roles;
 u32 vport_id;
 enum fc_port_type vport_type;
 char symbolic_name[64];


 void *dd_data;


 struct Scsi_Host *shost;
 unsigned int channel;
 u32 number;
 u8 flags;
 struct list_head peers;
 struct device dev;
 struct work_struct vport_delete_work;
} ;
struct fc_fpin_stats {

 u64 dn;
 u64 dn_unknown;
 u64 dn_timeout;
 u64 dn_unable_to_route;
 u64 dn_device_specific;


 u64 li;
 u64 li_failure_unknown;
 u64 li_link_failure_count;
 u64 li_loss_of_sync_count;
 u64 li_loss_of_signals_count;
 u64 li_prim_seq_err_count;
 u64 li_invalid_tx_word_count;
 u64 li_invalid_crc_count;
 u64 li_device_specific;


 u64 cn;
 u64 cn_clear;
 u64 cn_lost_credit;
 u64 cn_credit_stall;
 u64 cn_oversubscription;
 u64 cn_device_specific;
};
struct fc_rport {

 u32 maxframe_size;
 u32 supported_classes;


 u32 dev_loss_tmo;
 struct fc_fpin_stats fpin_stats;


 u64 node_name;
 u64 port_name;
 u32 port_id;
 u32 roles;
 enum fc_port_state port_state;
 u32 scsi_target_id;
 u32 fast_io_fail_tmo;


 void *dd_data;


 unsigned int channel;
 u32 number;
 u8 flags;
 struct list_head peers;
 struct device dev;
  struct delayed_work dev_loss_work;
  struct work_struct scan_work;
  struct delayed_work fail_io_work;
  struct work_struct stgt_delete_work;
 struct work_struct rport_delete_work;
 struct request_queue *rqst_q;

 struct workqueue_struct *devloss_work_q;
} ;
struct fc_host_statistics {

 u64 seconds_since_last_reset;
 u64 tx_frames;
 u64 tx_words;
 u64 rx_frames;
 u64 rx_words;
 u64 lip_count;
 u64 nos_count;
 u64 error_frames;
 u64 dumped_frames;
 u64 link_failure_count;
 u64 loss_of_sync_count;
 u64 loss_of_signal_count;
 u64 prim_seq_protocol_err_count;
 u64 invalid_tx_word_count;
 u64 invalid_crc_count;


 u64 fcp_input_requests;
 u64 fcp_output_requests;
 u64 fcp_control_requests;
 u64 fcp_input_megabytes;
 u64 fcp_output_megabytes;
 u64 fcp_packet_alloc_failures;
 u64 fcp_packet_aborts;
 u64 fcp_frame_alloc_failures;


 u64 fc_no_free_exch;
 u64 fc_no_free_exch_xid;
 u64 fc_xid_not_found;
 u64 fc_xid_busy;
 u64 fc_seq_not_found;
 u64 fc_non_bls_resp;


 u64 cn_sig_warn;
 u64 cn_sig_alarm;
};
struct fc_els_ls_rjt {
 __u8 er_cmd;
 __u8 er_resv[4];
 __u8 er_reason;
 __u8 er_explan;
 __u8 er_vendor;
};
struct fc_els_csp {
 __u8 sp_hi_ver;
 __u8 sp_lo_ver;
 __be16 sp_bb_cred;
 __be16 sp_features;
 __be16 sp_bb_data;
 union {
  struct {
   __be16 _sp_tot_seq;
   __be16 _sp_rel_off;
  } sp_plogi;
  struct {
   __be32 _sp_r_a_tov;
  } sp_flogi_acc;
 } sp_u;
 __be32 sp_e_d_tov;
};
struct fc_els_cssp {
 __be16 cp_class;
 __be16 cp_init;
 __be16 cp_recip;
 __be16 cp_rdfs;
 __be16 cp_con_seq;
 __be16 cp_ee_cred;
 __u8 cp_resv1;
 __u8 cp_open_seq;
 __u8 _cp_resv2[2];
};
struct fc_els_flogi {
 __u8 fl_cmd;
 __u8 _fl_resvd[3];
 struct fc_els_csp fl_csp;
 __be64 fl_wwpn;
 __be64 fl_wwnn;
 struct fc_els_cssp fl_cssp[4];
 __u8 fl_vend[16];
} __attribute__((__packed__));
typedef struct {
 uint8_t domain;
 uint8_t area;
 uint8_t al_pa;
} be_id_t;
typedef struct {
 uint8_t al_pa;
 uint8_t area;
 uint8_t domain;
} le_id_t;
typedef union {
 uint32_t b24 : 24;
 struct {





  uint8_t al_pa;
  uint8_t area;
  uint8_t domain;



  uint8_t rsvd_1;
 } b;
} port_id_t;
struct app_id {
 int app_vid;
 uint8_t version;
 uint8_t pad[3];
 uint8_t reserved[28];
} __attribute__((__packed__));
struct app_stop {
 struct app_id app_info;
 uint8_t version;
 uint8_t pad[3];
 uint8_t reserved[28];
} __attribute__((__packed__));
struct qla_sa_update_frame {
 struct app_id app_info;
 uint16_t flags;



 uint16_t fast_sa_index:10,
   reserved:6;
 uint32_t salt;
 uint32_t spi;
 uint8_t sa_key[32];
 uint8_t node_name[8];
 uint8_t port_name[8];
 port_id_t port_id;
 uint8_t version;
 uint8_t pad[3];
 uint8_t reserved2[28];
} __attribute__((__packed__));
struct dsd32 {
 __le32 address;
 __le32 length;
};
struct dsd64 {
 __le64 address;
 __le32 length;
} __attribute__((__packed__));
struct qla82xx_legacy_intr_set {
 uint32_t int_vec_bit;
 uint32_t tgt_status_reg;
 uint32_t tgt_mask_reg;
 uint32_t pci_int_reg;
};
struct device_reg_82xx {
 __le32 req_q_out[64];
 __le32 rsp_q_in[64];
 __le32 rsp_q_out[64];

 __le16 mailbox_in[32];
 __le16 unused_1[32];
 __le32 hint;
 __le16 unused_2[62];
 __le16 mailbox_out[32];
 __le32 unused_3[48];

 __le32 host_status;
 __le32 host_int;
};
struct fcp_cmnd {
 struct scsi_lun lun;
 uint8_t crn;
 uint8_t task_attribute;
 uint8_t task_management;
 uint8_t additional_cdb_len;
 uint8_t cdb[256 + 4];
};
struct ct6_dsd {
 uint16_t fcp_cmnd_len;
 dma_addr_t fcp_cmnd_dma;
 struct fcp_cmnd *fcp_cmnd;
 int dsd_use_cnt;
 struct list_head dsd_list;
};
struct qla8044_reset_template_hdr {
 uint16_t version;
 uint16_t signature;
 uint16_t size;
 uint16_t entries;
 uint16_t hdr_size;
 uint16_t checksum;
 uint16_t init_seq_offset;
 uint16_t start_seq_offset;
} __attribute__((__packed__));
struct qla8044_reset_template {
 int seq_index;
 int seq_error;
 int array_index;
 uint32_t array[16];
 uint8_t *buff;
 uint8_t *stop_offset;
 uint8_t *start_offset;
 uint8_t *init_offset;
 struct qla8044_reset_template_hdr *hdr;
 uint8_t seq_end;
 uint8_t template_end;
};
enum nvmefc_fcp_datadir {
 NVMEFC_FCP_NODATA,
 NVMEFC_FCP_WRITE,
 NVMEFC_FCP_READ,
};
enum nvme_fc_obj_state {
 FC_OBJSTATE_UNKNOWN,
 FC_OBJSTATE_NOTPRESENT,
 FC_OBJSTATE_ONLINE,
 FC_OBJSTATE_OFFLINE,
 FC_OBJSTATE_BLOCKED,
 FC_OBJSTATE_BYPASSED,
 FC_OBJSTATE_DIAGNOSTICS,
 FC_OBJSTATE_LINKDOWN,
 FC_OBJSTATE_ERROR,
 FC_OBJSTATE_LOOPBACK,
 FC_OBJSTATE_DELETED,
};
struct nvme_fc_local_port {

 u32 port_num;
 u32 port_role;
 u64 node_name;
 u64 port_name;

 void *private;


 u32 port_id;
 enum nvme_fc_obj_state port_state;
} ;
struct nvme_fc_remote_port {

 u32 port_num;
 u32 port_role;
 u64 node_name;
 u64 port_name;
 struct nvme_fc_local_port *localport;
 void *private;
 u32 dev_loss_tmo;


 u32 port_id;
 enum nvme_fc_obj_state port_state;
} ;
struct scsi_qla_host;
struct qla_hw_data;
struct req_que;
struct srb;
struct fcnvme_ls_rqst_w0 {
 u8 ls_cmd;
 u8 zeros[3];
};
struct fcnvme_lsdesc_rqst {
 __be32 desc_tag;
 __be32 desc_len;
 struct fcnvme_ls_rqst_w0 w0;
 __be32 rsvd12;
};
struct fcnvme_lsdesc_rjt {
 __be32 desc_tag;
 __be32 desc_len;
 u8 rsvd8;





 u8 reason_code;
 u8 reason_explanation;

 u8 vendor;
 __be32 rsvd12;
};
struct fcnvme_ls_rjt {
 struct fcnvme_ls_rqst_w0 w0;
 __be32 desc_list_len;
 struct fcnvme_lsdesc_rqst rqst;
 struct fcnvme_lsdesc_rjt rjt;
};
struct get_name_list_extended {
 __le16 flags;
 u8 current_login_state;
 u8 last_login_state;
 u8 hard_address[3];
 u8 reserved_1;
 u8 port_id[3];
 u8 sequence_id;
 __le16 port_timer;
 __le16 nport_handle;
 __le16 receive_data_size;
 __le16 reserved_2;


 u8 prli_svc_param_word_0[2];
 u8 prli_svc_param_word_3[2];
 u8 port_name[8];
 u8 node_name[8];
};
struct device_reg_24xx {
 __le32 flash_addr;















 __le32 flash_data;

 __le32 ctrl_status;




 __le32 ictrl;

 __le32 istatus;

 __le32 unused_1[2];


 __le32 req_q_in;
 __le32 req_q_out;

 __le32 rsp_q_in;
 __le32 rsp_q_out;

 __le32 preq_q_in;
 __le32 preq_q_out;

 __le32 unused_2[2];


 __le32 atio_q_in;
 __le32 atio_q_out;

 __le32 host_status;

 __le32 hccr;











 __le32 gpiod;










 __le32 gpioe;




 __le32 iobase_addr;

 __le32 unused_3[10];

 __le16 mailbox0;
 __le16 mailbox1;
 __le16 mailbox2;
 __le16 mailbox3;
 __le16 mailbox4;
 __le16 mailbox5;
 __le16 mailbox6;
 __le16 mailbox7;
 __le16 mailbox8;
 __le16 mailbox9;
 __le16 mailbox10;
 __le16 mailbox11;
 __le16 mailbox12;
 __le16 mailbox13;
 __le16 mailbox14;
 __le16 mailbox15;
 __le16 mailbox16;
 __le16 mailbox17;
 __le16 mailbox18;
 __le16 mailbox19;
 __le16 mailbox20;
 __le16 mailbox21;
 __le16 mailbox22;
 __le16 mailbox23;
 __le16 mailbox24;
 __le16 mailbox25;
 __le16 mailbox26;
 __le16 mailbox27;
 __le16 mailbox28;
 __le16 mailbox29;
 __le16 mailbox30;
 __le16 mailbox31;

 __le32 iobase_window;
 __le32 iobase_c4;
 __le32 iobase_c8;
 __le32 unused_4_1[6];
 __le32 iobase_q;
 __le32 unused_5[2];
 __le32 iobase_select;
 __le32 unused_6[2];
 __le32 iobase_sdata;
};
struct qla_flt_region {
 __le16 code;
 uint8_t attribute;
 uint8_t reserved;
 __le32 size;
 __le32 start;
 __le32 end;
};
struct qla_flt_header {
 __le16 version;
 __le16 length;
 __le16 checksum;
 __le16 unused;
 struct qla_flt_region region[1];
};
struct qla_npiv_entry {
 __le16 flags;
 __le16 vf_id;
 uint8_t q_qos;
 uint8_t f_qos;
 __le16 unused1;
 uint8_t port_name[8];
 uint8_t node_name[8];
};
struct ex_init_cb_81xx {
 uint16_t ex_version;
 uint8_t prio_fcf_matching_flags;
 uint8_t reserved_1[3];
 uint16_t pri_fcf_vlan_id;
 uint8_t pri_fcf_fabric_name[8];
 uint16_t reserved_2[7];
 uint8_t spma_mac_addr[6];
 uint16_t reserved_3[14];
};
struct qla_fcp_prio_entry {
 uint16_t flags;

 uint8_t tag;
 uint8_t reserved;
 uint32_t src_pid;

 uint32_t dst_pid;

 uint16_t lun_beg;

 uint16_t lun_end;

 uint8_t src_wwpn[8];
 uint8_t dst_wwpn[8];
};
struct qla_fcp_prio_cfg {
 uint8_t signature[4];
 uint16_t version;
 uint16_t length;
 uint16_t checksum;
 uint16_t num_entries;
 uint16_t size_of_entry;
 uint8_t attributes;
 uint8_t reserved;
 struct qla_fcp_prio_entry entry[1023];
 uint8_t reserved2[16];
};
struct name_list_extended {
 struct get_name_list_extended *l;
 dma_addr_t ldma;
 struct list_head fcports;
 u32 size;
 u8 sent;
};
struct qla_nvme_fc_rjt {
 struct fcnvme_ls_rjt *c;
 dma_addr_t cdma;
 u16 size;
};
struct els_reject {
 struct fc_els_ls_rjt *c;
 dma_addr_t cdma;
 u16 size;
};
struct req_que;
struct qla_tgt_sess;
struct qla_buf_dsc {
 u16 tag;
 void *buf;
 dma_addr_t buf_dma;
};
struct srb_cmd {
 struct scsi_cmnd *cmd;
 uint32_t request_sense_length;
 uint32_t fw_sense_length;
 uint8_t *request_sense_ptr;
 struct crc_context *crc_ctx;
 struct ct6_dsd ct6_ctx;
 struct qla_buf_dsc buf_dsc;
};
struct els_logo_payload {
 uint8_t opcode;
 uint8_t rsvd[3];
 uint8_t s_id[3];
 uint8_t rsvd1[1];
 uint8_t wwpn[8];
};
struct els_plogi_payload {
 uint8_t opcode;
 uint8_t rsvd[3];
 __be32 data[112 / 4];
};
struct ct_arg {
 void *iocb;
 u16 nport_handle;
 dma_addr_t req_dma;
 dma_addr_t rsp_dma;
 u32 req_size;
 u32 rsp_size;
 u32 req_allocated_size;
 u32 rsp_allocated_size;
 void *req;
 void *rsp;
 port_id_t id;
};
struct srb_iocb {
 union {
  struct {
   uint16_t flags;
   uint16_t data[2];
   u32 iop[2];
  } logio;
  struct {
   uint32_t flags;
   uint32_t els_cmd;
   struct completion comp;
   struct els_logo_payload *els_logo_pyld;
   dma_addr_t els_logo_pyld_dma;
  } els_logo;
  struct els_plogi {
   uint32_t flags;
   uint32_t els_cmd;
   struct completion comp;
   struct els_plogi_payload *els_plogi_pyld;
   struct els_plogi_payload *els_resp_pyld;
   u32 tx_size;
   u32 rx_size;
   dma_addr_t els_plogi_pyld_dma;
   dma_addr_t els_resp_pyld_dma;
   __le32 fw_status[3];
   __le16 comp_status;
   __le16 len;
  } els_plogi;
  struct {





   uint64_t lun;
   uint32_t flags;
   uint32_t data;
   struct completion comp;
   __le16 comp_status;

   uint8_t modifier;
   uint8_t vp_index;
   uint16_t loop_id;
  } tmf;
  struct {
   uint8_t flags;
   uint32_t req_len;
   uint32_t rsp_len;
   void *req_addr;
   void *rsp_addr;
   dma_addr_t req_dma_handle;
   dma_addr_t rsp_dma_handle;
   __le32 adapter_id;
   __le32 adapter_id_hi;
   __le16 req_func_type;
   __le32 req_data;
   __le32 req_data_extra;
   __le32 result;
   __le32 seq_number;
   __le16 fw_flags;
   struct completion fxiocb_comp;
   __le32 reserved_0;
   uint8_t reserved_1;
  } fxiocb;
  struct {
   uint32_t cmd_hndl;
   __le16 comp_status;
   __le16 req_que_no;
   struct completion comp;
  } abt;
  struct ct_arg ctarg;
  struct {
   u16 in_mb[28];
   u16 out_mb[28];
   void *out, *in;
   dma_addr_t out_dma, in_dma;
   struct completion comp;
   int rc;
  } mbx;
  struct {
   struct imm_ntfy_from_isp *ntfy;
  } nack;
  struct {
   __le16 comp_status;
   __le16 rsp_pyld_len;
   uint8_t aen_op;
   void *desc;


   __le32 cmd_len;
   __le32 rsp_len;
   dma_addr_t cmd_dma;
   dma_addr_t rsp_dma;
   enum nvmefc_fcp_datadir dir;
   uint32_t dl;
   uint32_t timeout_sec;
   __le32 exchange_address;
   __le16 nport_handle;
   __le16 ox_id;
   struct list_head entry;
  } nvme;
  struct {
   u16 cmd;
   u16 vp_index;
  } ctrlvp;
  struct {
   struct edif_sa_ctl *sa_ctl;
   struct qla_sa_update_frame sa_frame;
  } sa_update;
 } u;

 struct timer_list timer;
 void (*timeout)(void *);
};
struct qla_els_pt_arg {
 u8 els_opcode;
 u8 vp_idx;
 __le16 nport_handle;
 u16 control_flags, ox_id;
 __le32 rx_xchg_address;
 port_id_t did, sid;
 u32 tx_len, tx_byte_count, rx_len, rx_byte_count;
 dma_addr_t tx_addr, rx_addr;

};
struct iocb_resource {
 u8 res_type;
 u8 exch_cnt;
 u16 iocb_cnt;
};
struct bsg_cmd {
 struct bsg_job *bsg_job;
 union {
  struct qla_els_pt_arg els_arg;
 } u;
};
typedef struct srb {




 uint8_t cmd_type;
 uint8_t pad[3];
 struct iocb_resource iores;
 struct kref cmd_kref;
 void *priv;
 struct fc_port *fcport;
 struct scsi_qla_host *vha;
 unsigned int start_timer:1;
 unsigned int abort:1;
 unsigned int aborted:1;
 unsigned int completed:1;
 unsigned int unsol_rsp:1;

 uint32_t handle;
 uint16_t flags;
 uint16_t type;
 const char *name;
 int iocbs;
 struct qla_qpair *qpair;
 struct srb *cmd_sp;
 struct list_head elem;
 u32 gen1;
 u32 gen2;
 int rc;
 int retry_count;
 struct completion *comp;
 union {
  struct srb_iocb iocb_cmd;
  struct bsg_job *bsg_job;
  struct srb_cmd scmd;
  struct bsg_cmd bsg_cmd;
 } u;
 struct {
  bool remapped;
  struct {
   dma_addr_t dma;
   void *buf;
   uint len;
  } req;
  struct {
   dma_addr_t dma;
   void *buf;
   uint len;
  } rsp;
 } remap;





 void (*done)(struct srb *sp, int res);

 void (*free)(struct srb *sp);




 void (*put_fn)(struct kref *kref);




 void (*async_done)(struct srb *sp, int res);
} srb_t;
struct device_reg_2xxx {
 __le16 flash_address;
 __le16 flash_data;
 __le16 unused_1[1];
 __le16 ctrl_status;

 __le16 ictrl;

 __le16 istatus;

 __le16 semaphore;
 __le16 nvram;


 union {
  struct {
   __le16 mailbox0;
   __le16 mailbox1;
   __le16 mailbox2;
   __le16 mailbox3;
   __le16 mailbox4;
   __le16 mailbox5;
   __le16 mailbox6;
   __le16 mailbox7;
   __le16 unused_2[59];
  } __attribute__((packed)) isp2100;
  struct {

   __le16 req_q_in;
   __le16 req_q_out;

   __le16 rsp_q_in;
   __le16 rsp_q_out;


   __le32 host_status;


   __le16 host_semaphore;
   __le16 unused_3[17];
   __le16 mailbox0;
   __le16 mailbox1;
   __le16 mailbox2;
   __le16 mailbox3;
   __le16 mailbox4;
   __le16 mailbox5;
   __le16 mailbox6;
   __le16 mailbox7;
   __le16 mailbox8;
   __le16 mailbox9;
   __le16 mailbox10;
   __le16 mailbox11;
   __le16 mailbox12;
   __le16 mailbox13;
   __le16 mailbox14;
   __le16 mailbox15;
   __le16 mailbox16;
   __le16 mailbox17;
   __le16 mailbox18;
   __le16 mailbox19;
   __le16 mailbox20;
   __le16 mailbox21;
   __le16 mailbox22;
   __le16 mailbox23;
   __le16 mailbox24;
   __le16 mailbox25;
   __le16 mailbox26;
   __le16 mailbox27;
   __le16 mailbox28;
   __le16 mailbox29;
   __le16 mailbox30;
   __le16 mailbox31;
   __le16 fb_cmd;
   __le16 unused_4[10];
  } __attribute__((packed)) isp2300;
 } u;

 __le16 fpm_diag_config;
 __le16 unused_5[0x4];
 __le16 risc_hw;
 __le16 unused_5_1;
 __le16 pcr;
 __le16 unused_6[0x5];
 __le16 mctr;
 __le16 unused_7[0x3];
 __le16 fb_cmd_2100;
 __le16 unused_8[0x3];
 __le16 hccr;


 __le16 unused_9[5];
 __le16 gpiod;
 __le16 gpioe;

 union {
  struct {
   __le16 unused_10[8];
   __le16 mailbox8;
   __le16 mailbox9;
   __le16 mailbox10;
   __le16 mailbox11;
   __le16 mailbox12;
   __le16 mailbox13;
   __le16 mailbox14;
   __le16 mailbox15;
   __le16 mailbox16;
   __le16 mailbox17;
   __le16 mailbox18;
   __le16 mailbox19;
   __le16 mailbox20;
   __le16 mailbox21;
   __le16 mailbox22;
   __le16 mailbox23;
  } __attribute__((packed)) isp2200;
 } u_end;
};
struct device_reg_25xxmq {
 __le32 req_q_in;
 __le32 req_q_out;
 __le32 rsp_q_in;
 __le32 rsp_q_out;
 __le32 atio_q_in;
 __le32 atio_q_out;
};
struct device_reg_fx00 {
 __le32 mailbox0;
 __le32 mailbox1;
 __le32 mailbox2;
 __le32 mailbox3;
 __le32 mailbox4;
 __le32 mailbox5;
 __le32 mailbox6;
 __le32 mailbox7;
 __le32 mailbox8;
 __le32 mailbox9;
 __le32 mailbox10;
 __le32 mailbox11;
 __le32 mailbox12;
 __le32 mailbox13;
 __le32 mailbox14;
 __le32 mailbox15;
 __le32 mailbox16;
 __le32 mailbox17;
 __le32 mailbox18;
 __le32 mailbox19;
 __le32 mailbox20;
 __le32 mailbox21;
 __le32 mailbox22;
 __le32 mailbox23;
 __le32 mailbox24;
 __le32 mailbox25;
 __le32 mailbox26;
 __le32 mailbox27;
 __le32 mailbox28;
 __le32 mailbox29;
 __le32 mailbox30;
 __le32 mailbox31;
 __le32 aenmailbox0;
 __le32 aenmailbox1;
 __le32 aenmailbox2;
 __le32 aenmailbox3;
 __le32 aenmailbox4;
 __le32 aenmailbox5;
 __le32 aenmailbox6;
 __le32 aenmailbox7;

 __le32 req_q_in;
 __le32 req_q_out;

 __le32 rsp_q_in;
 __le32 rsp_q_out;

 __le32 initval0;
 __le32 initval1;
 __le32 initval2;
 __le32 initval3;
 __le32 initval4;
 __le32 initval5;
 __le32 initval6;
 __le32 initval7;
 __le32 fwheartbeat;
 __le32 pseudoaen;
};
typedef union {
  struct device_reg_2xxx isp;
  struct device_reg_24xx isp24;
  struct device_reg_25xxmq isp25mq;
  struct device_reg_82xx isp82;
  struct device_reg_fx00 ispfx00;
} device_reg_t;
typedef struct {
 uint32_t out_mb;
 uint32_t in_mb;
 uint16_t mb[32];
 long buf_size;
 void *bufp;
 uint32_t tov;
 uint8_t flags;
} mbx_cmd_t;
struct mbx_cmd_32 {
 uint32_t out_mb;
 uint32_t in_mb;
 uint32_t mb[32];
 long buf_size;
 void *bufp;
 uint32_t tov;
 uint8_t flags;
};
typedef struct {
 uint8_t version;
 uint8_t reserved_1;
 uint8_t firmware_options[2];

 __le16 frame_payload_size;
 __le16 max_iocb_allocation;
 __le16 execution_throttle;
 uint8_t retry_count;
 uint8_t retry_delay;
 uint8_t port_name[8];
 uint16_t hard_address;
 uint8_t inquiry_data;
 uint8_t login_timeout;
 uint8_t node_name[8];

 __le16 request_q_outpointer;
 __le16 response_q_inpointer;
 __le16 request_q_length;
 __le16 response_q_length;
 __le64 request_q_address __attribute__((__packed__));
 __le64 response_q_address __attribute__((__packed__));

 __le16 lun_enables;
 uint8_t command_resource_count;
 uint8_t immediate_notify_resource_count;
 __le16 timeout;
 uint8_t reserved_2[2];
 uint8_t add_firmware_options[2];

 uint8_t response_accumulation_timer;
 uint8_t interrupt_delay_timer;
 uint8_t special_options[2];

 uint8_t reserved_3[26];
} init_cb_t;
struct init_sf_cb {
 uint8_t format;
 uint8_t reserved0;






 __le16 flags;
 uint8_t reserved1[32];
 uint16_t discard_OHRB_timeout_value;
 uint16_t remote_write_opt_queue_num;
 uint8_t reserved2[40];
 uint8_t scm_related_parameter[16];
 uint8_t reserved3[32];
};
typedef struct {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t sys_define;
 uint8_t entry_status;
 uint32_t handle;
 uint8_t data[52];
 uint32_t signature;
} response_t;
struct atio {
 uint8_t entry_type;
 uint8_t entry_count;
 __le16 attr_n_length;
 uint8_t data[56];
 uint32_t signature;
};
typedef union {
 __le16 extended;
 struct {
  uint8_t reserved;
  uint8_t standard;
 } id;
} target_id_t;
typedef struct {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t sys_define;
 uint8_t entry_status;
 uint32_t handle;
 target_id_t target;
 __le16 lun;
 __le16 control_flags;
 uint16_t reserved_1;
 __le16 timeout;
 __le16 dseg_count;
 uint8_t scsi_cdb[16];
 __le32 byte_count;
 union {
  struct dsd32 dsd32[3];
  struct dsd64 dsd64[2];
 };
} cmd_entry_t;
typedef struct {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t sys_define;
 uint8_t entry_status;
 uint32_t handle;
 target_id_t target;
 __le16 lun;
 __le16 control_flags;
 uint16_t reserved_1;
 __le16 timeout;
 __le16 dseg_count;
 uint8_t scsi_cdb[16];
 uint32_t byte_count;
 struct dsd64 dsd[2];
} cmd_a64_entry_t, request_t;
struct crc_context {
 uint32_t handle;
 __le32 ref_tag;
 __le16 app_tag;
 uint8_t ref_tag_mask[4];
 uint8_t app_tag_mask[2];
 __le16 guard_seed;
 __le16 prot_opts;
 __le16 blk_size;
 __le16 runt_blk_guard;

 __le32 byte_count;

 union {
  struct {
   uint32_t reserved_1;
   uint16_t reserved_2;
   uint16_t reserved_3;
   uint32_t reserved_4;
   struct dsd64 data_dsd[1];
   uint32_t reserved_5[2];
   uint32_t reserved_6;
  } nobundling;
  struct {
   __le32 dif_byte_count;

   uint16_t reserved_1;
   __le16 dseg_count;
   uint32_t reserved_2;
   struct dsd64 data_dsd[1];
   struct dsd64 dif_dsd;
  } bundling;
 } u;

 struct fcp_cmnd fcp_cmnd;
 dma_addr_t crc_ctx_dma;

 struct list_head dsd_list;


 struct list_head ldif_dsd_list;
 u8 no_ldif_dsd;

 struct list_head ldif_dma_hndl_list;
 u32 dif_bundl_len;
 u8 no_dif_bundl;

};
typedef struct {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t handle_count;
 uint8_t entry_status;
 uint32_t handle1;
 target_id_t loop_id;
 __le16 status;
 __le16 control_flags;
 uint16_t reserved2;
 __le16 timeout;
 __le16 cmd_dsd_count;
 __le16 total_dsd_count;
 uint8_t type;
 uint8_t r_ctl;
 __le16 rx_id;
 uint16_t reserved3;
 uint32_t handle2;
 __le32 rsp_bytecount;
 __le32 req_bytecount;
 struct dsd64 req_dsd;
 struct dsd64 rsp_dsd;
} ms_iocb_entry_t;
struct imm_ntfy_from_isp {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t sys_define;
 uint8_t entry_status;
 union {
  struct {
   __le32 sys_define_2;
   target_id_t target;
   __le16 lun;
   uint8_t target_id;
   uint8_t reserved_1;
   __le16 status_modifier;
   __le16 status;
   __le16 task_flags;
   __le16 seq_id;
   __le16 srr_rx_id;
   __le32 srr_rel_offs;
   __le16 srr_ui;
   __le16 srr_ox_id;
   uint8_t reserved_2[28];
  } isp2x;
  struct {
   uint32_t reserved;
   __le16 nport_handle;
   uint16_t reserved_2;
   __le16 flags;
   __le16 srr_rx_id;
   __le16 status;
   uint8_t status_subcode;
   uint8_t fw_handle;
   __le32 exchange_address;
   __le32 srr_rel_offs;
   __le16 srr_ui;
   __le16 srr_ox_id;
   union {
    struct {
     uint8_t node_name[8];
    } plogi;
    struct {

     __le16 wd3_lo;
     uint8_t resv0[6];
    } prli;
    struct {
     uint8_t port_id[3];
     uint8_t resv1;
     __le16 nport_handle;
     uint16_t resv2;
    } req_els;
   } u;
   uint8_t port_name[8];
   uint8_t resv3[3];
   uint8_t vp_index;
   uint32_t reserved_5;
   uint8_t port_id[3];
   uint8_t reserved_6;
  } isp24;
 } u;
 uint16_t reserved_7;
 __le16 ox_id;
} __attribute__((__packed__));
typedef enum {
 FCT_UNKNOWN,
 FCT_BROADCAST = 0x01,
 FCT_INITIATOR = 0x02,
 FCT_TARGET = 0x04,
 FCT_NVME_INITIATOR = 0x10,
 FCT_NVME_TARGET = 0x20,
 FCT_NVME_DISCOVERY = 0x40,
 FCT_NVME = 0xf0,
} fc_port_type_t;
enum qlt_plogi_link_t {
 QLT_PLOGI_LINK_SAME_WWN,
 QLT_PLOGI_LINK_CONFLICT,
 QLT_PLOGI_LINK_MAX
};
struct qlt_plogi_ack_t {
 struct list_head list;
 struct imm_ntfy_from_isp iocb;
 port_id_t id;
 int ref_count;
 void *fcport;
};
struct ct_sns_desc {
 struct ct_sns_pkt *ct_sns;
 dma_addr_t ct_sns_dma;
};
enum discovery_state {
 DSC_DELETED,
 DSC_GNL,
 DSC_LOGIN_PEND,
 DSC_LOGIN_FAILED,
 DSC_GPDB,
 DSC_UPD_FCPORT,
 DSC_LOGIN_COMPLETE,
 DSC_ADISC,
 DSC_DELETE_PEND,
 DSC_LOGIN_AUTH_PEND,
};
enum login_state {
 DSC_LS_LLIOCB_SENT = 2,
 DSC_LS_PLOGI_PEND,
 DSC_LS_PLOGI_COMP,
 DSC_LS_PRLI_PEND,
 DSC_LS_PRLI_COMP,
 DSC_LS_PORT_UNAVAIL,
 DSC_LS_PRLO_PEND = 9,
 DSC_LS_LOGO_PEND,
};
typedef struct fc_port {
 struct list_head list;
 struct scsi_qla_host *vha;
 struct list_head unsol_ctx_head;

 spinlock_t unsol_ctx_lock;

 unsigned int conf_compl_supported:1;
 unsigned int deleted:2;
 unsigned int free_pending:1;
 unsigned int local:1;
 unsigned int logout_on_delete:1;
 unsigned int logo_ack_needed:1;
 unsigned int keep_nport_handle:1;
 unsigned int send_els_logo:1;
 unsigned int login_pause:1;
 unsigned int login_succ:1;
 unsigned int query:1;
 unsigned int id_changed:1;
 unsigned int scan_needed:1;
 unsigned int n2n_flag:1;
 unsigned int explicit_logout:1;
 unsigned int prli_pend_timer:1;
 unsigned int do_prli_nvme:1;

 uint8_t nvme_flag;
 uint8_t node_name[8];
 uint8_t port_name[8];
 port_id_t d_id;
 uint16_t loop_id;
 uint16_t old_loop_id;

 struct completion nvme_del_done;
 uint32_t nvme_prli_service_param;

 uint32_t nvme_first_burst_size;

 struct fc_port *conflict;
 unsigned char logout_completed;
 int generation;

 struct se_session *se_sess;
 struct list_head sess_cmd_list;
 spinlock_t sess_cmd_lock;
 struct kref sess_kref;
 struct qla_tgt *tgt;
 unsigned long expires;
 struct work_struct free_work;
 struct work_struct reg_work;
 uint64_t jiffies_at_registration;
 unsigned long prli_expired;
 struct qlt_plogi_ack_t *plogi_link[QLT_PLOGI_LINK_MAX];

 uint16_t tgt_id;
 uint16_t old_tgt_id;
 uint16_t sec_since_registration;

 uint8_t fcp_prio;

 uint8_t fabric_port_name[8];
 uint16_t fp_speed;

 fc_port_type_t port_type;

 atomic_t state;
 uint32_t flags;

 int login_retry;

 struct fc_rport *rport;
 u32 supported_classes;

 uint8_t fc4_type;
 uint8_t fc4_features;
 uint8_t scan_state;

 unsigned long last_queue_full;
 unsigned long last_ramp_up;

 uint16_t port_id;

 struct nvme_fc_remote_port *nvme_remote_port;

 unsigned long retry_delay_timestamp;
 struct qla_tgt_sess *tgt_session;
 struct ct_sns_desc ct_desc;
 enum discovery_state disc_state;
 atomic_t shadow_disc_state;
 enum discovery_state next_disc_state;
 enum login_state fw_login_state;
 unsigned long dm_login_expire;
 unsigned long plogi_nack_done_deadline;

 u32 login_gen, last_login_gen;
 u32 rscn_gen, last_rscn_gen;
 u32 chip_reset;
 struct list_head gnl_entry;
 struct work_struct del_work;
 u8 iocb[64];
 u8 current_login_state;
 u8 last_login_state;
 u16 n2n_link_reset_cnt;
 u16 n2n_chip_reset;

 struct dentry *dfs_rport_dir;

 u64 tgt_short_link_down_cnt;
 u64 tgt_link_down_time;
 u64 dev_loss_tmo;



 struct {
  uint32_t enable:1;
  uint32_t app_stop:2;
  uint32_t aes_gmac:1;
  uint32_t app_sess_online:1;
  uint32_t tx_sa_set:1;
  uint32_t rx_sa_set:1;
  uint32_t tx_sa_pending:1;
  uint32_t rx_sa_pending:1;
  uint32_t tx_rekey_cnt;
  uint32_t rx_rekey_cnt;
  uint64_t tx_bytes;
  uint64_t rx_bytes;
  uint8_t sess_down_acked;
  uint8_t auth_state;
  uint16_t authok:1;
  uint16_t rekey_cnt;
  struct list_head edif_indx_list;
  spinlock_t indx_list_lock;

  struct list_head tx_sa_list;
  struct list_head rx_sa_list;
  spinlock_t sa_list_lock;
 } edif;
} fc_port_t;
struct mr_data_fx00 {
 uint8_t symbolic_name[64];
 uint8_t serial_num[32];
 uint8_t hw_version[16];
 uint8_t fw_version[16];
 uint8_t uboot_version[16];
 uint8_t fru_serial_num[32];
 fc_port_t fcport;



 uint8_t fw_hbt_en;
 uint8_t fw_hbt_cnt;
 uint8_t fw_hbt_miss_cnt;
 uint32_t old_fw_hbt_cnt;
 uint16_t fw_reset_timer_tick;
 uint8_t fw_reset_timer_exp;
 uint16_t fw_critemp_timer_tick;
 uint32_t old_aenmbx0_state;
 uint32_t critical_temperature;
 bool extended_io_enabled;
 bool host_info_resend;
 uint8_t hinfo_resend_timer_tick;
};
struct ct_fdmi_hba_attr {
 __be16 type;
 __be16 len;
 union {
  uint8_t node_name[8];
  uint8_t manufacturer[64];
  uint8_t serial_num[32];
  uint8_t model[16+1];
  uint8_t model_desc[80];
  uint8_t hw_version[32];
  uint8_t driver_version[32];
  uint8_t orom_version[16];
  uint8_t fw_version[32];
  uint8_t os_version[128];
  __be32 max_ct_len;

  uint8_t sym_name[256];
  __be32 vendor_specific_info;
  __be32 num_ports;
  uint8_t fabric_name[8];
  uint8_t bios_name[32];
  uint8_t vendor_identifier[8];
 } a;
};
struct ct_fdmi1_hba_attributes {
 __be32 count;
 struct ct_fdmi_hba_attr entry[10];
};
struct ct_fdmi2_hba_attributes {
 __be32 count;
 struct ct_fdmi_hba_attr entry[17];
};
struct ct_fdmi_port_attr {
 __be16 type;
 __be16 len;
 union {
  uint8_t fc4_types[32];
  __be32 sup_speed;
  __be32 cur_speed;
  __be32 max_frame_size;
  uint8_t os_dev_name[32];
  uint8_t host_name[256];

  uint8_t node_name[8];
  uint8_t port_name[8];
  uint8_t port_sym_name[128];
  __be32 port_type;
  __be32 port_supported_cos;
  uint8_t fabric_name[8];
  uint8_t port_fc4_type[32];
  __be32 port_state;
  __be32 num_ports;
  __be32 port_id;

  uint8_t smartsan_service[24];
  uint8_t smartsan_guid[16];
  uint8_t smartsan_version[24];
  uint8_t smartsan_prod_name[16];
  __be32 smartsan_port_info;
  __be32 smartsan_qos_support;
  __be32 smartsan_security_support;
 } a;
};
struct ct_fdmi2_port_attributes {
 __be32 count;
 struct ct_fdmi_port_attr entry[16];
};
struct ct_cmd_hdr {
 uint8_t revision;
 uint8_t in_id[3];
 uint8_t gs_type;
 uint8_t gs_subtype;
 uint8_t options;
 uint8_t reserved;
};
struct ct_sns_req {
 struct ct_cmd_hdr header;
 __be16 command;
 __be16 max_rsp_size;
 uint8_t fragment_id;
 uint8_t reserved[3];

 union {

  struct {
   uint8_t reserved;
   be_id_t port_id;
  } port_id;

  struct {
   uint8_t reserved;
   uint8_t domain;
   uint8_t area;
   uint8_t port_type;
  } gpn_ft;

  struct {
   uint8_t port_type;
   uint8_t domain;
   uint8_t area;
   uint8_t reserved;
  } gid_pt;

  struct {
   uint8_t reserved;
   be_id_t port_id;
   uint8_t fc4_types[32];
  } rft_id;

  struct {
   uint8_t reserved;
   be_id_t port_id;
   uint16_t reserved2;
   uint8_t fc4_feature;
   uint8_t fc4_type;
  } rff_id;

  struct {
   uint8_t reserved;
   be_id_t port_id;
   uint8_t node_name[8];
  } rnn_id;

  struct {
   uint8_t node_name[8];
   uint8_t name_len;
   uint8_t sym_node_name[255];
  } rsnn_nn;

  struct {
   uint8_t hba_identifier[8];
  } ghat;

  struct {
   uint8_t hba_identifier[8];
   __be32 entry_count;
   uint8_t port_name[8];
   struct ct_fdmi2_hba_attributes attrs;
  } rhba;

  struct {
   uint8_t hba_identifier[8];
   struct ct_fdmi1_hba_attributes attrs;
  } rhat;

  struct {
   uint8_t port_name[8];
   struct ct_fdmi2_port_attributes attrs;
  } rpa;

  struct {
   uint8_t hba_identifier[8];
   uint8_t port_name[8];
   struct ct_fdmi2_port_attributes attrs;
  } rprt;

  struct {
   uint8_t port_name[8];
  } dhba;

  struct {
   uint8_t port_name[8];
  } dhat;

  struct {
   uint8_t port_name[8];
  } dprt;

  struct {
   uint8_t port_name[8];
  } dpa;

  struct {
   uint8_t port_name[8];
  } gpsc;

  struct {
   uint8_t reserved;
   uint8_t port_id[3];
  } gff_id;

  struct {
   uint8_t port_name[8];
  } gid_pn;
 } req;
};
struct ct_rsp_hdr {
 struct ct_cmd_hdr header;
 __be16 response;
 uint16_t residual;
 uint8_t fragment_id;
 uint8_t reason_code;
 uint8_t explanation_code;
 uint8_t vendor_unique;
};
struct ct_sns_gid_pt_data {
 uint8_t control_byte;
 be_id_t port_id;
};
struct ct_sns_rsp {
 struct ct_rsp_hdr header;

 union {
  struct {
   uint8_t port_type;
   be_id_t port_id;
   uint8_t port_name[8];
   uint8_t sym_port_name_len;
   uint8_t sym_port_name[255];
   uint8_t node_name[8];
   uint8_t sym_node_name_len;
   uint8_t sym_node_name[255];
   uint8_t init_proc_assoc[8];
   uint8_t node_ip_addr[16];
   uint8_t class_of_service[4];
   uint8_t fc4_types[32];
   uint8_t ip_address[16];
   uint8_t fabric_port_name[8];
   uint8_t reserved;
   uint8_t hard_address[3];
  } ga_nxt;

  struct {

   struct ct_sns_gid_pt_data
       entries[2048];
  } gid_pt;

  struct {
   uint8_t port_name[8];
  } gpn_id;

  struct {
   uint8_t node_name[8];
  } gnn_id;

  struct {
   uint8_t fc4_types[32];
  } gft_id;

  struct {
   uint32_t entry_count;
   uint8_t port_name[8];
   struct ct_fdmi1_hba_attributes attrs;
  } ghat;

  struct {
   uint8_t port_name[8];
  } gfpn_id;

  struct {
   __be16 speeds;
   __be16 speed;
  } gpsc;

  struct {
   uint8_t fc4_features[128];
  } gff_id;
  struct {
   uint8_t reserved;
   uint8_t port_id[3];
  } gid_pn;
 } rsp;
};
struct ct_sns_pkt {
 union {
  struct ct_sns_req req;
  struct ct_sns_rsp rsp;
 } p;
};
enum scan_flags_t {
 SF_SCANNING = 0x1,
 SF_QUEUED = 0x2,
};
enum fc4type_t {
 FS_FC4TYPE_FCP = 0x1,
 FS_FC4TYPE_NVME = 0x2,
 FS_FCP_IS_N2N = 0x80,
};
struct fab_scan_rp {
 port_id_t id;
 enum fc4type_t fc4type;
 u8 port_name[8];
 u8 node_name[8];
};
enum scan_step {
 FAB_SCAN_START,
 FAB_SCAN_GPNFT_FCP,
 FAB_SCAN_GNNFT_FCP,
 FAB_SCAN_GPNFT_NVME,
 FAB_SCAN_GNNFT_NVME,
};
struct fab_scan {
 struct fab_scan_rp *l;
 u32 size;
 u32 rscn_gen_start;
 u32 rscn_gen_end;
 enum scan_step step;
 u16 scan_retry;
 enum scan_flags_t scan_flags;
 struct delayed_work scan_work;
};
struct sns_cmd_pkt {
 union {
  struct {
   __le16 buffer_length;
   __le16 reserved_1;
   __le64 buffer_address __attribute__((__packed__));
   __le16 subcommand_length;
   __le16 reserved_2;
   __le16 subcommand;
   __le16 size;
   uint32_t reserved_3;
   uint8_t param[36];
  } cmd;

  uint8_t rft_data[16];
  uint8_t rnn_data[16];
  uint8_t gan_data[(620 + 16)];
  uint8_t gid_data[(512 * 4 + 16)];
  uint8_t gpn_data[(8 + 16)];
  uint8_t gnn_data[(8 + 16)];
 } p;
};
struct fw_blob {
 char *name;
 uint32_t segs[4];
 const struct firmware *fw;
};
struct gid_list_info {
 uint8_t al_pa;
 uint8_t area;
 uint8_t domain;
 uint8_t loop_id_2100;
 __le16 loop_id;
 uint16_t reserved_1;
};
struct qla_hw_data;
struct rsp_que;
struct isp_operations {

 int (*pci_config) (struct scsi_qla_host *);
 int (*reset_chip)(struct scsi_qla_host *);
 int (*chip_diag) (struct scsi_qla_host *);
 void (*config_rings) (struct scsi_qla_host *);
 int (*reset_adapter)(struct scsi_qla_host *);
 int (*nvram_config) (struct scsi_qla_host *);
 void (*update_fw_options) (struct scsi_qla_host *);
 int (*load_risc) (struct scsi_qla_host *, uint32_t *);

 char * (*pci_info_str)(struct scsi_qla_host *, char *, size_t);
 char * (*fw_version_str)(struct scsi_qla_host *, char *, size_t);

 irq_handler_t intr_handler;
 void (*enable_intrs) (struct qla_hw_data *);
 void (*disable_intrs) (struct qla_hw_data *);

 int (*abort_command) (srb_t *);
 int (*target_reset) (struct fc_port *, uint64_t, int);
 int (*lun_reset) (struct fc_port *, uint64_t, int);
 int (*fabric_login) (struct scsi_qla_host *, uint16_t, uint8_t,
  uint8_t, uint8_t, uint16_t *, uint8_t);
 int (*fabric_logout) (struct scsi_qla_host *, uint16_t, uint8_t,
     uint8_t, uint8_t);

 uint16_t (*calc_req_entries) (uint16_t);
 void (*build_iocbs) (srb_t *, cmd_entry_t *, uint16_t);
 void *(*prep_ms_iocb) (struct scsi_qla_host *, struct ct_arg *);
 void *(*prep_ms_fdmi_iocb) (struct scsi_qla_host *, uint32_t,
     uint32_t);

 uint8_t *(*read_nvram)(struct scsi_qla_host *, void *,
  uint32_t, uint32_t);
 int (*write_nvram)(struct scsi_qla_host *, void *, uint32_t,
  uint32_t);

 void (*fw_dump)(struct scsi_qla_host *vha);
 void (*mpi_fw_dump)(struct scsi_qla_host *, int);


 int (*beacon_on) (struct scsi_qla_host *);
 int (*beacon_off) (struct scsi_qla_host *);

 void (*beacon_blink) (struct scsi_qla_host *);

 void *(*read_optrom)(struct scsi_qla_host *, void *,
  uint32_t, uint32_t);
 int (*write_optrom)(struct scsi_qla_host *, void *, uint32_t,
  uint32_t);

 int (*get_flash_version) (struct scsi_qla_host *, void *);
 int (*start_scsi) (srb_t *);
 int (*start_scsi_mq) (srb_t *);


 int (*abort_isp) (struct scsi_qla_host *);

 int (*iospace_config)(struct qla_hw_data *);
 int (*initialize_adapter)(struct scsi_qla_host *);
};
struct scsi_qla_host;
struct qla_msix_entry {
 int have_irq;
 int in_use;
 uint32_t vector;
 uint32_t vector_base0;
 uint16_t entry;
 char name[30];
 void *handle;
 int cpuid;
};
struct qla_chip_state_84xx {
 struct list_head list;
 struct kref kref;

 void *bus;
 spinlock_t access_lock;
 struct mutex fw_update_mutex;
 uint32_t fw_update;
 uint32_t op_fw_version;
 uint32_t op_fw_size;
 uint32_t op_fw_seq_size;
 uint32_t diag_fw_version;
 uint32_t gold_fw_version;
};
struct qla_dif_statistics {
 uint64_t dif_input_bytes;
 uint64_t dif_output_bytes;
 uint64_t dif_input_requests;
 uint64_t dif_output_requests;
 uint32_t dif_guard_err;
 uint32_t dif_ref_tag_err;
 uint32_t dif_app_tag_err;
};
struct qla_statistics {
 uint32_t total_isp_aborts;
 uint64_t input_bytes;
 uint64_t output_bytes;
 uint64_t input_requests;
 uint64_t output_requests;
 uint32_t control_requests;

 uint64_t jiffies_at_last_reset;
 uint32_t stat_max_pend_cmds;
 uint32_t stat_max_qfull_cmds_alloc;
 uint32_t stat_max_qfull_cmds_dropped;

 struct qla_dif_statistics qla_dif_stats;
};
struct bidi_statistics {
 unsigned long long io_count;
 unsigned long long transfer_bytes;
};
struct qla_tgt_counters {
 uint64_t qla_core_sbt_cmd;
 uint64_t core_qla_que_buf;
 uint64_t qla_core_ret_ctio;
 uint64_t core_qla_snd_status;
 uint64_t qla_core_ret_sta_ctio;
 uint64_t core_qla_free_cmd;
 uint64_t num_q_full_sent;
 uint64_t num_alloc_iocb_failed;
 uint64_t num_term_xchg_sent;
};
struct qla_counters {
 uint64_t input_bytes;
 uint64_t input_requests;
 uint64_t output_bytes;
 uint64_t output_requests;

};
struct qla_qpair;
struct rsp_que {
 dma_addr_t dma;
 response_t *ring;
 response_t *ring_ptr;
 __le32 *rsp_q_in;
 __le32 *rsp_q_out;
 uint16_t ring_index;
 uint16_t out_ptr;
 uint16_t *in_ptr;
 uint16_t length;
 uint16_t options;
 uint16_t rid;
 uint16_t id;
 uint16_t vp_idx;
 struct qla_hw_data *hw;
 struct qla_msix_entry *msix;
 struct req_que *req;
 srb_t *status_srb;
 struct qla_qpair *qpair;

 dma_addr_t dma_fx00;
 response_t *ring_fx00;
 uint16_t length_fx00;
 uint8_t rsp_pkt[(sizeof(request_t))];
};
struct req_que {
 dma_addr_t dma;
 request_t *ring;
 request_t *ring_ptr;
 __le32 *req_q_in;
 __le32 *req_q_out;
 uint16_t ring_index;
 uint16_t in_ptr;
 uint16_t *out_ptr;
 uint16_t cnt;
 uint16_t length;
 uint16_t options;
 uint16_t rid;
 uint16_t id;
 uint16_t qos;
 uint16_t vp_idx;
 struct rsp_que *rsp;
 srb_t **outstanding_cmds;
 uint32_t current_outstanding_cmd;
 uint16_t num_outstanding_cmds;
 int max_q_depth;

 dma_addr_t dma_fx00;
 request_t *ring_fx00;
 uint16_t length_fx00;
 uint8_t req_pkt[(sizeof(request_t))];
};
struct qla_fw_resources {
 u16 iocbs_total;
 u16 iocbs_limit;
 u16 iocbs_qp_limit;
 u16 iocbs_used;
 u16 exch_total;
 u16 exch_limit;
 u16 exch_used;
 u16 pad;
};
struct qla_fw_res {
 u16 iocb_total;
 u16 iocb_limit;
 atomic_t iocb_used;

 u16 exch_total;
 u16 exch_limit;
 atomic_t exch_used;
};
struct qla_buf_pool {
 u16 num_bufs;
 u16 num_active;
 u16 max_used;
 u16 num_alloc;
 u16 prev_max;
 u16 pad;
 uint32_t take_snapshot:1;
 unsigned long *buf_map;
 void **buf_array;
 dma_addr_t *dma_array;
};
struct qla_qpair {
 spinlock_t qp_lock;
 atomic_t ref_count;
 uint32_t lun_cnt;




 spinlock_t *qp_lock_ptr;
 struct scsi_qla_host *vha;
 u32 chip_reset;






 uint32_t online:1;

 uint32_t difdix_supported:1;
 uint32_t delete_in_progress:1;
 uint32_t fw_started:1;
 uint32_t enable_class_2:1;
 uint32_t enable_explicit_conf:1;
 uint32_t use_shadow_reg:1;
 uint32_t rcv_intr:1;

 uint16_t id;
 uint16_t vp_idx;

 uint16_t dsd_inuse;
 uint16_t dsd_avail;
 struct list_head dsd_list;

 mempool_t *srb_mempool;

 struct pci_dev *pdev;
 void (*reqq_start_iocbs)(struct qla_qpair *);


 struct req_que *req;
 struct rsp_que *rsp;
 struct atio_que *atio;
 struct qla_msix_entry *msix;
 struct qla_hw_data *hw;
 struct work_struct q_work;
 struct qla_counters counters;

 struct list_head qp_list_elem;
 struct list_head hints_list;

 uint16_t retry_term_cnt;
 __le32 retry_term_exchg_addr;
 uint64_t retry_term_jiff;
 struct qla_tgt_counters tgt_counters;
 uint16_t cpuid;
 bool cpu_mapped;
 struct qla_fw_resources fwres ;
 struct qla_buf_pool buf_pool;
 u32 cmd_cnt;
 u32 cmd_completion_cnt;
 u32 prev_completion_cnt;
};
struct qlfc_fw {
 void *fw_buf;
 dma_addr_t fw_dma;
 uint32_t len;
};
struct scsi_qlt_host {
 void *target_lport_ptr;
 struct mutex tgt_mutex;
 struct mutex tgt_host_action_mutex;
 struct qla_tgt *qla_tgt;
};
struct qlt_hw_data {

 uint32_t node_name_set:1;

 dma_addr_t atio_dma;
 struct atio *atio_ring;
 struct atio *atio_ring_ptr;
 uint16_t atio_ring_index;
 uint16_t atio_q_length;
 __le32 *atio_q_in;
 __le32 *atio_q_out;

 const struct qla_tgt_func_tmpl *tgt_ops;

 int saved_set;
 __le16 saved_exchange_count;
 __le32 saved_firmware_options_1;
 __le32 saved_firmware_options_2;
 __le32 saved_firmware_options_3;
 uint8_t saved_firmware_options[2];
 uint8_t saved_add_firmware_options[2];

 uint8_t tgt_node_name[8];

 struct dentry *dfs_tgt_sess;
 struct dentry *dfs_tgt_port_database;
 struct dentry *dfs_naqp;

 struct list_head q_full_list;
 uint32_t num_pend_cmds;
 uint32_t num_qfull_cmds_alloc;
 uint32_t num_qfull_cmds_dropped;
 spinlock_t q_full_lock;
 uint32_t leak_exchg_thresh_hold;
 spinlock_t sess_lock;
 int num_act_qpairs;
 spinlock_t atio_lock ;
};
struct qla_hw_data_stat {
 u32 num_fw_dump;
 u32 num_mpi_reset;
};
typedef enum {
 QLA_PCI_RESUME,
 QLA_PCI_ERR_DETECTED,
 QLA_PCI_MMIO_ENABLED,
 QLA_PCI_SLOT_RESET,
} pci_error_state_t;
struct qla_hw_data {
 struct pci_dev *pdev;

 mempool_t *srb_mempool;
 u8 port_name[8];

 volatile struct {
  uint32_t mbox_int :1;
  uint32_t mbox_busy :1;
  uint32_t disable_risc_code_load :1;
  uint32_t enable_64bit_addressing :1;
  uint32_t enable_lip_reset :1;
  uint32_t enable_target_reset :1;
  uint32_t enable_lip_full_login :1;
  uint32_t enable_led_scheme :1;

  uint32_t msi_enabled :1;
  uint32_t msix_enabled :1;
  uint32_t disable_serdes :1;
  uint32_t gpsc_supported :1;
  uint32_t npiv_supported :1;
  uint32_t pci_channel_io_perm_failure :1;
  uint32_t fce_enabled :1;
  uint32_t user_enabled_fce :1;
  uint32_t fce_dump_buf_alloced :1;
  uint32_t fac_supported :1;

  uint32_t chip_reset_done :1;
  uint32_t running_gold_fw :1;
  uint32_t eeh_busy :1;
  uint32_t disable_msix_handshake :1;
  uint32_t fcp_prio_enabled :1;
  uint32_t isp82xx_fw_hung:1;
  uint32_t nic_core_hung:1;

  uint32_t quiesce_owner:1;
  uint32_t nic_core_reset_hdlr_active:1;
  uint32_t nic_core_reset_owner:1;
  uint32_t isp82xx_no_md_cap:1;
  uint32_t host_shutting_down:1;
  uint32_t idc_compl_status:1;
  uint32_t mr_reset_hdlr_active:1;
  uint32_t mr_intr_valid:1;

  uint32_t dport_enabled:1;
  uint32_t fawwpn_enabled:1;
  uint32_t exlogins_enabled:1;
  uint32_t exchoffld_enabled:1;

  uint32_t lip_ae:1;
  uint32_t n2n_ae:1;
  uint32_t fw_started:1;
  uint32_t fw_init_done:1;

  uint32_t lr_detected:1;

  uint32_t rida_fmt2:1;
  uint32_t purge_mbox:1;
  uint32_t n2n_bigger:1;
  uint32_t secure_adapter:1;
  uint32_t secure_fw:1;

  uint32_t scm_supported_a:1;

  uint32_t scm_supported_f:1;

  uint32_t scm_enabled:1;
  uint32_t edif_hw:1;
  uint32_t edif_enabled:1;
  uint32_t n2n_fw_acc_sec:1;
  uint32_t plogi_template_valid:1;
  uint32_t port_isolated:1;
  uint32_t eeh_flush:2;
 } flags;

 uint16_t max_exchg;
 uint16_t lr_distance;
 spinlock_t hardware_lock ;
 int bars;
 int mem_only;
 device_reg_t *iobase;
 resource_size_t pio_address;

 dma_addr_t bar0_hdl;

 void *cregbase;
 dma_addr_t bar2_hdl;

 uint32_t rqstq_intr_code;
 uint32_t mbx_intr_code;
 uint32_t req_que_len;
 uint32_t rsp_que_len;
 uint32_t req_que_off;
 uint32_t rsp_que_off;
 unsigned long eeh_jif;


 device_reg_t *mqiobase;
 device_reg_t *msixbase;
 uint16_t msix_count;
 uint8_t mqenable;
 struct req_que **req_q_map;
 struct rsp_que **rsp_q_map;
 struct qla_qpair **queue_pair_map;
 struct qla_qpair **qp_cpu_map;
 unsigned long req_qid_map[(256 / 8) / sizeof(unsigned long)];
 unsigned long rsp_qid_map[(256 / 8) / sizeof(unsigned long)];
 unsigned long qpair_qid_map[(256 / 8)
  / sizeof(unsigned long)];
 uint8_t max_req_queues;
 uint8_t max_rsp_queues;
 uint8_t max_qpairs;
 uint8_t num_qpairs;
 struct qla_qpair *base_qpair;
 struct qla_npiv_entry *npiv_info;
 uint16_t nvram_npiv_size;

 uint16_t switch_cap;

 uint8_t port_no;
 uint8_t exch_starvation;


 uint8_t loop_down_abort_time;
 atomic_t loop_down_timer;
 uint8_t link_down_timeout;
 uint16_t max_loop_id;
 uint16_t max_fibre_devices;

 uint16_t fb_rev;
 uint16_t min_external_loopid;

 uint16_t link_data_rate;
 uint16_t set_data_rate;

 uint8_t current_topology;
 uint8_t prev_topology;

 uint8_t operating_mode;
 uint8_t interrupts_on;
 uint32_t isp_abort_cnt;

 uint32_t isp_type;

 uint32_t device_type;





































 uint8_t serial0;
 uint8_t serial1;
 uint8_t serial2;


 uint16_t nvram_size;
 uint16_t nvram_base;
 void *nvram;
 uint16_t vpd_size;
 uint16_t vpd_base;
 void *vpd;

 uint16_t loop_reset_delay;
 uint8_t retry_count;
 uint8_t login_timeout;
 uint16_t r_a_tov;
 int port_down_retry_count;
 uint8_t mbx_count;
 uint8_t aen_mbx_count;
 atomic_t num_pend_mbx_stage1;
 atomic_t num_pend_mbx_stage2;
 uint16_t frame_payload_size;

 uint32_t login_retry_count;

 ms_iocb_entry_t *ms_iocb;
 dma_addr_t ms_iocb_dma;
 struct ct_sns_pkt *ct_sns;
 dma_addr_t ct_sns_dma;

 struct sns_cmd_pkt *sns_cmd;
 dma_addr_t sns_cmd_dma;


 void *sfp_data;
 dma_addr_t sfp_data_dma;

 struct qla_flt_header *flt;
 dma_addr_t flt_dma;

 void *xgmac_data;
 dma_addr_t xgmac_data_dma;

 void *dcbx_tlv;
 dma_addr_t dcbx_tlv_dma;

 struct task_struct *dpc_thread;
 uint8_t dpc_active;

 dma_addr_t gid_list_dma;
 struct gid_list_info *gid_list;
 int gid_list_info_size;


 struct dma_pool *s_dma_pool;

 dma_addr_t init_cb_dma;
 init_cb_t *init_cb;
 int init_cb_size;
 dma_addr_t ex_init_cb_dma;
 struct ex_init_cb_81xx *ex_init_cb;
 dma_addr_t sf_init_cb_dma;
 struct init_sf_cb *sf_init_cb;

 void *scm_fpin_els_buff;
 uint64_t scm_fpin_els_buff_size;
 bool scm_fpin_valid;
 bool scm_fpin_payload_size;

 void *async_pd;
 dma_addr_t async_pd_dma;



 void *exlogin_buf;
 dma_addr_t exlogin_buf_dma;
 uint32_t exlogin_size;



 void *exchoffld_buf;
 dma_addr_t exchoffld_buf_dma;
 int exchoffld_size;
 int exchoffld_count;


 struct fc_els_flogi plogi_els_payld;

 void *swl;


 uint16_t mailbox_out[32];
 uint32_t mailbox_out32[32];
 uint32_t aenmb[8];

 mbx_cmd_t *mcp;
 struct mbx_cmd_32 *mcp32;

 unsigned long mbx_cmd_flags;

 struct mutex vport_lock;
 spinlock_t vport_slock;
 struct mutex mq_lock;
 struct completion mbx_cmd_comp;
 struct completion mbx_intr_comp;
 struct completion dcbx_comp;
 struct completion lb_portup_comp;


 int notify_dcbx_comp;
 int notify_lb_portup_comp;
 struct mutex selflogin_lock;


 uint16_t fw_major_version;
 uint16_t fw_minor_version;
 uint16_t fw_subminor_version;
 uint16_t fw_attributes;
 uint16_t fw_attributes_h;




 uint16_t fw_attributes_ext[2];
 uint32_t fw_memory_size;
 uint32_t fw_transfer_size;
 uint32_t fw_srisc_address;

 uint16_t orig_fw_tgt_xcb_count;
 uint16_t cur_fw_tgt_xcb_count;
 uint16_t orig_fw_xcb_count;
 uint16_t cur_fw_xcb_count;
 uint16_t orig_fw_iocb_count;
 uint16_t cur_fw_iocb_count;
 uint16_t fw_max_fcf_count;

 uint32_t fw_shared_ram_start;
 uint32_t fw_shared_ram_end;
 uint32_t fw_ddr_ram_start;
 uint32_t fw_ddr_ram_end;

 uint16_t fw_options[16];
 uint8_t fw_seriallink_options[4];
 __le16 fw_seriallink_options24[4];

 uint8_t serdes_version[3];
 uint8_t mpi_version[3];
 uint32_t mpi_capabilities;
 uint8_t phy_version[3];
 uint8_t pep_version[3];


 struct fwdt {
  void *template;
  ulong length;
  ulong dump_size;
 } fwdt[2];
 struct qla2xxx_fw_dump *fw_dump;
 uint32_t fw_dump_len;
 u32 fw_dump_alloc_len;
 bool fw_dumped;
 unsigned long fw_dump_cap_flags;
 int fw_dump_reading;
 void *mpi_fw_dump;
 u32 mpi_fw_dump_len;
 unsigned int mpi_fw_dump_reading:1;
 unsigned int mpi_fw_dumped:1;
 int prev_minidump_failed;
 dma_addr_t eft_dma;
 void *eft;

 dma_addr_t mctp_dump_dma;
 void *mctp_dump;
 int mctp_dumped;
 int mctp_dump_reading;
 uint32_t chain_offset;
 struct dentry *dfs_dir;
 struct dentry *dfs_fce;
 struct dentry *dfs_tgt_counters;
 struct dentry *dfs_fw_resource_cnt;

 dma_addr_t fce_dma;
 void *fce;
 uint32_t fce_bufs;
 uint16_t fce_mb[8];
 uint64_t fce_wr, fce_rd;
 struct mutex fce_mutex;

 uint32_t pci_attr;
 uint16_t chip_revision;

 uint16_t product_id[4];

 uint8_t model_number[16+1];
 char model_desc[80];
 uint8_t adapter_id[16+1];


 char *optrom_buffer;
 uint32_t optrom_size;
 int optrom_state;
 uint32_t optrom_region_start;
 uint32_t optrom_region_size;
 struct mutex optrom_mutex;


 uint8_t bios_revision[2];
 uint8_t efi_revision[2];
 uint8_t fcode_revision[16];
 uint32_t fw_revision[4];

 uint32_t gold_fw_version[4];


 uint32_t flash_conf_off;
 uint32_t flash_data_off;
 uint32_t nvram_conf_off;
 uint32_t nvram_data_off;

 uint32_t fdt_wrt_disable;
 uint32_t fdt_wrt_enable;
 uint32_t fdt_erase_cmd;
 uint32_t fdt_block_size;
 uint32_t fdt_unprotect_sec_cmd;
 uint32_t fdt_protect_sec_cmd;
 uint32_t fdt_wrt_sts_reg_cmd;

 struct {
  uint32_t flt_region_flt;
  uint32_t flt_region_fdt;
  uint32_t flt_region_boot;
  uint32_t flt_region_boot_sec;
  uint32_t flt_region_fw;
  uint32_t flt_region_fw_sec;
  uint32_t flt_region_vpd_nvram;
  uint32_t flt_region_vpd_nvram_sec;
  uint32_t flt_region_vpd;
  uint32_t flt_region_vpd_sec;
  uint32_t flt_region_nvram;
  uint32_t flt_region_nvram_sec;
  uint32_t flt_region_npiv_conf;
  uint32_t flt_region_gold_fw;
  uint32_t flt_region_fcp_prio;
  uint32_t flt_region_bootload;
  uint32_t flt_region_img_status_pri;
  uint32_t flt_region_img_status_sec;
  uint32_t flt_region_aux_img_status_pri;
  uint32_t flt_region_aux_img_status_sec;
 };
 uint8_t active_image;
 uint8_t active_tmf;


 uint16_t beacon_blink_led;
 uint8_t beacon_color_state;

 uint16_t zio_mode;
 uint16_t zio_timer;

 struct qla_msix_entry *msix_entries;

 struct list_head tmf_pending;
 struct list_head tmf_active;
 struct list_head vp_list;
 unsigned long vp_idx_map[(256 / 8) /
   sizeof(unsigned long)];
 uint16_t num_vhosts;
 uint16_t num_vsans;
 uint16_t max_npiv_vports;
 int cur_vport_count;

 struct qla_chip_state_84xx *cs84xx;
 struct isp_operations *isp_ops;
 struct workqueue_struct *wq;
 struct work_struct heartbeat_work;
 struct qlfc_fw fw_buf;
 unsigned long last_heartbeat_run_jiffies;


 struct qla_fcp_prio_cfg *fcp_prio_cfg;

 struct dma_pool *dl_dma_pool;

 struct dma_pool *fcp_cmnd_dma_pool;
 mempool_t *ctx_mempool;

 void *nx_pcibase;
 void *nxdb_rd_ptr;
 void *nxdb_wr_ptr;

 uint32_t crb_win;
 uint32_t curr_window;
 uint32_t ddr_mn_window;
 unsigned long mn_win_crb;
 unsigned long ms_win_crb;
 int qdr_sn_window;
 uint32_t fcoe_dev_init_timeout;
 uint32_t fcoe_reset_timeout;
 rwlock_t hw_lock;
 uint16_t portnum;
 int link_width;
 struct fw_blob *hablob;
 struct qla82xx_legacy_intr_set nx_legacy_intr;

 uint8_t fw_type;
 uint32_t file_prd_off;

 uint32_t md_template_size;
 void *md_tmplt_hdr;
 dma_addr_t md_tmplt_hdr_dma;
 void *md_dump;
 uint32_t md_dump_size;

 void *loop_id_map;


 uint32_t idc_audit_ts;
 uint32_t idc_extend_tmo;


 struct workqueue_struct *dpc_lp_wq;
 struct work_struct idc_aen;

 struct workqueue_struct *dpc_hp_wq;
 struct work_struct nic_core_reset;
 struct work_struct idc_state_handler;
 struct work_struct nic_core_unrecoverable;
 struct work_struct board_disable;

 struct mr_data_fx00 mr;
 uint32_t chip_reset;

 struct qlt_hw_data tgt;
 int allow_cna_fw_dump;
 uint32_t fw_ability_mask;
 uint16_t min_supported_speed;
 uint16_t max_supported_speed;


 struct dma_pool *dif_bundl_pool;
 struct {
  struct {
   struct list_head head;
   uint count;
  } good;
  struct {
   struct list_head head;
   uint count;
  } unusable;
 } pool;

 unsigned long long dif_bundle_crossed_pages;
 unsigned long long dif_bundle_reads;
 unsigned long long dif_bundle_writes;
 unsigned long long dif_bundle_kallocs;
 unsigned long long dif_bundle_dma_allocs;

 atomic_t nvme_active_aen_cnt;
 uint16_t nvme_last_rptd_aen;

 uint8_t fc4_type_priority;

 atomic_t zio_threshold;
 uint16_t last_zio_threshold;


 struct qla_hw_data_stat stat;
 pci_error_state_t pci_error_state;
 struct dma_pool *purex_dma_pool;
 struct btree_head32 host_map;

 void *edif_rx_sa_id_map;
 void *edif_tx_sa_id_map;
 spinlock_t sadb_fp_lock;

 struct list_head sadb_tx_index_list;
 struct list_head sadb_rx_index_list;
 spinlock_t sadb_lock;
 struct els_reject elsrej;
 u8 edif_post_stop_cnt_down;
 struct qla_vp_map *vp_map;
 struct qla_nvme_fc_rjt lsrjt;
 struct qla_fw_res fwres ;
};
struct purex_item {
 void *purls_context;
 struct list_head list;
 struct scsi_qla_host *vha;
 void (*process_item)(struct scsi_qla_host *vha,
        struct purex_item *pkt);
 atomic_t in_use;
 uint16_t size;
 struct {
  uint8_t iocb[64];
 } iocb;
};
struct edif_sa_ctl {
 struct list_head next;
 uint16_t del_index;
 uint16_t index;
 uint16_t slot;
 uint16_t flags;

 unsigned long state;
 struct fc_port *fcport;
 struct bsg_job *bsg_job;
 struct qla_sa_update_frame sa_frame;
};
enum enode_flags_t {
 ENODE_ACTIVE = 0x1,
};
struct pur_core {
 enum enode_flags_t enode_flags;
 spinlock_t pur_lock;
 struct list_head head;
};
enum db_flags_t {
 EDB_ACTIVE = 0x1,
};
struct edif_dbell {
 enum db_flags_t db_flags;
 spinlock_t db_lock;
 struct list_head head;
 struct bsg_job *dbell_bsg_job;
 unsigned long bsg_expire;
};
typedef struct scsi_qla_host {
 struct list_head list;
 struct list_head vp_fcports;
 struct list_head work_list;
 spinlock_t work_lock;
 struct work_struct iocb_work;


 struct Scsi_Host *host;
 unsigned long host_no;
 uint8_t host_str[16];

 volatile struct {
  uint32_t init_done :1;
  uint32_t online :1;
  uint32_t reset_active :1;

  uint32_t management_server_logged_in :1;
  uint32_t process_response_queue :1;
  uint32_t difdix_supported:1;
  uint32_t delete_progress:1;

  uint32_t fw_tgt_reported:1;
  uint32_t bbcr_enable:1;
  uint32_t qpairs_available:1;
  uint32_t qpairs_req_created:1;
  uint32_t qpairs_rsp_created:1;
  uint32_t nvme_enabled:1;
  uint32_t nvme_first_burst:1;
  uint32_t nvme2_enabled:1;
 } flags;

 atomic_t loop_state;

 unsigned long buf_expired;
 unsigned long relogin_jif;
 unsigned long dpc_flags;


 unsigned long pci_flags;

 uint32_t device_flags;


 uint16_t loop_id;
 uint16_t self_login_loop_id;


 fc_port_t bidir_fcport;




 port_id_t d_id;
 uint8_t marker_needed;
 uint16_t mgmt_svr_loop_id;




 uint8_t loop_down_abort_time;
 atomic_t loop_down_timer;
 uint8_t link_down_timeout;

 uint32_t timer_active;
 struct timer_list timer;

 uint8_t node_name[8];
 uint8_t port_name[8];
 uint8_t fabric_node_name[8];
 uint8_t fabric_port_name[8];

 struct nvme_fc_local_port *nvme_local_port;
 struct completion nvme_del_done;

 uint16_t fcoe_vlan_id;
 uint16_t fcoe_fcf_idx;
 uint8_t fcoe_vn_port_mac[6];


 struct list_head qla_cmd_list;
 struct list_head unknown_atio_list;
 spinlock_t cmd_list_lock;
 struct delayed_work unknown_atio_work;


 atomic_t generation_tick;
 atomic_t rscn_gen;

 int total_fcport_update_gen;

 struct list_head logo_list;

 struct list_head plogi_ack_list;

 struct list_head qp_list;

 uint32_t vp_abort_cnt;

 struct fc_vport *fc_vport;
 uint16_t vp_idx;
 struct qla_qpair *qpair;

 unsigned long vp_flags;
 atomic_t vp_state;

 uint16_t vp_err_state;
 uint16_t vp_prev_err_state;
 struct qla_hw_data *hw;
 struct scsi_qlt_host vha_tgt;
 struct req_que *req;
 int fw_heartbeat_counter;
 int seconds_since_last_heartbeat;
 struct fc_host_statistics fc_host_stat;
 struct qla_statistics qla_stats;
 struct bidi_statistics bidi_stats;
 atomic_t vref_count;
 struct qla8044_reset_template reset_tmplt;
 uint16_t bbcr;

 uint16_t u_ql2xexchoffld;
 uint16_t u_ql2xiniexchg;
 uint16_t qlini_mode;
 uint16_t ql2xexchoffld;
 uint16_t ql2xiniexchg;

 struct dentry *dfs_rport_root;

 struct purex_list {
  struct list_head head;
  spinlock_t lock;
 } purex_list;
 struct purex_item default_item;

 struct name_list_extended gnl;

 int fcport_count;
 wait_queue_head_t fcport_waitQ;
 wait_queue_head_t vref_waitq;
 uint8_t min_supported_speed;
 uint8_t n2n_node_name[8];
 uint8_t n2n_port_name[8];
 uint16_t n2n_id;
 __le16 dport_data[4];
 struct fab_scan scan;
 uint8_t scm_fabric_connection_flags;

 unsigned int irq_offset;

 u64 hw_err_cnt;
 u64 interface_err_cnt;
 u64 cmd_timeout_cnt;
 u64 reset_cmd_err_cnt;
 u64 link_down_time;
 u64 short_link_down_cnt;
 struct edif_dbell e_dbell;
 struct pur_core pur_cinfo;

 uint16_t dport_status;
} scsi_qla_host_t;
struct qla_vp_map {
 uint8_t idx;
 scsi_qla_host_t *vha;
};
struct fcp_hdr {
 uint8_t r_ctl;
 be_id_t d_id;
 uint8_t cs_ctl;
 be_id_t s_id;
 uint8_t type;
 uint8_t f_ctl[3];
 uint8_t seq_id;
 uint8_t df_ctl;
 uint16_t seq_cnt;
 __be16 ox_id;
 uint16_t rx_id;
 __le32 parameter;
};
struct fcp_hdr_le {
 le_id_t d_id;
 uint8_t r_ctl;
 le_id_t s_id;
 uint8_t cs_ctl;
 uint8_t f_ctl[3];
 uint8_t type;
 __le16 seq_cnt;
 uint8_t df_ctl;
 uint8_t seq_id;
 __le16 rx_id;
 __le16 ox_id;
 __le32 parameter;
};
struct atio7_fcp_cmnd {
 uint64_t lun;
 uint8_t cmnd_ref;
 uint8_t task_attr:3;
 uint8_t reserved:5;
 uint8_t task_mgmt_flags;
 uint8_t wrdata:1;
 uint8_t rddata:1;
 uint8_t add_cdb_len:6;
 uint8_t cdb[16];





 uint8_t add_cdb[4];

} __attribute__((__packed__));
struct atio_from_isp {
 union {
  struct {
   __le16 entry_hdr;
   uint8_t sys_define;
   uint8_t entry_status;
   __le32 sys_define_2;
   target_id_t target;
   __le16 rx_id;
   __le16 flags;
   __le16 status;
   uint8_t command_ref;
   uint8_t task_codes;
   uint8_t task_flags;
   uint8_t execution_codes;
   uint8_t cdb[16];
   __le32 data_length;
   __le16 lun;
   uint8_t initiator_port_name[8];
   __le16 reserved_32[6];
   __le16 ox_id;
  } isp2x;
  struct {
   __le16 entry_hdr;
   uint8_t fcp_cmnd_len_low;
   uint8_t fcp_cmnd_len_high:4;
   uint8_t attr:4;
   __le32 exchange_addr;
   struct fcp_hdr fcp_hdr;
   struct atio7_fcp_cmnd fcp_cmnd;
  } isp24;
  struct {
   uint8_t entry_type;
   uint8_t entry_count;
   __le16 attr_n_length;
   uint8_t data[56];
   __le32 signature;
  } raw;
 } u;
} __attribute__((__packed__));
struct abts_recv_from_24xx {
 uint8_t entry_type;
 uint8_t entry_count;
 uint8_t sys_define;
 uint8_t entry_status;
 uint8_t reserved_1[6];
 __le16 nport_handle;
 uint8_t reserved_2[2];
 uint8_t vp_index;
 uint8_t reserved_3:4;
 uint8_t sof_type:4;
 __le32 exchange_address;
 struct fcp_hdr_le fcp_hdr_le;
 uint8_t reserved_4[16];
 __le32 exchange_addr_to_abort;
} __attribute__((__packed__));
struct qla_tgt_mgmt_cmd;
struct fc_port;
struct qla_tgt_cmd;
struct qla_tgt_func_tmpl {
 struct qla_tgt_cmd *(*find_cmd_by_tag)(struct fc_port *, uint64_t);
 int (*handle_cmd)(struct scsi_qla_host *, struct qla_tgt_cmd *,
   unsigned char *, uint32_t, int, int, int);
 void (*handle_data)(struct qla_tgt_cmd *);
 int (*handle_tmr)(struct qla_tgt_mgmt_cmd *, u64, uint16_t,
   uint32_t);
 struct qla_tgt_cmd *(*get_cmd)(struct fc_port *);
 void (*rel_cmd)(struct qla_tgt_cmd *);
 void (*free_cmd)(struct qla_tgt_cmd *);
 void (*free_mcmd)(struct qla_tgt_mgmt_cmd *);
 void (*free_session)(struct fc_port *);

 int (*check_initiator_node_acl)(struct scsi_qla_host *, unsigned char *,
     struct fc_port *);
 void (*update_sess)(struct fc_port *, port_id_t, uint16_t, bool);
 struct fc_port *(*find_sess_by_loop_id)(struct scsi_qla_host *,
      const uint16_t);
 struct fc_port *(*find_sess_by_s_id)(struct scsi_qla_host *,
          const be_id_t);
 void (*clear_nacl_from_fcport_map)(struct fc_port *);
 void (*put_sess)(struct fc_port *);
 void (*shutdown_sess)(struct fc_port *);
 int (*get_dif_tags)(struct qla_tgt_cmd *cmd, uint16_t *pfw_prot_opts);
 int (*chk_dif_tags)(uint32_t tag);
 void (*add_target)(struct scsi_qla_host *);
 void (*remove_target)(struct scsi_qla_host *);
};
struct module;
struct configfs_item_operations;
struct configfs_group_operations;
struct configfs_attribute;
struct configfs_bin_attribute;
struct configfs_subsystem;
struct config_item {
 char *ci_name;
 char ci_namebuf[20];
 struct kref ci_kref;
 struct list_head ci_entry;
 struct config_item *ci_parent;
 struct config_group *ci_group;
 const struct config_item_type *ci_type;
 struct dentry *ci_dentry;
};
struct config_item_type {
 struct module *ct_owner;
 struct configfs_item_operations *ct_item_ops;
 struct configfs_group_operations *ct_group_ops;
 struct configfs_attribute **ct_attrs;
 struct configfs_bin_attribute **ct_bin_attrs;
};
struct config_group {
 struct config_item cg_item;
 struct list_head cg_children;
 struct configfs_subsystem *cg_subsys;
 struct list_head default_groups;
 struct list_head group_entry;
};
struct configfs_attribute {
 const char *ca_name;
 struct module *ca_owner;
 umode_t ca_mode;
 ssize_t (*show)(struct config_item *, char *);
 ssize_t (*store)(struct config_item *, const char *, size_t);
};
struct file;
struct vm_area_struct;
struct configfs_bin_attribute {
 struct configfs_attribute cb_attr;
 void *cb_private;
 size_t cb_max_size;
 ssize_t (*read)(struct config_item *, void *, size_t);
 ssize_t (*write)(struct config_item *, const void *, size_t);
};
struct configfs_item_operations {
 void (*release)(struct config_item *);
 int (*allow_link)(struct config_item *src, struct config_item *target);
 void (*drop_link)(struct config_item *src, struct config_item *target);
};
struct configfs_group_operations {
 struct config_item *(*make_item)(struct config_group *group, const char *name);
 struct config_group *(*make_group)(struct config_group *group, const char *name);
 void (*disconnect_notify)(struct config_group *group, struct config_item *item);
 void (*drop_item)(struct config_group *group, struct config_item *item);
 bool (*is_visible)(struct config_item *item, struct configfs_attribute *attr, int n);
 bool (*is_bin_visible)(struct config_item *item, struct configfs_bin_attribute *attr,
          int n);
};
struct configfs_subsystem {
 struct config_group su_group;
 struct mutex su_mutex;
};
enum transport_state_table {
 TRANSPORT_NO_STATE = 0,
 TRANSPORT_NEW_CMD = 1,
 TRANSPORT_WRITE_PENDING = 3,
 TRANSPORT_PROCESSING = 5,
 TRANSPORT_COMPLETE = 6,
 TRANSPORT_ISTATE_PROCESSING = 11,
 TRANSPORT_COMPLETE_QF_WP = 18,
 TRANSPORT_COMPLETE_QF_OK = 19,
 TRANSPORT_COMPLETE_QF_ERR = 20,
};
typedef unsigned sense_reason_t;
struct se_cmd;
struct t10_alua {

 u16 alua_tg_pt_gps_counter;
 u32 alua_tg_pt_gps_count;

 spinlock_t lba_map_lock;
 u32 lba_map_segment_size;
 u32 lba_map_segment_multiplier;
 struct list_head lba_map_list;
 spinlock_t tg_pt_gps_lock;
 struct se_device *t10_dev;

 struct t10_alua_tg_pt_gp *default_tg_pt_gp;

 struct config_group alua_tg_pt_gps_group;
 struct list_head tg_pt_gps_list;
};
struct t10_alua_lu_gp {
 u16 lu_gp_id;
 int lu_gp_valid_id;
 u32 lu_gp_members;
 atomic_t lu_gp_ref_cnt;
 spinlock_t lu_gp_lock;
 struct config_group lu_gp_group;
 struct list_head lu_gp_node;
 struct list_head lu_gp_mem_list;
};
struct t10_alua_lu_gp_member {
 bool lu_gp_assoc;
 atomic_t lu_gp_mem_ref_cnt;
 spinlock_t lu_gp_mem_lock;
 struct t10_alua_lu_gp *lu_gp;
 struct se_device *lu_gp_mem_dev;
 struct list_head lu_gp_mem_list;
};
struct t10_alua_tg_pt_gp {
 u16 tg_pt_gp_id;
 int tg_pt_gp_valid_id;
 int tg_pt_gp_alua_supported_states;
 int tg_pt_gp_alua_access_status;
 int tg_pt_gp_alua_access_type;
 int tg_pt_gp_nonop_delay_msecs;
 int tg_pt_gp_trans_delay_msecs;
 int tg_pt_gp_implicit_trans_secs;
 int tg_pt_gp_pref;
 int tg_pt_gp_write_metadata;
 u32 tg_pt_gp_members;
 int tg_pt_gp_alua_access_state;
 atomic_t tg_pt_gp_ref_cnt;
 spinlock_t tg_pt_gp_lock;
 struct mutex tg_pt_gp_transition_mutex;
 struct se_device *tg_pt_gp_dev;
 struct config_group tg_pt_gp_group;
 struct list_head tg_pt_gp_list;
 struct list_head tg_pt_gp_lun_list;
 struct se_lun *tg_pt_gp_alua_lun;
 struct se_node_acl *tg_pt_gp_alua_nacl;
};
struct t10_wwn {




 char vendor[8 + 1];
 char model[16 + 1];
 char revision[4 + 1];
 char unit_serial[254];
 u32 company_id;
 spinlock_t t10_vpd_lock;
 struct se_device *t10_dev;
 struct config_group t10_wwn_group;
 struct list_head t10_vpd_list;
};
struct t10_pr_registration {


 char pr_reg_isid[16];

 unsigned char pr_iport[256];

 unsigned char pr_tport[256];
 u16 pr_aptpl_rpti;
 u16 pr_reg_tpgt;

 int pr_reg_all_tg_pt;

 int pr_reg_aptpl;
 int pr_res_holder;
 int pr_res_type;
 int pr_res_scope;

 bool isid_present_at_reg;
 u64 pr_res_mapped_lun;
 u64 pr_aptpl_target_lun;
 u16 tg_pt_sep_rtpi;
 u32 pr_res_generation;
 u64 pr_reg_bin_isid;
 u64 pr_res_key;
 atomic_t pr_res_holders;
 struct se_node_acl *pr_reg_nacl;

 struct se_dev_entry *pr_reg_deve;
 struct list_head pr_reg_list;
 struct list_head pr_reg_abort_list;
 struct list_head pr_reg_aptpl_list;
 struct list_head pr_reg_atp_list;
 struct list_head pr_reg_atp_mem_list;
};
struct t10_reservation {

 int pr_all_tg_pt;


 int pr_aptpl_active;
 u32 pr_generation;
 spinlock_t registration_lock;
 spinlock_t aptpl_reg_lock;
 struct se_node_acl *pr_res_holder;
 struct list_head registration_list;
 struct list_head aptpl_reg_list;
};
struct se_tmr_req {

 u8 function;

 u8 response;
 int call_transport;

 u64 ref_task_tag;
 void *fabric_tmr_ptr;
 struct se_cmd *task_cmd;
 struct se_device *tmr_dev;
 struct list_head tmr_list;
};
enum target_prot_op {
 TARGET_PROT_NORMAL = 0,
 TARGET_PROT_DIN_INSERT = (1 << 0),
 TARGET_PROT_DOUT_INSERT = (1 << 1),
 TARGET_PROT_DIN_STRIP = (1 << 2),
 TARGET_PROT_DOUT_STRIP = (1 << 3),
 TARGET_PROT_DIN_PASS = (1 << 4),
 TARGET_PROT_DOUT_PASS = (1 << 5),
};
enum target_prot_type {
 TARGET_DIF_TYPE0_PROT,
 TARGET_DIF_TYPE1_PROT,
 TARGET_DIF_TYPE2_PROT,
 TARGET_DIF_TYPE3_PROT,
};
enum target_ua_intlck_ctrl {
 TARGET_UA_INTLCK_CTRL_CLEAR = 0,
 TARGET_UA_INTLCK_CTRL_NO_CLEAR = 1,
 TARGET_UA_INTLCK_CTRL_ESTABLISH_UA = 2,
};
struct se_cmd {

 sense_reason_t sense_reason;

 u8 scsi_status;
 u16 scsi_sense_length;
 unsigned unknown_data_length:1;
 bool state_active:1;
 u64 tag;

 int alua_nonop_delay;

 enum dma_data_direction data_direction;

 int sam_task_attr;

 unsigned int map_tag;
 int map_cpu;

 enum transport_state_table t_state;

 u32 se_cmd_flags;

 u32 data_length;
 u32 residual_count;
 u64 orig_fe_lun;

 u64 pr_res_key;

 void *sense_buffer;
 struct list_head se_delayed_node;
 struct list_head se_qf_node;
 struct se_device *se_dev;
 struct se_lun *se_lun;

 struct se_session *se_sess;
 struct target_cmd_counter *cmd_cnt;
 struct se_tmr_req *se_tmr_req;
 struct llist_node se_cmd_list;
 struct completion *free_compl;
 struct completion *abrt_compl;
 const struct target_core_fabric_ops *se_tfo;
 sense_reason_t (*execute_cmd)(struct se_cmd *);
 sense_reason_t (*transport_complete_callback)(struct se_cmd *, bool, int *);
 void *protocol_data;

 unsigned char *t_task_cdb;
 unsigned char __t_task_cdb[32];
 unsigned long long t_task_lba;
 unsigned int t_task_nolb;
 unsigned int transport_state;
 spinlock_t t_state_lock;
 struct kref cmd_kref;
 struct completion t_transport_stop_comp;

 struct work_struct work;

 struct scatterlist *t_data_sg;
 struct scatterlist *t_data_sg_orig;
 unsigned int t_data_nents;
 unsigned int t_data_nents_orig;
 void *t_data_vmap;
 struct scatterlist *t_bidi_data_sg;
 unsigned int t_bidi_data_nents;


 int lun_ref_active;

 struct list_head state_list;


 void *priv;


 enum target_prot_op prot_op;
 enum target_prot_type prot_type;
 u8 prot_checks;
 bool prot_pto;
 u32 prot_length;
 u32 reftag_seed;
 struct scatterlist *t_prot_sg;
 unsigned int t_prot_nents;
 sense_reason_t pi_err;
 u64 sense_info;




 int cpuid;
};
struct se_node_acl {
 char initiatorname[224];

 bool dynamic_node_acl;
 bool dynamic_stop;
 u32 queue_depth;
 u32 acl_index;
 enum target_prot_type saved_prot_type;
 char acl_tag[64];

 atomic_t acl_pr_ref_count;
 struct hlist_head lun_entry_hlist;
 struct se_session *nacl_sess;
 struct se_portal_group *se_tpg;
 struct mutex lun_entry_mutex;
 spinlock_t nacl_sess_lock;
 struct config_group acl_group;
 struct config_group acl_attrib_group;
 struct config_group acl_auth_group;
 struct config_group acl_param_group;
 struct config_group acl_fabric_stat_group;
 struct list_head acl_list;
 struct list_head acl_sess_list;
 struct completion acl_free_comp;
 struct kref acl_kref;
};
struct target_cmd_counter {
 struct percpu_ref refcnt;
 wait_queue_head_t refcnt_wq;
 struct completion stop_done;
 atomic_t stopped;
};
struct se_session {
 u64 sess_bin_isid;
 enum target_prot_op sup_prot_ops;
 enum target_prot_type sess_prot_type;
 struct se_node_acl *se_node_acl;
 struct se_portal_group *se_tpg;
 void *fabric_sess_ptr;
 struct list_head sess_list;
 struct list_head sess_acl_list;
 spinlock_t sess_cmd_lock;
 void *sess_cmd_map;
 struct sbitmap_queue sess_tag_pool;
 struct target_cmd_counter *cmd_cnt;
};
struct se_device;
struct scatterlist;
struct se_ml_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_auth_intr_group;
 struct config_group scsi_att_intr_port_group;
};
struct se_lun_acl {
 u64 mapped_lun;
 struct se_node_acl *se_lun_nacl;
 struct se_lun *se_lun;
 struct config_group se_lun_group;
 struct se_ml_stat_grps ml_stat_grps;
};
struct se_dev_entry_io_stats {
 u64 total_cmds;
 u64 read_bytes;
 u64 write_bytes;
};
struct se_dev_entry {
 u64 mapped_lun;
 u64 pr_res_key;
 u64 creation_time;
 bool lun_access_ro;
 u32 attach_count;
 struct se_dev_entry_io_stats *stats;

 struct kref pr_kref;
 struct completion pr_comp;
 struct se_lun_acl *se_lun_acl;
 spinlock_t ua_lock;
 struct se_lun *se_lun;
 unsigned long deve_flags;
 struct list_head alua_port_list;
 struct list_head lun_link;
 struct list_head ua_list;
 struct hlist_node link;
 struct callback_head callback_head;
};
struct se_dev_attrib {
 bool emulate_model_alias;
 bool emulate_dpo;
 bool emulate_fua_write;
 bool emulate_fua_read;
 bool emulate_write_cache;
 enum target_ua_intlck_ctrl emulate_ua_intlck_ctrl;
 bool emulate_tas;
 bool emulate_tpu;
 bool emulate_tpws;
 bool emulate_caw;
 bool emulate_3pc;
 bool emulate_pr;
 bool emulate_rsoc;
 enum target_prot_type pi_prot_type;
 enum target_prot_type hw_pi_prot_type;
 bool pi_prot_verify;
 bool enforce_pr_isids;
 bool force_pr_aptpl;
 bool is_nonrot;
 bool emulate_rest_reord;
 bool unmap_zeroes_data;
 u32 hw_block_size;
 u32 block_size;
 u32 hw_max_sectors;
 u32 optimal_sectors;
 u32 hw_queue_depth;
 u32 queue_depth;
 u32 max_unmap_lba_count;
 u32 max_unmap_block_desc_count;
 u32 unmap_granularity;
 u32 unmap_granularity_alignment;
 u32 max_write_same_len;
 u8 submit_type;
 struct se_device *da_dev;
 struct config_group da_group;
};
struct se_port_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_port_group;
 struct config_group scsi_tgt_port_group;
 struct config_group scsi_transport_group;
};
struct scsi_port_stats {
 atomic_long_t cmd_pdus;
 atomic_long_t tx_data_octets;
 atomic_long_t rx_data_octets;
};
struct se_lun {
 u64 unpacked_lun;
 bool lun_shutdown;
 bool lun_access_ro;
 u32 lun_index;

 atomic_t lun_acl_count;
 struct se_device *lun_se_dev;

 struct list_head lun_deve_list;
 spinlock_t lun_deve_lock;


 int lun_tg_pt_secondary_stat;
 int lun_tg_pt_secondary_write_md;
 atomic_t lun_tg_pt_secondary_offline;
 struct mutex lun_tg_pt_md_mutex;


 struct list_head lun_tg_pt_gp_link;
 struct t10_alua_tg_pt_gp *lun_tg_pt_gp;
 spinlock_t lun_tg_pt_gp_lock;

 struct se_portal_group *lun_tpg;
 struct scsi_port_stats lun_stats;
 struct config_group lun_group;
 struct se_port_stat_grps port_stat_grps;
 struct completion lun_shutdown_comp;
 struct percpu_ref lun_ref;
 struct list_head lun_dev_link;
 struct hlist_node link;
 struct callback_head callback_head;
};
struct se_dev_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_dev_group;
 struct config_group scsi_tgt_dev_group;
 struct config_group scsi_lu_group;
};
struct se_cmd_queue {
 struct llist_head cmd_list;
 struct work_struct work;
};
struct se_device_queue {
 struct list_head state_list;
 spinlock_t lock;
 struct se_cmd_queue sq;
};
struct se_dev_io_stats {
 u64 total_cmds;
 u64 read_bytes;
 u64 write_bytes;
};
struct se_device {

 u32 dev_cur_ordered_id;
 u32 dev_flags;
 u8 transport_flags;

 u32 queue_depth;

 u64 dev_res_bin_isid;

 u32 dev_index;
 u64 creation_time;
 atomic_long_t num_resets;
 atomic_long_t aborts_complete;
 atomic_long_t aborts_no_task;
 struct se_dev_io_stats *stats;

 struct percpu_ref non_ordered;
 bool ordered_sync_in_progress;
 atomic_t dev_qf_count;
 u32 export_count;
 spinlock_t delayed_cmd_lock;
 spinlock_t dev_reservation_lock;
 unsigned int dev_reservation_flags;
 spinlock_t se_port_lock;
 spinlock_t se_tmr_lock;
 spinlock_t qf_cmd_lock;
 struct semaphore caw_sem;

 struct se_session *reservation_holder;

 struct t10_alua_lu_gp_member *dev_alua_lu_gp_mem;

 struct t10_pr_registration *dev_pr_res_holder;
 struct list_head dev_sep_list;
 struct list_head dev_tmr_list;
 struct work_struct qf_work_queue;
 struct work_struct delayed_cmd_work;
 struct list_head delayed_cmd_list;
 struct list_head qf_cmd_list;

 struct se_hba *se_hba;

 struct t10_wwn t10_wwn;

 struct t10_alua t10_alua;

 struct t10_reservation t10_pr;
 struct se_dev_attrib dev_attrib;
 struct config_group dev_action_group;
 struct config_group dev_group;
 struct config_group dev_pr_group;
 struct se_dev_stat_grps dev_stat_grps;
 unsigned char dev_alias[512];
 unsigned char udev_path[512];

 const struct target_backend_ops *transport;
 struct se_lun xcopy_lun;

 int prot_length;

 u32 hba_index;
 struct callback_head callback_head;
 int queue_cnt;
 struct se_device_queue *queues;
 struct mutex lun_reset_mutex;
};
struct se_hba {
 u16 hba_tpgt;
 u32 hba_id;

 u32 hba_flags;

 u32 dev_count;
 u32 hba_index;

 void *hba_ptr;
 struct list_head hba_node;
 spinlock_t device_lock;
 struct config_group hba_group;
 struct mutex hba_access_mutex;
 struct target_backend *backend;
};
struct se_portal_group {





 int proto_id;
 bool enabled;

 u16 tpg_rtpi;
 bool rtpi_manual;

 atomic_t tpg_pr_ref_count;

 struct mutex acl_node_mutex;

 spinlock_t session_lock;
 struct mutex tpg_lun_mutex;

 struct list_head acl_node_list;
 struct hlist_head tpg_lun_hlist;
 struct se_lun *tpg_virt_lun0;

 struct list_head tpg_sess_list;

 const struct target_core_fabric_ops *se_tpg_tfo;
 struct se_wwn *se_tpg_wwn;
 struct config_group tpg_group;
 struct config_group tpg_lun_group;
 struct config_group tpg_np_group;
 struct config_group tpg_acl_group;
 struct config_group tpg_attrib_group;
 struct config_group tpg_auth_group;
 struct config_group tpg_param_group;
};
struct se_wwn {
 struct target_fabric_configfs *wwn_tf;
 void *priv;
 struct config_group wwn_group;
 struct config_group fabric_stat_group;
 struct config_group param_group;
 int cmd_compl_affinity;
};
struct qla_qpair_hint {
 struct list_head hint_elem;
 struct qla_qpair *qpair;
 u16 cpuid;
 uint8_t cmd_cnt;
};
struct qla_tgt {
 struct scsi_qla_host *vha;
 struct qla_hw_data *ha;
 struct btree_head64 lun_qpair_map;
 struct qla_qpair_hint *qphints;





 int atio_irq_cmd_count;

 int sg_tablesize;


 unsigned int link_reinit_iocb_pending:1;





 int tgt_stop;
 int tgt_stopped;


 int sess_count;

 spinlock_t sess_work_lock;
 struct list_head sess_works_list;
 struct work_struct sess_work;

 struct imm_ntfy_from_isp link_reinit_iocb;
 wait_queue_head_t waitQ;
 int notify_ack_expected;
 int abts_resp_expected;
 int modify_lun_expected;
 atomic_t tgt_global_resets_count;
 struct list_head tgt_list_entry;
};
enum trace_flags {
 TRC_NEW_CMD = 0x1,
 TRC_DO_WORK = 0x2,
 TRC_DO_WORK_ERR = 0x4,
 TRC_XFR_RDY = 0x8,
 TRC_XMIT_DATA = 0x10,
 TRC_XMIT_STATUS = 0x20,
 TRC_SRR_RSP = 0x40,
 TRC_SRR_XRDY = 0x80,
 TRC_SRR_TERM = 0x100,
 TRC_SRR_CTIO = 0x200,
 TRC_FLUSH = 0x400,
 TRC_CTIO_ERR = 0x800,
 TRC_CTIO_DONE = 0x1000,
 TRC_CTIO_ABORTED = 0x2000,
 TRC_CTIO_STRANGE = 0x4000,
 TRC_CMD_DONE = 0x8000,
 TRC_CMD_CHK_STOP = 0x10000,
 TRC_CMD_FREE = 0x20000,
 TRC_DATA_IN = 0x40000,
 TRC_ABORT = 0x80000,
 TRC_DIF_ERR = 0x100000,
};
struct qla_tgt_cmd {



 uint8_t cmd_type;
 uint8_t pad[7];
 struct se_cmd se_cmd;
 struct list_head sess_cmd_list;
 struct fc_port *sess;
 struct qla_qpair *qpair;
 uint32_t reset_count;
 int state;
 struct work_struct work;

 unsigned char sense_buffer[96];

 spinlock_t cmd_lock;

 unsigned int conf_compl_supported:1;
 unsigned int sg_mapped:1;
 unsigned int write_data_transferred:1;
 unsigned int q_full:1;
 unsigned int term_exchg:1;
 unsigned int cmd_sent_to_fw:1;
 unsigned int cmd_in_wq:1;
 unsigned int edif:1;







 unsigned int aborted;

 struct scatterlist *sg;
 int sg_cnt;
 int bufflen;
 int offset;
 u64 unpacked_lun;
 enum dma_data_direction dma_data_direction;

 uint16_t ctio_flags;
 uint16_t vp_idx;
 uint16_t loop_id;
 struct qla_tgt *tgt;
 struct scsi_qla_host *vha;
 struct list_head cmd_list;

 struct atio_from_isp atio;

 uint8_t ctx_dsd_alloced;


 int8_t dif_err_code;
 struct scatterlist *prot_sg;
 uint32_t prot_sg_cnt;
 uint32_t blk_sz, num_blks;
 uint8_t scsi_status, sense_key, asc, ascq;

 struct crc_context *ctx;
 const uint8_t *cdb;
 uint64_t lba;
 uint16_t a_guard, e_guard, a_app_tag, e_app_tag;
 uint32_t a_ref_tag, e_ref_tag;
 uint16_t prot_flags;

 uint64_t jiffies_at_alloc;
 uint64_t jiffies_at_free;

 enum trace_flags trc_flags;
};
struct qla_tgt_mgmt_cmd {
 uint8_t cmd_type;
 uint8_t pad[3];
 uint16_t tmr_func;
 uint8_t fc_tm_rsp;
 uint8_t abort_io_attr;
 struct fc_port *sess;
 struct qla_qpair *qpair;
 struct scsi_qla_host *vha;
 struct se_cmd se_cmd;
 struct work_struct free_work;
 unsigned int flags;
 uint32_t reset_count;
 struct work_struct work;
 uint64_t unpacked_lun;
 union {
  struct atio_from_isp atio;
  struct imm_ntfy_from_isp imm_ntfy;
  struct abts_recv_from_24xx abts;
 } __attribute__((__packed__)) orig_iocb;
};
extern void qlt_do_generation_tick(struct scsi_qla_host *, int *);
extern int ql2xexchoffld;
extern int ql2xiniexchg;
void qla2100_fw_dump(scsi_qla_host_t *vha);
void qla2300_fw_dump(scsi_qla_host_t *vha);
void qla24xx_fw_dump(scsi_qla_host_t *vha);
void qla25xx_fw_dump(scsi_qla_host_t *vha);
void qla81xx_fw_dump(scsi_qla_host_t *vha);
void qla83xx_fw_dump(scsi_qla_host_t *vha);
struct qla2300_fw_dump {
 __be16 hccr;
 __be16 pbiu_reg[8];
 __be16 risc_host_reg[8];
 __be16 mailbox_reg[32];
 __be16 resp_dma_reg[32];
 __be16 dma_reg[48];
 __be16 risc_hdw_reg[16];
 __be16 risc_gp0_reg[16];
 __be16 risc_gp1_reg[16];
 __be16 risc_gp2_reg[16];
 __be16 risc_gp3_reg[16];
 __be16 risc_gp4_reg[16];
 __be16 risc_gp5_reg[16];
 __be16 risc_gp6_reg[16];
 __be16 risc_gp7_reg[16];
 __be16 frame_buf_hdw_reg[64];
 __be16 fpm_b0_reg[64];
 __be16 fpm_b1_reg[64];
 __be16 risc_ram[0xf800];
 __be16 stack_ram[0x1000];
 __be16 data_ram[1];
};
struct qla2100_fw_dump {
 __be16 hccr;
 __be16 pbiu_reg[8];
 __be16 mailbox_reg[32];
 __be16 dma_reg[48];
 __be16 risc_hdw_reg[16];
 __be16 risc_gp0_reg[16];
 __be16 risc_gp1_reg[16];
 __be16 risc_gp2_reg[16];
 __be16 risc_gp3_reg[16];
 __be16 risc_gp4_reg[16];
 __be16 risc_gp5_reg[16];
 __be16 risc_gp6_reg[16];
 __be16 risc_gp7_reg[16];
 __be16 frame_buf_hdw_reg[16];
 __be16 fpm_b0_reg[64];
 __be16 fpm_b1_reg[64];
 __be16 risc_ram[0xf000];
 u8 queue_dump[1];
};
struct qla24xx_fw_dump {
 __be32 host_status;
 __be32 host_reg[32];
 __be32 shadow_reg[7];
 __be16 mailbox_reg[32];
 __be32 xseq_gp_reg[128];
 __be32 xseq_0_reg[16];
 __be32 xseq_1_reg[16];
 __be32 rseq_gp_reg[128];
 __be32 rseq_0_reg[16];
 __be32 rseq_1_reg[16];
 __be32 rseq_2_reg[16];
 __be32 cmd_dma_reg[16];
 __be32 req0_dma_reg[15];
 __be32 resp0_dma_reg[15];
 __be32 req1_dma_reg[15];
 __be32 xmt0_dma_reg[32];
 __be32 xmt1_dma_reg[32];
 __be32 xmt2_dma_reg[32];
 __be32 xmt3_dma_reg[32];
 __be32 xmt4_dma_reg[32];
 __be32 xmt_data_dma_reg[16];
 __be32 rcvt0_data_dma_reg[32];
 __be32 rcvt1_data_dma_reg[32];
 __be32 risc_gp_reg[128];
 __be32 lmc_reg[112];
 __be32 fpm_hdw_reg[192];
 __be32 fb_hdw_reg[176];
 __be32 code_ram[0x2000];
 __be32 ext_mem[1];
};
struct qla25xx_fw_dump {
 __be32 host_status;
 __be32 host_risc_reg[32];
 __be32 pcie_regs[4];
 __be32 host_reg[32];
 __be32 shadow_reg[11];
 __be32 risc_io_reg;
 __be16 mailbox_reg[32];
 __be32 xseq_gp_reg[128];
 __be32 xseq_0_reg[48];
 __be32 xseq_1_reg[16];
 __be32 rseq_gp_reg[128];
 __be32 rseq_0_reg[32];
 __be32 rseq_1_reg[16];
 __be32 rseq_2_reg[16];
 __be32 aseq_gp_reg[128];
 __be32 aseq_0_reg[32];
 __be32 aseq_1_reg[16];
 __be32 aseq_2_reg[16];
 __be32 cmd_dma_reg[16];
 __be32 req0_dma_reg[15];
 __be32 resp0_dma_reg[15];
 __be32 req1_dma_reg[15];
 __be32 xmt0_dma_reg[32];
 __be32 xmt1_dma_reg[32];
 __be32 xmt2_dma_reg[32];
 __be32 xmt3_dma_reg[32];
 __be32 xmt4_dma_reg[32];
 __be32 xmt_data_dma_reg[16];
 __be32 rcvt0_data_dma_reg[32];
 __be32 rcvt1_data_dma_reg[32];
 __be32 risc_gp_reg[128];
 __be32 lmc_reg[128];
 __be32 fpm_hdw_reg[192];
 __be32 fb_hdw_reg[192];
 __be32 code_ram[0x2000];
 __be32 ext_mem[1];
};
struct qla81xx_fw_dump {
 __be32 host_status;
 __be32 host_risc_reg[32];
 __be32 pcie_regs[4];
 __be32 host_reg[32];
 __be32 shadow_reg[11];
 __be32 risc_io_reg;
 __be16 mailbox_reg[32];
 __be32 xseq_gp_reg[128];
 __be32 xseq_0_reg[48];
 __be32 xseq_1_reg[16];
 __be32 rseq_gp_reg[128];
 __be32 rseq_0_reg[32];
 __be32 rseq_1_reg[16];
 __be32 rseq_2_reg[16];
 __be32 aseq_gp_reg[128];
 __be32 aseq_0_reg[32];
 __be32 aseq_1_reg[16];
 __be32 aseq_2_reg[16];
 __be32 cmd_dma_reg[16];
 __be32 req0_dma_reg[15];
 __be32 resp0_dma_reg[15];
 __be32 req1_dma_reg[15];
 __be32 xmt0_dma_reg[32];
 __be32 xmt1_dma_reg[32];
 __be32 xmt2_dma_reg[32];
 __be32 xmt3_dma_reg[32];
 __be32 xmt4_dma_reg[32];
 __be32 xmt_data_dma_reg[16];
 __be32 rcvt0_data_dma_reg[32];
 __be32 rcvt1_data_dma_reg[32];
 __be32 risc_gp_reg[128];
 __be32 lmc_reg[128];
 __be32 fpm_hdw_reg[224];
 __be32 fb_hdw_reg[208];
 __be32 code_ram[0x2000];
 __be32 ext_mem[1];
};
struct qla83xx_fw_dump {
 __be32 host_status;
 __be32 host_risc_reg[48];
 __be32 pcie_regs[4];
 __be32 host_reg[32];
 __be32 shadow_reg[11];
 __be32 risc_io_reg;
 __be16 mailbox_reg[32];
 __be32 xseq_gp_reg[256];
 __be32 xseq_0_reg[48];
 __be32 xseq_1_reg[16];
 __be32 xseq_2_reg[16];
 __be32 rseq_gp_reg[256];
 __be32 rseq_0_reg[32];
 __be32 rseq_1_reg[16];
 __be32 rseq_2_reg[16];
 __be32 rseq_3_reg[16];
 __be32 aseq_gp_reg[256];
 __be32 aseq_0_reg[32];
 __be32 aseq_1_reg[16];
 __be32 aseq_2_reg[16];
 __be32 aseq_3_reg[16];
 __be32 cmd_dma_reg[64];
 __be32 req0_dma_reg[15];
 __be32 resp0_dma_reg[15];
 __be32 req1_dma_reg[15];
 __be32 xmt0_dma_reg[32];
 __be32 xmt1_dma_reg[32];
 __be32 xmt2_dma_reg[32];
 __be32 xmt3_dma_reg[32];
 __be32 xmt4_dma_reg[32];
 __be32 xmt_data_dma_reg[16];
 __be32 rcvt0_data_dma_reg[32];
 __be32 rcvt1_data_dma_reg[32];
 __be32 risc_gp_reg[128];
 __be32 lmc_reg[128];
 __be32 fpm_hdw_reg[256];
 __be32 rq0_array_reg[256];
 __be32 rq1_array_reg[256];
 __be32 rp0_array_reg[256];
 __be32 rp1_array_reg[256];
 __be32 queue_control_reg[16];
 __be32 fb_hdw_reg[432];
 __be32 at0_array_reg[128];
 __be32 code_ram[0x2400];
 __be32 ext_mem[1];
};
struct qla2xxx_fw_dump {
 uint8_t signature[4];
 __be32 version;

 __be32 fw_major_version;
 __be32 fw_minor_version;
 __be32 fw_subminor_version;
 __be32 fw_attributes;

 __be32 vendor;
 __be32 device;
 __be32 subsystem_vendor;
 __be32 subsystem_device;

 __be32 fixed_size;
 __be32 mem_size;
 __be32 req_q_size;
 __be32 rsp_q_size;

 __be32 eft_size;
 __be32 eft_addr_l;
 __be32 eft_addr_h;

 __be32 header_size;

 union {
  struct qla2100_fw_dump isp21;
  struct qla2300_fw_dump isp23;
  struct qla24xx_fw_dump isp24;
  struct qla25xx_fw_dump isp25;
  struct qla81xx_fw_dump isp81;
  struct qla83xx_fw_dump isp83;
 } isp;
};
static char *qlini_mode = "enabled";
/*@ requires \valid(dest); ensures *dest == \old(*dest) + 1; */

void qlt_do_generation_tick(struct scsi_qla_host *vha, int *dest)
{
 scsi_qla_host_t *base_vha = pci_get_drvdata(vha->hw->pdev);
 *dest = atomic_inc_return(&base_vha->generation_tick);

 do { do { } while (0); asm volatile("sfence" ::: "memory"); } while (0);
}
