typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __uint32_t uint32_t;
typedef __size_t size_t;
typedef struct ocs_softc ocs_t;
typedef ocs_t * ocs_os_handle_t;
/*@ requires 1; ensures \result == 4294967295; */

static inline uint32_t ocs_max_dma_alloc(ocs_os_handle_t os, size_t align)
{
 return ~((uint32_t)0);
}
