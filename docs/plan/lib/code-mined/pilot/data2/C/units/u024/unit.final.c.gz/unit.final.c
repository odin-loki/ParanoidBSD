typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
size_t libder_size_length(size_t);
/*@ requires sz >= 0; ensures sz < 0x80 ? \result == 1 : \result >= 2 && \result <= sizeof(size_t) + 1; */

 size_t
libder_size_length(size_t sz)
{
 size_t nbytes;





 if (sz < 0x80)
  return (1);






 for (nbytes = 1; nbytes < sizeof(size_t); nbytes++) {
  if ((sz & ~((1ULL << 8 * nbytes) - 1)) == 0)
   break;
 }


 return (nbytes + 1);
}
