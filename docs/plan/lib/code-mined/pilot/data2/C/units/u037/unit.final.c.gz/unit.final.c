typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u16 u16;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures 1 <= \result <= 4 && ((chain_mask & 0xf) == 0xf ==> \result == 4) && ((chain_mask & 0xf) != 0xf && (chain_mask & 0x7) == 0x7 ==> \result == 3) && ((chain_mask & 0xf) != 0xf && (chain_mask & 0x7) != 0x7 && (chain_mask & 0x3) == 0x3 ==> \result == 2) && ((chain_mask & 0x3) != 0x3 ==> \result == 1); */

static u32 get_nss_from_chainmask(u16 chain_mask)
{
 if ((chain_mask & 0xf) == 0xf)
  return 4;
 else if ((chain_mask & 0x7) == 0x7)
  return 3;
 else if ((chain_mask & 0x3) == 0x3)
  return 2;
 return 1;
}
