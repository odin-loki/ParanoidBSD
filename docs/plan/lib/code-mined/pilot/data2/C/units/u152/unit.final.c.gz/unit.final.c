enum {
 false = 0,
 true = 1
};
struct intel_display_platforms {
 union {
  struct {
   unsigned long g4x:1; unsigned long mobile:1; unsigned long dgfx:1; unsigned long i830:1; unsigned long i845g:1; unsigned long i85x:1; unsigned long i865g:1; unsigned long i915g:1; unsigned long i915gm:1; unsigned long i945g:1; unsigned long i945gm:1; unsigned long g33:1; unsigned long pineview:1; unsigned long i965g:1; unsigned long i965gm:1; unsigned long g45:1; unsigned long gm45:1; unsigned long ironlake:1; unsigned long sandybridge:1; unsigned long ivybridge:1; unsigned long valleyview:1; unsigned long haswell:1; unsigned long haswell_ult:1; unsigned long haswell_ulx:1; unsigned long broadwell:1; unsigned long broadwell_ult:1; unsigned long broadwell_ulx:1; unsigned long cherryview:1; unsigned long skylake:1; unsigned long skylake_ult:1; unsigned long skylake_ulx:1; unsigned long broxton:1; unsigned long kabylake:1; unsigned long kabylake_ult:1; unsigned long kabylake_ulx:1; unsigned long geminilake:1; unsigned long coffeelake:1; unsigned long coffeelake_ult:1; unsigned long coffeelake_ulx:1; unsigned long cometlake:1; unsigned long cometlake_ult:1; unsigned long cometlake_ulx:1; unsigned long icelake:1; unsigned long icelake_port_f:1; unsigned long jasperlake:1; unsigned long elkhartlake:1; unsigned long tigerlake:1; unsigned long tigerlake_uy:1; unsigned long rocketlake:1; unsigned long dg1:1; unsigned long alderlake_s:1; unsigned long alderlake_s_raptorlake_s:1; unsigned long alderlake_p:1; unsigned long alderlake_p_alderlake_n:1; unsigned long alderlake_p_raptorlake_p:1; unsigned long alderlake_p_raptorlake_u:1; unsigned long dg2:1; unsigned long dg2_g10:1; unsigned long dg2_g11:1; unsigned long dg2_g12:1; unsigned long meteorlake:1; unsigned long meteorlake_u:1; unsigned long lunarlake:1; unsigned long battlemage:1; unsigned long pantherlake:1; unsigned long pantherlake_wildcatlake:1;;
  };
  unsigned long bitmap[((((1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 0)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 };
};
/*@ requires true; ensures \result == sizeof(((struct intel_display_platforms *)0)->bitmap) * 8; */

static unsigned int display_platforms_num_bits(void)
{
 return sizeof(((struct intel_display_platforms *)0)->bitmap) * 8;
}
