typedef unsigned int __u32;
typedef __u32 u32;
/*@ requires 0 <= value; ensures \result == value / 3; */

static  u32 kprobe_recursed_target(u32 value)
{
 return (value / 3);
}
