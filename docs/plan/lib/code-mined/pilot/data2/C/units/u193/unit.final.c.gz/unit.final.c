typedef unsigned int __uint32_t;
typedef __uint32_t uint32_t;
/*@ requires \true; ensures \result == (ports & (~(ports - 1))); */

static uint32_t
hdspe_port_first(uint32_t ports)
{
 return (ports & (~(ports - 1)));
}
