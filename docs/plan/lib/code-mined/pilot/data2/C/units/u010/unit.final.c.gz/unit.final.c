typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef __u32 __be32;
/*@ requires true; ensures \result == ((u32)a > (u32)b); */

static int be32_gt(__be32 a, __be32 b)
{
 return ( u32) a > ( u32) b;
}
