typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
enum {
 ___GFP_DMA_BIT,
 ___GFP_HIGHMEM_BIT,
 ___GFP_DMA32_BIT,
 ___GFP_MOVABLE_BIT,
 ___GFP_RECLAIMABLE_BIT,
 ___GFP_HIGH_BIT,
 ___GFP_IO_BIT,
 ___GFP_FS_BIT,
 ___GFP_ZERO_BIT,
 ___GFP_UNUSED_BIT,
 ___GFP_DIRECT_RECLAIM_BIT,
 ___GFP_KSWAPD_RECLAIM_BIT,
 ___GFP_WRITE_BIT,
 ___GFP_NOWARN_BIT,
 ___GFP_RETRY_MAYFAIL_BIT,
 ___GFP_NOFAIL_BIT,
 ___GFP_NORETRY_BIT,
 ___GFP_MEMALLOC_BIT,
 ___GFP_COMP_BIT,
 ___GFP_NOMEMALLOC_BIT,
 ___GFP_HARDWALL_BIT,
 ___GFP_THISNODE_BIT,
 ___GFP_ACCOUNT_BIT,
 ___GFP_ZEROTAGS_BIT,





 ___GFP_NOLOCKDEP_BIT,


 ___GFP_NO_OBJ_EXT_BIT,

 ___GFP_LAST_BIT
};
struct scatterlist;
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct scatterlist *sgl_alloc_order(unsigned long long length,
        unsigned int order, bool chainable,
        gfp_t gfp, unsigned int *nent_p);
struct scatterlist;
struct scatterlist;
struct scatterlist;
int target_alloc_sgl(struct scatterlist **sgl, unsigned int *nents,
  u32 length, bool zero_page, bool chainable);
/*@ requires nents == \null || \true; ensures \result == 0 ==> *sgl != \null && *nents > 0; ensures \result == -12 ==> *sgl == \null; */

int
target_alloc_sgl(struct scatterlist **sgl, unsigned int *nents, u32 length,
   bool zero_page, bool chainable)
{
 gfp_t gfp = ((( gfp_t)(((((1UL))) << (___GFP_DIRECT_RECLAIM_BIT))|((((1UL))) << (___GFP_KSWAPD_RECLAIM_BIT)))) | (( gfp_t)((((1UL))) << (___GFP_IO_BIT))) | (( gfp_t)((((1UL))) << (___GFP_FS_BIT)))) | (zero_page ? (( gfp_t)((((1UL))) << (___GFP_ZERO_BIT))) : 0);

 *sgl = sgl_alloc_order(length, 0, chainable, gfp, nents);
 return *sgl ? 0 : -12;
}
extern typeof(target_alloc_sgl) target_alloc_sgl;
