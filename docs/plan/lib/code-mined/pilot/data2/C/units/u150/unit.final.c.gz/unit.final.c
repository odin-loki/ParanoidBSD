__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == (data >> 32 == 0); */

static inline    bool kvm_dr7_valid(u64 data)
{

 return !(data >> 32);
}
