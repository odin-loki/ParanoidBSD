typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
struct nested_vmx_msrs {





 u32 procbased_ctls_low;
 u32 procbased_ctls_high;
 u32 secondary_ctls_low;
 u32 secondary_ctls_high;
 u32 pinbased_ctls_low;
 u32 pinbased_ctls_high;
 u32 exit_ctls_low;
 u32 exit_ctls_high;
 u32 entry_ctls_low;
 u32 entry_ctls_high;
 u32 misc_low;
 u32 misc_high;
 u32 ept_caps;
 u32 vpid_caps;
 u64 basic;
 u64 cr0_fixed0;
 u64 cr0_fixed1;
 u64 cr4_fixed0;
 u64 cr4_fixed1;
 u64 vmcs_enum;
 u64 vmfunc_controls;
};
struct vmcs_config {
 u64 basic;
 u32 pin_based_exec_ctrl;
 u32 cpu_based_exec_ctrl;
 u32 cpu_based_2nd_exec_ctrl;
 u64 cpu_based_3rd_exec_ctrl;
 u32 vmexit_ctrl;
 u32 vmentry_ctrl;
 u64 misc;
 struct nested_vmx_msrs nested;
};
extern struct vmcs_config vmcs_config ;
/*@ requires \true; ensures \result == ((vmcs_config.misc & ((((1ULL))) << (14))) != 0 && (vmcs_config.cpu_based_2nd_exec_ctrl & ((((1UL))) << (( 2*32+ 24) & 0x1f))) != 0 && (vmcs_config.vmentry_ctrl & 0x00040000) != 0); */

static inline    bool cpu_has_vmx_intel_pt(void)
{
 return (vmcs_config.misc & ((((1ULL))) << (14))) &&
  (vmcs_config.cpu_based_2nd_exec_ctrl & ((((1UL))) << (( 2*32+ 24) & 0x1f))) &&
  (vmcs_config.vmentry_ctrl & 0x00040000);
}
