typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s32 int32_t;
typedef u32 uint32_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef u64 phys_addr_t;
typedef phys_addr_t resource_size_t;
typedef unsigned long irq_hw_number_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct kernel_param;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct cacheline_padding {
 char x[1];
} ;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct task_struct;
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct module;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct mm_struct;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct completion;
struct user;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct static_key;
struct task_struct;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct task_struct;
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct task_struct;
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
typedef struct wait_queue_entry wait_queue_entry_t;
typedef int (*wait_queue_func_t)(struct wait_queue_entry *wq_entry, unsigned mode, int flags, void *key);
struct wait_queue_entry {
 unsigned int flags;
 void *private;
 wait_queue_func_t func;
 struct list_head entry;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct device;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct page;
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
struct task_struct;
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
typedef __s64 time64_t;
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct module;
struct page;
struct vm_area_struct;
struct mm_struct;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct resource;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
typedef struct {
 __u8 b[16];
} uuid_t;
typedef unsigned long kernel_ulong_t;
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
struct resource {
 resource_size_t start;
 resource_size_t end;
 const char *name;
 unsigned long flags;
 unsigned long desc;
 struct resource *parent, *sibling, *child;
};
static inline    resource_size_t resource_size(const struct resource *res)
;
struct device;
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct user_namespace;
struct uid_gid_map;
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct resource;
struct vm_area_struct;
struct file;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct cred;
struct file;
struct task_struct;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
struct sg_table;
struct file;
struct pid;
struct cred;
struct sock;
struct seq_file;
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
extern bool capable(int cap);
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
enum irqreturn {
 IRQ_NONE = (0 << 0),
 IRQ_HANDLED = (1 << 0),
 IRQ_WAKE_THREAD = (1 << 1),
};
typedef enum irqreturn irqreturn_t;
extern char _data[], _sdata[], _edata[];
struct device;
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct device;
struct device;
struct module;
struct pglist_data;
struct file;
struct resource;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct kobject;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct sg_table {
 struct scatterlist *sgl;
 unsigned int nents;
 unsigned int orig_nents;
};
struct device;
struct device_node;
struct irq_domain;
struct firmware {
 size_t size;
 const u8 *data;


 void *priv;
};
struct module;
struct device;
struct device;
bool device_dma_supported(const struct device *dev);
enum dev_dma_attr device_get_dma_attr(const struct device *dev);
const void *device_get_match_data(const struct device *dev);
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct irq_domain;
struct irq_domain_ops;
struct iommu_ops;
struct bio_vec;
struct page;
struct device;
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct u64_stats_sync {



};
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
void css_rstat_flush(struct cgroup_subsys_state *css);
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
static inline    void *kmap(struct page *page)
;
static inline    void *kmap(struct page *page);
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct folio_batch;
struct wait_page_queue {
 struct folio *folio;
 int bit_nr;
 wait_queue_entry_t wait;
};
struct readahead_control {
 struct file *file;
 struct address_space *mapping;
 struct file_ra_state *ra;

 unsigned long _index;
 unsigned int _nr_pages;
 unsigned int _batch_count;
 bool dropbehind;
 bool _workingset;
 unsigned long _pflags;
};
struct notifier_block;
struct bio;
struct reclaim_state {

 unsigned long reclaimed;


 struct lru_gen_mm_walk *mm_walk;

};
struct address_space;
struct writeback_control;
struct zone;
struct swap_sequential_cluster {
 unsigned int next[((21 - 12) + 1)];
};
struct swap_info_struct {
 struct percpu_ref users;
 unsigned long flags;
 signed short prio;
 struct plist_node list;
 signed char type;
 unsigned int max;
 unsigned char *swap_map;
 unsigned long *zeromap;
 struct swap_cluster_info *cluster_info;
 struct list_head free_clusters;
 struct list_head full_clusters;
 struct list_head nonfull_clusters[((21 - 12) + 1)];

 struct list_head frag_clusters[((21 - 12) + 1)];

 unsigned int pages;
 atomic_long_t inuse_pages;
 struct swap_sequential_cluster *global_cluster;
 spinlock_t global_cluster_lock;
 struct rb_root swap_extent_root;
 struct block_device *bdev;
 struct file *swap_file;
 struct completion comp;
 spinlock_t lock;
 spinlock_t cont_lock;



 struct work_struct discard_work;
 struct work_struct reclaim_work;
 struct list_head discard_clusters;
 struct plist_node avail_lists[1];
};
extern unsigned long totalreserve_pages;
struct backing_dev_info;
extern bool frozen(struct task_struct *p);
struct device;
struct notifier_block;
struct rt_mutex_waiter;
enum irq_domain_bus_token {
 DOMAIN_BUS_ANY = 0,
 DOMAIN_BUS_WIRED,
 DOMAIN_BUS_GENERIC_MSI,
 DOMAIN_BUS_PCI_MSI,
 DOMAIN_BUS_PLATFORM_MSI,
 DOMAIN_BUS_NEXUS,
 DOMAIN_BUS_IPI,
 DOMAIN_BUS_FSL_MC_MSI,
 DOMAIN_BUS_TI_SCI_INTA_MSI,
 DOMAIN_BUS_WAKEUP,
 DOMAIN_BUS_VMD_MSI,
 DOMAIN_BUS_PCI_DEVICE_MSI,
 DOMAIN_BUS_PCI_DEVICE_MSIX,
 DOMAIN_BUS_DMAR,
 DOMAIN_BUS_AMDVI,
 DOMAIN_BUS_DEVICE_MSI,
 DOMAIN_BUS_WIRED_TO_MSI,
};
typedef u32 phandle;
struct property {
 char *name;
 int length;
 void *value;
 struct property *next;

 unsigned long _flags;





 struct bin_attribute attr;

};
struct device_node {
 const char *name;
 phandle phandle;
 const char *full_name;
 struct fwnode_handle fwnode;

 struct property *properties;
 struct property *deadprops;
 struct device_node *parent;
 struct device_node *child;
 struct device_node *sibling;

 struct kobject kobj;

 unsigned long _flags;
 void *data;




};
struct of_phandle_args {
 struct device_node *np;
 int args_count;
 uint32_t args[16];
};
struct notifier_block;
struct device_node;
struct fwnode_handle;
struct irq_domain;
struct irq_data;
struct cpumask;
struct seq_file;
struct msi_parent_ops;
struct irq_fwspec {
 struct fwnode_handle *fwnode;
 int param_count;
 u32 param[16];
};
struct irq_domain_ops {
 int (*match)(struct irq_domain *d, struct device_node *node,
    enum irq_domain_bus_token bus_token);
 int (*select)(struct irq_domain *d, struct irq_fwspec *fwspec,
     enum irq_domain_bus_token bus_token);
 int (*map)(struct irq_domain *d, unsigned int virq, irq_hw_number_t hw);
 void (*unmap)(struct irq_domain *d, unsigned int virq);
 int (*xlate)(struct irq_domain *d, struct device_node *node,
    const u32 *intspec, unsigned int intsize,
    unsigned long *out_hwirq, unsigned int *out_type);


 int (*alloc)(struct irq_domain *d, unsigned int virq,
    unsigned int nr_irqs, void *arg);
 void (*free)(struct irq_domain *d, unsigned int virq,
   unsigned int nr_irqs);
 int (*activate)(struct irq_domain *d, struct irq_data *irqd, bool reserve);
 void (*deactivate)(struct irq_domain *d, struct irq_data *irq_data);
 int (*translate)(struct irq_domain *d, struct irq_fwspec *fwspec,
        unsigned long *out_hwirq, unsigned int *out_type);


 void (*debug_show)(struct seq_file *m, struct irq_domain *d,
         struct irq_data *irqd, int ind);

};
struct irq_domain_chip_generic;
struct irq_domain {
 struct list_head link;
 const char *name;
 const struct irq_domain_ops *ops;
 void *host_data;
 unsigned int flags;
 unsigned int mapcount;
 struct mutex mutex;
 struct irq_domain *root;


 struct fwnode_handle *fwnode;
 enum irq_domain_bus_token bus_token;
 struct irq_domain_chip_generic *gc;
 struct device *dev;
 struct device *pm_dev;

 struct irq_domain *parent;


 const struct msi_parent_ops *msi_parent_ops;

 void (*exit)(struct irq_domain *d);


 irq_hw_number_t hwirq_max;
 unsigned int revmap_size;
 struct xarray revmap_tree;
 struct irq_data *revmap[1] ;
};
struct module;
struct vm_area_struct;
struct notifier_block;
struct iov_iter;
struct vm_struct {
 struct vm_struct *next;
 void *addr;
 unsigned long size;
 unsigned long flags;
 struct page **pages;

 unsigned int page_order;

 unsigned int nr_pages;
 phys_addr_t phys_addr;
 const void *caller;
 unsigned long requested_size;
};
struct device;
struct attribute_group;
struct device_node;
struct fwnode_handle;
struct kernfs_node;
struct device_node;
struct device;
struct clk;
struct device_node;
struct of_phandle_args;
struct device;
struct device_node;
struct iova_bitmap;
enum iommu_hw_info_type {
 IOMMU_HW_INFO_TYPE_NONE = 0,
 IOMMU_HW_INFO_TYPE_DEFAULT = 0,
 IOMMU_HW_INFO_TYPE_INTEL_VTD = 1,
 IOMMU_HW_INFO_TYPE_ARM_SMMUV3 = 2,
 IOMMU_HW_INFO_TYPE_TEGRA241_CMDQV = 3,
};
enum iommu_viommu_type {
 IOMMU_VIOMMU_TYPE_DEFAULT = 0,
 IOMMU_VIOMMU_TYPE_ARM_SMMUV3 = 1,





 IOMMU_VIOMMU_TYPE_TEGRA241_CMDQV = 2,
};
struct iommu_ops;
struct iommu_group;
struct bus_type;
struct device;
struct iommu_domain;
struct iommu_domain_ops;
struct iommu_dirty_ops;
struct notifier_block;
struct iommu_dma_cookie;
struct iommu_dma_msi_cookie;
struct iommu_fault_param;
struct iommufd_viommu;
struct iommu_fault_page_request {
 u32 flags;
 u32 pasid;
 u32 grpid;
 u32 perm;
 u64 addr;
 u64 private_data[2];
};
struct iommu_fault {
 u32 type;
 struct iommu_fault_page_request prm;
};
struct iommu_page_response {
 u32 pasid;
 u32 grpid;
 u32 code;
};
struct iopf_fault {
 struct iommu_fault fault;

 struct list_head list;
};
struct iopf_group {
 struct iopf_fault last_fault;
 struct list_head faults;
 size_t fault_count;

 struct list_head pending_node;
 struct work_struct work;
 struct iommu_attach_handle *attach_handle;

 struct iommu_fault_param *fault_param;

 struct list_head node;
 u32 cookie;
};
struct iopf_queue {
 struct workqueue_struct *wq;
 struct list_head devices;
 struct mutex lock;
};
typedef int (*iommu_fault_handler_t)(struct iommu_domain *,
   struct device *, unsigned long, int, void *);
struct iommu_domain_geometry {
 dma_addr_t aperture_start;
 dma_addr_t aperture_end;
 bool force_aperture;
};
enum iommu_domain_cookie_type {
 IOMMU_COOKIE_NONE,
 IOMMU_COOKIE_DMA_IOVA,
 IOMMU_COOKIE_DMA_MSI,
 IOMMU_COOKIE_FAULT_HANDLER,
 IOMMU_COOKIE_SVA,
 IOMMU_COOKIE_IOMMUFD,
};
struct iommu_domain {
 unsigned type;
 enum iommu_domain_cookie_type cookie_type;
 const struct iommu_domain_ops *ops;
 const struct iommu_dirty_ops *dirty_ops;
 const struct iommu_ops *owner;
 unsigned long pgsize_bitmap;
 struct iommu_domain_geometry geometry;
 int (*iopf_handler)(struct iopf_group *group);

 union {
  struct iommu_dma_cookie *iova_cookie;
  struct iommu_dma_msi_cookie *msi_cookie;
  struct iommufd_hw_pagetable *iommufd_hwpt;
  struct {
   iommu_fault_handler_t handler;
   void *handler_token;
  };
  struct {
   struct mm_struct *mm;
   int users;




   struct list_head next;
  };
 };
};
enum iommu_cap {
 IOMMU_CAP_CACHE_COHERENCY,
 IOMMU_CAP_NOEXEC,
 IOMMU_CAP_PRE_BOOT_PROTECTION,





 IOMMU_CAP_ENFORCE_CACHE_COHERENCY,




 IOMMU_CAP_DEFERRED_FLUSH,
 IOMMU_CAP_DIRTY_TRACKING,
};
typedef unsigned int ioasid_t;
struct iommu_pages_list {
 struct list_head pages;
};
struct iommu_iotlb_gather {
 unsigned long start;
 unsigned long end;
 size_t pgsize;
 struct iommu_pages_list freelist;
 bool queued;
};
struct iommu_dirty_bitmap {
 struct iova_bitmap *bitmap;
 struct iommu_iotlb_gather *gather;
};
struct iommu_dirty_ops {
 int (*set_dirty_tracking)(struct iommu_domain *domain, bool enabled);
 int (*read_and_clear_dirty)(struct iommu_domain *domain,
        unsigned long iova, size_t size,
        unsigned long flags,
        struct iommu_dirty_bitmap *dirty);
};
struct iommu_user_data {
 unsigned int type;
 void *uptr;
 size_t len;
};
struct iommu_user_data_array {
 unsigned int type;
 void *uptr;
 size_t entry_len;
 u32 entry_num;
};
struct iommu_ops {
 bool (*capable)(struct device *dev, enum iommu_cap);
 void *(*hw_info)(struct device *dev, u32 *length,
    enum iommu_hw_info_type *type);





 struct iommu_domain *(*domain_alloc_identity)(struct device *dev);
 struct iommu_domain *(*domain_alloc_paging_flags)(
  struct device *dev, u32 flags,
  const struct iommu_user_data *user_data);
 struct iommu_domain *(*domain_alloc_paging)(struct device *dev);
 struct iommu_domain *(*domain_alloc_sva)(struct device *dev,
       struct mm_struct *mm);
 struct iommu_domain *(*domain_alloc_nested)(
  struct device *dev, struct iommu_domain *parent, u32 flags,
  const struct iommu_user_data *user_data);

 struct iommu_device *(*probe_device)(struct device *dev);
 void (*release_device)(struct device *dev);
 void (*probe_finalize)(struct device *dev);
 struct iommu_group *(*device_group)(struct device *dev);


 void (*get_resv_regions)(struct device *dev, struct list_head *list);

 int (*of_xlate)(struct device *dev, const struct of_phandle_args *args);
 bool (*is_attach_deferred)(struct device *dev);


 void (*page_response)(struct device *dev, struct iopf_fault *evt,
         struct iommu_page_response *msg);

 int (*def_domain_type)(struct device *dev);

 size_t (*get_viommu_size)(struct device *dev,
      enum iommu_viommu_type viommu_type);
 int (*viommu_init)(struct iommufd_viommu *viommu,
      struct iommu_domain *parent_domain,
      const struct iommu_user_data *user_data);

 const struct iommu_domain_ops *default_domain_ops;
 struct module *owner;
 struct iommu_domain *identity_domain;
 struct iommu_domain *blocked_domain;
 struct iommu_domain *release_domain;
 struct iommu_domain *default_domain;
 u8 user_pasid_table:1;
};
struct iommu_domain_ops {
 int (*attach_dev)(struct iommu_domain *domain, struct device *dev,
     struct iommu_domain *old);
 int (*set_dev_pasid)(struct iommu_domain *domain, struct device *dev,
        ioasid_t pasid, struct iommu_domain *old);

 int (*map_pages)(struct iommu_domain *domain, unsigned long iova,
    phys_addr_t paddr, size_t pgsize, size_t pgcount,
    int prot, gfp_t gfp, size_t *mapped);
 size_t (*unmap_pages)(struct iommu_domain *domain, unsigned long iova,
         size_t pgsize, size_t pgcount,
         struct iommu_iotlb_gather *iotlb_gather);

 void (*flush_iotlb_all)(struct iommu_domain *domain);
 int (*iotlb_sync_map)(struct iommu_domain *domain, unsigned long iova,
         size_t size);
 void (*iotlb_sync)(struct iommu_domain *domain,
      struct iommu_iotlb_gather *iotlb_gather);
 int (*cache_invalidate_user)(struct iommu_domain *domain,
         struct iommu_user_data_array *array);

 phys_addr_t (*iova_to_phys)(struct iommu_domain *domain,
        dma_addr_t iova);

 bool (*enforce_cache_coherency)(struct iommu_domain *domain);
 int (*set_pgtable_quirks)(struct iommu_domain *domain,
      unsigned long quirks);

 void (*free)(struct iommu_domain *domain);
};
struct iommu_device {
 struct list_head list;
 const struct iommu_ops *ops;
 struct fwnode_handle *fwnode;
 struct device *dev;
 struct iommu_group *singleton_group;
 u32 max_pasids;
 bool ready;
};
struct iommu_fault_param {
 struct mutex lock;
 refcount_t users;
 struct callback_head rcu;

 struct device *dev;
 struct iopf_queue *queue;
 struct list_head queue_list;

 struct list_head partial;
 struct list_head faults;
};
struct dev_iommu {
 struct mutex lock;
 struct iommu_fault_param *fault_param;
 struct iommu_fwspec *fwspec;
 struct iommu_device *iommu_dev;
 void *priv;
 u32 max_pasids;
 u32 attach_deferred:1;
 u32 pci_32bit_workaround:1;
 u32 require_direct:1;
 u32 shadow_on_flush:1;
};
struct iommu_fwspec {
 struct fwnode_handle *iommu_fwnode;
 u32 flags;
 unsigned int num_ids;
 u32 ids[1];
};
struct iommu_attach_handle {
 struct iommu_domain *domain;
};
struct iommu_mm_data {
 u32 pasid;
 struct mm_struct *mm;
 struct list_head sva_domains;
 struct list_head mm_list_elm;
};
struct device;
struct of_device_id;
struct kobj_uevent_env;
struct clk;
struct nvkm_oclass;
struct nvkm_object;
struct nvkm_sclass {
 int minver;
 int maxver;
 s32 oclass;
 const struct nvkm_object_func *func;
 int (*ctor)(const struct nvkm_oclass *, void *data, u32 size,
      struct nvkm_object **);
};
struct nvkm_oclass {
 int (*ctor)(const struct nvkm_oclass *, void *data, u32 size,
      struct nvkm_object **);
 struct nvkm_sclass base;
 const void *priv;
 const void *engn;
 u32 handle;
 u64 object;
 struct nvkm_client *client;
 struct nvkm_object *parent;
 struct nvkm_engine *engine;
};
enum nvkm_suspend_state {
 NVKM_POWEROFF,
 NVKM_SUSPEND,
 NVKM_RUNTIME_SUSPEND,
};
struct nvkm_device;
struct nvkm_subdev;
enum nvkm_intr_prio {
 NVKM_INTR_PRIO_VBLANK = 0,
 NVKM_INTR_PRIO_NORMAL,
 NVKM_INTR_PRIO_NR
};
struct nvkm_intr {
 const struct nvkm_intr_func {
  bool (*pending)(struct nvkm_intr *);
  void (*unarm)(struct nvkm_intr *);
  void (*rearm)(struct nvkm_intr *);
  void (*block)(struct nvkm_intr *, int leaf, u32 mask);
  void (*allow)(struct nvkm_intr *, int leaf, u32 mask);
  void (*reset)(struct nvkm_intr *, int leaf, u32 mask);
 } *func;
 const struct nvkm_intr_data {
  int type;
  int inst;
  int leaf;
  u32 mask;
  bool legacy;
 } *data;

 struct nvkm_subdev *subdev;
 int leaves;
 u32 *stat;
 u32 *mask;

 struct list_head head;
};
struct nvkm_inth;
typedef irqreturn_t (*nvkm_inth_func)(struct nvkm_inth *);
struct nvkm_inth {
 struct nvkm_intr *intr;
 int leaf;
 u32 mask;
 nvkm_inth_func func;

 atomic_t allowed;

 struct list_head head;
};
enum nvkm_subdev_type;
enum nvkm_device_type {
 NVKM_DEVICE_PCI,
 NVKM_DEVICE_AGP,
 NVKM_DEVICE_PCIE,
 NVKM_DEVICE_TEGRA,
};
struct nvkm_device {
 const struct nvkm_device_func *func;
 const struct nvkm_device_quirk *quirk;
 struct device *dev;
 enum nvkm_device_type type;
 u64 handle;
 const char *name;
 const char *cfgopt;
 const char *dbgopt;

 struct list_head head;
 struct mutex mutex;
 int refcount;

 void *pri;

 u32 debug;

 const struct nvkm_device_chip *chip;
 enum {
  NV_04 = 0x04,
  NV_10 = 0x10,
  NV_11 = 0x11,
  NV_20 = 0x20,
  NV_30 = 0x30,
  NV_40 = 0x40,
  NV_50 = 0x50,
  NV_C0 = 0xc0,
  NV_E0 = 0xe0,
  GM100 = 0x110,
  GP100 = 0x130,
  GV100 = 0x140,
  TU100 = 0x160,
  GA100 = 0x170,
  GH100 = 0x180,
  AD100 = 0x190,
  GB10x = 0x1a0,
  GB20x = 0x1b0,
 } card_type;
 u32 chipset;
 u8 chiprev;
 u32 crystal;

 struct {
  struct notifier_block nb;
 } acpi;


struct nvkm_fsp *fsp;
struct nvkm_gsp *gsp;
struct nvkm_top *top;
struct nvkm_vfn *vfn;
struct nvkm_pci *pci;
struct nvkm_bios *bios;
struct nvkm_devinit *devinit;
struct nvkm_subdev *privring;
struct nvkm_gpio *gpio;
struct nvkm_i2c *i2c;
struct nvkm_fuse *fuse;
struct nvkm_subdev *mxm;
struct nvkm_mc *mc;
struct nvkm_bus *bus;
struct nvkm_timer *timer;
struct nvkm_instmem *imem;
struct nvkm_fb *fb;
struct nvkm_ltc *ltc;
struct nvkm_mmu *mmu;
struct nvkm_bar *bar;
struct nvkm_fault *fault;
struct nvkm_acr *acr;
struct nvkm_pmu *pmu;
struct nvkm_volt *volt;
struct nvkm_iccsense *iccsense;
struct nvkm_therm *therm;
struct nvkm_clk *clk;
struct nvkm_subdev *ioctrl[3];
struct nvkm_subdev *fla;

struct nvkm_engine *bsp;
struct nvkm_engine *ce[20];
struct nvkm_engine *cipher;
struct nvkm_disp *disp;
struct nvkm_dma *dma;
struct nvkm_fifo *fifo;
struct nvkm_gr *gr;
struct nvkm_engine *ifb;
struct nvkm_engine *me;
struct nvkm_engine *mpeg;
struct nvkm_engine *msenc;
struct nvkm_engine *mspdec;
struct nvkm_engine *msppp;
struct nvkm_engine *msvld;
struct nvkm_nvdec *nvdec[8];
struct nvkm_nvenc *nvenc[4];
struct nvkm_engine *nvjpg[8];
struct nvkm_engine *ofa[2];
struct nvkm_engine *sec;
struct nvkm_sec2 *sec2;
struct nvkm_sw *sw;
struct nvkm_engine *vic;
struct nvkm_engine *vp;
 struct list_head subdev;

 struct {
  struct list_head intr;
  struct list_head prio[NVKM_INTR_PRIO_NR];
  spinlock_t lock;
  int irq;
  bool alloc;
  bool armed;
  bool legacy_done;
 } intr;
};
enum nvkm_bar_id {
 NVKM_BAR_INVALID = 0,
 NVKM_BAR0_PRI,
 NVKM_BAR1_FB,
 NVKM_BAR2_INST,
};
struct nvkm_device_func {
 struct nvkm_device_pci *(*pci)(struct nvkm_device *);
 struct nvkm_device_tegra *(*tegra)(struct nvkm_device *);
 void *(*dtor)(struct nvkm_device *);
 int (*preinit)(struct nvkm_device *);
 int (*init)(struct nvkm_device *);
 void (*fini)(struct nvkm_device *, enum nvkm_suspend_state suspend);
 int (*irq)(struct nvkm_device *);
 resource_size_t (*resource_addr)(struct nvkm_device *, enum nvkm_bar_id);
 resource_size_t (*resource_size)(struct nvkm_device *, enum nvkm_bar_id);
 bool cpu_coherent;
};
struct nvkm_device_quirk {
 u8 tv_pin_mask;
 u8 tv_gpio;
};
struct nvkm_device_chip {
 const char *name;





struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_fsp **); } fsp;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_gsp **); } gsp;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_top **); } top;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_vfn **); } vfn;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_pci **); } pci;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_bios **); } bios;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_devinit **); } devinit;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_subdev **); } privring;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_gpio **); } gpio;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_i2c **); } i2c;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_fuse **); } fuse;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_subdev **); } mxm;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_mc **); } mc;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_bus **); } bus;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_timer **); } timer;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_instmem **); } imem;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_fb **); } fb;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_ltc **); } ltc;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_mmu **); } mmu;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_bar **); } bar;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_fault **); } fault;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_acr **); } acr;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_pmu **); } pmu;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_volt **); } volt;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_iccsense **); } iccsense;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_therm **); } therm;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_clk **); } clk;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_subdev **); } ioctrl;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_subdev **); } fla;

struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } bsp;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } ce;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } cipher;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_disp **); } disp;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_dma **); } dma;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_fifo **); } fifo;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_gr **); } gr;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } ifb;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } me;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } mpeg;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } msenc;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } mspdec;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } msppp;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } msvld;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_nvdec **); } nvdec;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_nvenc **); } nvenc;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } nvjpg;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } ofa;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } sec;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_sec2 **); } sec2;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_sw **); } sw;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } vic;
struct { u32 inst; int (*ctor)(struct nvkm_device *, enum nvkm_subdev_type, int inst, struct nvkm_engine **); } vp;
};
struct nvkm_device_oclass {
 int (*ctor)(struct nvkm_device *, const struct nvkm_oclass *,
      void *data, u32 size, struct nvkm_object **);
 struct nvkm_sclass base;
};
enum nvkm_subdev_type {

NVKM_SUBDEV_FSP,
NVKM_SUBDEV_GSP,
NVKM_SUBDEV_TOP,
NVKM_SUBDEV_VFN,
NVKM_SUBDEV_PCI,
NVKM_SUBDEV_VBIOS,
NVKM_SUBDEV_DEVINIT,
NVKM_SUBDEV_PRIVRING,
NVKM_SUBDEV_GPIO,
NVKM_SUBDEV_I2C,
NVKM_SUBDEV_FUSE,
NVKM_SUBDEV_MXM,
NVKM_SUBDEV_MC,
NVKM_SUBDEV_BUS,
NVKM_SUBDEV_TIMER,
NVKM_SUBDEV_INSTMEM,
NVKM_SUBDEV_FB,
NVKM_SUBDEV_LTC,
NVKM_SUBDEV_MMU,
NVKM_SUBDEV_BAR,
NVKM_SUBDEV_FAULT,
NVKM_SUBDEV_ACR,
NVKM_SUBDEV_PMU,
NVKM_SUBDEV_VOLT,
NVKM_SUBDEV_ICCSENSE,
NVKM_SUBDEV_THERM,
NVKM_SUBDEV_CLK,
NVKM_SUBDEV_IOCTRL,
NVKM_SUBDEV_FLA,

NVKM_ENGINE_BSP,
NVKM_ENGINE_CE,
NVKM_ENGINE_CIPHER,
NVKM_ENGINE_DISP,
NVKM_ENGINE_DMAOBJ,
NVKM_ENGINE_FIFO,
NVKM_ENGINE_GR,
NVKM_ENGINE_IFB,
NVKM_ENGINE_ME,
NVKM_ENGINE_MPEG,
NVKM_ENGINE_MSENC,
NVKM_ENGINE_MSPDEC,
NVKM_ENGINE_MSPPP,
NVKM_ENGINE_MSVLD,
NVKM_ENGINE_NVDEC,
NVKM_ENGINE_NVENC,
NVKM_ENGINE_NVJPG,
NVKM_ENGINE_OFA,
NVKM_ENGINE_SEC,
NVKM_ENGINE_SEC2,
NVKM_ENGINE_SW,
NVKM_ENGINE_VIC,
NVKM_ENGINE_VP,
 NVKM_SUBDEV_NR
};
struct nvkm_subdev {
 const struct nvkm_subdev_func *func;
 struct nvkm_device *device;
 enum nvkm_subdev_type type;
 int inst;

 char name[16];
 u32 debug;

 struct {
  refcount_t refcount;
  struct mutex mutex;
  bool enabled;
 } use;

 struct nvkm_inth inth;

 struct list_head head;
 void **pself;
 bool oneinit;
};
struct nvkm_subdev_func {
 void *(*dtor)(struct nvkm_subdev *);
 int (*preinit)(struct nvkm_subdev *);
 int (*oneinit)(struct nvkm_subdev *);
 int (*info)(struct nvkm_subdev *, u64 mthd, u64 *data);
 int (*init)(struct nvkm_subdev *);
 int (*fini)(struct nvkm_subdev *, enum nvkm_suspend_state suspend);
 void (*intr)(struct nvkm_subdev *);
};
extern const char *nvkm_subdev_type[NVKM_SUBDEV_NR];
struct nvkm_devinit;
struct nvkm_devinit {
 const struct nvkm_devinit_func *func;
 struct nvkm_subdev subdev;
 bool post;
 bool force_post;
};
int ga100_devinit_new(struct nvkm_device *, enum nvkm_subdev_type, int, struct nvkm_devinit **);
int r535_devinit_new(const struct nvkm_devinit_func *,
       struct nvkm_device *, enum nvkm_subdev_type, int, struct nvkm_devinit **);
struct nvkm_devinit_func {
 void *(*dtor)(struct nvkm_devinit *);
 void (*preinit)(struct nvkm_devinit *);
 void (*init)(struct nvkm_devinit *);
 int (*post)(struct nvkm_devinit *, bool post);
 u32 (*mmio)(struct nvkm_devinit *, u32);
 void (*meminit)(struct nvkm_devinit *);
 int (*pll_set)(struct nvkm_devinit *, u32 type, u32 freq);
 void (*disable)(struct nvkm_devinit *);
};
int tu102_devinit_post(struct nvkm_devinit *, bool);
int nv50_devinit_new_(const struct nvkm_devinit_func *, struct nvkm_device *, enum nvkm_subdev_type,
        int, struct nvkm_devinit **);
void nv50_devinit_init(struct nvkm_devinit *);
struct nvkm_bios {
 struct nvkm_subdev subdev;
 u32 size;
 u8 *data;

 u32 image0_size;
 u32 imaged_addr;

 u32 bmp_offset;
 u32 bit_offset;

 struct {
  u8 major;
  u8 chip;
  u8 minor;
  u8 micro;
  u8 patch;
 } version;
};
struct nvkm_subdev;
struct nvkm_device;
struct nvkm_vma;
struct nvkm_vmm;
struct nvkm_tags {
 struct nvkm_mm_node *mn;
 refcount_t refcount;
};
enum nvkm_memory_target {
 NVKM_MEM_TARGET_INST_SR_LOST,
 NVKM_MEM_TARGET_INST,
 NVKM_MEM_TARGET_VRAM,
 NVKM_MEM_TARGET_HOST,
 NVKM_MEM_TARGET_NCOH,
};
struct nvkm_memory {
 const struct nvkm_memory_func *func;
 const struct nvkm_memory_ptrs *ptrs;
 struct kref kref;
 struct nvkm_tags *tags;
};
struct nvkm_memory_func {
 void *(*dtor)(struct nvkm_memory *);
 enum nvkm_memory_target (*target)(struct nvkm_memory *);
 u8 (*page)(struct nvkm_memory *);
 u64 (*bar2)(struct nvkm_memory *);
 u64 (*addr)(struct nvkm_memory *);
 u64 (*size)(struct nvkm_memory *);
 void (*boot)(struct nvkm_memory *, struct nvkm_vmm *);
 void *(*acquire)(struct nvkm_memory *);
 void (*release)(struct nvkm_memory *);
 int (*map)(struct nvkm_memory *, u64 offset, struct nvkm_vmm *,
     struct nvkm_vma *, void *argv, u32 argc);
 int (*kmap)(struct nvkm_memory *, struct nvkm_memory **);
};
struct nvkm_memory_ptrs {
 u32 (*rd32)(struct nvkm_memory *, u64 offset);
 void (*wr32)(struct nvkm_memory *, u64 offset, u32 data);
};
struct nvkm_firmware {
 const struct nvkm_firmware_func {
  enum nvkm_firmware_type {
   NVKM_FIRMWARE_IMG_RAM,
   NVKM_FIRMWARE_IMG_DMA,
   NVKM_FIRMWARE_IMG_SGT,
  } type;
 } *func;
 const char *name;
 struct nvkm_device *device;

 int len;
 u8 *img;
 u64 phys;

 struct nvkm_firmware_mem {
  struct nvkm_memory memory;
  union {
   struct scatterlist sgl;
   struct sg_table sgt;
  };
 } mem;
};
struct nvkm_chan;
struct nvkm_fb_tile;
extern const struct nvkm_subdev_func nvkm_engine;
struct nvkm_engine {
 const struct nvkm_engine_func *func;
 struct nvkm_subdev subdev;
 spinlock_t lock;
};
struct nvkm_engine_func {
 void *(*dtor)(struct nvkm_engine *);
 void (*preinit)(struct nvkm_engine *);
 int (*oneinit)(struct nvkm_engine *);
 int (*info)(struct nvkm_engine *, u64 mthd, u64 *data);
 int (*init)(struct nvkm_engine *);
 int (*fini)(struct nvkm_engine *, enum nvkm_suspend_state suspend);
 int (*reset)(struct nvkm_engine *);
 int (*nonstall)(struct nvkm_engine *);
 void (*intr)(struct nvkm_engine *);
 void (*tile)(struct nvkm_engine *, int region, struct nvkm_fb_tile *);
 bool (*chsw_load)(struct nvkm_engine *);

 struct {
  int (*sclass)(struct nvkm_oclass *, int index,
         const struct nvkm_device_oclass **);
 } base;

 struct {
  int (*cclass)(struct nvkm_chan *, const struct nvkm_oclass *,
         struct nvkm_object **);
  int (*sclass)(struct nvkm_oclass *, int index);
 } fifo;

 const struct nvkm_object_func *cclass;
 struct nvkm_sclass sclass[1];
};
struct nvkm_chan;
struct nvkm_falcon {
 const struct nvkm_falcon_func *func;
 struct nvkm_subdev *owner;
 const char *name;
 u32 addr;
 u32 addr2;

 struct mutex mutex;
 struct mutex dmem_mutex;
 bool oneinit;

 struct nvkm_subdev *user;

 u8 version;
 u8 secret;
 bool debug;

 struct nvkm_memory *core;
 bool external;

 struct {
  u32 limit;
  u32 *data;
  u32 size;
  u8 ports;
 } code;

 struct {
  u32 limit;
  u32 *data;
  u32 size;
  u8 ports;
 } data;

 struct nvkm_engine engine;
};
struct nvkm_falcon_func {
 int (*disable)(struct nvkm_falcon *);
 int (*enable)(struct nvkm_falcon *);
 int (*select)(struct nvkm_falcon *);
 u32 addr2;
 u32 riscv_irqmask;
 bool reset_pmc;
 int (*reset_eng)(struct nvkm_falcon *);
 int (*reset_prep)(struct nvkm_falcon *);
 int (*reset_wait_mem_scrubbing)(struct nvkm_falcon *);

 u32 debug;
 void (*bind_inst)(struct nvkm_falcon *, int target, u64 addr);
 int (*bind_stat)(struct nvkm_falcon *, bool intr);
 bool bind_intr;

 const struct nvkm_falcon_func_pio *imem_pio;
 const struct nvkm_falcon_func_dma *imem_dma;

 const struct nvkm_falcon_func_pio *dmem_pio;
 const struct nvkm_falcon_func_dma *dmem_dma;

 u32 emem_addr;
 const struct nvkm_falcon_func_pio *emem_pio;

 struct {
  u32 head;
  u32 tail;
  u32 stride;
 } cmdq, msgq;

 bool (*riscv_active)(struct nvkm_falcon *);
 void (*intr_retrigger)(struct nvkm_falcon *);

 struct {
  u32 *data;
  u32 size;
 } code;
 struct {
  u32 *data;
  u32 size;
 } data;
 void (*init)(struct nvkm_falcon *);
 void (*intr)(struct nvkm_falcon *, struct nvkm_chan *);

 void (*load_imem)(struct nvkm_falcon *, void *, u32, u32, u16, u8, bool);
 void (*load_dmem)(struct nvkm_falcon *, void *, u32, u32, u8);
 void (*start)(struct nvkm_falcon *);

 struct nvkm_sclass sclass[1];
};
enum nvkm_falcon_mem {
 IMEM,
 DMEM,
 EMEM,
};
static inline    const char *
nvkm_falcon_mem(enum nvkm_falcon_mem mem)
;
struct nvkm_falcon_func_pio {
 int min;
 int max;
 void (*wr_init)(struct nvkm_falcon *, u8 port, bool sec, u32 mem_base);
 void (*wr)(struct nvkm_falcon *, u8 port, const u8 *img, int len, u16 tag);
 void (*rd_init)(struct nvkm_falcon *, u8 port, u32 mem_base);
 void (*rd)(struct nvkm_falcon *, u8 port, const u8 *img, int len);
};
struct nvkm_falcon_func_dma {
 int (*init)(struct nvkm_falcon *, u64 dma_addr, int xfer_len,
      enum nvkm_falcon_mem, bool sec, u32 *cmd);
 void (*xfer)(struct nvkm_falcon *, u32 mem_base, u32 dma_base, u32 cmd);
 bool (*done)(struct nvkm_falcon *);
};
struct nvkm_falcon_fw {
 const struct nvkm_falcon_fw_func {
  int (*signature)(struct nvkm_falcon_fw *, u32 *sig_base_src);
  int (*reset)(struct nvkm_falcon_fw *);
  int (*setup)(struct nvkm_falcon_fw *);
  int (*load)(struct nvkm_falcon_fw *);
  int (*load_bld)(struct nvkm_falcon_fw *);
  int (*boot)(struct nvkm_falcon_fw *,
       u32 *mbox0, u32 *mbox1, u32 mbox0_ok, u32 irqsclr);
 } *func;
 struct nvkm_firmware fw;

 u32 sig_base_prd;
 u32 sig_base_dbg;
 u32 sig_base_img;
 u32 sig_size;
 int sig_nr;
 u8 *sigs;
 u32 fuse_ver;
 u32 engine_id;
 u32 ucode_id;

 u32 nmem_base_img;
 u32 nmem_base;
 u32 nmem_size;

 u32 imem_base_img;
 u32 imem_base;
 u32 imem_size;

 u32 dmem_base_img;
 u32 dmem_base;
 u32 dmem_size;
 u32 dmem_sign;

 u8 *boot;
 u32 boot_size;
 u32 boot_addr;

 struct nvkm_falcon *falcon;
 struct nvkm_memory *inst;
 struct nvkm_vmm *vmm;
 struct nvkm_vma *vma;
};
struct device;
struct file_operations;
struct debugfs_blob_wrapper {
 void *data;
 unsigned long size;
};
struct nvkm_gsp_mem {
 struct device *dev;
 size_t size;
 void *data;
 dma_addr_t addr;
};
struct nvkm_gsp_radix3 {
 struct nvkm_gsp_mem lvl0;
 struct nvkm_gsp_mem lvl1;
 struct sg_table lvl2;
};
typedef int (*nvkm_gsp_msg_ntfy_func)(void *priv, u32 fn, void *repv, u32 repc);
struct nvkm_gsp_event;
typedef void (*nvkm_gsp_event_func)(struct nvkm_gsp_event *, void *repv, u32 repc);
enum nvkm_gsp_rpc_reply_policy {
 NVKM_GSP_RPC_REPLY_NOWAIT = 0,
 NVKM_GSP_RPC_REPLY_NOSEQ,
 NVKM_GSP_RPC_REPLY_RECV,
 NVKM_GSP_RPC_REPLY_POLL,
};
struct nvkm_gsp {
 const struct nvkm_gsp_func *func;
 struct nvkm_subdev subdev;

 struct nvkm_falcon falcon;

 struct {
  struct {
   const struct firmware *load;
   const struct firmware *unload;
  } booter;

  const struct firmware *fmc;

  const struct firmware *bl;
  const struct firmware *rm;

  struct {
   struct nvkm_falcon_fw sb;
  } falcon;
 } fws;

 struct nvkm_firmware fw;
 struct nvkm_gsp_mem sig;
 struct nvkm_gsp_radix3 radix3;

 struct {
  struct {
   struct {
    u64 addr;
    u64 size;
   } vga_workspace;
   u64 addr;
   u64 size;
  } bios;
  struct {
   struct {
    u64 addr;
    u64 size;
   } frts, boot, elf, heap;
   u64 addr;
   u64 size;
  } wpr2;
  struct {
   u64 addr;
   u64 size;
  } heap;
  u64 addr;
  u64 size;

  struct {
   u64 addr;
   u64 size;
  } region[16];
  int region_nr;
  u32 rsvd_size;
 } fb;

 struct {
  struct nvkm_falcon_fw load;
  struct nvkm_falcon_fw unload;
 } booter;

 struct {
  struct nvkm_gsp_mem fw;
  u8 *hash;
  u8 *pkey;
  u8 *sig;

  struct nvkm_gsp_mem args;
 } fmc;

 struct {
  struct nvkm_gsp_mem fw;
  u32 code_offset;
  u32 data_offset;
  u32 manifest_offset;
  u32 app_version;
 } boot;

 struct nvkm_gsp_mem libos;
 struct nvkm_gsp_mem loginit;
 struct nvkm_gsp_mem logintr;
 struct nvkm_gsp_mem logrm;
 struct nvkm_gsp_mem rmargs;

 struct nvkm_gsp_mem wpr_meta;

 struct {
  struct sg_table sgt;
  struct nvkm_gsp_radix3 radix3;
  struct nvkm_gsp_mem meta;
  struct sg_table fbsr;
 } sr;

 struct {
  struct nvkm_gsp_mem mem;

  struct {
   int nr;
   u32 size;
   u64 *ptr;
  } ptes;

  struct {
   u32 size;
   void *ptr;
  } cmdq, msgq;
 } shm;

 struct nvkm_gsp_cmdq {
  struct mutex mutex;
  u32 cnt;
  u32 seq;
  u32 *wptr;
  u32 *rptr;
 } cmdq;

 struct nvkm_gsp_msgq {
  struct mutex mutex;
  u32 cnt;
  u32 *wptr;
  u32 *rptr;
  struct nvkm_gsp_msgq_ntfy {
   u32 fn;
   nvkm_gsp_msg_ntfy_func func;
   void *priv;
  } ntfy[16];
  int ntfy_nr;
  struct work_struct work;
 } msgq;

 bool running;


 struct {
  struct nvkm_gsp_client {
   struct nvkm_gsp_object {
    struct nvkm_gsp_client *client;
    struct nvkm_gsp_object *parent;
    u32 handle;
   } object;

   struct nvkm_gsp *gsp;

   struct list_head events;
  } client;

  struct nvkm_gsp_device {
   struct nvkm_gsp_object object;
   struct nvkm_gsp_object subdevice;
  } device;
 } internal;

 struct {
  enum nvkm_subdev_type type;
  int inst;
  u32 stall;
  u32 nonstall;
 } intr[32];
 int intr_nr;

 struct {
  u64 rm_bar1_pdb;
  u64 rm_bar2_pdb;
 } bar;

 struct {
  u8 gpcs;
  u8 tpcs;
 } gr;

 struct nvkm_rm *rm;

 struct {
  struct mutex mutex;
  struct idr idr;
 } client_id;


 struct list_head registry_list;


 size_t registry_rpc_size;

 u32 rpc_seq;






 struct {
  struct dentry *parent;
  struct dentry *init;
  struct dentry *rm;
  struct dentry *intr;
  struct dentry *pmu;
 } debugfs;
 struct debugfs_blob_wrapper blob_init;
 struct debugfs_blob_wrapper blob_intr;
 struct debugfs_blob_wrapper blob_rm;
 struct debugfs_blob_wrapper blob_pmu;

};
static inline    bool
nvkm_gsp_rm(struct nvkm_gsp *gsp)
;
struct nvkm_ior;
struct nvkm_outp;
struct r535_gr;
struct nvkm_rm {
 struct nvkm_device *device;
 const struct nvkm_rm_gpu *gpu;
 const struct nvkm_rm_wpr *wpr;
 const struct nvkm_rm_api *api;
};
struct nvkm_rm_wpr {
 u32 os_carveout_size;
 u32 base_size;
 u64 heap_size_min;
 u32 heap_size_non_wpr;
 u32 rsvd_size_pmu;
 bool offset_set_by_acr;
};
struct nvkm_rm_api {
 const struct nvkm_rm_api_gsp {
  void (*set_rmargs)(struct nvkm_gsp *, bool resume);
  int (*set_system_info)(struct nvkm_gsp *);
  int (*get_static_info)(struct nvkm_gsp *);
  bool (*xlat_mc_engine_idx)(u32 mc_engine_idx, enum nvkm_subdev_type *, int *inst);
  void (*drop_send_user_shared_data)(struct nvkm_gsp *);
  void (*drop_post_nocat_record)(struct nvkm_gsp *);
  u32 (*sr_data_size)(struct nvkm_gsp *);
 } *gsp;

 const struct nvkm_rm_api_rpc {
  void *(*get)(struct nvkm_gsp *, u32 fn, u32 argc);
  void *(*push)(struct nvkm_gsp *gsp, void *argv,
         enum nvkm_gsp_rpc_reply_policy policy, u32 repc);
  void (*done)(struct nvkm_gsp *gsp, void *repv);
 } *rpc;

 const struct nvkm_rm_api_ctrl {
  void *(*get)(struct nvkm_gsp_object *, u32 cmd, u32 params_size);
  int (*push)(struct nvkm_gsp_object *, void **params, u32 repc);
  void (*done)(struct nvkm_gsp_object *, void *params);
 } *ctrl;

 const struct nvkm_rm_api_alloc {
  void *(*get)(struct nvkm_gsp_object *, u32 oclass, u32 params_size);
  void *(*push)(struct nvkm_gsp_object *, void *params);
  void (*done)(struct nvkm_gsp_object *, void *params);

  int (*free)(struct nvkm_gsp_object *);
 } *alloc;

 const struct nvkm_rm_api_client {
  int (*ctor)(struct nvkm_gsp_client *, u32 handle);
 } *client;

 const struct nvkm_rm_api_device {
  int (*ctor)(struct nvkm_gsp_client *, struct nvkm_gsp_device *);
  void (*dtor)(struct nvkm_gsp_device *);

  struct {
   int (*ctor)(struct nvkm_gsp_device *, u32 handle, u32 id,
        nvkm_gsp_event_func, struct nvkm_gsp_event *);
   void (*dtor)(struct nvkm_gsp_event *);
  } event;
 } *device;

 const struct nvkm_rm_api_fbsr {
  int (*suspend)(struct nvkm_gsp *);
  void (*resume)(struct nvkm_gsp *);
 } *fbsr;

 const struct nvkm_rm_api_disp {
  int (*get_static_info)(struct nvkm_disp *);
  int (*get_supported)(struct nvkm_disp *, unsigned long *display_mask);
  int (*get_connect_state)(struct nvkm_disp *, unsigned display_id);
  int (*get_active)(struct nvkm_disp *, unsigned head, u32 *display_id);

  int (*bl_ctrl)(struct nvkm_disp *, unsigned display_id, bool set, int *val);

  struct {
   int (*get_caps)(struct nvkm_disp *, int *link_bw, bool *mst, bool *wm);
   int (*set_indexed_link_rates)(struct nvkm_outp *);
   int (*sst)(struct nvkm_ior *, int head, bool ef,
       u32 watermark, u32 hblanksym, u32 vblanksym);
   int (*vcpi)(struct nvkm_ior *, int head,
        u8 slot, u8 slot_nr, u16 pbn, u16 aligned_pbn);
  } dp;

  struct {
   int (*set_pushbuf)(struct nvkm_disp *, s32 oclass, int inst,
        struct nvkm_memory *);
   int (*dmac_alloc)(struct nvkm_disp *, u32 oclass, int inst, u32 put_offset,
       struct nvkm_gsp_object *);
  } chan;
 } *disp;

 const struct nvkm_rm_api_fifo {
  int (*xlat_rm_engine_type)(u32 rm_engine_type,
        enum nvkm_subdev_type *, int *nv2080_type);
  int (*ectx_size)(struct nvkm_fifo *);
  unsigned rsvd_chids;
  int (*rc_triggered)(void *priv, u32 fn, void *repv, u32 repc);
  struct {
   int (*alloc)(struct nvkm_gsp_device *, u32 handle,
         u32 nv2080_engine_type, u8 runq, bool priv, int chid,
         u64 inst_addr, u64 userd_addr, u64 mthdbuf_addr,
         struct nvkm_vmm *, u64 gpfifo_offset, u32 gpfifo_length,
         struct nvkm_gsp_object *);
  } chan;
 } *fifo;

 const struct nvkm_rm_api_engine {
  int (*alloc)(struct nvkm_gsp_object *chan, u32 handle, u32 class, int inst,
        struct nvkm_gsp_object *);
 } *ce, *nvdec, *nvenc, *nvjpg, *ofa;

 const struct nvkm_rm_api_gr {
  int (*get_ctxbufs_info)(struct r535_gr *);
  struct {
   int (*init)(struct r535_gr *);
   void (*fini)(struct r535_gr *);
  } scrubber;
 } *gr;
};
extern const struct nvkm_rm_api_gr r535_gr;
struct nvkm_gsp_event {
 struct nvkm_gsp_device *device;
 u32 id;
 nvkm_gsp_event_func func;

 struct nvkm_gsp_object object;

 struct list_head head;
};
static int
ga100_devinit_pll_set(struct nvkm_devinit *init, u32 type, u32 freq)
;
static void
ga100_devinit_disable(struct nvkm_devinit *init)
;
static const struct nvkm_devinit_func
ga100_devinit = {
 .disable = ga100_devinit_disable,
 .init = nv50_devinit_init,
 .post = tu102_devinit_post,
 .pll_set = ga100_devinit_pll_set,
};
/*@ requires true; ensures (\result == 0) == (*pinit != ((void *)0)); */

int
ga100_devinit_new(struct nvkm_device *device, enum nvkm_subdev_type type, int inst,
    struct nvkm_devinit **pinit)
{
 if (nvkm_gsp_rm(device->gsp))
  return r535_devinit_new(&ga100_devinit, device, type, inst, pinit);

 return nv50_devinit_new_(&ga100_devinit, device, type, inst, pinit);
}
