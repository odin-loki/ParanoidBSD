typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __size_t;
typedef __int32_t __clock_t;
typedef __int64_t __time_t;
typedef __int64_t __off_t;
typedef long __suseconds_t;
typedef unsigned char u_char;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int32_t int32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __clock_t clock_t;
typedef __off_t off_t;
typedef __size_t size_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
typedef __builtin_va_list va_list;
char *index(const char *, int) ;
typedef u_int path_id_t;
typedef u_int target_id_t;
typedef uint64_t lun_id_t;
struct cam_periph;
typedef struct {
 uint32_t priority;
 uint32_t generation;
 int index;
} cam_pinfo;
typedef enum {
 CAM_FLAG_NONE = 0x00,
 CAM_EXPECT_INQ_CHANGE = 0x01,
 CAM_RETRY_SELTO = 0x02
} cam_flags;
union ccb;
clock_t clock(void);
typedef enum {
 CAM_DEBUG_NONE = 0x00,
 CAM_DEBUG_INFO = 0x01,
 CAM_DEBUG_TRACE = 0x02,
 CAM_DEBUG_SUBTRACE = 0x04,
 CAM_DEBUG_CDB = 0x08,
 CAM_DEBUG_XPT = 0x10,
 CAM_DEBUG_PERIPH = 0x20,
 CAM_DEBUG_PROBE = 0x40
} cam_debug_flags;
struct scsi_inquiry_data
{
 uint8_t device;






 uint8_t dev_qual2;
 uint8_t version;

 uint8_t response_format;
 uint8_t additional_length;


 uint8_t spc3_flags;
 uint8_t spc2_flags;





 uint8_t flags;
 char vendor[8];
 char product[16];
 char revision[4];




 uint8_t vendor_specific0[20];



 uint8_t spi3data;
 uint8_t reserved2;



 uint8_t version1[2];
 uint8_t version2[2];
 uint8_t version3[2];
 uint8_t version4[2];
 uint8_t version5[2];
 uint8_t version6[2];
 uint8_t version7[2];
 uint8_t version8[2];

 uint8_t reserved3[22];

 uint8_t vendor_specific1[160];
};
struct scsi_sense_data
{
 uint8_t error_code;




 uint8_t sense_buf[252 - 1];






};
struct scsi_static_inquiry_pattern {
 uint8_t type;
 uint8_t media_type;
 char vendor[8 +1];
 char product[16 +1];
 char revision[4 +1];
};
struct ccb_scsiio;
struct cam_periph;
union ccb;
struct ata_params {
        u_int16_t config;

        u_int16_t cylinders;
        u_int16_t specconf;
        u_int16_t heads;
 u_int16_t obsolete4;
 u_int16_t obsolete5;
        u_int16_t sectors;
        u_int16_t vendor7[3];
        u_int8_t serial[20];
        u_int16_t retired20;
 u_int16_t retired21;
 u_int16_t obsolete22;
        u_int8_t revision[8];
        u_int8_t model[40];
        u_int16_t sectors_intr;
        u_int16_t tcg;
        u_int16_t capabilities1;

        u_int16_t capabilities2;
        u_int16_t retired_piomode;

        u_int16_t retired_dmamode;

        u_int16_t atavalid;

        u_int16_t current_cylinders;
        u_int16_t current_heads;
        u_int16_t current_sectors;
        u_int16_t current_size_1;
        u_int16_t current_size_2;
        u_int16_t multi;

        u_int16_t lba_size_1;
 u_int16_t lba_size_2;
 u_int16_t obsolete62;
        u_int16_t mwdmamodes;
        u_int16_t apiomodes;

        u_int16_t mwdmamin;
        u_int16_t mwdmarec;
        u_int16_t pioblind;
        u_int16_t pioiordy;
        u_int16_t support3;
 u_int16_t reserved70;
        u_int16_t rlsovlap;
        u_int16_t rlsservice;
 u_int16_t reserved73;
 u_int16_t reserved74;
        u_int16_t queue;

        u_int16_t satacapabilities;

        u_int16_t satacapabilities2;
        u_int16_t satasupport;
        u_int16_t sataenabled;

        u_int16_t version_major;
        u_int16_t version_minor;

 struct {
            u_int16_t command1;

            u_int16_t command2;

            u_int16_t extension;
 } __attribute__((__packed__)) support, enabled;

        u_int16_t udmamodes;
        u_int16_t erase_time;
        u_int16_t enhanced_erase_time;
        u_int16_t apm_value;
        u_int16_t master_passwd_revision;
        u_int16_t hwres;

        u_int16_t acoustic;

        u_int16_t stream_min_req_size;
        u_int16_t stream_transfer_time;
        u_int16_t stream_access_latency;
        u_int32_t stream_granularity;
        u_int16_t lba_size48_1;
 u_int16_t lba_size48_2;
 u_int16_t lba_size48_3;
 u_int16_t lba_size48_4;
 u_int16_t reserved104;
        u_int16_t max_dsm_blocks;
        u_int16_t pss;
        u_int16_t isd;
        u_int16_t wwn[4];
 u_int16_t reserved112[5];
        u_int16_t lss_1;
        u_int16_t lss_2;
        u_int16_t support2;
        u_int16_t enabled2;
 u_int16_t reserved121[6];
        u_int16_t removable_status;
        u_int16_t security_status;

 u_int16_t reserved129[31];
        u_int16_t cfa_powermode1;
 u_int16_t reserved161;
        u_int16_t cfa_kms_support;
        u_int16_t cfa_trueide_modes;
        u_int16_t cfa_memory_modes;
 u_int16_t reserved165[3];
        u_int16_t form_factor;
        u_int16_t support_dsm;
        u_int8_t product_id[8];
 u_int16_t reserved174[2];
        u_int8_t media_serial[60];
        u_int16_t sct;
 u_int16_t reserved207[2];
        u_int16_t lsalign;
        u_int16_t wrv_sectors_m3_1;
 u_int16_t wrv_sectors_m3_2;
        u_int16_t wrv_sectors_m2_1;
 u_int16_t wrv_sectors_m2_2;
        u_int16_t nv_cache_caps;
        u_int16_t nv_cache_size_1;
 u_int16_t nv_cache_size_2;
        u_int16_t media_rotation_rate;
 u_int16_t reserved218;
        u_int16_t nv_cache_opt;
        u_int16_t wrv_mode;
 u_int16_t reserved221;
        u_int16_t transport_major;
        u_int16_t transport_minor;
 u_int16_t reserved224[31];
        u_int16_t integrity;
} __attribute__((__packed__)) ;
struct ccb_ataio;
struct cam_periph;
union ccb;
struct ata_cmd {
 uint8_t flags;

 uint8_t command;
 uint8_t features;

 uint8_t lba_low;
 uint8_t lba_mid;
 uint8_t lba_high;
 uint8_t device;

 uint8_t lba_low_exp;
 uint8_t lba_mid_exp;
 uint8_t lba_high_exp;
 uint8_t features_exp;

 uint8_t sector_count;
 uint8_t sector_count_exp;
 uint8_t control;
};
struct ata_res {
 uint8_t flags;

 uint8_t status;
 uint8_t error;

 uint8_t lba_low;
 uint8_t lba_mid;
 uint8_t lba_high;
 uint8_t device;

 uint8_t lba_low_exp;
 uint8_t lba_mid_exp;
 uint8_t lba_high_exp;

 uint8_t sector_count;
 uint8_t sector_count_exp;
};
struct nvme_sgl_descriptor {
 uint64_t address;
 uint32_t length;
 uint8_t reserved[3];
 uint8_t type;
};
struct nvme_command {

 uint8_t opc;
 uint8_t fuse;
 uint16_t cid;


 uint32_t nsid;


 uint32_t rsvd2;
 uint32_t rsvd3;


 uint64_t mptr;


 union {
  struct {
   uint64_t prp1;
   uint64_t prp2;
  };
  struct nvme_sgl_descriptor sgl;
 };


 uint32_t cdw10;
 uint32_t cdw11;
 uint32_t cdw12;
 uint32_t cdw13;
 uint32_t cdw14;
 uint32_t cdw15;
} ;
struct nvme_completion {

 uint32_t cdw0;


 uint32_t rsvd1;


 uint16_t sqhd;
 uint16_t sqid;


 uint16_t cid;
 uint16_t status;
} ;
struct ccb_nvmeio;
struct mmc_data;
struct mmc_request;
struct mmc_command {
 uint32_t opcode;
 uint32_t arg;
 uint32_t resp[4];
 uint32_t flags;


 uint32_t retries;
 uint32_t error;
 struct mmc_data *data;
 struct mmc_request *mrq;
};
struct mmc_data {
 size_t len;
 size_t xfer_len;
 void *data;
 uint32_t flags;
 struct mmc_request *mrq;
 size_t block_size;
 size_t block_count;
};
struct mmc_request {
 struct mmc_command *cmd;
 struct mmc_command *stop;
 void (*done)(struct mmc_request *);
 void *done_data;
 uint32_t flags;
};
struct ccb_pathinq;
typedef enum {

 XPT_FC_QUEUED = 0x100,

 XPT_FC_USER_CCB = 0x200,
 XPT_FC_XPT_ONLY = 0x400,

 XPT_FC_DEV_QUEUED = 0x800 | XPT_FC_QUEUED,


 XPT_NOOP = 0x00,

 XPT_SCSI_IO = 0x01 | XPT_FC_DEV_QUEUED,

 XPT_GDEV_TYPE = 0x02,

 XPT_GDEVLIST = 0x03,

 XPT_PATH_INQ = 0x04,

 XPT_REL_SIMQ = 0x05,

 XPT_SASYNC_CB = 0x06,

 XPT_SDEV_TYPE = 0x07,

 XPT_SCAN_BUS = 0x08 | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,

 XPT_DEV_MATCH = 0x09 | XPT_FC_XPT_ONLY,

 XPT_DEBUG = 0x0a,

 XPT_PATH_STATS = 0x0b,

 XPT_GDEV_STATS = 0x0c,

 XPT_DEV_ADVINFO = 0x0e,

 XPT_ASYNC = 0x0f | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,


 XPT_ABORT = 0x10,

 XPT_RESET_BUS = 0x11 | XPT_FC_XPT_ONLY,

 XPT_RESET_DEV = 0x12 | XPT_FC_DEV_QUEUED,

 XPT_TERM_IO = 0x13,

 XPT_SCAN_LUN = 0x14 | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,

 XPT_GET_TRAN_SETTINGS = 0x15,




 XPT_SET_TRAN_SETTINGS = 0x16,




 XPT_CALC_GEOMETRY = 0x17,





 XPT_ATA_IO = 0x18 | XPT_FC_DEV_QUEUED,


 XPT_GET_SIM_KNOB_OLD = 0x18,

 XPT_SET_SIM_KNOB = 0x19,




 XPT_GET_SIM_KNOB = 0x1a,




 XPT_SMP_IO = 0x1b | XPT_FC_DEV_QUEUED,


 XPT_NVME_IO = 0x1c | XPT_FC_DEV_QUEUED,


 XPT_MMC_IO = 0x1d | XPT_FC_DEV_QUEUED,


 XPT_SCAN_TGT = 0x1e | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,


 XPT_NVME_ADMIN = 0x1f | XPT_FC_DEV_QUEUED,



 XPT_ENG_INQ = 0x20 | XPT_FC_XPT_ONLY,

 XPT_ENG_EXEC = 0x21 | XPT_FC_DEV_QUEUED,



 XPT_EN_LUN = 0x30,

 XPT_TARGET_IO = 0x31 | XPT_FC_DEV_QUEUED,

 XPT_ACCEPT_TARGET_IO = 0x32 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_CONT_TARGET_IO = 0x33 | XPT_FC_DEV_QUEUED,

 XPT_IMMED_NOTIFY = 0x34 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_NOTIFY_ACK = 0x35,

 XPT_IMMEDIATE_NOTIFY = 0x36 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_NOTIFY_ACKNOWLEDGE = 0x37 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_REPROBE_LUN = 0x38 | XPT_FC_QUEUED | XPT_FC_USER_CCB,


 XPT_MMC_SET_TRAN_SETTINGS = 0x40 | XPT_FC_DEV_QUEUED,
 XPT_MMC_GET_TRAN_SETTINGS = 0x41 | XPT_FC_DEV_QUEUED,


 XPT_VUNIQUE = 0x80
} xpt_opcode;
typedef enum {
 PROTO_UNKNOWN,
 PROTO_UNSPECIFIED,
 PROTO_SCSI,
 PROTO_ATA,
 PROTO_ATAPI,
 PROTO_SATAPM,
 PROTO_SEMB,
 PROTO_NVME,
 PROTO_MMCSD,
} cam_proto;
typedef enum {
 XPORT_UNKNOWN,
 XPORT_UNSPECIFIED,
 XPORT_SPI,
 XPORT_FC,
 XPORT_SSA,
 XPORT_USB,
 XPORT_PPB,
 XPORT_ATA,
 XPORT_SAS,
 XPORT_SATA,
 XPORT_ISCSI,
 XPORT_SRP,
 XPORT_NVME,
 XPORT_MMCSD,
 XPORT_NVMF,
 XPORT_UFSHCI,
} cam_xport;
typedef union {
 struct { struct ccb_hdr *le_next; struct ccb_hdr **le_prev; } le;
 struct { struct ccb_hdr *sle_next; } sle;
 struct { struct ccb_hdr *tqe_next; struct ccb_hdr **tqe_prev; } tqe;
 struct { struct ccb_hdr *stqe_next; } stqe;
} camq_entry;
typedef union {
 void *ptr;
 u_long field;
 uint8_t bytes[sizeof(uintptr_t)];
} ccb_priv_entry;
typedef union {
 ccb_priv_entry entries[2];
 uint8_t bytes[2 * sizeof(ccb_priv_entry)];
} ccb_ppriv_area;
typedef union {
 ccb_priv_entry entries[2];
 uint8_t bytes[2 * sizeof(ccb_priv_entry)];
} ccb_spriv_area;
typedef struct {
 struct timeval *etime;
 uintptr_t sim_data;
 uintptr_t periph_data;
} ccb_qos_area;
struct ccb_hdr {
 cam_pinfo pinfo;
 camq_entry xpt_links;
 camq_entry sim_links;
 camq_entry periph_links;

 uint16_t retry_count;
 uint16_t alloc_flags;




 void (*cbfcnp)(struct cam_periph *, union ccb *);

 xpt_opcode func_code;
 uint32_t status;
 struct cam_path *path;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 uint32_t flags;
 uint32_t xflags;
 ccb_ppriv_area periph_priv;
 ccb_spriv_area sim_priv;
 ccb_qos_area qos;
 uint32_t timeout;
 struct timeval softtimeout;
};
struct ccb_getdev {
 struct ccb_hdr ccb_h;
 cam_proto protocol;
 struct scsi_inquiry_data inq_data;
 struct ata_params ident_data;
 uint8_t serial_num[252];
 uint8_t inq_flags;
 uint8_t serial_num_len;
 void *padding[2];
};
struct ccb_getdevstats {
 struct ccb_hdr ccb_h;
 int dev_openings;
 int dev_active;
 int allocated;
 int queued;
 int held;



 int maxtags;



 int mintags;
 struct timeval last_reset;
};
typedef enum {
 CAM_GDEVLIST_LAST_DEVICE,
 CAM_GDEVLIST_LIST_CHANGED,
 CAM_GDEVLIST_MORE_DEVS,
 CAM_GDEVLIST_ERROR
} ccb_getdevlist_status_e;
struct ccb_getdevlist {
 struct ccb_hdr ccb_h;
 char periph_name[16];
 uint32_t unit_number;
 unsigned int generation;
 uint32_t index;
 ccb_getdevlist_status_e status;
};
typedef enum {
 PERIPH_MATCH_ANY = 0x000,
 PERIPH_MATCH_PATH = 0x001,
 PERIPH_MATCH_TARGET = 0x002,
 PERIPH_MATCH_LUN = 0x004,
 PERIPH_MATCH_NAME = 0x008,
 PERIPH_MATCH_UNIT = 0x010,
} periph_pattern_flags;
struct periph_match_pattern {
 char periph_name[16];
 uint32_t unit_number;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 periph_pattern_flags flags;
};
typedef enum {
 DEV_MATCH_ANY = 0x000,
 DEV_MATCH_PATH = 0x001,
 DEV_MATCH_TARGET = 0x002,
 DEV_MATCH_LUN = 0x004,
 DEV_MATCH_INQUIRY = 0x008,
 DEV_MATCH_DEVID = 0x010,
} dev_pattern_flags;
struct device_id_match_pattern {
 uint8_t id_len;
 uint8_t id[256];
};
struct device_match_pattern {
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 dev_pattern_flags flags;
 union {
  struct scsi_static_inquiry_pattern inq_pat;
  struct device_id_match_pattern devid_pat;
 } data;
};
typedef enum {
 BUS_MATCH_ANY = 0x000,
 BUS_MATCH_PATH = 0x001,
 BUS_MATCH_NAME = 0x002,
 BUS_MATCH_UNIT = 0x004,
 BUS_MATCH_BUS_ID = 0x008,
} bus_pattern_flags;
struct bus_match_pattern {
 path_id_t path_id;
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
 bus_pattern_flags flags;
};
union match_pattern {
 struct periph_match_pattern periph_pattern;
 struct device_match_pattern device_pattern;
 struct bus_match_pattern bus_pattern;
};
typedef enum {
 DEV_MATCH_PERIPH,
 DEV_MATCH_DEVICE,
 DEV_MATCH_BUS
} dev_match_type;
struct dev_match_pattern {
 dev_match_type type;
 union match_pattern pattern;
};
struct periph_match_result {
 char periph_name[16];
 uint32_t unit_number;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
};
typedef enum {
 DEV_RESULT_NOFLAG = 0x00,
 DEV_RESULT_UNCONFIGURED = 0x01
} dev_result_flags;
struct device_match_result {
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 cam_proto protocol;
 struct scsi_inquiry_data inq_data;
 struct ata_params ident_data;
 dev_result_flags flags;
};
struct bus_match_result {
 path_id_t path_id;
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
};
union match_result {
 struct periph_match_result periph_result;
 struct device_match_result device_result;
 struct bus_match_result bus_result;
};
struct dev_match_result {
 dev_match_type type;
 union match_result result;
};
typedef enum {
 CAM_DEV_MATCH_LAST,
 CAM_DEV_MATCH_MORE,
 CAM_DEV_MATCH_LIST_CHANGED,
 CAM_DEV_MATCH_SIZE_ERROR,
 CAM_DEV_MATCH_ERROR
} ccb_dev_match_status;
typedef enum {
 CAM_DEV_POS_NONE = 0x000,
 CAM_DEV_POS_BUS = 0x001,
 CAM_DEV_POS_TARGET = 0x002,
 CAM_DEV_POS_DEVICE = 0x004,
 CAM_DEV_POS_PERIPH = 0x008,
 CAM_DEV_POS_PDPTR = 0x010,
 CAM_DEV_POS_TYPEMASK = 0xf00,
 CAM_DEV_POS_EDT = 0x100,
 CAM_DEV_POS_PDRV = 0x200
} dev_pos_type;
struct ccb_dm_cookie {
 void *bus;
 void *target;
 void *device;
 void *periph;
 void *pdrv;
};
struct ccb_dev_position {
 u_int generations[4];
 dev_pos_type position_type;
 struct ccb_dm_cookie cookie;
};
struct ccb_dev_match {
 struct ccb_hdr ccb_h;
 ccb_dev_match_status status;
 uint32_t num_patterns;
 uint32_t pattern_buf_len;
 struct dev_match_pattern *patterns;
 uint32_t num_matches;
 uint32_t match_buf_len;
 struct dev_match_result *matches;
 struct ccb_dev_position pos;
};
struct ccb_pathinq_settings_spi {
 uint8_t ppr_options;
};
struct ccb_pathinq_settings_fc {
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t port;
 uint32_t bitrate;
};
struct ccb_pathinq_settings_sas {
 uint32_t bitrate;
};
struct ccb_pathinq_settings_nvme {
 uint32_t nsid;
 uint32_t domain;
 uint8_t bus;
 uint8_t slot;
 uint8_t function;
 uint8_t extra;
 char dev_name[52];
};
struct ccb_pathinq_settings_nvmf {
 uint32_t nsid;
 uint8_t trtype;
 char dev_name[52];
};
struct ccb_pathinq {
 struct ccb_hdr ccb_h;
 uint8_t version_num;
 uint8_t hba_inquiry;
 uint16_t target_sprt;
 uint32_t hba_misc;
 uint16_t hba_eng_cnt;

 uint8_t vuhba_flags[14];
 uint32_t max_target;
 uint32_t max_lun;
 uint32_t async_flags;
 path_id_t hpath_id;
 target_id_t initiator_id;
 char sim_vid[16];
 char hba_vid[16];
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
 uint32_t base_transfer_speed;
 cam_proto protocol;
 u_int protocol_version;
 cam_xport transport;
 u_int transport_version;
 union {
  struct ccb_pathinq_settings_spi spi;
  struct ccb_pathinq_settings_fc fc;
  struct ccb_pathinq_settings_sas sas;
  struct ccb_pathinq_settings_nvme nvme;
  struct ccb_pathinq_settings_nvmf nvmf;
  char ccb_pathinq_settings_opaque[128];
 } xport_specific;
 u_int maxio;
 uint16_t hba_vendor;
 uint16_t hba_device;
 uint16_t hba_subvendor;
 uint16_t hba_subdevice;
};
struct ccb_pathstats {
 struct ccb_hdr ccb_h;
 struct timeval last_reset;
};
typedef enum {
 SMP_FLAG_NONE = 0x00,
 SMP_FLAG_REQ_SG = 0x01,
 SMP_FLAG_RSP_SG = 0x02
} ccb_smp_pass_flags;
struct ccb_smpio {
 struct ccb_hdr ccb_h;
 uint8_t *smp_request;
 int smp_request_len;
 uint16_t smp_request_sglist_cnt;
 uint8_t *smp_response;
 int smp_response_len;
 uint16_t smp_response_sglist_cnt;
 ccb_smp_pass_flags flags;
};
typedef union {
 uint8_t *cdb_ptr;

 uint8_t cdb_bytes[16];
} cdb_t;
struct ccb_scsiio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 uint8_t *req_map;
 uint8_t *data_ptr;
 uint32_t dxfer_len;

 struct scsi_sense_data sense_data;
 uint8_t sense_len;
 uint8_t cdb_len;
 uint16_t sglist_cnt;
 uint8_t scsi_status;
 uint8_t sense_resid;
 uint32_t resid;
 cdb_t cdb_io;
 uint8_t *msg_ptr;
 uint16_t msg_len;
 uint8_t tag_action;





 uint8_t priority;
 u_int tag_id;
 u_int init_id;



};
struct ccb_ataio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct ata_cmd cmd;
 struct ata_res res;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint32_t resid;
 uint8_t ata_flags;
 uint8_t icc;
 uint32_t aux;
 uint32_t unused;
};
struct ccb_mmcio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct mmc_command cmd;
        struct mmc_command stop;
};
struct ccb_accept_tio {
 struct ccb_hdr ccb_h;
 cdb_t cdb_io;
 uint8_t cdb_len;
 uint8_t tag_action;
 uint8_t sense_len;
 uint8_t priority;
 u_int tag_id;
 u_int init_id;
 struct scsi_sense_data sense_data;
};
struct ccb_relsim {
 struct ccb_hdr ccb_h;
 uint32_t release_flags;
 uint32_t openings;
 uint32_t release_timeout;
 uint32_t qfrozen_cnt;
};
struct ccb_nvmeio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct nvme_command cmd;
 struct nvme_completion cpl;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint16_t sglist_cnt;
 uint16_t unused;
};
typedef void ac_callback_t (void *softc, uint32_t code,
       struct cam_path *path, void *args);
struct ccb_setasync {
 struct ccb_hdr ccb_h;
 uint32_t event_enable;
 ac_callback_t *callback;
 void *callback_arg;
};
struct ccb_setdev {
 struct ccb_hdr ccb_h;
 uint8_t dev_type;
};
struct ccb_abort {
 struct ccb_hdr ccb_h;
 union ccb *abort_ccb;
};
struct ccb_resetbus {
 struct ccb_hdr ccb_h;
};
struct ccb_resetdev {
 struct ccb_hdr ccb_h;
};
struct ccb_termio {
 struct ccb_hdr ccb_h;
 union ccb *termio_ccb;
};
typedef enum {
 CTS_TYPE_CURRENT_SETTINGS,
 CTS_TYPE_USER_SETTINGS
} cts_type;
struct ccb_trans_settings_scsi
{
 u_int valid;
 u_int flags;
};
struct ccb_trans_settings_ata
{
 u_int valid;
 u_int flags;
};
struct ccb_trans_settings_spi
{
 u_int valid;
 u_int flags;
 u_int sync_period;
 u_int sync_offset;
 u_int bus_width;
 u_int ppr_options;
};
struct ccb_trans_settings_fc {
 u_int valid;
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t port;
 uint32_t bitrate;
};
struct ccb_trans_settings_sas {
 u_int valid;
 uint32_t bitrate;
};
struct ccb_trans_settings_pata {
 u_int valid;
 int mode;
 u_int bytecount;
 u_int atapi;
 u_int caps;
};
struct ccb_trans_settings_sata {
 u_int valid;
 int mode;
 u_int bytecount;
 int revision;
 u_int pm_present;
 u_int tags;
 u_int atapi;
 u_int caps;
};
struct ccb_trans_settings_nvme
{
 u_int valid;
 uint32_t spec;
 uint32_t max_xfer;
 uint32_t caps;
 uint8_t lanes;
 uint8_t speed;
 uint8_t max_lanes;
 uint8_t max_speed;
};
struct ccb_trans_settings_nvmf
{
 u_int valid;
 uint8_t trtype;
};
struct ccb_trans_settings_ufshci
{
 u_int valid;




 uint32_t speed;
 uint8_t hs_gear;
 uint8_t tx_lanes;
 uint8_t rx_lanes;
 uint8_t max_hs_gear;
 uint8_t max_tx_lanes;
 uint8_t max_rx_lanes;
};
enum mmc_vdd {
 vdd_150 = 0, vdd_155, vdd_160, vdd_165, vdd_170, vdd_180,
 vdd_190, vdd_200, vdd_210, vdd_220, vdd_230, vdd_240, vdd_250,
 vdd_260, vdd_270, vdd_280, vdd_290, vdd_300, vdd_310, vdd_320,
 vdd_330, vdd_340, vdd_350, vdd_360
};
enum mmc_vccq {
 vccq_120 = 0, vccq_180, vccq_330
};
enum mmc_power_mode {
 power_off = 0, power_up, power_on
};
enum mmc_bus_mode {
 opendrain = 1, pushpull
};
enum mmc_chip_select {
 cs_dontcare = 0, cs_high, cs_low
};
enum mmc_bus_type {
 bus_type_default = 0, bus_type_spi
};
enum mmc_bus_width {
 bus_width_1 = 0, bus_width_4 = 2, bus_width_8 = 3
};
enum mmc_drv_type {
 drv_type_b = 0, drv_type_a, drv_type_c, drv_type_d
};
enum mmc_bus_timing {
 bus_timing_normal = 0, bus_timing_hs, bus_timing_uhs_sdr12,
 bus_timing_uhs_sdr25, bus_timing_uhs_sdr50, bus_timing_uhs_ddr50,
 bus_timing_uhs_sdr104, bus_timing_mmc_ddr52, bus_timing_mmc_hs200,
 bus_timing_mmc_hs400, bus_timing_mmc_hs400es, bus_timing_max =
 bus_timing_mmc_hs400es
};
struct mmc_ios {
 uint32_t clock;
 enum mmc_vdd vdd;
 enum mmc_vccq vccq;
 enum mmc_bus_type bus_type;
 enum mmc_bus_mode bus_mode;
 enum mmc_chip_select chip_select;
 enum mmc_bus_width bus_width;
 enum mmc_power_mode power_mode;
 enum mmc_bus_timing timing;
 enum mmc_drv_type drv_type;
};
struct ccb_trans_settings_mmc {
 struct mmc_ios ios;
 uint32_t ios_valid;

 uint32_t host_ocr;
 int host_f_min;
 int host_f_max;


 uint32_t host_caps;
 uint32_t host_max_data;
};
struct ccb_trans_settings {
 struct ccb_hdr ccb_h;
 cts_type type;
 cam_proto protocol;
 u_int protocol_version;
 cam_xport transport;
 u_int transport_version;
 union {
  u_int valid;
  struct ccb_trans_settings_ata ata;
  struct ccb_trans_settings_scsi scsi;
  struct ccb_trans_settings_nvme nvme;
  struct ccb_trans_settings_mmc mmc;
 } proto_specific;
 union {
  u_int valid;
  struct ccb_trans_settings_spi spi;
  struct ccb_trans_settings_fc fc;
  struct ccb_trans_settings_sas sas;
  struct ccb_trans_settings_pata ata;
  struct ccb_trans_settings_sata sata;
  struct ccb_trans_settings_nvme nvme;
  struct ccb_trans_settings_nvmf nvmf;
  struct ccb_trans_settings_ufshci ufshci;
 } xport_specific;
};
struct ccb_calc_geometry {
 struct ccb_hdr ccb_h;
 uint32_t block_size;
 uint64_t volume_size;
 uint32_t cylinders;
 uint8_t heads;
 uint8_t secs_per_track;
};
struct ccb_sim_knob_settings_spi {
 u_int valid;
 u_int initiator_id;
 u_int role;
};
struct ccb_sim_knob_settings_fc {
 u_int valid;
 uint64_t wwnn;
 uint64_t wwpn;
 u_int role;
};
struct ccb_sim_knob_settings_sas {
 u_int valid;
 uint64_t wwnn;
 u_int role;
};
struct ccb_sim_knob {
 struct ccb_hdr ccb_h;
 union {
  u_int valid;
  struct ccb_sim_knob_settings_spi spi;
  struct ccb_sim_knob_settings_fc fc;
  struct ccb_sim_knob_settings_sas sas;
  char pad[128];
 } xport_specific;
};
struct ccb_rescan {
 struct ccb_hdr ccb_h;
 cam_flags flags;
};
struct ccb_debug {
 struct ccb_hdr ccb_h;
 cam_debug_flags flags;
};
struct ccb_en_lun {
 struct ccb_hdr ccb_h;
 uint16_t grp6_len;
 uint16_t grp7_len;
 uint8_t enable;
};
struct ccb_immed_notify {
 struct ccb_hdr ccb_h;
 struct scsi_sense_data sense_data;
 uint8_t sense_len;
 uint8_t initiator_id;
 uint8_t message_args[7];
};
struct ccb_notify_ack {
 struct ccb_hdr ccb_h;
 uint16_t seq_id;
 uint8_t event;
};
struct ccb_immediate_notify {
 struct ccb_hdr ccb_h;
 u_int tag_id;
 u_int seq_id;
 u_int initiator_id;
 u_int arg;
};
struct ccb_notify_acknowledge {
 struct ccb_hdr ccb_h;
 u_int tag_id;
 u_int seq_id;
 u_int initiator_id;
 u_int arg;





};
typedef enum {
 EIT_BUFFER,
 EIT_LOSSLESS,
 EIT_LOSSY,
 EIT_ENCRYPT
} ei_type;
typedef enum {
 EAD_VUNIQUE,
 EAD_LZ1V1,
 EAD_LZ2V1,
 EAD_LZ2V2
} ei_algo;
struct ccb_eng_inq {
 struct ccb_hdr ccb_h;
 uint16_t eng_num;
 ei_type eng_type;
 ei_algo eng_algo;
 uint32_t eng_memeory;
};
struct ccb_eng_exec {
 struct ccb_hdr ccb_h;
 uint8_t *pdrv_ptr;
 uint8_t *req_map;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint8_t *engdata_ptr;
 uint16_t sglist_cnt;
 uint32_t dmax_len;
 uint32_t dest_len;
 int32_t src_resid;
 uint32_t timeout;
 uint16_t eng_num;
 uint16_t vu_flags;
};
struct ccb_dev_advinfo {
 struct ccb_hdr ccb_h;
 uint32_t flags;
 uint32_t buftype;

 off_t bufsiz;
 off_t provsiz;
 uint8_t *buf;
};
struct ccb_async {
 struct ccb_hdr ccb_h;
 uint32_t async_code;
 off_t async_arg_size;
 void *async_arg_ptr;
};
union ccb {
 struct ccb_hdr ccb_h;
 struct ccb_scsiio csio;
 struct ccb_getdev cgd;
 struct ccb_getdevlist cgdl;
 struct ccb_pathinq cpi;
 struct ccb_relsim crs;
 struct ccb_setasync csa;
 struct ccb_setdev csd;
 struct ccb_pathstats cpis;
 struct ccb_getdevstats cgds;
 struct ccb_dev_match cdm;
 struct ccb_trans_settings cts;
 struct ccb_calc_geometry ccg;
 struct ccb_sim_knob knob;
 struct ccb_abort cab;
 struct ccb_resetbus crb;
 struct ccb_resetdev crd;
 struct ccb_termio tio;
 struct ccb_accept_tio atio;
 struct ccb_scsiio ctio;
 struct ccb_en_lun cel;
 struct ccb_immed_notify cin;
 struct ccb_notify_ack cna;
 struct ccb_immediate_notify cin1;
 struct ccb_notify_acknowledge cna2;
 struct ccb_eng_inq cei;
 struct ccb_eng_exec cee;
 struct ccb_smpio smpio;
 struct ccb_rescan crcn;
 struct ccb_debug cdbg;
 struct ccb_ataio ataio;
 struct ccb_dev_advinfo cdai;
 struct ccb_async casync;
 struct ccb_nvmeio nvmeio;
 struct ccb_mmcio mmcio;
};
int csio_encode(struct ccb_scsiio *csio, const char *fmt, ...)
  ;
static int
do_encode(u_char *buff, size_t vec_max, size_t *used,
   int (*arg_get)(void *, char *), void *gethook, const char *fmt,
   va_list *ap)
;
/*@ requires csio != ((void *)0); ensures \result == -1 || \result == 0; */

int
csio_encode(struct ccb_scsiio *csio, const char *fmt, ...)
{
 va_list ap;
 int retval;

 if (csio == ((void *)0))
  return (0);

 __builtin_va_start((ap), (fmt));

 retval = do_encode(csio->data_ptr, csio->dxfer_len, ((void *)0), ((void *)0), ((void *)0),
     fmt, &ap);

 __builtin_va_end(ap);

 return (retval);
}
