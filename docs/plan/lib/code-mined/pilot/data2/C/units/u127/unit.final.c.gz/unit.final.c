typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __vm_size_t;
typedef __uint64_t __size_t;
typedef __int64_t __register_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint32_t __gid_t;
typedef __int32_t __lwpid_t;
typedef __uint16_t __mode_t;
typedef __int64_t __off_t;
typedef __int32_t __pid_t;
typedef __int64_t __sbintime_t;
typedef __int64_t __rlim_t;
typedef long __suseconds_t;
typedef __uint32_t __uid_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef char * caddr_t;
typedef __gid_t gid_t;
typedef __lwpid_t lwpid_t;
typedef __mode_t mode_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __register_t register_t;
typedef __rlim_t rlim_t;
typedef __sbintime_t sbintime_t;
typedef __size_t size_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __vm_offset_t vm_offset_t;
typedef __uint64_t vm_ooffset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __vm_size_t vm_size_t;
typedef __register_t syscallarg_t;
typedef struct _device *device_t;
typedef char vm_memattr_t;
typedef _Bool bool;
typedef struct __sigset {
 __uint32_t __bits[4];
} __sigset_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
struct timespec {
 time_t tv_sec;
 long tv_nsec;
};
typedef __sigset_t sigset_t;
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
struct priority {
 u_char pri_class;
 u_char pri_level;
 u_char pri_native;
 u_char pri_user;
};
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct region_descriptor;
extern const char version[];
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
 long ru_maxrss;
 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;
};
struct system_segment_descriptor {
 u_int64_t sd_lolimit:16;
 u_int64_t sd_lobase:24;
 u_int64_t sd_type:5;
 u_int64_t sd_dpl:2;
 u_int64_t sd_p:1;
 u_int64_t sd_hilimit:4;
 u_int64_t sd_xx0:3;
 u_int64_t sd_gran:1;
 u_int64_t sd_hibase:40 __attribute__((__packed__));
 u_int64_t sd_xx1:8;
 u_int64_t sd_mbz:5;
 u_int64_t sd_xx2:19;
} __attribute__((__packed__));
struct region_descriptor {
 uint64_t rd_limit:16;
 uint64_t rd_base:64 __attribute__((__packed__));
} __attribute__((__packed__));
struct amd64tss {
 u_int32_t tss_rsvd0;
 u_int64_t tss_rsp0 __attribute__((__packed__));
 u_int64_t tss_rsp1 __attribute__((__packed__));
 u_int64_t tss_rsp2 __attribute__((__packed__));
 u_int32_t tss_rsvd1;
 u_int32_t tss_rsvd2;
 u_int64_t tss_ist1 __attribute__((__packed__));
 u_int64_t tss_ist2 __attribute__((__packed__));
 u_int64_t tss_ist3 __attribute__((__packed__));
 u_int64_t tss_ist4 __attribute__((__packed__));
 u_int64_t tss_ist5 __attribute__((__packed__));
 u_int64_t tss_ist6 __attribute__((__packed__));
 u_int64_t tss_ist7 __attribute__((__packed__));
 u_int32_t tss_rsvd3;
 u_int32_t tss_rsvd4;
 u_int16_t tss_rsvd5;
 u_int16_t tss_iobase;
};
struct lock_object;
struct mtx;
struct proc;
struct thread;
struct tty;
struct ucred;
struct uio;
struct trapframe;
static __inline char *
index(const char *p, int ch)
;
struct cdev;
struct root_hold_token {
 int flags;
 const char *who;
 struct { struct root_hold_token *tqe_next; struct root_hold_token **tqe_prev; } list;
};
struct domainset;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
struct resource;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct lock_list_entry;
struct thread;
struct lock_profile_object;
struct lpohead { struct lock_profile_object *lh_first; };
typedef void task_fn_t(void *context, int pending);
struct task {
 struct { struct task *stqe_next; } ta_link;
 uint16_t ta_pending;
 uint8_t ta_priority;
 uint8_t ta_flags;
 task_fn_t *ta_func;
 void *ta_context;
};
struct proc;
struct thread;
typedef unsigned long bitstr_t;
struct thread;
union ccb;
struct bio;
struct uio;
struct cv {
 const char *cv_description;
 int cv_waiters;
};
struct lock_object;
struct sema {
 struct mtx sema_mtx;
 struct cv sema_cv;
 int sema_waiters;
 int sema_value;
};
int sema_value(struct sema *sema);
struct kevent {
 __uintptr_t ident;
 short filter;
 unsigned short flags;
 unsigned int fflags;
 __int64_t data;
 void *udata;
 __uint64_t ext[4];
};
struct knote;
struct klist { struct knote *slh_first; };
struct kqueue;
struct knlist {
 struct klist kl_list;
 void (*kl_lock)(void *);
 void (*kl_unlock)(void *);
 void (*kl_assert_lock)(void *, int);
 void *kl_lockarg;
 int kl_autodestroy;
};
struct kinfo_knote;
struct proc;
struct filterops {
 int f_isfd;
 int (*f_attach)(struct knote *kn);
 void (*f_detach)(struct knote *kn);
 int (*f_event)(struct knote *kn, long hint);
 void (*f_touch)(struct knote *kn, struct kevent *kev, u_long type);
 int (*f_userdump)(struct proc *p, struct knote *kn,
      struct kinfo_knote *kin);
 int (*f_copy)(struct knote *kn, struct proc *p1);
};
struct knote {
 struct { struct knote *sle_next; } kn_link;
 struct { struct knote *sle_next; } kn_selnext;
 struct knlist *kn_knlist;
 struct { struct knote *tqe_next; struct knote **tqe_prev; } kn_tqe;
 struct kqueue *kn_kq;
 struct kevent kn_kevent;
 void *kn_hook;
 int kn_hookid;
 int kn_status;
 int kn_influx;
 unsigned int kn_sfflags;
 int64_t kn_sdata;
 union {
  struct file *p_fp;
  struct proc *p_proc;
  struct kaiocb *p_aio;
  struct aioliojob *p_lio;
  struct prison *p_prison;
  void *p_v;
 } kn_ptr;
 const struct filterops *kn_fop;

};
struct thread;
struct proc;
struct knlist;
struct mtx;
void knote(struct knlist *list, long hint, int lockflags);
struct kexterr {
 int error;
 const char *msg;
 __uint64_t p1;
 __uint64_t p2;
 unsigned cat;
 unsigned src_line;
};
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
struct thread;
struct sigio {
 union {
  struct proc *siu_proc;
  struct pgrp *siu_pgrp;
 } sio_u;
 struct { struct sigio *sle_next; } sio_pgsigio;
 struct sigio **sio_myref;

 struct ucred *sio_ucred;
 pid_t sio_pgid;
};
struct sigiolst { struct sigio *slh_first; };
typedef struct sigaltstack stack_t;
struct sigaltstack {
 void *ss_sp;
 __size_t ss_size;
 int ss_flags;
};
union sigval {

 int sival_int;
 void *sival_ptr;

 int sigval_int;
 void *sigval_ptr;
};
typedef void __sighandler_t(int);
typedef struct __siginfo {
 int si_signo;
 int si_errno;






 int si_code;
 __pid_t si_pid;
 __uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 union {
  struct {
   int _trapno;
  } _fault;
  struct {
   int _timerid;
   int _overrun;
  } _timer;
  struct {
   int _mqd;
  } _mesgq;
  struct {
   long _band;
  } _poll;
  struct {
   int _syscall;



  } _capsicum;
  struct {
   long __spare1__;
   int __spare2__[7];
  } __spare__;
 } _reason;
} siginfo_t;
struct __siginfo;
typedef __sighandler_t *sig_t;
struct sigacts {
 sig_t ps_sigact[128];
 sigset_t ps_catchmask[128];
 sigset_t ps_sigonstack;
 sigset_t ps_sigintr;
 sigset_t ps_sigreset;
 sigset_t ps_signodefer;
 sigset_t ps_siginfo;
 sigset_t ps_sigignore;
 sigset_t ps_sigcatch;
 sigset_t ps_freebsd4;
 sigset_t ps_osigset;
 sigset_t ps_usertramp;
 int ps_flag;
 u_int ps_refcnt;
 struct mtx ps_mtx;
};
typedef struct ksiginfo {
 struct { struct ksiginfo *tqe_next; struct ksiginfo **tqe_prev; } ksi_link;
 siginfo_t ksi_info;
 int ksi_flags;
 struct sigqueue *ksi_sigq;
} ksiginfo_t;
typedef struct sigqueue {
 sigset_t sq_signals;
 sigset_t sq_kill;
 sigset_t sq_ptrace;
 struct { struct ksiginfo *tqh_first; struct ksiginfo **tqh_last; } sq_list;
 struct proc *sq_proc;
 int sq_flags;
} sigqueue_t;
struct pgrp;
struct proc;
struct sigio;
struct thread;
struct thread;
typedef uid_t au_id_t;
typedef pid_t au_asid_t;
typedef u_int64_t au_asflgs_t ;
struct au_tid_addr {
 u_int32_t at_port;
 u_int32_t at_type;
 u_int32_t at_addr[4];
};
typedef struct au_tid_addr au_tid_addr_t;
struct au_mask {
 unsigned int am_success;
 unsigned int am_failure;
};
typedef struct au_mask au_mask_t;
struct auditinfo_addr {
 au_id_t ai_auid;
 au_mask_t ai_mask;
 au_tid_addr_t ai_termid;
 au_asid_t ai_asid;
 au_asflgs_t ai_flags;
};
struct label;
struct loginclass;
struct prison;
struct uidinfo;
struct ucred {
 struct mtx cr_mtx;
 long cr_ref;
 u_int cr_users;
 u_int cr_flags;
 struct auditinfo_addr cr_audit;
 int cr_ngroups;
 uid_t cr_uid;
 uid_t cr_ruid;
 uid_t cr_svuid;
 gid_t cr_gid;
 gid_t cr_rgid;
 gid_t cr_svgid;
 struct uidinfo *cr_uidinfo;
 struct uidinfo *cr_ruidinfo;
 struct prison *cr_prison;
 struct loginclass *cr_loginclass;
 void *cr_pspare2[2];
 struct label *cr_label;
 gid_t *cr_groups;
 int cr_agroups;

 gid_t cr_smallgroups[16];
};
struct thread;
struct proc;
struct domainset;
struct domainset_ref {
 struct domainset * volatile dr_policy;
 unsigned int dr_iter;
};
struct fpacc87 {
 uint8_t fp_bytes[10];
};
struct xmmacc {
 uint8_t xmm_bytes[16];
};
struct envxmm {
 uint16_t en_cw;
 uint16_t en_sw;
 uint8_t en_tw;
 uint8_t en_zero;
 uint16_t en_opcode;
 uint64_t en_rip;
 uint64_t en_rdp;
 uint32_t en_mxcsr;
 uint32_t en_mxcsr_mask;
};
struct savefpu {
 struct envxmm sv_env;
 struct {
  struct fpacc87 fp_acc;
  uint8_t fp_pad[6];
 } sv_fp[8];
 struct xmmacc sv_xmm[16];
 uint8_t sv_pad[96];
} ;
struct pcb {
 register_t pcb_r15;
 register_t pcb_r14;
 register_t pcb_r13;
 register_t pcb_r12;
 register_t pcb_rbp;
 register_t pcb_rsp;
 register_t pcb_rbx;
 register_t pcb_rip;
 register_t pcb_fsbase;
 register_t pcb_gsbase;
 register_t pcb_kgsbase;
 register_t pcb_cr0;
 register_t pcb_cr2;
 register_t pcb_cr3;
 register_t pcb_cr4;
 register_t pcb_dr0;
 register_t pcb_dr1;
 register_t pcb_dr2;
 register_t pcb_dr3;
 register_t pcb_dr6;
 register_t pcb_dr7;

 struct region_descriptor pcb_gdt;
 struct region_descriptor pcb_idt;
 struct region_descriptor pcb_ldt;
 uint16_t pcb_tr;

 u_int pcb_flags;

 uint16_t pcb_initial_fpucw;


 caddr_t pcb_onfault;

 uint64_t pcb_saved_ucr3;


 struct amd64tss *pcb_tssp;


 register_t pcb_efer;
 register_t pcb_star;
 register_t pcb_lstar;
 register_t pcb_cstar;
 register_t pcb_sfmask;

 struct savefpu *pcb_save;

 register_t pcb_tlsbase;
 uint64_t pcb_pad[4];
};
struct trapframe;
struct proc_ldt {
 caddr_t ldt_base;
 int ldt_refcnt;
};
struct pmap_invl_gen {
 u_long gen;
 union {
  struct { struct pmap_invl_gen *le_next; struct pmap_invl_gen **le_prev; } link;
  struct {
   struct pmap_invl_gen *next;
   u_char saved_pri;
  };
 };
} ;
struct mdthread {
 int md_spinlock_count;
 register_t md_saved_flags;
 register_t md_spurflt_addr;
 struct pmap_invl_gen md_invl_gen;
 register_t md_efirt_tmp;
 int md_efirt_dis_pf;
 struct pcb md_pcb;
 vm_offset_t md_stack_base;
 void *md_usr_fpu_save;
};
struct mdproc {
 struct proc_ldt *md_ldt;
 struct system_segment_descriptor md_ldt_sd;
 u_int md_flags;
};
struct trapframe {
 register_t tf_rdi;
 register_t tf_rsi;
 register_t tf_rdx;
 register_t tf_rcx;
 register_t tf_r8;
 register_t tf_r9;
 register_t tf_rax;
 register_t tf_rbx;
 register_t tf_rbp;
 register_t tf_r10;
 register_t tf_r11;
 register_t tf_r12;
 register_t tf_r13;
 register_t tf_r14;
 register_t tf_r15;
 uint32_t tf_trapno;
 uint16_t tf_fs;
 uint16_t tf_gs;
 register_t tf_addr;
 uint32_t tf_flags;
 uint16_t tf_es;
 uint16_t tf_ds;

 register_t tf_err;
 register_t tf_rip;
 uint16_t tf_cs;
 uint16_t tf_fred_evinfo3;
 uint32_t tf_fred_zero2;
 register_t tf_rflags;

 register_t tf_rsp;
 uint16_t tf_ss;
 uint16_t tf_fred_evinfo1;
 uint32_t tf_fred_evinfo2;
};
struct session {
 u_int s_count;
 struct proc *s_leader;
 struct vnode *s_ttyvp;
 struct cdev_priv *s_ttydp;
 struct tty *s_ttyp;
 pid_t s_sid;

 char s_login[((((33)+((sizeof(long))-1))/(sizeof(long)))*(sizeof(long)))];
 struct mtx s_mtx;
};
struct pgrp {
 struct { struct pgrp *le_next; struct pgrp **le_prev; } pg_hash;
 struct { struct proc *lh_first; } pg_members;
 struct session *pg_session;
 struct sigiolst pg_sigiolst;
 pid_t pg_id;
 struct mtx pg_mtx;
 int pg_flags;
 struct sx pg_killsx;

};
struct pargs {
 u_int ar_ref;
 u_int ar_length;
 u_char ar_args[1];
};
struct cpuset;
struct filemon;
struct kaioinfo;
struct kaudit_record;
struct kcov_info;
struct kdtrace_proc;
struct kdtrace_thread;
struct kmsan_td;
struct kq_timer_cb_data;
struct mqueue_notifier;
struct proc;
struct procdesc;
struct racct;
struct sleepqueue;
struct thread;
struct trapframe;
struct turnstile;
struct vm_map_entry;
struct syscall_args {
 u_int code;
 u_int original_code;
 struct sysent *callp;
 register_t args[8];
};
struct rusage_ext {
 uint64_t rux_runtime;
 uint64_t rux_uticks;
 uint64_t rux_sticks;
 uint64_t rux_iticks;
 uint64_t rux_uu;
 uint64_t rux_su;
 uint64_t rux_tu;
};
struct thread {
 struct mtx *volatile td_lock;
 struct proc *td_proc;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_plist;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_runq;
 union {
  struct { struct thread *tqe_next; struct thread **tqe_prev; } td_slpq;
  struct thread *td_zombie;
 };
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_lockq;
 struct { struct thread *le_next; struct thread **le_prev; } td_hash;
 struct cpuset *td_cpuset;
 struct domainset_ref td_domain;
 struct seltd *td_sel;
 struct sleepqueue *td_sleepqueue;
 struct turnstile *td_turnstile;
 void *td_pad1;
 struct umtx_q *td_umtxq;
 lwpid_t td_tid;
 sigqueue_t td_sigqueue;
 u_char td_lend_user_pri;
 u_char td_allocdomain;
 u_char td_base_ithread_pri;
 struct kmsan_td *td_kmsan;


 int td_flags;
 int td_ast;
 int td_inhibitors;
 int td_pflags;
 int td_pflags2;
 int td_dupfd;
 int td_sqqueue;
 const void *td_wchan;
 const char *td_wmesg;
 volatile u_char td_owepreempt;
 u_char td_tsqueue;
 u_char _td_pad0[2];
 int td_locks;
 int td_rw_rlocks;
 int td_sx_slocks;
 int td_lk_slocks;
 struct lock_object *td_wantedlock;
 struct turnstile *td_blocked;
 const char *td_lockname;
 struct { struct turnstile *lh_first; } td_contested;
 struct lock_list_entry *td_sleeplocks;
 int td_intr_nesting_level;
 int td_pinned;
 struct ucred *td_realucred;
 struct ucred *td_ucred;
 struct plimit *td_limit;
 int td_slptick;
 int td_blktick;
 int td_swvoltick;
 int td_swinvoltick;
 u_int td_cow;
 struct rusage td_ru;
 struct rusage_ext td_rux;
 uint64_t td_incruntime;
 uint64_t td_runtime;
 u_int td_pticks;
 u_int td_sticks;
 u_int td_iticks;
 u_int td_uticks;
 int td_intrval;
 sigset_t td_oldsigmask;
 volatile u_int td_generation;
 stack_t td_sigstk;
 int td_xsig;
 u_long td_profil_addr;
 u_int td_profil_ticks;
 char td_name[19 + 1];
 struct file *td_fpop;
 int td_dbgflags;
 siginfo_t td_si;
 int td_ng_outbound;
 struct osd td_osd;
 struct vm_map_entry *td_map_def_user;
 pid_t td_dbg_forked;
 u_int td_no_sleeping;
 struct vnode *td_vp_reserved;
 void *td_su;
 sbintime_t td_sleeptimo;
 int td_rtcgen;
 int td_errno;
 size_t td_vslock_sz;
 struct kcov_info *td_kcov_info;
 long td_ucredref;
 struct kexterr td_kexterr;


 sigset_t td_sigmask;
 u_char td_rqindex;
 u_char td_base_pri;
 u_char td_priority;
 u_char td_pri_class;
 u_char td_user_pri;
 u_char td_base_user_pri;
 uint32_t td_pax;
 uintptr_t td_rb_list;
 uintptr_t td_rbp_list;
 uintptr_t td_rb_inact;
 struct syscall_args td_sa;

 void *td_sigblock_ptr;
 uint32_t td_sigblock_val;

 void *td_exterr_ptr;





 struct pcb *td_pcb;
 enum td_states {
  TDS_INACTIVE = 0x0,
  TDS_INHIBITED,
  TDS_CAN_RUN,
  TDS_RUNQ,
  TDS_RUNNING
 } td_state;

 union {
  syscallarg_t tdu_retval[2];
  off_t tdu_off;
 } td_uretoff;
 u_int td_cowgen;

 struct callout td_slpcallout;
 struct trapframe *td_frame;
 vm_offset_t td_kstack;
 u_short td_kstack_pages;
 u_short td_kstack_domain;
 volatile u_int td_critnest;
 struct mdthread td_md;
 struct kaudit_record *td_ar;
 struct lpohead td_lprof[2];
 struct kdtrace_thread *td_dtrace;
 struct vnet *td_vnet;
 const char *td_vnet_lpush;
 struct trapframe *td_intr_frame;
 struct proc *td_rfppwait_p;
 struct vm_page **td_ma;
 int td_ma_cnt;

 void *td_emuldata;
 int td_lastcpu;
 int td_oncpu;
 void *td_lkpi_task;
 int td_pmcpend;
 void *td_remotereq;
 off_t td_ktr_io_lim;



};
struct proc {
 struct { struct proc *le_next; struct proc **le_prev; } p_list;
 struct { struct thread *tqh_first; struct thread **tqh_last; } p_threads;
 struct mtx p_slock;
 struct ucred *p_ucred;
 struct filedesc *p_fd;
 struct filedesc_to_leader *p_fdtol;
 struct pwddesc *p_pd;
 struct pstats *p_stats;
 struct plimit *p_limit;
 struct callout p_limco;
 struct sigacts *p_sigacts;

 int p_flag;
 int p_flag2;
 enum p_states {
  PRS_NEW = 0,
  PRS_NORMAL,
  PRS_ZOMBIE
 } p_state;
 pid_t p_pid;
 struct { struct proc *le_next; struct proc **le_prev; } p_hash;
 struct { struct proc *le_next; struct proc **le_prev; } p_pglist;
 struct proc *p_pptr;
 struct { struct proc *le_next; struct proc **le_prev; } p_sibling;
 struct { struct proc *lh_first; } p_children;
 struct proc *p_reaper;
 struct { struct proc *lh_first; } p_reaplist;

 struct { struct proc *le_next; struct proc **le_prev; } p_reapsibling;

 struct mtx p_mtx;
 struct mtx p_statmtx;
 struct mtx p_itimmtx;
 struct mtx p_profmtx;
 struct ksiginfo *p_ksi;
 sigqueue_t p_sigqueue;
 pid_t p_oppid;


 struct vmspace *p_vmspace;
 u_int p_swtick;
 u_int p_cowgen;
 struct itimerval p_realtimer;
 struct rusage p_ru;
 struct rusage_ext p_rux;
 struct rusage_ext p_crux;
 int p_profthreads;
 volatile int p_exitthreads;
 int p_traceflag;
 struct ktr_io_params *p_ktrioparms;
 struct vnode *p_textvp;
 struct vnode *p_textdvp;
 char *p_binname;
 u_int p_lock;
 struct sigiolst p_sigiolst;
 int p_sigparent;
 int p_sig;
 u_int p_ptevents;
 struct kaioinfo *p_aioinfo;
 struct thread *p_singlethread;
 int p_suspcount;
 struct thread *p_xthread;
 int p_boundary_count;
 int p_pendingcnt;
 struct itimers *p_itimers;
 struct procdesc *p_procdesc;
 u_int p_treeflag;
 int p_pendingexits;
 struct filemon *p_filemon;
 int p_pdeathsig;



 u_int p_magic;
 int p_osrel;

 uint32_t p_fctl0;
 char p_comm[19 + 1];
 struct sysentvec *p_sysent;
 struct pargs *p_args;
 rlim_t p_cpulimit;
 signed char p_nice;
 int p_fibnum;
 uint32_t p_pax;
 pid_t p_reapsubtree;


 vm_offset_t p_usrstack;
 vm_offset_t p_psstrings;
 vm_offset_t p_timekeep_base;
 vm_offset_t p_shared_page_base;
 vm_offset_t p_sigcode_base;
 vm_offset_t p_vdso_base;
 uint64_t p_elf_flags;
 const void *p_elf_brandinfo;

 sbintime_t p_umtx_min_timeout;


 u_int p_xexit;
 u_int p_xsig;
 struct pgrp *p_pgrp;
 struct knlist *p_klist;
 int p_numthreads;
 struct mdproc p_md;
 struct callout p_itcallout;
 u_short p_acflag;
 struct proc *p_peers;
 struct proc *p_leader;
 void *p_emuldata;
 struct label *p_label;
 struct { struct ktr_request *stqh_first; struct ktr_request **stqh_last; } p_ktr;
 struct { struct mqueue_notifier *lh_first; } p_mqnotifier;
 struct kdtrace_proc *p_dtrace;
 struct cv p_pwait;
 struct racct *p_racct;
 int p_throttled;






 struct { struct proc *le_next; struct proc **le_prev; } p_orphan;
 struct { struct proc *lh_first; } p_orphans;

 struct { struct kq_timer_cb_data *tqh_first; struct kq_timer_cb_data **tqh_last; } p_kqtim_stop;
 struct { struct proc *le_next; struct proc **le_prev; } p_jaillist;
 u_int p_asig;
 u_int p_tree_refcnt;
 u_int p_execblock;
};
struct proc;
struct thread;
struct snapdata;
struct cdevsw;
struct file;
struct cdev {
 void *si_spare0;
 u_int si_flags;
 struct timespec si_atime;
 struct timespec si_ctime;
 struct timespec si_mtime;
 uid_t si_uid;
 gid_t si_gid;
 mode_t si_mode;
 struct ucred *si_cred;
 int si_drv0;
 int si_refcount;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_list;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_clone;
 struct { struct cdev *lh_first; } si_children;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_siblings;
 struct cdev *si_parent;
 struct mount *si_mountpt;
 void *si_drv1, *si_drv2;
 struct cdevsw *si_devsw;
 int si_iosize_max;
 u_long si_usecount;
 u_long si_threadcount;
 union {
  struct snapdata *__sid_snapdata;
 } __si_u;
 char si_name[255 + 1];
};
struct bio;
struct buf;
struct thread;
struct uio;
struct knote;
struct vm_object;
struct vnode;
typedef int d_open_t(struct cdev *dev, int oflags, int devtype, struct thread *td);
typedef int d_fdopen_t(struct cdev *dev, int oflags, struct thread *td, struct file *fp);
typedef int d_close_t(struct cdev *dev, int fflag, int devtype, struct thread *td);
typedef void d_strategy_t(struct bio *bp);
typedef int d_ioctl_t(struct cdev *dev, u_long cmd, caddr_t data,
        int fflag, struct thread *td);
typedef int d_read_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_write_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_poll_t(struct cdev *dev, int events, struct thread *td);
typedef int d_kqfilter_t(struct cdev *dev, struct knote *kn);
typedef int d_mmap_t(struct cdev *dev, vm_ooffset_t offset, vm_paddr_t *paddr,
       int nprot, vm_memattr_t *memattr);
typedef int d_mmap_single_t(struct cdev *cdev, vm_ooffset_t *offset,
    vm_size_t size, struct vm_object **object, int nprot);
typedef void d_purge_t(struct cdev *dev);
struct cdevsw {
 int d_version;
 u_int d_flags;
 const char *d_name;
 d_open_t *d_open;
 d_fdopen_t *d_fdopen;
 d_close_t *d_close;
 d_read_t *d_read;
 d_write_t *d_write;
 d_ioctl_t *d_ioctl;
 d_poll_t *d_poll;
 d_mmap_t *d_mmap;
 d_strategy_t *d_strategy;
 void *d_spare0;
 d_kqfilter_t *d_kqfilter;
 d_purge_t *d_purge;
 d_mmap_single_t *d_mmap_single;

 int32_t d_spare1[3];
 void *d_spare2[3];


 struct { struct cdev *lh_first; } d_devs;
 int d_spare3;
 union {
  struct cdevsw *gianttrick;
  struct { struct cdevsw *sle_next; } postfree_list;
 } __d_giant;
};
struct thread;
struct vm_map_entry;
struct vm_object;
struct ucred;
struct prison;
struct proc;
struct thread;
struct vm_offset_t;
struct vnode;
typedef struct ocs_softc ocs_t;
typedef ocs_t * ocs_os_handle_t;
extern int loglevel;
extern void _ocs_log(ocs_t *ocs, const char *func, int line, const char *fmt, ...);
typedef struct ocs_dma_s {



 void *virt;
 void *alloc;
 uintptr_t phys;
 size_t size;



 size_t len;
 bus_dma_tag_t tag;
 bus_dmamap_t map;
} ocs_dma_t;
typedef struct ocs_lock_s {
 struct mtx lock;
 char name[64];
} ocs_lock_t;
typedef struct ocs_lock_s ocs_rlock_t;
typedef struct {
 char name[32];
 struct sema sem;
} ocs_sem_t;
typedef bitstr_t ocs_bitmap_t;
typedef struct {
 struct callout callout;
 struct mtx lock;

 void (*func)(void *);
 void *data;
} ocs_timer_t;
typedef uint32_t ocs_atomic_t;
typedef struct ocs_thread_s ocs_thread_t;
typedef int32_t (*ocs_thread_fctn)(ocs_thread_t *mythread);
struct ocs_thread_s {
 struct thread *tcb;
 ocs_thread_fctn fctn;
 char *name;
 void *arg;
 ocs_atomic_t terminate;
 int32_t retval;
 uint32_t cpu_affinity;
};
typedef struct ocs_pci_reg_s {
 uint32_t rid;
 struct resource *res;
 bus_space_tag_t btag;
 bus_space_handle_t bhandle;
} ocs_pci_reg_t;
typedef void (*ocs_ref_release_t)(void *arg);
typedef struct ocs_ref_s {
 ocs_ref_release_t release;
 void *arg;
 uint32_t count;
} ocs_ref_t;
typedef struct ocs_list_s ocs_list_t;
struct ocs_list_s {
 uint32_t magic;
 ocs_list_t *next;
 ocs_list_t *prev;
 uint32_t offset;
};
typedef ocs_list_t ocs_list_link_t;
typedef struct ocs_array_s ocs_array_t;
typedef struct ocs_varray_s ocs_varray_t;
typedef struct ocs_cbuf_s ocs_cbuf_t;
typedef struct {
 ocs_t *ocs;
 ocs_list_t segment_list;
 uint8_t extendable:1;
 uint32_t allocation_length;
 uint32_t total_allocation_length;
 uint32_t max_allocation_length;
} ocs_textbuf_t;
typedef struct ocs_pool_s ocs_pool_t;
typedef struct sparse_vector_s {
 ocs_os_handle_t os;
 uint32_t max_idx;
 void **array;
} *sparse_vector_t;
typedef struct ocs_ramlog_s ocs_ramlog_t;
typedef void (*ocs_mgmt_get_list_handler)(ocs_textbuf_t *textbuf, void* object);
typedef void (*ocs_mgmt_get_all_handler)(ocs_textbuf_t *textbuf, void* object);
typedef int (*ocs_mgmt_get_handler)(ocs_textbuf_t *, char *parent, char *name, void *object);
typedef int (*ocs_mgmt_set_handler)(char *parent, char *name, char *value, void *object);
typedef int (*ocs_mgmt_exec_handler)(char *parent, char *action, void *arg_in, uint32_t arg_in_length,
          void *arg_out, uint32_t arg_out_length, void *object);
typedef struct ocs_mgmt_functions_s {
 ocs_mgmt_get_list_handler get_list_handler;
 ocs_mgmt_get_handler get_handler;
 ocs_mgmt_get_all_handler get_all_handler;
 ocs_mgmt_set_handler set_handler;
 ocs_mgmt_exec_handler exec_handler;
} ocs_mgmt_functions_t;
enum {
 OCS_SM_COMMON = 0,
 OCS_SM_DOMAIN,
 OCS_SM_PORT,
 OCS_SM_LOGIN,
 OCS_SM_LAST
};
typedef enum {

 OCS_EVT_ENTER = ((OCS_SM_COMMON) << 24),
 OCS_EVT_REENTER,
 OCS_EVT_EXIT,
 OCS_EVT_SHUTDOWN,
 OCS_EVT_ALL_CHILD_NODES_FREE,
 OCS_EVT_RESUME,
 OCS_EVT_TIMER_EXPIRED,


 OCS_EVT_RESPONSE = ((OCS_SM_DOMAIN) << 24),
 OCS_EVT_ERROR,

 OCS_EVT_DOMAIN_FOUND,
 OCS_EVT_DOMAIN_ALLOC_OK,
 OCS_EVT_DOMAIN_ALLOC_FAIL,
 OCS_EVT_DOMAIN_REQ_ATTACH,
 OCS_EVT_DOMAIN_ATTACH_OK,
 OCS_EVT_DOMAIN_ATTACH_FAIL,
 OCS_EVT_DOMAIN_LOST,
 OCS_EVT_DOMAIN_FREE_OK,
 OCS_EVT_DOMAIN_FREE_FAIL,
 OCS_EVT_HW_DOMAIN_REQ_ATTACH,
 OCS_EVT_HW_DOMAIN_REQ_FREE,


 OCS_EVT_SPORT_ALLOC_OK = ((OCS_SM_PORT) << 24),
 OCS_EVT_SPORT_ALLOC_FAIL,
 OCS_EVT_SPORT_ATTACH_OK,
 OCS_EVT_SPORT_ATTACH_FAIL,
 OCS_EVT_SPORT_FREE_OK,
 OCS_EVT_SPORT_FREE_FAIL,
 OCS_EVT_SPORT_TOPOLOGY_NOTIFY,
 OCS_EVT_HW_PORT_ALLOC_OK,
 OCS_EVT_HW_PORT_ALLOC_FAIL,
 OCS_EVT_HW_PORT_ATTACH_OK,
 OCS_EVT_HW_PORT_REQ_ATTACH,
 OCS_EVT_HW_PORT_REQ_FREE,
 OCS_EVT_HW_PORT_FREE_OK,


 OCS_EVT_SRRS_ELS_REQ_OK = ((OCS_SM_LOGIN) << 24),
 OCS_EVT_SRRS_ELS_CMPL_OK,
 OCS_EVT_SRRS_ELS_REQ_FAIL,
 OCS_EVT_SRRS_ELS_CMPL_FAIL,
 OCS_EVT_SRRS_ELS_REQ_RJT,
 OCS_EVT_NODE_ATTACH_OK,
 OCS_EVT_NODE_ATTACH_FAIL,
 OCS_EVT_NODE_FREE_OK,
 OCS_EVT_NODE_FREE_FAIL,
 OCS_EVT_ELS_FRAME,
 OCS_EVT_ELS_REQ_TIMEOUT,
 OCS_EVT_ELS_REQ_ABORTED,
 OCS_EVT_ABORT_ELS,
 OCS_EVT_ELS_ABORT_CMPL,

 OCS_EVT_ABTS_RCVD,

 OCS_EVT_NODE_MISSING,
 OCS_EVT_NODE_REFOUND,
 OCS_EVT_SHUTDOWN_IMPLICIT_LOGO,
 OCS_EVT_SHUTDOWN_EXPLICIT_LOGO,

 OCS_EVT_PLOGI_RCVD,
 OCS_EVT_FLOGI_RCVD,
 OCS_EVT_LOGO_RCVD,
 OCS_EVT_RRQ_RCVD,
 OCS_EVT_PRLI_RCVD,
 OCS_EVT_PRLO_RCVD,
 OCS_EVT_PDISC_RCVD,
 OCS_EVT_FDISC_RCVD,
 OCS_EVT_ADISC_RCVD,
 OCS_EVT_RSCN_RCVD,
 OCS_EVT_SCR_RCVD,
 OCS_EVT_ELS_RCVD,

 OCS_EVT_FCP_CMD_RCVD,


 OCS_EVT_RFT_ID_RCVD,
 OCS_EVT_RFF_ID_RCVD,
 OCS_EVT_GNN_ID_RCVD,
 OCS_EVT_GPN_ID_RCVD,
 OCS_EVT_GFPN_ID_RCVD,
 OCS_EVT_GFF_ID_RCVD,
 OCS_EVT_GID_FT_RCVD,
 OCS_EVT_GID_PT_RCVD,
 OCS_EVT_RPN_ID_RCVD,
 OCS_EVT_RNN_ID_RCVD,
 OCS_EVT_RCS_ID_RCVD,
 OCS_EVT_RSNN_NN_RCVD,
 OCS_EVT_RSPN_ID_RCVD,
 OCS_EVT_RHBA_RCVD,
 OCS_EVT_RPA_RCVD,

 OCS_EVT_GIDPT_DELAY_EXPIRED,


 OCS_EVT_ABORT_IO,
 OCS_EVT_ABORT_IO_NO_RESP,
 OCS_EVT_IO_CMPL,
 OCS_EVT_IO_CMPL_ERRORS,
 OCS_EVT_RESP_CMPL,
 OCS_EVT_ABORT_CMPL,
 OCS_EVT_NODE_ACTIVE_IO_LIST_EMPTY,
 OCS_EVT_NODE_DEL_INI_COMPLETE,
 OCS_EVT_NODE_DEL_TGT_COMPLETE,
 OCS_EVT_IO_ABORTED_BY_TMF,
 OCS_EVT_IO_ABORT_IGNORED,
 OCS_EVT_IO_FIRST_BURST,
 OCS_EVT_IO_FIRST_BURST_ERR,
 OCS_EVT_IO_FIRST_BURST_ABORTED,


 OCS_EVT_LAST
} ocs_sm_event_t;
typedef struct ocs_sm_ctx_s ocs_sm_ctx_t;
typedef void *(*ocs_sm_function_t)(ocs_sm_ctx_t *, ocs_sm_event_t, void *);
struct ocs_sm_ctx_s {
 ocs_sm_function_t current_state;
 const char *description;
 void *app;
};
typedef enum {
 NO_ERR_INJECT = 0,
 INJECT_DROP_CMD,
 INJECT_FREE_DROPPED,
 INJECT_DROP_DATA,
 INJECT_DROP_RESP,
 INJECT_DELAY_CMD,
} ocs_err_injection_e;
typedef enum {OCS_XPORT_FC, OCS_XPORT_ISCSI} ocs_xport_e;
typedef struct ocs_hw_s ocs_hw_t;
typedef struct ocs_domain_s ocs_domain_t;
typedef struct ocs_sli_port_s ocs_sli_port_t;
typedef struct ocs_sli_port_s ocs_sport_t;
typedef struct ocs_remote_node_s ocs_remote_node_t;
typedef struct ocs_remote_node_group_s ocs_remote_node_group_t;
typedef struct ocs_node_s ocs_node_t;
typedef struct ocs_io_s ocs_io_t;
typedef struct ocs_xport_s ocs_xport_t;
typedef struct ocs_node_cb_s ocs_node_cb_t;
typedef struct ocs_ns_s ocs_ns_t;
typedef struct ocs_node_group_dir_s ocs_node_group_dir_t;
typedef u_int path_id_t;
typedef u_int target_id_t;
typedef uint64_t lun_id_t;
struct cam_periph;
typedef struct {
 uint32_t priority;
 uint32_t generation;
 int index;
} cam_pinfo;
typedef enum {
 CAM_FLAG_NONE = 0x00,
 CAM_EXPECT_INQ_CHANGE = 0x01,
 CAM_RETRY_SELTO = 0x02
} cam_flags;
union ccb;
struct cam_sim;
struct cam_devq;
typedef void (*sim_action_func)(struct cam_sim *sim, union ccb *ccb);
typedef void (*sim_poll_func)(struct cam_sim *sim);
struct cam_sim {
 sim_action_func sim_action;
 sim_poll_func sim_poll;
 const char *sim_name;
 void *softc;
 struct mtx *mtx;
 struct { struct cam_sim *tqe_next; struct cam_sim **tqe_prev; } links;
 uint32_t path_id;
 uint32_t unit_number;
 uint32_t bus_id;
 int max_tagged_dev_openings;
 int max_dev_openings;
 uint32_t flags;
 struct cam_devq *devq;
 int refcount;
};
typedef enum {
 CAM_DEBUG_NONE = 0x00,
 CAM_DEBUG_INFO = 0x01,
 CAM_DEBUG_TRACE = 0x02,
 CAM_DEBUG_SUBTRACE = 0x04,
 CAM_DEBUG_CDB = 0x08,
 CAM_DEBUG_XPT = 0x10,
 CAM_DEBUG_PERIPH = 0x20,
 CAM_DEBUG_PROBE = 0x40
} cam_debug_flags;
struct scsi_inquiry_data
{
 uint8_t device;






 uint8_t dev_qual2;
 uint8_t version;

 uint8_t response_format;
 uint8_t additional_length;


 uint8_t spc3_flags;
 uint8_t spc2_flags;





 uint8_t flags;
 char vendor[8];
 char product[16];
 char revision[4];




 uint8_t vendor_specific0[20];



 uint8_t spi3data;
 uint8_t reserved2;



 uint8_t version1[2];
 uint8_t version2[2];
 uint8_t version3[2];
 uint8_t version4[2];
 uint8_t version5[2];
 uint8_t version6[2];
 uint8_t version7[2];
 uint8_t version8[2];

 uint8_t reserved3[22];

 uint8_t vendor_specific1[160];
};
struct scsi_sense_data
{
 uint8_t error_code;




 uint8_t sense_buf[252 - 1];






};
struct scsi_static_inquiry_pattern {
 uint8_t type;
 uint8_t media_type;
 char vendor[8 +1];
 char product[16 +1];
 char revision[4 +1];
};
struct ccb_scsiio;
struct cam_periph;
union ccb;
struct ata_params {
        u_int16_t config;

        u_int16_t cylinders;
        u_int16_t specconf;
        u_int16_t heads;
 u_int16_t obsolete4;
 u_int16_t obsolete5;
        u_int16_t sectors;
        u_int16_t vendor7[3];
        u_int8_t serial[20];
        u_int16_t retired20;
 u_int16_t retired21;
 u_int16_t obsolete22;
        u_int8_t revision[8];
        u_int8_t model[40];
        u_int16_t sectors_intr;
        u_int16_t tcg;
        u_int16_t capabilities1;

        u_int16_t capabilities2;
        u_int16_t retired_piomode;

        u_int16_t retired_dmamode;

        u_int16_t atavalid;

        u_int16_t current_cylinders;
        u_int16_t current_heads;
        u_int16_t current_sectors;
        u_int16_t current_size_1;
        u_int16_t current_size_2;
        u_int16_t multi;

        u_int16_t lba_size_1;
 u_int16_t lba_size_2;
 u_int16_t obsolete62;
        u_int16_t mwdmamodes;
        u_int16_t apiomodes;

        u_int16_t mwdmamin;
        u_int16_t mwdmarec;
        u_int16_t pioblind;
        u_int16_t pioiordy;
        u_int16_t support3;
 u_int16_t reserved70;
        u_int16_t rlsovlap;
        u_int16_t rlsservice;
 u_int16_t reserved73;
 u_int16_t reserved74;
        u_int16_t queue;

        u_int16_t satacapabilities;

        u_int16_t satacapabilities2;
        u_int16_t satasupport;
        u_int16_t sataenabled;

        u_int16_t version_major;
        u_int16_t version_minor;

 struct {
            u_int16_t command1;

            u_int16_t command2;

            u_int16_t extension;
 } __attribute__((__packed__)) support, enabled;

        u_int16_t udmamodes;
        u_int16_t erase_time;
        u_int16_t enhanced_erase_time;
        u_int16_t apm_value;
        u_int16_t master_passwd_revision;
        u_int16_t hwres;

        u_int16_t acoustic;

        u_int16_t stream_min_req_size;
        u_int16_t stream_transfer_time;
        u_int16_t stream_access_latency;
        u_int32_t stream_granularity;
        u_int16_t lba_size48_1;
 u_int16_t lba_size48_2;
 u_int16_t lba_size48_3;
 u_int16_t lba_size48_4;
 u_int16_t reserved104;
        u_int16_t max_dsm_blocks;
        u_int16_t pss;
        u_int16_t isd;
        u_int16_t wwn[4];
 u_int16_t reserved112[5];
        u_int16_t lss_1;
        u_int16_t lss_2;
        u_int16_t support2;
        u_int16_t enabled2;
 u_int16_t reserved121[6];
        u_int16_t removable_status;
        u_int16_t security_status;

 u_int16_t reserved129[31];
        u_int16_t cfa_powermode1;
 u_int16_t reserved161;
        u_int16_t cfa_kms_support;
        u_int16_t cfa_trueide_modes;
        u_int16_t cfa_memory_modes;
 u_int16_t reserved165[3];
        u_int16_t form_factor;
        u_int16_t support_dsm;
        u_int8_t product_id[8];
 u_int16_t reserved174[2];
        u_int8_t media_serial[60];
        u_int16_t sct;
 u_int16_t reserved207[2];
        u_int16_t lsalign;
        u_int16_t wrv_sectors_m3_1;
 u_int16_t wrv_sectors_m3_2;
        u_int16_t wrv_sectors_m2_1;
 u_int16_t wrv_sectors_m2_2;
        u_int16_t nv_cache_caps;
        u_int16_t nv_cache_size_1;
 u_int16_t nv_cache_size_2;
        u_int16_t media_rotation_rate;
 u_int16_t reserved218;
        u_int16_t nv_cache_opt;
        u_int16_t wrv_mode;
 u_int16_t reserved221;
        u_int16_t transport_major;
        u_int16_t transport_minor;
 u_int16_t reserved224[31];
        u_int16_t integrity;
} __attribute__((__packed__)) ;
struct ccb_ataio;
struct cam_periph;
union ccb;
struct ata_cmd {
 uint8_t flags;

 uint8_t command;
 uint8_t features;

 uint8_t lba_low;
 uint8_t lba_mid;
 uint8_t lba_high;
 uint8_t device;

 uint8_t lba_low_exp;
 uint8_t lba_mid_exp;
 uint8_t lba_high_exp;
 uint8_t features_exp;

 uint8_t sector_count;
 uint8_t sector_count_exp;
 uint8_t control;
};
struct ata_res {
 uint8_t flags;

 uint8_t status;
 uint8_t error;

 uint8_t lba_low;
 uint8_t lba_mid;
 uint8_t lba_high;
 uint8_t device;

 uint8_t lba_low_exp;
 uint8_t lba_mid_exp;
 uint8_t lba_high_exp;

 uint8_t sector_count;
 uint8_t sector_count_exp;
};
struct nvme_sgl_descriptor {
 uint64_t address;
 uint32_t length;
 uint8_t reserved[3];
 uint8_t type;
};
struct nvme_command {

 uint8_t opc;
 uint8_t fuse;
 uint16_t cid;


 uint32_t nsid;


 uint32_t rsvd2;
 uint32_t rsvd3;


 uint64_t mptr;


 union {
  struct {
   uint64_t prp1;
   uint64_t prp2;
  };
  struct nvme_sgl_descriptor sgl;
 };


 uint32_t cdw10;
 uint32_t cdw11;
 uint32_t cdw12;
 uint32_t cdw13;
 uint32_t cdw14;
 uint32_t cdw15;
} ;
struct nvme_completion {

 uint32_t cdw0;


 uint32_t rsvd1;


 uint16_t sqhd;
 uint16_t sqid;


 uint16_t cid;
 uint16_t status;
} ;
struct vnet {
 struct { struct vnet *le_next; struct vnet **le_prev; } vnet_le;
 u_int vnet_magic_n;
 u_int vnet_ifcnt;
 u_int vnet_sockcnt;
 u_int vnet_state;
 void *vnet_data_mem;
 uintptr_t vnet_data_base;
 bool vnet_shutdown;
} ;
struct bio;
struct thread;
struct ccb_nvmeio;
struct mmc_data;
struct mmc_request;
struct mmc_command {
 uint32_t opcode;
 uint32_t arg;
 uint32_t resp[4];
 uint32_t flags;


 uint32_t retries;
 uint32_t error;
 struct mmc_data *data;
 struct mmc_request *mrq;
};
struct mmc_data {
 size_t len;
 size_t xfer_len;
 void *data;
 uint32_t flags;
 struct mmc_request *mrq;
 size_t block_size;
 size_t block_count;
};
struct mmc_request {
 struct mmc_command *cmd;
 struct mmc_command *stop;
 void (*done)(struct mmc_request *);
 void *done_data;
 uint32_t flags;
};
struct ccb_pathinq;
struct cam_sim;
typedef enum {

 XPT_FC_QUEUED = 0x100,

 XPT_FC_USER_CCB = 0x200,
 XPT_FC_XPT_ONLY = 0x400,

 XPT_FC_DEV_QUEUED = 0x800 | XPT_FC_QUEUED,


 XPT_NOOP = 0x00,

 XPT_SCSI_IO = 0x01 | XPT_FC_DEV_QUEUED,

 XPT_GDEV_TYPE = 0x02,

 XPT_GDEVLIST = 0x03,

 XPT_PATH_INQ = 0x04,

 XPT_REL_SIMQ = 0x05,

 XPT_SASYNC_CB = 0x06,

 XPT_SDEV_TYPE = 0x07,

 XPT_SCAN_BUS = 0x08 | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,

 XPT_DEV_MATCH = 0x09 | XPT_FC_XPT_ONLY,

 XPT_DEBUG = 0x0a,

 XPT_PATH_STATS = 0x0b,

 XPT_GDEV_STATS = 0x0c,

 XPT_DEV_ADVINFO = 0x0e,

 XPT_ASYNC = 0x0f | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,


 XPT_ABORT = 0x10,

 XPT_RESET_BUS = 0x11 | XPT_FC_XPT_ONLY,

 XPT_RESET_DEV = 0x12 | XPT_FC_DEV_QUEUED,

 XPT_TERM_IO = 0x13,

 XPT_SCAN_LUN = 0x14 | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,

 XPT_GET_TRAN_SETTINGS = 0x15,




 XPT_SET_TRAN_SETTINGS = 0x16,




 XPT_CALC_GEOMETRY = 0x17,





 XPT_ATA_IO = 0x18 | XPT_FC_DEV_QUEUED,


 XPT_GET_SIM_KNOB_OLD = 0x18,

 XPT_SET_SIM_KNOB = 0x19,




 XPT_GET_SIM_KNOB = 0x1a,




 XPT_SMP_IO = 0x1b | XPT_FC_DEV_QUEUED,


 XPT_NVME_IO = 0x1c | XPT_FC_DEV_QUEUED,


 XPT_MMC_IO = 0x1d | XPT_FC_DEV_QUEUED,


 XPT_SCAN_TGT = 0x1e | XPT_FC_QUEUED | XPT_FC_USER_CCB
           | XPT_FC_XPT_ONLY,


 XPT_NVME_ADMIN = 0x1f | XPT_FC_DEV_QUEUED,



 XPT_ENG_INQ = 0x20 | XPT_FC_XPT_ONLY,

 XPT_ENG_EXEC = 0x21 | XPT_FC_DEV_QUEUED,



 XPT_EN_LUN = 0x30,

 XPT_TARGET_IO = 0x31 | XPT_FC_DEV_QUEUED,

 XPT_ACCEPT_TARGET_IO = 0x32 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_CONT_TARGET_IO = 0x33 | XPT_FC_DEV_QUEUED,

 XPT_IMMED_NOTIFY = 0x34 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_NOTIFY_ACK = 0x35,

 XPT_IMMEDIATE_NOTIFY = 0x36 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_NOTIFY_ACKNOWLEDGE = 0x37 | XPT_FC_QUEUED | XPT_FC_USER_CCB,

 XPT_REPROBE_LUN = 0x38 | XPT_FC_QUEUED | XPT_FC_USER_CCB,


 XPT_MMC_SET_TRAN_SETTINGS = 0x40 | XPT_FC_DEV_QUEUED,
 XPT_MMC_GET_TRAN_SETTINGS = 0x41 | XPT_FC_DEV_QUEUED,


 XPT_VUNIQUE = 0x80
} xpt_opcode;
typedef enum {
 PROTO_UNKNOWN,
 PROTO_UNSPECIFIED,
 PROTO_SCSI,
 PROTO_ATA,
 PROTO_ATAPI,
 PROTO_SATAPM,
 PROTO_SEMB,
 PROTO_NVME,
 PROTO_MMCSD,
} cam_proto;
typedef enum {
 XPORT_UNKNOWN,
 XPORT_UNSPECIFIED,
 XPORT_SPI,
 XPORT_FC,
 XPORT_SSA,
 XPORT_USB,
 XPORT_PPB,
 XPORT_ATA,
 XPORT_SAS,
 XPORT_SATA,
 XPORT_ISCSI,
 XPORT_SRP,
 XPORT_NVME,
 XPORT_MMCSD,
 XPORT_NVMF,
 XPORT_UFSHCI,
} cam_xport;
typedef union {
 struct { struct ccb_hdr *le_next; struct ccb_hdr **le_prev; } le;
 struct { struct ccb_hdr *sle_next; } sle;
 struct { struct ccb_hdr *tqe_next; struct ccb_hdr **tqe_prev; } tqe;
 struct { struct ccb_hdr *stqe_next; } stqe;
} camq_entry;
typedef union {
 void *ptr;
 u_long field;
 uint8_t bytes[sizeof(uintptr_t)];
} ccb_priv_entry;
typedef union {
 ccb_priv_entry entries[2];
 uint8_t bytes[2 * sizeof(ccb_priv_entry)];
} ccb_ppriv_area;
typedef union {
 ccb_priv_entry entries[2];
 uint8_t bytes[2 * sizeof(ccb_priv_entry)];
} ccb_spriv_area;
typedef struct {
 struct timeval *etime;
 uintptr_t sim_data;
 uintptr_t periph_data;
} ccb_qos_area;
struct ccb_hdr {
 cam_pinfo pinfo;
 camq_entry xpt_links;
 camq_entry sim_links;
 camq_entry periph_links;

 uint16_t retry_count;
 uint16_t alloc_flags;




 void (*cbfcnp)(struct cam_periph *, union ccb *);

 xpt_opcode func_code;
 uint32_t status;
 struct cam_path *path;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 uint32_t flags;
 uint32_t xflags;
 ccb_ppriv_area periph_priv;
 ccb_spriv_area sim_priv;
 ccb_qos_area qos;
 uint32_t timeout;
 struct timeval softtimeout;
};
struct ccb_getdev {
 struct ccb_hdr ccb_h;
 cam_proto protocol;
 struct scsi_inquiry_data inq_data;
 struct ata_params ident_data;
 uint8_t serial_num[252];
 uint8_t inq_flags;
 uint8_t serial_num_len;
 void *padding[2];
};
struct ccb_getdevstats {
 struct ccb_hdr ccb_h;
 int dev_openings;
 int dev_active;
 int allocated;
 int queued;
 int held;



 int maxtags;



 int mintags;
 struct timeval last_reset;
};
typedef enum {
 CAM_GDEVLIST_LAST_DEVICE,
 CAM_GDEVLIST_LIST_CHANGED,
 CAM_GDEVLIST_MORE_DEVS,
 CAM_GDEVLIST_ERROR
} ccb_getdevlist_status_e;
struct ccb_getdevlist {
 struct ccb_hdr ccb_h;
 char periph_name[16];
 uint32_t unit_number;
 unsigned int generation;
 uint32_t index;
 ccb_getdevlist_status_e status;
};
typedef enum {
 PERIPH_MATCH_ANY = 0x000,
 PERIPH_MATCH_PATH = 0x001,
 PERIPH_MATCH_TARGET = 0x002,
 PERIPH_MATCH_LUN = 0x004,
 PERIPH_MATCH_NAME = 0x008,
 PERIPH_MATCH_UNIT = 0x010,
} periph_pattern_flags;
struct periph_match_pattern {
 char periph_name[16];
 uint32_t unit_number;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 periph_pattern_flags flags;
};
typedef enum {
 DEV_MATCH_ANY = 0x000,
 DEV_MATCH_PATH = 0x001,
 DEV_MATCH_TARGET = 0x002,
 DEV_MATCH_LUN = 0x004,
 DEV_MATCH_INQUIRY = 0x008,
 DEV_MATCH_DEVID = 0x010,
} dev_pattern_flags;
struct device_id_match_pattern {
 uint8_t id_len;
 uint8_t id[256];
};
struct device_match_pattern {
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 dev_pattern_flags flags;
 union {
  struct scsi_static_inquiry_pattern inq_pat;
  struct device_id_match_pattern devid_pat;
 } data;
};
typedef enum {
 BUS_MATCH_ANY = 0x000,
 BUS_MATCH_PATH = 0x001,
 BUS_MATCH_NAME = 0x002,
 BUS_MATCH_UNIT = 0x004,
 BUS_MATCH_BUS_ID = 0x008,
} bus_pattern_flags;
struct bus_match_pattern {
 path_id_t path_id;
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
 bus_pattern_flags flags;
};
union match_pattern {
 struct periph_match_pattern periph_pattern;
 struct device_match_pattern device_pattern;
 struct bus_match_pattern bus_pattern;
};
typedef enum {
 DEV_MATCH_PERIPH,
 DEV_MATCH_DEVICE,
 DEV_MATCH_BUS
} dev_match_type;
struct dev_match_pattern {
 dev_match_type type;
 union match_pattern pattern;
};
struct periph_match_result {
 char periph_name[16];
 uint32_t unit_number;
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
};
typedef enum {
 DEV_RESULT_NOFLAG = 0x00,
 DEV_RESULT_UNCONFIGURED = 0x01
} dev_result_flags;
struct device_match_result {
 path_id_t path_id;
 target_id_t target_id;
 lun_id_t target_lun;
 cam_proto protocol;
 struct scsi_inquiry_data inq_data;
 struct ata_params ident_data;
 dev_result_flags flags;
};
struct bus_match_result {
 path_id_t path_id;
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
};
union match_result {
 struct periph_match_result periph_result;
 struct device_match_result device_result;
 struct bus_match_result bus_result;
};
struct dev_match_result {
 dev_match_type type;
 union match_result result;
};
typedef enum {
 CAM_DEV_MATCH_LAST,
 CAM_DEV_MATCH_MORE,
 CAM_DEV_MATCH_LIST_CHANGED,
 CAM_DEV_MATCH_SIZE_ERROR,
 CAM_DEV_MATCH_ERROR
} ccb_dev_match_status;
typedef enum {
 CAM_DEV_POS_NONE = 0x000,
 CAM_DEV_POS_BUS = 0x001,
 CAM_DEV_POS_TARGET = 0x002,
 CAM_DEV_POS_DEVICE = 0x004,
 CAM_DEV_POS_PERIPH = 0x008,
 CAM_DEV_POS_PDPTR = 0x010,
 CAM_DEV_POS_TYPEMASK = 0xf00,
 CAM_DEV_POS_EDT = 0x100,
 CAM_DEV_POS_PDRV = 0x200
} dev_pos_type;
struct ccb_dm_cookie {
 void *bus;
 void *target;
 void *device;
 void *periph;
 void *pdrv;
};
struct ccb_dev_position {
 u_int generations[4];
 dev_pos_type position_type;
 struct ccb_dm_cookie cookie;
};
struct ccb_dev_match {
 struct ccb_hdr ccb_h;
 ccb_dev_match_status status;
 uint32_t num_patterns;
 uint32_t pattern_buf_len;
 struct dev_match_pattern *patterns;
 uint32_t num_matches;
 uint32_t match_buf_len;
 struct dev_match_result *matches;
 struct ccb_dev_position pos;
};
struct ccb_pathinq_settings_spi {
 uint8_t ppr_options;
};
struct ccb_pathinq_settings_fc {
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t port;
 uint32_t bitrate;
};
struct ccb_pathinq_settings_sas {
 uint32_t bitrate;
};
struct ccb_pathinq_settings_nvme {
 uint32_t nsid;
 uint32_t domain;
 uint8_t bus;
 uint8_t slot;
 uint8_t function;
 uint8_t extra;
 char dev_name[52];
};
struct ccb_pathinq_settings_nvmf {
 uint32_t nsid;
 uint8_t trtype;
 char dev_name[52];
};
struct ccb_pathinq {
 struct ccb_hdr ccb_h;
 uint8_t version_num;
 uint8_t hba_inquiry;
 uint16_t target_sprt;
 uint32_t hba_misc;
 uint16_t hba_eng_cnt;

 uint8_t vuhba_flags[14];
 uint32_t max_target;
 uint32_t max_lun;
 uint32_t async_flags;
 path_id_t hpath_id;
 target_id_t initiator_id;
 char sim_vid[16];
 char hba_vid[16];
 char dev_name[16];
 uint32_t unit_number;
 uint32_t bus_id;
 uint32_t base_transfer_speed;
 cam_proto protocol;
 u_int protocol_version;
 cam_xport transport;
 u_int transport_version;
 union {
  struct ccb_pathinq_settings_spi spi;
  struct ccb_pathinq_settings_fc fc;
  struct ccb_pathinq_settings_sas sas;
  struct ccb_pathinq_settings_nvme nvme;
  struct ccb_pathinq_settings_nvmf nvmf;
  char ccb_pathinq_settings_opaque[128];
 } xport_specific;
 u_int maxio;
 uint16_t hba_vendor;
 uint16_t hba_device;
 uint16_t hba_subvendor;
 uint16_t hba_subdevice;
};
struct ccb_pathstats {
 struct ccb_hdr ccb_h;
 struct timeval last_reset;
};
typedef enum {
 SMP_FLAG_NONE = 0x00,
 SMP_FLAG_REQ_SG = 0x01,
 SMP_FLAG_RSP_SG = 0x02
} ccb_smp_pass_flags;
struct ccb_smpio {
 struct ccb_hdr ccb_h;
 uint8_t *smp_request;
 int smp_request_len;
 uint16_t smp_request_sglist_cnt;
 uint8_t *smp_response;
 int smp_response_len;
 uint16_t smp_response_sglist_cnt;
 ccb_smp_pass_flags flags;
};
typedef union {
 uint8_t *cdb_ptr;

 uint8_t cdb_bytes[16];
} cdb_t;
struct ccb_scsiio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 uint8_t *req_map;
 uint8_t *data_ptr;
 uint32_t dxfer_len;

 struct scsi_sense_data sense_data;
 uint8_t sense_len;
 uint8_t cdb_len;
 uint16_t sglist_cnt;
 uint8_t scsi_status;
 uint8_t sense_resid;
 uint32_t resid;
 cdb_t cdb_io;
 uint8_t *msg_ptr;
 uint16_t msg_len;
 uint8_t tag_action;





 uint8_t priority;
 u_int tag_id;
 u_int init_id;



};
struct ccb_ataio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct ata_cmd cmd;
 struct ata_res res;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint32_t resid;
 uint8_t ata_flags;
 uint8_t icc;
 uint32_t aux;
 uint32_t unused;
};
struct ccb_mmcio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct mmc_command cmd;
        struct mmc_command stop;
};
struct ccb_accept_tio {
 struct ccb_hdr ccb_h;
 cdb_t cdb_io;
 uint8_t cdb_len;
 uint8_t tag_action;
 uint8_t sense_len;
 uint8_t priority;
 u_int tag_id;
 u_int init_id;
 struct scsi_sense_data sense_data;
};
struct ccb_relsim {
 struct ccb_hdr ccb_h;
 uint32_t release_flags;
 uint32_t openings;
 uint32_t release_timeout;
 uint32_t qfrozen_cnt;
};
struct ccb_nvmeio {
 struct ccb_hdr ccb_h;
 union ccb *next_ccb;
 struct nvme_command cmd;
 struct nvme_completion cpl;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint16_t sglist_cnt;
 uint16_t unused;
};
typedef enum {
 AC_UNIT_ATTENTION = 0x4000,
 AC_ADVINFO_CHANGED = 0x2000,
 AC_CONTRACT = 0x1000,
 AC_GETDEV_CHANGED = 0x800,
 AC_INQ_CHANGED = 0x400,
 AC_TRANSFER_NEG = 0x200,
 AC_LOST_DEVICE = 0x100,
 AC_FOUND_DEVICE = 0x080,
 AC_PATH_DEREGISTERED = 0x040,
 AC_PATH_REGISTERED = 0x020,
 AC_SENT_BDR = 0x010,
 AC_SCSI_AEN = 0x008,
 AC_UNSOL_RESEL = 0x002,
 AC_BUS_RESET = 0x001
} ac_code;
typedef void ac_callback_t (void *softc, uint32_t code,
       struct cam_path *path, void *args);
struct ccb_setasync {
 struct ccb_hdr ccb_h;
 uint32_t event_enable;
 ac_callback_t *callback;
 void *callback_arg;
};
struct ccb_setdev {
 struct ccb_hdr ccb_h;
 uint8_t dev_type;
};
struct ccb_abort {
 struct ccb_hdr ccb_h;
 union ccb *abort_ccb;
};
struct ccb_resetbus {
 struct ccb_hdr ccb_h;
};
struct ccb_resetdev {
 struct ccb_hdr ccb_h;
};
struct ccb_termio {
 struct ccb_hdr ccb_h;
 union ccb *termio_ccb;
};
typedef enum {
 CTS_TYPE_CURRENT_SETTINGS,
 CTS_TYPE_USER_SETTINGS
} cts_type;
struct ccb_trans_settings_scsi
{
 u_int valid;
 u_int flags;
};
struct ccb_trans_settings_ata
{
 u_int valid;
 u_int flags;
};
struct ccb_trans_settings_spi
{
 u_int valid;
 u_int flags;
 u_int sync_period;
 u_int sync_offset;
 u_int bus_width;
 u_int ppr_options;
};
struct ccb_trans_settings_fc {
 u_int valid;
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t port;
 uint32_t bitrate;
};
struct ccb_trans_settings_sas {
 u_int valid;
 uint32_t bitrate;
};
struct ccb_trans_settings_pata {
 u_int valid;
 int mode;
 u_int bytecount;
 u_int atapi;
 u_int caps;
};
struct ccb_trans_settings_sata {
 u_int valid;
 int mode;
 u_int bytecount;
 int revision;
 u_int pm_present;
 u_int tags;
 u_int atapi;
 u_int caps;
};
struct ccb_trans_settings_nvme
{
 u_int valid;
 uint32_t spec;
 uint32_t max_xfer;
 uint32_t caps;
 uint8_t lanes;
 uint8_t speed;
 uint8_t max_lanes;
 uint8_t max_speed;
};
struct ccb_trans_settings_nvmf
{
 u_int valid;
 uint8_t trtype;
};
struct ccb_trans_settings_ufshci
{
 u_int valid;




 uint32_t speed;
 uint8_t hs_gear;
 uint8_t tx_lanes;
 uint8_t rx_lanes;
 uint8_t max_hs_gear;
 uint8_t max_tx_lanes;
 uint8_t max_rx_lanes;
};
enum mmc_vdd {
 vdd_150 = 0, vdd_155, vdd_160, vdd_165, vdd_170, vdd_180,
 vdd_190, vdd_200, vdd_210, vdd_220, vdd_230, vdd_240, vdd_250,
 vdd_260, vdd_270, vdd_280, vdd_290, vdd_300, vdd_310, vdd_320,
 vdd_330, vdd_340, vdd_350, vdd_360
};
enum mmc_vccq {
 vccq_120 = 0, vccq_180, vccq_330
};
enum mmc_power_mode {
 power_off = 0, power_up, power_on
};
enum mmc_bus_mode {
 opendrain = 1, pushpull
};
enum mmc_chip_select {
 cs_dontcare = 0, cs_high, cs_low
};
enum mmc_bus_type {
 bus_type_default = 0, bus_type_spi
};
enum mmc_bus_width {
 bus_width_1 = 0, bus_width_4 = 2, bus_width_8 = 3
};
enum mmc_drv_type {
 drv_type_b = 0, drv_type_a, drv_type_c, drv_type_d
};
enum mmc_bus_timing {
 bus_timing_normal = 0, bus_timing_hs, bus_timing_uhs_sdr12,
 bus_timing_uhs_sdr25, bus_timing_uhs_sdr50, bus_timing_uhs_ddr50,
 bus_timing_uhs_sdr104, bus_timing_mmc_ddr52, bus_timing_mmc_hs200,
 bus_timing_mmc_hs400, bus_timing_mmc_hs400es, bus_timing_max =
 bus_timing_mmc_hs400es
};
struct mmc_ios {
 uint32_t clock;
 enum mmc_vdd vdd;
 enum mmc_vccq vccq;
 enum mmc_bus_type bus_type;
 enum mmc_bus_mode bus_mode;
 enum mmc_chip_select chip_select;
 enum mmc_bus_width bus_width;
 enum mmc_power_mode power_mode;
 enum mmc_bus_timing timing;
 enum mmc_drv_type drv_type;
};
struct ccb_trans_settings_mmc {
 struct mmc_ios ios;
 uint32_t ios_valid;

 uint32_t host_ocr;
 int host_f_min;
 int host_f_max;


 uint32_t host_caps;
 uint32_t host_max_data;
};
struct ccb_trans_settings {
 struct ccb_hdr ccb_h;
 cts_type type;
 cam_proto protocol;
 u_int protocol_version;
 cam_xport transport;
 u_int transport_version;
 union {
  u_int valid;
  struct ccb_trans_settings_ata ata;
  struct ccb_trans_settings_scsi scsi;
  struct ccb_trans_settings_nvme nvme;
  struct ccb_trans_settings_mmc mmc;
 } proto_specific;
 union {
  u_int valid;
  struct ccb_trans_settings_spi spi;
  struct ccb_trans_settings_fc fc;
  struct ccb_trans_settings_sas sas;
  struct ccb_trans_settings_pata ata;
  struct ccb_trans_settings_sata sata;
  struct ccb_trans_settings_nvme nvme;
  struct ccb_trans_settings_nvmf nvmf;
  struct ccb_trans_settings_ufshci ufshci;
 } xport_specific;
};
struct ccb_calc_geometry {
 struct ccb_hdr ccb_h;
 uint32_t block_size;
 uint64_t volume_size;
 uint32_t cylinders;
 uint8_t heads;
 uint8_t secs_per_track;
};
struct ccb_sim_knob_settings_spi {
 u_int valid;
 u_int initiator_id;
 u_int role;
};
struct ccb_sim_knob_settings_fc {
 u_int valid;
 uint64_t wwnn;
 uint64_t wwpn;
 u_int role;
};
struct ccb_sim_knob_settings_sas {
 u_int valid;
 uint64_t wwnn;
 u_int role;
};
struct ccb_sim_knob {
 struct ccb_hdr ccb_h;
 union {
  u_int valid;
  struct ccb_sim_knob_settings_spi spi;
  struct ccb_sim_knob_settings_fc fc;
  struct ccb_sim_knob_settings_sas sas;
  char pad[128];
 } xport_specific;
};
struct ccb_rescan {
 struct ccb_hdr ccb_h;
 cam_flags flags;
};
struct ccb_debug {
 struct ccb_hdr ccb_h;
 cam_debug_flags flags;
};
struct ccb_en_lun {
 struct ccb_hdr ccb_h;
 uint16_t grp6_len;
 uint16_t grp7_len;
 uint8_t enable;
};
struct ccb_immed_notify {
 struct ccb_hdr ccb_h;
 struct scsi_sense_data sense_data;
 uint8_t sense_len;
 uint8_t initiator_id;
 uint8_t message_args[7];
};
struct ccb_notify_ack {
 struct ccb_hdr ccb_h;
 uint16_t seq_id;
 uint8_t event;
};
struct ccb_immediate_notify {
 struct ccb_hdr ccb_h;
 u_int tag_id;
 u_int seq_id;
 u_int initiator_id;
 u_int arg;
};
struct ccb_notify_acknowledge {
 struct ccb_hdr ccb_h;
 u_int tag_id;
 u_int seq_id;
 u_int initiator_id;
 u_int arg;





};
typedef enum {
 EIT_BUFFER,
 EIT_LOSSLESS,
 EIT_LOSSY,
 EIT_ENCRYPT
} ei_type;
typedef enum {
 EAD_VUNIQUE,
 EAD_LZ1V1,
 EAD_LZ2V1,
 EAD_LZ2V2
} ei_algo;
struct ccb_eng_inq {
 struct ccb_hdr ccb_h;
 uint16_t eng_num;
 ei_type eng_type;
 ei_algo eng_algo;
 uint32_t eng_memeory;
};
struct ccb_eng_exec {
 struct ccb_hdr ccb_h;
 uint8_t *pdrv_ptr;
 uint8_t *req_map;
 uint8_t *data_ptr;
 uint32_t dxfer_len;
 uint8_t *engdata_ptr;
 uint16_t sglist_cnt;
 uint32_t dmax_len;
 uint32_t dest_len;
 int32_t src_resid;
 uint32_t timeout;
 uint16_t eng_num;
 uint16_t vu_flags;
};
struct ccb_dev_advinfo {
 struct ccb_hdr ccb_h;
 uint32_t flags;
 uint32_t buftype;

 off_t bufsiz;
 off_t provsiz;
 uint8_t *buf;
};
struct ccb_async {
 struct ccb_hdr ccb_h;
 uint32_t async_code;
 off_t async_arg_size;
 void *async_arg_ptr;
};
union ccb {
 struct ccb_hdr ccb_h;
 struct ccb_scsiio csio;
 struct ccb_getdev cgd;
 struct ccb_getdevlist cgdl;
 struct ccb_pathinq cpi;
 struct ccb_relsim crs;
 struct ccb_setasync csa;
 struct ccb_setdev csd;
 struct ccb_pathstats cpis;
 struct ccb_getdevstats cgds;
 struct ccb_dev_match cdm;
 struct ccb_trans_settings cts;
 struct ccb_calc_geometry ccg;
 struct ccb_sim_knob knob;
 struct ccb_abort cab;
 struct ccb_resetbus crb;
 struct ccb_resetdev crd;
 struct ccb_termio tio;
 struct ccb_accept_tio atio;
 struct ccb_scsiio ctio;
 struct ccb_en_lun cel;
 struct ccb_immed_notify cin;
 struct ccb_notify_ack cna;
 struct ccb_immediate_notify cin1;
 struct ccb_notify_acknowledge cna2;
 struct ccb_eng_inq cei;
 struct ccb_eng_exec cee;
 struct ccb_smpio smpio;
 struct ccb_rescan crcn;
 struct ccb_debug cdbg;
 struct ccb_ataio ataio;
 struct ccb_dev_advinfo cdai;
 struct ccb_async casync;
 struct ccb_nvmeio nvmeio;
 struct ccb_mmcio mmcio;
};
struct uma_zone;
typedef struct uma_zone * uma_zone_t;
struct uio;
union ccb;
struct cam_periph;
struct cam_sim;
struct cam_path;
typedef enum {
 CAM_PERIPH_BIO
} cam_periph_type;
typedef void periph_start_t (struct cam_periph *periph,
     union ccb *start_ccb);
typedef void periph_oninv_t (struct cam_periph *periph);
typedef void periph_dtor_t (struct cam_periph *periph);
struct cam_periph {
 periph_start_t *periph_start;
 periph_oninv_t *periph_oninval;
 periph_dtor_t *periph_dtor;
 char *periph_name;
 struct cam_path *path;
 void *softc;
 struct cam_sim *sim;
 uint32_t unit_number;
 cam_periph_type type;
 uint32_t flags;
 uint32_t scheduled_priority;
 uint32_t immediate_priority;
 int periph_allocating;
 int periph_allocated;
 uint32_t refcount;
 struct { struct ccb_hdr *slh_first; } ccb_list;
 struct { struct cam_periph *sle_next; } periph_links;
 struct { struct cam_periph *tqe_next; struct cam_periph **tqe_prev; } unit_links;
 ac_callback_t *deferred_callback;
 ac_code deferred_ac;
 struct task periph_run_task;
 uma_zone_t ccb_zone;
 struct root_hold_token periph_rootmount;
};
struct camq {
 cam_pinfo **queue_array;
 int array_size;
 int entries;
 uint32_t generation;
 uint32_t qfrozen_cnt;
};
struct cam_devq {
 struct mtx send_mtx;
 struct camq send_queue;
 int send_openings;
 int send_active;
};
typedef struct ocs_hdr_list_s { struct ccb_hdr *stqh_first; struct ccb_hdr **stqh_last; } ocs_hdr_list_t;
typedef struct ocs_tgt_resource_s {
 ocs_hdr_list_t atio;
 ocs_hdr_list_t inot;
 uint8_t enabled;

 lun_id_t lun;
} ocs_tgt_resource_t;
typedef struct {
} ocs_scsi_tgt_domain_t;
typedef struct {
} ocs_scsi_ini_domain_t;
typedef struct {
} ocs_scsi_tgt_sport_t;
typedef struct {
} ocs_scsi_ini_sport_t;
typedef enum {
 OCS_CAM_IO_FREE,
 OCS_CAM_IO_COMMAND,
 OCS_CAM_IO_DATA,
 OCS_CAM_IO_DATA_DONE,
 OCS_CAM_IO_RESP,
 OCS_CAM_IO_MAX
} ocs_cam_io_state_t;
typedef struct {
 bus_dmamap_t dmap;
 uint64_t lun;
 void *app;
 ocs_cam_io_state_t state;
        bool sendresp;
 uint32_t flags;
} ocs_scsi_tgt_io_t;
typedef struct {
} ocs_scsi_ini_io_t;
struct ocs_lun_crn {
        uint64_t lun;
        uint8_t crnseed;
};
typedef struct {
 struct ocs_lun_crn *lun_crn[512];
} ocs_scsi_ini_node_t;
typedef struct {
 uint32_t busy_sent;
} ocs_scsi_tgt_node_t;
typedef struct ocs_domain_record_s {
 uint32_t index;
 uint32_t priority;
 uint8_t address[6];
 uint8_t wwn[8];
 union {
  uint8_t vlan[512];
  uint8_t loop[128];
 } map;
 uint32_t speed;
 uint32_t fc_id;
 uint32_t is_fc:1,
   is_ethernet:1,
   is_loop:1,
   is_nport:1,
   :28;
} ocs_domain_record_t;
struct ocs_node_group_dir_s {
 uint32_t instance_index;
 ocs_sport_t *sport;
 uint8_t service_params[0x74];
 ocs_list_link_t link;
 ocs_list_t node_group_list;
 uint32_t node_group_list_count;
 uint32_t next_idx;
};
typedef enum {
 OCS_SPORT_TOPOLOGY_UNKNOWN=0,
 OCS_SPORT_TOPOLOGY_FABRIC,
 OCS_SPORT_TOPOLOGY_P2P,
 OCS_SPORT_TOPOLOGY_LOOP,
} ocs_sport_topology_e;
struct ocs_sli_port_s {
 ocs_t *ocs;
 uint32_t tgt_id;
 uint32_t index;
 uint32_t instance_index;
 char display_name[32];
 ocs_domain_t *domain;
 uint32_t is_vport:1;
 uint64_t wwpn;
 uint64_t wwnn;
 ocs_list_t node_list;
 ocs_scsi_ini_sport_t ini_sport;
 ocs_scsi_tgt_sport_t tgt_sport;
 void *tgt_data;
 void *ini_data;
 ocs_mgmt_functions_t *mgmt_functions;




 ocs_sm_ctx_t ctx;
 ocs_hw_t *hw;
 uint32_t indicator;
 uint32_t fc_id;
 ocs_dma_t dma;

 uint8_t wwnn_str[32];
 uint64_t sli_wwpn;
 uint64_t sli_wwnn;
 uint32_t sm_free_req_pending:1;




 ocs_sm_ctx_t sm;
 sparse_vector_t lookup;
 ocs_list_link_t link;
 uint32_t enable_ini:1,
   enable_tgt:1,
   enable_rscn:1,
   shutting_down:1,
   p2p_winner:1;
 ocs_sport_topology_e topology;
 uint8_t service_params[0x74];
 uint32_t p2p_remote_port_id;
 uint32_t p2p_port_id;


 ocs_lock_t node_group_lock;
 uint32_t node_group_dir_next_instance;
 uint32_t node_group_next_instance;
 ocs_list_t node_group_dir_list;
};
struct ocs_domain_s {
 ocs_t *ocs;
 uint32_t instance_index;
 char display_name[32];
 ocs_list_t sport_list;
 ocs_scsi_ini_domain_t ini_domain;
 ocs_scsi_tgt_domain_t tgt_domain;
 ocs_mgmt_functions_t *mgmt_functions;


 ocs_hw_t *hw;
 ocs_sm_ctx_t sm;
 uint32_t fcf;
 uint32_t fcf_indicator;
 uint32_t vlan_id;
 uint32_t indicator;
 ocs_dma_t dma;
 uint32_t req_rediscover_fcf:1;



 uint64_t fcf_wwn;
 ocs_list_link_t link;
 ocs_sm_ctx_t drvsm;
 uint32_t attached:1,
   is_fc:1,
   is_loop:1,
   is_nlport:1,
   domain_found_pending:1,
   req_domain_free:1,
   req_accept_frames:1,
   domain_notify_pend:1;
 ocs_domain_record_t pending_drec;
 uint8_t service_params[0x74];
 uint8_t flogi_service_params[0x74];
 uint8_t femul_enable;


 sparse_vector_t lookup;
 ocs_lock_t lookup_lock;

 ocs_sli_port_t *sport;
 uint32_t sport_instance_count;


 ocs_bitmap_t *portid_pool;
 ocs_ns_t *ocs_ns;
};
struct ocs_remote_node_s {



 uint32_t indicator;
 uint32_t index;
 uint32_t fc_id;

 uint32_t attached:1,
   node_group:1,
   free_group:1;

 ocs_sli_port_t *sport;




 void *node;
};
struct ocs_remote_node_group_s {



 uint32_t indicator;
 uint32_t index;





 uint32_t instance_index;
 ocs_node_group_dir_t *node_group_dir;
 ocs_list_link_t link;
};
typedef enum {
 OCS_NODE_SHUTDOWN_DEFAULT = 0,
 OCS_NODE_SHUTDOWN_EXPLICIT_LOGO,
 OCS_NODE_SHUTDOWN_IMPLICIT_LOGO,
} ocs_node_shutd_rsn_e;
typedef enum {
 OCS_NODE_SEND_LS_ACC_NONE = 0,
 OCS_NODE_SEND_LS_ACC_PLOGI,
 OCS_NODE_SEND_LS_ACC_PRLI,
} ocs_node_send_ls_acc_e;
struct ocs_node_s {
 ocs_t *ocs;
 uint32_t instance_index;
 char display_name[32];
 ocs_sport_t *sport;
 uint32_t hold_frames:1;
 ocs_rlock_t lock;
 ocs_lock_t active_ios_lock;
 ocs_list_t active_ios;
 uint32_t max_wr_xfer_size;
 ocs_scsi_ini_node_t ini_node;
 ocs_scsi_tgt_node_t tgt_node;
 ocs_mgmt_functions_t *mgmt_functions;


 ocs_remote_node_t rnode;


 ocs_sm_ctx_t sm;
 uint32_t evtdepth;
 uint32_t req_free:1,
    attached:1,
    fcp_enabled:1,
    rscn_pending:1,
    send_plogi:1,
    send_plogi_acc:1,
    io_alloc_enabled:1,
    sent_prli:1;
 ocs_node_send_ls_acc_e send_ls_acc;
 ocs_io_t *ls_acc_io;
 uint32_t ls_acc_oxid;
 uint32_t ls_acc_did;
 ocs_node_shutd_rsn_e shutdown_reason;
 ocs_dma_t sparm_dma_buf;
 uint8_t service_params[0x74];
 ocs_lock_t pend_frames_lock;
 ocs_list_t pend_frames;
 uint32_t pend_frames_processed;
 uint32_t ox_id_in_use;
 uint32_t els_retries_remaining;
 uint32_t els_req_cnt;
 uint32_t els_cmpl_cnt;
 uint32_t abort_cnt;

 char current_state_name[32];
 char prev_state_name[32];
 ocs_sm_event_t current_evt;
 ocs_sm_event_t prev_evt;
 uint32_t targ:1,
    init:1,
    refound:1,
    fcp2device:1,
    reserved:4,
    fc_type:8;
 ocs_list_t els_io_pend_list;
 ocs_list_t els_io_active_list;

 ocs_sm_function_t nodedb_state;

 ocs_timer_t gidpt_delay_timer;
 time_t time_last_gidpt_msec;


 char wwnn[32];
 char wwpn[32];


 uint32_t chained_io_count;

 ocs_list_link_t link;

 ocs_remote_node_group_t *node_group;
};
typedef struct ocs_vport_spec_s ocs_vport_spec_t;
struct ocs_vport_spec_s {
 uint32_t domain_instance;
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t fc_id;
 uint32_t enable_tgt:1,
  enable_ini:1;
 ocs_list_link_t link;
 void *tgt_data;
 void *ini_data;
 ocs_sport_t *sport;
};
typedef struct sli4_lsp_sge_s {

 uint32_t buffer_address_high;
 uint32_t buffer_address_low;
 uint32_t :27,
   sge_type:4,
   last:1;
 uint32_t segment_length:24,
   :8;



} sli4_lsp_sge_t;
typedef union {

 struct {
  uint32_t iaab:1,
    npiv:1,
    dif:1,
    vf:1,
    fcpi:1,
    fcpt:1,
    fcpc:1,
    :1,
    rqd:1,
    iaar:1,
    hlm:1,
    perfh:1,
    rxseq:1,
    rxri:1,
    dcl2:1,
    rsco:1,
    mrqp:1,
    :15;
 } flag;
 uint32_t dword;



} sli4_features_t;
typedef enum {
 SLI_QTYPE_EQ,
 SLI_QTYPE_CQ,
 SLI_QTYPE_MQ,
 SLI_QTYPE_WQ,
 SLI_QTYPE_RQ,
 SLI_QTYPE_MAX,
} sli4_qtype_e;
typedef struct sli4_queue_s {

 ocs_dma_t dma;
 ocs_lock_t lock;
 uint32_t index;
 uint16_t size;
 uint16_t length;
 uint16_t n_posted;
 uint16_t id;
 uint16_t ulp;
 uint32_t doorbell_offset;
 uint16_t doorbell_rset;
 uint8_t type;
 uint32_t proc_limit;
 uint32_t posted_limit;
 uint32_t max_num_processed;
 time_t max_process_time;

 uint16_t phase;



 union {
  uint32_t r_idx;
  struct {
   uint32_t is_mq:1,
     is_hdr:1,
     rq_batch:1;
  } flag;
 } u;
} sli4_queue_t;
typedef enum {
 SLI_LINK_STATUS_UP,
 SLI_LINK_STATUS_DOWN,
 SLI_LINK_STATUS_NO_ALPA,
 SLI_LINK_STATUS_MAX,
} sli4_link_status_e;
typedef enum {
 SLI_LINK_TOPO_NPORT = 1,
 SLI_LINK_TOPO_LOOP,
 SLI_LINK_TOPO_LOOPBACK_INTERNAL,
 SLI_LINK_TOPO_LOOPBACK_EXTERNAL,
 SLI_LINK_TOPO_NONE,
 SLI_LINK_TOPO_MAX,
} sli4_link_topology_e;
typedef enum {
 SLI_LINK_MEDIUM_ETHERNET,
 SLI_LINK_MEDIUM_FC,
 SLI_LINK_MEDIUM_MAX,
} sli4_link_medium_e;
typedef struct sli4_link_event_s {
 sli4_link_status_e status;
 sli4_link_topology_e topology;
 sli4_link_medium_e medium;
 uint32_t speed;
 uint8_t *loop_map;
 uint32_t fc_id;
} sli4_link_event_t;
typedef struct sli4_sgl_chaining_params_s {
 uint8_t chaining_capable;
 uint16_t frag_num_field_offset;
 uint16_t sgl_index_field_offset;
 uint64_t frag_num_field_mask;
 uint64_t sgl_index_field_mask;
 uint32_t chain_sge_initial_value_lo;
 uint32_t chain_sge_initial_value_hi;
} sli4_sgl_chaining_params_t;
typedef enum {
 SLI_RSRC_FCOE_VFI,
 SLI_RSRC_FCOE_VPI,
 SLI_RSRC_FCOE_RPI,
 SLI_RSRC_FCOE_XRI,
 SLI_RSRC_FCOE_FCFI,
 SLI_RSRC_MAX
} sli4_resource_e;
typedef enum {
 SLI4_PORT_TYPE_FC,
 SLI4_PORT_TYPE_NIC,
 SLI4_PORT_TYPE_MAX
} sli4_port_type_e;
typedef enum {
 SLI4_ASIC_TYPE_BE3 = 1,
 SLI4_ASIC_TYPE_SKYHAWK,
 SLI4_ASIC_TYPE_LANCER,
 SLI4_ASIC_TYPE_CORSAIR,
 SLI4_ASIC_TYPE_LANCERG6,
 SLI4_ASIC_TYPE_LANCERG7
} sli4_asic_type_e;
typedef enum {
 SLI4_ASIC_REV_FPGA = 1,
 SLI4_ASIC_REV_A0,
 SLI4_ASIC_REV_A1,
 SLI4_ASIC_REV_A2,
 SLI4_ASIC_REV_A3,
 SLI4_ASIC_REV_B0,
 SLI4_ASIC_REV_B1,
 SLI4_ASIC_REV_C0,
 SLI4_ASIC_REV_D0,
} sli4_asic_rev_e;
typedef struct sli4_s {
 ocs_os_handle_t os;
 sli4_port_type_e port_type;

 uint32_t sli_rev;
 uint32_t sli_family;
 uint32_t if_type;

 sli4_asic_type_e asic_type;
 sli4_asic_rev_e asic_rev;
 uint32_t physical_port;

 struct {
  uint16_t e_d_tov;
  uint16_t r_a_tov;
  uint16_t max_qcount[SLI_QTYPE_MAX];
  uint32_t max_qentries[SLI_QTYPE_MAX];
  uint16_t count_mask[SLI_QTYPE_MAX];
  uint16_t count_method[SLI_QTYPE_MAX];
  uint32_t qpage_count[SLI_QTYPE_MAX];
  uint16_t link_module_type;
  uint8_t rq_batch;
  uint16_t rq_min_buf_size;
  uint32_t rq_max_buf_size;
  uint8_t topology;
  uint8_t pt:4,
     tf:1,
     ptv:1,
     :2;
  uint8_t wwpn[8];
  uint8_t wwnn[8];
  uint32_t fw_rev[2];
  uint8_t fw_name[2][16];
  char ipl_name[16];
  uint32_t hw_rev[3];
  uint8_t port_number;
  char port_name[2];
  char bios_version_string[32];
  uint8_t dual_ulp_capable;
  uint8_t is_ulp_fc[2];






  struct {
   uint32_t number;
   uint32_t size;
   uint32_t n_alloc;
   uint32_t *base;
   ocs_bitmap_t *use_map;
   uint32_t map_size;
  } extent[SLI_RSRC_MAX];
  sli4_features_t features;
  uint32_t has_extents:1,
     auto_reg:1,
     auto_xfer_rdy:1,
     hdr_template_req:1,
     perf_hint:1,
     perf_wq_id_association:1,
     cq_create_version:2,
     mq_create_version:2,
     high_login_mode:1,
     sgl_pre_registered:1,
     sgl_pre_registration_required:1,
     t10_dif_inline_capable:1,
     t10_dif_separate_capable:1;
  uint32_t sge_supported_length;
  uint32_t sgl_page_sizes;
  uint32_t max_sgl_pages;
  sli4_sgl_chaining_params_t sgl_chaining_params;
  size_t wqe_size;
 } config;




 int32_t (*link)(void *, void *);
 void *link_arg;
 int32_t (*fip)(void *, void *);
 void *fip_arg;

 ocs_dma_t bmbx;



 ocs_dma_t *bmbx_non_emb_pmd;


 struct {
  ocs_dma_t data;
  uint32_t length;
 } vpd;
} sli4_t;
static inline uint32_t
sli_get_sgl_preregister(sli4_t *sli4)
;
typedef struct fc_header_s {
 uint32_t info:4,
   r_ctl:4,
   d_id:24;
 uint32_t cs_ctl:8,
   s_id:24;
 uint32_t type:8,
   f_ctl:24;
 uint32_t seq_id:8,
   df_ctl:8,
   seq_cnt:16;
 uint32_t ox_id:16,
   rx_id:16;
 uint32_t parameter;
} fc_header_t;
typedef struct ocs_hw_io_s ocs_hw_io_t;
typedef struct hw_eq_s hw_eq_t;
typedef struct hw_cq_s hw_cq_t;
typedef struct hw_mq_s hw_mq_t;
typedef struct hw_wq_s hw_wq_t;
typedef struct hw_rq_s hw_rq_t;
typedef enum {
 OCS_HW_RTN_SUCCESS = 0,
 OCS_HW_RTN_SUCCESS_SYNC = 1,
 OCS_HW_RTN_ERROR = -1,
 OCS_HW_RTN_NO_RESOURCES = -2,
 OCS_HW_RTN_NO_MEMORY = -3,
 OCS_HW_RTN_IO_NOT_ACTIVE = -4,
 OCS_HW_RTN_IO_ABORT_IN_PROGRESS = -5,
 OCS_HW_RTN_IO_PORT_OWNED_ALREADY_ABORTED = -6,
 OCS_HW_RTN_INVALID_ARG = -7,
} ocs_hw_rtn_e;
typedef struct {
 uint16_t rqindex;
 ocs_dma_t dma;
} ocs_hw_rq_buffer_t;
typedef enum {
 OCS_HW_DIF_OPER_DISABLED,
 OCS_HW_SGE_DIF_OP_IN_NODIF_OUT_CRC,
 OCS_HW_SGE_DIF_OP_IN_CRC_OUT_NODIF,
 OCS_HW_SGE_DIF_OP_IN_NODIF_OUT_CHKSUM,
 OCS_HW_SGE_DIF_OP_IN_CHKSUM_OUT_NODIF,
 OCS_HW_SGE_DIF_OP_IN_CRC_OUT_CRC,
 OCS_HW_SGE_DIF_OP_IN_CHKSUM_OUT_CHKSUM,
 OCS_HW_SGE_DIF_OP_IN_CRC_OUT_CHKSUM,
 OCS_HW_SGE_DIF_OP_IN_CHKSUM_OUT_CRC,
 OCS_HW_SGE_DIF_OP_IN_RAW_OUT_RAW,
} ocs_hw_dif_oper_e;
typedef enum {
 OCS_HW_DIF_BK_SIZE_512,
 OCS_HW_DIF_BK_SIZE_1024,
 OCS_HW_DIF_BK_SIZE_2048,
 OCS_HW_DIF_BK_SIZE_4096,
 OCS_HW_DIF_BK_SIZE_520,
 OCS_HW_DIF_BK_SIZE_4104,
 OCS_HW_DIF_BK_SIZE_NA = 0
} ocs_hw_dif_blk_size_e;
typedef enum {
 OCS_HW_LINKCFG_4X10G = 0,
 OCS_HW_LINKCFG_1X40G,
 OCS_HW_LINKCFG_2X16G,
 OCS_HW_LINKCFG_4X8G,
 OCS_HW_LINKCFG_4X1G,
 OCS_HW_LINKCFG_2X10G,
 OCS_HW_LINKCFG_2X10G_2X8G,


 OCS_HW_LINKCFG_NA,
} ocs_hw_linkcfg_e;
typedef struct ocs_hw_dif_info_s {
 ocs_hw_dif_oper_e dif_oper;
 ocs_hw_dif_blk_size_e blk_size;
 uint32_t ref_tag_cmp;
 uint32_t ref_tag_repl;
 uint32_t app_tag_cmp:16,
  app_tag_repl:16;
 uint32_t check_ref_tag:1,
  check_app_tag:1,
  check_guard:1,
  auto_incr_ref_tag:1,
  repl_app_tag:1,
  repl_ref_tag:1,
  dif:2,
  dif_separate:1,


  disable_app_ffff:1,


  disable_app_ref_ffff:1,

  :21;
 uint16_t dif_seed;
} ocs_hw_dif_info_t;
typedef enum {
 OCS_HW_ELS_REQ,
 OCS_HW_ELS_RSP,
 OCS_HW_ELS_RSP_SID,
 OCS_HW_FC_CT,
 OCS_HW_FC_CT_RSP,
 OCS_HW_BLS_ACC,
 OCS_HW_BLS_ACC_SID,
 OCS_HW_BLS_RJT,
 OCS_HW_BCAST,
 OCS_HW_IO_TARGET_READ,
 OCS_HW_IO_TARGET_WRITE,
 OCS_HW_IO_TARGET_RSP,
 OCS_HW_IO_INITIATOR_READ,
 OCS_HW_IO_INITIATOR_WRITE,
 OCS_HW_IO_INITIATOR_NODATA,
 OCS_HW_IO_DNRX_REQUEUE,
 OCS_HW_IO_MAX,
} ocs_hw_io_type_e;
typedef enum {
 OCS_HW_IO_STATE_FREE,
 OCS_HW_IO_STATE_INUSE,
 OCS_HW_IO_STATE_WAIT_FREE,
 OCS_HW_IO_STATE_WAIT_SEC_HIO,
} ocs_hw_io_state_e;
typedef int32_t (*ocs_hw_done_t)(struct ocs_hw_io_s *, ocs_remote_node_t *, uint32_t len, int32_t status, uint32_t ext, void *ul_arg);
typedef union ocs_hw_io_param_u {
 struct {
  uint16_t ox_id;
  uint16_t rx_id;
  uint8_t payload[12];
 } bls;
 struct {
  uint32_t s_id;
  uint16_t ox_id;
  uint16_t rx_id;
  uint8_t payload[12];
 } bls_sid;
 struct {
  uint8_t r_ctl;
  uint8_t type;
  uint8_t df_ctl;
  uint8_t timeout;
 } bcast;
 struct {
  uint16_t ox_id;
  uint8_t timeout;
 } els;
 struct {
  uint32_t s_id;
  uint16_t ox_id;
  uint8_t timeout;
 } els_sid;
 struct {
  uint8_t r_ctl;
  uint8_t type;
  uint8_t df_ctl;
  uint8_t timeout;
 } fc_ct;
 struct {
  uint8_t r_ctl;
  uint8_t type;
  uint8_t df_ctl;
  uint8_t timeout;
  uint16_t ox_id;
 } fc_ct_rsp;
 struct {
  uint32_t offset;
  uint16_t ox_id;
  uint16_t flags;
  uint8_t cs_ctl;
  ocs_hw_dif_oper_e dif_oper;
  ocs_hw_dif_blk_size_e blk_size;
  uint8_t timeout;
  uint32_t app_id;
 } fcp_tgt;
 struct {
  ocs_dma_t *cmnd;
  ocs_dma_t *rsp;
  ocs_hw_dif_oper_e dif_oper;
  ocs_hw_dif_blk_size_e blk_size;
  uint32_t cmnd_size;
  uint16_t flags;
  uint32_t timeout;
  uint32_t first_burst;
 } fcp_ini;
} ocs_hw_io_param_t;
typedef enum {
 OCS_HW_WQ_STEERING_CLASS,
 OCS_HW_WQ_STEERING_REQUEST,
 OCS_HW_WQ_STEERING_CPU,
} ocs_hw_wq_steering_e;
typedef struct {
 uint32_t abort_wqe_submit_needed:1,
   send_abts:1,
   auto_xfer_rdy_dnrx:1,
   :29;
 uint32_t id;
 uint32_t abort_reqtag;
 ocs_list_link_t link;
 uint8_t *wqebuf;
} ocs_hw_wqe_t;
struct ocs_hw_io_s {

 ocs_list_link_t link;
 ocs_list_link_t wqe_link;
 ocs_list_link_t dnrx_link;
 ocs_hw_io_state_e state;
 ocs_hw_wqe_t wqe;
 ocs_lock_t axr_lock;
 ocs_hw_t *hw;
 ocs_remote_node_t *rnode;
 struct ocs_hw_auto_xfer_rdy_buffer_s *axr_buf;
 ocs_dma_t xfer_rdy;
 uint16_t type;
 uint32_t port_owned_abort_count;
 hw_wq_t *wq;
 uint32_t xbusy;
 ocs_hw_done_t done;
 void *arg;
 ocs_hw_done_t abort_done;
 void *abort_arg;
 ocs_ref_t ref;
 size_t length;
 uint32_t wqe_timeout;
 struct timeval submit_time;

 uint32_t status_saved:1,
   abort_in_progress:1,
   quarantine:1,
   quarantine_first_phase:1,
   is_port_owned:1,
   auto_xfer_rdy_dnrx:1,
   :26;
 uint32_t saved_status;
 uint32_t saved_len;
 uint32_t saved_ext;

 hw_eq_t *eq;
 ocs_hw_wq_steering_e wq_steering;
 uint8_t wq_class;


 uint16_t reqtag;
 uint32_t abort_reqtag;

 uint32_t indicator;
 ocs_dma_t def_sgl;
 uint32_t def_sgl_count;
 ocs_dma_t *sgl;
 uint32_t sgl_count;
 uint32_t first_data_sge;
 ocs_dma_t *ovfl_sgl;
 uint32_t ovfl_sgl_count;
 sli4_lsp_sge_t *ovfl_lsp;
 ocs_hw_io_t *ovfl_io;
 uint32_t n_sge;
 uint32_t sge_offset;


 struct ocs_hw_io_s *sec_hio;
 ocs_hw_io_param_t sec_iparam;
 uint32_t sec_len;


 void *ul_io;
};
typedef enum {
 OCS_HW_DOMAIN_ALLOC_OK,
 OCS_HW_DOMAIN_ALLOC_FAIL,
 OCS_HW_DOMAIN_ATTACH_OK,
 OCS_HW_DOMAIN_ATTACH_FAIL,
 OCS_HW_DOMAIN_FREE_OK,
 OCS_HW_DOMAIN_FREE_FAIL,
 OCS_HW_DOMAIN_LOST,
 OCS_HW_DOMAIN_FOUND,
 OCS_HW_DOMAIN_CHANGED,
} ocs_hw_domain_event_e;
typedef enum {
 OCS_HW_PORT_ALLOC_OK,
 OCS_HW_PORT_ALLOC_FAIL,
 OCS_HW_PORT_ATTACH_OK,
 OCS_HW_PORT_ATTACH_FAIL,
 OCS_HW_PORT_FREE_OK,
 OCS_HW_PORT_FREE_FAIL,
} ocs_hw_port_event_e;
typedef enum {
 OCS_HW_NODE_ATTACH_OK,
 OCS_HW_NODE_ATTACH_FAIL,
 OCS_HW_NODE_FREE_OK,
 OCS_HW_NODE_FREE_FAIL,
 OCS_HW_NODE_FREE_ALL_OK,
 OCS_HW_NODE_FREE_ALL_FAIL,
} ocs_hw_remote_node_event_e;
typedef enum {
 OCS_HW_UNSOL_SUCCESS,
 OCS_HW_UNSOL_ERROR,
 OCS_HW_UNSOL_ABTS_RCVD,
 OCS_HW_UNSOL_MAX,
} ocs_hw_unsol_status_e;
typedef struct {
 ocs_atomic_t rpi_count;
 ocs_atomic_t rpi_attached;
} ocs_hw_rpi_ref_t;
typedef enum {
 OCS_HW_STATE_UNINITIALIZED,
 OCS_HW_STATE_QUEUES_ALLOCATED,
 OCS_HW_STATE_ACTIVE,
 OCS_HW_STATE_RESET_IN_PROGRESS,
 OCS_HW_STATE_TEARDOWN_IN_PROGRESS,
} ocs_hw_state_e;
typedef struct {
 ocs_hw_t *hw;

 uint8_t fcfi;
 uint8_t auto_xrdy;
 uint8_t out_of_xris;
 ocs_hw_rq_buffer_t *header;
 ocs_hw_rq_buffer_t *payload;


 ocs_hw_unsol_status_e status;
 uint32_t xri;
 ocs_hw_io_t *hio;

 ocs_list_link_t link;
 void *hw_priv;
} ocs_hw_sequence_t;
typedef struct ocs_hw_auto_xfer_rdy_buffer_s {
 fc_header_t hdr;
 ocs_hw_rq_buffer_t header;
 ocs_hw_rq_buffer_t payload;
 ocs_hw_sequence_t seq;
 uint8_t data_cqe;
 uint8_t cmd_cqe;


 uint8_t fcfi;


 uint8_t call_axr_cmd;
 uint8_t call_axr_data;
 ocs_hw_sequence_t *cmd_seq;
} ocs_hw_auto_xfer_rdy_buffer_t;
typedef enum {
 QTOP_EQ = 0,
 QTOP_CQ,
 QTOP_WQ,
 QTOP_RQ,
 QTOP_MQ,
 QTOP_LAST,
} ocs_hw_qtop_entry_e;
typedef struct {
 ocs_hw_qtop_entry_e entry;
 uint8_t set_default;
 uint32_t len;
 uint8_t class;
 uint8_t ulp;
 uint8_t filter_mask;
} ocs_hw_qtop_entry_t;
typedef struct {
 ocs_os_handle_t os;
 ocs_hw_qtop_entry_t *entries;
 uint32_t alloc_count;
 uint32_t inuse_count;
 uint32_t entry_counts[QTOP_LAST];
 uint32_t rptcount[10];
 uint32_t rptcount_idx;
} ocs_hw_qtop_t;
typedef struct {
 uint32_t id:16,
  in_use:1,
  index:15;
} ocs_queue_hash_t;
typedef struct {
 uint32_t quarantine_index;
 ocs_hw_io_t *quarantine_ios[4];
} ocs_quarantine_info_t;
typedef struct {
 uint64_t fwrev;



 uint8_t retain_tsend_io_length;


 uint8_t use_unregistered_rpi;
 uint32_t unregistered_rid;
 uint32_t unregistered_index;

 uint8_t disable_ar_tgt_dif;
 uint8_t disable_dump_loc;
 uint8_t use_dif_quarantine;
 uint8_t use_dif_sec_xri;

 uint8_t override_fcfi;

 uint8_t fw_version_too_low;

 uint8_t sglc_misreported;

 uint8_t ignore_send_frame;

} ocs_hw_workaround_t;
struct ocs_hw_s {
 ocs_os_handle_t os;
 sli4_t sli;
 uint16_t ulp_start;
 uint16_t ulp_max;
 uint32_t dump_size;
 ocs_hw_state_e state;
 uint8_t hw_setup_called;
 uint8_t sliport_healthcheck;
 uint16_t watchdog_timeout;
 ocs_lock_t watchdog_lock;


 struct {
  uint32_t n_eq;
  uint32_t n_cq;
  uint32_t n_mq;
  uint32_t n_rq;
  uint32_t n_wq;
  uint32_t n_io;
  uint32_t n_sgl;
  uint32_t speed;
  uint32_t topology;
  uint32_t rq_default_buffer_size;
  uint32_t auto_xfer_rdy_xri_cnt;
  uint32_t auto_xfer_rdy_size;
  uint8_t auto_xfer_rdy_blk_size_chip;
  uint8_t esoc;
  uint16_t dif_seed;
  uint16_t auto_xfer_rdy_app_tag_value;
  uint8_t dif_mode;
  uint8_t i_only_aab;
  uint8_t emulate_wqe_timeout;
  uint32_t bounce:1;
  const char *queue_topology;
  uint8_t auto_xfer_rdy_t10_enable;
  uint8_t auto_xfer_rdy_p_type;
  uint8_t auto_xfer_rdy_ref_tag_is_lba;
  uint8_t auto_xfer_rdy_app_tag_valid;
  uint8_t rq_selection_policy;
  uint8_t rr_quanta;
  uint32_t filter_def[4];
 } config;


 uint32_t num_qentries[SLI_QTYPE_MAX];


 sli4_queue_t wq[32];
 sli4_queue_t rq[32];
 uint16_t hw_rq_lookup[32];
 sli4_queue_t mq[1];
 sli4_queue_t cq[((32*2) + 1 + (16 * 2))];
 sli4_queue_t eq[16];


 uint32_t eq_count;
 uint32_t cq_count;
 uint32_t mq_count;
 uint32_t wq_count;
 uint32_t rq_count;
 ocs_list_t eq_list;

 ocs_queue_hash_t cq_hash[((( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) | (( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) >>16) ) + 1)];
 ocs_queue_hash_t rq_hash[((( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) | (( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) >>16) ) + 1)];
 ocs_queue_hash_t wq_hash[((( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) | (( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) | ( ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) | ( ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) | ( ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) | ( ((((1) > (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))))) ? (1) : (((32) > (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))))) ? (32) : (((16) > (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2))))) ? (16) : (((32) > (((32*2) + 1 + (16 * 2))) ? (32) : (((32*2) + 1 + (16 * 2)))))))))))-1) >> 1) ) >> 2) ) >> 4) ) >> 8) ) >>16) ) + 1)];


 hw_wq_t *hw_wq[32];
 hw_rq_t *hw_rq[32];
 hw_mq_t *hw_mq[1];
 hw_cq_t *hw_cq[((32*2) + 1 + (16 * 2))];
 hw_eq_t *hw_eq[16];
 uint32_t hw_rq_count;
 uint32_t hw_mrq_count;

 ocs_varray_t *wq_class_array[4];
 ocs_varray_t *wq_cpu_array[128];


 ocs_array_t *seq_pool;


 uint32_t auto_xfer_rdy_enabled:1,
   :31;
 ocs_pool_t *auto_xfer_rdy_buf_pool;


 ocs_lock_t cmd_lock;
 ocs_list_t cmd_head;
 ocs_list_t cmd_pending;
 uint32_t cmd_head_count;

 sli4_link_event_t link;
 ocs_hw_linkcfg_e linkcfg;
 uint32_t eth_license;

 struct {
  int32_t (*domain)(void *, ocs_hw_domain_event_e, void *);






  int32_t (*port)(void *, ocs_hw_port_event_e, void *);

  int32_t (*unsolicited)(void *, ocs_hw_sequence_t *);
  int32_t (*rnode)(void *, ocs_hw_remote_node_event_e, void *);
  int32_t (*bounce)(void (*)(void *arg), void *arg, uint32_t s_id, uint32_t d_id, uint32_t ox_id);
 } callback;
 struct {
  void *domain;
  void *port;
  void *unsolicited;
  void *rnode;
  void *bounce;
 } args;


 int32_t first_domain_idx;
 ocs_domain_t *domains[64];


 uint16_t fcf_index_fcfi[64];

 uint16_t fcf_indicator;

 ocs_hw_io_t **io;
 uint8_t *wqe_buffs;

 ocs_lock_t io_lock;
 ocs_lock_t io_abort_lock;
 ocs_list_t io_inuse;
 ocs_list_t io_timed_wqe;
 ocs_list_t io_wait_free;
 ocs_list_t io_free;
 ocs_list_t io_port_owned;
 ocs_list_t io_port_dnrx;

 ocs_dma_t loop_map;

 ocs_dma_t xfer_rdy;

 ocs_dma_t dump_sges;

 ocs_dma_t rnode_mem;

 ocs_dma_t domain_dmem;
 ocs_dma_t fcf_dmem;

 ocs_hw_rpi_ref_t *rpi_ref;

 char *hw_war_version;
 ocs_hw_workaround_t workaround;

 ocs_atomic_t io_alloc_failed_count;





 ocs_list_t sec_hio_wait_list;
 uint32_t sec_hio_wait_count;



 ocs_hw_qtop_t *qtop;

 uint32_t tcmd_wq_submit[32];
 uint32_t tcmd_wq_complete[32];

 ocs_timer_t wqe_timer;
 ocs_timer_t watchdog_timer;
 bool expiration_logged;
 uint32_t in_active_wqe_timer:1,
   active_wqe_timer_shutdown:1,
   :30;

 ocs_list_t iopc_list;
 ocs_lock_t iopc_list_lock;

 ocs_pool_t *wq_reqtag_pool;

 ocs_atomic_t send_frame_seq_id;
};
struct hw_eq_s {
 ocs_list_link_t link;
 sli4_qtype_e type;
 uint32_t instance;
 uint32_t entry_count;
 uint32_t entry_size;
 ocs_hw_t *hw;
 sli4_queue_t *queue;
 ocs_list_t cq_list;



 ocs_varray_t *wq_array;
};
struct hw_cq_s {
 ocs_list_link_t link;
 sli4_qtype_e type;
 uint32_t instance;
 uint32_t entry_count;
 uint32_t entry_size;
 hw_eq_t *eq;
 sli4_queue_t *queue;
 ocs_list_t q_list;




};
struct hw_mq_s {
 ocs_list_link_t link;
 sli4_qtype_e type;
 uint32_t instance;

 uint32_t entry_count;
 uint32_t entry_size;
 hw_cq_t *cq;
 sli4_queue_t *queue;




};
struct hw_wq_s {
 ocs_list_link_t link;
 sli4_qtype_e type;
 uint32_t instance;
 ocs_hw_t *hw;

 uint32_t entry_count;
 uint32_t entry_size;
 hw_cq_t *cq;
 sli4_queue_t *queue;
 uint32_t class;
 uint8_t ulp;


 uint32_t wqec_set_count;
 uint32_t wqec_count;
 uint32_t free_count;
 uint32_t total_submit_count;
 ocs_list_t pending_list;
 ocs_quarantine_info_t quarantine_info;




 ocs_hw_io_t *send_frame_io;






};
struct hw_rq_s {
 ocs_list_link_t link;
 sli4_qtype_e type;
 uint32_t instance;

 uint32_t entry_count;
 uint32_t hdr_entry_size;
 uint32_t first_burst_entry_size;
 uint32_t data_entry_size;
 uint8_t ulp;
 bool is_mrq;
 uint32_t base_mrq_id;

 hw_cq_t *cq;

 uint8_t filter_mask;
 sli4_queue_t *hdr;
 sli4_queue_t *first_burst;
 sli4_queue_t *data;

 ocs_hw_rq_buffer_t *hdr_buf;
 ocs_hw_rq_buffer_t *fb_buf;
 ocs_hw_rq_buffer_t *payload_buf;

 ocs_hw_sequence_t **rq_tracker;






};
extern ocs_hw_rtn_e ocs_hw_io_register_sgl(ocs_hw_t *, ocs_hw_io_t *, ocs_dma_t *, uint32_t);
typedef struct {
 uint8_t scsi_status;
 uint16_t scsi_status_qualifier;
 uint8_t *response_data;
 uint32_t response_data_length;
 uint8_t *sense_data;
 uint32_t sense_data_length;
 int32_t residual;


 uint32_t response_wire_length;
} ocs_scsi_cmd_resp_t;
typedef enum {
 OCS_SCSI_STATUS_GOOD = 0,
 OCS_SCSI_STATUS_ABORTED,
 OCS_SCSI_STATUS_ERROR,
 OCS_SCSI_STATUS_DIF_GUARD_ERROR,
 OCS_SCSI_STATUS_DIF_REF_TAG_ERROR,
 OCS_SCSI_STATUS_DIF_APP_TAG_ERROR,
 OCS_SCSI_STATUS_DIF_UNKNOWN_ERROR,
 OCS_SCSI_STATUS_PROTOCOL_CRC_ERROR,
 OCS_SCSI_STATUS_NO_IO,
 OCS_SCSI_STATUS_ABORT_IN_PROGRESS,
 OCS_SCSI_STATUS_CHECK_RESPONSE,
 OCS_SCSI_STATUS_COMMAND_TIMEOUT,
 OCS_SCSI_STATUS_TIMEDOUT_AND_ABORTED,
 OCS_SCSI_STATUS_SHUTDOWN,
 OCS_SCSI_STATUS_NEXUS_LOST,

} ocs_scsi_io_status_e;
typedef int32_t (*ocs_scsi_io_cb_t)(ocs_io_t *io, ocs_scsi_io_status_e status, uint32_t flags,
 void *arg);
typedef int32_t (*ocs_scsi_rsp_io_cb_t)(ocs_io_t *io, ocs_scsi_io_status_e status, ocs_scsi_cmd_resp_t *rsp,
 uint32_t flags, void *arg);
typedef enum {
 OCS_SCSI_TMF_ABORT_TASK = 1,
 OCS_SCSI_TMF_QUERY_TASK_SET,
 OCS_SCSI_TMF_ABORT_TASK_SET,
 OCS_SCSI_TMF_CLEAR_TASK_SET,
 OCS_SCSI_TMF_QUERY_ASYNCHRONOUS_EVENT,
 OCS_SCSI_TMF_LOGICAL_UNIT_RESET,
 OCS_SCSI_TMF_CLEAR_ACA,
 OCS_SCSI_TMF_TARGET_RESET,
} ocs_scsi_tmf_cmd_e;
typedef enum {
 OCS_SCSI_DIF_OPER_DISABLED,
 OCS_SCSI_DIF_OPER_IN_NODIF_OUT_CRC,
 OCS_SCSI_DIF_OPER_IN_CRC_OUT_NODIF,
 OCS_SCSI_DIF_OPER_IN_NODIF_OUT_CHKSUM,
 OCS_SCSI_DIF_OPER_IN_CHKSUM_OUT_NODIF,
 OCS_SCSI_DIF_OPER_IN_CRC_OUT_CRC,
 OCS_SCSI_DIF_OPER_IN_CHKSUM_OUT_CHKSUM,
 OCS_SCSI_DIF_OPER_IN_CRC_OUT_CHKSUM,
 OCS_SCSI_DIF_OPER_IN_CHKSUM_OUT_CRC,
 OCS_SCSI_DIF_OPER_IN_RAW_OUT_RAW,
} ocs_scsi_dif_oper_e;
typedef enum {
 OCS_SCSI_DIF_BK_SIZE_512,
 OCS_SCSI_DIF_BK_SIZE_1024,
 OCS_SCSI_DIF_BK_SIZE_2048,
 OCS_SCSI_DIF_BK_SIZE_4096,
 OCS_SCSI_DIF_BK_SIZE_520,
 OCS_SCSI_DIF_BK_SIZE_4104
} ocs_scsi_dif_blk_size_e;
typedef struct ocs_scsi_sgl_s {
 uintptr_t addr;
 uintptr_t dif_addr;
 size_t len;
} ocs_scsi_sgl_t;
typedef struct ocs_scsi_dif_info_s {
 ocs_scsi_dif_oper_e dif_oper;
 ocs_scsi_dif_blk_size_e blk_size;
 uint32_t ref_tag;
 uint32_t app_tag:16,
  check_ref_tag:1,
  check_app_tag:1,
  check_guard:1,
  dif_separate:1,


  disable_app_ffff:1,


  disable_app_ref_ffff:1,
  :10;
 uint64_t lba;
} ocs_scsi_dif_info_t;
typedef enum {
 OCS_IO_TYPE_IO = 0,
 OCS_IO_TYPE_ELS,
 OCS_IO_TYPE_CT,
 OCS_IO_TYPE_CT_RESP,
 OCS_IO_TYPE_BLS_RESP,
 OCS_IO_TYPE_ABORT,

 OCS_IO_TYPE_MAX,
} ocs_io_type_e;
struct ocs_io_s {
 ocs_t *ocs;
 uint32_t instance_index;
 const char *display_name;
 ocs_node_t *node;
 ocs_list_link_t io_alloc_link;
 uint32_t init_task_tag;
 uint32_t tgt_task_tag;
 uint32_t hw_tag;
 uint32_t tag;
 ocs_scsi_sgl_t *sgl;
 uint32_t sgl_allocated;
 uint32_t sgl_count;
 ocs_scsi_ini_io_t ini_io;
 ocs_scsi_tgt_io_t tgt_io;
 uint32_t exp_xfer_len;
 ocs_mgmt_functions_t *mgmt_functions;


 void *hw_priv;


 ocs_io_type_e io_type;
 ocs_ref_t ref;
 void *dslab_item;
 ocs_hw_io_t *hio;
 size_t transferred;
 uint32_t auto_resp:1,
   low_latency:1,
   wq_steering:4,
   wq_class:4;
 uint32_t xfer_req;
 ocs_scsi_rsp_io_cb_t scsi_ini_cb;
 void *scsi_ini_cb_arg;
 ocs_scsi_io_cb_t scsi_tgt_cb;
 void *scsi_tgt_cb_arg;
 ocs_scsi_io_cb_t abort_cb;
 void *abort_cb_arg;
 ocs_scsi_io_cb_t bls_cb;
 void *bls_cb_arg;
 ocs_scsi_tmf_cmd_e tmf_cmd;
 uint16_t abort_rx_id;

 uint32_t cmd_tgt:1,
   send_abts:1,
   cmd_ini:1,
   seq_init:1;
 ocs_hw_io_param_t iparam;
 ocs_hw_dif_info_t hw_dif;
 ocs_scsi_dif_info_t scsi_dif_info;
 ocs_hw_io_type_e hio_type;
 uint32_t wire_len;
 void *hw_cb;
 ocs_list_link_t io_pending_link;

 ocs_dma_t ovfl_sgl;


 uint32_t els_pend:1,
  els_active:1;
 ocs_dma_t els_req;
 ocs_dma_t els_rsp;
 ocs_sm_ctx_t els_sm;
 uint32_t els_evtdepth;
 uint32_t els_req_free:1;
 uint32_t els_retries_remaining;
 void (*els_callback)(ocs_node_t *node, ocs_node_cb_t *cbdata, void *cbarg);
 void *els_callback_arg;
 uint32_t els_timeout_sec;

 ocs_timer_t delay_timer;


 ocs_io_t *io_to_abort;

 ocs_list_link_t link;
 ocs_dma_t cmdbuf;
 ocs_dma_t rspbuf;
 uint32_t timeout;
 uint8_t cs_ctl;
 uint8_t io_free;
 uint32_t app_id;
};
typedef struct ocs_io_pool_s ocs_io_pool_t;
typedef struct ocs_intr_ctx_s {
 uint32_t vec;
 void *softc;
 char name[64];
} ocs_intr_ctx_t;
typedef struct ocs_fc_rport_db_s {
 uint32_t node_id;
 uint32_t state;
 uint32_t port_id;
 uint64_t wwnn;
 uint64_t wwpn;
 uint32_t gone_timer;
} ocs_fc_target_t;
typedef struct ocs_fcport_s {
 ocs_t *ocs;
 struct cam_sim *sim;
 struct cam_path *path;
 uint32_t role;
 uint32_t fc_id;

 ocs_fc_target_t tgt[1024];
 int lost_device_time;
 struct callout ldt;
 struct task ltask;

 ocs_tgt_resource_t targ_rsrc_wildcard;
 ocs_tgt_resource_t targ_rsrc[512];
 ocs_vport_spec_t *vport;
} ocs_fcport;
struct ocs_softc {
 device_t dev;
 struct cdev *cdev;

 ocs_pci_reg_t reg[6];

 uint32_t instance_index;
 const char *desc;

 uint32_t irqid;
 struct resource *irq;
 void *tag;

 ocs_intr_ctx_t intr_ctx;
 uint32_t n_vec;

 bus_dma_tag_t dmat;
 bus_dma_tag_t buf_dmat;
 char display_name[32];
 uint16_t pci_vendor;
 uint16_t pci_device;
 uint16_t pci_subsystem_vendor;
 uint16_t pci_subsystem_device;
 char businfo[16];
 const char *driver_version;
 const char *fw_version;
 const char *model;

 ocs_hw_t hw;

 ocs_rlock_t lock;

 ocs_xport_e ocs_xport;
 ocs_xport_t *xport;
 ocs_domain_t *domain;
 ocs_list_t domain_list;
 uint32_t domain_instance_count;
 void (*domain_list_empty_cb)(ocs_t *ocs, void *arg);
 void *domain_list_empty_cb_arg;

 uint8_t enable_ini;
 uint8_t enable_tgt;
 uint8_t fc_type;
 int ctrlmask;
 uint8_t explicit_buffer_list;
 uint8_t external_loopback;
 uint8_t skip_hw_teardown;
 int speed;
 int topology;
 int ethernet_license;
 int num_scsi_ios;
 uint8_t enable_hlm;
 uint32_t hlm_group_size;
 uint32_t max_isr_time_msec;
 uint32_t auto_xfer_rdy_size;
 uint8_t esoc;
 int logmask;
 char *hw_war_version;
 uint32_t num_vports;
 uint32_t target_io_timer_sec;
 uint32_t hw_bounce;
 uint8_t rq_threads;
 uint8_t rq_selection_policy;
 uint8_t rr_quanta;
 char *filter_def;
 uint32_t max_remote_nodes;
 time_t tgt_rscn_delay_msec;
 time_t tgt_rscn_period_msec;

 uint32_t enable_task_set_full;
 uint32_t io_in_use;
 uint32_t io_high_watermark;
 struct mtx sim_lock;
 uint32_t config_tgt:1,
    config_ini:1;

 uint32_t nodedb_mask;

 char modeldesc[64];
 char serialnum[64];
 char fwrev[64];
 char sli_intf[9];

 ocs_ramlog_t *ramlog;
 ocs_textbuf_t ddump_saved;

 ocs_mgmt_functions_t *mgmt_functions;
 ocs_mgmt_functions_t *tgt_mgmt_functions;
 ocs_mgmt_functions_t *ini_mgmt_functions;

 ocs_err_injection_e err_injection;
 uint32_t cmd_err_inject;
 time_t delay_value_msec;

 bool attached;
 struct mtx dbg_lock;

 struct cam_devq *devq;
 ocs_fcport *fcports;

 void* tgt_ocs;
};
typedef struct ocs_xport_fcfi_s {
 ocs_lock_t pend_frames_lock;
 ocs_list_t pend_frames;
 uint32_t hold_frames:1;
 uint32_t pend_frames_processed;
} ocs_xport_fcfi_t;
typedef struct ocs_xport_rq_thread_info_s {
 ocs_t *ocs;
 uint8_t thread_started;
 ocs_thread_t thread;
 ocs_cbuf_t * seq_cbuf;
 char thread_name[64];
} ocs_xport_rq_thread_info_t;
typedef struct ocs_xport_link_stats_s {
 uint32_t rec:1,
    gec:1,
    w02of:1,
    w03of:1,
    w04of:1,
    w05of:1,
    w06of:1,
    w07of:1,
    w08of:1,
    w09of:1,
    w10of:1,
    w11of:1,
    w12of:1,
    w13of:1,
    w14of:1,
    w15of:1,
    w16of:1,
    w17of:1,
    w18of:1,
    w19of:1,
    w20of:1,
    w21of:1,
    resv0:8,
    clrc:1,
    clof:1;
 uint32_t link_failure_error_count;
 uint32_t loss_of_sync_error_count;
 uint32_t loss_of_signal_error_count;
 uint32_t primitive_sequence_error_count;
 uint32_t invalid_transmission_word_error_count;
 uint32_t crc_error_count;
 uint32_t primitive_sequence_event_timeout_count;
 uint32_t elastic_buffer_overrun_error_count;
 uint32_t arbitration_fc_al_timout_count;
 uint32_t advertised_receive_bufftor_to_buffer_credit;
 uint32_t current_receive_buffer_to_buffer_credit;
 uint32_t advertised_transmit_buffer_to_buffer_credit;
 uint32_t current_transmit_buffer_to_buffer_credit;
 uint32_t received_eofa_count;
 uint32_t received_eofdti_count;
 uint32_t received_eofni_count;
 uint32_t received_soff_count;
 uint32_t received_dropped_no_aer_count;
 uint32_t received_dropped_no_available_rpi_resources_count;
 uint32_t received_dropped_no_available_xri_resources_count;
} ocs_xport_link_stats_t;
typedef struct ocs_xport_host_stats_s {
 uint32_t cc:1,
      :31;
 uint32_t transmit_kbyte_count;
 uint32_t receive_kbyte_count;
 uint32_t transmit_frame_count;
 uint32_t receive_frame_count;
 uint32_t transmit_sequence_count;
 uint32_t receive_sequence_count;
 uint32_t total_exchanges_originator;
 uint32_t total_exchanges_responder;
 uint32_t receive_p_bsy_count;
 uint32_t receive_f_bsy_count;
 uint32_t dropped_frames_due_to_no_rq_buffer_count;
 uint32_t empty_rq_timeout_count;
 uint32_t dropped_frames_due_to_no_xri_count;
 uint32_t empty_xri_pool_count;
} ocs_xport_host_stats_t;
typedef struct ocs_xport_host_statistics_s {
 ocs_sem_t semaphore;
 ocs_xport_link_stats_t link_stats;
 ocs_xport_host_stats_t host_stats;
} ocs_xport_host_statistics_t;
typedef union ocs_xport {
 uint32_t value;
 ocs_xport_host_statistics_t stats;
} ocs_xport_stats_t;
struct ocs_xport_s {
 ocs_t *ocs;
 uint64_t req_wwpn;
 uint64_t req_wwnn;

 ocs_xport_fcfi_t fcfi[64];


 uint32_t nodes_count;
 ocs_node_t **nodes;
 ocs_list_t nodes_free_list;


 ocs_io_pool_t *io_pool;
 ocs_atomic_t io_alloc_failed_count;
 ocs_lock_t io_pending_lock;
 ocs_list_t io_pending_list;



 ocs_atomic_t io_total_alloc;
 ocs_atomic_t io_total_free;
 ocs_atomic_t io_total_pending;
 ocs_atomic_t io_active_count;
 ocs_atomic_t io_pending_count;
 ocs_atomic_t io_pending_recursing;


 ocs_list_t vport_list;


 uint32_t configured_link_state;


 uint32_t num_rq_threads;
 ocs_xport_rq_thread_info_t *rq_thread_info;

 ocs_timer_t stats_timer;
 ocs_xport_stats_t fc_xport_stats;
};
struct ocs_node_cb_s {
 ocs_io_t *io;
 int32_t status;
 int32_t ext_status;
 ocs_hw_rq_buffer_t *header;
 ocs_hw_rq_buffer_t *payload;
 ocs_io_t *els;
};
/*@ requires hw != ((void *)0) && io != ((void *)0); ensures \result == 0 || \result != 0; */

ocs_hw_rtn_e
ocs_hw_io_register_sgl(ocs_hw_t *hw, ocs_hw_io_t *io, ocs_dma_t *sgl, uint32_t sgl_count)
{
 if (sli_get_sgl_preregister(&hw->sli)) {
  do { if (1 <= loglevel) { _ocs_log(hw->os, __func__, 4405, "can't use temporary SGL with pre-registered SGLs\n"); } } while (0);;
  return OCS_HW_RTN_ERROR;
 }
 io->ovfl_sgl = sgl;
 io->ovfl_sgl_count = sgl_count;
 io->ovfl_io = ((void *)0);

 return OCS_HW_RTN_SUCCESS;
}
