typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
enum ethtool_link_mode_bit_indices {
 ETHTOOL_LINK_MODE_10baseT_Half_BIT = 0,
 ETHTOOL_LINK_MODE_10baseT_Full_BIT = 1,
 ETHTOOL_LINK_MODE_100baseT_Half_BIT = 2,
 ETHTOOL_LINK_MODE_100baseT_Full_BIT = 3,
 ETHTOOL_LINK_MODE_1000baseT_Half_BIT = 4,
 ETHTOOL_LINK_MODE_1000baseT_Full_BIT = 5,
 ETHTOOL_LINK_MODE_Autoneg_BIT = 6,
 ETHTOOL_LINK_MODE_TP_BIT = 7,
 ETHTOOL_LINK_MODE_AUI_BIT = 8,
 ETHTOOL_LINK_MODE_MII_BIT = 9,
 ETHTOOL_LINK_MODE_FIBRE_BIT = 10,
 ETHTOOL_LINK_MODE_BNC_BIT = 11,
 ETHTOOL_LINK_MODE_10000baseT_Full_BIT = 12,
 ETHTOOL_LINK_MODE_Pause_BIT = 13,
 ETHTOOL_LINK_MODE_Asym_Pause_BIT = 14,
 ETHTOOL_LINK_MODE_2500baseX_Full_BIT = 15,
 ETHTOOL_LINK_MODE_Backplane_BIT = 16,
 ETHTOOL_LINK_MODE_1000baseKX_Full_BIT = 17,
 ETHTOOL_LINK_MODE_10000baseKX4_Full_BIT = 18,
 ETHTOOL_LINK_MODE_10000baseKR_Full_BIT = 19,
 ETHTOOL_LINK_MODE_10000baseR_FEC_BIT = 20,
 ETHTOOL_LINK_MODE_20000baseMLD2_Full_BIT = 21,
 ETHTOOL_LINK_MODE_20000baseKR2_Full_BIT = 22,
 ETHTOOL_LINK_MODE_40000baseKR4_Full_BIT = 23,
 ETHTOOL_LINK_MODE_40000baseCR4_Full_BIT = 24,
 ETHTOOL_LINK_MODE_40000baseSR4_Full_BIT = 25,
 ETHTOOL_LINK_MODE_40000baseLR4_Full_BIT = 26,
 ETHTOOL_LINK_MODE_56000baseKR4_Full_BIT = 27,
 ETHTOOL_LINK_MODE_56000baseCR4_Full_BIT = 28,
 ETHTOOL_LINK_MODE_56000baseSR4_Full_BIT = 29,
 ETHTOOL_LINK_MODE_56000baseLR4_Full_BIT = 30,
 ETHTOOL_LINK_MODE_25000baseCR_Full_BIT = 31,







 ETHTOOL_LINK_MODE_25000baseKR_Full_BIT = 32,
 ETHTOOL_LINK_MODE_25000baseSR_Full_BIT = 33,
 ETHTOOL_LINK_MODE_50000baseCR2_Full_BIT = 34,
 ETHTOOL_LINK_MODE_50000baseKR2_Full_BIT = 35,
 ETHTOOL_LINK_MODE_100000baseKR4_Full_BIT = 36,
 ETHTOOL_LINK_MODE_100000baseSR4_Full_BIT = 37,
 ETHTOOL_LINK_MODE_100000baseCR4_Full_BIT = 38,
 ETHTOOL_LINK_MODE_100000baseLR4_ER4_Full_BIT = 39,
 ETHTOOL_LINK_MODE_50000baseSR2_Full_BIT = 40,
 ETHTOOL_LINK_MODE_1000baseX_Full_BIT = 41,
 ETHTOOL_LINK_MODE_10000baseCR_Full_BIT = 42,
 ETHTOOL_LINK_MODE_10000baseSR_Full_BIT = 43,
 ETHTOOL_LINK_MODE_10000baseLR_Full_BIT = 44,
 ETHTOOL_LINK_MODE_10000baseLRM_Full_BIT = 45,
 ETHTOOL_LINK_MODE_10000baseER_Full_BIT = 46,
 ETHTOOL_LINK_MODE_2500baseT_Full_BIT = 47,
 ETHTOOL_LINK_MODE_5000baseT_Full_BIT = 48,

 ETHTOOL_LINK_MODE_FEC_NONE_BIT = 49,
 ETHTOOL_LINK_MODE_FEC_RS_BIT = 50,
 ETHTOOL_LINK_MODE_FEC_BASER_BIT = 51,
 ETHTOOL_LINK_MODE_50000baseKR_Full_BIT = 52,
 ETHTOOL_LINK_MODE_50000baseSR_Full_BIT = 53,
 ETHTOOL_LINK_MODE_50000baseCR_Full_BIT = 54,
 ETHTOOL_LINK_MODE_50000baseLR_ER_FR_Full_BIT = 55,
 ETHTOOL_LINK_MODE_50000baseDR_Full_BIT = 56,
 ETHTOOL_LINK_MODE_100000baseKR2_Full_BIT = 57,
 ETHTOOL_LINK_MODE_100000baseSR2_Full_BIT = 58,
 ETHTOOL_LINK_MODE_100000baseCR2_Full_BIT = 59,
 ETHTOOL_LINK_MODE_100000baseLR2_ER2_FR2_Full_BIT = 60,
 ETHTOOL_LINK_MODE_100000baseDR2_Full_BIT = 61,
 ETHTOOL_LINK_MODE_200000baseKR4_Full_BIT = 62,
 ETHTOOL_LINK_MODE_200000baseSR4_Full_BIT = 63,
 ETHTOOL_LINK_MODE_200000baseLR4_ER4_FR4_Full_BIT = 64,
 ETHTOOL_LINK_MODE_200000baseDR4_Full_BIT = 65,
 ETHTOOL_LINK_MODE_200000baseCR4_Full_BIT = 66,
 ETHTOOL_LINK_MODE_100baseT1_Full_BIT = 67,
 ETHTOOL_LINK_MODE_1000baseT1_Full_BIT = 68,
 ETHTOOL_LINK_MODE_400000baseKR8_Full_BIT = 69,
 ETHTOOL_LINK_MODE_400000baseSR8_Full_BIT = 70,
 ETHTOOL_LINK_MODE_400000baseLR8_ER8_FR8_Full_BIT = 71,
 ETHTOOL_LINK_MODE_400000baseDR8_Full_BIT = 72,
 ETHTOOL_LINK_MODE_400000baseCR8_Full_BIT = 73,
 ETHTOOL_LINK_MODE_FEC_LLRS_BIT = 74,
 ETHTOOL_LINK_MODE_100000baseKR_Full_BIT = 75,
 ETHTOOL_LINK_MODE_100000baseSR_Full_BIT = 76,
 ETHTOOL_LINK_MODE_100000baseLR_ER_FR_Full_BIT = 77,
 ETHTOOL_LINK_MODE_100000baseCR_Full_BIT = 78,
 ETHTOOL_LINK_MODE_100000baseDR_Full_BIT = 79,
 ETHTOOL_LINK_MODE_200000baseKR2_Full_BIT = 80,
 ETHTOOL_LINK_MODE_200000baseSR2_Full_BIT = 81,
 ETHTOOL_LINK_MODE_200000baseLR2_ER2_FR2_Full_BIT = 82,
 ETHTOOL_LINK_MODE_200000baseDR2_Full_BIT = 83,
 ETHTOOL_LINK_MODE_200000baseCR2_Full_BIT = 84,
 ETHTOOL_LINK_MODE_400000baseKR4_Full_BIT = 85,
 ETHTOOL_LINK_MODE_400000baseSR4_Full_BIT = 86,
 ETHTOOL_LINK_MODE_400000baseLR4_ER4_FR4_Full_BIT = 87,
 ETHTOOL_LINK_MODE_400000baseDR4_Full_BIT = 88,
 ETHTOOL_LINK_MODE_400000baseCR4_Full_BIT = 89,
 ETHTOOL_LINK_MODE_100baseFX_Half_BIT = 90,
 ETHTOOL_LINK_MODE_100baseFX_Full_BIT = 91,
 ETHTOOL_LINK_MODE_10baseT1L_Full_BIT = 92,
 ETHTOOL_LINK_MODE_800000baseCR8_Full_BIT = 93,
 ETHTOOL_LINK_MODE_800000baseKR8_Full_BIT = 94,
 ETHTOOL_LINK_MODE_800000baseDR8_Full_BIT = 95,
 ETHTOOL_LINK_MODE_800000baseDR8_2_Full_BIT = 96,
 ETHTOOL_LINK_MODE_800000baseSR8_Full_BIT = 97,
 ETHTOOL_LINK_MODE_800000baseVR8_Full_BIT = 98,
 ETHTOOL_LINK_MODE_10baseT1S_Full_BIT = 99,
 ETHTOOL_LINK_MODE_10baseT1S_Half_BIT = 100,
 ETHTOOL_LINK_MODE_10baseT1S_P2MP_Half_BIT = 101,
 ETHTOOL_LINK_MODE_10baseT1BRR_Full_BIT = 102,
 ETHTOOL_LINK_MODE_200000baseCR_Full_BIT = 103,
 ETHTOOL_LINK_MODE_200000baseKR_Full_BIT = 104,
 ETHTOOL_LINK_MODE_200000baseDR_Full_BIT = 105,
 ETHTOOL_LINK_MODE_200000baseDR_2_Full_BIT = 106,
 ETHTOOL_LINK_MODE_200000baseSR_Full_BIT = 107,
 ETHTOOL_LINK_MODE_200000baseVR_Full_BIT = 108,
 ETHTOOL_LINK_MODE_400000baseCR2_Full_BIT = 109,
 ETHTOOL_LINK_MODE_400000baseKR2_Full_BIT = 110,
 ETHTOOL_LINK_MODE_400000baseDR2_Full_BIT = 111,
 ETHTOOL_LINK_MODE_400000baseDR2_2_Full_BIT = 112,
 ETHTOOL_LINK_MODE_400000baseSR2_Full_BIT = 113,
 ETHTOOL_LINK_MODE_400000baseVR2_Full_BIT = 114,
 ETHTOOL_LINK_MODE_800000baseCR4_Full_BIT = 115,
 ETHTOOL_LINK_MODE_800000baseKR4_Full_BIT = 116,
 ETHTOOL_LINK_MODE_800000baseDR4_Full_BIT = 117,
 ETHTOOL_LINK_MODE_800000baseDR4_2_Full_BIT = 118,
 ETHTOOL_LINK_MODE_800000baseSR4_Full_BIT = 119,
 ETHTOOL_LINK_MODE_800000baseVR4_Full_BIT = 120,


 __ETHTOOL_LINK_MODE_MASK_NBITS
};
/*@ requires true; ensures (\result & ~(0x0100 | 0x0200)) == 0 && ((ethadv & (1UL << (ETHTOOL_LINK_MODE_1000baseT_Half_BIT))) != 0 <==> (\result & 0x0100) != 0) && ((ethadv & (1UL << (ETHTOOL_LINK_MODE_1000baseT_Full_BIT))) != 0 <==> (\result & 0x0200) != 0); */

static inline    u32 ethtool_adv_to_mii_ctrl1000_t(u32 ethadv)
{
 u32 result = 0;

 if (ethadv & (1UL << (ETHTOOL_LINK_MODE_1000baseT_Half_BIT)))
  result |= 0x0100;
 if (ethadv & (1UL << (ETHTOOL_LINK_MODE_1000baseT_Full_BIT)))
  result |= 0x0200;

 return result;
}

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
enum { bv_const_0 = (ETHTOOL_LINK_MODE_1000baseT_Full_BIT) };
enum { bv_const_1 = (ETHTOOL_LINK_MODE_1000baseT_Half_BIT) };
int main(void) {
  u32 ethadv;
  __CPROVER_assume(((((__int128)1)) != 0));
  u32 bv_r = ethtool_adv_to_mii_ctrl1000_t(ethadv);
  __CPROVER_assert((((__int128)((((__int128)((((__int128)(((((__int128)bv_r) & (~((((__int128)0x0100ULL) | ((__int128)0x0200ULL)))))) == ((__int128)0ULL))) != 0) && ((((__int128)((((__int128)(((((__int128)(ethadv)) & (bv_shl(((__int128)1ULL), (((__int128)(ETHTOOL_LINK_MODE_1000baseT_Half_BIT))))))) != ((__int128)0ULL))) != 0) == (((__int128)(((((__int128)bv_r) & ((__int128)0x0100ULL))) != ((__int128)0ULL))) != 0)))) != 0))) != 0) && ((((__int128)((((__int128)(((((__int128)(ethadv)) & (bv_shl(((__int128)1ULL), (((__int128)(ETHTOOL_LINK_MODE_1000baseT_Full_BIT))))))) != ((__int128)0ULL))) != 0) == (((__int128)(((((__int128)bv_r) & ((__int128)0x0200ULL))) != ((__int128)0ULL))) != 0)))) != 0))) != 0), "ensures");
  return 0;
}
