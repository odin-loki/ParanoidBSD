__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == 52 || \result == 48; */

static inline    u64 kvm_get_parange_max(void)
{
 if (system_supports_lpa2() ||
    (0 && 12 == 16))
  return ID_AA64MMFR0_EL1_PARANGE_52;
 else
  return ID_AA64MMFR0_EL1_PARANGE_48;
}
