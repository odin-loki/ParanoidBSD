/*@ requires new >= start && end_data >= start_data; ensures \result == 0 || \result == -28; ensures \result == -28 <==> (rlim < (~0UL) && (new - start) + (end_data - start_data) > rlim); */

static inline    int check_data_rlimit(unsigned long rlim,
        unsigned long new,
        unsigned long start,
        unsigned long end_data,
        unsigned long start_data)
{
 if (rlim < (~0UL)) {
  if (((new - start) + (end_data - start_data)) > rlim)
   return -28;
 }

 return 0;
}
