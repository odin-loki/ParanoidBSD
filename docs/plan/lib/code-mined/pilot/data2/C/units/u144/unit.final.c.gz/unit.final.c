__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
extern u64 amd_iommu_efr;
/*@ requires true; ensures \result == ((amd_iommu_efr & mask) != 0); */

static inline    bool check_feature(u64 mask)
{
 return (amd_iommu_efr & mask);
}
