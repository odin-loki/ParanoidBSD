static __inline  int
ffsl(long mask)
;
/*@ requires mask != 0; ensures 0 <= \result && \result < 64 && (mask & (1L << \result)) != 0 && ((mask & ((1L << \result) - 1)) == 0); */

static inline int
__ffsl(long mask)
{
 return (ffsl(mask) - 1);
}
