/*@ requires 0 <= num && num < 16 && (dir == 1 || dir == 0); ensures \result == num + (dir == 1 ? 16 : 0); */

static inline    int hw_ep_bit(int num, int dir)
{
 return num + ((dir == 1) ? 16 : 0);
}
