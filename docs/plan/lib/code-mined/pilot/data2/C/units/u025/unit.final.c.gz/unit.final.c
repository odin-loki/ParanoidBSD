typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires \true; ensures \result == 0 || \result == 1; */

static bool stm32_dma_is_burst_possible(u32 buf_len, u32 threshold)
{

 if (threshold == 0x04)
  return false;






 return ((buf_len % ((threshold + 1) * 4)) == 0);
}
