typedef long int __time_t;
typedef int __clockid_t;
typedef long int __syscall_slong_t;
typedef __clockid_t clockid_t;
typedef __time_t time_t;
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
};
extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
      ;
static void error(const char *s)
;
/*@ requires 1; ensures \result >= 0; */

static time_t current_nsec(void)
{
 struct timespec ts;

 if (clock_gettime(
                  0
                                , &ts))
  error("clock_gettime");

 return (ts.tv_sec * (1000000000ULL)) + ts.tv_nsec;
}
