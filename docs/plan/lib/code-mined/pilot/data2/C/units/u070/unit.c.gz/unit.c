typedef unsigned char __u8;
typedef unsigned short __u16;
typedef __u8 u8;
typedef __u16 u16;
enum {
 false = 0,
 true = 1
};
typedef struct {
 int counter;
} atomic_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
enum lockdep_wait_type {
 LD_WAIT_INV = 0,

 LD_WAIT_FREE,
 LD_WAIT_SPIN,


 LD_WAIT_CONFIG,



 LD_WAIT_SLEEP,

 LD_WAIT_MAX,
};
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct qspinlock;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
extern void __raw_spin_lock_init(raw_spinlock_t *lock, const char *name,
       struct lock_class_key *key, short inner);
static inline     raw_spinlock_t *spinlock_check(spinlock_t *lock)
;
struct comedi_device;
struct comedi_device;
/*@ requires \true; ensures (\result == 0 ==> dev->private != \null) && (\result == -12 ==> dev->private == \null); */

static int ni_alloc_private(struct comedi_device *dev)
{
 struct ni_private *devpriv;

 devpriv = comedi_alloc_devpriv(dev, sizeof(*devpriv));
 if (!devpriv)
  return -12;

 do { static struct lock_class_key __key; __raw_spin_lock_init(spinlock_check(&devpriv->window_lock), "&devpriv->window_lock", &__key, LD_WAIT_CONFIG); } while (0);
 do { static struct lock_class_key __key; __raw_spin_lock_init(spinlock_check(&devpriv->soft_reg_copy_lock), "&devpriv->soft_reg_copy_lock", &__key, LD_WAIT_CONFIG); } while (0);
 do { static struct lock_class_key __key; __raw_spin_lock_init(spinlock_check(&devpriv->mite_channel_lock), "&devpriv->mite_channel_lock", &__key, LD_WAIT_CONFIG); } while (0);

 return 0;
}
