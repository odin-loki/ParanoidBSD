/*@ requires 0 <= val; ensures \result == val/0xccc+0x06; */

static int tda9855_bass(int val) { return val/0xccc+0x06; }
