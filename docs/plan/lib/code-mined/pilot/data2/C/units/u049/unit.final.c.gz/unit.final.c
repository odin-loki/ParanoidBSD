typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
typedef u32 uint32_t;
typedef u64 uint64_t;
/*@ requires m != 0; ensures \result == parent * n / m; */

static unsigned long ccu_nm_calc_rate(unsigned long parent,
          unsigned long n, unsigned long m)
{
 u64 rate = parent;

 rate *= n;
 ({ uint32_t __base = (m); uint32_t __rem; __rem = ((uint64_t)(rate)) % __base; (rate) = ((uint64_t)(rate)) / __base; __rem; });

 return rate;
}
