typedef __signed__ int __s32;
__extension__ typedef __signed__ long long __s64;
typedef __s32 s32;
typedef __s64 s64;
static inline    s64 div_s64(s64 dividend, s32 divisor)
;
/*@ requires cycle_time > 0; ensures \result >= now && \result == base_time + n * cycle_time && n >= 0 && (base_time >= now ==> \result == base_time); */

static inline    s64 future_base_time(s64 base_time, s64 cycle_time, s64 now)
{
 s64 a, b, n;

 if (base_time >= now)
  return base_time;

 a = now - base_time;
 b = cycle_time;
 n = div_s64(a + b - 1, b);

 return base_time + n * cycle_time;
}
