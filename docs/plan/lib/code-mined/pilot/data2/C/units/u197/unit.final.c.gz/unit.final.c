enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures wcaps == 0 ? \result == -1 : \result == ((wcaps & (0xf<<20)) >> 20); */

static inline    int snd_hdac_get_wcaps_type(unsigned int wcaps)
{
 if (!wcaps)
  return -1;
 return (wcaps & (0xf<<20)) >> 20;
}
