typedef unsigned int __u32;
typedef __u32 u32;
/*@ requires cid <= 0xFFFFFFFF / (4); ensures \result == (DEMS << 2) + cid * (4); */

static inline    u32 qed_db_addr(u32 cid, u32 DEMS)
{
 u32 db_addr = ((DEMS & 0x7) << 2) |
        (cid * (4));

 return db_addr;
}
