typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result <= ((((1UL))) << (20)); */

static u32 size_h264d_vpp_cmd_buf(u32 height)
{
 u32 aligned_height = ((((height)) + ((__typeof__((height)))((32)) - 1)) & ~((__typeof__((height)))((32)) - 1));
 u32 size;

 size = ({ u32 __UNIQUE_ID_x_1208 = ((((aligned_height + 15) >> 4) * 3 * 4)); u32 __UNIQUE_ID_y_1209 = (1800); ((__UNIQUE_ID_x_1208) < (__UNIQUE_ID_y_1209) ? (__UNIQUE_ID_x_1208) : (__UNIQUE_ID_y_1209)); })
                        * 512;
 if (size > ((((1UL))) << (20)))
  size = ((((1UL))) << (20));

 return size;
}
