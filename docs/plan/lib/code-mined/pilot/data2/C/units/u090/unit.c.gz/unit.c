typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __u8 u8;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef unsigned short umode_t;
typedef _Bool bool;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;

int _printk(const char *fmt, ...);
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
static inline     bool arch_static_branch(struct static_key * const key, const bool branch)
;
static inline     bool arch_static_branch_jump(struct static_key * const key, const bool branch)
;
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
extern bool ____wrong_branch_error(void);
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
extern 
void __dynamic_pr_debug(struct _ddebug *descriptor, const char *fmt, ...);
struct module;
struct file;
struct qspinlock;
struct completion;
typedef atomic64_t atomic_long_t;
struct static_key;
struct module;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct file;
struct optimistic_spin_queue {




 atomic_t tail;
};
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct module;
struct configfs_item_operations;
struct configfs_group_operations;
struct configfs_attribute;
struct configfs_bin_attribute;
struct configfs_subsystem;
struct config_item {
 char *ci_name;
 char ci_namebuf[20];
 struct kref ci_kref;
 struct list_head ci_entry;
 struct config_item *ci_parent;
 struct config_group *ci_group;
 const struct config_item_type *ci_type;
 struct dentry *ci_dentry;
};
struct config_item_type {
 struct module *ct_owner;
 struct configfs_item_operations *ct_item_ops;
 struct configfs_group_operations *ct_group_ops;
 struct configfs_attribute **ct_attrs;
 struct configfs_bin_attribute **ct_bin_attrs;
};
struct config_group {
 struct config_item cg_item;
 struct list_head cg_children;
 struct configfs_subsystem *cg_subsys;
 struct list_head default_groups;
 struct list_head group_entry;
};
struct configfs_attribute {
 const char *ca_name;
 struct module *ca_owner;
 umode_t ca_mode;
 ssize_t (*show)(struct config_item *, char *);
 ssize_t (*store)(struct config_item *, const char *, size_t);
};
struct file;
struct configfs_bin_attribute {
 struct configfs_attribute cb_attr;
 void *cb_private;
 size_t cb_max_size;
 ssize_t (*read)(struct config_item *, void *, size_t);
 ssize_t (*write)(struct config_item *, const void *, size_t);
};
struct configfs_item_operations {
 void (*release)(struct config_item *);
 int (*allow_link)(struct config_item *src, struct config_item *target);
 void (*drop_link)(struct config_item *src, struct config_item *target);
};
struct configfs_group_operations {
 struct config_item *(*make_item)(struct config_group *group, const char *name);
 struct config_group *(*make_group)(struct config_group *group, const char *name);
 void (*disconnect_notify)(struct config_group *group, struct config_item *item);
 void (*drop_item)(struct config_group *group, struct config_item *item);
 bool (*is_visible)(struct config_item *item, struct configfs_attribute *attr, int n);
 bool (*is_bin_visible)(struct config_item *item, struct configfs_bin_attribute *attr,
          int n);
};
struct configfs_subsystem {
 struct config_group su_group;
 struct mutex su_mutex;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct sbitmap_word {



 unsigned long word;




 unsigned long cleared ;




 raw_spinlock_t swap_lock;
} ;
struct sbitmap {



 unsigned int depth;




 unsigned int shift;




 unsigned int map_nr;




 bool round_robin;




 struct sbitmap_word *map;







 unsigned int *alloc_hint;
};
struct sbq_wait_state {



 wait_queue_head_t wait;
} ;
struct sbitmap_queue {



 struct sbitmap sb;





 unsigned int wake_batch;




 atomic_t wake_index;




 struct sbq_wait_state *ws;




 atomic_t ws_active;





 unsigned int min_shallow_depth;





 atomic_t completion_cnt;




 atomic_t wakeup_cnt;
};
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;


 unsigned long last_holder;

};
struct t10_alua {

 u16 alua_tg_pt_gps_counter;
 u32 alua_tg_pt_gps_count;

 spinlock_t lba_map_lock;
 u32 lba_map_segment_size;
 u32 lba_map_segment_multiplier;
 struct list_head lba_map_list;
 spinlock_t tg_pt_gps_lock;
 struct se_device *t10_dev;

 struct t10_alua_tg_pt_gp *default_tg_pt_gp;

 struct config_group alua_tg_pt_gps_group;
 struct list_head tg_pt_gps_list;
};
struct t10_alua_lu_gp {
 u16 lu_gp_id;
 int lu_gp_valid_id;
 u32 lu_gp_members;
 atomic_t lu_gp_ref_cnt;
 spinlock_t lu_gp_lock;
 struct config_group lu_gp_group;
 struct list_head lu_gp_node;
 struct list_head lu_gp_mem_list;
};
struct t10_alua_lu_gp_member {
 bool lu_gp_assoc;
 atomic_t lu_gp_mem_ref_cnt;
 spinlock_t lu_gp_mem_lock;
 struct t10_alua_lu_gp *lu_gp;
 struct se_device *lu_gp_mem_dev;
 struct list_head lu_gp_mem_list;
};
struct t10_alua_tg_pt_gp {
 u16 tg_pt_gp_id;
 int tg_pt_gp_valid_id;
 int tg_pt_gp_alua_supported_states;
 int tg_pt_gp_alua_access_status;
 int tg_pt_gp_alua_access_type;
 int tg_pt_gp_nonop_delay_msecs;
 int tg_pt_gp_trans_delay_msecs;
 int tg_pt_gp_implicit_trans_secs;
 int tg_pt_gp_pref;
 int tg_pt_gp_write_metadata;
 u32 tg_pt_gp_members;
 int tg_pt_gp_alua_access_state;
 atomic_t tg_pt_gp_ref_cnt;
 spinlock_t tg_pt_gp_lock;
 struct mutex tg_pt_gp_transition_mutex;
 struct se_device *tg_pt_gp_dev;
 struct config_group tg_pt_gp_group;
 struct list_head tg_pt_gp_list;
 struct list_head tg_pt_gp_lun_list;
 struct se_lun *tg_pt_gp_alua_lun;
 struct se_node_acl *tg_pt_gp_alua_nacl;
};
struct t10_wwn {




 char vendor[8 + 1];
 char model[16 + 1];
 char revision[4 + 1];
 char unit_serial[254];
 u32 company_id;
 spinlock_t t10_vpd_lock;
 struct se_device *t10_dev;
 struct config_group t10_wwn_group;
 struct list_head t10_vpd_list;
};
struct t10_pr_registration {


 char pr_reg_isid[16];

 unsigned char pr_iport[256];

 unsigned char pr_tport[256];
 u16 pr_aptpl_rpti;
 u16 pr_reg_tpgt;

 int pr_reg_all_tg_pt;

 int pr_reg_aptpl;
 int pr_res_holder;
 int pr_res_type;
 int pr_res_scope;

 bool isid_present_at_reg;
 u64 pr_res_mapped_lun;
 u64 pr_aptpl_target_lun;
 u16 tg_pt_sep_rtpi;
 u32 pr_res_generation;
 u64 pr_reg_bin_isid;
 u64 pr_res_key;
 atomic_t pr_res_holders;
 struct se_node_acl *pr_reg_nacl;

 struct se_dev_entry *pr_reg_deve;
 struct list_head pr_reg_list;
 struct list_head pr_reg_abort_list;
 struct list_head pr_reg_aptpl_list;
 struct list_head pr_reg_atp_list;
 struct list_head pr_reg_atp_mem_list;
};
struct t10_reservation {

 int pr_all_tg_pt;


 int pr_aptpl_active;
 u32 pr_generation;
 spinlock_t registration_lock;
 spinlock_t aptpl_reg_lock;
 struct se_node_acl *pr_res_holder;
 struct list_head registration_list;
 struct list_head aptpl_reg_list;
};
enum target_prot_op {
 TARGET_PROT_NORMAL = 0,
 TARGET_PROT_DIN_INSERT = (1 << 0),
 TARGET_PROT_DOUT_INSERT = (1 << 1),
 TARGET_PROT_DIN_STRIP = (1 << 2),
 TARGET_PROT_DOUT_STRIP = (1 << 3),
 TARGET_PROT_DIN_PASS = (1 << 4),
 TARGET_PROT_DOUT_PASS = (1 << 5),
};
enum target_prot_type {
 TARGET_DIF_TYPE0_PROT,
 TARGET_DIF_TYPE1_PROT,
 TARGET_DIF_TYPE2_PROT,
 TARGET_DIF_TYPE3_PROT,
};
enum target_ua_intlck_ctrl {
 TARGET_UA_INTLCK_CTRL_CLEAR = 0,
 TARGET_UA_INTLCK_CTRL_NO_CLEAR = 1,
 TARGET_UA_INTLCK_CTRL_ESTABLISH_UA = 2,
};
struct se_node_acl {
 char initiatorname[224];

 bool dynamic_node_acl;
 bool dynamic_stop;
 u32 queue_depth;
 u32 acl_index;
 enum target_prot_type saved_prot_type;
 char acl_tag[64];

 atomic_t acl_pr_ref_count;
 struct hlist_head lun_entry_hlist;
 struct se_session *nacl_sess;
 struct se_portal_group *se_tpg;
 struct mutex lun_entry_mutex;
 spinlock_t nacl_sess_lock;
 struct config_group acl_group;
 struct config_group acl_attrib_group;
 struct config_group acl_auth_group;
 struct config_group acl_param_group;
 struct config_group acl_fabric_stat_group;
 struct list_head acl_list;
 struct list_head acl_sess_list;
 struct completion acl_free_comp;
 struct kref acl_kref;
};
struct target_cmd_counter {
 struct percpu_ref refcnt;
 wait_queue_head_t refcnt_wq;
 struct completion stop_done;
 atomic_t stopped;
};
struct se_session {
 u64 sess_bin_isid;
 enum target_prot_op sup_prot_ops;
 enum target_prot_type sess_prot_type;
 struct se_node_acl *se_node_acl;
 struct se_portal_group *se_tpg;
 void *fabric_sess_ptr;
 struct list_head sess_list;
 struct list_head sess_acl_list;
 spinlock_t sess_cmd_lock;
 void *sess_cmd_map;
 struct sbitmap_queue sess_tag_pool;
 struct target_cmd_counter *cmd_cnt;
};
struct se_device;
struct se_ml_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_auth_intr_group;
 struct config_group scsi_att_intr_port_group;
};
struct se_lun_acl {
 u64 mapped_lun;
 struct se_node_acl *se_lun_nacl;
 struct se_lun *se_lun;
 struct config_group se_lun_group;
 struct se_ml_stat_grps ml_stat_grps;
};
struct se_dev_entry_io_stats {
 u64 total_cmds;
 u64 read_bytes;
 u64 write_bytes;
};
struct se_dev_entry {
 u64 mapped_lun;
 u64 pr_res_key;
 u64 creation_time;
 bool lun_access_ro;
 u32 attach_count;
 struct se_dev_entry_io_stats *stats;

 struct kref pr_kref;
 struct completion pr_comp;
 struct se_lun_acl *se_lun_acl;
 spinlock_t ua_lock;
 struct se_lun *se_lun;
 unsigned long deve_flags;
 struct list_head alua_port_list;
 struct list_head lun_link;
 struct list_head ua_list;
 struct hlist_node link;
 struct callback_head callback_head;
};
struct se_dev_attrib {
 bool emulate_model_alias;
 bool emulate_dpo;
 bool emulate_fua_write;
 bool emulate_fua_read;
 bool emulate_write_cache;
 enum target_ua_intlck_ctrl emulate_ua_intlck_ctrl;
 bool emulate_tas;
 bool emulate_tpu;
 bool emulate_tpws;
 bool emulate_caw;
 bool emulate_3pc;
 bool emulate_pr;
 bool emulate_rsoc;
 enum target_prot_type pi_prot_type;
 enum target_prot_type hw_pi_prot_type;
 bool pi_prot_verify;
 bool enforce_pr_isids;
 bool force_pr_aptpl;
 bool is_nonrot;
 bool emulate_rest_reord;
 bool unmap_zeroes_data;
 u32 hw_block_size;
 u32 block_size;
 u32 hw_max_sectors;
 u32 optimal_sectors;
 u32 hw_queue_depth;
 u32 queue_depth;
 u32 max_unmap_lba_count;
 u32 max_unmap_block_desc_count;
 u32 unmap_granularity;
 u32 unmap_granularity_alignment;
 u32 max_write_same_len;
 u8 submit_type;
 struct se_device *da_dev;
 struct config_group da_group;
};
struct se_port_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_port_group;
 struct config_group scsi_tgt_port_group;
 struct config_group scsi_transport_group;
};
struct scsi_port_stats {
 atomic_long_t cmd_pdus;
 atomic_long_t tx_data_octets;
 atomic_long_t rx_data_octets;
};
struct se_lun {
 u64 unpacked_lun;
 bool lun_shutdown;
 bool lun_access_ro;
 u32 lun_index;

 atomic_t lun_acl_count;
 struct se_device *lun_se_dev;

 struct list_head lun_deve_list;
 spinlock_t lun_deve_lock;


 int lun_tg_pt_secondary_stat;
 int lun_tg_pt_secondary_write_md;
 atomic_t lun_tg_pt_secondary_offline;
 struct mutex lun_tg_pt_md_mutex;


 struct list_head lun_tg_pt_gp_link;
 struct t10_alua_tg_pt_gp *lun_tg_pt_gp;
 spinlock_t lun_tg_pt_gp_lock;

 struct se_portal_group *lun_tpg;
 struct scsi_port_stats lun_stats;
 struct config_group lun_group;
 struct se_port_stat_grps port_stat_grps;
 struct completion lun_shutdown_comp;
 struct percpu_ref lun_ref;
 struct list_head lun_dev_link;
 struct hlist_node link;
 struct callback_head callback_head;
};
struct se_dev_stat_grps {
 struct config_group stat_group;
 struct config_group scsi_dev_group;
 struct config_group scsi_tgt_dev_group;
 struct config_group scsi_lu_group;
};
struct se_cmd_queue {
 struct llist_head cmd_list;
 struct work_struct work;
};
struct se_device_queue {
 struct list_head state_list;
 spinlock_t lock;
 struct se_cmd_queue sq;
};
struct se_dev_io_stats {
 u64 total_cmds;
 u64 read_bytes;
 u64 write_bytes;
};
struct se_device {

 u32 dev_cur_ordered_id;
 u32 dev_flags;
 u8 transport_flags;

 u32 queue_depth;

 u64 dev_res_bin_isid;

 u32 dev_index;
 u64 creation_time;
 atomic_long_t num_resets;
 atomic_long_t aborts_complete;
 atomic_long_t aborts_no_task;
 struct se_dev_io_stats *stats;

 struct percpu_ref non_ordered;
 bool ordered_sync_in_progress;
 atomic_t dev_qf_count;
 u32 export_count;
 spinlock_t delayed_cmd_lock;
 spinlock_t dev_reservation_lock;
 unsigned int dev_reservation_flags;
 spinlock_t se_port_lock;
 spinlock_t se_tmr_lock;
 spinlock_t qf_cmd_lock;
 struct semaphore caw_sem;

 struct se_session *reservation_holder;

 struct t10_alua_lu_gp_member *dev_alua_lu_gp_mem;

 struct t10_pr_registration *dev_pr_res_holder;
 struct list_head dev_sep_list;
 struct list_head dev_tmr_list;
 struct work_struct qf_work_queue;
 struct work_struct delayed_cmd_work;
 struct list_head delayed_cmd_list;
 struct list_head qf_cmd_list;

 struct se_hba *se_hba;

 struct t10_wwn t10_wwn;

 struct t10_alua t10_alua;

 struct t10_reservation t10_pr;
 struct se_dev_attrib dev_attrib;
 struct config_group dev_action_group;
 struct config_group dev_group;
 struct config_group dev_pr_group;
 struct se_dev_stat_grps dev_stat_grps;
 unsigned char dev_alias[512];
 unsigned char udev_path[512];

 const struct target_backend_ops *transport;
 struct se_lun xcopy_lun;

 int prot_length;

 u32 hba_index;
 struct callback_head callback_head;
 int queue_cnt;
 struct se_device_queue *queues;
 struct mutex lun_reset_mutex;
};
struct se_hba {
 u16 hba_tpgt;
 u32 hba_id;

 u32 hba_flags;

 u32 dev_count;
 u32 hba_index;

 void *hba_ptr;
 struct list_head hba_node;
 spinlock_t device_lock;
 struct config_group hba_group;
 struct mutex hba_access_mutex;
 struct target_backend *backend;
};
struct se_portal_group {





 int proto_id;
 bool enabled;

 u16 tpg_rtpi;
 bool rtpi_manual;

 atomic_t tpg_pr_ref_count;

 struct mutex acl_node_mutex;

 spinlock_t session_lock;
 struct mutex tpg_lun_mutex;

 struct list_head acl_node_list;
 struct hlist_head tpg_lun_hlist;
 struct se_lun *tpg_virt_lun0;

 struct list_head tpg_sess_list;

 const struct target_core_fabric_ops *se_tpg_tfo;
 struct se_wwn *se_tpg_wwn;
 struct config_group tpg_group;
 struct config_group tpg_lun_group;
 struct config_group tpg_np_group;
 struct config_group tpg_acl_group;
 struct config_group tpg_attrib_group;
 struct config_group tpg_auth_group;
 struct config_group tpg_param_group;
};
struct se_wwn {
 struct target_fabric_configfs *wwn_tf;
 void *priv;
 struct config_group wwn_group;
 struct config_group fabric_stat_group;
 struct config_group param_group;
 int cmd_compl_affinity;
};
struct file;
enum naf_flags_table {
 NAF_USERID_SET = 0x01,
 NAF_PASSWORD_SET = 0x02,
 NAF_USERID_IN_SET = 0x04,
 NAF_PASSWORD_IN_SET = 0x08,
};
struct iscsi_node_attrib {
 s32 authentication;
 u32 dataout_timeout;
 u32 dataout_timeout_retries;
 u32 default_erl;
 u32 nopin_timeout;
 u32 nopin_response_timeout;
 u32 random_datain_pdu_offsets;
 u32 random_datain_seq_offsets;
 u32 random_r2t_offsets;
 u32 tmr_cold_reset;
 u32 tmr_warm_reset;
 struct iscsi_node_acl *nacl;
};
struct iscsi_node_auth {
 enum naf_flags_table naf_flags;
 int authenticate_target;


 int enforce_discovery_auth;
 char userid[256];
 char password[256];
 char userid_mutual[256];
 char password_mutual[256];
};
struct iscsi_node_stat_grps {
 struct config_group iscsi_sess_stats_group;
 struct config_group iscsi_conn_stats_group;
};
struct iscsi_node_acl {
 struct se_node_acl se_node_acl;
 struct iscsi_node_attrib node_attrib;
 struct iscsi_node_auth node_auth;
 struct iscsi_node_stat_grps node_stat_grps;
};
struct se_node_acl;
struct iscsi_node_acl;
extern int iscsit_na_nopin_response_timeout(struct iscsi_node_acl *, u32);
static inline    char *iscsit_na_get_initiatorname(
 struct iscsi_node_acl *nacl)
;
/*@ requires true; ensures (nopin_response_timeout > 60 || nopin_response_timeout < 3) ? \result == -22 : (\result == 0 && a->nopin_response_timeout == nopin_response_timeout); */

int iscsit_na_nopin_response_timeout(
 struct iscsi_node_acl *acl,
 u32 nopin_response_timeout)
{
 struct iscsi_node_attrib *a = &acl->node_attrib;

 if (nopin_response_timeout > 60) {
  ({ do { if (__builtin_constant_p("\001" "3" "Requested NopIn Response Timeout %u larger" " than maximum %u\n") && __builtin_constant_p(((void *)0))) { static const struct pi_entry _entry  = { .fmt = __builtin_constant_p("\001" "3" "Requested NopIn Response Timeout %u larger" " than maximum %u\n") ? ("\001" "3" "Requested NopIn Response Timeout %u larger" " than maximum %u\n") : ((void *)0), .func = __func__, .file = "drivers/target/iscsi/iscsi_target_nodeattrib.c", .line = 157, .level = __builtin_constant_p(((void *)0)) ? (((void *)0)) : ((void *)0), .subsys_fmt_prefix = ((void *)0), }; static const struct pi_entry *_entry_ptr   = &_entry; } } while (0); _printk("\001" "3" "Requested NopIn Response Timeout %u larger" " than maximum %u\n", nopin_response_timeout, 60); })

                                  ;
  return -22;
 } else if (nopin_response_timeout < 3) {
  ({ do { if (__builtin_constant_p("\001" "3" "Requested NopIn Response Timeout %u smaller" " than minimum %u\n") && __builtin_constant_p(((void *)0))) { static const struct pi_entry _entry  = { .fmt = __builtin_constant_p("\001" "3" "Requested NopIn Response Timeout %u smaller" " than minimum %u\n") ? ("\001" "3" "Requested NopIn Response Timeout %u smaller" " than minimum %u\n") : ((void *)0), .func = __func__, .file = "drivers/target/iscsi/iscsi_target_nodeattrib.c", .line = 162, .level = __builtin_constant_p(((void *)0)) ? (((void *)0)) : ((void *)0), .subsys_fmt_prefix = ((void *)0), }; static const struct pi_entry *_entry_ptr   = &_entry; } } while (0); _printk("\001" "3" "Requested NopIn Response Timeout %u smaller" " than minimum %u\n", nopin_response_timeout, 3); })

                                  ;
  return -22;
 }

 a->nopin_response_timeout = nopin_response_timeout;
 do { static struct _ddebug   __UNIQUE_ID_ddebug739 = { .modname = "iscsi_target_mod", .function = __func__, .filename = "drivers/target/iscsi/iscsi_target_nodeattrib.c", .format = ("Set NopIn Response Timeout to %u for" " Initiator Node %s\n"), .lineno = 169, .flags = 0, .class_id = ((1 << 6) - 1), .key.dd_key_false = ((struct static_key_false){ .key = { .enabled = { 0 }, { .type = 0UL } }, }) }; do { __attribute__((__noreturn__)) extern void __compiletime_assert_740(void) ; if (!(!(((1 << 6) - 1) > ((1 << 6) - 1)))) __compiletime_assert_740(); } while (0); if (({ bool branch; if (__builtin_types_compatible_p(typeof(*&__UNIQUE_ID_ddebug739.key.dd_key_false), struct static_key_true)) branch = arch_static_branch_jump(&(&__UNIQUE_ID_ddebug739.key.dd_key_false)->key, false); else if (__builtin_types_compatible_p(typeof(*&__UNIQUE_ID_ddebug739.key.dd_key_false), struct static_key_false)) branch = arch_static_branch(&(&__UNIQUE_ID_ddebug739.key.dd_key_false)->key, false); else branch = ____wrong_branch_error(); __builtin_expect(!!(branch), 0); })) __dynamic_pr_debug(&__UNIQUE_ID_ddebug739, "Set NopIn Response Timeout to %u for" " Initiator Node %s\n", a->nopin_timeout, iscsit_na_get_initiatorname(acl)); } while (0)

                                   ;

 return 0;
}
