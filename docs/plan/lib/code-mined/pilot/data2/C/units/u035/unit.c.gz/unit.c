typedef _Bool bool;
enum criteria {





 CR_POWER2_ALIGNED,






 CR_GOAL_LEN_FAST,





 CR_BEST_AVAIL_LEN,







 CR_GOAL_LEN_SLOW,






 CR_ANY_FREE,




 EXT4_MB_NUM_CRS
};
/*@ requires 0 <= cr && cr <= CR_MAX; ensures \result == (cr >= CR_GOAL_LEN_SLOW); */

static inline    bool ext4_mb_cr_expensive(enum criteria cr)
{
 return cr >= CR_GOAL_LEN_SLOW;
}
