typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s8 int8_t;
typedef s32 int32_t;
typedef u8 uint8_t;
typedef u16 uint16_t;
typedef u32 uint32_t;
typedef u64 uint64_t;
typedef s64 int64_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef u64 phys_addr_t;
typedef phys_addr_t resource_size_t;
typedef unsigned long irq_hw_number_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
struct cacheline_padding {
 char x[1];
} ;
struct task_struct;
struct file_system_type;
struct task_struct;
struct mm_struct;
struct io_bitmap;
typedef __builtin_va_list va_list;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct va_format {
 const char *fmt;
 va_list *va;
};
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct kernel_param;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
static inline    pteval_t pte_flags(pte_t pte)
;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
struct mm_struct;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef struct cpumask *cpumask_var_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct static_key;
static inline    void halt(void)
;
extern unsigned long max_pfn;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct optimistic_spin_queue {




 atomic_t tail;
};
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : ( __builtin_constant_p((1L << 10)) ? ( (((1L << 10)) == 0 || ((1L << 10)) == 1) ? 1 : ( __builtin_constant_p((1L << 10)) ? (((1L << 10)) < 2 ? 0 : 63 - __builtin_clzll((1L << 10))) : (sizeof((1L << 10)) <= 4) ? __ilog2_u32((1L << 10)) : __ilog2_u64((1L << 10)) ) + 1 ) : __bits_per((1L << 10)) );
 unsigned int bucket_id : ( __builtin_constant_p(5) ? ( ((5) == 0 || (5) == 1) ? 1 : ( __builtin_constant_p(5) ? ((5) < 2 ? 0 : 63 - __builtin_clzll(5)) : (sizeof(5) <= 4) ? __ilog2_u32(5) : __ilog2_u64(5) ) + 1 ) : __bits_per(5) );
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
typedef __s64 time64_t;
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct module;
struct page;
struct vm_area_struct;
struct mm_struct;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
static inline     void udelay(unsigned long usec)
;
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
typedef struct wait_queue_entry wait_queue_entry_t;
typedef int (*wait_queue_func_t)(struct wait_queue_entry *wq_entry, unsigned mode, int flags, void *key);
struct wait_queue_entry {
 unsigned int flags;
 void *private;
 wait_queue_func_t func;
 struct list_head entry;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct device;
struct page;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct task_struct;
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct raw_notifier_head {
 struct notifier_block *head;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct resource;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct irq_domain;
struct timespec64;
struct pci_bus;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct firmware {
 size_t size;
 const u8 *data;


 void *priv;
};
struct module;
struct device;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct user_namespace;
struct uid_gid_map;
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct vm_area_struct;
struct file;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct cred;
struct file;
struct task_struct;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
struct sg_table;
struct file;
struct pid;
struct cred;
struct sock;
struct seq_file;
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct semaphore {
 raw_spinlock_t lock;
 unsigned int count;
 struct list_head wait_list;


 unsigned long last_holder;

};
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct interval_tree_node {
 struct rb_node rb;
 unsigned long start;
 unsigned long last;
 unsigned long __subtree_last;
};
struct mmu_notifier_subscriptions;
struct mmu_notifier_range;
struct mmu_interval_notifier;
enum mmu_notifier_event {
 MMU_NOTIFY_UNMAP = 0,
 MMU_NOTIFY_CLEAR,
 MMU_NOTIFY_PROTECTION_VMA,
 MMU_NOTIFY_PROTECTION_PAGE,
 MMU_NOTIFY_SOFT_DIRTY,
 MMU_NOTIFY_RELEASE,
 MMU_NOTIFY_MIGRATE,
 MMU_NOTIFY_EXCLUSIVE,
};
struct mmu_interval_notifier_ops {
 bool (*invalidate)(struct mmu_interval_notifier *interval_sub,
      const struct mmu_notifier_range *range,
      unsigned long cur_seq);
};
struct mmu_interval_notifier {
 struct interval_tree_node interval_tree;
 const struct mmu_interval_notifier_ops *ops;
 struct mm_struct *mm;
 struct hlist_node deferred_item;
 unsigned long invalidate_seq;
};
struct mmu_notifier_range {
 struct mm_struct *mm;
 unsigned long start;
 unsigned long end;
 unsigned flags;
 enum mmu_notifier_event event;
 void *owner;
};
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} guid_t;
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct ida {
 struct xarray xa;
};
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
typedef unsigned long kernel_ulong_t;
struct pci_device_id {
 __u32 vendor, device;
 __u32 subvendor, subdevice;
 __u32 class, class_mask;
 kernel_ulong_t driver_data;
 __u32 override_only;
};
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
struct platform_device_id {
 char name[24];
 kernel_ulong_t driver_data;
};
struct resource {
 resource_size_t start;
 resource_size_t end;
 const char *name;
 unsigned long flags;
 unsigned long desc;
 struct resource *parent, *sibling, *child;
};
struct device;
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct resource;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct pdev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_attribute {
 struct attribute attr;
 ssize_t (*show)(struct device *dev, struct device_attribute *attr,
   char *buf);
 ssize_t (*store)(struct device *dev, struct device_attribute *attr,
    const char *buf, size_t count);
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
extern char _data[], _sdata[], _edata[];
struct device;
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
struct pci_dev;
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct device;
struct device;
struct pci_slot {
 struct pci_bus *bus;
 struct list_head list;
 struct hotplug_slot *hotplug;
 u16 number;
 unsigned int per_func_slot:1;
 struct kobject kobj;
};
enum {

 PCI_STD_RESOURCES,
 PCI_STD_RESOURCE_END = PCI_STD_RESOURCES + 6 - 1,


 PCI_ROM_RESOURCE,



 PCI_IOV_RESOURCES,
 PCI_IOV_RESOURCE_END = PCI_IOV_RESOURCES + 6 - 1,









 PCI_BRIDGE_RESOURCES,
 PCI_BRIDGE_RESOURCE_END = PCI_BRIDGE_RESOURCES +
      4 - 1,


 PCI_NUM_RESOURCES,


 DEVICE_COUNT_RESOURCE = PCI_NUM_RESOURCES,
};
typedef int pci_power_t;
typedef unsigned int pci_channel_state_t;
typedef unsigned short pci_dev_flags_t;
typedef unsigned short pci_bus_flags_t;
struct pci_vpd {
 struct mutex lock;
 unsigned int len;
 u8 cap;
};
struct pcie_bwctrl_data;
struct pcie_link_state;
struct pci_sriov;
struct pci_p2pdma;
struct rcec_ea;
struct pci_dev {
 struct list_head bus_list;
 struct pci_bus *bus;
 struct pci_bus *subordinate;

 void *sysdata;
 struct proc_dir_entry *procent;
 struct pci_slot *slot;

 unsigned int devfn;
 unsigned short vendor;
 unsigned short device;
 unsigned short subsystem_vendor;
 unsigned short subsystem_device;
 unsigned int class;
 u8 revision;
 u8 hdr_type;

 u16 aer_cap;
 struct aer_info *aer_info;


 struct rcec_ea *rcec_ea;
 struct pci_dev *rcec;

 u32 devcap;
 u16 rebar_cap;
 u8 pcie_cap;
 u8 msi_cap;
 u8 msix_cap;
 u8 pcie_mpss:3;
 u8 rom_base_reg;
 u8 pin;
 u16 pcie_flags_reg;
 unsigned long *dma_alias_mask;

 struct pci_driver *driver;
 u64 dma_mask;





 struct device_dma_parameters dma_parms;

 pci_power_t current_state;


 u8 pm_cap;
 unsigned int pme_support:5;

 unsigned int pme_poll:1;
 unsigned int pinned:1;
 unsigned int config_rrs_sv:1;
 unsigned int imm_ready:1;
 unsigned int d1_support:1;
 unsigned int d2_support:1;
 unsigned int no_d1d2:1;
 unsigned int no_d3cold:1;
 unsigned int bridge_d3:1;
 unsigned int d3cold_allowed:1;
 unsigned int mmio_always_on:1;

 unsigned int wakeup_prepared:1;
 unsigned int skip_bus_pm:1;
 unsigned int ignore_hotplug:1;
 unsigned int hotplug_user_indicators:1;


 unsigned int clear_retrain_link:1;

 unsigned int no_bw_notif:1;
 unsigned int d3hot_delay;
 unsigned int d3cold_delay;

 u16 l1ss;

 struct pcie_link_state *link_state;
 unsigned int aspm_l0s_support:1;
 unsigned int aspm_l1_support:1;
 unsigned int ltr_path:1;


 unsigned int pasid_no_tlp:1;
 unsigned int eetlp_prefix_max:3;

 pci_channel_state_t error_state;
 struct device dev;

 int cfg_size;





 unsigned int irq;
 struct resource resource[DEVICE_COUNT_RESOURCE];
 struct resource driver_exclusive_resource;

 unsigned int transparent:1;
 unsigned int io_window:1;
 unsigned int pref_window:1;
 unsigned int pref_64_window:1;
 unsigned int multifunction:1;

 unsigned int is_busmaster:1;
 unsigned int no_msi:1;
 unsigned int no_64bit_msi:1;
 unsigned int block_cfg_access:1;
 unsigned int broken_parity_status:1;
 unsigned int irq_reroute_variant:2;
 unsigned int msi_enabled:1;
 unsigned int msix_enabled:1;
 unsigned int ari_enabled:1;
 unsigned int ats_enabled:1;
 unsigned int pasid_enabled:1;
 unsigned int pri_enabled:1;
 unsigned int tph_enabled:1;
 unsigned int is_managed:1;
 unsigned int is_msi_managed:1;
 unsigned int needs_freset:1;
 unsigned int state_saved:1;
 unsigned int is_physfn:1;
 unsigned int is_virtfn:1;
 unsigned int is_hotplug_bridge:1;
 unsigned int is_pciehp:1;
 unsigned int shpc_managed:1;
 unsigned int is_thunderbolt:1;







 unsigned int untrusted:1;





 unsigned int external_facing:1;
 unsigned int broken_intx_masking:1;
 unsigned int io_window_1k:1;
 unsigned int irq_managed:1;
 unsigned int non_compliant_bars:1;
 unsigned int is_probed:1;
 unsigned int link_active_reporting:1;
 unsigned int no_vf_scan:1;
 unsigned int no_command_memory:1;
 unsigned int rom_bar_overlap:1;
 unsigned int rom_attr_enabled:1;
 unsigned int non_mappable_bars:1;
 pci_dev_flags_t dev_flags;
 atomic_t enable_cnt;

 spinlock_t pcie_cap_lock;
 u32 saved_config_space[16];
 struct hlist_head saved_cap_space;
 struct bin_attribute *res_attr[DEVICE_COUNT_RESOURCE];
 struct bin_attribute *res_attr_wc[DEVICE_COUNT_RESOURCE];


 unsigned int broken_cmd_compl:1;


 u16 ptm_cap;
 unsigned int ptm_root:1;
 unsigned int ptm_enabled:1;
 u8 ptm_granularity;


 void *msix_base;
 raw_spinlock_t msi_lock;

 struct pci_vpd vpd;

 u16 dpc_cap;
 unsigned int dpc_rp_extensions:1;
 u8 dpc_rp_log_size;

 struct pcie_bwctrl_data *link_bwctrl;

 union {
  struct pci_sriov *sriov;
  struct pci_dev *physfn;
 };
 u16 ats_cap;
 u8 ats_stu;


 u16 pri_cap;
 u32 pri_reqs_alloc;
 unsigned int pasid_required:1;


 u16 pasid_cap;
 u16 pasid_features;


 struct pci_p2pdma *p2pdma;


 struct xarray doe_mbs;


 struct npem *npem;

 u16 acs_cap;
 u8 supported_speeds;
 phys_addr_t rom;
 size_t romlen;
 unsigned long priv_flags;


 u8 reset_methods[8];


 u16 tph_cap;
 u8 tph_mode;
 u8 tph_req_type;

};
struct pci_bus {
 struct list_head node;
 struct pci_bus *parent;
 struct list_head children;
 struct list_head devices;
 struct pci_dev *self;
 struct list_head slots;

 struct resource *resource[4];
 struct list_head resources;
 struct resource busn_res;

 struct pci_ops *ops;
 void *sysdata;
 struct proc_dir_entry *procdir;

 unsigned char number;
 unsigned char primary;
 unsigned char max_bus_speed;
 unsigned char cur_bus_speed;




 char name[48];

 unsigned short bridge_ctl;
 pci_bus_flags_t bus_flags;
 struct device *bridge;
 struct device dev;
 struct bin_attribute *legacy_io;
 struct bin_attribute *legacy_mem;
 unsigned int is_added:1;
 unsigned int unsafe_warn:1;
 unsigned int flit_mode:1;
};
struct pci_ops {
 int (*add_bus)(struct pci_bus *bus);
 void (*remove_bus)(struct pci_bus *bus);
 void *(*map_bus)(struct pci_bus *bus, unsigned int devfn, int where);
 int (*read)(struct pci_bus *bus, unsigned int devfn, int where, int size, u32 *val);
 int (*write)(struct pci_bus *bus, unsigned int devfn, int where, int size, u32 val);
};
struct pci_dynids {
 spinlock_t lock;
 struct list_head list;
};
typedef unsigned int pci_ers_result_t;
struct pci_error_handlers {

 pci_ers_result_t (*error_detected)(struct pci_dev *dev,
        pci_channel_state_t error);


 pci_ers_result_t (*mmio_enabled)(struct pci_dev *dev);


 pci_ers_result_t (*slot_reset)(struct pci_dev *dev);


 void (*reset_prepare)(struct pci_dev *dev);
 void (*reset_done)(struct pci_dev *dev);


 void (*resume)(struct pci_dev *dev);


 void (*cor_error_detected)(struct pci_dev *dev);
};
struct module;
struct pci_driver {
 const char *name;
 const struct pci_device_id *id_table;
 int (*probe)(struct pci_dev *dev, const struct pci_device_id *id);
 void (*remove)(struct pci_dev *dev);
 int (*suspend)(struct pci_dev *dev, pm_message_t state);
 int (*resume)(struct pci_dev *dev);
 void (*shutdown)(struct pci_dev *dev);
 int (*sriov_configure)(struct pci_dev *dev, int num_vfs);
 int (*sriov_set_msix_vec_count)(struct pci_dev *vf, int msix_vec_count);
 u32 (*sriov_get_vf_total_msix)(struct pci_dev *pf);
 const struct pci_error_handlers *err_handler;
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;
 struct device_driver driver;
 struct pci_dynids dynids;
 bool driver_managed_dma;
};
struct pglist_data;
struct file;
struct resource;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct device;
struct device_node;
struct attribute;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct kobject;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct mmu_notifier_range;
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct sg_table {
 struct scatterlist *sgl;
 unsigned int nents;
 unsigned int orig_nents;
};
struct device;
struct device_node;
struct irq_domain;
enum dma_data_direction {
 DMA_BIDIRECTIONAL = 0,
 DMA_TO_DEVICE = 1,
 DMA_FROM_DEVICE = 2,
 DMA_NONE = 3,
};
typedef unsigned int drm_magic_t;
struct drm_clip_rect {
 unsigned short x1;
 unsigned short y1;
 unsigned short x2;
 unsigned short y2;
};
enum drm_mode_subconnector {
 DRM_MODE_SUBCONNECTOR_Automatic = 0,
 DRM_MODE_SUBCONNECTOR_Unknown = 0,
 DRM_MODE_SUBCONNECTOR_VGA = 1,
 DRM_MODE_SUBCONNECTOR_DVID = 3,
 DRM_MODE_SUBCONNECTOR_DVIA = 4,
 DRM_MODE_SUBCONNECTOR_Composite = 5,
 DRM_MODE_SUBCONNECTOR_SVIDEO = 6,
 DRM_MODE_SUBCONNECTOR_Component = 8,
 DRM_MODE_SUBCONNECTOR_SCART = 9,
 DRM_MODE_SUBCONNECTOR_DisplayPort = 10,
 DRM_MODE_SUBCONNECTOR_HDMIA = 11,
 DRM_MODE_SUBCONNECTOR_Native = 15,
 DRM_MODE_SUBCONNECTOR_Wireless = 18,
};
struct drm_mode_fb_cmd2 {

 __u32 fb_id;

 __u32 width;

 __u32 height;




 __u32 pixel_format;




 __u32 flags;





 __u32 handles[4];

 __u32 pitches[4];

 __u32 offsets[4];





 __u64 modifier[4];
};
struct hdr_metadata_infoframe {




 __u8 eotf;



 __u8 metadata_type;
 struct {
  __u16 x, y;
 } display_primaries[3];
 struct {
  __u16 x, y;
 } white_point;





 __u16 max_display_mastering_luminance;






 __u16 min_display_mastering_luminance;





 __u16 max_cll;





 __u16 max_fall;
};
struct hdr_output_metadata {



 __u32 metadata_type;



 union {
  struct hdr_metadata_infoframe hdmi_metadata_type1;
 };
};
struct drm_amdgpu_userq_in {

 __u32 op;

 __u32 queue_id;

 __u32 ip_type;




 __u32 doorbell_handle;





 __u32 doorbell_offset;



 __u32 flags;




 __u64 queue_va;




 __u64 queue_size;




 __u64 rptr_va;







 __u64 wptr_va;
 __u64 mqd;





 __u64 mqd_size;
};
struct spsc_node {


 struct spsc_node *next;
};
struct spsc_queue {

  struct spsc_node *head;


 atomic_long_t tail;

 atomic_t job_count;
};
struct dma_fence;
struct dma_fence_ops;
struct dma_fence_cb;
struct seq_file;
struct dma_fence {
 spinlock_t *lock;
 const struct dma_fence_ops *ops;
 union {
  struct list_head cb_list;

  ktime_t timestamp;

  struct callback_head rcu;
 };
 u64 context;
 u64 seqno;
 unsigned long flags;
 struct kref refcount;
 int error;
};
typedef void (*dma_fence_func_t)(struct dma_fence *fence,
     struct dma_fence_cb *cb);
struct dma_fence_cb {
 struct list_head node;
 dma_fence_func_t func;
};
struct dma_fence_ops {
 const char * (*get_driver_name)(struct dma_fence *fence);
 const char * (*get_timeline_name)(struct dma_fence *fence);
 bool (*enable_signaling)(struct dma_fence *fence);
 bool (*signaled)(struct dma_fence *fence);
 signed long (*wait)(struct dma_fence *fence,
       bool intr, signed long timeout);
 void (*release)(struct dma_fence *fence);
 void (*set_deadline)(struct dma_fence *fence, ktime_t deadline);
};
struct dma_resv;
struct drm_gem_object;
struct drm_gpu_scheduler;
struct drm_sched_rq;
struct drm_file;
enum drm_sched_priority {
 DRM_SCHED_PRIORITY_KERNEL,
 DRM_SCHED_PRIORITY_HIGH,
 DRM_SCHED_PRIORITY_NORMAL,
 DRM_SCHED_PRIORITY_LOW,

 DRM_SCHED_PRIORITY_COUNT
};
struct drm_sched_entity {
 struct list_head list;







 spinlock_t lock;
 struct drm_sched_rq *rq;
 struct drm_gpu_scheduler **sched_list;






 unsigned int num_sched_list;







 enum drm_sched_priority priority;




 struct spsc_queue job_queue;
 atomic_t fence_seq;
 uint64_t fence_context;






 struct dma_fence *dependency;






 struct dma_fence_cb cb;






 atomic_t *guilty;
 struct dma_fence *last_scheduled;




 struct task_struct *last_user;
 bool stopped;







 struct completion entity_idle;






 ktime_t oldest_job_waiting;






 struct rb_node rb_tree_node;

};
struct drm_sched_rq {
 struct drm_gpu_scheduler *sched;

 spinlock_t lock;

 struct drm_sched_entity *current_entity;
 struct list_head entities;
 struct rb_root_cached rb_tree_root;
};
struct drm_sched_fence {




 struct dma_fence scheduled;
 struct dma_fence finished;





 ktime_t deadline;






 struct dma_fence *parent;




 struct drm_gpu_scheduler *sched;



 spinlock_t lock;



 void *owner;






 uint64_t drm_client_id;
};
struct drm_sched_job {





 ktime_t submit_ts;
 struct drm_gpu_scheduler *sched;

 struct drm_sched_fence *s_fence;
 struct drm_sched_entity *entity;

 enum drm_sched_priority s_priority;
 u32 credits;

 unsigned int last_dependency;
 atomic_t karma;

 struct spsc_node queue_node;
 struct list_head list;





 union {
  struct dma_fence_cb finish_cb;
  struct work_struct work;
 };

 struct dma_fence_cb cb;
 struct xarray dependencies;
};
enum drm_gpu_sched_stat {
 DRM_GPU_SCHED_STAT_NONE,
 DRM_GPU_SCHED_STAT_RESET,
 DRM_GPU_SCHED_STAT_ENODEV,
 DRM_GPU_SCHED_STAT_NO_HANG,
};
struct drm_sched_backend_ops {
 struct dma_fence *(*prepare_job)(struct drm_sched_job *sched_job,
      struct drm_sched_entity *s_entity);
 struct dma_fence *(*run_job)(struct drm_sched_job *sched_job);
 enum drm_gpu_sched_stat (*timedout_job)(struct drm_sched_job *sched_job);





 void (*free_job)(struct drm_sched_job *sched_job);
 void (*cancel_job)(struct drm_sched_job *sched_job);
};
struct drm_gpu_scheduler {
 const struct drm_sched_backend_ops *ops;
 u32 credit_limit;
 atomic_t credit_count;
 long timeout;
 const char *name;
 u32 num_rqs;
 struct drm_sched_rq **sched_rq;
 wait_queue_head_t job_scheduled;
 atomic64_t job_id_count;
 struct workqueue_struct *submit_wq;
 struct workqueue_struct *timeout_wq;
 struct work_struct work_run_job;
 struct work_struct work_free_job;
 struct delayed_work work_tdr;
 struct list_head pending_list;
 spinlock_t job_list_lock;
 int hang_limit;
 atomic_t *score;
 atomic_t _score;
 bool ready;
 bool free_guilty;
 bool pause_submit;
 bool own_submit_wq;
 struct device *dev;
};
typedef u32 depot_stack_handle_t;
struct rt_mutex_base {
 raw_spinlock_t wait_lock;
 struct rb_root_cached waiters;
 struct task_struct *owner;
};
struct rt_mutex {
 struct rt_mutex_base rtmutex;

 struct lockdep_map dep_map;

};
struct rt_mutex_waiter;
struct ww_class {
 atomic_long_t stamp;
 struct lock_class_key acquire_key;
 struct lock_class_key mutex_key;
 const char *acquire_name;
 const char *mutex_name;
 unsigned int is_wait_die;
};
struct ww_mutex {
 struct mutex base;
 struct ww_acquire_ctx *ctx;

 struct ww_class *ww_class;

};
struct ww_acquire_ctx {
 struct task_struct *task;
 unsigned long stamp;
 unsigned int acquired;
 unsigned short wounded;
 unsigned short is_wait_die;

 unsigned int done_acquire;
 struct ww_class *ww_class;
 void *contending_lock;


 struct lockdep_map dep_map;
 struct lockdep_map first_lock_dep_map;


 unsigned int deadlock_inject_interval;
 unsigned int deadlock_inject_countdown;

};
struct drm_modeset_lock;
struct drm_modeset_acquire_ctx {

 struct ww_acquire_ctx ww_ctx;






 struct drm_modeset_lock *contended;





 depot_stack_handle_t stack_depot;




 struct list_head locked;




 bool trylock_only;


 bool interruptible;
};
struct drm_modeset_lock {



 struct ww_mutex mutex;





 struct list_head head;
};
int drm_modeset_lock(struct drm_modeset_lock *lock,
  struct drm_modeset_acquire_ctx *ctx);
struct drm_device;
struct drm_crtc;
struct drm_plane;
struct drm_file;
struct drm_device;
struct drm_atomic_state;
struct drm_mode_fb_cmd2;
struct drm_format_info;
struct drm_display_mode;
struct drm_mode_config_funcs {
 struct drm_framebuffer *(*fb_create)(struct drm_device *dev,
          struct drm_file *file_priv,
          const struct drm_format_info *info,
          const struct drm_mode_fb_cmd2 *mode_cmd);
 const struct drm_format_info *(*get_format_info)(u32 pixel_format, u64 modifier);
 enum drm_mode_status (*mode_valid)(struct drm_device *dev,
        const struct drm_display_mode *mode);
 int (*atomic_check)(struct drm_device *dev,
       struct drm_atomic_state *state);
 int (*atomic_commit)(struct drm_device *dev,
        struct drm_atomic_state *state,
        bool nonblock);
 struct drm_atomic_state *(*atomic_state_alloc)(struct drm_device *dev);
 void (*atomic_state_clear)(struct drm_atomic_state *state);
 void (*atomic_state_free)(struct drm_atomic_state *state);
};
struct drm_mode_config {
 struct mutex mutex;
 struct drm_modeset_lock connection_mutex;
 struct drm_modeset_acquire_ctx *acquire_ctx;







 struct mutex idr_mutex;







 struct idr object_idr;







 struct idr tile_idr;


 struct mutex fb_lock;

 int num_fb;

 struct list_head fb_list;





 spinlock_t connector_list_lock;




 int num_connector;



 struct ida connector_ida;







 struct list_head connector_list;
 struct llist_head connector_free_list;



 struct work_struct connector_free_work;







 int num_encoder;







 struct list_head encoder_list;
 int num_total_plane;






 struct list_head plane_list;
 struct raw_spinlock panic_lock;







 int num_crtc;






 struct list_head crtc_list;
 struct list_head property_list;
 struct list_head privobj_list;

 unsigned int min_width, min_height;
 unsigned int max_width, max_height;
 const struct drm_mode_config_funcs *funcs;


 bool poll_enabled;
 bool poll_running;
 bool delayed_event;
 struct delayed_work output_poll_work;







 struct mutex blob_lock;







 struct list_head property_blob_list;







 struct drm_property *edid_property;




 struct drm_property *dpms_property;




 struct drm_property *path_property;





 struct drm_property *tile_property;




 struct drm_property *link_status_property;




 struct drm_property *plane_type_property;




 struct drm_property *prop_src_x;




 struct drm_property *prop_src_y;




 struct drm_property *prop_src_w;




 struct drm_property *prop_src_h;




 struct drm_property *prop_crtc_x;




 struct drm_property *prop_crtc_y;




 struct drm_property *prop_crtc_w;




 struct drm_property *prop_crtc_h;




 struct drm_property *prop_fb_id;




 struct drm_property *prop_in_fence_fd;





 struct drm_property *prop_out_fence_ptr;




 struct drm_property *prop_crtc_id;
 struct drm_property *prop_fb_damage_clips;





 struct drm_property *prop_active;





 struct drm_property *prop_mode_id;




 struct drm_property *prop_vrr_enabled;





 struct drm_property *dvi_i_subconnector_property;




 struct drm_property *dvi_i_select_subconnector_property;





 struct drm_property *dp_subconnector_property;





 struct drm_property *tv_subconnector_property;




 struct drm_property *tv_select_subconnector_property;







 struct drm_property *legacy_tv_mode_property;





 struct drm_property *tv_mode_property;





 struct drm_property *tv_left_margin_property;




 struct drm_property *tv_right_margin_property;




 struct drm_property *tv_top_margin_property;




 struct drm_property *tv_bottom_margin_property;




 struct drm_property *tv_brightness_property;




 struct drm_property *tv_contrast_property;




 struct drm_property *tv_flicker_reduction_property;




 struct drm_property *tv_overscan_property;




 struct drm_property *tv_saturation_property;



 struct drm_property *tv_hue_property;





 struct drm_property *scaling_mode_property;




 struct drm_property *aspect_ratio_property;




 struct drm_property *content_type_property;




 struct drm_property *degamma_lut_property;




 struct drm_property *degamma_lut_size_property;





 struct drm_property *ctm_property;





 struct drm_property *gamma_lut_property;




 struct drm_property *gamma_lut_size_property;





 struct drm_property *suggested_x_property;




 struct drm_property *suggested_y_property;






 struct drm_property *non_desktop_property;






 struct drm_property *panel_orientation_property;






 struct drm_property *writeback_fb_id_property;







 struct drm_property *writeback_pixel_formats_property;







 struct drm_property *writeback_out_fence_ptr_property;






 struct drm_property *hdr_output_metadata_property;





 struct drm_property *content_protection_property;





 struct drm_property *hdcp_content_type_property;


 uint32_t preferred_depth, prefer_shadow;







 bool quirk_addfb_prefer_xbgr_30bpp;
 bool quirk_addfb_prefer_host_byte_order;





 bool async_page_flip;
 bool fb_modifiers_not_supported;







 bool normalize_zpos;





 struct drm_property *modifiers_property;





 struct drm_property *async_modifiers_property;




 struct drm_property *size_hints_property;


 uint32_t cursor_width, cursor_height;
 struct drm_atomic_state *suspend_state;

 const struct drm_mode_config_helper_funcs *helper_private;
};
struct drm_driver;
struct drm_minor;
struct drm_master;
struct drm_vblank_crtc;
struct drm_vma_offset_manager;
struct drm_vram_mm;
struct drm_fb_helper;
struct inode;
struct pci_dev;
struct drm_wedge_task_info {

 pid_t pid;

 char comm[TASK_COMM_LEN];
};
enum switch_power_state {

 DRM_SWITCH_POWER_ON = 0,


 DRM_SWITCH_POWER_OFF = 1,


 DRM_SWITCH_POWER_CHANGING = 2,


 DRM_SWITCH_POWER_DYNAMIC_OFF = 3,
};
struct drm_device {

 int if_version;


 struct kref ref;


 struct device *dev;
 struct device *dma_dev;







 struct {

  struct list_head resources;

  void *final_kfree;

  spinlock_t lock;
 } managed;


 const struct drm_driver *driver;
 void *dev_private;
 struct drm_minor *primary;
 struct drm_minor *render;


 struct drm_minor *accel;






 bool registered;







 struct drm_master *master;
 u32 driver_features;







 bool unplugged;


 struct inode *anon_inode;


 char *unique;






 struct mutex master_mutex;







 atomic_t open_count;


 struct mutex filelist_mutex;





 struct list_head filelist;







 struct list_head filelist_internal;






 struct mutex clientlist_mutex;






 struct list_head clientlist;
 bool vblank_disable_immediate;
 struct drm_vblank_crtc *vblank;






 spinlock_t vblank_time_lock;




 spinlock_t vbl_lock;
 u32 max_vblank_count;


 struct list_head vblank_event_list;







 spinlock_t event_lock;


 unsigned int num_crtcs;


 struct drm_mode_config mode_config;


 struct mutex object_name_lock;


 struct idr object_name_idr;


 struct drm_vma_offset_manager *vma_offset_manager;


 struct drm_vram_mm *vram_mm;
 enum switch_power_state switch_power_state;







 struct drm_fb_helper *fb_helper;






 struct dentry *debugfs_root;
};
struct drm_device;
struct seq_file;
enum drm_debug_category {





 DRM_UT_CORE,




 DRM_UT_DRIVER,



 DRM_UT_KMS,



 DRM_UT_PRIME,



 DRM_UT_ATOMIC,



 DRM_UT_VBL,



 DRM_UT_STATE,



 DRM_UT_LEASE,



 DRM_UT_DP,



 DRM_UT_DRMRES
};
struct drm_printer {

 void (*printfn)(struct drm_printer *p, struct va_format *vaf);
 void (*puts)(struct drm_printer *p, const char *str);
 void *arg;
 const void *origin;
 const char *prefix;
 struct {
  unsigned int series;
  unsigned int counter;
 } line;
 enum drm_debug_category category;
};
struct _ddebug;
struct drm_mm_node {

 unsigned long color;

 u64 start;

 u64 size;

 struct drm_mm *mm;
 struct list_head node_list;
 struct list_head hole_stack;
 struct rb_node rb;
 struct rb_node rb_hole_size;
 struct rb_node rb_hole_addr;
 u64 __subtree_last;
 u64 hole_size;
 u64 subtree_max_hole;
 unsigned long flags;

 depot_stack_handle_t stack;

};
struct drm_mm {
 void (*color_adjust)(const struct drm_mm_node *node,
        unsigned long color,
        u64 *start, u64 *end);



 struct list_head hole_stack;


 struct drm_mm_node head_node;

 struct rb_root_cached interval_tree;
 struct rb_root_cached holes_size;
 struct rb_root holes_addr;

 unsigned long scan_active;
};
struct drm_suballoc_manager {
 wait_queue_head_t wq;
 struct list_head *hole;
 struct list_head olist;
 struct list_head flist[32];
 size_t size;
 size_t align;
};
struct drm_suballoc {
 struct list_head olist;
 struct list_head flist;
 struct drm_suballoc_manager *manager;
 size_t soffset;
 size_t eoffset;
 struct dma_fence *fence;
};
struct amdgpu_device;
struct amdgpu_ring;
struct amdgpu_ib;
struct amdgpu_cs_parser;
struct amdgpu_job;
struct amdgpu_vm;
enum amdgpu_ring_priority_level {
 AMDGPU_RING_PRIO_0,
 AMDGPU_RING_PRIO_1,
 AMDGPU_RING_PRIO_DEFAULT = 1,
 AMDGPU_RING_PRIO_2,
 AMDGPU_RING_PRIO_MAX
};
enum amdgpu_ring_type {
 AMDGPU_RING_TYPE_GFX = 0,
 AMDGPU_RING_TYPE_COMPUTE = 1,
 AMDGPU_RING_TYPE_SDMA = 2,
 AMDGPU_RING_TYPE_UVD = 3,
 AMDGPU_RING_TYPE_VCE = 4,
 AMDGPU_RING_TYPE_UVD_ENC = 5,
 AMDGPU_RING_TYPE_VCN_DEC = 6,
 AMDGPU_RING_TYPE_VCN_ENC = 7,
 AMDGPU_RING_TYPE_VCN_JPEG = 8,
 AMDGPU_RING_TYPE_VPE = 9,
 AMDGPU_RING_TYPE_KIQ,
 AMDGPU_RING_TYPE_MES,
 AMDGPU_RING_TYPE_UMSCH_MM,
 AMDGPU_RING_TYPE_CPER,
};
enum amdgpu_ib_pool_type {

 AMDGPU_IB_POOL_DELAYED,

 AMDGPU_IB_POOL_IMMEDIATE,

 AMDGPU_IB_POOL_DIRECT,

 AMDGPU_IB_POOL_MAX
};
struct amdgpu_ib {
 struct drm_suballoc *sa_bo;
 uint32_t length_dw;
 uint64_t gpu_addr;
 uint32_t *ptr;
 uint32_t flags;
};
struct amdgpu_sched {
 u32 num_scheds;
 struct drm_gpu_scheduler *sched[64];
};
struct amdgpu_fence_driver {
 uint64_t gpu_addr;
 uint32_t *cpu_addr;

 uint32_t sync_seq;
 atomic_t last_seq;
 u64 signalled_wptr;
 bool initialized;
 struct amdgpu_irq_src *irq_src;
 unsigned irq_type;
 struct timer_list fallback_timer;
 unsigned num_fences_mask;
 spinlock_t lock;
 struct dma_fence **fences;
};
struct amdgpu_fence {
 struct dma_fence base;


 struct amdgpu_ring *ring;
 ktime_t start_timestamp;


 u64 wptr;

 u64 context;
 uint32_t seq;
};
struct amdgpu_ring_funcs {







 enum amdgpu_ring_type type;
 uint32_t align_mask;
 u32 nop;
 bool support_64bit_ptrs;
 bool no_user_fence;
 bool secure_submission_supported;
 unsigned extra_bytes;


 u64 (*get_rptr)(struct amdgpu_ring *ring);
 u64 (*get_wptr)(struct amdgpu_ring *ring);
 void (*set_wptr)(struct amdgpu_ring *ring);

 int (*parse_cs)(struct amdgpu_cs_parser *p,
   struct amdgpu_job *job,
   struct amdgpu_ib *ib);
 int (*patch_cs_in_place)(struct amdgpu_cs_parser *p,
     struct amdgpu_job *job,
     struct amdgpu_ib *ib);

 unsigned emit_frame_size;
 unsigned emit_ib_size;

 void (*emit_ib)(struct amdgpu_ring *ring,
   struct amdgpu_job *job,
   struct amdgpu_ib *ib,
   uint32_t flags);
 void (*emit_fence)(struct amdgpu_ring *ring, uint64_t addr,
      uint64_t seq, unsigned flags);
 void (*emit_pipeline_sync)(struct amdgpu_ring *ring);
 void (*emit_vm_flush)(struct amdgpu_ring *ring, unsigned vmid,
         uint64_t pd_addr);
 void (*emit_hdp_flush)(struct amdgpu_ring *ring);
 void (*emit_gds_switch)(struct amdgpu_ring *ring, uint32_t vmid,
    uint32_t gds_base, uint32_t gds_size,
    uint32_t gws_base, uint32_t gws_size,
    uint32_t oa_base, uint32_t oa_size);

 int (*test_ring)(struct amdgpu_ring *ring);
 int (*test_ib)(struct amdgpu_ring *ring, long timeout);

 void (*insert_nop)(struct amdgpu_ring *ring, uint32_t count);
 void (*insert_start)(struct amdgpu_ring *ring);
 void (*insert_end)(struct amdgpu_ring *ring);

 void (*pad_ib)(struct amdgpu_ring *ring, struct amdgpu_ib *ib);
 unsigned (*init_cond_exec)(struct amdgpu_ring *ring, uint64_t addr);

 void (*begin_use)(struct amdgpu_ring *ring);
 void (*end_use)(struct amdgpu_ring *ring);
 void (*emit_switch_buffer) (struct amdgpu_ring *ring);
 void (*emit_cntxcntl) (struct amdgpu_ring *ring, uint32_t flags);
 void (*emit_gfx_shadow)(struct amdgpu_ring *ring, u64 shadow_va, u64 csa_va,
    u64 gds_va, bool init_shadow, int vmid);
 void (*emit_rreg)(struct amdgpu_ring *ring, uint32_t reg,
     uint32_t reg_val_offs);
 void (*emit_wreg)(struct amdgpu_ring *ring, uint32_t reg, uint32_t val);
 void (*emit_reg_wait)(struct amdgpu_ring *ring, uint32_t reg,
         uint32_t val, uint32_t mask);
 void (*emit_reg_write_reg_wait)(struct amdgpu_ring *ring,
     uint32_t reg0, uint32_t reg1,
     uint32_t ref, uint32_t mask);
 void (*emit_frame_cntl)(struct amdgpu_ring *ring, bool start,
    bool secure);

 void (*soft_recovery)(struct amdgpu_ring *ring, unsigned vmid);
 int (*preempt_ib)(struct amdgpu_ring *ring);
 void (*emit_mem_sync)(struct amdgpu_ring *ring);
 void (*emit_wave_limit)(struct amdgpu_ring *ring, bool enable);
 void (*patch_cntl)(struct amdgpu_ring *ring, unsigned offset);
 void (*patch_ce)(struct amdgpu_ring *ring, unsigned offset);
 void (*patch_de)(struct amdgpu_ring *ring, unsigned offset);
 int (*reset)(struct amdgpu_ring *ring, unsigned int vmid,
       struct amdgpu_fence *timedout_fence);
 void (*emit_cleaner_shader)(struct amdgpu_ring *ring);
};
struct amdgpu_ring {
 struct amdgpu_device *adev;
 const struct amdgpu_ring_funcs *funcs;
 struct amdgpu_fence_driver fence_drv;
 struct drm_gpu_scheduler sched;

 struct amdgpu_bo *ring_obj;
 uint32_t *ring;

 uint32_t *ring_backup;
 unsigned int ring_backup_entries_to_copy;
 unsigned rptr_offs;
 u64 rptr_gpu_addr;
 u32 *rptr_cpu_addr;







 u64 wptr;







 u64 wptr_old;
 unsigned ring_size;
 unsigned max_dw;







 int count_dw;
 uint64_t gpu_addr;
 uint64_t ptr_mask;
 uint32_t buf_mask;
 u32 idx;
 u32 xcc_id;
 u32 xcp_id;
 u32 me;
 u32 pipe;
 u32 queue;
 struct amdgpu_bo *mqd_obj;
 uint64_t mqd_gpu_addr;
 void *mqd_ptr;
 unsigned mqd_size;
 uint64_t eop_gpu_addr;
 u32 doorbell_index;
 bool use_doorbell;
 bool use_pollmem;
 unsigned wptr_offs;
 u64 wptr_gpu_addr;







 u32 *wptr_cpu_addr;
 unsigned fence_offs;
 u64 fence_gpu_addr;
 u32 *fence_cpu_addr;
 uint64_t current_ctx;
 char name[16];
 u32 trail_seq;
 unsigned trail_fence_offs;
 u64 trail_fence_gpu_addr;
 u32 *trail_fence_cpu_addr;
 unsigned cond_exe_offs;
 u64 cond_exe_gpu_addr;
 u32 *cond_exe_cpu_addr;
 unsigned int set_q_mode_offs;
 u32 *set_q_mode_ptr;
 u64 set_q_mode_token;
 unsigned vm_hub;
 unsigned vm_inv_eng;
 struct dma_fence *vmid_wait;
 bool has_compute_vm_bug;
 bool no_scheduler;
 bool no_user_submission;
 int hw_prio;
 unsigned num_hw_submission;
 atomic_t *sched_score;

 bool is_sw_ring;
 unsigned int entry_index;

 uint64_t cached_rptr;
};
struct drm_device;
struct drm_file;
struct amdgpu_ctx_mgr;
struct amdgpu_ctx_entity {
 uint32_t hw_ip;
 uint64_t sequence;
 struct drm_sched_entity entity;
 struct dma_fence *fences[1];
};
struct amdgpu_ctx {
 struct kref refcount;
 struct amdgpu_ctx_mgr *mgr;
 unsigned reset_counter;
 unsigned reset_counter_query;
 uint64_t generation;
 spinlock_t ring_lock;
 struct amdgpu_ctx_entity *entities[10][4];
 bool preamble_presented;
 int32_t init_priority;
 int32_t override_priority;
 atomic_t guilty;
 unsigned long ras_counter_ce;
 unsigned long ras_counter_ue;
 uint32_t stable_pstate;
 struct amdgpu_ctx_mgr *ctx_mgr;
};
struct amdgpu_ctx_mgr {
 struct amdgpu_device *adev;
 struct mutex lock;

 struct idr ctx_handles;
 atomic64_t time_spend[10];
};
struct iosys_map {
 union {
  void *vaddr_iomem;
  void *vaddr;
 };
 bool is_iomem;
};
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct device;
struct dma_buf;
struct dma_buf_attachment;
struct dma_buf_ops {
 int (*attach)(struct dma_buf *, struct dma_buf_attachment *);
 void (*detach)(struct dma_buf *, struct dma_buf_attachment *);
 int (*pin)(struct dma_buf_attachment *attach);
 void (*unpin)(struct dma_buf_attachment *attach);
 struct sg_table * (*map_dma_buf)(struct dma_buf_attachment *,
      enum dma_data_direction);
 void (*unmap_dma_buf)(struct dma_buf_attachment *,
         struct sg_table *,
         enum dma_data_direction);
 void (*release)(struct dma_buf *);
 int (*begin_cpu_access)(struct dma_buf *, enum dma_data_direction);
 int (*end_cpu_access)(struct dma_buf *, enum dma_data_direction);
 int (*mmap)(struct dma_buf *, struct vm_area_struct *vma);

 int (*vmap)(struct dma_buf *dmabuf, struct iosys_map *map);
 void (*vunmap)(struct dma_buf *dmabuf, struct iosys_map *map);
};
struct dma_buf {





 size_t size;







 struct file *file;







 struct list_head attachments;


 const struct dma_buf_ops *ops;







 unsigned vmapping_counter;





 struct iosys_map vmap_ptr;






 const char *exp_name;
 const char *name;


 spinlock_t name_lock;







 struct module *owner;


 struct list_head list_node;


 void *priv;
 struct dma_resv *resv;


 wait_queue_head_t poll;



 struct dma_buf_poll_cb_t {
  struct dma_fence_cb cb;
  wait_queue_head_t *poll;

  __poll_t active;
 } cb_in, cb_out;







 struct dma_buf_sysfs_entry {
  struct kobject kobj;
  struct dma_buf *dmabuf;
 } *sysfs_entry;

};
struct dma_buf_attach_ops {






 bool allow_peer2peer;
 void (*move_notify)(struct dma_buf_attachment *attach);
};
struct dma_buf_attachment {
 struct dma_buf *dmabuf;
 struct device *dev;
 struct list_head node;
 bool peer2peer;
 const struct dma_buf_attach_ops *importer_ops;
 void *importer_priv;
 void *priv;
};
struct dma_resv_list;
struct dma_resv {
 struct ww_mutex lock;
 struct dma_resv_list *fences;
};
struct drm_file;
struct drm_vma_offset_node {
 rwlock_t vm_lock;
 struct drm_mm_node vm_node;
 struct rb_root vm_files;
 void *driver_private;
};
struct drm_vma_offset_manager {
 rwlock_t vm_lock;
 struct drm_mm vm_addr_space_mm;
};
struct iosys_map;
struct drm_gem_object;
enum drm_gem_object_status {
 DRM_GEM_OBJECT_RESIDENT = ((((1UL))) << (0)),
 DRM_GEM_OBJECT_PURGEABLE = ((((1UL))) << (1)),
 DRM_GEM_OBJECT_ACTIVE = ((((1UL))) << (2)),
};
struct drm_gem_object_funcs {







 void (*free)(struct drm_gem_object *obj);
 int (*open)(struct drm_gem_object *obj, struct drm_file *file);
 void (*close)(struct drm_gem_object *obj, struct drm_file *file);
 void (*print_info)(struct drm_printer *p, unsigned int indent,
      const struct drm_gem_object *obj);
 struct dma_buf *(*export)(struct drm_gem_object *obj, int flags);
 int (*pin)(struct drm_gem_object *obj);
 void (*unpin)(struct drm_gem_object *obj);
 struct sg_table *(*get_sg_table)(struct drm_gem_object *obj);
 int (*vmap)(struct drm_gem_object *obj, struct iosys_map *map);
 void (*vunmap)(struct drm_gem_object *obj, struct iosys_map *map);
 int (*mmap)(struct drm_gem_object *obj, struct vm_area_struct *vma);
 int (*evict)(struct drm_gem_object *obj);
 enum drm_gem_object_status (*status)(struct drm_gem_object *obj);
 size_t (*rss)(struct drm_gem_object *obj);
 const struct vm_operations_struct *vm_ops;
};
struct drm_gem_lru {







 struct mutex *lock;







 long count;






 struct list_head list;
};
struct drm_gem_object {
 struct kref refcount;
 unsigned handle_count;




 struct drm_device *dev;
 struct file *filp;
 struct drm_vma_offset_node vma_node;







 size_t size;
 int name;
 struct dma_buf *dma_buf;
 struct dma_buf_attachment *import_attach;
 struct dma_resv *resv;
 struct dma_resv _resv;
 struct {







  struct list_head list;
  struct mutex lock;
 } gpuva;
 const struct drm_gem_object_funcs *funcs;






 struct list_head lru_node;






 struct drm_gem_lru *lru;
};
enum ttm_caching {




 ttm_uncached,





 ttm_write_combined,





 ttm_cached
};
struct iosys_map;
struct ttm_device;
struct ttm_resource_manager;
struct ttm_resource;
struct ttm_place;
struct ttm_buffer_object;
struct ttm_placement;
struct iosys_map;
struct sg_table;
struct scatterlist;
enum ttm_lru_item_type {

 TTM_LRU_RESOURCE,

 TTM_LRU_HITCH
};
struct ttm_lru_item {
 struct list_head link;
 enum ttm_lru_item_type type;
};
struct ttm_resource_manager_func {
 int (*alloc)(struct ttm_resource_manager *man,
        struct ttm_buffer_object *bo,
        const struct ttm_place *place,
        struct ttm_resource **res);
 void (*free)(struct ttm_resource_manager *man,
       struct ttm_resource *res);
 bool (*intersects)(struct ttm_resource_manager *man,
      struct ttm_resource *res,
      const struct ttm_place *place,
      size_t size);
 bool (*compatible)(struct ttm_resource_manager *man,
      struct ttm_resource *res,
      const struct ttm_place *place,
      size_t size);
 void (*debug)(struct ttm_resource_manager *man,
        struct drm_printer *printer);
};
struct ttm_resource_manager {



 bool use_type;
 bool use_tt;
 struct ttm_device *bdev;
 uint64_t size;
 const struct ttm_resource_manager_func *func;
 spinlock_t move_lock;




 struct dma_fence *move;




 struct list_head lru[4U];





 uint64_t usage;




 struct dmem_cgroup_region *cg;
};
struct ttm_bus_placement {
 void *addr;
 phys_addr_t offset;
 bool is_iomem;
 enum ttm_caching caching;
};
struct ttm_resource {
 unsigned long start;
 size_t size;
 uint32_t mem_type;
 uint32_t placement;
 struct ttm_bus_placement bus;
 struct ttm_buffer_object *bo;

 struct dmem_cgroup_pool_state *css;




 struct ttm_lru_item lru;
};
struct ttm_lru_bulk_move_pos {
 struct ttm_resource *first;
 struct ttm_resource *last;
};
struct ttm_lru_bulk_move {
 struct ttm_lru_bulk_move_pos pos[9][4U];
 struct list_head cursor_list;
};
struct device;
struct seq_file;
struct ttm_operation_ctx;
struct ttm_pool;
struct ttm_tt;
struct ttm_pool_type {
 struct ttm_pool *pool;
 unsigned int order;
 enum ttm_caching caching;

 struct list_head shrinker_list;

 spinlock_t lock;
 struct list_head pages;
};
struct ttm_pool {
 struct device *dev;
 int nid;

 bool use_dma_alloc;
 bool use_dma32;

 struct {
  struct ttm_pool_type orders[(10 + 1)];
 } caching[3];
};
struct ttm_device;
struct ttm_placement;
struct ttm_buffer_object;
struct ttm_operation_ctx;
struct ttm_device_funcs {
 struct ttm_tt *(*ttm_tt_create)(struct ttm_buffer_object *bo,
     uint32_t page_flags);
 int (*ttm_tt_populate)(struct ttm_device *bdev,
          struct ttm_tt *ttm,
          struct ttm_operation_ctx *ctx);
 void (*ttm_tt_unpopulate)(struct ttm_device *bdev,
      struct ttm_tt *ttm);
 void (*ttm_tt_destroy)(struct ttm_device *bdev, struct ttm_tt *ttm);
 bool (*eviction_valuable)(struct ttm_buffer_object *bo,
      const struct ttm_place *place);
 void (*evict_flags)(struct ttm_buffer_object *bo,
       struct ttm_placement *placement);
 int (*move)(struct ttm_buffer_object *bo, bool evict,
      struct ttm_operation_ctx *ctx,
      struct ttm_resource *new_mem,
      struct ttm_place *hop);




 void (*delete_mem_notify)(struct ttm_buffer_object *bo);




 void (*swap_notify)(struct ttm_buffer_object *bo);







 int (*io_mem_reserve)(struct ttm_device *bdev,
         struct ttm_resource *mem);
 void (*io_mem_free)(struct ttm_device *bdev,
       struct ttm_resource *mem);







 unsigned long (*io_mem_pfn)(struct ttm_buffer_object *bo,
        unsigned long page_offset);
 int (*access_memory)(struct ttm_buffer_object *bo, unsigned long offset,
        void *buf, int len, int write);
 void (*release_notify)(struct ttm_buffer_object *bo);
};
struct ttm_device {




 struct list_head device_list;





 const struct ttm_device_funcs *funcs;





 struct ttm_resource_manager sysman;




 struct ttm_resource_manager *man_drv[9];




 struct drm_vma_offset_manager *vma_manager;




 struct ttm_pool pool;




 spinlock_t lru_lock;





 struct list_head unevictable;





 struct address_space *dev_mapping;




 struct workqueue_struct *wq;
};
struct iosys_map;
struct ttm_device;
struct ttm_placement;
struct ttm_place;
struct ttm_resource;
struct ttm_resource_manager;
struct ttm_tt;
enum ttm_bo_type {
 ttm_bo_type_device,
 ttm_bo_type_kernel,
 ttm_bo_type_sg
};
struct ttm_buffer_object {
 struct drm_gem_object base;




 struct ttm_device *bdev;
 enum ttm_bo_type type;
 uint32_t page_alignment;
 void (*destroy) (struct ttm_buffer_object *);




 struct kref kref;




 struct ttm_resource *resource;
 struct ttm_tt *ttm;
 bool deleted;
 struct ttm_lru_bulk_move *bulk_move;
 unsigned priority;
 unsigned pin_count;





 struct work_struct delayed_delete;





 struct sg_table *sg;
};
struct ttm_bo_kmap_obj {
 void *virtual;
 struct page *page;
 enum {
  ttm_bo_map_iomap = 1 | 0x80,
  ttm_bo_map_vmap = 2,
  ttm_bo_map_kmap = 3,
  ttm_bo_map_premapped = 4 | 0x80,
 } bo_kmap_type;
 struct ttm_buffer_object *bo;
};
struct ttm_operation_ctx {
 bool interruptible;
 bool no_wait_gpu;
 bool gfp_retry_mayfail;
 bool allow_res_evict;
 struct dma_resv *resv;
 uint64_t bytes_moved;
};
struct ttm_place {
 unsigned fpfn;
 unsigned lpfn;
 uint32_t mem_type;
 uint32_t flags;
};
struct ttm_placement {
 unsigned num_placement;
 const struct ttm_place *placement;
};
struct drm_device;
struct drm_file;
struct file;
enum irq_domain_bus_token {
 DOMAIN_BUS_ANY = 0,
 DOMAIN_BUS_WIRED,
 DOMAIN_BUS_GENERIC_MSI,
 DOMAIN_BUS_PCI_MSI,
 DOMAIN_BUS_PLATFORM_MSI,
 DOMAIN_BUS_NEXUS,
 DOMAIN_BUS_IPI,
 DOMAIN_BUS_FSL_MC_MSI,
 DOMAIN_BUS_TI_SCI_INTA_MSI,
 DOMAIN_BUS_WAKEUP,
 DOMAIN_BUS_VMD_MSI,
 DOMAIN_BUS_PCI_DEVICE_MSI,
 DOMAIN_BUS_PCI_DEVICE_MSIX,
 DOMAIN_BUS_DMAR,
 DOMAIN_BUS_AMDVI,
 DOMAIN_BUS_DEVICE_MSI,
 DOMAIN_BUS_WIRED_TO_MSI,
};
struct device;
enum dev_prop_type {
 DEV_PROP_U8,
 DEV_PROP_U16,
 DEV_PROP_U32,
 DEV_PROP_U64,
 DEV_PROP_STRING,
 DEV_PROP_REF,
};
struct software_node;
struct property_entry {
 const char *name;
 size_t length;
 bool is_inline;
 enum dev_prop_type type;
 union {
  const void *pointer;
  union {
   u8 u8_data[sizeof(u64) / sizeof(u8)];
   u16 u16_data[sizeof(u64) / sizeof(u16)];
   u32 u32_data[sizeof(u64) / sizeof(u32)];
   u64 u64_data[sizeof(u64) / sizeof(u64)];
   const char *str[sizeof(u64) / sizeof(char *)];
  } value;
 };
};
bool device_dma_supported(const struct device *dev);
enum dev_dma_attr device_get_dma_attr(const struct device *dev);
const void *device_get_match_data(const struct device *dev);
struct software_node {
 const char *name;
 const struct software_node *parent;
 const struct property_entry *properties;
};
typedef u32 phandle;
struct property {
 char *name;
 int length;
 void *value;
 struct property *next;

 unsigned long _flags;





 struct bin_attribute attr;

};
struct device_node {
 const char *name;
 phandle phandle;
 const char *full_name;
 struct fwnode_handle fwnode;

 struct property *properties;
 struct property *deadprops;
 struct device_node *parent;
 struct device_node *child;
 struct device_node *sibling;

 struct kobject kobj;

 unsigned long _flags;
 void *data;




};
struct notifier_block;
struct device_node;
struct fwnode_handle;
struct irq_domain;
struct irq_data;
struct cpumask;
struct seq_file;
struct msi_parent_ops;
struct irq_fwspec {
 struct fwnode_handle *fwnode;
 int param_count;
 u32 param[16];
};
struct irq_domain_ops {
 int (*match)(struct irq_domain *d, struct device_node *node,
    enum irq_domain_bus_token bus_token);
 int (*select)(struct irq_domain *d, struct irq_fwspec *fwspec,
     enum irq_domain_bus_token bus_token);
 int (*map)(struct irq_domain *d, unsigned int virq, irq_hw_number_t hw);
 void (*unmap)(struct irq_domain *d, unsigned int virq);
 int (*xlate)(struct irq_domain *d, struct device_node *node,
    const u32 *intspec, unsigned int intsize,
    unsigned long *out_hwirq, unsigned int *out_type);


 int (*alloc)(struct irq_domain *d, unsigned int virq,
    unsigned int nr_irqs, void *arg);
 void (*free)(struct irq_domain *d, unsigned int virq,
   unsigned int nr_irqs);
 int (*activate)(struct irq_domain *d, struct irq_data *irqd, bool reserve);
 void (*deactivate)(struct irq_domain *d, struct irq_data *irq_data);
 int (*translate)(struct irq_domain *d, struct irq_fwspec *fwspec,
        unsigned long *out_hwirq, unsigned int *out_type);


 void (*debug_show)(struct seq_file *m, struct irq_domain *d,
         struct irq_data *irqd, int ind);

};
struct irq_domain_chip_generic;
struct irq_domain {
 struct list_head link;
 const char *name;
 const struct irq_domain_ops *ops;
 void *host_data;
 unsigned int flags;
 unsigned int mapcount;
 struct mutex mutex;
 struct irq_domain *root;


 struct fwnode_handle *fwnode;
 enum irq_domain_bus_token bus_token;
 struct irq_domain_chip_generic *gc;
 struct device *dev;
 struct device *pm_dev;

 struct irq_domain *parent;


 const struct msi_parent_ops *msi_parent_ops;

 void (*exit)(struct irq_domain *d);


 irq_hw_number_t hwirq_max;
 unsigned int revmap_size;
 struct xarray revmap_tree;
 struct irq_data *revmap[1] ;
};
enum soc15_ih_clientid {
 SOC15_IH_CLIENTID_IH = 0x00,
 SOC15_IH_CLIENTID_ACP = 0x01,
 SOC15_IH_CLIENTID_ATHUB = 0x02,
 SOC15_IH_CLIENTID_BIF = 0x03,
 SOC15_IH_CLIENTID_DCE = 0x04,
 SOC15_IH_CLIENTID_ISP = 0x05,
 SOC15_IH_CLIENTID_PCIE0 = 0x06,
 SOC15_IH_CLIENTID_RLC = 0x07,
 SOC15_IH_CLIENTID_SDMA0 = 0x08,
 SOC15_IH_CLIENTID_SDMA1 = 0x09,
 SOC15_IH_CLIENTID_SE0SH = 0x0a,
 SOC15_IH_CLIENTID_SE1SH = 0x0b,
 SOC15_IH_CLIENTID_SE2SH = 0x0c,
 SOC15_IH_CLIENTID_SE3SH = 0x0d,
 SOC15_IH_CLIENTID_UVD1 = 0x0e,
 SOC15_IH_CLIENTID_THM = 0x0f,
 SOC15_IH_CLIENTID_UVD = 0x10,
 SOC15_IH_CLIENTID_VCE0 = 0x11,
 SOC15_IH_CLIENTID_VMC = 0x12,
 SOC15_IH_CLIENTID_XDMA = 0x13,
 SOC15_IH_CLIENTID_GRBM_CP = 0x14,
 SOC15_IH_CLIENTID_ATS = 0x15,
 SOC15_IH_CLIENTID_ROM_SMUIO = 0x16,
 SOC15_IH_CLIENTID_DF = 0x17,
 SOC15_IH_CLIENTID_VCE1 = 0x18,
 SOC15_IH_CLIENTID_PWR = 0x19,
 SOC15_IH_CLIENTID_RESERVED = 0x1a,
 SOC15_IH_CLIENTID_UTCL2 = 0x1b,
 SOC15_IH_CLIENTID_EA = 0x1c,
 SOC15_IH_CLIENTID_UTCL2LOG = 0x1d,
 SOC15_IH_CLIENTID_MP0 = 0x1e,
 SOC15_IH_CLIENTID_MP1 = 0x1f,

 SOC15_IH_CLIENTID_MAX,

 SOC15_IH_CLIENTID_VCN = SOC15_IH_CLIENTID_UVD,
 SOC15_IH_CLIENTID_VCN1 = SOC15_IH_CLIENTID_UVD1,
 SOC15_IH_CLIENTID_SDMA2 = SOC15_IH_CLIENTID_ACP,
 SOC15_IH_CLIENTID_SDMA3 = SOC15_IH_CLIENTID_DCE,
 SOC15_IH_CLIENTID_SDMA3_Sienna_Cichlid = SOC15_IH_CLIENTID_ISP,
 SOC15_IH_CLIENTID_SDMA4 = SOC15_IH_CLIENTID_ISP,
 SOC15_IH_CLIENTID_SDMA5 = SOC15_IH_CLIENTID_VCE0,
 SOC15_IH_CLIENTID_SDMA6 = SOC15_IH_CLIENTID_XDMA,
 SOC15_IH_CLIENTID_SDMA7 = SOC15_IH_CLIENTID_VCE1,
 SOC15_IH_CLIENTID_VMC1 = SOC15_IH_CLIENTID_PCIE0,
};
struct amdgpu_device;
struct amdgpu_iv_entry;
struct amdgpu_ih_regs {
 uint32_t ih_rb_base;
 uint32_t ih_rb_base_hi;
 uint32_t ih_rb_cntl;
 uint32_t ih_rb_wptr;
 uint32_t ih_rb_rptr;
 uint32_t ih_doorbell_rptr;
 uint32_t ih_rb_wptr_addr_lo;
 uint32_t ih_rb_wptr_addr_hi;
 uint32_t psp_reg_id;
};
struct amdgpu_ih_ring {
 unsigned ring_size;
 uint32_t ptr_mask;
 u32 doorbell_index;
 bool use_doorbell;
 bool use_bus_addr;

 struct amdgpu_bo *ring_obj;
 uint32_t *ring;
 uint64_t gpu_addr;

 uint64_t wptr_addr;
 uint32_t *wptr_cpu;

 uint64_t rptr_addr;
 uint32_t *rptr_cpu;

 bool enabled;
 unsigned rptr;
 struct amdgpu_ih_regs ih_regs;


 wait_queue_head_t wait_process;
 uint64_t processed_timestamp;
 bool overflow;
};
struct amdgpu_ih_funcs {

 u32 (*get_wptr)(struct amdgpu_device *adev, struct amdgpu_ih_ring *ih);
 void (*decode_iv)(struct amdgpu_device *adev, struct amdgpu_ih_ring *ih,
     struct amdgpu_iv_entry *entry);
 uint64_t (*decode_iv_ts)(struct amdgpu_ih_ring *ih, u32 rptr,
     signed int offset);
 void (*set_rptr)(struct amdgpu_device *adev, struct amdgpu_ih_ring *ih);
};
struct amdgpu_device;
enum amdgpu_interrupt_state {
 AMDGPU_IRQ_STATE_DISABLE,
 AMDGPU_IRQ_STATE_ENABLE,
};
struct amdgpu_iv_entry {
 struct amdgpu_ih_ring *ih;
 unsigned client_id;
 unsigned src_id;
 unsigned ring_id;
 unsigned vmid;
 unsigned vmid_src;
 uint64_t timestamp;
 unsigned timestamp_src;
 unsigned pasid;
 unsigned node_id;
 unsigned src_data[4];
 const uint32_t *iv_entry;
};
struct amdgpu_irq_src {
 unsigned num_types;
 atomic_t *enabled_types;
 const struct amdgpu_irq_src_funcs *funcs;
};
struct amdgpu_irq_client {
 struct amdgpu_irq_src **sources;
};
struct amdgpu_irq_src_funcs {
 int (*set)(struct amdgpu_device *adev, struct amdgpu_irq_src *source,
     unsigned type, enum amdgpu_interrupt_state state);

 int (*process)(struct amdgpu_device *adev,
         struct amdgpu_irq_src *source,
         struct amdgpu_iv_entry *entry);
};
struct amdgpu_irq {
 bool installed;
 unsigned int irq;
 spinlock_t lock;

 struct amdgpu_irq_client client[SOC15_IH_CLIENTID_MAX];


 bool msi_enabled;


 struct amdgpu_ih_ring ih, ih1, ih2, ih_soft;
 const struct amdgpu_ih_funcs *ih_funcs;
 struct work_struct ih1_work, ih2_work, ih_soft_work;
 struct amdgpu_irq_src self_irq;


 struct irq_domain *domain;
 unsigned virq[0x100];
 uint32_t srbm_soft_reset;
 u32 retry_cam_doorbell_index;
 bool retry_cam_enabled;
};
enum section_id {
    SECT_NONE,
    SECT_CONTEXT,
    SECT_CLEAR,
    SECT_CTRLCONST
};
struct cs_extent_def {
    const unsigned int *extent;
    const unsigned int reg_index;
    const unsigned int reg_count;
};
struct cs_section_def {
    const struct cs_extent_def *section;
    const enum section_id id;
};
struct amdgpu_rlc_funcs {
 bool (*is_rlc_enabled)(struct amdgpu_device *adev);
 void (*set_safe_mode)(struct amdgpu_device *adev, int xcc_id);
 void (*unset_safe_mode)(struct amdgpu_device *adev, int xcc_id);
 int (*init)(struct amdgpu_device *adev);
 u32 (*get_csb_size)(struct amdgpu_device *adev);
 void (*get_csb_buffer)(struct amdgpu_device *adev, u32 *buffer);
 int (*get_cp_table_num)(struct amdgpu_device *adev);
 int (*resume)(struct amdgpu_device *adev);
 void (*stop)(struct amdgpu_device *adev);
 void (*reset)(struct amdgpu_device *adev);
 void (*start)(struct amdgpu_device *adev);
 void (*update_spm_vmid)(struct amdgpu_device *adev, struct amdgpu_ring *ring, unsigned vmid);
 bool (*is_rlcg_access_range)(struct amdgpu_device *adev, uint32_t reg);
};
struct amdgpu_rlcg_reg_access_ctrl {
 uint32_t scratch_reg0;
 uint32_t scratch_reg1;
 uint32_t scratch_reg2;
 uint32_t scratch_reg3;
 uint32_t grbm_cntl;
 uint32_t grbm_idx;
 uint32_t spare_int;
};
struct amdgpu_rlc {

 struct amdgpu_bo *save_restore_obj;
 uint64_t save_restore_gpu_addr;
 uint32_t *sr_ptr;
 const u32 *reg_list;
 u32 reg_list_size;

 struct amdgpu_bo *clear_state_obj;
 uint64_t clear_state_gpu_addr;
 uint32_t *cs_ptr;
 const struct cs_section_def *cs_data;
 u32 clear_state_size;

 struct amdgpu_bo *cp_table_obj;
 uint64_t cp_table_gpu_addr;
 uint32_t *cp_table_ptr;
 u32 cp_table_size;


 bool in_safe_mode[8];
 const struct amdgpu_rlc_funcs *funcs;


 u32 save_and_restore_offset;
 u32 clear_state_descriptor_offset;
 u32 avail_scratch_ram_locations;
 u32 reg_restore_list_size;
 u32 reg_list_format_start;
 u32 reg_list_format_separate_start;
 u32 starting_offsets_start;
 u32 reg_list_format_size_bytes;
 u32 reg_list_size_bytes;
 u32 reg_list_format_direct_reg_list_length;
 u32 save_restore_list_cntl_size_bytes;
 u32 save_restore_list_gpm_size_bytes;
 u32 save_restore_list_srm_size_bytes;
 u32 rlc_iram_ucode_size_bytes;
 u32 rlc_dram_ucode_size_bytes;
 u32 rlcp_ucode_size_bytes;
 u32 rlcv_ucode_size_bytes;
 u32 global_tap_delays_ucode_size_bytes;
 u32 se0_tap_delays_ucode_size_bytes;
 u32 se1_tap_delays_ucode_size_bytes;
 u32 se2_tap_delays_ucode_size_bytes;
 u32 se3_tap_delays_ucode_size_bytes;

 u32 *register_list_format;
 u32 *register_restore;
 u8 *save_restore_list_cntl;
 u8 *save_restore_list_gpm;
 u8 *save_restore_list_srm;
 u8 *rlc_iram_ucode;
 u8 *rlc_dram_ucode;
 u8 *rlcp_ucode;
 u8 *rlcv_ucode;
 u8 *global_tap_delays_ucode;
 u8 *se0_tap_delays_ucode;
 u8 *se1_tap_delays_ucode;
 u8 *se2_tap_delays_ucode;
 u8 *se3_tap_delays_ucode;

 bool is_rlc_v2_1;


 struct amdgpu_bo *rlc_autoload_bo;
 u64 rlc_autoload_gpu_addr;
 void *rlc_autoload_ptr;


 struct amdgpu_bo *rlc_toc_bo;
 uint64_t rlc_toc_gpu_addr;
 void *rlc_toc_buf;

 bool rlcg_reg_access_supported;

 struct amdgpu_rlcg_reg_access_ctrl reg_access_ctrl[8];
};
enum imu_work_mode {
 DEBUG_MODE,
 MISSION_MODE
};
struct amdgpu_imu_funcs {
    int (*init_microcode)(struct amdgpu_device *adev);
    int (*load_microcode)(struct amdgpu_device *adev);
    void (*setup_imu)(struct amdgpu_device *adev);
    int (*start_imu)(struct amdgpu_device *adev);
    void (*program_rlc_ram)(struct amdgpu_device *adev);
    int (*wait_for_reset_status)(struct amdgpu_device *adev);
};
struct amdgpu_imu {
    const struct amdgpu_imu_funcs *funcs;
    enum imu_work_mode mode;
};
enum amdgpu_reg_state {
 AMDGPU_REG_STATE_TYPE_INVALID = 0,
 AMDGPU_REG_STATE_TYPE_XGMI = 1,
 AMDGPU_REG_STATE_TYPE_WAFL = 2,
 AMDGPU_REG_STATE_TYPE_PCIE = 3,
 AMDGPU_REG_STATE_TYPE_USR = 4,
 AMDGPU_REG_STATE_TYPE_USR_1 = 5
};
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct device;
struct file_operations;
struct debugfs_blob_wrapper {
 void *data;
 unsigned long size;
};
struct scatterlist;
struct __kfifo {
 unsigned int in;
 unsigned int out;
 unsigned int mask;
 unsigned int esize;
 void *data;
};
struct kfifo { union { struct __kfifo kfifo; unsigned char *type; const unsigned char *const_type; char (*rectype)[1]; void *ptr; void const *ptr_const; }; unsigned char buf[1]; };
enum ta_ras_address_type {
 TA_RAS_MCA_TO_PA,
 TA_RAS_PA_TO_MCA,
};
struct ta_ras_mca_addr {
 uint64_t err_addr;
 uint32_t ch_inst;
 uint32_t umc_inst;
 uint32_t node_inst;
 uint32_t socket_id;
};
struct ta_ras_phy_addr {
 uint64_t pa;
 uint32_t bank;
 uint32_t channel_idx;
};
struct ta_ras_query_address_input {
 enum ta_ras_address_type addr_type;
 struct ta_ras_mca_addr ma;
 struct ta_ras_phy_addr pa;
};
struct ta_ras_output_flags {
 uint8_t ras_init_success_flag;
 uint8_t err_inject_switch_disable_flag;
 uint8_t reg_access_failure_flag;
};
struct ta_ras_query_address_output {

 struct ta_ras_output_flags flags;
 struct ta_ras_mca_addr ma;
 struct ta_ras_phy_addr pa;
};
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct irq_domain;
struct irq_domain_ops;
struct proc_dir_entry;
struct pci_bus;
struct pci_dev;
struct bio_vec;
struct page;
struct device;
struct pci_dev;
enum acpi_predicate {
 all_versions,
 less_than_or_equal,
 equal,
 greater_than_or_equal,
};
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct u64_stats_sync {



};
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
void css_rstat_flush(struct cgroup_subsys_state *css);
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
static inline    void *kmap(struct page *page)
;
static inline    void *kmap(struct page *page);
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct folio_batch;
static inline    loff_t page_offset(struct page *page)
;
struct wait_page_queue {
 struct folio *folio;
 int bit_nr;
 wait_queue_entry_t wait;
};
struct readahead_control {
 struct file *file;
 struct address_space *mapping;
 struct file_ra_state *ra;

 unsigned long _index;
 unsigned int _nr_pages;
 unsigned int _batch_count;
 bool dropbehind;
 bool _workingset;
 unsigned long _pflags;
};
struct notifier_block;
struct bio;
struct reclaim_state {

 unsigned long reclaimed;


 struct lru_gen_mm_walk *mm_walk;

};
struct address_space;
struct writeback_control;
struct zone;
struct swap_sequential_cluster {
 unsigned int next[((21 - 12) + 1)];
};
struct swap_info_struct {
 struct percpu_ref users;
 unsigned long flags;
 signed short prio;
 struct plist_node list;
 signed char type;
 unsigned int max;
 unsigned char *swap_map;
 unsigned long *zeromap;
 struct swap_cluster_info *cluster_info;
 struct list_head free_clusters;
 struct list_head full_clusters;
 struct list_head nonfull_clusters[((21 - 12) + 1)];

 struct list_head frag_clusters[((21 - 12) + 1)];

 unsigned int pages;
 atomic_long_t inuse_pages;
 struct swap_sequential_cluster *global_cluster;
 spinlock_t global_cluster_lock;
 struct rb_root swap_extent_root;
 struct block_device *bdev;
 struct file *swap_file;
 struct completion comp;
 spinlock_t lock;
 spinlock_t cont_lock;



 struct work_struct discard_work;
 struct work_struct reclaim_work;
 struct list_head discard_clusters;
 struct plist_node avail_lists[1];
};
extern unsigned long totalreserve_pages;
struct backing_dev_info;
extern bool frozen(struct task_struct *p);
typedef int suspend_state_t;
struct device;
struct notifier_block;
struct regulator;
struct i2c_msg {
 __u16 addr;
 __u16 flags;
 __u16 len;
 __u8 *buf;
};
union i2c_smbus_data {
 __u8 byte;
 __u16 word;
 __u8 block[32 + 2];

};
struct i2c_msg;
struct i2c_adapter;
struct i2c_client;
union i2c_smbus_data;
enum i2c_slave_event;
typedef int (*i2c_slave_cb_t)(struct i2c_client *client,
         enum i2c_slave_event event, u8 *val);
struct module;
struct property_entry;
struct i2c_client {
 unsigned short flags;



 unsigned short addr;


 char name[20];
 struct i2c_adapter *adapter;
 struct device dev;
 int init_irq;
 int irq;
 struct list_head detected;

 i2c_slave_cb_t slave_cb;

 void *devres_group_id;
 struct dentry *debugfs;
};
enum i2c_slave_event {
 I2C_SLAVE_READ_REQUESTED,
 I2C_SLAVE_WRITE_REQUESTED,
 I2C_SLAVE_READ_PROCESSED,
 I2C_SLAVE_WRITE_RECEIVED,
 I2C_SLAVE_STOP,
};
int i2c_slave_event(struct i2c_client *client,
      enum i2c_slave_event event, u8 *val);
struct i2c_algorithm {






 union {
  int (*xfer)(struct i2c_adapter *adap, struct i2c_msg *msgs,
       int num);
  int (*master_xfer)(struct i2c_adapter *adap, struct i2c_msg *msgs,
       int num);
 };
 union {
  int (*xfer_atomic)(struct i2c_adapter *adap,
       struct i2c_msg *msgs, int num);
  int (*master_xfer_atomic)(struct i2c_adapter *adap,
        struct i2c_msg *msgs, int num);
 };
 int (*smbus_xfer)(struct i2c_adapter *adap, u16 addr,
     unsigned short flags, char read_write,
     u8 command, int size, union i2c_smbus_data *data);
 int (*smbus_xfer_atomic)(struct i2c_adapter *adap, u16 addr,
     unsigned short flags, char read_write,
     u8 command, int size, union i2c_smbus_data *data);


 u32 (*functionality)(struct i2c_adapter *adap);


 union {
  int (*reg_target)(struct i2c_client *client);
  int (*reg_slave)(struct i2c_client *client);
 };
 union {
  int (*unreg_target)(struct i2c_client *client);
  int (*unreg_slave)(struct i2c_client *client);
 };

};
struct i2c_lock_operations {
 void (*lock_bus)(struct i2c_adapter *adapter, unsigned int flags);
 int (*trylock_bus)(struct i2c_adapter *adapter, unsigned int flags);
 void (*unlock_bus)(struct i2c_adapter *adapter, unsigned int flags);
};
struct i2c_bus_recovery_info {
 int (*recover_bus)(struct i2c_adapter *adap);

 int (*get_scl)(struct i2c_adapter *adap);
 void (*set_scl)(struct i2c_adapter *adap, int val);
 int (*get_sda)(struct i2c_adapter *adap);
 void (*set_sda)(struct i2c_adapter *adap, int val);
 int (*get_bus_free)(struct i2c_adapter *adap);

 void (*prepare_recovery)(struct i2c_adapter *adap);
 void (*unprepare_recovery)(struct i2c_adapter *adap);


 struct gpio_desc *scl_gpiod;
 struct gpio_desc *sda_gpiod;
 struct pinctrl *pinctrl;
 struct pinctrl_state *pins_default;
 struct pinctrl_state *pins_gpio;
};
struct i2c_adapter_quirks {
 u64 flags;
 int max_num_msgs;
 u16 max_write_len;
 u16 max_read_len;
 u16 max_comb_1st_msg_len;
 u16 max_comb_2nd_msg_len;
};
struct i2c_adapter {
 struct module *owner;
 unsigned int class;
 const struct i2c_algorithm *algo;
 void *algo_data;


 const struct i2c_lock_operations *lock_ops;
 struct rt_mutex bus_lock;
 struct rt_mutex mux_lock;

 int timeout;
 int retries;
 struct device dev;
 unsigned long locked_flags;

 int nr;
 char name[48];
 struct completion dev_released;

 struct mutex userspace_clients_lock;
 struct list_head userspace_clients;

 struct i2c_bus_recovery_info *bus_recovery_info;
 const struct i2c_adapter_quirks *quirks;

 struct irq_domain *host_notify_domain;
 struct regulator *bus_regulator;

 struct dentry *debugfs;


 unsigned long addrs_in_instantiation[(((1 << 7) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct amdgpu_device;
enum amdgpu_ras_eeprom_err_type {
 AMDGPU_RAS_EEPROM_ERR_NA,
 AMDGPU_RAS_EEPROM_ERR_RECOVERABLE,
 AMDGPU_RAS_EEPROM_ERR_NON_RECOVERABLE,
 AMDGPU_RAS_EEPROM_ERR_COUNT,
};
struct amdgpu_ras_eeprom_table_header {
 uint32_t header;
 uint32_t version;
 uint32_t first_rec_offset;
 uint32_t tbl_size;
 uint32_t checksum;
} __attribute__((__packed__));
struct amdgpu_ras_eeprom_table_ras_info {
 u8 rma_status;
 u8 health_percent;
 u16 ecc_page_threshold;
 u32 padding[64 - 1];
} __attribute__((__packed__));
struct amdgpu_ras_eeprom_control {
 struct amdgpu_ras_eeprom_table_header tbl_hdr;

 struct amdgpu_ras_eeprom_table_ras_info tbl_rai;





 u32 i2c_address;






 u32 ras_header_offset;
 u32 ras_info_offset;
 u32 ras_record_offset;



 u32 ras_num_recs;




 u32 ras_num_bad_pages;


 u32 ras_num_mca_recs;


 u32 ras_num_pa_recs;






 u32 ras_fri;





 u32 ras_max_record_count;



 struct mutex ras_tbl_mutex;



 u32 bad_channel_bitmap;

 bool is_eeprom_valid;
};
struct eeprom_table_record {

 union {
  uint64_t address;
  uint64_t offset;
 };

 uint64_t retired_page;
 uint64_t ts;

 enum amdgpu_ras_eeprom_err_type err_type;

 union {
  unsigned char bank;
  unsigned char cu;
 };

 unsigned char mem_channel;
 unsigned char mcumc_id;
} __attribute__((__packed__));
enum amdgpu_pkg_type {
 AMDGPU_PKG_TYPE_APU = 2,
 AMDGPU_PKG_TYPE_CEM = 3,
 AMDGPU_PKG_TYPE_OAM = 4,
 AMDGPU_PKG_TYPE_UNKNOWN,
};
struct amdgpu_smuio_funcs {
 u32 (*get_rom_index_offset)(struct amdgpu_device *adev);
 u32 (*get_rom_data_offset)(struct amdgpu_device *adev);
 void (*update_rom_clock_gating)(struct amdgpu_device *adev, bool enable);
 void (*get_clock_gating_state)(struct amdgpu_device *adev, u64 *flags);
 u32 (*get_die_id)(struct amdgpu_device *adev);
 u32 (*get_socket_id)(struct amdgpu_device *adev);
 enum amdgpu_pkg_type (*get_pkg_type)(struct amdgpu_device *adev);
 bool (*is_host_gpu_xgmi_supported)(struct amdgpu_device *adev);
 u64 (*get_gpu_clock_counter)(struct amdgpu_device *adev);
};
struct amdgpu_smuio {
 const struct amdgpu_smuio_funcs *funcs;
};
struct ras_err_data;
enum aca_hwip_type {
 ACA_HWIP_TYPE_UNKNOW = -1,
 ACA_HWIP_TYPE_PSP = 0,
 ACA_HWIP_TYPE_UMC,
 ACA_HWIP_TYPE_SMU,
 ACA_HWIP_TYPE_PCS_XGMI,
 ACA_HWIP_TYPE_COUNT,
};
enum aca_error_type {
 ACA_ERROR_TYPE_INVALID = -1,
 ACA_ERROR_TYPE_UE = 0,
 ACA_ERROR_TYPE_CE,
 ACA_ERROR_TYPE_DEFERRED,
 ACA_ERROR_TYPE_COUNT
};
enum aca_smu_type {
 ACA_SMU_TYPE_INVALID = -1,
 ACA_SMU_TYPE_UE = 0,
 ACA_SMU_TYPE_CE,
 ACA_SMU_TYPE_COUNT,
};
struct aca_bank {
 enum aca_error_type aca_err_type;
 enum aca_smu_type smu_err_type;
 u64 regs[(16)];
};
struct aca_error {
 struct list_head list;
 struct mutex lock;
 enum aca_error_type type;
 int nr_errors;
};
struct aca_handle_manager {
 struct list_head list;
 int nr_handles;
};
struct aca_error_cache {
 struct aca_error errors[ACA_ERROR_TYPE_COUNT];
};
struct aca_handle {
 struct list_head node;
 enum aca_hwip_type hwip;
 struct amdgpu_device *adev;
 struct aca_handle_manager *mgr;
 struct aca_error_cache error_cache;
 const struct aca_bank_ops *bank_ops;
 struct device_attribute aca_attr;
 char attr_name[64];
 const char *name;
 u32 mask;
 void *data;
};
struct aca_bank_ops {
 int (*aca_bank_parser)(struct aca_handle *handle, struct aca_bank *bank, enum aca_smu_type type, void *data);
 bool (*aca_bank_is_valid)(struct aca_handle *handle, struct aca_bank *bank, enum aca_smu_type type,
      void *data);
};
struct aca_smu_funcs {
 int max_ue_bank_count;
 int max_ce_bank_count;
 int (*set_debug_mode)(struct amdgpu_device *adev, bool enable);
 int (*get_valid_aca_count)(struct amdgpu_device *adev, enum aca_smu_type type, u32 *count);
 int (*get_valid_aca_bank)(struct amdgpu_device *adev, enum aca_smu_type type, int idx, struct aca_bank *bank);
 int (*parse_error_code)(struct amdgpu_device *adev, struct aca_bank *bank);
};
struct amdgpu_aca {
 struct aca_handle_manager mgr;
 const struct aca_smu_funcs *smu_funcs;
 atomic_t ue_update_flag;
 bool is_enabled;
};
struct amdgpu_iv_entry;
enum amdgpu_ras_block {
 AMDGPU_RAS_BLOCK__UMC = 0,
 AMDGPU_RAS_BLOCK__SDMA,
 AMDGPU_RAS_BLOCK__GFX,
 AMDGPU_RAS_BLOCK__MMHUB,
 AMDGPU_RAS_BLOCK__ATHUB,
 AMDGPU_RAS_BLOCK__PCIE_BIF,
 AMDGPU_RAS_BLOCK__HDP,
 AMDGPU_RAS_BLOCK__XGMI_WAFL,
 AMDGPU_RAS_BLOCK__DF,
 AMDGPU_RAS_BLOCK__SMN,
 AMDGPU_RAS_BLOCK__SEM,
 AMDGPU_RAS_BLOCK__MP0,
 AMDGPU_RAS_BLOCK__MP1,
 AMDGPU_RAS_BLOCK__FUSE,
 AMDGPU_RAS_BLOCK__MCA,
 AMDGPU_RAS_BLOCK__VCN,
 AMDGPU_RAS_BLOCK__JPEG,
 AMDGPU_RAS_BLOCK__IH,
 AMDGPU_RAS_BLOCK__MPIO,
 AMDGPU_RAS_BLOCK__MMSCH,

 AMDGPU_RAS_BLOCK__LAST,
 AMDGPU_RAS_BLOCK__ANY = -1
};
enum amdgpu_ras_error_type {
 AMDGPU_RAS_ERROR__NONE = 0,
 AMDGPU_RAS_ERROR__PARITY = 1,
 AMDGPU_RAS_ERROR__SINGLE_CORRECTABLE = 2,
 AMDGPU_RAS_ERROR__MULTI_UNCORRECTABLE = 4,
 AMDGPU_RAS_ERROR__POISON = 8,
};
struct ras_common_if {
 enum amdgpu_ras_block block;
 enum amdgpu_ras_error_type type;
 uint32_t sub_block_index;
 char name[32];
};
struct ecc_info_per_ch {
 uint16_t ce_count_lo_chip;
 uint16_t ce_count_hi_chip;
 uint64_t mca_umc_status;
 uint64_t mca_umc_addr;
 uint64_t mca_ceumc_addr;
};
struct umc_ecc_info {
 struct ecc_info_per_ch ecc[32];




 int record_ce_addr_supported;
};
enum ras_event_type {
 RAS_EVENT_TYPE_INVALID = 0,
 RAS_EVENT_TYPE_FATAL,
 RAS_EVENT_TYPE_POISON_CREATION,
 RAS_EVENT_TYPE_POISON_CONSUMPTION,
 RAS_EVENT_TYPE_COUNT,
};
struct ras_event_state {
 u64 last_seqno;
 atomic64_t count;
};
struct ras_event_manager {
 atomic64_t seqno;
 struct ras_event_state event_state[RAS_EVENT_TYPE_COUNT];
};
typedef int (*pasid_notify)(struct amdgpu_device *adev,
  uint16_t pasid, void *data);
struct ras_poison_msg {
 enum amdgpu_ras_block block;
 uint16_t pasid;
 uint32_t reset;
 pasid_notify pasid_fn;
 void *data;
};
struct ras_ecc_log_info {
 struct mutex lock;
 struct xarray de_page_tree;
 uint64_t de_queried_count;
 uint64_t consumption_q_count;
};
struct amdgpu_ras {


 uint32_t features;
 uint32_t schema;
 struct list_head head;

 struct device_attribute features_attr;
 struct device_attribute version_attr;
 struct device_attribute schema_attr;
 struct device_attribute event_state_attr;
 struct bin_attribute badpages_attr;
 struct dentry *de_ras_eeprom_table;

 struct ras_manager *objs;


 struct work_struct recovery_work;
 atomic_t in_recovery;
 atomic_t rma_in_recovery;
 struct amdgpu_device *adev;

 struct ras_err_handler_data *eh_data;
 struct mutex recovery_lock;

 uint32_t flags;
 bool reboot;
 struct amdgpu_ras_eeprom_control eeprom_control;

 bool error_query_ready;


 uint32_t bad_page_cnt_threshold;


 bool disable_ras_err_cnt_harvest;


 bool poison_supported;


 struct delayed_work ras_counte_delay_work;
 atomic_t ras_ue_count;
 atomic_t ras_ce_count;


 struct umc_ecc_info umc_ecc;


 bool update_channel_flag;

 bool is_aca_debug_mode;
 bool is_rma;


 uint32_t gpu_reset_flags;

 struct task_struct *page_retirement_thread;
 wait_queue_head_t page_retirement_wq;
 struct mutex page_retirement_lock;
 atomic_t page_retirement_req_cnt;
 atomic_t poison_creation_count;
 atomic_t poison_consumption_count;
 struct mutex page_rsv_lock;
 struct { union { struct __kfifo kfifo; struct ras_poison_msg *type; const struct ras_poison_msg *const_type; char (*rectype)[1]; struct ras_poison_msg *ptr; struct ras_poison_msg const *ptr_const; }; struct ras_poison_msg buf[((128 < 2) || (128 & (128 - 1))) ? -1 : 128]; } poison_fifo;
 struct ras_ecc_log_info umc_ecc_log;
 struct delayed_work page_retirement_dwork;


 unsigned long ras_err_state;


 struct ras_event_manager __event_mgr;
 struct ras_event_manager *event_mgr;

 uint64_t reserved_pages_in_bytes;

 pid_t init_task_pid;
 char init_task_comm[TASK_COMM_LEN];

 int bad_page_num;

 struct list_head critical_region_head;
 struct mutex critical_region_lock;


 struct mutex poison_lock;
};
struct ras_fs_data {
 char sysfs_name[48];
 char debugfs_name[32];
};
struct ras_err_data {
 unsigned long ue_count;
 unsigned long ce_count;
 unsigned long de_count;
 unsigned long err_addr_cnt;
 struct eeprom_table_record *err_addr;
 unsigned long err_addr_len;
 u32 err_list_count;
 struct list_head err_node_list;
};
struct ras_err_handler_data {

 struct eeprom_table_record *bps;

 int count;
 int count_saved;

 int space_left;
};
typedef int (*ras_ih_cb)(struct amdgpu_device *adev,
  void *err_data,
  struct amdgpu_iv_entry *entry);
struct ras_ih_data {

 struct work_struct ih_work;
 int inuse;

 ras_ih_cb cb;

 unsigned char *ring;
 unsigned int ring_size;
 unsigned int element_size;
 unsigned int aligned_element_size;
 unsigned int rptr;
 unsigned int wptr;
};
struct ras_manager {
 struct ras_common_if head;

 int use;

 struct list_head node;

 struct amdgpu_device *adev;

 struct device_attribute sysfs_attr;
 int attr_inuse;


 struct ras_fs_data fs_data;


 struct ras_ih_data ih_data;

 struct ras_err_data err_data;

 struct aca_handle aca_handle;
};
struct amdgpu_ras_block_object {
 struct ras_common_if ras_comm;

 int (*ras_block_match)(struct amdgpu_ras_block_object *block_obj,
    enum amdgpu_ras_block block, uint32_t sub_block_index);
 int (*ras_late_init)(struct amdgpu_device *adev, struct ras_common_if *ras_block);
 void (*ras_suspend)(struct amdgpu_device *adev, struct ras_common_if *ras_block);
 void (*ras_fini)(struct amdgpu_device *adev, struct ras_common_if *ras_block);
 ras_ih_cb ras_cb;
 const struct amdgpu_ras_block_hw_ops *hw_ops;
};
struct amdgpu_ras_block_hw_ops {
 int (*ras_error_inject)(struct amdgpu_device *adev,
   void *inject_if, uint32_t instance_mask);
 void (*query_ras_error_count)(struct amdgpu_device *adev, void *ras_error_status);
 void (*query_ras_error_status)(struct amdgpu_device *adev);
 void (*query_ras_error_address)(struct amdgpu_device *adev, void *ras_error_status);
 void (*reset_ras_error_count)(struct amdgpu_device *adev);
 void (*reset_ras_error_status)(struct amdgpu_device *adev);
 bool (*query_poison_status)(struct amdgpu_device *adev);
 bool (*handle_poison_consumption)(struct amdgpu_device *adev);
};
struct amdgpu_ring;
struct amdgpu_mux_entry {
 struct amdgpu_ring *ring;
 u64 start_ptr_in_hw_ring;
 u64 end_ptr_in_hw_ring;
 u64 sw_cptr;
 u64 sw_rptr;
 u64 sw_wptr;
 struct list_head list;
};
struct amdgpu_ring_mux {
 struct amdgpu_ring *real_ring;

 struct amdgpu_mux_entry *ring_entry;
 unsigned int num_ring_entries;
 unsigned int ring_entry_size;

 spinlock_t lock;
 bool s_resubmit;
 uint32_t seqno_to_resubmit;
 u64 wptr_resubmit;
 struct timer_list resubmit_timer;

 bool pending_trailing_fence_signaled;
};
enum AMDGPU_XCP_IP_BLOCK {
 AMDGPU_XCP_GFXHUB,
 AMDGPU_XCP_GFX,
 AMDGPU_XCP_SDMA,
 AMDGPU_XCP_VCN,
 AMDGPU_XCP_MAX_BLOCKS
};
enum amdgpu_xcp_res_id {
 AMDGPU_XCP_RES_XCC,
 AMDGPU_XCP_RES_DMA,
 AMDGPU_XCP_RES_DEC,
 AMDGPU_XCP_RES_JPEG,
 AMDGPU_XCP_RES_MAX,
};
struct amdgpu_xcp_res_details {
 enum amdgpu_xcp_res_id id;
 u8 num_inst;
 u8 num_shared;
 struct kobject kobj;
};
struct amdgpu_xcp_cfg {
 u8 mode;
 struct amdgpu_xcp_res_details xcp_res[AMDGPU_XCP_RES_MAX];
 u8 num_res;
 struct amdgpu_xcp_mgr *xcp_mgr;
 struct kobject kobj;
 u16 compatible_nps_modes;
};
struct amdgpu_xcp_ip_funcs {
 int (*prepare_suspend)(void *handle, uint32_t inst_mask);
 int (*suspend)(void *handle, uint32_t inst_mask);
 int (*prepare_resume)(void *handle, uint32_t inst_mask);
 int (*resume)(void *handle, uint32_t inst_mask);
};
struct amdgpu_xcp_ip {
 struct amdgpu_xcp_ip_funcs *ip_funcs;
 uint32_t inst_mask;

 enum AMDGPU_XCP_IP_BLOCK ip_id;
 bool valid;
};
struct amdgpu_xcp {
 struct amdgpu_xcp_ip ip[AMDGPU_XCP_MAX_BLOCKS];

 uint8_t id;
 uint8_t mem_id;
 bool valid;
 atomic_t ref_cnt;
 struct drm_device *ddev;
 struct drm_device *rdev;
 struct drm_device *pdev;
 struct drm_driver *driver;
 struct drm_vma_offset_manager *vma_offset_manager;
 struct amdgpu_sched gpu_sched[10][AMDGPU_RING_PRIO_MAX];
 struct amdgpu_xcp_mgr *xcp_mgr;
 struct kobject kobj;
 uint64_t unique_id;
};
struct amdgpu_xcp_mgr {
 struct amdgpu_device *adev;
 struct mutex xcp_lock;
 struct amdgpu_xcp_mgr_funcs *funcs;

 struct amdgpu_xcp xcp[8];
 uint8_t num_xcps;
 int8_t mode;


 unsigned int num_xcp_per_mem_partition;
 struct amdgpu_xcp_cfg *xcp_cfg;
 uint32_t supp_xcp_modes;
 uint32_t avail_xcp_modes;
};
struct amdgpu_xcp_mgr_funcs {
 int (*switch_partition_mode)(struct amdgpu_xcp_mgr *xcp_mgr, int mode,
         int *num_xcps);
 int (*query_partition_mode)(struct amdgpu_xcp_mgr *xcp_mgr);
 int (*get_ip_details)(struct amdgpu_xcp_mgr *xcp_mgr, int xcp_id,
         enum AMDGPU_XCP_IP_BLOCK ip_id,
         struct amdgpu_xcp_ip *ip);
 int (*get_xcp_mem_id)(struct amdgpu_xcp_mgr *xcp_mgr,
         struct amdgpu_xcp *xcp, uint8_t *mem_id);
 int (*get_xcp_res_info)(struct amdgpu_xcp_mgr *xcp_mgr,
    int mode,
    struct amdgpu_xcp_cfg *xcp_cfg);
 int (*prepare_suspend)(struct amdgpu_xcp_mgr *xcp_mgr, int xcp_id);
 int (*suspend)(struct amdgpu_xcp_mgr *xcp_mgr, int xcp_id);
 int (*prepare_resume)(struct amdgpu_xcp_mgr *xcp_mgr, int xcp_id);
 int (*resume)(struct amdgpu_xcp_mgr *xcp_mgr, int xcp_id);
};
enum amdgpu_gfx_partition {
 AMDGPU_SPX_PARTITION_MODE = 0,
 AMDGPU_DPX_PARTITION_MODE = 1,
 AMDGPU_TPX_PARTITION_MODE = 2,
 AMDGPU_QPX_PARTITION_MODE = 3,
 AMDGPU_CPX_PARTITION_MODE = 4,
 AMDGPU_UNKNOWN_COMPUTE_PARTITION_MODE = -1,

 AMDGPU_AUTO_COMPUTE_PARTITION_MODE = -2,
};
struct amdgpu_mec {
 struct amdgpu_bo *hpd_eop_obj;
 u64 hpd_eop_gpu_addr;
 struct amdgpu_bo *mec_fw_obj;
 u64 mec_fw_gpu_addr;
 struct amdgpu_bo *mec_fw_data_obj;
 u64 mec_fw_data_gpu_addr;

 u32 num_mec;
 u32 num_pipe_per_mec;
 u32 num_queue_per_pipe;
 void *mqd_backup[8 * 8];
};
struct amdgpu_mec_bitmap {

 unsigned long queue_bitmap[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
enum amdgpu_unmap_queues_action {
 PREEMPT_QUEUES = 0,
 RESET_QUEUES,
 DISABLE_PROCESS_QUEUES,
 PREEMPT_QUEUES_NO_UNMAP,
};
struct kiq_pm4_funcs {

 void (*kiq_set_resources)(struct amdgpu_ring *kiq_ring,
     uint64_t queue_mask);
 void (*kiq_map_queues)(struct amdgpu_ring *kiq_ring,
     struct amdgpu_ring *ring);
 void (*kiq_unmap_queues)(struct amdgpu_ring *kiq_ring,
     struct amdgpu_ring *ring,
     enum amdgpu_unmap_queues_action action,
     u64 gpu_addr, u64 seq);
 void (*kiq_query_status)(struct amdgpu_ring *kiq_ring,
     struct amdgpu_ring *ring,
     u64 addr,
     u64 seq);
 void (*kiq_invalidate_tlbs)(struct amdgpu_ring *kiq_ring,
    uint16_t pasid, uint32_t flush_type,
    bool all_hub);
 void (*kiq_reset_hw_queue)(struct amdgpu_ring *kiq_ring,
       uint32_t queue_type, uint32_t me_id,
       uint32_t pipe_id, uint32_t queue_id,
       uint32_t xcc_id, uint32_t vmid);

 int set_resources_size;
 int map_queues_size;
 int unmap_queues_size;
 int query_status_size;
 int invalidate_tlbs_size;
};
struct amdgpu_kiq {
 u64 eop_gpu_addr;
 struct amdgpu_bo *eop_obj;
 spinlock_t ring_lock;
 struct amdgpu_ring ring;
 struct amdgpu_irq_src irq;
 const struct kiq_pm4_funcs *pmf;
 void *mqd_backup;
};
struct amdgpu_rb_config {






 uint32_t rb_backend_disable;







 uint32_t user_rb_backend_disable;







 uint32_t raster_config;







 uint32_t raster_config_1;
};
struct gb_addr_config {
 uint16_t pipe_interleave_size;
 uint8_t num_pipes;
 uint8_t max_compress_frags;
 uint8_t num_banks;
 uint8_t num_se;
 uint8_t num_rb_per_se;
 uint8_t num_pkrs;
};
struct amdgpu_gfx_config {
 unsigned max_shader_engines;
 unsigned max_tile_pipes;
 unsigned max_cu_per_sh;
 unsigned max_sh_per_se;
 unsigned max_backends_per_se;
 unsigned max_texture_channel_caches;
 unsigned max_gprs;
 unsigned max_gs_threads;
 unsigned max_hw_contexts;
 unsigned sc_prim_fifo_size_frontend;
 unsigned sc_prim_fifo_size_backend;
 unsigned sc_hiz_tile_fifo_size;
 unsigned sc_earlyz_tile_fifo_size;

 unsigned num_tile_pipes;
 unsigned backend_enable_mask;
 unsigned mem_max_burst_length_bytes;
 unsigned mem_row_size_in_kb;
 unsigned shader_engine_tile_size;
 unsigned num_gpus;
 unsigned multi_gpu_tile_size;
 unsigned mc_arb_ramcfg;
 unsigned num_banks;
 unsigned num_ranks;
 unsigned gb_addr_config;
 unsigned num_rbs;
 unsigned gs_vgt_table_depth;
 unsigned gs_prim_buffer_depth;

 uint32_t tile_mode_array[32];
 uint32_t macrotile_mode_array[16];

 struct gb_addr_config gb_addr_config_fields;







 struct amdgpu_rb_config rb_config[4][2];


 uint32_t double_offchip_lds_buf;

 uint32_t db_debug2;

 uint32_t num_sc_per_sh;
 uint32_t num_packer_per_sc;
 uint32_t pa_sc_tile_steering_override;

 bool ta_cntl2_truncate_coord_mode;
 uint64_t tcc_disabled_mask;
 uint32_t gc_num_tcp_per_sa;
 uint32_t gc_num_sdp_interface;
 uint32_t gc_num_tcps;
 uint32_t gc_num_tcp_per_wpg;
 uint32_t gc_tcp_l1_size;
 uint32_t gc_num_sqc_per_wgp;
 uint32_t gc_l1_instruction_cache_size_per_sqc;
 uint32_t gc_l1_data_cache_size_per_sqc;
 uint32_t gc_gl1c_per_sa;
 uint32_t gc_gl1c_size_per_instance;
 uint32_t gc_gl2c_per_gpu;
 uint32_t gc_tcp_size_per_cu;
 uint32_t gc_num_cu_per_sqc;
 uint32_t gc_tcc_size;
 uint32_t gc_tcp_cache_line_size;
 uint32_t gc_instruction_cache_size_per_sqc;
 uint32_t gc_instruction_cache_line_size;
 uint32_t gc_scalar_data_cache_size_per_sqc;
 uint32_t gc_scalar_data_cache_line_size;
 uint32_t gc_tcc_cache_line_size;
};
struct amdgpu_cu_info {
 uint32_t simd_per_cu;
 uint32_t max_waves_per_simd;
 uint32_t wave_front_size;
 uint32_t max_scratch_slots_per_cu;
 uint32_t lds_size;


 uint32_t number;
 uint32_t ao_cu_mask;
 uint32_t ao_cu_bitmap[4][4];
 uint32_t bitmap[8][4][4];
};
struct amdgpu_gfx_ras {
 struct amdgpu_ras_block_object ras_block;
 void (*enable_watchdog_timer)(struct amdgpu_device *adev);
 int (*rlc_gc_fed_irq)(struct amdgpu_device *adev,
    struct amdgpu_irq_src *source,
    struct amdgpu_iv_entry *entry);
 int (*poison_consumption_handler)(struct amdgpu_device *adev,
      struct amdgpu_iv_entry *entry);
};
struct amdgpu_gfx_shadow_info {
 u32 shadow_size;
 u32 shadow_alignment;
 u32 csa_size;
 u32 csa_alignment;
};
struct amdgpu_gfx_funcs {

 uint64_t (*get_gpu_clock_counter)(struct amdgpu_device *adev);
 void (*select_se_sh)(struct amdgpu_device *adev, u32 se_num,
        u32 sh_num, u32 instance, int xcc_id);
 void (*read_wave_data)(struct amdgpu_device *adev, uint32_t xcc_id, uint32_t simd,
          uint32_t wave, uint32_t *dst, int *no_fields);
 void (*read_wave_vgprs)(struct amdgpu_device *adev, uint32_t xcc_id, uint32_t simd,
    uint32_t wave, uint32_t thread, uint32_t start,
    uint32_t size, uint32_t *dst);
 void (*read_wave_sgprs)(struct amdgpu_device *adev, uint32_t xcc_id, uint32_t simd,
    uint32_t wave, uint32_t start, uint32_t size,
    uint32_t *dst);
 void (*select_me_pipe_q)(struct amdgpu_device *adev, u32 me, u32 pipe,
     u32 queue, u32 vmid, u32 xcc_id);
 void (*init_spm_golden)(struct amdgpu_device *adev);
 void (*update_perfmon_mgcg)(struct amdgpu_device *adev, bool enable);
 int (*get_gfx_shadow_info)(struct amdgpu_device *adev,
       struct amdgpu_gfx_shadow_info *shadow_info,
       bool skip_check);
 enum amdgpu_gfx_partition
   (*query_partition_mode)(struct amdgpu_device *adev);
 int (*switch_partition_mode)(struct amdgpu_device *adev,
         int num_xccs_per_xcp);
 int (*ih_node_to_logical_xcc)(struct amdgpu_device *adev, int ih_node);
 int (*get_xccs_per_xcp)(struct amdgpu_device *adev);
};
struct sq_work {
 struct work_struct work;
 unsigned ih_data;
};
struct amdgpu_pfp {
 struct amdgpu_bo *pfp_fw_obj;
 uint64_t pfp_fw_gpu_addr;
 uint32_t *pfp_fw_ptr;

 struct amdgpu_bo *pfp_fw_data_obj;
 uint64_t pfp_fw_data_gpu_addr;
 uint32_t *pfp_fw_data_ptr;
};
struct amdgpu_ce {
 struct amdgpu_bo *ce_fw_obj;
 uint64_t ce_fw_gpu_addr;
 uint32_t *ce_fw_ptr;
};
struct amdgpu_me {
 struct amdgpu_bo *me_fw_obj;
 uint64_t me_fw_gpu_addr;
 uint32_t *me_fw_ptr;

 struct amdgpu_bo *me_fw_data_obj;
 uint64_t me_fw_data_gpu_addr;
 uint32_t *me_fw_data_ptr;

 uint32_t num_me;
 uint32_t num_pipe_per_me;
 uint32_t num_queue_per_pipe;
 void *mqd_backup[2];


 unsigned long queue_bitmap[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct amdgpu_isolation_work {
 struct amdgpu_device *adev;
 u32 xcp_id;
 struct delayed_work work;
};
struct amdgpu_gfx {
 struct mutex gpu_clock_mutex;
 struct amdgpu_gfx_config config;
 struct amdgpu_rlc rlc;
 struct amdgpu_pfp pfp;
 struct amdgpu_ce ce;
 struct amdgpu_me me;
 struct amdgpu_mec mec;
 struct amdgpu_mec_bitmap mec_bitmap[8];
 struct amdgpu_kiq kiq[8];
 struct amdgpu_imu imu;
 bool rs64_enable;
 const struct firmware *me_fw;
 uint32_t me_fw_version;
 const struct firmware *pfp_fw;
 uint32_t pfp_fw_version;
 const struct firmware *ce_fw;
 uint32_t ce_fw_version;
 const struct firmware *rlc_fw;
 uint32_t rlc_fw_version;
 const struct firmware *mec_fw;
 uint32_t mec_fw_version;
 const struct firmware *mec2_fw;
 uint32_t mec2_fw_version;
 const struct firmware *imu_fw;
 uint32_t imu_fw_version;
 uint32_t me_feature_version;
 uint32_t ce_feature_version;
 uint32_t pfp_feature_version;
 uint32_t rlc_feature_version;
 uint32_t rlc_srlc_fw_version;
 uint32_t rlc_srlc_feature_version;
 uint32_t rlc_srlg_fw_version;
 uint32_t rlc_srlg_feature_version;
 uint32_t rlc_srls_fw_version;
 uint32_t rlc_srls_feature_version;
 uint32_t rlcp_ucode_version;
 uint32_t rlcp_ucode_feature_version;
 uint32_t rlcv_ucode_version;
 uint32_t rlcv_ucode_feature_version;
 uint32_t mec_feature_version;
 uint32_t mec2_feature_version;
 bool mec_fw_write_wait;
 bool me_fw_write_wait;
 bool cp_fw_write_wait;
 struct amdgpu_ring gfx_ring[2];
 unsigned num_gfx_rings;
 struct amdgpu_ring compute_ring[8 * 8];
 unsigned num_compute_rings;
 struct amdgpu_irq_src eop_irq;
 struct amdgpu_irq_src priv_reg_irq;
 struct amdgpu_irq_src priv_inst_irq;
 struct amdgpu_irq_src bad_op_irq;
 struct amdgpu_irq_src cp_ecc_error_irq;
 struct amdgpu_irq_src sq_irq;
 struct amdgpu_irq_src rlc_gc_fed_irq;
 struct sq_work sq_work;


 uint32_t gfx_current_status;

 unsigned ce_ram_size;
 struct amdgpu_cu_info cu_info;
 const struct amdgpu_gfx_funcs *funcs;


 uint32_t grbm_soft_reset;
 uint32_t srbm_soft_reset;
 uint32_t gfx_supported_reset;
 uint32_t compute_supported_reset;


 bool gfx_off_state;
 struct mutex gfx_off_mutex;
 uint32_t gfx_off_req_count;
 struct delayed_work gfx_off_delay_work;
 uint32_t gfx_off_residency;
 uint64_t gfx_off_entrycount;


 struct mutex pipe_reserve_mutex;
 unsigned long pipe_reserve_bitmap[(((128) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];


 struct ras_common_if *ras_if;
 struct amdgpu_gfx_ras *ras;

 bool is_poweron;

 struct amdgpu_ring sw_gfx_ring[2];
 struct amdgpu_ring_mux muxer;

 bool cp_gfx_shadow;

 uint16_t xcc_mask;
 uint32_t num_xcc_per_xcp;
 struct mutex partition_mutex;
 bool mcbp;


 uint32_t *ip_dump_core;
 uint32_t *ip_dump_compute_queues;
 uint32_t *ip_dump_gfx_queues;

 struct mutex reset_sem_mutex;


 struct amdgpu_bo *cleaner_shader_obj;
 unsigned int cleaner_shader_size;
 u64 cleaner_shader_gpu_addr;
 void *cleaner_shader_cpu_ptr;
 const void *cleaner_shader_ptr;
 bool enable_cleaner_shader;
 struct amdgpu_isolation_work enforce_isolation[8];

 struct mutex userq_sch_mutex;
 u64 userq_sch_req_count[8];
 bool userq_sch_inactive[8];
 unsigned long enforce_isolation_jiffies[8];
 unsigned long enforce_isolation_time[8];

 atomic_t total_submission_cnt;
 struct delayed_work idle_work;
 bool workload_profile_active;
 struct mutex workload_profile_mutex;

 bool disable_kq;
 bool disable_uq;
};
struct pci_dev;
struct amdgpu_device;
struct kfd_dev;
struct kgd_mem;
struct kfd_vm_fault_info {
 uint64_t page_addr;
 uint32_t vmid;
 uint32_t mc_id;
 uint32_t status;
 bool prot_valid;
 bool prot_read;
 bool prot_write;
 bool prot_exec;
};
struct cred;
struct module;
struct fs_pin;
struct pid_namespace {
 struct idr idr;
 struct callback_head rcu;
 unsigned int pid_allocated;
 struct task_struct *child_reaper;
 struct kmem_cache *pid_cachep;
 unsigned int level;
 int pid_max;
 struct pid_namespace *parent;

 struct fs_pin *bacct;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 int reboot;
 struct ns_common ns;
 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 int memfd_noexec_scope;


} ;
struct seq_file;
struct pid_namespace;
struct pid;
struct module;
struct seq_file;
typedef unsigned int insn_attr_t;
typedef unsigned char insn_byte_t;
typedef signed int insn_value_t;
struct insn_field {
 union {
  insn_value_t value;
  insn_byte_t bytes[4];
 };

 unsigned char got;
 unsigned char nbytes;
};
struct insn {
 struct insn_field prefixes;



 struct insn_field rex_prefix;
 union {
  struct insn_field vex_prefix;
  struct insn_field xop_prefix;
 };
 struct insn_field opcode;




 struct insn_field modrm;
 struct insn_field sib;
 struct insn_field displacement;
 union {
  struct insn_field immediate;
  struct insn_field moffset1;
  struct insn_field immediate1;
 };
 union {
  struct insn_field moffset2;
  struct insn_field immediate2;
 };

 int emulate_prefix_size;
 insn_attr_t attr;
 unsigned char opnd_bytes;
 unsigned char addr_bytes;
 unsigned char length;
 unsigned char x86_64;

 const insn_byte_t *kaddr;
 const insn_byte_t *end_kaddr;
 const insn_byte_t *next_byte;
};
struct task_struct;
struct vm_area_struct;
struct notifier_block;
struct iov_iter;
struct vm_struct {
 struct vm_struct *next;
 void *addr;
 unsigned long size;
 unsigned long flags;
 struct page **pages;

 unsigned int page_order;

 unsigned int nr_pages;
 phys_addr_t phys_addr;
 const void *caller;
 unsigned long requested_size;
};
extern void *vmap(struct page **pages, unsigned int count,
   unsigned long flags, pgprot_t prot);
extern void vunmap(const void *addr);
enum hdmi_infoframe_type {
 HDMI_INFOFRAME_TYPE_VENDOR = 0x81,
 HDMI_INFOFRAME_TYPE_AVI = 0x82,
 HDMI_INFOFRAME_TYPE_SPD = 0x83,
 HDMI_INFOFRAME_TYPE_AUDIO = 0x84,
 HDMI_INFOFRAME_TYPE_DRM = 0x87,
};
struct hdmi_any_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
};
enum hdmi_colorspace {
 HDMI_COLORSPACE_RGB,
 HDMI_COLORSPACE_YUV422,
 HDMI_COLORSPACE_YUV444,
 HDMI_COLORSPACE_YUV420,
 HDMI_COLORSPACE_RESERVED4,
 HDMI_COLORSPACE_RESERVED5,
 HDMI_COLORSPACE_RESERVED6,
 HDMI_COLORSPACE_IDO_DEFINED,
};
enum hdmi_scan_mode {
 HDMI_SCAN_MODE_NONE,
 HDMI_SCAN_MODE_OVERSCAN,
 HDMI_SCAN_MODE_UNDERSCAN,
 HDMI_SCAN_MODE_RESERVED,
};
enum hdmi_colorimetry {
 HDMI_COLORIMETRY_NONE,
 HDMI_COLORIMETRY_ITU_601,
 HDMI_COLORIMETRY_ITU_709,
 HDMI_COLORIMETRY_EXTENDED,
};
enum hdmi_picture_aspect {
 HDMI_PICTURE_ASPECT_NONE,
 HDMI_PICTURE_ASPECT_4_3,
 HDMI_PICTURE_ASPECT_16_9,
 HDMI_PICTURE_ASPECT_64_27,
 HDMI_PICTURE_ASPECT_256_135,
 HDMI_PICTURE_ASPECT_RESERVED,
};
enum hdmi_active_aspect {
 HDMI_ACTIVE_ASPECT_16_9_TOP = 2,
 HDMI_ACTIVE_ASPECT_14_9_TOP = 3,
 HDMI_ACTIVE_ASPECT_16_9_CENTER = 4,
 HDMI_ACTIVE_ASPECT_PICTURE = 8,
 HDMI_ACTIVE_ASPECT_4_3 = 9,
 HDMI_ACTIVE_ASPECT_16_9 = 10,
 HDMI_ACTIVE_ASPECT_14_9 = 11,
 HDMI_ACTIVE_ASPECT_4_3_SP_14_9 = 13,
 HDMI_ACTIVE_ASPECT_16_9_SP_14_9 = 14,
 HDMI_ACTIVE_ASPECT_16_9_SP_4_3 = 15,
};
enum hdmi_extended_colorimetry {
 HDMI_EXTENDED_COLORIMETRY_XV_YCC_601,
 HDMI_EXTENDED_COLORIMETRY_XV_YCC_709,
 HDMI_EXTENDED_COLORIMETRY_S_YCC_601,
 HDMI_EXTENDED_COLORIMETRY_OPYCC_601,
 HDMI_EXTENDED_COLORIMETRY_OPRGB,


 HDMI_EXTENDED_COLORIMETRY_BT2020_CONST_LUM,
 HDMI_EXTENDED_COLORIMETRY_BT2020,
 HDMI_EXTENDED_COLORIMETRY_RESERVED,
};
enum hdmi_quantization_range {
 HDMI_QUANTIZATION_RANGE_DEFAULT,
 HDMI_QUANTIZATION_RANGE_LIMITED,
 HDMI_QUANTIZATION_RANGE_FULL,
 HDMI_QUANTIZATION_RANGE_RESERVED,
};
enum hdmi_nups {
 HDMI_NUPS_UNKNOWN,
 HDMI_NUPS_HORIZONTAL,
 HDMI_NUPS_VERTICAL,
 HDMI_NUPS_BOTH,
};
enum hdmi_ycc_quantization_range {
 HDMI_YCC_QUANTIZATION_RANGE_LIMITED,
 HDMI_YCC_QUANTIZATION_RANGE_FULL,
};
enum hdmi_content_type {
 HDMI_CONTENT_TYPE_GRAPHICS,
 HDMI_CONTENT_TYPE_PHOTO,
 HDMI_CONTENT_TYPE_CINEMA,
 HDMI_CONTENT_TYPE_GAME,
};
enum hdmi_metadata_type {
 HDMI_STATIC_METADATA_TYPE1 = 0,
};
enum hdmi_eotf {
 HDMI_EOTF_TRADITIONAL_GAMMA_SDR,
 HDMI_EOTF_TRADITIONAL_GAMMA_HDR,
 HDMI_EOTF_SMPTE_ST2084,
 HDMI_EOTF_BT_2100_HLG,
};
struct hdmi_avi_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
 bool itc;
 unsigned char pixel_repeat;
 enum hdmi_colorspace colorspace;
 enum hdmi_scan_mode scan_mode;
 enum hdmi_colorimetry colorimetry;
 enum hdmi_picture_aspect picture_aspect;
 enum hdmi_active_aspect active_aspect;
 enum hdmi_extended_colorimetry extended_colorimetry;
 enum hdmi_quantization_range quantization_range;
 enum hdmi_nups nups;
 unsigned char video_code;
 enum hdmi_ycc_quantization_range ycc_quantization_range;
 enum hdmi_content_type content_type;
 unsigned short top_bar;
 unsigned short bottom_bar;
 unsigned short left_bar;
 unsigned short right_bar;
};
struct hdmi_drm_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
 enum hdmi_eotf eotf;
 enum hdmi_metadata_type metadata_type;
 struct {
  u16 x, y;
 } display_primaries[3];
 struct {
  u16 x, y;
 } white_point;
 u16 max_display_mastering_luminance;
 u16 min_display_mastering_luminance;
 u16 max_cll;
 u16 max_fall;
};
enum hdmi_spd_sdi {
 HDMI_SPD_SDI_UNKNOWN,
 HDMI_SPD_SDI_DSTB,
 HDMI_SPD_SDI_DVDP,
 HDMI_SPD_SDI_DVHS,
 HDMI_SPD_SDI_HDDVR,
 HDMI_SPD_SDI_DVC,
 HDMI_SPD_SDI_DSC,
 HDMI_SPD_SDI_VCD,
 HDMI_SPD_SDI_GAME,
 HDMI_SPD_SDI_PC,
 HDMI_SPD_SDI_BD,
 HDMI_SPD_SDI_SACD,
 HDMI_SPD_SDI_HDDVD,
 HDMI_SPD_SDI_PMP,
};
struct hdmi_spd_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
 char vendor[8];
 char product[16];
 enum hdmi_spd_sdi sdi;
};
enum hdmi_audio_coding_type {
 HDMI_AUDIO_CODING_TYPE_STREAM,
 HDMI_AUDIO_CODING_TYPE_PCM,
 HDMI_AUDIO_CODING_TYPE_AC3,
 HDMI_AUDIO_CODING_TYPE_MPEG1,
 HDMI_AUDIO_CODING_TYPE_MP3,
 HDMI_AUDIO_CODING_TYPE_MPEG2,
 HDMI_AUDIO_CODING_TYPE_AAC_LC,
 HDMI_AUDIO_CODING_TYPE_DTS,
 HDMI_AUDIO_CODING_TYPE_ATRAC,
 HDMI_AUDIO_CODING_TYPE_DSD,
 HDMI_AUDIO_CODING_TYPE_EAC3,
 HDMI_AUDIO_CODING_TYPE_DTS_HD,
 HDMI_AUDIO_CODING_TYPE_MLP,
 HDMI_AUDIO_CODING_TYPE_DST,
 HDMI_AUDIO_CODING_TYPE_WMA_PRO,
 HDMI_AUDIO_CODING_TYPE_CXT,
};
enum hdmi_audio_sample_size {
 HDMI_AUDIO_SAMPLE_SIZE_STREAM,
 HDMI_AUDIO_SAMPLE_SIZE_16,
 HDMI_AUDIO_SAMPLE_SIZE_20,
 HDMI_AUDIO_SAMPLE_SIZE_24,
};
enum hdmi_audio_sample_frequency {
 HDMI_AUDIO_SAMPLE_FREQUENCY_STREAM,
 HDMI_AUDIO_SAMPLE_FREQUENCY_32000,
 HDMI_AUDIO_SAMPLE_FREQUENCY_44100,
 HDMI_AUDIO_SAMPLE_FREQUENCY_48000,
 HDMI_AUDIO_SAMPLE_FREQUENCY_88200,
 HDMI_AUDIO_SAMPLE_FREQUENCY_96000,
 HDMI_AUDIO_SAMPLE_FREQUENCY_176400,
 HDMI_AUDIO_SAMPLE_FREQUENCY_192000,
};
enum hdmi_audio_coding_type_ext {

 HDMI_AUDIO_CODING_TYPE_EXT_CT,






 HDMI_AUDIO_CODING_TYPE_EXT_HE_AAC,
 HDMI_AUDIO_CODING_TYPE_EXT_HE_AAC_V2,
 HDMI_AUDIO_CODING_TYPE_EXT_MPEG_SURROUND,


 HDMI_AUDIO_CODING_TYPE_EXT_MPEG4_HE_AAC,
 HDMI_AUDIO_CODING_TYPE_EXT_MPEG4_HE_AAC_V2,
 HDMI_AUDIO_CODING_TYPE_EXT_MPEG4_AAC_LC,
 HDMI_AUDIO_CODING_TYPE_EXT_DRA,
 HDMI_AUDIO_CODING_TYPE_EXT_MPEG4_HE_AAC_SURROUND,
 HDMI_AUDIO_CODING_TYPE_EXT_MPEG4_AAC_LC_SURROUND = 10,
};
struct hdmi_audio_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
 unsigned char channels;
 enum hdmi_audio_coding_type coding_type;
 enum hdmi_audio_sample_size sample_size;
 enum hdmi_audio_sample_frequency sample_frequency;
 enum hdmi_audio_coding_type_ext coding_type_ext;
 unsigned char channel_allocation;
 unsigned char level_shift_value;
 bool downmix_inhibit;

};
enum hdmi_3d_structure {
 HDMI_3D_STRUCTURE_INVALID = -1,
 HDMI_3D_STRUCTURE_FRAME_PACKING = 0,
 HDMI_3D_STRUCTURE_FIELD_ALTERNATIVE,
 HDMI_3D_STRUCTURE_LINE_ALTERNATIVE,
 HDMI_3D_STRUCTURE_SIDE_BY_SIDE_FULL,
 HDMI_3D_STRUCTURE_L_DEPTH,
 HDMI_3D_STRUCTURE_L_DEPTH_GFX_GFX_DEPTH,
 HDMI_3D_STRUCTURE_TOP_AND_BOTTOM,
 HDMI_3D_STRUCTURE_SIDE_BY_SIDE_HALF = 8,
};
struct hdmi_vendor_infoframe {
 enum hdmi_infoframe_type type;
 unsigned char version;
 unsigned char length;
 unsigned int oui;
 u8 vic;
 enum hdmi_3d_structure s3d_struct;
 unsigned int s3d_ext_data;
};
struct hdr_static_metadata {
 __u8 eotf;
 __u8 metadata_type;
 __u16 max_cll;
 __u16 max_fall;
 __u16 min_cll;
};
struct hdr_sink_metadata {



 __u32 metadata_type;



 union {
  struct hdr_static_metadata hdmi_type1;
 };
};
union hdmi_vendor_any_infoframe {
 struct {
  enum hdmi_infoframe_type type;
  unsigned char version;
  unsigned char length;
  unsigned int oui;
 } any;
 struct hdmi_vendor_infoframe hdmi;
};
union hdmi_infoframe {
 struct hdmi_any_infoframe any;
 struct hdmi_avi_infoframe avi;
 struct hdmi_spd_infoframe spd;
 union hdmi_vendor_any_infoframe vendor;
 struct hdmi_audio_infoframe audio;
 struct hdmi_drm_infoframe drm;
};
struct drm_file;
struct drm_device;
struct drm_master;
struct drm_object_properties;
struct drm_property;
struct drm_device;
struct drm_file;
struct drm_mode_object {
 uint32_t id;
 uint32_t type;
 struct drm_object_properties *properties;
 struct kref refcount;
 void (*free_cb)(struct kref *kref);
};
struct drm_object_properties {





 int count;
 struct drm_property *properties[64];
 uint64_t values[64];
};
struct drm_property {



 struct list_head head;




 struct drm_mode_object base;
 uint32_t flags;




 char name[32];




 uint32_t num_values;







 uint64_t *values;




 struct drm_device *dev;







 struct list_head enum_list;
};
struct drm_property_blob {
 struct drm_mode_object base;
 struct drm_device *dev;
 struct list_head head_global;
 struct list_head head_file;
 size_t length;
 void *data;
};
struct drm_connector_helper_funcs;
struct drm_modeset_acquire_ctx;
struct drm_device;
struct drm_crtc;
struct drm_display_mode;
struct drm_encoder;
struct drm_property;
struct drm_property_blob;
struct drm_printer;
struct drm_privacy_screen;
struct drm_edid;
struct hdmi_codec_daifmt;
struct hdmi_codec_params;
struct i2c_adapter;
enum drm_connector_force {
 DRM_FORCE_UNSPECIFIED,
 DRM_FORCE_OFF,
 DRM_FORCE_ON,
 DRM_FORCE_ON_DIGITAL,
};
enum drm_connector_status {




 connector_status_connected = 1,







 connector_status_disconnected = 2,
 connector_status_unknown = 3,
};
enum drm_connector_registration_state {






 DRM_CONNECTOR_INITIALIZING = 0,







 DRM_CONNECTOR_REGISTERED = 1,
 DRM_CONNECTOR_UNREGISTERED = 2,
};
enum subpixel_order {
 SubPixelUnknown = 0,
 SubPixelHorizontalRGB,
 SubPixelHorizontalBGR,
 SubPixelVerticalRGB,
 SubPixelVerticalBGR,
 SubPixelNone,

};
enum drm_connector_tv_mode {




 DRM_MODE_TV_MODE_NTSC,






 DRM_MODE_TV_MODE_NTSC_443,






 DRM_MODE_TV_MODE_NTSC_J,





 DRM_MODE_TV_MODE_PAL,





 DRM_MODE_TV_MODE_PAL_M,







 DRM_MODE_TV_MODE_PAL_N,





 DRM_MODE_TV_MODE_SECAM,






 DRM_MODE_TV_MODE_MONOCHROME,






 DRM_MODE_TV_MODE_MAX,
};
struct drm_scrambling {



 bool supported;



 bool low_rates;
};
struct drm_scdc {



 bool supported;



 bool read_request;



 struct drm_scrambling scrambling;
};
struct drm_hdmi_dsc_cap {

 bool v_1p2;


 bool native_420;





 bool all_bpp;




 u8 bpc_supported;


 u8 max_slices;


 int clk_per_slice;


 u8 max_lanes;


 u8 max_frl_rate_per_lane;


 u8 total_chunk_kbytes;
};
struct drm_hdmi_info {

 struct drm_scdc scdc;







 unsigned long y420_vdb_modes[(((256) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];







 unsigned long y420_cmdb_modes[(((256) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];


 u8 y420_dc_modes;


 u8 max_frl_rate_per_lane;


 u8 max_lanes;


 struct drm_hdmi_dsc_cap dsc_cap;
};
enum drm_link_status {
 DRM_LINK_STATUS_GOOD = 0,
 DRM_LINK_STATUS_BAD = 1,
};
enum drm_panel_orientation {
 DRM_MODE_PANEL_ORIENTATION_UNKNOWN = -1,
 DRM_MODE_PANEL_ORIENTATION_NORMAL = 0,
 DRM_MODE_PANEL_ORIENTATION_BOTTOM_UP,
 DRM_MODE_PANEL_ORIENTATION_LEFT_UP,
 DRM_MODE_PANEL_ORIENTATION_RIGHT_UP,
};
enum drm_hdmi_broadcast_rgb {




 DRM_HDMI_BROADCAST_RGB_AUTO,




 DRM_HDMI_BROADCAST_RGB_FULL,




 DRM_HDMI_BROADCAST_RGB_LIMITED,
};
struct drm_monitor_range_info {
 u16 min_vfreq;
 u16 max_vfreq;
};
struct drm_luminance_range_info {
 u32 min_luminance;
 u32 max_luminance;
};
enum drm_privacy_screen_status {
 PRIVACY_SCREEN_DISABLED = 0,
 PRIVACY_SCREEN_ENABLED,
 PRIVACY_SCREEN_DISABLED_LOCKED,
 PRIVACY_SCREEN_ENABLED_LOCKED,
};
enum drm_colorspace {

 DRM_MODE_COLORIMETRY_DEFAULT = 0,

 DRM_MODE_COLORIMETRY_NO_DATA = 0,
 DRM_MODE_COLORIMETRY_SMPTE_170M_YCC = 1,
 DRM_MODE_COLORIMETRY_BT709_YCC = 2,

 DRM_MODE_COLORIMETRY_XVYCC_601 = 3,
 DRM_MODE_COLORIMETRY_XVYCC_709 = 4,
 DRM_MODE_COLORIMETRY_SYCC_601 = 5,
 DRM_MODE_COLORIMETRY_OPYCC_601 = 6,
 DRM_MODE_COLORIMETRY_OPRGB = 7,
 DRM_MODE_COLORIMETRY_BT2020_CYCC = 8,
 DRM_MODE_COLORIMETRY_BT2020_RGB = 9,
 DRM_MODE_COLORIMETRY_BT2020_YCC = 10,

 DRM_MODE_COLORIMETRY_DCI_P3_RGB_D65 = 11,
 DRM_MODE_COLORIMETRY_DCI_P3_RGB_THEATER = 12,

 DRM_MODE_COLORIMETRY_RGB_WIDE_FIXED = 13,
 DRM_MODE_COLORIMETRY_RGB_WIDE_FLOAT = 14,
 DRM_MODE_COLORIMETRY_BT601_YCC = 15,
 DRM_MODE_COLORIMETRY_COUNT
};
struct drm_display_info {



 unsigned int width_mm;




 unsigned int height_mm;




 unsigned int bpc;




 enum subpixel_order subpixel_order;

 int panel_orientation;







 u32 color_formats;






 const u32 *bus_formats;



 unsigned int num_bus_formats;






 u32 bus_flags;





 int max_tmds_clock;




 bool dvi_dual;







 bool is_hdmi;







 bool has_audio;




 bool has_hdmi_infoframe;





 bool rgb_quant_range_selectable;





 u8 edid_hdmi_rgb444_dc_modes;





 u8 edid_hdmi_ycbcr444_dc_modes;




 u8 cea_rev;




 struct drm_hdmi_info hdmi;




 struct hdr_sink_metadata hdr_sink_metadata;




 bool non_desktop;




 struct drm_monitor_range_info monitor_range;




 struct drm_luminance_range_info luminance_range;






 u8 mso_stream_count;




 u8 mso_pixel_overlap;





 u32 max_dsc_bpp;




 u8 *vics;




 int vics_len;






 u32 quirks;







 u16 source_physical_address;
};
struct drm_connector_tv_margins {



 unsigned int bottom;




 unsigned int left;




 unsigned int right;




 unsigned int top;
};
struct drm_tv_connector_state {
 enum drm_mode_subconnector select_subconnector;
 enum drm_mode_subconnector subconnector;
 struct drm_connector_tv_margins margins;
 unsigned int legacy_mode;
 unsigned int mode;
 unsigned int brightness;
 unsigned int contrast;
 unsigned int flicker_reduction;
 unsigned int overscan;
 unsigned int saturation;
 unsigned int hue;
};
struct drm_connector_hdmi_infoframe {



 union hdmi_infoframe data;




 bool set;
};
struct drm_connector_hdmi_state {




 enum drm_hdmi_broadcast_rgb broadcast_rgb;




 struct {




  struct drm_connector_hdmi_infoframe avi;





  struct drm_connector_hdmi_infoframe hdr_drm;





  struct drm_connector_hdmi_infoframe spd;





  struct drm_connector_hdmi_infoframe hdmi;
 } infoframes;





 bool is_limited_range;




 unsigned int output_bpc;




 enum hdmi_colorspace output_format;




 unsigned long long tmds_char_rate;
};
struct drm_connector_state {

 struct drm_connector *connector;







 struct drm_crtc *crtc;
 struct drm_encoder *best_encoder;





 enum drm_link_status link_status;


 struct drm_atomic_state *state;






 struct drm_crtc_commit *commit;


 struct drm_tv_connector_state tv;
 bool self_refresh_aware;
 enum hdmi_picture_aspect picture_aspect_ratio;







 unsigned int content_type;





 unsigned int hdcp_content_type;





 unsigned int scaling_mode;





 unsigned int content_protection;






 enum drm_colorspace colorspace;
 struct drm_writeback_job *writeback_job;





 u8 max_requested_bpc;





 u8 max_bpc;





 enum drm_privacy_screen_status privacy_screen_sw_state;





 struct drm_property_blob *hdr_output_metadata;





 struct drm_connector_hdmi_state hdmi;
};
struct drm_connector_hdmi_audio_funcs {
 int (*startup)(struct drm_connector *connector);
 int (*prepare)(struct drm_connector *connector,
         struct hdmi_codec_daifmt *fmt,
         struct hdmi_codec_params *hparms);
 void (*shutdown)(struct drm_connector *connector);
 int (*mute_stream)(struct drm_connector *connector,
      bool enable, int direction);
};
struct drm_connector_cec_funcs {






 void (*phys_addr_invalidate)(struct drm_connector *connector);






 void (*phys_addr_set)(struct drm_connector *connector, u16 addr);
};
struct drm_connector_hdmi_funcs {
 enum drm_mode_status
 (*tmds_char_rate_valid)(const struct drm_connector *connector,
    const struct drm_display_mode *mode,
    unsigned long long tmds_rate);
 int (*clear_infoframe)(struct drm_connector *connector,
          enum hdmi_infoframe_type type);
 int (*write_infoframe)(struct drm_connector *connector,
          enum hdmi_infoframe_type type,
          const u8 *buffer, size_t len);
 const struct drm_edid *(*read_edid)(struct drm_connector *connector);
};
struct drm_connector_funcs {
 int (*dpms)(struct drm_connector *connector, int mode);
 void (*reset)(struct drm_connector *connector);
 enum drm_connector_status (*detect)(struct drm_connector *connector,
         bool force);
 void (*force)(struct drm_connector *connector);
 int (*fill_modes)(struct drm_connector *connector, uint32_t max_width, uint32_t max_height);
 int (*set_property)(struct drm_connector *connector, struct drm_property *property,
        uint64_t val);
 int (*late_register)(struct drm_connector *connector);
 void (*early_unregister)(struct drm_connector *connector);
 void (*destroy)(struct drm_connector *connector);
 struct drm_connector_state *(*atomic_duplicate_state)(struct drm_connector *connector);
 void (*atomic_destroy_state)(struct drm_connector *connector,
         struct drm_connector_state *state);
 int (*atomic_set_property)(struct drm_connector *connector,
       struct drm_connector_state *state,
       struct drm_property *property,
       uint64_t val);
 int (*atomic_get_property)(struct drm_connector *connector,
       const struct drm_connector_state *state,
       struct drm_property *property,
       uint64_t *val);
 void (*atomic_print_state)(struct drm_printer *p,
       const struct drm_connector_state *state);







 void (*oob_hotplug_event)(struct drm_connector *connector,
      enum drm_connector_status status);






 void (*debugfs_init)(struct drm_connector *connector, struct dentry *root);
};
struct drm_cmdline_mode {





 char name[32];






 bool specified;






 bool refresh_specified;






 bool bpp_specified;






 unsigned int pixel_clock;






 int xres;






 int yres;






 int bpp;






 int refresh;






 bool rb;






 bool interlace;







 bool cvt;







 bool margins;







 enum drm_connector_force force;
 unsigned int rotation_reflection;







 enum drm_panel_orientation panel_orientation;




 struct drm_connector_tv_margins tv_margins;




 enum drm_connector_tv_mode tv_mode;






 bool tv_mode_specified;
};
struct drm_connector_hdmi_audio {






 const struct drm_connector_hdmi_audio_funcs *funcs;







 struct platform_device *codec_pdev;






 struct mutex lock;
 void (*plugged_cb)(struct device *dev, bool plugged);






 struct device *plugged_cb_dev;







 bool last_state;






 int dai_port;
};
struct drm_connector_hdmi {



 unsigned char vendor[8] ;




 unsigned char product[16] ;





 unsigned long supported_formats;




 const struct drm_connector_hdmi_funcs *funcs;




 struct {




  struct mutex lock;





  struct drm_connector_hdmi_infoframe audio;
 } infoframes;
};
struct drm_connector_cec {



 struct mutex mutex;




 const struct drm_connector_cec_funcs *funcs;




 void *data;
};
struct drm_connector {

 struct drm_device *dev;

 struct device *kdev;

 struct device_attribute *attr;







 struct fwnode_handle *fwnode;
 struct list_head head;







 struct list_head global_connector_list_entry;


 struct drm_mode_object base;


 char *name;






 struct mutex mutex;







 unsigned index;





 int connector_type;

 int connector_type_id;





 bool interlace_allowed;





 bool doublescan_allowed;





 bool stereo_allowed;







 bool ycbcr_420_allowed;







 enum drm_connector_registration_state registration_state;






 struct list_head modes;






 enum drm_connector_status status;







 struct list_head probed_modes;
 struct drm_display_info display_info;


 const struct drm_connector_funcs *funcs;
 struct drm_property_blob *edid_blob_ptr;


 struct drm_object_properties properties;





 struct drm_property *scaling_mode_property;
 struct drm_property *vrr_capable_property;





 struct drm_property *colorspace_property;







 struct drm_property_blob *path_blob_ptr;




 unsigned int max_bpc;





 struct drm_property *max_bpc_property;


 struct drm_privacy_screen *privacy_screen;


 struct notifier_block privacy_screen_notifier;





 struct drm_property *privacy_screen_sw_state_property;





 struct drm_property *privacy_screen_hw_state_property;





 struct drm_property *broadcast_rgb_property;

 uint8_t polled;







 int dpms;


 const struct drm_connector_helper_funcs *helper_private;


 struct drm_cmdline_mode cmdline_mode;

 enum drm_connector_force force;







 const struct drm_edid *edid_override;




 struct mutex edid_override_mutex;


 u64 epoch_counter;






 u32 possible_encoders;







 struct drm_encoder *encoder;


 uint8_t eld[128];

 struct mutex eld_mutex;


 bool latency_present[2];




 int video_latency[2];




 int audio_latency[2];
 struct i2c_adapter *ddc;





 int null_edid_counter;


 unsigned bad_edid_counter;






 bool edid_corrupt;





 u8 real_edid_checksum;


 struct dentry *debugfs_entry;
 struct drm_connector_state *state;
 struct drm_property_blob *tile_blob_ptr;


 bool has_tile;

 struct drm_tile_group *tile_group;

 bool tile_is_single_monitor;



 uint8_t num_h_tile, num_v_tile;


 uint8_t tile_h_loc, tile_v_loc;


 uint16_t tile_h_size, tile_v_size;
 struct llist_node free_node;




 struct drm_connector_hdmi hdmi;




 struct drm_connector_hdmi_audio hdmi_audio;




 struct drm_connector_cec cec;
};
struct drm_tile_group {
 struct kref refcount;
 struct drm_device *dev;
 int id;
 u8 group_data[9];
};
struct drm_device;
struct drm_dp_aux;
struct drm_dp_aux_msg {
 unsigned int address;
 u8 request;
 u8 reply;
 void *buffer;
 size_t size;
};
struct cec_adapter;
struct drm_connector;
struct drm_edid;
struct drm_dp_aux_cec {
 struct mutex lock;
 struct cec_adapter *adap;
 struct drm_connector *connector;
 struct delayed_work unregister_work;
};
struct drm_dp_aux {







 const char *name;





 struct i2c_adapter ddc;





 struct device *dev;
 struct drm_device *drm_dev;





 struct drm_crtc *crtc;
 struct mutex hw_mutex;




 struct work_struct crc_work;




 u8 crc_count;
 ssize_t (*transfer)(struct drm_dp_aux *aux,
       struct drm_dp_aux_msg *msg);
 int (*wait_hpd_asserted)(struct drm_dp_aux *aux, unsigned long wait_us);




 unsigned i2c_nack_count;



 unsigned i2c_defer_count;



 struct drm_dp_aux_cec cec;



 bool is_remote;




 bool powered_down;




 bool no_zero_sized;




 bool dpcd_probe_disabled;
};
enum amd_asic_type {
 CHIP_TAHITI = 0,
 CHIP_PITCAIRN,
 CHIP_VERDE,
 CHIP_OLAND,
 CHIP_HAINAN,
 CHIP_BONAIRE,
 CHIP_KAVERI,
 CHIP_KABINI,
 CHIP_HAWAII,
 CHIP_MULLINS,
 CHIP_TOPAZ,
 CHIP_TONGA,
 CHIP_FIJI,
 CHIP_CARRIZO,
 CHIP_STONEY,
 CHIP_POLARIS10,
 CHIP_POLARIS11,
 CHIP_POLARIS12,
 CHIP_VEGAM,
 CHIP_VEGA10,
 CHIP_VEGA12,
 CHIP_VEGA20,
 CHIP_RAVEN,
 CHIP_ARCTURUS,
 CHIP_RENOIR,
 CHIP_ALDEBARAN,
 CHIP_NAVI10,
 CHIP_CYAN_SKILLFISH,
 CHIP_NAVI14,
 CHIP_NAVI12,
 CHIP_SIENNA_CICHLID,
 CHIP_NAVY_FLOUNDER,
 CHIP_VANGOGH,
 CHIP_DIMGREY_CAVEFISH,
 CHIP_BEIGE_GOBY,
 CHIP_YELLOW_CARP,
 CHIP_IP_DISCOVERY,
 CHIP_LAST,
};
struct amdgpu_ip_block;
enum amd_ip_block_type {
 AMD_IP_BLOCK_TYPE_COMMON,
 AMD_IP_BLOCK_TYPE_GMC,
 AMD_IP_BLOCK_TYPE_IH,
 AMD_IP_BLOCK_TYPE_SMC,
 AMD_IP_BLOCK_TYPE_PSP,
 AMD_IP_BLOCK_TYPE_DCE,
 AMD_IP_BLOCK_TYPE_GFX,
 AMD_IP_BLOCK_TYPE_SDMA,
 AMD_IP_BLOCK_TYPE_UVD,
 AMD_IP_BLOCK_TYPE_VCE,
 AMD_IP_BLOCK_TYPE_ACP,
 AMD_IP_BLOCK_TYPE_VCN,
 AMD_IP_BLOCK_TYPE_MES,
 AMD_IP_BLOCK_TYPE_JPEG,
 AMD_IP_BLOCK_TYPE_VPE,
 AMD_IP_BLOCK_TYPE_UMSCH_MM,
 AMD_IP_BLOCK_TYPE_ISP,
 AMD_IP_BLOCK_TYPE_NUM,
};
enum amd_clockgating_state {
 AMD_CG_STATE_GATE = 0,
 AMD_CG_STATE_UNGATE,
};
enum amd_powergating_state {
 AMD_PG_STATE_GATE = 0,
 AMD_PG_STATE_UNGATE,
};
enum amd_dpm_forced_level;
struct amd_ip_funcs {
 char *name;
 int (*early_init)(struct amdgpu_ip_block *ip_block);
 int (*late_init)(struct amdgpu_ip_block *ip_block);
 int (*sw_init)(struct amdgpu_ip_block *ip_block);
 int (*sw_fini)(struct amdgpu_ip_block *ip_block);
 int (*early_fini)(struct amdgpu_ip_block *ip_block);
 int (*hw_init)(struct amdgpu_ip_block *ip_block);
 int (*hw_fini)(struct amdgpu_ip_block *ip_block);
 void (*late_fini)(struct amdgpu_ip_block *ip_block);
 int (*prepare_suspend)(struct amdgpu_ip_block *ip_block);
 int (*suspend)(struct amdgpu_ip_block *ip_block);
 int (*resume)(struct amdgpu_ip_block *ip_block);
 void (*complete)(struct amdgpu_ip_block *ip_block);
 bool (*is_idle)(struct amdgpu_ip_block *ip_block);
 int (*wait_for_idle)(struct amdgpu_ip_block *ip_block);
 bool (*check_soft_reset)(struct amdgpu_ip_block *ip_block);
 int (*pre_soft_reset)(struct amdgpu_ip_block *ip_block);
 int (*soft_reset)(struct amdgpu_ip_block *ip_block);
 int (*post_soft_reset)(struct amdgpu_ip_block *ip_block);
 int (*set_clockgating_state)(struct amdgpu_ip_block *ip_block,
         enum amd_clockgating_state state);
 int (*set_powergating_state)(struct amdgpu_ip_block *ip_block,
         enum amd_powergating_state state);
 void (*get_clockgating_state)(struct amdgpu_ip_block *ip_block, u64 *flags);
 void (*dump_ip_state)(struct amdgpu_ip_block *ip_block);
 void (*print_ip_state)(struct amdgpu_ip_block *ip_block, struct drm_printer *p);
};
struct cgs_device;
enum cgs_ind_reg {
 CGS_IND_REG__PCIE,
 CGS_IND_REG__SMC,
 CGS_IND_REG__UVD_CTX,
 CGS_IND_REG__DIDT,
 CGS_IND_REG_GC_CAC,
 CGS_IND_REG_SE_CAC,
 CGS_IND_REG__AUDIO_ENDPT
};
enum cgs_ucode_id {
 CGS_UCODE_ID_SMU = 0,
 CGS_UCODE_ID_SMU_SK,
 CGS_UCODE_ID_SDMA0,
 CGS_UCODE_ID_SDMA1,
 CGS_UCODE_ID_CP_CE,
 CGS_UCODE_ID_CP_PFP,
 CGS_UCODE_ID_CP_ME,
 CGS_UCODE_ID_CP_MEC,
 CGS_UCODE_ID_CP_MEC_JT1,
 CGS_UCODE_ID_CP_MEC_JT2,
 CGS_UCODE_ID_GMCON_RENG,
 CGS_UCODE_ID_RLC_G,
 CGS_UCODE_ID_STORAGE,
 CGS_UCODE_ID_MAXIMUM,
};
struct cgs_firmware_info {
 uint16_t version;
 uint16_t fw_version;
 uint16_t feature_version;
 uint32_t image_size;
 uint64_t mc_addr;


 uint32_t ucode_start_address;

 void *kptr;
 bool is_kicker;
};
typedef uint32_t (*cgs_read_register_t)(struct cgs_device *cgs_device, unsigned offset);
typedef void (*cgs_write_register_t)(struct cgs_device *cgs_device, unsigned offset,
         uint32_t value);
typedef uint32_t (*cgs_read_ind_register_t)(struct cgs_device *cgs_device, enum cgs_ind_reg space,
         unsigned index);
typedef void (*cgs_write_ind_register_t)(struct cgs_device *cgs_device, enum cgs_ind_reg space,
      unsigned index, uint32_t value);
typedef int (*cgs_get_firmware_info)(struct cgs_device *cgs_device,
         enum cgs_ucode_id type,
         struct cgs_firmware_info *info);
struct cgs_ops {

 cgs_read_register_t read_register;
 cgs_write_register_t write_register;
 cgs_read_ind_register_t read_ind_register;
 cgs_write_ind_register_t write_ind_register;

 cgs_get_firmware_info get_firmware_info;
};
struct cgs_device {
 const struct cgs_ops *ops;

};
struct dc_context;
enum dc_irq_source {

 DC_IRQ_SOURCE_INVALID = 0,

 DC_IRQ_SOURCE_HPD1,
 DC_IRQ_SOURCE_HPD2,
 DC_IRQ_SOURCE_HPD3,
 DC_IRQ_SOURCE_HPD4,
 DC_IRQ_SOURCE_HPD5,
 DC_IRQ_SOURCE_HPD6,

 DC_IRQ_SOURCE_HPD1RX,
 DC_IRQ_SOURCE_HPD2RX,
 DC_IRQ_SOURCE_HPD3RX,
 DC_IRQ_SOURCE_HPD4RX,
 DC_IRQ_SOURCE_HPD5RX,
 DC_IRQ_SOURCE_HPD6RX,

 DC_IRQ_SOURCE_I2C_DDC1,
 DC_IRQ_SOURCE_I2C_DDC2,
 DC_IRQ_SOURCE_I2C_DDC3,
 DC_IRQ_SOURCE_I2C_DDC4,
 DC_IRQ_SOURCE_I2C_DDC5,
 DC_IRQ_SOURCE_I2C_DDC6,

 DC_IRQ_SOURCE_DPSINK1,
 DC_IRQ_SOURCE_DPSINK2,
 DC_IRQ_SOURCE_DPSINK3,
 DC_IRQ_SOURCE_DPSINK4,
 DC_IRQ_SOURCE_DPSINK5,
 DC_IRQ_SOURCE_DPSINK6,

 DC_IRQ_SOURCE_TIMER,

 DC_IRQ_SOURCE_PFLIP_FIRST,
 DC_IRQ_SOURCE_PFLIP1 = DC_IRQ_SOURCE_PFLIP_FIRST,
 DC_IRQ_SOURCE_PFLIP2,
 DC_IRQ_SOURCE_PFLIP3,
 DC_IRQ_SOURCE_PFLIP4,
 DC_IRQ_SOURCE_PFLIP5,
 DC_IRQ_SOURCE_PFLIP6,
 DC_IRQ_SOURCE_PFLIP_UNDERLAY0,
 DC_IRQ_SOURCE_PFLIP_LAST = DC_IRQ_SOURCE_PFLIP_UNDERLAY0,

 DC_IRQ_SOURCE_GPIOPAD0,
 DC_IRQ_SOURCE_GPIOPAD1,
 DC_IRQ_SOURCE_GPIOPAD2,
 DC_IRQ_SOURCE_GPIOPAD3,
 DC_IRQ_SOURCE_GPIOPAD4,
 DC_IRQ_SOURCE_GPIOPAD5,
 DC_IRQ_SOURCE_GPIOPAD6,
 DC_IRQ_SOURCE_GPIOPAD7,
 DC_IRQ_SOURCE_GPIOPAD8,
 DC_IRQ_SOURCE_GPIOPAD9,
 DC_IRQ_SOURCE_GPIOPAD10,
 DC_IRQ_SOURCE_GPIOPAD11,
 DC_IRQ_SOURCE_GPIOPAD12,
 DC_IRQ_SOURCE_GPIOPAD13,
 DC_IRQ_SOURCE_GPIOPAD14,
 DC_IRQ_SOURCE_GPIOPAD15,
 DC_IRQ_SOURCE_GPIOPAD16,
 DC_IRQ_SOURCE_GPIOPAD17,
 DC_IRQ_SOURCE_GPIOPAD18,
 DC_IRQ_SOURCE_GPIOPAD19,
 DC_IRQ_SOURCE_GPIOPAD20,
 DC_IRQ_SOURCE_GPIOPAD21,
 DC_IRQ_SOURCE_GPIOPAD22,
 DC_IRQ_SOURCE_GPIOPAD23,
 DC_IRQ_SOURCE_GPIOPAD24,
 DC_IRQ_SOURCE_GPIOPAD25,
 DC_IRQ_SOURCE_GPIOPAD26,
 DC_IRQ_SOURCE_GPIOPAD27,
 DC_IRQ_SOURCE_GPIOPAD28,
 DC_IRQ_SOURCE_GPIOPAD29,
 DC_IRQ_SOURCE_GPIOPAD30,

 DC_IRQ_SOURCE_DC1UNDERFLOW,
 DC_IRQ_SOURCE_DC2UNDERFLOW,
 DC_IRQ_SOURCE_DC3UNDERFLOW,
 DC_IRQ_SOURCE_DC4UNDERFLOW,
 DC_IRQ_SOURCE_DC5UNDERFLOW,
 DC_IRQ_SOURCE_DC6UNDERFLOW,

 DC_IRQ_SOURCE_DMCU_SCP,
 DC_IRQ_SOURCE_VBIOS_SW,

 DC_IRQ_SOURCE_VUPDATE1,
 DC_IRQ_SOURCE_VUPDATE2,
 DC_IRQ_SOURCE_VUPDATE3,
 DC_IRQ_SOURCE_VUPDATE4,
 DC_IRQ_SOURCE_VUPDATE5,
 DC_IRQ_SOURCE_VUPDATE6,

 DC_IRQ_SOURCE_VBLANK1,
 DC_IRQ_SOURCE_VBLANK2,
 DC_IRQ_SOURCE_VBLANK3,
 DC_IRQ_SOURCE_VBLANK4,
 DC_IRQ_SOURCE_VBLANK5,
 DC_IRQ_SOURCE_VBLANK6,

 DC_IRQ_SOURCE_DC1_VLINE0,
 DC_IRQ_SOURCE_DC2_VLINE0,
 DC_IRQ_SOURCE_DC3_VLINE0,
 DC_IRQ_SOURCE_DC4_VLINE0,
 DC_IRQ_SOURCE_DC5_VLINE0,
 DC_IRQ_SOURCE_DC6_VLINE0,

 DC_IRQ_SOURCE_DC1_VLINE1,
 DC_IRQ_SOURCE_DC2_VLINE1,
 DC_IRQ_SOURCE_DC3_VLINE1,
 DC_IRQ_SOURCE_DC4_VLINE1,
 DC_IRQ_SOURCE_DC5_VLINE1,
 DC_IRQ_SOURCE_DC6_VLINE1,
 DC_IRQ_SOURCE_DMCUB_OUTBOX,
 DC_IRQ_SOURCE_DMCUB_OUTBOX0,
 DC_IRQ_SOURCE_DMCUB_GENERAL_DATAOUT,

 DC_IRQ_SOURCE_DPCX_TX_PHYA,
 DC_IRQ_SOURCE_DPCX_TX_PHYB,
 DC_IRQ_SOURCE_DPCX_TX_PHYC,
 DC_IRQ_SOURCE_DPCX_TX_PHYD,
 DC_IRQ_SOURCE_DPCX_TX_PHYE,
 DC_IRQ_SOURCE_DPCX_TX_PHYF,

 DC_IRQ_SOURCE_DC1_VLINE2,
 DC_IRQ_SOURCE_DC2_VLINE2,
 DC_IRQ_SOURCE_DC3_VLINE2,
 DC_IRQ_SOURCE_DC4_VLINE2,
 DC_IRQ_SOURCE_DC5_VLINE2,
 DC_IRQ_SOURCE_DC6_VLINE2,

 DC_IRQ_SOURCE_DCI2C_RR_DDC1,
 DC_IRQ_SOURCE_DCI2C_RR_DDC2,
 DC_IRQ_SOURCE_DCI2C_RR_DDC3,
 DC_IRQ_SOURCE_DCI2C_RR_DDC4,
 DC_IRQ_SOURCE_DCI2C_RR_DDC5,
 DC_IRQ_SOURCE_DCI2C_RR_DDC6,

 DAL_IRQ_SOURCES_NUMBER
};
enum irq_type
{
 IRQ_TYPE_PFLIP = DC_IRQ_SOURCE_PFLIP1,
 IRQ_TYPE_VUPDATE = DC_IRQ_SOURCE_VUPDATE1,
 IRQ_TYPE_VBLANK = DC_IRQ_SOURCE_VBLANK1,
 IRQ_TYPE_VLINE0 = DC_IRQ_SOURCE_DC1_VLINE0,
 IRQ_TYPE_VLINE1 = DC_IRQ_SOURCE_DC1_VLINE1,
 IRQ_TYPE_VLINE2 = DC_IRQ_SOURCE_DC1_VLINE2,
 IRQ_TYPE_DCUNDERFLOW = DC_IRQ_SOURCE_DC1UNDERFLOW,
};
struct gpio_ddc_hw_info {
 bool hw_supported;
 uint32_t ddc_channel;
};
struct ddc {
 struct gpio *pin_data;
 struct gpio *pin_clock;
 struct gpio_ddc_hw_info hw_info;
 struct dc_context *ctx;
};
union ddc_wa {
 struct {
  uint32_t DP_SKIP_POWER_OFF:1;
  uint32_t DP_AUX_POWER_UP_WA_DELAY:1;
 } bits;
 uint32_t raw;
};
struct ddc_flags {
 uint8_t EDID_QUERY_DONE_ONCE:1;
 uint8_t IS_INTERNAL_DISPLAY:1;
 uint8_t FORCE_READ_REPEATED_START:1;
 uint8_t EDID_STRESS_READ:1;

};
enum ddc_transaction_type {
 DDC_TRANSACTION_TYPE_NONE = 0,
 DDC_TRANSACTION_TYPE_I2C,
 DDC_TRANSACTION_TYPE_I2C_OVER_AUX,
 DDC_TRANSACTION_TYPE_I2C_OVER_AUX_WITH_DEFER,
 DDC_TRANSACTION_TYPE_I2C_OVER_AUX_RETRY_DEFER
};
enum display_dongle_type {
 DISPLAY_DONGLE_NONE = 0,

 DISPLAY_DONGLE_DP_VGA_CONVERTER,
 DISPLAY_DONGLE_DP_DVI_CONVERTER,
 DISPLAY_DONGLE_DP_HDMI_CONVERTER,

 DISPLAY_DONGLE_DP_DVI_DONGLE,
 DISPLAY_DONGLE_DP_HDMI_DONGLE,

 DISPLAY_DONGLE_DP_HDMI_MISMATCHED_DONGLE,
};
struct ddc_service {
 struct ddc *ddc_pin;
 struct ddc_flags flags;
 union ddc_wa wa;
 enum ddc_transaction_type transaction_type;
 enum display_dongle_type dongle_type;
 struct dc_context *ctx;
 struct dc_link *link;

 uint32_t address;
 uint32_t edid_buf_len;
 uint8_t edid_buf[2048];
};
union dpcd_rev {
 struct {
  uint8_t MINOR:4;
  uint8_t MAJOR:4;
 } bits;
 uint8_t raw;
};
union sink_count {
 struct {
  uint8_t SINK_COUNT:6;
  uint8_t CPREADY:1;
  uint8_t RESERVED:1;
 } bits;
 uint8_t raw;
};
union dp_downstream_port_present {
 uint8_t byte;
 struct {
  uint8_t PORT_PRESENT:1;
  uint8_t PORT_TYPE:2;
  uint8_t FMT_CONVERSION:1;
  uint8_t DETAILED_CAPS:1;
  uint8_t RESERVED:3;
 } fields;
};
union dpcd_sink_ext_caps {
 struct {



  uint8_t sdr_aux_backlight_control : 1;
  uint8_t hdr_aux_backlight_control : 1;
  uint8_t reserved_1 : 2;
  uint8_t oled : 1;
  uint8_t reserved_2 : 1;
  uint8_t miniled : 1;
  uint8_t emission_output : 1;
 } bits;
 uint8_t raw;
};
enum signal_type {
 SIGNAL_TYPE_NONE = 0L,
 SIGNAL_TYPE_DVI_SINGLE_LINK = (1 << 0),
 SIGNAL_TYPE_DVI_DUAL_LINK = (1 << 1),
 SIGNAL_TYPE_HDMI_TYPE_A = (1 << 2),
 SIGNAL_TYPE_LVDS = (1 << 3),
 SIGNAL_TYPE_RGB = (1 << 4),
 SIGNAL_TYPE_DISPLAY_PORT = (1 << 5),
 SIGNAL_TYPE_DISPLAY_PORT_MST = (1 << 6),
 SIGNAL_TYPE_EDP = (1 << 7),
 SIGNAL_TYPE_VIRTUAL = (1 << 9),
};
struct rect {
 int x;
 int y;
 int width;
 int height;
};
enum pixel_format {

 PIXEL_FORMAT_UNINITIALIZED,
 PIXEL_FORMAT_INDEX8,
 PIXEL_FORMAT_RGB565,
 PIXEL_FORMAT_ARGB8888,
 PIXEL_FORMAT_ARGB2101010,
 PIXEL_FORMAT_ARGB2101010_XRBIAS,
 PIXEL_FORMAT_FP16,

 PIXEL_FORMAT_420BPP8,
 PIXEL_FORMAT_420BPP10,

 PIXEL_FORMAT_INVALID,

 PIXEL_FORMAT_GRPH_BEGIN = PIXEL_FORMAT_INDEX8,
 PIXEL_FORMAT_GRPH_END = PIXEL_FORMAT_FP16,
 PIXEL_FORMAT_VIDEO_BEGIN = PIXEL_FORMAT_420BPP8,
 PIXEL_FORMAT_VIDEO_END = PIXEL_FORMAT_420BPP10,
 PIXEL_FORMAT_UNKNOWN
};
enum dc_color_depth {
 COLOR_DEPTH_UNDEFINED,
 COLOR_DEPTH_666,
 COLOR_DEPTH_888,
 COLOR_DEPTH_101010,
 COLOR_DEPTH_121212,
 COLOR_DEPTH_141414,
 COLOR_DEPTH_161616,
 COLOR_DEPTH_999,
 COLOR_DEPTH_111111,
 COLOR_DEPTH_COUNT
};
enum dc_pixel_encoding {
 PIXEL_ENCODING_UNDEFINED,
 PIXEL_ENCODING_RGB,
 PIXEL_ENCODING_YCBCR422,
 PIXEL_ENCODING_YCBCR444,
 PIXEL_ENCODING_YCBCR420,
 PIXEL_ENCODING_COUNT
};
enum dc_aspect_ratio {
 ASPECT_RATIO_NO_DATA,
 ASPECT_RATIO_4_3,
 ASPECT_RATIO_16_9,
 ASPECT_RATIO_64_27,
 ASPECT_RATIO_256_135,
 ASPECT_RATIO_FUTURE
};
enum scanning_type {
 SCANNING_TYPE_NODATA = 0,
 SCANNING_TYPE_OVERSCAN,
 SCANNING_TYPE_UNDERSCAN,
 SCANNING_TYPE_FUTURE,
 SCANNING_TYPE_UNDEFINED
};
struct dc_crtc_timing_flags {
 uint32_t INTERLACE :1;
 uint32_t HSYNC_POSITIVE_POLARITY :1;

 uint32_t VSYNC_POSITIVE_POLARITY :1;


 uint32_t HORZ_COUNT_BY_TWO:1;

 uint32_t EXCLUSIVE_3D :1;


 uint32_t RIGHT_EYE_3D_POLARITY :1;

 uint32_t SUB_SAMPLE_3D :1;

 uint32_t USE_IN_3D_VIEW_ONLY :1;

 uint32_t STEREO_3D_PREFERENCE :1;

 uint32_t Y_ONLY :1;

 uint32_t YCBCR420 :1;
 uint32_t DTD_COUNTER :5;

 uint32_t FORCE_HDR :1;



 uint32_t LTE_340MCSC_SCRAMBLE:1;

 uint32_t DSC : 1;
 uint32_t VBLANK_SYNCHRONIZABLE: 1;
};
enum dc_timing_3d_format {
 TIMING_3D_FORMAT_NONE,
 TIMING_3D_FORMAT_FRAME_ALTERNATE,
 TIMING_3D_FORMAT_INBAND_FA,
 TIMING_3D_FORMAT_DP_HDMI_INBAND_FA,

 TIMING_3D_FORMAT_SIDEBAND_FA,
 TIMING_3D_FORMAT_HW_FRAME_PACKING,
 TIMING_3D_FORMAT_SW_FRAME_PACKING,
 TIMING_3D_FORMAT_ROW_INTERLEAVE,
 TIMING_3D_FORMAT_COLUMN_INTERLEAVE,
 TIMING_3D_FORMAT_PIXEL_INTERLEAVE,
 TIMING_3D_FORMAT_SIDE_BY_SIDE,
 TIMING_3D_FORMAT_TOP_AND_BOTTOM,
 TIMING_3D_FORMAT_SBS_SW_PACKED,

 TIMING_3D_FORMAT_TB_SW_PACKED,


 TIMING_3D_FORMAT_MAX,
};
struct dc_dsc_rc_params_override {
 int32_t rc_model_size;
 int32_t rc_buf_thresh[14];
 int32_t rc_minqp[15];
 int32_t rc_maxqp[15];
 int32_t rc_offset[15];

 int32_t rc_tgt_offset_hi;
 int32_t rc_tgt_offset_lo;
 int32_t rc_edge_factor;
 int32_t rc_quant_incr_limit0;
 int32_t rc_quant_incr_limit1;

 int32_t initial_fullness_offset;
 int32_t initial_delay;

 int32_t flatness_min_qp;
 int32_t flatness_max_qp;
 int32_t flatness_det_thresh;
};
struct dc_dsc_config {
 uint32_t num_slices_h;
 uint32_t num_slices_v;
 uint32_t bits_per_pixel;
 bool block_pred_enable;
 uint32_t linebuf_depth;
 uint32_t version_minor;
 bool ycbcr422_simple;
 int32_t rc_buffer_size;
 bool is_frl;
 bool is_dp;
 uint32_t mst_pbn;
 const struct dc_dsc_rc_params_override *rc_params_ovrd;
};
struct dc_crtc_timing {




 uint32_t h_total;




 uint32_t h_border_left;






 uint32_t h_addressable;




 uint32_t h_border_right;





 uint32_t h_front_porch;




 uint32_t h_sync_width;
 uint32_t v_total;




 uint32_t v_border_top;







 uint32_t v_addressable;




 uint32_t v_border_bottom;
 uint32_t v_front_porch;




 uint32_t v_sync_width;







 uint32_t pix_clk_100hz;

 uint32_t min_refresh_in_uhz;
 uint32_t max_refresh_in_uhz;

 uint32_t vic;
 uint32_t hdmi_vic;
 uint32_t rid;
 uint32_t fr_index;
 uint32_t frl_uncompressed_video_bandwidth_in_kbps;
 enum dc_timing_3d_format timing_3d_format;
 enum dc_color_depth display_color_depth;
 enum dc_pixel_encoding pixel_encoding;
 enum dc_aspect_ratio aspect_ratio;
 enum scanning_type scan_type;

 struct dc_crtc_timing_flags flags;
 uint32_t dsc_fixed_bits_per_pixel_x16;
 struct dc_dsc_config dsc_cfg;


 uint32_t expanded_hblank;
};
struct dc_crtc_timing_adjust {
 uint32_t v_total_min;
 uint32_t v_total_max;
 uint32_t v_total_mid;
 uint32_t v_total_mid_frame_num;
 uint32_t allow_otg_v_count_halt;
 uint8_t timing_adjust_pending;
};
enum vram_type {
 VIDEO_MEMORY_TYPE_GDDR5 = 2,
 VIDEO_MEMORY_TYPE_DDR3 = 3,
 VIDEO_MEMORY_TYPE_DDR4 = 4,
 VIDEO_MEMORY_TYPE_HBM = 5,
 VIDEO_MEMORY_TYPE_GDDR6 = 6,
};
struct dal_logger;
struct dc_bios;
enum dce_version {
 DCE_VERSION_UNKNOWN = (-1),
 DCE_VERSION_6_0,
 DCE_VERSION_6_1,
 DCE_VERSION_6_4,
 DCE_VERSION_8_0,
 DCE_VERSION_8_1,
 DCE_VERSION_8_3,
 DCE_VERSION_10_0,
 DCE_VERSION_11_0,
 DCE_VERSION_11_2,
 DCE_VERSION_11_22,
 DCE_VERSION_12_0,
 DCE_VERSION_12_1,
 DCE_VERSION_MAX,
 DCN_VERSION_1_0,
 DCN_VERSION_1_01,
 DCN_VERSION_2_0,
 DCN_VERSION_2_01,
 DCN_VERSION_2_1,
 DCN_VERSION_3_0,
 DCN_VERSION_3_01,
 DCN_VERSION_3_02,
 DCN_VERSION_3_03,
 DCN_VERSION_3_1,
 DCN_VERSION_3_14,
 DCN_VERSION_3_15,
 DCN_VERSION_3_16,
 DCN_VERSION_3_2,
 DCN_VERSION_3_21,
 DCN_VERSION_3_5,
 DCN_VERSION_3_51,
 DCN_VERSION_3_6,
 DCN_VERSION_4_01,
 DCN_VERSION_MAX
};
enum controller_id {
 CONTROLLER_ID_UNDEFINED = 0,
 CONTROLLER_ID_D0,
 CONTROLLER_ID_D1,
 CONTROLLER_ID_D2,
 CONTROLLER_ID_D3,
 CONTROLLER_ID_D4,
 CONTROLLER_ID_D5,
 CONTROLLER_ID_UNDERLAY0,
 CONTROLLER_ID_MAX = CONTROLLER_ID_UNDERLAY0
};
enum encoder_id {
 ENCODER_ID_UNKNOWN = 0,


 ENCODER_ID_INTERNAL_LVDS,
 ENCODER_ID_INTERNAL_TMDS1,
 ENCODER_ID_INTERNAL_TMDS2,
 ENCODER_ID_INTERNAL_DAC1,
 ENCODER_ID_INTERNAL_DAC2,


 ENCODER_ID_INTERNAL_LVTM1,
 ENCODER_ID_INTERNAL_HDMI,


 ENCODER_ID_INTERNAL_KLDSCP_TMDS1,
 ENCODER_ID_INTERNAL_KLDSCP_DAC1,
 ENCODER_ID_INTERNAL_KLDSCP_DAC2,

 ENCODER_ID_EXTERNAL_MVPU_FPGA,
 ENCODER_ID_INTERNAL_DDI,
 ENCODER_ID_INTERNAL_UNIPHY,
 ENCODER_ID_INTERNAL_KLDSCP_LVTMA,
 ENCODER_ID_INTERNAL_UNIPHY1,
 ENCODER_ID_INTERNAL_UNIPHY2,
 ENCODER_ID_EXTERNAL_NUTMEG,
 ENCODER_ID_EXTERNAL_TRAVIS,

 ENCODER_ID_INTERNAL_WIRELESS,
 ENCODER_ID_INTERNAL_UNIPHY3,
 ENCODER_ID_INTERNAL_VIRTUAL,
};
enum connector_id {
 CONNECTOR_ID_UNKNOWN = 0,
 CONNECTOR_ID_SINGLE_LINK_DVII = 1,
 CONNECTOR_ID_DUAL_LINK_DVII = 2,
 CONNECTOR_ID_SINGLE_LINK_DVID = 3,
 CONNECTOR_ID_DUAL_LINK_DVID = 4,
 CONNECTOR_ID_VGA = 5,
 CONNECTOR_ID_HDMI_TYPE_A = 12,
 CONNECTOR_ID_LVDS = 14,
 CONNECTOR_ID_PCIE = 16,
 CONNECTOR_ID_HARDCODE_DVI = 18,
 CONNECTOR_ID_DISPLAY_PORT = 19,
 CONNECTOR_ID_EDP = 20,
 CONNECTOR_ID_MXM = 21,
 CONNECTOR_ID_WIRELESS = 22,
 CONNECTOR_ID_MIRACAST = 23,
 CONNECTOR_ID_USBC = 24,

 CONNECTOR_ID_VIRTUAL = 100
};
enum dal_device_type {
 DEVICE_TYPE_UNKNOWN = 0,
 DEVICE_TYPE_LCD,
 DEVICE_TYPE_CRT,
 DEVICE_TYPE_DFP,
 DEVICE_TYPE_CV,
 DEVICE_TYPE_TV,
 DEVICE_TYPE_CF,
 DEVICE_TYPE_WIRELESS
};
struct device_id {
 enum dal_device_type device_type:16;
 uint32_t enum_id:16;
 uint16_t raw_device_tag;
};
union ddi_channel_mapping {
 struct mapping {
  uint8_t lane0:2;
  uint8_t lane1:2;
  uint8_t lane2:2;
  uint8_t lane3:2;
 } mapping;
 uint8_t raw;
};
struct dc_link;
struct cp_psp_stream_config {
 uint8_t otg_inst;
 uint8_t dig_be;
 uint8_t dig_fe;
 uint8_t link_enc_idx;
 uint8_t stream_enc_idx;
 uint8_t dio_output_idx;
 uint8_t phy_idx;
 uint8_t assr_enabled;
 uint8_t mst_enabled;
 uint8_t dp2_enabled;
 uint8_t usb4_enabled;
 void *dm_stream_ctx;
 bool dpms_off;
};
struct cp_psp_funcs {
 bool (*enable_assr)(void *handle, struct dc_link *link);
 void (*update_stream_config)(void *handle, struct cp_psp_stream_config *config);
};
struct cp_psp {
 void *handle;
 struct cp_psp_funcs funcs;
};
struct dc_stream_state;
struct dc_link;
struct dc_sink;
struct dc_dmub_srv;
enum dce_environment {
 DCE_ENV_PRODUCTION_DRV = 0,



 DCE_ENV_FPGA_MAXIMUS,


 DCE_ENV_DIAG,




 DCE_ENV_VIRTUAL_HW
};
struct dc_perf_trace {
 unsigned long read_count;
 unsigned long write_count;
 unsigned long last_entry_read;
 unsigned long last_entry_write;
};
struct hw_asic_id {
 uint32_t chip_id;
 uint32_t chip_family;
 uint32_t pci_revision_id;
 uint32_t hw_internal_rev;
 uint32_t vram_type;
 uint32_t vram_width;
 uint32_t feature_flags;
 uint32_t fake_paths_num;
 void *atombios_base_address;
};
struct dc_context {
 struct dc *dc;

 void *driver_context;
 struct dal_logger *logger;
 struct dc_perf_trace *perf_trace;
 void *cgs_device;

 enum dce_environment dce_environment;
 struct hw_asic_id asic_id;




 enum dce_version dce_version;
 struct dc_bios *dc_bios;
 bool created_bios;
 struct gpio_service *gpio_service;
 uint32_t dc_sink_id_count;
 uint32_t dc_stream_id_count;
 uint32_t dc_edp_id_count;
 uint64_t fbc_gpu_addr;
 struct dc_dmub_srv *dmub_srv;
 struct cp_psp cp_psp;
 uint32_t *dcn_reg_offsets;
 uint32_t *nbio_reg_offsets;
 uint32_t *clk_reg_offsets;
};
struct crc_window {
 struct rect rect;
 bool enable;
};
enum amd_pp_display_config_type {
 AMD_PP_DisplayConfigType_None = 0,
 AMD_PP_DisplayConfigType_DP54 ,
 AMD_PP_DisplayConfigType_DP432 ,
 AMD_PP_DisplayConfigType_DP324 ,
 AMD_PP_DisplayConfigType_DP27,
 AMD_PP_DisplayConfigType_DP243,
 AMD_PP_DisplayConfigType_DP216,
 AMD_PP_DisplayConfigType_DP162,
 AMD_PP_DisplayConfigType_HDMI6G,
 AMD_PP_DisplayConfigType_HDMI297,
 AMD_PP_DisplayConfigType_HDMI162,
 AMD_PP_DisplayConfigType_LVDS,
 AMD_PP_DisplayConfigType_DVI,
 AMD_PP_DisplayConfigType_WIRELESS,
 AMD_PP_DisplayConfigType_VGA
};
struct single_display_configuration {
 uint32_t controller_index;
 uint32_t controller_id;
 uint32_t signal_type;
 uint32_t display_state;

 uint8_t primary_transmitter_phyi_d;

 uint8_t primary_transmitter_active_lanemap;

 uint8_t secondary_transmitter_phy_id;

 uint8_t secondary_transmitter_active_lanemap;

 uint32_t config_flags;
 uint32_t display_type;
 uint32_t view_resolution_cx;
 uint32_t view_resolution_cy;
 enum amd_pp_display_config_type displayconfigtype;
 uint32_t vertical_refresh;
 uint32_t pixel_clock;
};
struct amd_pp_display_configuration {
 bool nb_pstate_switch_disable;
 bool cpu_cc6_disable;
 bool cpu_pstate_disable;
 uint32_t cpu_pstate_separation_time;

 uint32_t num_display;
 uint32_t num_path_including_non_display;
 uint32_t crossfire_display_index;
 uint32_t min_mem_set_clock;
 uint32_t min_core_set_clock;

 uint32_t min_bus_bandwidth;

 uint32_t min_core_set_clock_in_sr;

 struct single_display_configuration displays[32];

 uint32_t vrefresh;

 uint32_t min_vblank_time;
 bool multi_monitor_in_sync;


 uint32_t crtc_index;

 uint32_t line_time_in_us;
 bool invalid_vblank_time;

 uint32_t display_clk;





 uint32_t dce_tolerable_mclk_in_active_latency;
 uint32_t min_dcef_set_clk;
 uint32_t min_dcef_deep_sleep_set_clk;
};
struct amd_pp_simple_clock_info {
 uint32_t engine_max_clock;
 uint32_t memory_max_clock;
 uint32_t level;
};
enum PP_DAL_POWERLEVEL {
 PP_DAL_POWERLEVEL_INVALID = 0,
 PP_DAL_POWERLEVEL_ULTRALOW,
 PP_DAL_POWERLEVEL_LOW,
 PP_DAL_POWERLEVEL_NOMINAL,
 PP_DAL_POWERLEVEL_PERFORMANCE,

 PP_DAL_POWERLEVEL_0 = PP_DAL_POWERLEVEL_ULTRALOW,
 PP_DAL_POWERLEVEL_1 = PP_DAL_POWERLEVEL_LOW,
 PP_DAL_POWERLEVEL_2 = PP_DAL_POWERLEVEL_NOMINAL,
 PP_DAL_POWERLEVEL_3 = PP_DAL_POWERLEVEL_PERFORMANCE,
 PP_DAL_POWERLEVEL_4 = PP_DAL_POWERLEVEL_3+1,
 PP_DAL_POWERLEVEL_5 = PP_DAL_POWERLEVEL_4+1,
 PP_DAL_POWERLEVEL_6 = PP_DAL_POWERLEVEL_5+1,
 PP_DAL_POWERLEVEL_7 = PP_DAL_POWERLEVEL_6+1,
};
struct amd_pp_clock_info {
 uint32_t min_engine_clock;
 uint32_t max_engine_clock;
 uint32_t min_memory_clock;
 uint32_t max_memory_clock;
 uint32_t min_bus_bandwidth;
 uint32_t max_bus_bandwidth;
 uint32_t max_engine_clock_in_sr;
 uint32_t min_engine_clock_in_sr;
 enum PP_DAL_POWERLEVEL max_clocks_state;
};
enum amd_pp_clock_type {
 amd_pp_disp_clock = 1,
 amd_pp_sys_clock,
 amd_pp_mem_clock,
 amd_pp_dcef_clock,
 amd_pp_soc_clock,
 amd_pp_pixel_clock,
 amd_pp_phy_clock,
 amd_pp_dcf_clock,
 amd_pp_dpp_clock,
 amd_pp_f_clock = amd_pp_dcef_clock,
};
struct amd_pp_clocks {
 uint32_t count;
 uint32_t clock[16];
 uint32_t latency[16];
};
struct pp_clock_with_latency {
 uint32_t clocks_in_khz;
 uint32_t latency_in_us;
};
struct pp_clock_levels_with_latency {
 uint32_t num_levels;
 struct pp_clock_with_latency data[16];
};
struct pp_clock_with_voltage {
 uint32_t clocks_in_khz;
 uint32_t voltage_in_mv;
};
struct pp_clock_levels_with_voltage {
 uint32_t num_levels;
 struct pp_clock_with_voltage data[16];
};
struct pp_display_clock_request {
 enum amd_pp_clock_type clock_type;
 uint32_t clock_freq_in_khz;
};
enum smu_temp_metric_type {
 SMU_TEMP_METRIC_BASEBOARD,
 SMU_TEMP_METRIC_GPUBOARD,
 SMU_TEMP_METRIC_MAX,
};
struct amd_vce_state {

 u32 evclk;
 u32 ecclk;

 u32 sclk;
 u32 mclk;
 u8 clk_idx;
 u8 pstate;
};
enum amd_dpm_forced_level {
 AMD_DPM_FORCED_LEVEL_AUTO = 0x1,
 AMD_DPM_FORCED_LEVEL_MANUAL = 0x2,
 AMD_DPM_FORCED_LEVEL_LOW = 0x4,
 AMD_DPM_FORCED_LEVEL_HIGH = 0x8,
 AMD_DPM_FORCED_LEVEL_PROFILE_STANDARD = 0x10,
 AMD_DPM_FORCED_LEVEL_PROFILE_MIN_SCLK = 0x20,
 AMD_DPM_FORCED_LEVEL_PROFILE_MIN_MCLK = 0x40,
 AMD_DPM_FORCED_LEVEL_PROFILE_PEAK = 0x80,
 AMD_DPM_FORCED_LEVEL_PROFILE_EXIT = 0x100,
 AMD_DPM_FORCED_LEVEL_PERF_DETERMINISM = 0x200,
};
enum amd_pm_state_type {

 POWER_STATE_TYPE_DEFAULT,
 POWER_STATE_TYPE_POWERSAVE,

 POWER_STATE_TYPE_BATTERY,
 POWER_STATE_TYPE_BALANCED,
 POWER_STATE_TYPE_PERFORMANCE,

 POWER_STATE_TYPE_INTERNAL_UVD,
 POWER_STATE_TYPE_INTERNAL_UVD_SD,
 POWER_STATE_TYPE_INTERNAL_UVD_HD,
 POWER_STATE_TYPE_INTERNAL_UVD_HD2,
 POWER_STATE_TYPE_INTERNAL_UVD_MVC,
 POWER_STATE_TYPE_INTERNAL_BOOT,
 POWER_STATE_TYPE_INTERNAL_THERMAL,
 POWER_STATE_TYPE_INTERNAL_ACPI,
 POWER_STATE_TYPE_INTERNAL_ULV,
 POWER_STATE_TYPE_INTERNAL_3DPERF,
};
enum amd_vce_level {
 AMD_VCE_LEVEL_AC_ALL = 0,
 AMD_VCE_LEVEL_DC_EE = 1,
 AMD_VCE_LEVEL_DC_LL_LOW = 2,
 AMD_VCE_LEVEL_DC_LL_HIGH = 3,
 AMD_VCE_LEVEL_DC_GP_LOW = 4,
 AMD_VCE_LEVEL_DC_GP_HIGH = 5,
};
enum pp_clock_type {
 PP_SCLK,
 PP_MCLK,
 PP_PCIE,
 PP_SOCCLK,
 PP_FCLK,
 PP_DCEFCLK,
 PP_VCLK,
 PP_VCLK1,
 PP_DCLK,
 PP_DCLK1,
 PP_ISPICLK,
 PP_ISPXCLK,
 OD_SCLK,
 OD_MCLK,
 OD_VDDC_CURVE,
 OD_RANGE,
 OD_VDDGFX_OFFSET,
 OD_CCLK,
 OD_FAN_CURVE,
 OD_ACOUSTIC_LIMIT,
 OD_ACOUSTIC_TARGET,
 OD_FAN_TARGET_TEMPERATURE,
 OD_FAN_MINIMUM_PWM,
 OD_FAN_ZERO_RPM_ENABLE,
 OD_FAN_ZERO_RPM_STOP_TEMP,
};
enum amd_pp_task {
 AMD_PP_TASK_DISPLAY_CONFIG_CHANGE,
 AMD_PP_TASK_ENABLE_USER_STATE,
 AMD_PP_TASK_READJUST_POWER_STATE,
 AMD_PP_TASK_COMPLETE_INIT,
 AMD_PP_TASK_MAX
};
enum PP_SMC_POWER_PROFILE {
 PP_SMC_POWER_PROFILE_UNKNOWN = -1,
 PP_SMC_POWER_PROFILE_BOOTUP_DEFAULT = 0x0,
 PP_SMC_POWER_PROFILE_FULLSCREEN3D = 0x1,
 PP_SMC_POWER_PROFILE_POWERSAVING = 0x2,
 PP_SMC_POWER_PROFILE_VIDEO = 0x3,
 PP_SMC_POWER_PROFILE_VR = 0x4,
 PP_SMC_POWER_PROFILE_COMPUTE = 0x5,
 PP_SMC_POWER_PROFILE_CUSTOM = 0x6,
 PP_SMC_POWER_PROFILE_WINDOW3D = 0x7,
 PP_SMC_POWER_PROFILE_CAPPED = 0x8,
 PP_SMC_POWER_PROFILE_UNCAPPED = 0x9,
 PP_SMC_POWER_PROFILE_COUNT,
};
enum PP_OD_DPM_TABLE_COMMAND {
 PP_OD_EDIT_SCLK_VDDC_TABLE,
 PP_OD_EDIT_MCLK_VDDC_TABLE,
 PP_OD_EDIT_CCLK_VDDC_TABLE,
 PP_OD_EDIT_VDDC_CURVE,
 PP_OD_RESTORE_DEFAULT_TABLE,
 PP_OD_COMMIT_DPM_TABLE,
 PP_OD_EDIT_VDDGFX_OFFSET,
 PP_OD_EDIT_FAN_CURVE,
 PP_OD_EDIT_ACOUSTIC_LIMIT,
 PP_OD_EDIT_ACOUSTIC_TARGET,
 PP_OD_EDIT_FAN_TARGET_TEMPERATURE,
 PP_OD_EDIT_FAN_MINIMUM_PWM,
 PP_OD_EDIT_FAN_ZERO_RPM_ENABLE,
 PP_OD_EDIT_FAN_ZERO_RPM_STOP_TEMP,
};
struct pp_states_info {
 uint32_t nums;
 uint32_t states[16];
};
enum pp_mp1_state {
 PP_MP1_STATE_NONE,
 PP_MP1_STATE_SHUTDOWN,
 PP_MP1_STATE_UNLOAD,
 PP_MP1_STATE_RESET,
 PP_MP1_STATE_FLR,
};
enum pp_df_cstate {
 DF_CSTATE_DISALLOW = 0,
 DF_CSTATE_ALLOW,
};
enum pp_power_limit_level {
 PP_PWR_LIMIT_MIN = -1,
 PP_PWR_LIMIT_CURRENT,
 PP_PWR_LIMIT_DEFAULT,
 PP_PWR_LIMIT_MAX,
};
enum pp_power_type {
 PP_PWR_TYPE_SUSTAINED,
 PP_PWR_TYPE_FAST,
};
struct seq_file;
enum amd_pp_clock_type;
struct amd_pp_simple_clock_info;
struct amd_pp_display_configuration;
struct amd_pp_clock_info;
struct pp_display_clock_request;
struct pp_clock_levels_with_voltage;
struct pp_clock_levels_with_latency;
struct amd_pp_clocks;
struct pp_smu_wm_range_sets;
struct pp_smu_nv_clock_table;
struct dpm_clocks;
struct amd_pm_funcs {

 int (*pre_set_power_state)(void *handle);
 int (*set_power_state)(void *handle);
 void (*post_set_power_state)(void *handle);
 void (*display_configuration_changed)(void *handle);
 void (*print_power_state)(void *handle, void *ps);
 bool (*vblank_too_short)(void *handle);
 void (*enable_bapm)(void *handle, bool enable);
 int (*check_state_equal)(void *handle,
    void *cps,
    void *rps,
    bool *equal);

 int (*set_fan_control_mode)(void *handle, u32 mode);
 int (*get_fan_control_mode)(void *handle, u32 *fan_mode);
 int (*set_fan_speed_pwm)(void *handle, u32 speed);
 int (*get_fan_speed_pwm)(void *handle, u32 *speed);
 int (*force_clock_level)(void *handle, enum pp_clock_type type, uint32_t mask);
 int (*print_clock_levels)(void *handle, enum pp_clock_type type, char *buf);
 int (*emit_clock_levels)(void *handle, enum pp_clock_type type, char *buf, int *offset);
 int (*force_performance_level)(void *handle, enum amd_dpm_forced_level level);
 int (*get_sclk_od)(void *handle);
 int (*set_sclk_od)(void *handle, uint32_t value);
 int (*get_mclk_od)(void *handle);
 int (*set_mclk_od)(void *handle, uint32_t value);
 int (*read_sensor)(void *handle, int idx, void *value, int *size);
 int (*get_apu_thermal_limit)(void *handle, uint32_t *limit);
 int (*set_apu_thermal_limit)(void *handle, uint32_t limit);
 enum amd_dpm_forced_level (*get_performance_level)(void *handle);
 enum amd_pm_state_type (*get_current_power_state)(void *handle);
 int (*get_fan_speed_rpm)(void *handle, uint32_t *rpm);
 int (*set_fan_speed_rpm)(void *handle, uint32_t rpm);
 int (*get_pp_num_states)(void *handle, struct pp_states_info *data);
 int (*get_pp_table)(void *handle, char **table);
 int (*set_pp_table)(void *handle, const char *buf, size_t size);
 void (*debugfs_print_current_performance_level)(void *handle, struct seq_file *m);
 int (*switch_power_profile)(void *handle, enum PP_SMC_POWER_PROFILE type, bool en);
 int (*pause_power_profile)(void *handle, bool pause);

 struct amd_vce_state *(*get_vce_clock_state)(void *handle, u32 idx);
 int (*dispatch_tasks)(void *handle, enum amd_pp_task task_id,
   enum amd_pm_state_type *user_state);
 int (*load_firmware)(void *handle);
 int (*wait_for_fw_loading_complete)(void *handle);
 int (*set_powergating_by_smu)(void *handle,
    uint32_t block_type,
    bool gate,
    int inst);
 int (*set_clockgating_by_smu)(void *handle, uint32_t msg_id);
 int (*set_power_limit)(void *handle, uint32_t n);
 int (*get_power_limit)(void *handle, uint32_t *limit,
   enum pp_power_limit_level pp_limit_level,
   enum pp_power_type power_type);
 int (*get_power_profile_mode)(void *handle, char *buf);
 int (*set_power_profile_mode)(void *handle, long *input, uint32_t size);
 int (*set_fine_grain_clk_vol)(void *handle, uint32_t type, long *input, uint32_t size);
 int (*odn_edit_dpm_table)(void *handle, enum PP_OD_DPM_TABLE_COMMAND type,
      long *input, uint32_t size);
 int (*set_mp1_state)(void *handle, enum pp_mp1_state mp1_state);
 int (*smu_i2c_bus_access)(void *handle, bool acquire);
 int (*gfx_state_change_set)(void *handle, uint32_t state);

 u32 (*get_sclk)(void *handle, bool low);
 u32 (*get_mclk)(void *handle, bool low);
 int (*display_configuration_change)(void *handle,
  const struct amd_pp_display_configuration *input);
 int (*get_display_power_level)(void *handle,
  struct amd_pp_simple_clock_info *output);
 int (*get_current_clocks)(void *handle,
  struct amd_pp_clock_info *clocks);
 int (*get_clock_by_type)(void *handle,
  enum amd_pp_clock_type type,
  struct amd_pp_clocks *clocks);
 int (*get_clock_by_type_with_latency)(void *handle,
  enum amd_pp_clock_type type,
  struct pp_clock_levels_with_latency *clocks);
 int (*get_clock_by_type_with_voltage)(void *handle,
  enum amd_pp_clock_type type,
  struct pp_clock_levels_with_voltage *clocks);
 int (*set_watermarks_for_clocks_ranges)(void *handle,
      void *clock_ranges);
 int (*display_clock_voltage_request)(void *handle,
    struct pp_display_clock_request *clock);
 int (*get_display_mode_validation_clocks)(void *handle,
  struct amd_pp_simple_clock_info *clocks);
 int (*notify_smu_enable_pwe)(void *handle);
 int (*enable_mgpu_fan_boost)(void *handle);
 int (*set_active_display_count)(void *handle, uint32_t count);
 int (*set_hard_min_dcefclk_by_freq)(void *handle, uint32_t clock);
 int (*set_hard_min_fclk_by_freq)(void *handle, uint32_t clock);
 int (*set_min_deep_sleep_dcefclk)(void *handle, uint32_t clock);
 int (*get_asic_baco_capability)(void *handle);
 int (*get_asic_baco_state)(void *handle, int *state);
 int (*set_asic_baco_state)(void *handle, int state);
 int (*get_ppfeature_status)(void *handle, char *buf);
 int (*set_ppfeature_status)(void *handle, uint64_t ppfeature_masks);
 int (*asic_reset_mode_2)(void *handle);
 int (*asic_reset_enable_gfx_features)(void *handle);
 int (*set_df_cstate)(void *handle, enum pp_df_cstate state);
 int (*set_xgmi_pstate)(void *handle, uint32_t pstate);
 ssize_t (*get_gpu_metrics)(void *handle, void **table);
 ssize_t (*get_temp_metrics)(void *handle, enum smu_temp_metric_type type, void *table);
 bool (*temp_metrics_is_supported)(void *handle, enum smu_temp_metric_type type);
 ssize_t (*get_xcp_metrics)(void *handle, int xcp_id, void *table);
 ssize_t (*get_pm_metrics)(void *handle, void *pmmetrics, size_t size);
 int (*set_watermarks_for_clock_ranges)(void *handle,
            struct pp_smu_wm_range_sets *ranges);
 int (*display_disable_memory_clock_switch)(void *handle,
         bool disable_memory_clock_switch);
 int (*get_max_sustainable_clocks_by_dc)(void *handle,
      struct pp_smu_nv_clock_table *max_clocks);
 int (*get_uclk_dpm_states)(void *handle,
       unsigned int *clock_values_in_khz,
       unsigned int *num_states);
 int (*get_dpm_clock_table)(void *handle,
       struct dpm_clocks *clock_table);
 int (*get_smu_prv_buf_details)(void *handle, void **addr, size_t *size);
 void (*pm_compute_clocks)(void *handle);
 int (*notify_rlc_state)(void *handle, bool en);
};
enum drm_mode_status {
 MODE_OK = 0,
 MODE_HSYNC,
 MODE_VSYNC,
 MODE_H_ILLEGAL,
 MODE_V_ILLEGAL,
 MODE_BAD_WIDTH,
 MODE_NOMODE,
 MODE_NO_INTERLACE,
 MODE_NO_DBLESCAN,
 MODE_NO_VSCAN,
 MODE_MEM,
 MODE_VIRTUAL_X,
 MODE_VIRTUAL_Y,
 MODE_MEM_VIRT,
 MODE_NOCLOCK,
 MODE_CLOCK_HIGH,
 MODE_CLOCK_LOW,
 MODE_CLOCK_RANGE,
 MODE_BAD_HVALUE,
 MODE_BAD_VVALUE,
 MODE_BAD_VSCAN,
 MODE_HSYNC_NARROW,
 MODE_HSYNC_WIDE,
 MODE_HBLANK_NARROW,
 MODE_HBLANK_WIDE,
 MODE_VSYNC_NARROW,
 MODE_VSYNC_WIDE,
 MODE_VBLANK_NARROW,
 MODE_VBLANK_WIDE,
 MODE_PANEL,
 MODE_INTERLACE_WIDTH,
 MODE_ONE_WIDTH,
 MODE_ONE_HEIGHT,
 MODE_ONE_SIZE,
 MODE_NO_REDUCED,
 MODE_NO_STEREO,
 MODE_NO_420,
 MODE_STALE = -3,
 MODE_BAD = -2,
 MODE_ERROR = -1
};
struct drm_display_mode {





 int clock;
 u16 hdisplay;
 u16 hsync_start;
 u16 hsync_end;
 u16 htotal;
 u16 hskew;
 u16 vdisplay;
 u16 vsync_start;
 u16 vsync_end;
 u16 vtotal;
 u16 vscan;
 u32 flags;
 int crtc_clock;
 u16 crtc_hdisplay;
 u16 crtc_hblank_start;
 u16 crtc_hblank_end;
 u16 crtc_hsync_start;
 u16 crtc_hsync_end;
 u16 crtc_htotal;
 u16 crtc_hskew;
 u16 crtc_vdisplay;
 u16 crtc_vblank_start;
 u16 crtc_vblank_end;
 u16 crtc_vsync_start;
 u16 crtc_vsync_end;
 u16 crtc_vtotal;







 u16 width_mm;







 u16 height_mm;
 u8 type;
 bool expose_to_userspace;






 struct list_head head;






 char name[32];







 enum drm_mode_status status;






 enum hdmi_picture_aspect picture_aspect_ratio;

};
struct drm_connector;
struct drm_cmdline_mode;
enum kmsg_dump_reason {
 KMSG_DUMP_UNDEF,
 KMSG_DUMP_PANIC,
 KMSG_DUMP_OOPS,
 KMSG_DUMP_EMERG,
 KMSG_DUMP_SHUTDOWN,
 KMSG_DUMP_MAX
};
struct kmsg_dump_detail {
 enum kmsg_dump_reason reason;
 const char *description;
};
struct kmsg_dumper {
 struct list_head list;
 void (*dump)(struct kmsg_dumper *dumper, struct kmsg_dump_detail *detail);
 enum kmsg_dump_reason max_reason;
 bool registered;
};
struct drm_crtc;
struct drm_plane;
enum drm_color_encoding {
 DRM_COLOR_YCBCR_BT601,
 DRM_COLOR_YCBCR_BT709,
 DRM_COLOR_YCBCR_BT2020,
 DRM_COLOR_ENCODING_MAX,
};
enum drm_color_range {
 DRM_COLOR_YCBCR_LIMITED_RANGE,
 DRM_COLOR_YCBCR_FULL_RANGE,
 DRM_COLOR_RANGE_MAX,
};
struct drm_rect {
 int x1, y1, x2, y2;
};
struct drm_crtc;
struct drm_printer;
struct drm_modeset_acquire_ctx;
enum drm_scaling_filter {
 DRM_SCALING_FILTER_DEFAULT,
 DRM_SCALING_FILTER_NEAREST_NEIGHBOR,
};
struct drm_plane_state {

 struct drm_plane *plane;







 struct drm_crtc *crtc;







 struct drm_framebuffer *fb;
 struct dma_fence *fence;
 int32_t crtc_x;






 int32_t crtc_y;



 uint32_t crtc_w, crtc_h;





 uint32_t src_x;




 uint32_t src_y;


 uint32_t src_h, src_w;



 int32_t hotspot_x, hotspot_y;







 u16 alpha;







 uint16_t pixel_blend_mode;






 unsigned int rotation;
 unsigned int zpos;
 unsigned int normalized_zpos;






 enum drm_color_encoding color_encoding;






 enum drm_color_range color_range;
 struct drm_property_blob *fb_damage_clips;
 bool ignore_damage_clips;
 struct drm_rect src, dst;







 bool visible;






 enum drm_scaling_filter scaling_filter;







 struct drm_crtc_commit *commit;


 struct drm_atomic_state *state;






 bool color_mgmt_changed : 1;
};
struct drm_plane_funcs {
 int (*update_plane)(struct drm_plane *plane,
       struct drm_crtc *crtc, struct drm_framebuffer *fb,
       int crtc_x, int crtc_y,
       unsigned int crtc_w, unsigned int crtc_h,
       uint32_t src_x, uint32_t src_y,
       uint32_t src_w, uint32_t src_h,
       struct drm_modeset_acquire_ctx *ctx);
 int (*disable_plane)(struct drm_plane *plane,
        struct drm_modeset_acquire_ctx *ctx);
 void (*destroy)(struct drm_plane *plane);
 void (*reset)(struct drm_plane *plane);
 int (*set_property)(struct drm_plane *plane,
       struct drm_property *property, uint64_t val);
 struct drm_plane_state *(*atomic_duplicate_state)(struct drm_plane *plane);
 void (*atomic_destroy_state)(struct drm_plane *plane,
         struct drm_plane_state *state);
 int (*atomic_set_property)(struct drm_plane *plane,
       struct drm_plane_state *state,
       struct drm_property *property,
       uint64_t val);
 int (*atomic_get_property)(struct drm_plane *plane,
       const struct drm_plane_state *state,
       struct drm_property *property,
       uint64_t *val);
 int (*late_register)(struct drm_plane *plane);
 void (*early_unregister)(struct drm_plane *plane);
 void (*atomic_print_state)(struct drm_printer *p,
       const struct drm_plane_state *state);
 bool (*format_mod_supported)(struct drm_plane *plane, uint32_t format,
         uint64_t modifier);
 bool (*format_mod_supported_async)(struct drm_plane *plane,
        u32 format, u64 modifier);

};
enum drm_plane_type {






 DRM_PLANE_TYPE_OVERLAY,
 DRM_PLANE_TYPE_PRIMARY,
 DRM_PLANE_TYPE_CURSOR,
};
struct drm_plane {

 struct drm_device *dev;
 struct list_head head;


 char *name;
 struct drm_modeset_lock mutex;


 struct drm_mode_object base;





 uint32_t possible_crtcs;

 uint32_t *format_types;

 unsigned int format_count;




 bool format_default;


 uint64_t *modifiers;

 unsigned int modifier_count;
 struct drm_crtc *crtc;
 struct drm_framebuffer *fb;







 struct drm_framebuffer *old_fb;


 const struct drm_plane_funcs *funcs;


 struct drm_object_properties properties;


 enum drm_plane_type type;





 unsigned index;


 const struct drm_plane_helper_funcs *helper_private;
 struct drm_plane_state *state;






 struct drm_property *alpha_property;





 struct drm_property *zpos_property;





 struct drm_property *rotation_property;







 struct drm_property *blend_mode_property;
 struct drm_property *color_encoding_property;







 struct drm_property *color_range_property;





 struct drm_property *scaling_filter_property;




 struct drm_property *hotspot_x_property;




 struct drm_property *hotspot_y_property;




 struct kmsg_dumper kmsg_panic;
};
struct drm_crtc;
struct drm_crtc_crc_entry {
 bool has_frame_counter;
 uint32_t frame;
 uint32_t crcs[10];
};
struct drm_crtc_crc {
 spinlock_t lock;
 const char *source;
 bool opened, overflow;
 struct drm_crtc_crc_entry *entries;
 int head, tail;
 size_t values_cnt;
 wait_queue_head_t wq;
};
struct drm_connector;
struct drm_device;
struct drm_framebuffer;
struct drm_mode_set;
struct drm_file;
struct drm_printer;
struct drm_self_refresh_data;
struct device_node;
struct drm_crtc;
struct drm_pending_vblank_event;
struct drm_plane;
struct drm_atomic_state;
struct drm_crtc_helper_funcs;
struct drm_plane_helper_funcs;
struct drm_crtc_state {

 struct drm_crtc *crtc;






 bool enable;
 bool active;





 bool planes_changed : 1;
 bool mode_changed : 1;






 bool active_changed : 1;
 bool connectors_changed : 1;





 bool zpos_changed : 1;





 bool color_mgmt_changed : 1;
 bool no_vblank : 1;





 u32 plane_mask;





 u32 connector_mask;





 u32 encoder_mask;
 struct drm_display_mode adjusted_mode;
 struct drm_display_mode mode;





 struct drm_property_blob *mode_blob;
 struct drm_property_blob *degamma_lut;







 struct drm_property_blob *ctm;
 struct drm_property_blob *gamma_lut;







 u32 target_vblank;







 bool async_flip;
 bool vrr_enabled;
 bool self_refresh_active;






 enum drm_scaling_filter scaling_filter;
 struct drm_pending_vblank_event *event;
 struct drm_crtc_commit *commit;


 struct drm_atomic_state *state;
};
struct drm_crtc_funcs {
 void (*reset)(struct drm_crtc *crtc);
 int (*cursor_set)(struct drm_crtc *crtc, struct drm_file *file_priv,
     uint32_t handle, uint32_t width, uint32_t height);
 int (*cursor_set2)(struct drm_crtc *crtc, struct drm_file *file_priv,
      uint32_t handle, uint32_t width, uint32_t height,
      int32_t hot_x, int32_t hot_y);
 int (*cursor_move)(struct drm_crtc *crtc, int x, int y);
 int (*gamma_set)(struct drm_crtc *crtc, u16 *r, u16 *g, u16 *b,
    uint32_t size,
    struct drm_modeset_acquire_ctx *ctx);
 void (*destroy)(struct drm_crtc *crtc);
 int (*set_config)(struct drm_mode_set *set,
     struct drm_modeset_acquire_ctx *ctx);
 int (*page_flip)(struct drm_crtc *crtc,
    struct drm_framebuffer *fb,
    struct drm_pending_vblank_event *event,
    uint32_t flags,
    struct drm_modeset_acquire_ctx *ctx);
 int (*page_flip_target)(struct drm_crtc *crtc,
    struct drm_framebuffer *fb,
    struct drm_pending_vblank_event *event,
    uint32_t flags, uint32_t target,
    struct drm_modeset_acquire_ctx *ctx);
 int (*set_property)(struct drm_crtc *crtc,
       struct drm_property *property, uint64_t val);
 struct drm_crtc_state *(*atomic_duplicate_state)(struct drm_crtc *crtc);
 void (*atomic_destroy_state)(struct drm_crtc *crtc,
         struct drm_crtc_state *state);
 int (*atomic_set_property)(struct drm_crtc *crtc,
       struct drm_crtc_state *state,
       struct drm_property *property,
       uint64_t val);
 int (*atomic_get_property)(struct drm_crtc *crtc,
       const struct drm_crtc_state *state,
       struct drm_property *property,
       uint64_t *val);
 int (*late_register)(struct drm_crtc *crtc);
 void (*early_unregister)(struct drm_crtc *crtc);
 int (*set_crc_source)(struct drm_crtc *crtc, const char *source);
 int (*verify_crc_source)(struct drm_crtc *crtc, const char *source,
     size_t *values_cnt);
 const char *const *(*get_crc_sources)(struct drm_crtc *crtc,
           size_t *count);
 void (*atomic_print_state)(struct drm_printer *p,
       const struct drm_crtc_state *state);
 u32 (*get_vblank_counter)(struct drm_crtc *crtc);
 int (*enable_vblank)(struct drm_crtc *crtc);







 void (*disable_vblank)(struct drm_crtc *crtc);
 bool (*get_vblank_timestamp)(struct drm_crtc *crtc,
         int *max_error,
         ktime_t *vblank_time,
         bool in_vblank_irq);
};
struct drm_crtc {

 struct drm_device *dev;

 struct device_node *port;







 struct list_head head;


 char *name;
 struct drm_modeset_lock mutex;


 struct drm_mode_object base;
 struct drm_plane *primary;
 struct drm_plane *cursor;





 unsigned index;
 int cursor_x;







 int cursor_y;
 bool enabled;
 struct drm_display_mode mode;
 struct drm_display_mode hwmode;
 int x;







 int y;


 const struct drm_crtc_funcs *funcs;
 uint32_t gamma_size;
 uint16_t *gamma_store;


 const struct drm_crtc_helper_funcs *helper_private;


 struct drm_object_properties properties;





 struct drm_property *scaling_filter_property;
 struct drm_crtc_state *state;
 struct list_head commit_list;






 spinlock_t commit_lock;






 struct dentry *debugfs_entry;






 struct drm_crtc_crc crc;






 unsigned int fence_context;






 spinlock_t fence_lock;






 unsigned long fence_seqno;






 char timeline_name[32];






 struct drm_self_refresh_data *self_refresh_data;
};
struct drm_mode_set {
 struct drm_framebuffer *fb;
 struct drm_crtc *crtc;
 struct drm_display_mode *mode;

 uint32_t x;
 uint32_t y;

 struct drm_connector **connectors;
 size_t num_connectors;
};
struct drm_encoder;
struct drm_encoder_funcs {







 void (*reset)(struct drm_encoder *encoder);
 void (*destroy)(struct drm_encoder *encoder);
 int (*late_register)(struct drm_encoder *encoder);
 void (*early_unregister)(struct drm_encoder *encoder);






 void (*debugfs_init)(struct drm_encoder *encoder, struct dentry *root);
};
struct drm_encoder {
 struct drm_device *dev;
 struct list_head head;

 struct drm_mode_object base;
 char *name;
 int encoder_type;





 unsigned index;
 uint32_t possible_crtcs;
 uint32_t possible_clones;






 struct drm_crtc *crtc;





 struct list_head bridge_chain;

 const struct drm_encoder_funcs *funcs;
 const struct drm_encoder_helper_funcs *helper_private;






 struct dentry *debugfs_entry;
};
typedef union dfixed {
 u32 full;
} fixed20_12;
struct drm_device;
struct drm_format_info {

 u32 format;
 u8 depth;


 u8 num_planes;

 union {
  u8 cpp[4u];
  u8 char_per_block[4u];
 };







 u8 block_w[4u];







 u8 block_h[4u];


 u8 hsub;

 u8 vsub;


 bool has_alpha;


 bool is_yuv;


 bool is_color_indexed;
};
const struct drm_format_info *drm_format_info(u32 format);
struct drm_clip_rect;
struct drm_device;
struct drm_file;
struct drm_framebuffer;
struct drm_gem_object;
struct drm_framebuffer_funcs {
 void (*destroy)(struct drm_framebuffer *framebuffer);
 int (*create_handle)(struct drm_framebuffer *fb,
        struct drm_file *file_priv,
        unsigned int *handle);
 int (*dirty)(struct drm_framebuffer *framebuffer,
       struct drm_file *file_priv, unsigned flags,
       unsigned color, struct drm_clip_rect *clips,
       unsigned num_clips);
};
struct drm_framebuffer {



 struct drm_device *dev;




 struct list_head head;




 struct drm_mode_object base;




 char comm[TASK_COMM_LEN];




 const struct drm_format_info *format;



 const struct drm_framebuffer_funcs *funcs;




 unsigned int pitches[4u];
 unsigned int offsets[4u];






 uint64_t modifier;




 unsigned int width;




 unsigned int height;




 int flags;



 unsigned int internal_flags;



 struct list_head filp_head;






 struct drm_gem_object *obj[4u];
};
struct drm_connector;
struct drm_crtc;
struct drm_device;
struct drm_modeset_acquire_ctx;
struct i2c_algo_bit_data {
 void *data;
 void (*setsda) (void *data, int state);
 void (*setscl) (void *data, int state);
 int (*getsda) (void *data);
 int (*getscl) (void *data);
 int (*pre_xfer) (struct i2c_adapter *);
 void (*post_xfer) (struct i2c_adapter *);


 int udelay;



 int timeout;
 bool can_do_atomic;
};
struct drm_crtc_commit {





 struct drm_crtc *crtc;
 struct kref ref;
 struct completion flip_done;
 struct completion hw_done;
 struct completion cleanup_done;







 struct list_head commit_entry;






 struct drm_pending_vblank_event *event;
 bool abort_completion;
};
struct __drm_planes_state {
 struct drm_plane *ptr;
 struct drm_plane_state *state, *old_state, *new_state;
};
struct __drm_crtcs_state {
 struct drm_crtc *ptr;
 struct drm_crtc_state *state, *old_state, *new_state;
 struct drm_crtc_commit *commit;

 s32 *out_fence_ptr;
 u64 last_vblank_count;
};
struct __drm_connnectors_state {
 struct drm_connector *ptr;
 struct drm_connector_state *state, *old_state, *new_state;







 s32 *out_fence_ptr;
};
struct drm_private_obj;
struct drm_private_state;
struct drm_private_state_funcs {
 struct drm_private_state *(*atomic_duplicate_state)(struct drm_private_obj *obj);






 void (*atomic_destroy_state)(struct drm_private_obj *obj,
         struct drm_private_state *state);
 void (*atomic_print_state)(struct drm_printer *p,
       const struct drm_private_state *state);
};
struct drm_private_obj {




 struct list_head head;




 struct drm_modeset_lock lock;




 struct drm_private_state *state;







 const struct drm_private_state_funcs *funcs;
};
struct drm_private_state {



 struct drm_atomic_state *state;




 struct drm_private_obj *obj;
};
struct __drm_private_objs_state {
 struct drm_private_obj *ptr;
 struct drm_private_state *state, *old_state, *new_state;
};
struct drm_atomic_state {





 struct kref ref;




 struct drm_device *dev;
 bool allow_modeset : 1;
 bool legacy_cursor_update : 1;




 bool async_update : 1;
 bool duplicated : 1;







 struct __drm_planes_state *planes;







 struct __drm_crtcs_state *crtcs;




 int num_connector;







 struct __drm_connnectors_state *connectors;




 int num_private_objs;







 struct __drm_private_objs_state *private_objs;




 struct drm_modeset_acquire_ctx *acquire_ctx;
 struct drm_crtc_commit *fake_commit;







 struct work_struct commit_work;
};
enum drm_dp_mst_topology_ref_type {
 DRM_DP_MST_TOPOLOGY_REF_GET,
 DRM_DP_MST_TOPOLOGY_REF_PUT,
};
struct drm_dp_mst_topology_ref_history {
 struct drm_dp_mst_topology_ref_entry {
  enum drm_dp_mst_topology_ref_type type;
  int count;
  ktime_t ts_nsec;
  depot_stack_handle_t backtrace;
 } *entries;
 int len;
};
struct drm_dp_mst_branch;
struct drm_dp_mst_port {




 struct kref topology_kref;






 struct kref malloc_kref;






 struct drm_dp_mst_topology_ref_history topology_ref_history;


 u8 port_num;
 bool input;
 bool mcs;
 bool ddps;
 u8 pdt;
 bool ldps;
 u8 dpcd_rev;
 u8 num_sdp_streams;
 u8 num_sdp_stream_sinks;
 uint16_t full_pbn;
 struct list_head next;
 struct drm_dp_mst_branch *mstb;
 struct drm_dp_aux aux;
 struct drm_dp_aux *passthrough_aux;
 struct drm_dp_mst_branch *parent;

 struct drm_connector *connector;
 struct drm_dp_mst_topology_mgr *mgr;





 const struct drm_edid *cached_edid;





 bool fec_capable;
};
struct drm_dp_sideband_msg_hdr {
 u8 lct;
 u8 lcr;
 u8 rad[8];
 bool broadcast;
 bool path_msg;
 u8 msg_len;
 bool somt;
 bool eomt;
 bool seqno;
};
struct drm_dp_sideband_msg_rx {
 u8 chunk[48];
 u8 msg[256];
 u8 curchunk_len;
 u8 curchunk_idx;
 u8 curchunk_hdrlen;
 u8 curlen;
 bool have_somt;
 bool have_eomt;
 struct drm_dp_sideband_msg_hdr initial_hdr;
};
struct drm_dp_mst_branch {




 struct kref topology_kref;






 struct kref malloc_kref;






 struct drm_dp_mst_topology_ref_history topology_ref_history;






 struct list_head destroy_next;
 u8 rad[8];
 u8 lct;
 int num_ports;
 struct list_head ports;

 struct drm_dp_mst_port *port_parent;
 struct drm_dp_mst_topology_mgr *mgr;

 bool link_address_sent;


 guid_t guid;
};
struct drm_dp_mst_topology_mgr;
struct drm_dp_mst_topology_cbs {

 struct drm_connector *(*add_connector)(struct drm_dp_mst_topology_mgr *mgr, struct drm_dp_mst_port *port, const char *path);
 void (*poll_hpd_irq)(struct drm_dp_mst_topology_mgr *mgr);
};
struct drm_dp_mst_topology_mgr {



 struct drm_private_obj base;




 struct drm_device *dev;



 const struct drm_dp_mst_topology_cbs *cbs;




 int max_dpcd_transaction_bytes;




 struct drm_dp_aux *aux;



 int max_payloads;




 int conn_base_id;




 struct drm_dp_sideband_msg_rx up_req_recv;





 struct drm_dp_sideband_msg_rx down_rep_recv;





 struct mutex lock;






 struct mutex probe_lock;





 bool mst_state : 1;





 bool payload_id_table_cleared : 1;






 bool reset_rx_state : 1;






 u8 payload_count;






 u8 next_start_slot;




 struct drm_dp_mst_branch *mst_primary;




 u8 dpcd[0xf];



 u8 sink_count;




 const struct drm_private_state_funcs *funcs;




 struct mutex qlock;




 struct list_head tx_msg_downq;




 wait_queue_head_t tx_waitq;



 struct work_struct work;




 struct work_struct tx_work;




 struct list_head destroy_port_list;




 struct list_head destroy_branch_device_list;




 struct mutex delayed_destroy_lock;






 struct workqueue_struct *delayed_destroy_wq;





 struct work_struct delayed_destroy_work;





 struct list_head up_req_list;



 struct mutex up_req_lock;





 struct work_struct up_req_work;







 struct mutex topology_ref_history_lock;

};
struct mod_freesync {
 int dummy;
};
enum mod_vrr_state {
 VRR_STATE_UNSUPPORTED = 0,
 VRR_STATE_DISABLED,
 VRR_STATE_INACTIVE,
 VRR_STATE_ACTIVE_VARIABLE,
 VRR_STATE_ACTIVE_FIXED
};
struct mod_freesync_config {
 enum mod_vrr_state state;
 bool vsif_supported;
 bool ramping;
 bool btr;
 unsigned int min_refresh_in_uhz;
 unsigned int max_refresh_in_uhz;
 unsigned int fixed_refresh_in_uhz;

};
struct mod_vrr_params_btr {
 bool btr_enabled;
 bool btr_active;
 uint32_t mid_point_in_us;
 uint32_t inserted_duration_in_us;
 uint32_t frames_to_insert;
 uint32_t frame_counter;
 uint32_t margin_in_us;
};
struct mod_vrr_params_fixed_refresh {
 bool fixed_active;
 bool ramping_active;
 bool ramping_done;
 uint32_t target_refresh_in_uhz;
 uint32_t frame_counter;
};
struct mod_vrr_params_flip_interval {
 bool flip_interval_workaround_active;
 bool program_flip_interval_workaround;
 bool do_flip_interval_workaround_cleanup;
 uint32_t flip_interval_detect_counter;
 uint32_t vsyncs_between_flip;
 uint32_t vsync_to_flip_in_us;
 uint32_t v_update_timestamp_in_us;
};
struct mod_vrr_params {
 bool supported;
 bool send_info_frame;
 enum mod_vrr_state state;

 uint32_t min_refresh_in_uhz;
 uint32_t max_duration_in_us;
 uint32_t max_refresh_in_uhz;
 uint32_t min_duration_in_us;
 uint32_t fixed_refresh_in_uhz;

 struct dc_crtc_timing_adjust adjust;

 struct mod_vrr_params_fixed_refresh fixed;

 struct mod_vrr_params_btr btr;

 struct mod_vrr_params_flip_interval flip_interval;
};
struct drm_crtc;
enum amdgpu_dm_pipe_crc_source {
 AMDGPU_DM_PIPE_CRC_SOURCE_NONE = 0,
 AMDGPU_DM_PIPE_CRC_SOURCE_CRTC,
 AMDGPU_DM_PIPE_CRC_SOURCE_CRTC_DITHER,
 AMDGPU_DM_PIPE_CRC_SOURCE_DPRX,
 AMDGPU_DM_PIPE_CRC_SOURCE_DPRX_DITHER,
 AMDGPU_DM_PIPE_CRC_SOURCE_MAX,
 AMDGPU_DM_PIPE_CRC_SOURCE_INVALID = -1,
};
enum secure_display_mode {

 LEGACY_MODE = 0,

 DISPLAY_CRC_MODE,
 SECURE_DISPLAY_MODE_MAX,
};
struct phy_id_mapping {
 bool assigned;
 bool is_mst;
 uint8_t enc_hw_inst;
 u8 lct;
 u8 port_num;
 u8 rad[8];
};
struct crc_data {
 uint32_t crc_R;
 uint32_t crc_G;
 uint32_t crc_B;
 uint32_t frame_count;
 bool crc_ready;
};
struct crc_info {
 struct crc_data crc[2];
 struct completion completion;
 spinlock_t lock;
};
struct crc_window_param {
 uint16_t x_start;
 uint16_t y_start;
 uint16_t x_end;
 uint16_t y_end;

 bool enable;

 bool update_win;

 int skip_frame_cnt;
};
struct secure_display_crtc_context {

 struct work_struct notify_ta_work;


 struct work_struct forward_roi_work;

 struct drm_crtc *crtc;


 struct crc_window roi[2];

 struct crc_info crc_info;
};
struct secure_display_context {

 struct secure_display_crtc_context *crtc_ctx;

 bool support_mul_roi;
 enum secure_display_mode op_mode;
 bool phy_mapping_updated;
 int phy_id_mapping_cnt;
 struct phy_id_mapping phy_id_mapping[6];
};
struct dm_irq_params {
 u32 last_flip_vblank;
 struct mod_vrr_params vrr_params;
 struct dc_stream_state *stream;
 int active_planes;
 bool allow_sr_entry;
 struct mod_freesync_config freesync_config;


 enum amdgpu_dm_pipe_crc_source crc_src;

 struct crc_window_param window_param[2];

 bool crc_window_activated;


};
struct amdgpu_bo;
struct amdgpu_device;
struct amdgpu_encoder;
struct amdgpu_router;
struct amdgpu_hpd;
struct drm_edid;
enum amdgpu_rmx_type {
 RMX_OFF,
 RMX_FULL,
 RMX_CENTER,
 RMX_ASPECT
};
enum amdgpu_underscan_type {
 UNDERSCAN_OFF,
 UNDERSCAN_ON,
 UNDERSCAN_AUTO,
};
enum amdgpu_hpd_id {
 AMDGPU_HPD_1 = 0,
 AMDGPU_HPD_2,
 AMDGPU_HPD_3,
 AMDGPU_HPD_4,
 AMDGPU_HPD_5,
 AMDGPU_HPD_6,
 AMDGPU_HPD_NONE = 0xff,
};
enum amdgpu_flip_status {
 AMDGPU_FLIP_NONE,
 AMDGPU_FLIP_PENDING,
 AMDGPU_FLIP_SUBMITTED
};
struct amdgpu_i2c_bus_rec {
 bool valid;

 uint8_t i2c_id;

 enum amdgpu_hpd_id hpd;

 bool hw_capable;

 bool mm_i2c;

 uint32_t mask_clk_reg;
 uint32_t mask_data_reg;
 uint32_t a_clk_reg;
 uint32_t a_data_reg;
 uint32_t en_clk_reg;
 uint32_t en_data_reg;
 uint32_t y_clk_reg;
 uint32_t y_data_reg;
 uint32_t mask_clk_mask;
 uint32_t mask_data_mask;
 uint32_t a_clk_mask;
 uint32_t a_data_mask;
 uint32_t en_clk_mask;
 uint32_t en_data_mask;
 uint32_t y_clk_mask;
 uint32_t y_data_mask;
};
struct amdgpu_pll {

 uint32_t reference_freq;


 uint32_t reference_div;
 uint32_t post_div;


 uint32_t pll_in_min;
 uint32_t pll_in_max;
 uint32_t pll_out_min;
 uint32_t pll_out_max;
 uint32_t lcd_pll_out_min;
 uint32_t lcd_pll_out_max;
 uint32_t best_vco;


 uint32_t min_ref_div;
 uint32_t max_ref_div;
 uint32_t min_post_div;
 uint32_t max_post_div;
 uint32_t min_feedback_div;
 uint32_t max_feedback_div;
 uint32_t min_frac_feedback_div;
 uint32_t max_frac_feedback_div;


 uint32_t flags;


 uint32_t id;
};
struct amdgpu_i2c_chan {
 struct i2c_adapter adapter;
 struct drm_device *dev;
 struct i2c_algo_bit_data bit;
 struct amdgpu_i2c_bus_rec rec;
 struct drm_dp_aux aux;
 bool has_aux;
 struct mutex mutex;
};
struct amdgpu_afmt {
 bool enabled;
 int offset;
 bool last_buffer_filled_status;
 int id;
 struct amdgpu_audio_pin *pin;
};
struct amdgpu_audio_pin {
 int channels;
 int rate;
 int bits_per_sample;
 u8 status_bits;
 u8 category_code;
 u32 offset;
 bool connected;
 u32 id;
};
struct amdgpu_audio {
 bool enabled;
 struct amdgpu_audio_pin pin[9];
 int num_pins;
};
struct amdgpu_display_funcs {

 void (*bandwidth_update)(struct amdgpu_device *adev);

 u32 (*vblank_get_counter)(struct amdgpu_device *adev, int crtc);

 void (*backlight_set_level)(struct amdgpu_encoder *amdgpu_encoder,
        u8 level);

 u8 (*backlight_get_level)(struct amdgpu_encoder *amdgpu_encoder);

 bool (*hpd_sense)(struct amdgpu_device *adev, enum amdgpu_hpd_id hpd);
 void (*hpd_set_polarity)(struct amdgpu_device *adev,
     enum amdgpu_hpd_id hpd);
 u32 (*hpd_get_gpio_reg)(struct amdgpu_device *adev);

 void (*page_flip)(struct amdgpu_device *adev,
     int crtc_id, u64 crtc_base, bool async);
 int (*page_flip_get_scanoutpos)(struct amdgpu_device *adev, int crtc,
     u32 *vbl, u32 *position);

 void (*add_encoder)(struct amdgpu_device *adev,
       uint32_t encoder_enum,
       uint32_t supported_device,
       u16 caps);
 void (*add_connector)(struct amdgpu_device *adev,
         uint32_t connector_id,
         uint32_t supported_device,
         int connector_type,
         struct amdgpu_i2c_bus_rec *i2c_bus,
         uint16_t connector_object_id,
         struct amdgpu_hpd *hpd,
         struct amdgpu_router *router);


};
struct amdgpu_mode_info {
 struct atom_context *atom_context;
 struct card_info *atom_card_info;
 bool mode_config_initialized;
 struct amdgpu_crtc *crtcs[6];
 struct drm_plane *planes[6];
 struct amdgpu_afmt *afmt[9];

 struct drm_property *coherent_mode_property;

 struct drm_property *load_detect_property;

 struct drm_property *underscan_property;
 struct drm_property *underscan_hborder_property;
 struct drm_property *underscan_vborder_property;

 struct drm_property *audio_property;

 struct drm_property *dither_property;

 const struct drm_edid *bios_hardcoded_edid;


 u32 firmware_flags;

 struct amdgpu_encoder *bl_encoder;
 u8 bl_level;
 struct amdgpu_audio audio;
 int num_crtc;
 int num_hpd;
 int num_dig;
 bool gpu_vm_support;
 int disp_priority;
 const struct amdgpu_display_funcs *funcs;
 const enum drm_plane_type *plane_type;







 struct drm_property *plane_degamma_lut_property;



 struct drm_property *plane_degamma_lut_size_property;




 struct drm_property *plane_degamma_tf_property;



 struct drm_property *plane_hdr_mult_property;

 struct drm_property *plane_ctm_property;







 struct drm_property *plane_shaper_lut_property;




 struct drm_property *plane_shaper_lut_size_property;







 struct drm_property *plane_shaper_tf_property;
 struct drm_property *plane_lut3d_property;






 struct drm_property *plane_lut3d_size_property;
 struct drm_property *plane_blend_lut_property;




 struct drm_property *plane_blend_lut_size_property;







 struct drm_property *plane_blend_tf_property;






 struct drm_property *regamma_tf_property;
};
struct amdgpu_atom_ss {
 uint16_t percentage;
 uint16_t percentage_divider;
 uint8_t type;
 uint16_t step;
 uint8_t delay;
 uint8_t range;
 uint8_t refdiv;

 uint16_t rate;
 uint16_t amount;
};
struct amdgpu_crtc {
 struct drm_crtc base;
 int crtc_id;
 bool enabled;
 bool can_tile;
 uint32_t crtc_offset;
 struct drm_gem_object *cursor_bo;
 uint64_t cursor_addr;
 int cursor_x;
 int cursor_y;
 int cursor_hot_x;
 int cursor_hot_y;
 int cursor_width;
 int cursor_height;
 int max_cursor_width;
 int max_cursor_height;
 enum amdgpu_rmx_type rmx_type;
 u8 h_border;
 u8 v_border;
 fixed20_12 vsc;
 fixed20_12 hsc;
 struct drm_display_mode native_mode;
 u32 pll_id;

 struct amdgpu_flip_work *pflip_works;
 enum amdgpu_flip_status pflip_status;
 int deferred_flip_completion;

 struct dm_irq_params dm_irq_params;

 struct amdgpu_atom_ss ss;
 bool ss_enabled;
 u32 adjusted_clock;
 int bpc;
 u32 pll_reference_div;
 u32 pll_post_div;
 u32 pll_flags;
 struct drm_encoder *encoder;
 struct drm_connector *connector;

 u32 line_time;
 u32 lb_vblank_lead_lines;
 struct drm_display_mode hw_mode;

 struct hrtimer vblank_timer;
 enum amdgpu_interrupt_state vsync_timer_enabled;

 int otg_inst;
 struct drm_pending_vblank_event *event;

 bool wb_pending;
 bool wb_enabled;
 struct drm_writeback_connector *wb_conn;
};
struct amdgpu_encoder {
 struct drm_encoder base;
 uint32_t encoder_enum;
 uint32_t encoder_id;
 uint32_t devices;
 uint32_t active_device;
 uint32_t flags;
 uint32_t pixel_clock;
 enum amdgpu_rmx_type rmx_type;
 enum amdgpu_underscan_type underscan_type;
 uint32_t underscan_hborder;
 uint32_t underscan_vborder;
 struct drm_display_mode native_mode;
 void *enc_priv;
 int audio_polling_active;
 bool is_ext_encoder;
 u16 caps;
};
struct amdgpu_gpio_rec {
 bool valid;
 u8 id;
 u32 reg;
 u32 mask;
 u32 shift;
};
struct amdgpu_hpd {
 enum amdgpu_hpd_id hpd;
 u8 plugged_state;
 struct amdgpu_gpio_rec gpio;
};
struct amdgpu_router {
 u32 router_id;
 struct amdgpu_i2c_bus_rec i2c_info;
 u8 i2c_addr;

 bool ddc_valid;
 u8 ddc_mux_type;
 u8 ddc_mux_control_pin;
 u8 ddc_mux_state;

 bool cd_valid;
 u8 cd_mux_type;
 u8 cd_mux_control_pin;
 u8 cd_mux_state;
};
struct amdgpu_dm_dp_aux {
 struct drm_dp_aux aux;
 struct ddc_service *ddc_service;
};
struct amdgpu_i2c_adapter {
 struct i2c_adapter base;

 struct ddc_service *ddc_service;
 bool oem;
};
struct gpu_info_voltage_scaling_v1_0 {
 uint32_t state;
 uint32_t dscclk_mhz;
 uint32_t dcfclk_mhz;
 uint32_t socclk_mhz;
 uint32_t dram_speed_mts;
 uint32_t fabricclk_mhz;
 uint32_t dispclk_mhz;
 uint32_t phyclk_mhz;
 uint32_t dppclk_mhz;
};
struct gpu_info_soc_bounding_box_v1_0 {
 uint32_t sr_exit_time_us;
 uint32_t sr_enter_plus_exit_time_us;
 uint32_t urgent_latency_us;
 uint32_t urgent_latency_pixel_data_only_us;
 uint32_t urgent_latency_pixel_mixed_with_vm_data_us;
 uint32_t urgent_latency_vm_data_only_us;
 uint32_t writeback_latency_us;
 uint32_t ideal_dram_bw_after_urgent_percent;
 uint32_t pct_ideal_dram_sdp_bw_after_urgent_pixel_only;
 uint32_t pct_ideal_dram_sdp_bw_after_urgent_pixel_and_vm;
 uint32_t pct_ideal_dram_sdp_bw_after_urgent_vm_only;
 uint32_t max_avg_sdp_bw_use_normal_percent;
 uint32_t max_avg_dram_bw_use_normal_percent;
 uint32_t max_request_size_bytes;
 uint32_t downspread_percent;
 uint32_t dram_page_open_time_ns;
 uint32_t dram_rw_turnaround_time_ns;
 uint32_t dram_return_buffer_per_channel_bytes;
 uint32_t dram_channel_width_bytes;
 uint32_t fabric_datapath_to_dcn_data_return_bytes;
 uint32_t dcn_downspread_percent;
 uint32_t dispclk_dppclk_vco_speed_mhz;
 uint32_t dfs_vco_period_ps;
 uint32_t urgent_out_of_order_return_per_channel_pixel_only_bytes;
 uint32_t urgent_out_of_order_return_per_channel_pixel_and_vm_bytes;
 uint32_t urgent_out_of_order_return_per_channel_vm_only_bytes;
 uint32_t round_trip_ping_latency_dcfclk_cycles;
 uint32_t urgent_out_of_order_return_per_channel_bytes;
 uint32_t channel_interleave_bytes;
 uint32_t num_banks;
 uint32_t num_chans;
 uint32_t vmm_page_size_bytes;
 uint32_t dram_clock_change_latency_us;
 uint32_t writeback_dram_clock_change_latency_us;
 uint32_t return_bus_width_bytes;
 uint32_t voltage_override;
 uint32_t xfc_bus_transport_time_us;
 uint32_t xfc_xbuf_latency_tolerance_us;
 uint32_t use_urgent_burst_bw;
 uint32_t num_states;
 struct gpu_info_voltage_scaling_v1_0 clock_limits[8];
};
enum AMDGPU_UCODE_ID {
 AMDGPU_UCODE_ID_CAP = 0,
 AMDGPU_UCODE_ID_SDMA0,
 AMDGPU_UCODE_ID_SDMA1,
 AMDGPU_UCODE_ID_SDMA2,
 AMDGPU_UCODE_ID_SDMA3,
 AMDGPU_UCODE_ID_SDMA4,
 AMDGPU_UCODE_ID_SDMA5,
 AMDGPU_UCODE_ID_SDMA6,
 AMDGPU_UCODE_ID_SDMA7,
 AMDGPU_UCODE_ID_SDMA_UCODE_TH0,
 AMDGPU_UCODE_ID_SDMA_UCODE_TH1,
 AMDGPU_UCODE_ID_SDMA_RS64,
 AMDGPU_UCODE_ID_CP_CE,
 AMDGPU_UCODE_ID_CP_PFP,
 AMDGPU_UCODE_ID_CP_ME,
 AMDGPU_UCODE_ID_CP_RS64_PFP,
 AMDGPU_UCODE_ID_CP_RS64_ME,
 AMDGPU_UCODE_ID_CP_RS64_MEC,
 AMDGPU_UCODE_ID_CP_RS64_PFP_P0_STACK,
 AMDGPU_UCODE_ID_CP_RS64_PFP_P1_STACK,
 AMDGPU_UCODE_ID_CP_RS64_ME_P0_STACK,
 AMDGPU_UCODE_ID_CP_RS64_ME_P1_STACK,
 AMDGPU_UCODE_ID_CP_RS64_MEC_P0_STACK,
 AMDGPU_UCODE_ID_CP_RS64_MEC_P1_STACK,
 AMDGPU_UCODE_ID_CP_RS64_MEC_P2_STACK,
 AMDGPU_UCODE_ID_CP_RS64_MEC_P3_STACK,
 AMDGPU_UCODE_ID_CP_MEC1,
 AMDGPU_UCODE_ID_CP_MEC1_JT,
 AMDGPU_UCODE_ID_CP_MEC2,
 AMDGPU_UCODE_ID_CP_MEC2_JT,
 AMDGPU_UCODE_ID_CP_MES,
 AMDGPU_UCODE_ID_CP_MES_DATA,
 AMDGPU_UCODE_ID_CP_MES1,
 AMDGPU_UCODE_ID_CP_MES1_DATA,
 AMDGPU_UCODE_ID_IMU_I,
 AMDGPU_UCODE_ID_IMU_D,
 AMDGPU_UCODE_ID_GLOBAL_TAP_DELAYS,
 AMDGPU_UCODE_ID_SE0_TAP_DELAYS,
 AMDGPU_UCODE_ID_SE1_TAP_DELAYS,
 AMDGPU_UCODE_ID_SE2_TAP_DELAYS,
 AMDGPU_UCODE_ID_SE3_TAP_DELAYS,
 AMDGPU_UCODE_ID_RLC_RESTORE_LIST_CNTL,
 AMDGPU_UCODE_ID_RLC_RESTORE_LIST_GPM_MEM,
 AMDGPU_UCODE_ID_RLC_RESTORE_LIST_SRM_MEM,
 AMDGPU_UCODE_ID_RLC_IRAM,
 AMDGPU_UCODE_ID_RLC_DRAM,
 AMDGPU_UCODE_ID_RLC_P,
 AMDGPU_UCODE_ID_RLC_V,
 AMDGPU_UCODE_ID_RLC_G,
 AMDGPU_UCODE_ID_STORAGE,
 AMDGPU_UCODE_ID_SMC,
 AMDGPU_UCODE_ID_PPTABLE,
 AMDGPU_UCODE_ID_UVD,
 AMDGPU_UCODE_ID_UVD1,
 AMDGPU_UCODE_ID_VCE,
 AMDGPU_UCODE_ID_VCN,
 AMDGPU_UCODE_ID_VCN1,
 AMDGPU_UCODE_ID_DMCU_ERAM,
 AMDGPU_UCODE_ID_DMCU_INTV,
 AMDGPU_UCODE_ID_VCN0_RAM,
 AMDGPU_UCODE_ID_VCN1_RAM,
 AMDGPU_UCODE_ID_DMCUB,
 AMDGPU_UCODE_ID_VPE_CTX,
 AMDGPU_UCODE_ID_VPE_CTL,
 AMDGPU_UCODE_ID_VPE,
 AMDGPU_UCODE_ID_UMSCH_MM_UCODE,
 AMDGPU_UCODE_ID_UMSCH_MM_DATA,
 AMDGPU_UCODE_ID_UMSCH_MM_CMD_BUFFER,
 AMDGPU_UCODE_ID_P2S_TABLE,
 AMDGPU_UCODE_ID_JPEG_RAM,
 AMDGPU_UCODE_ID_ISP,
 AMDGPU_UCODE_ID_MAXIMUM,
};
enum amdgpu_firmware_load_type {
 AMDGPU_FW_LOAD_DIRECT = 0,
 AMDGPU_FW_LOAD_PSP,
 AMDGPU_FW_LOAD_SMU,
 AMDGPU_FW_LOAD_RLC_BACKDOOR_AUTO,
};
struct amdgpu_firmware_info {

 enum AMDGPU_UCODE_ID ucode_id;

 const struct firmware *fw;

 uint64_t mc_addr;

 void *kaddr;

 uint32_t ucode_size;

 uint32_t tmr_mc_addr_lo;
 uint32_t tmr_mc_addr_hi;
};
struct amdgpu_firmware {
 struct amdgpu_firmware_info ucode[AMDGPU_UCODE_ID_MAXIMUM];
 enum amdgpu_firmware_load_type load_type;
 struct amdgpu_bo *fw_buf;
 unsigned int fw_size;
 unsigned int max_ucodes;

 const struct amdgpu_psp_funcs *funcs;
 struct amdgpu_bo *rbuf;
 struct mutex mutex;


 const struct firmware *gpu_info_fw;

 void *fw_buf_ptr;
 uint64_t fw_buf_mc;
 uint32_t pldm_version;
};
struct gpu_buddy_block {

 u64 header;

 struct gpu_buddy_block *left;
 struct gpu_buddy_block *right;
 struct gpu_buddy_block *parent;

 void *private;







 union {
  struct rb_node rb;
  struct list_head link;
 };

 struct list_head tmp_link;
};
struct gpu_buddy {

 struct rb_root **free_trees;
 struct gpu_buddy_block **roots;





 unsigned int n_roots;
 unsigned int max_order;


 u64 chunk_size;
 u64 size;
 u64 avail;
 u64 clear_avail;
};
struct amdgpu_vram_mgr {
 struct ttm_resource_manager manager;
 struct gpu_buddy mm;

 struct mutex lock;
 struct list_head reservations_pending;
 struct list_head reserved_pages;
 atomic64_t vis_usage;
 u64 default_page_size;
 struct list_head allocated_vres_list;
};
struct hmm_range;
struct amdgpu_gtt_mgr {
 struct ttm_resource_manager manager;
 struct drm_mm mm;
 spinlock_t lock;
};
struct amdgpu_mman {
 struct ttm_device bdev;
 struct ttm_pool *ttm_pools;
 bool initialized;
 void *aper_base_kaddr;


 const struct amdgpu_buffer_funcs *buffer_funcs;
 struct amdgpu_ring *buffer_funcs_ring;
 bool buffer_funcs_enabled;

 struct mutex gtt_window_lock;

 struct drm_sched_entity high_pr;

 struct drm_sched_entity low_pr;

 struct amdgpu_vram_mgr vram_mgr;
 struct amdgpu_gtt_mgr gtt_mgr;
 struct ttm_resource_manager preempt_mgr;

 uint64_t stolen_vga_size;
 struct amdgpu_bo *stolen_vga_memory;
 uint64_t stolen_extended_size;
 struct amdgpu_bo *stolen_extended_memory;
 bool keep_stolen_vga_memory;

 struct amdgpu_bo *stolen_reserved_memory;
 uint64_t stolen_reserved_offset;
 uint64_t stolen_reserved_size;


 uint8_t *discovery_bin;
 uint32_t discovery_tmr_size;

 struct amdgpu_bo *fw_reserved_memory;
 struct amdgpu_bo *fw_reserved_memory_extend;


 u64 fw_vram_usage_start_offset;
 u64 fw_vram_usage_size;
 struct amdgpu_bo *fw_vram_usage_reserved_bo;
 void *fw_vram_usage_va;


 u64 drv_vram_usage_start_offset;
 u64 drv_vram_usage_size;
 struct amdgpu_bo *drv_vram_usage_reserved_bo;
 void *drv_vram_usage_va;


 struct amdgpu_bo *sdma_access_bo;
 void *sdma_access_ptr;
};
enum psp_gfx_cmd_id
{
    GFX_CMD_ID_LOAD_TA = 0x00000001,
    GFX_CMD_ID_UNLOAD_TA = 0x00000002,
    GFX_CMD_ID_INVOKE_CMD = 0x00000003,
    GFX_CMD_ID_LOAD_ASD = 0x00000004,
    GFX_CMD_ID_SETUP_TMR = 0x00000005,
    GFX_CMD_ID_LOAD_IP_FW = 0x00000006,
    GFX_CMD_ID_DESTROY_TMR = 0x00000007,
    GFX_CMD_ID_SAVE_RESTORE = 0x00000008,
    GFX_CMD_ID_SETUP_VMR = 0x00000009,
    GFX_CMD_ID_DESTROY_VMR = 0x0000000A,
    GFX_CMD_ID_PROG_REG = 0x0000000B,
    GFX_CMD_ID_GET_FW_ATTESTATION = 0x0000000F,

    GFX_CMD_ID_LOAD_TOC = 0x00000020,
    GFX_CMD_ID_AUTOLOAD_RLC = 0x00000021,
    GFX_CMD_ID_BOOT_CFG = 0x00000022,
    GFX_CMD_ID_SRIOV_SPATIAL_PART = 0x00000027,

    GFX_CMD_ID_CONFIG_SQ_PERFMON = 0x00000046,

    GFX_CMD_ID_FB_NPS_MODE = 0x00000048,
    GFX_CMD_ID_FB_FW_RESERV_ADDR = 0x00000050,
    GFX_CMD_ID_FB_FW_RESERV_EXT_ADDR = 0x00000051,
};
enum psp_gfx_boot_config_cmd
{
    BOOTCFG_CMD_SET = 1,
    BOOTCFG_CMD_GET = 2,
    BOOTCFG_CMD_INVALIDATE = 3
};
struct psp_gfx_cmd_load_ta
{
    uint32_t app_phy_addr_lo;
    uint32_t app_phy_addr_hi;
    uint32_t app_len;
    uint32_t cmd_buf_phy_addr_lo;
    uint32_t cmd_buf_phy_addr_hi;
    uint32_t cmd_buf_len;





};
struct psp_gfx_cmd_unload_ta
{
    uint32_t session_id;

};
struct psp_gfx_buf_desc
{
    uint32_t buf_phy_addr_lo;
    uint32_t buf_phy_addr_hi;
    uint32_t buf_size;

};
struct psp_gfx_buf_list
{
    uint32_t num_desc;
    uint32_t total_size;
    struct psp_gfx_buf_desc buf_desc[64];


};
struct psp_gfx_cmd_invoke_cmd
{
    uint32_t session_id;
    uint32_t ta_cmd_id;
    struct psp_gfx_buf_list buf;

};
struct psp_gfx_cmd_setup_tmr
{
    uint32_t buf_phy_addr_lo;
    uint32_t buf_phy_addr_hi;
    uint32_t buf_size;
    union {
 struct {
  uint32_t sriov_enabled:1;
  uint32_t virt_phy_addr:1;
  uint32_t reserved:30;
 } bitfield;
 uint32_t tmr_flags;
    };
    uint32_t system_phy_addr_lo;
    uint32_t system_phy_addr_hi;

};
enum psp_gfx_fw_type {
 GFX_FW_TYPE_NONE = 0,
 GFX_FW_TYPE_CP_ME = 1,
 GFX_FW_TYPE_CP_PFP = 2,
 GFX_FW_TYPE_CP_CE = 3,
 GFX_FW_TYPE_CP_MEC = 4,
 GFX_FW_TYPE_CP_MEC_ME1 = 5,
 GFX_FW_TYPE_CP_MEC_ME2 = 6,
 GFX_FW_TYPE_RLC_V = 7,
 GFX_FW_TYPE_RLC_G = 8,
 GFX_FW_TYPE_SDMA0 = 9,
 GFX_FW_TYPE_SDMA1 = 10,
 GFX_FW_TYPE_DMCU_ERAM = 11,
 GFX_FW_TYPE_DMCU_ISR = 12,
 GFX_FW_TYPE_VCN = 13,
 GFX_FW_TYPE_UVD = 14,
 GFX_FW_TYPE_VCE = 15,
 GFX_FW_TYPE_ISP = 16,
 GFX_FW_TYPE_ACP = 17,
 GFX_FW_TYPE_SMU = 18,
 GFX_FW_TYPE_MMSCH = 19,
 GFX_FW_TYPE_RLC_RESTORE_LIST_GPM_MEM = 20,
 GFX_FW_TYPE_RLC_RESTORE_LIST_SRM_MEM = 21,
 GFX_FW_TYPE_RLC_RESTORE_LIST_SRM_CNTL = 22,
 GFX_FW_TYPE_UVD1 = 23,
 GFX_FW_TYPE_TOC = 24,
 GFX_FW_TYPE_RLC_P = 25,
 GFX_FW_TYPE_RLC_IRAM = 26,
 GFX_FW_TYPE_GLOBAL_TAP_DELAYS = 27,
 GFX_FW_TYPE_SE0_TAP_DELAYS = 28,
 GFX_FW_TYPE_SE1_TAP_DELAYS = 29,
 GFX_FW_TYPE_GLOBAL_SE0_SE1_SKEW_DELAYS = 30,
 GFX_FW_TYPE_SDMA0_JT = 31,
 GFX_FW_TYPE_SDMA1_JT = 32,
 GFX_FW_TYPE_CP_MES = 33,
 GFX_FW_TYPE_MES_STACK = 34,
 GFX_FW_TYPE_RLC_SRM_DRAM_SR = 35,
 GFX_FW_TYPE_RLCG_SCRATCH_SR = 36,
 GFX_FW_TYPE_RLCP_SCRATCH_SR = 37,
 GFX_FW_TYPE_RLCV_SCRATCH_SR = 38,
 GFX_FW_TYPE_RLX6_DRAM_SR = 39,
 GFX_FW_TYPE_SDMA0_PG_CONTEXT = 40,
 GFX_FW_TYPE_SDMA1_PG_CONTEXT = 41,
 GFX_FW_TYPE_GLOBAL_MUX_SELECT_RAM = 42,
 GFX_FW_TYPE_SE0_MUX_SELECT_RAM = 43,
 GFX_FW_TYPE_SE1_MUX_SELECT_RAM = 44,
 GFX_FW_TYPE_ACCUM_CTRL_RAM = 45,
 GFX_FW_TYPE_RLCP_CAM = 46,
 GFX_FW_TYPE_RLC_SPP_CAM_EXT = 47,
 GFX_FW_TYPE_RLC_DRAM_BOOT = 48,
 GFX_FW_TYPE_VCN0_RAM = 49,
 GFX_FW_TYPE_VCN1_RAM = 50,
 GFX_FW_TYPE_DMUB = 51,
 GFX_FW_TYPE_SDMA2 = 52,
 GFX_FW_TYPE_SDMA3 = 53,
 GFX_FW_TYPE_SDMA4 = 54,
 GFX_FW_TYPE_SDMA5 = 55,
 GFX_FW_TYPE_SDMA6 = 56,
 GFX_FW_TYPE_SDMA7 = 57,
 GFX_FW_TYPE_VCN1 = 58,
 GFX_FW_TYPE_CAP = 62,
 GFX_FW_TYPE_SE2_TAP_DELAYS = 65,
 GFX_FW_TYPE_SE3_TAP_DELAYS = 66,
 GFX_FW_TYPE_REG_LIST = 67,
 GFX_FW_TYPE_IMU_I = 68,
 GFX_FW_TYPE_IMU_D = 69,
 GFX_FW_TYPE_LSDMA = 70,
 GFX_FW_TYPE_SDMA_UCODE_TH0 = 71,
 GFX_FW_TYPE_SDMA_UCODE_TH1 = 72,
 GFX_FW_TYPE_PPTABLE = 73,
 GFX_FW_TYPE_DISCRETE_USB4 = 74,
 GFX_FW_TYPE_TA = 75,
 GFX_FW_TYPE_RS64_MES = 76,
 GFX_FW_TYPE_RS64_MES_STACK = 77,
 GFX_FW_TYPE_RS64_KIQ = 78,
 GFX_FW_TYPE_RS64_KIQ_STACK = 79,
 GFX_FW_TYPE_ISP_DATA = 80,
 GFX_FW_TYPE_CP_MES_KIQ = 81,
 GFX_FW_TYPE_MES_KIQ_STACK = 82,
 GFX_FW_TYPE_UMSCH_DATA = 83,
 GFX_FW_TYPE_UMSCH_UCODE = 84,
 GFX_FW_TYPE_UMSCH_CMD_BUFFER = 85,
 GFX_FW_TYPE_USB_DP_COMBO_PHY = 86,
 GFX_FW_TYPE_RS64_PFP = 87,
 GFX_FW_TYPE_RS64_ME = 88,
 GFX_FW_TYPE_RS64_MEC = 89,
 GFX_FW_TYPE_RS64_PFP_P0_STACK = 90,
 GFX_FW_TYPE_RS64_PFP_P1_STACK = 91,
 GFX_FW_TYPE_RS64_ME_P0_STACK = 92,
 GFX_FW_TYPE_RS64_ME_P1_STACK = 93,
 GFX_FW_TYPE_RS64_MEC_P0_STACK = 94,
 GFX_FW_TYPE_RS64_MEC_P1_STACK = 95,
 GFX_FW_TYPE_RS64_MEC_P2_STACK = 96,
 GFX_FW_TYPE_RS64_MEC_P3_STACK = 97,
 GFX_FW_TYPE_VPEC_FW1 = 100,
 GFX_FW_TYPE_VPEC_FW2 = 101,
 GFX_FW_TYPE_VPE = 102,
 GFX_FW_TYPE_JPEG_RAM = 128,
 GFX_FW_TYPE_P2S_TABLE = 129,
 GFX_FW_TYPE_MAX
};
struct psp_gfx_cmd_load_ip_fw
{
    uint32_t fw_phy_addr_lo;
    uint32_t fw_phy_addr_hi;
    uint32_t fw_size;
    enum psp_gfx_fw_type fw_type;

};
struct psp_gfx_cmd_save_restore_ip_fw
{
    uint32_t save_fw;
    uint32_t save_restore_addr_lo;
    uint32_t save_restore_addr_hi;
    uint32_t buf_size;
    enum psp_gfx_fw_type fw_type;
};
struct psp_gfx_cmd_reg_prog {
 uint32_t reg_value;
 uint32_t reg_id;
};
struct psp_gfx_cmd_load_toc
{
    uint32_t toc_phy_addr_lo;
    uint32_t toc_phy_addr_hi;
    uint32_t toc_size;
};
struct psp_gfx_cmd_boot_cfg
{
    uint32_t timestamp;
    enum psp_gfx_boot_config_cmd sub_cmd;
    uint32_t boot_config;
    uint32_t boot_config_valid;
};
struct psp_gfx_cmd_sriov_spatial_part {
 uint32_t mode;
 uint32_t override_ips;
 uint32_t override_xcds_avail;
 uint32_t override_this_aid;
};
struct psp_gfx_cmd_config_sq_perfmon {
 uint32_t gfx_xcp_mask;
 uint8_t core_override;
 uint8_t reg_override;
 uint8_t perfmon_override;
 uint8_t reserved[5];
};
struct psp_gfx_cmd_fb_memory_part {
 uint32_t mode;
 uint32_t resvd;
};
union psp_gfx_commands
{
    struct psp_gfx_cmd_load_ta cmd_load_ta;
    struct psp_gfx_cmd_unload_ta cmd_unload_ta;
    struct psp_gfx_cmd_invoke_cmd cmd_invoke_cmd;
    struct psp_gfx_cmd_setup_tmr cmd_setup_tmr;
    struct psp_gfx_cmd_load_ip_fw cmd_load_ip_fw;
    struct psp_gfx_cmd_save_restore_ip_fw cmd_save_restore_ip_fw;
    struct psp_gfx_cmd_reg_prog cmd_setup_reg_prog;
    struct psp_gfx_cmd_setup_tmr cmd_setup_vmr;
    struct psp_gfx_cmd_load_toc cmd_load_toc;
    struct psp_gfx_cmd_boot_cfg boot_cfg;
    struct psp_gfx_cmd_sriov_spatial_part cmd_spatial_part;
    struct psp_gfx_cmd_config_sq_perfmon config_sq_perfmon;
    struct psp_gfx_cmd_fb_memory_part cmd_memory_part;
};
struct psp_gfx_uresp_reserved
{
    uint32_t reserved[8];
};
struct psp_gfx_uresp_fwar_db_info
{
    uint32_t fwar_db_addr_lo;
    uint32_t fwar_db_addr_hi;
};
struct psp_gfx_uresp_bootcfg {
 uint32_t boot_cfg;
};
struct psp_gfx_uresp_fw_reserve_info {
    uint32_t reserve_base_address_hi;
    uint32_t reserve_base_address_lo;
    uint32_t reserve_size;
};
union psp_gfx_uresp {
 struct psp_gfx_uresp_reserved reserved;
 struct psp_gfx_uresp_bootcfg boot_cfg;
 struct psp_gfx_uresp_fwar_db_info fwar_db_info;
 struct psp_gfx_uresp_fw_reserve_info fw_reserve_info;
};
struct psp_gfx_resp
{
    uint32_t status;
    uint32_t session_id;
    uint32_t fw_addr_lo;
    uint32_t fw_addr_hi;
    uint32_t tmr_size;

    uint32_t reserved[11];

    union psp_gfx_uresp uresp;


};
struct psp_gfx_cmd_resp
{
    uint32_t buf_size;
    uint32_t buf_version;
    uint32_t cmd_id;



    uint32_t resp_buf_addr_lo;
    uint32_t resp_buf_addr_hi;
    uint32_t resp_offset;
    uint32_t resp_buf_size;

    union psp_gfx_commands cmd;

    uint8_t reserved_1[864 - sizeof(union psp_gfx_commands) - 28];




    struct psp_gfx_resp resp;

    uint8_t reserved_2[1024 - 864 - sizeof(struct psp_gfx_resp)];


};
struct psp_gfx_rb_frame
{
    uint32_t cmd_buf_addr_lo;
    uint32_t cmd_buf_addr_hi;
    uint32_t cmd_buf_size;
    uint32_t fence_addr_lo;
    uint32_t fence_addr_hi;
    uint32_t fence_value;
    uint32_t sid_lo;
    uint32_t sid_hi;
    uint8_t vmid;
    uint8_t frame_type;
    uint8_t reserved1[2];
    uint32_t reserved2[7];

};
enum { TA_XGMI__MAX_PORT_NUM = 8 };
enum ta_xgmi_assigned_sdma_engine {
 TA_XGMI_ASSIGNED_SDMA_ENGINE__NOT_ASSIGNED = -1,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA0 = 0,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA1 = 1,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA2 = 2,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA3 = 3,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA4 = 4,
 TA_XGMI_ASSIGNED_SDMA_ENGINE__SDMA5 = 5
};
struct xgmi_connected_port_num {
 uint8_t dst_xgmi_port_num;
 uint8_t src_xgmi_port_num;
};
enum psp_shared_mem_size {
 PSP_ASD_SHARED_MEM_SIZE = 0x0,
 PSP_XGMI_SHARED_MEM_SIZE = 0x4000,
 PSP_RAS_SHARED_MEM_SIZE = 0x4000,
 PSP_HDCP_SHARED_MEM_SIZE = 0x4000,
 PSP_DTM_SHARED_MEM_SIZE = 0x4000,
 PSP_RAP_SHARED_MEM_SIZE = 0x4000,
 PSP_SECUREDISPLAY_SHARED_MEM_SIZE = 0x4000,
};
enum ta_type_id {
 TA_TYPE_XGMI = 1,
 TA_TYPE_RAS,
 TA_TYPE_HDCP,
 TA_TYPE_DTM,
 TA_TYPE_RAP,
 TA_TYPE_SECUREDISPLAY,

 TA_TYPE_MAX_INDEX,
};
struct psp_context;
struct psp_xgmi_node_info;
struct psp_xgmi_topology_info;
struct psp_bin_desc;
enum psp_ring_type {
 PSP_RING_TYPE__INVALID = 0,




 PSP_RING_TYPE__UM = 1,
 PSP_RING_TYPE__KM = 2
};
struct psp_ring {
 enum psp_ring_type ring_type;
 struct psp_gfx_rb_frame *ring_mem;
 uint64_t ring_mem_mc_addr;
 void *ring_mem_handle;
 uint32_t ring_size;
 uint32_t ring_wptr;
};
enum psp_reg_prog_id {
 PSP_REG_IH_RB_CNTL = 0,
 PSP_REG_IH_RB_CNTL_RING1 = 1,
 PSP_REG_IH_RB_CNTL_RING2 = 2,
 PSP_REG_MMHUB_L1_TLB_CNTL = 25,
 PSP_REG_LAST
};
struct psp_funcs {
 int (*init_microcode)(struct psp_context *psp);
 int (*wait_for_bootloader)(struct psp_context *psp);
 int (*bootloader_load_kdb)(struct psp_context *psp);
 int (*bootloader_load_spl)(struct psp_context *psp);
 int (*bootloader_load_sysdrv)(struct psp_context *psp);
 int (*bootloader_load_soc_drv)(struct psp_context *psp);
 int (*bootloader_load_intf_drv)(struct psp_context *psp);
 int (*bootloader_load_dbg_drv)(struct psp_context *psp);
 int (*bootloader_load_ras_drv)(struct psp_context *psp);
 int (*bootloader_load_ipkeymgr_drv)(struct psp_context *psp);
 int (*bootloader_load_spdm_drv)(struct psp_context *psp);
 int (*bootloader_load_sos)(struct psp_context *psp);
 int (*ring_create)(struct psp_context *psp,
      enum psp_ring_type ring_type);
 int (*ring_stop)(struct psp_context *psp,
       enum psp_ring_type ring_type);
 int (*ring_destroy)(struct psp_context *psp,
       enum psp_ring_type ring_type);
 bool (*smu_reload_quirk)(struct psp_context *psp);
 int (*mode1_reset)(struct psp_context *psp);
 int (*mem_training)(struct psp_context *psp, uint32_t ops);
 uint32_t (*ring_get_wptr)(struct psp_context *psp);
 void (*ring_set_wptr)(struct psp_context *psp, uint32_t value);
 int (*load_usbc_pd_fw)(struct psp_context *psp, uint64_t fw_pri_mc_addr);
 int (*read_usbc_pd_fw)(struct psp_context *psp, uint32_t *fw_ver);
 int (*update_spirom)(struct psp_context *psp, uint64_t fw_pri_mc_addr);
 int (*dump_spirom)(struct psp_context *psp, uint64_t fw_pri_mc_addr);
 int (*vbflash_stat)(struct psp_context *psp);
 int (*fatal_error_recovery_quirk)(struct psp_context *psp);
 bool (*get_ras_capability)(struct psp_context *psp);
 bool (*is_aux_sos_load_required)(struct psp_context *psp);
 bool (*is_reload_needed)(struct psp_context *psp);
 int (*reg_program_no_ring)(struct psp_context *psp, uint32_t val,
       enum psp_reg_prog_id id);
};
struct ta_funcs {
 int (*fn_ta_initialize)(struct psp_context *psp);
 int (*fn_ta_invoke)(struct psp_context *psp, uint32_t ta_cmd_id);
 int (*fn_ta_terminate)(struct psp_context *psp);
};
struct psp_xgmi_node_info {
 uint64_t node_id;
 uint8_t num_hops;
 uint8_t is_sharing_enabled;
 enum ta_xgmi_assigned_sdma_engine sdma_engine;
 uint8_t num_links;
 struct xgmi_connected_port_num port_num[TA_XGMI__MAX_PORT_NUM];
};
struct psp_xgmi_topology_info {
 uint32_t num_nodes;
 struct psp_xgmi_node_info nodes[64];
};
struct psp_bin_desc {
 uint32_t fw_version;
 uint32_t feature_version;
 uint32_t size_bytes;
 uint8_t *start_addr;
};
struct ta_mem_context {
 struct amdgpu_bo *shared_bo;
 uint64_t shared_mc_addr;
 void *shared_buf;
 enum psp_shared_mem_size shared_mem_size;
};
struct ta_context {
 bool initialized;
 uint32_t session_id;
 uint32_t resp_status;
 struct ta_mem_context mem_context;
 struct psp_bin_desc bin_desc;
 enum psp_gfx_cmd_id ta_load_type;
 enum ta_type_id ta_type;
};
struct ta_cp_context {
 struct ta_context context;
 struct mutex mutex;
};
struct psp_xgmi_context {
 struct ta_context context;
 struct psp_xgmi_topology_info top_info;
 bool supports_extended_data;
 uint8_t xgmi_ta_caps;
};
struct psp_ras_context {
 struct ta_context context;
 struct amdgpu_ras *ras;
 struct mutex mutex;
};
enum psp_memory_training_init_flag {
 PSP_MEM_TRAIN_NOT_SUPPORT = 0x0,
 PSP_MEM_TRAIN_SUPPORT = 0x1,
 PSP_MEM_TRAIN_INIT_FAILED = 0x2,
 PSP_MEM_TRAIN_RESERVE_SUCCESS = 0x4,
 PSP_MEM_TRAIN_INIT_SUCCESS = 0x8,
};
struct psp_memory_training_context {

 u64 train_data_size;





 void *sys_cache;


 u64 p2c_train_data_offset;


 u64 c2p_train_data_offset;
 struct amdgpu_bo *c2p_bo;

 enum psp_memory_training_init_flag init;
 u32 training_cnt;
 bool enable_mem_training;
};
struct spirom_bo {
 struct amdgpu_bo *bo;
 uint64_t mc_addr;
 void *cpu_addr;
};
struct psp_context {
 struct amdgpu_device *adev;
 struct psp_ring km_ring;
 struct psp_gfx_cmd_resp *cmd;

 const struct psp_funcs *funcs;
 const struct ta_funcs *ta_funcs;


 struct amdgpu_bo *fw_pri_bo;
 uint64_t fw_pri_mc_addr;
 void *fw_pri_buf;


 const struct firmware *sos_fw;
 struct psp_bin_desc sys;
 struct psp_bin_desc sos;
 struct psp_bin_desc toc;
 struct psp_bin_desc kdb;
 struct psp_bin_desc spl;
 struct psp_bin_desc rl;
 struct psp_bin_desc soc_drv;
 struct psp_bin_desc intf_drv;
 struct psp_bin_desc dbg_drv;
 struct psp_bin_desc ras_drv;
 struct psp_bin_desc ipkeymgr_drv;
 struct psp_bin_desc spdm_drv;


 struct amdgpu_bo *tmr_bo;
 uint64_t tmr_mc_addr;


 const struct firmware *asd_fw;


 const struct firmware *toc_fw;


 const struct firmware *cap_fw;


 struct amdgpu_bo *fence_buf_bo;
 uint64_t fence_buf_mc_addr;
 void *fence_buf;


 struct amdgpu_bo *cmd_buf_bo;
 uint64_t cmd_buf_mc_addr;
 struct psp_gfx_cmd_resp *cmd_buf_mem;


 atomic_t fence_value;

 bool autoload_supported;

 bool boot_time_tmr;

 bool pmfw_centralized_cstate_management;


 const struct firmware *ta_fw;
 uint32_t ta_fw_version;

 uint32_t cap_fw_version;
 uint32_t cap_feature_version;
 uint32_t cap_ucode_size;

 struct ta_context asd_context;
 struct psp_xgmi_context xgmi_context;
 struct psp_ras_context ras_context;
 struct ta_cp_context hdcp_context;
 struct ta_cp_context dtm_context;
 struct ta_cp_context rap_context;
 struct ta_cp_context securedisplay_context;
 struct mutex mutex;
 struct psp_memory_training_context mem_train_ctx;

 uint32_t boot_cfg_bitmask;


 bool sup_pd_fw_up;
 bool sup_ifwi_up;

 char *vbflash_tmp_buf;
 size_t vbflash_image_size;
 bool vbflash_done;

 struct spirom_bo *spirom_dump_trip;

};
struct amdgpu_psp_funcs {
 bool (*check_fw_loading_status)(struct amdgpu_device *adev,
     enum AMDGPU_UCODE_ID);
};
struct amdgpu_ring;
struct amdgpu_bo;
struct amdgpu_gds {
 uint32_t gds_size;
 uint32_t gws_size;
 uint32_t oa_size;
 uint32_t gds_compute_max_wave_id;
};
struct dma_fence;
struct dma_resv;
struct amdgpu_device;
struct amdgpu_ring;
struct amdgpu_job;
struct amdgpu_sync {
 struct hlist_head fences[1 << (4)];
};
struct drm_prime_file_private {

 struct mutex lock;
 struct rb_root dmabufs;
 struct rb_root handles;
};
struct device;
struct dma_buf;
struct dma_buf_attachment;
struct iosys_map;
enum dma_data_direction;
struct drm_device;
struct drm_gem_object;
struct drm_file;
struct dma_fence;
struct drm_file;
struct drm_device;
struct drm_printer;
struct device;
struct file;
struct drm_minor {

 int index;
 int type;
 struct device *kdev;
 struct drm_device *dev;

 struct dentry *debugfs_symlink;
 struct dentry *debugfs_root;
};
struct drm_file {
 bool authenticated;






 bool stereo_allowed;







 bool universal_planes;


 bool atomic;







 bool aspect_ratio_allowed;






 bool writeback_connectors;
 bool was_master;
 bool is_master;
 bool supports_virtualized_cursor_plane;
 struct drm_master *master;


 spinlock_t master_lookup_lock;
 struct pid *pid;


 u64 client_id;


 drm_magic_t magic;







 struct list_head lhead;


 struct drm_minor *minor;
 struct idr object_idr;


 spinlock_t table_lock;


 struct idr syncobj_idr;

 spinlock_t syncobj_table_lock;


 struct file *filp;







 void *driver_priv;
 struct list_head fbs;


 struct mutex fbs_lock;
 struct list_head blobs;


 wait_queue_head_t event_wait;
 struct list_head pending_event_list;
 struct list_head event_list;
 int event_space;


 struct mutex event_read_lock;






 struct drm_prime_file_private prime;






 const char *client_name;




 struct mutex client_name_lock;






 struct dentry *debugfs_client;
};
struct drm_memory_stats {
 u64 shared;
 u64 private;
 u64 resident;
 u64 purgeable;
 u64 active;
};
enum drm_gem_object_status;
struct amdgpu_device;
struct amdgpu_vm;
struct amdgpu_ring;
struct amdgpu_sync;
struct amdgpu_job;
struct amdgpu_vmid {
 struct list_head list;
 struct amdgpu_sync active;
 struct dma_fence *last_flush;
 uint64_t owner;

 uint64_t pd_gpu_addr;

 uint64_t flushed_updates;

 uint32_t current_gpu_reset_count;

 uint32_t gds_base;
 uint32_t gds_size;
 uint32_t gws_base;
 uint32_t gws_size;
 uint32_t oa_base;
 uint32_t oa_size;

 unsigned pasid;
 struct dma_fence *pasid_mapping;
};
struct amdgpu_vmid_mgr {
 struct mutex lock;
 unsigned num_ids;
 struct list_head ids_lru;
 struct amdgpu_vmid ids[16];
 bool reserved_vmid;
};
struct drm_exec;
struct amdgpu_bo_va;
struct amdgpu_job;
struct amdgpu_bo_list_entry;
struct amdgpu_bo_vm;
enum amdgpu_vm_level {
 AMDGPU_VM_PDB2,
 AMDGPU_VM_PDB1,
 AMDGPU_VM_PDB0,
 AMDGPU_VM_PTB
};
struct amdgpu_vm_bo_base {

 struct amdgpu_vm *vm;
 struct amdgpu_bo *bo;


 struct amdgpu_vm_bo_base *next;


 struct list_head vm_status;



 bool shared;


 bool moved;
};
struct amdgpu_vm_pte_funcs {

 unsigned copy_pte_num_dw;


 void (*copy_pte)(struct amdgpu_ib *ib,
    uint64_t pe, uint64_t src,
    unsigned count);


 void (*write_pte)(struct amdgpu_ib *ib, uint64_t pe,
     uint64_t value, unsigned count,
     uint32_t incr);

 void (*set_pte_pde)(struct amdgpu_ib *ib,
       uint64_t pe,
       uint64_t addr, unsigned count,
       uint32_t incr, uint64_t flags);
};
struct amdgpu_task_info {
 struct drm_wedge_task_info task;
 char process_name[TASK_COMM_LEN];
 pid_t tgid;
 struct kref refcount;
};
struct amdgpu_vm_update_params {




 struct amdgpu_device *adev;




 struct amdgpu_vm *vm;




 bool immediate;




 bool unlocked;






 dma_addr_t *pages_addr;




 struct amdgpu_job *job;




 unsigned int num_dw_left;




 bool needs_flush;





 bool allow_override;




 struct list_head tlb_flush_waitlist;
};
struct amdgpu_vm_update_funcs {
 int (*map_table)(struct amdgpu_bo_vm *bo);
 int (*prepare)(struct amdgpu_vm_update_params *p,
         struct amdgpu_sync *sync, u64 k_job_id);
 int (*update)(struct amdgpu_vm_update_params *p,
        struct amdgpu_bo_vm *bo, uint64_t pe, uint64_t addr,
        unsigned count, uint32_t incr, uint64_t flags);
 int (*commit)(struct amdgpu_vm_update_params *p,
        struct dma_fence **fence);
};
struct amdgpu_vm_fault_info {

 uint64_t addr;

 uint32_t status;

 unsigned int vmhub;
};
struct amdgpu_mem_stats {
 struct drm_memory_stats drm;


 uint64_t evicted;
};
struct amdgpu_vm {

 struct rb_root_cached va;




 struct mutex eviction_lock;
 bool evicting;
 unsigned int saved_flags;


 spinlock_t status_lock;


 struct amdgpu_mem_stats stats[(3 + 6)];
 struct list_head evicted;


 struct list_head relocated;


 struct list_head moved;


 struct list_head idle;
 struct list_head evicted_user;


 struct list_head invalidated;


 struct list_head done;





 struct list_head freed;


 struct amdgpu_vm_bo_base root;
 struct dma_fence *last_update;


 struct drm_sched_entity immediate;
 struct drm_sched_entity delayed;


 atomic64_t tlb_seq;
 struct dma_fence *last_tlb_flush;
 atomic64_t kfd_last_flushed_seq;
 uint64_t tlb_fence_context;


 uint64_t generation;


 struct dma_fence *last_unlocked;

 unsigned int pasid;
 struct amdgpu_vmid *reserved_vmid[13];


 bool use_cpu_for_update;


 const struct amdgpu_vm_update_funcs *update_funcs;


 struct { union { struct __kfifo kfifo; u64 *type; const u64 *const_type; char (*rectype)[1]; u64 *ptr; u64 const *ptr_const; }; u64 buf[((128 < 2) || (128 & (128 - 1))) ? -1 : 128]; } faults;


 struct amdkfd_process_info *process_info;


 struct list_head vm_list_node;


 uint64_t pd_phys_addr;


 struct amdgpu_task_info *task_info;


 struct ttm_lru_bulk_move lru_bulk_move;

 bool is_compute_context;

 bool need_tlb_fence;


 int8_t mem_id;


 struct amdgpu_vm_fault_info fault_info;
};
struct amdgpu_vm_manager {

 struct amdgpu_vmid_mgr id_mgr[13];
 unsigned int first_kfd_vmid;
 bool concurrent_flush;


 u64 fence_context;
 unsigned seqno[149];

 uint64_t max_pfn;
 uint32_t num_level;
 uint32_t block_size;
 uint32_t fragment_size;
 enum amdgpu_vm_level root_level;

 u64 vram_base_offset;

 const struct amdgpu_vm_pte_funcs *vm_pte_funcs;
 struct drm_gpu_scheduler *vm_pte_scheds[149];
 unsigned vm_pte_num_scheds;
 struct amdgpu_ring *page_fault;


 spinlock_t prt_lock;
 atomic_t num_prt_users;





 int vm_update_mode;




 struct xarray pasids;

 struct amdgpu_vm_fault_info fault_info;
};
enum amdgpu_int_thermal_type {
 THERMAL_TYPE_NONE,
 THERMAL_TYPE_EXTERNAL,
 THERMAL_TYPE_EXTERNAL_GPIO,
 THERMAL_TYPE_RV6XX,
 THERMAL_TYPE_RV770,
 THERMAL_TYPE_ADT7473_WITH_INTERNAL,
 THERMAL_TYPE_EVERGREEN,
 THERMAL_TYPE_SUMO,
 THERMAL_TYPE_NI,
 THERMAL_TYPE_SI,
 THERMAL_TYPE_EMC2103_WITH_INTERNAL,
 THERMAL_TYPE_CI,
 THERMAL_TYPE_KV,
};
enum amdgpu_runpm_mode {
 AMDGPU_RUNPM_NONE,
 AMDGPU_RUNPM_PX,
 AMDGPU_RUNPM_BOCO,
 AMDGPU_RUNPM_BACO,
 AMDGPU_RUNPM_BAMACO,
};
struct amdgpu_ps {
 u32 caps;
 u32 class;
 u32 class2;

 u32 vclk;
 u32 dclk;

 u32 evclk;
 u32 ecclk;
 bool vce_active;
 enum amd_vce_level vce_level;

 void *ps_priv;
};
struct amdgpu_dpm_thermal {

 struct work_struct work;

 int min_temp;

 int max_temp;

 int max_edge_emergency_temp;

 int min_hotspot_temp;

 int max_hotspot_crit_temp;

 int max_hotspot_emergency_temp;

 int min_mem_temp;

 int max_mem_crit_temp;

 int max_mem_emergency_temp;

 int sw_ctf_threshold;

 bool high_to_low;

 struct amdgpu_irq_src irq;
};
struct amdgpu_clock_and_voltage_limits {
 u32 sclk;
 u32 mclk;
 u16 vddc;
 u16 vddci;
};
struct amdgpu_clock_array {
 u32 count;
 u32 *values;
};
struct amdgpu_clock_voltage_dependency_entry {
 u32 clk;
 u16 v;
};
struct amdgpu_clock_voltage_dependency_table {
 u32 count;
 struct amdgpu_clock_voltage_dependency_entry *entries;
};
union amdgpu_cac_leakage_entry {
 struct {
  u16 vddc;
  u32 leakage;
 };
 struct {
  u16 vddc1;
  u16 vddc2;
  u16 vddc3;
 };
};
struct amdgpu_cac_leakage_table {
 u32 count;
 union amdgpu_cac_leakage_entry *entries;
};
struct amdgpu_phase_shedding_limits_entry {
 u16 voltage;
 u32 sclk;
 u32 mclk;
};
struct amdgpu_phase_shedding_limits_table {
 u32 count;
 struct amdgpu_phase_shedding_limits_entry *entries;
};
struct amdgpu_uvd_clock_voltage_dependency_entry {
 u32 vclk;
 u32 dclk;
 u16 v;
};
struct amdgpu_uvd_clock_voltage_dependency_table {
 u8 count;
 struct amdgpu_uvd_clock_voltage_dependency_entry *entries;
};
struct amdgpu_vce_clock_voltage_dependency_entry {
 u32 ecclk;
 u32 evclk;
 u16 v;
};
struct amdgpu_vce_clock_voltage_dependency_table {
 u8 count;
 struct amdgpu_vce_clock_voltage_dependency_entry *entries;
};
struct amdgpu_ppm_table {
 u8 ppm_design;
 u16 cpu_core_number;
 u32 platform_tdp;
 u32 small_ac_platform_tdp;
 u32 platform_tdc;
 u32 small_ac_platform_tdc;
 u32 apu_tdp;
 u32 dgpu_tdp;
 u32 dgpu_ulv_power;
 u32 tj_max;
};
struct amdgpu_cac_tdp_table {
 u16 tdp;
 u16 configurable_tdp;
 u16 tdc;
 u16 battery_power_limit;
 u16 small_power_limit;
 u16 low_cac_leakage;
 u16 high_cac_leakage;
 u16 maximum_power_delivery_limit;
};
struct amdgpu_dpm_dynamic_state {
 struct amdgpu_clock_voltage_dependency_table vddc_dependency_on_sclk;
 struct amdgpu_clock_voltage_dependency_table vddci_dependency_on_mclk;
 struct amdgpu_clock_voltage_dependency_table vddc_dependency_on_mclk;
 struct amdgpu_clock_voltage_dependency_table mvdd_dependency_on_mclk;
 struct amdgpu_clock_voltage_dependency_table vddc_dependency_on_dispclk;
 struct amdgpu_uvd_clock_voltage_dependency_table uvd_clock_voltage_dependency_table;
 struct amdgpu_vce_clock_voltage_dependency_table vce_clock_voltage_dependency_table;
 struct amdgpu_clock_voltage_dependency_table samu_clock_voltage_dependency_table;
 struct amdgpu_clock_voltage_dependency_table acp_clock_voltage_dependency_table;
 struct amdgpu_clock_voltage_dependency_table vddgfx_dependency_on_sclk;
 struct amdgpu_clock_array valid_sclk_values;
 struct amdgpu_clock_array valid_mclk_values;
 struct amdgpu_clock_and_voltage_limits max_clock_voltage_on_dc;
 struct amdgpu_clock_and_voltage_limits max_clock_voltage_on_ac;
 u32 mclk_sclk_ratio;
 u32 sclk_mclk_delta;
 u16 vddc_vddci_delta;
 u16 min_vddc_for_pcie_gen2;
 struct amdgpu_cac_leakage_table cac_leakage_table;
 struct amdgpu_phase_shedding_limits_table phase_shedding_limits_table;
 struct amdgpu_ppm_table *ppm_table;
 struct amdgpu_cac_tdp_table *cac_tdp_table;
};
struct amdgpu_dpm_fan {
 u16 t_min;
 u16 t_med;
 u16 t_high;
 u16 pwm_min;
 u16 pwm_med;
 u16 pwm_high;
 u8 t_hyst;
 u32 cycle_delay;
 u16 t_max;
 u8 control_mode;
 u16 default_max_fan_pwm;
 u16 default_fan_output_sensitivity;
 u16 fan_output_sensitivity;
 bool ucode_fan_control;
};
struct amdgpu_dpm {
 struct amdgpu_ps *ps;

 int num_ps;

 struct amdgpu_ps *current_ps;

 struct amdgpu_ps *requested_ps;

 struct amdgpu_ps *boot_ps;

 struct amdgpu_ps *uvd_ps;

 u32 num_of_vce_states;
 struct amd_vce_state vce_states[6];
 enum amd_vce_level vce_level;
 enum amd_pm_state_type state;
 enum amd_pm_state_type user_state;
 enum amd_pm_state_type last_state;
 enum amd_pm_state_type last_user_state;
 u32 platform_caps;
 u32 voltage_response_time;
 u32 backbias_response_time;
 void *priv;
 struct amdgpu_dpm_dynamic_state dyn_state;
 struct amdgpu_dpm_fan fan;
 u32 tdp_limit;
 u32 near_tdp_limit;
 u32 near_tdp_limit_adjusted;
 u32 sq_ramping_threshold;
 u32 cac_leakage;
 u16 tdp_od_limit;
 u32 tdp_adjustment;
 u16 load_line_slope;
 bool power_control;

 bool thermal_active;
 bool uvd_active;
 bool vce_active;

 struct amdgpu_dpm_thermal thermal;

 enum amd_dpm_forced_level forced_level;
};
struct amdgpu_smu_i2c_bus {
 struct i2c_adapter adapter;
 struct amdgpu_device *adev;
 int port;
 struct mutex mutex;
};
struct config_table_setting
{
 uint16_t gfxclk_average_tau;
 uint16_t socclk_average_tau;
 uint16_t uclk_average_tau;
 uint16_t gfx_activity_average_tau;
 uint16_t mem_activity_average_tau;
 uint16_t socket_power_average_tau;
 uint16_t apu_socket_power_average_tau;
 uint16_t fclk_average_tau;
};
struct amdgpu_pm {
 struct mutex mutex;
 u32 current_sclk;
 u32 current_mclk;
 u32 default_sclk;
 u32 default_mclk;
 struct amdgpu_i2c_chan *i2c_bus;
 bool bus_locked;

 enum amdgpu_int_thermal_type int_thermal_type;
 struct device *int_hwmon_dev;

 bool no_fan;
 u8 fan_pulses_per_revolution;
 u8 fan_min_rpm;
 u8 fan_max_rpm;

 bool dpm_enabled;
 bool sysfs_initialized;
 struct amdgpu_dpm dpm;
 const struct firmware *fw;
 uint32_t fw_version;
 uint32_t pcie_gen_mask;
 uint32_t pcie_mlw_mask;
 struct amd_pp_display_configuration pm_display_cfg;
 uint32_t smu_prv_buffer_size;
 struct amdgpu_bo *smu_prv_buffer;
 bool ac_power;

 uint32_t pp_feature;


 struct amdgpu_smu_i2c_bus smu_i2c[2];
 struct i2c_adapter *ras_eeprom_i2c_bus;
 struct i2c_adapter *fru_eeprom_i2c_bus;
 struct list_head pm_attr_list;

 atomic_t pwr_state[AMD_IP_BLOCK_TYPE_NUM];




 uint32_t smu_debug_mask;

 bool pp_force_state_enabled;

 struct mutex stable_pstate_ctx_lock;
 struct amdgpu_ctx *stable_pstate_ctx;

 struct config_table_setting config_table;

 enum amdgpu_runpm_mode rpm_mode;

 struct list_head od_kobj_list;
 uint32_t od_feature_mask;
};
struct mfd_cell;
struct property_entry;
struct platform_device_id;
struct platform_device {
 const char *name;
 int id;
 bool id_auto;
 struct device dev;
 u64 platform_dma_mask;
 struct device_dma_parameters dma_parms;
 u32 num_resources;
 struct resource *resource;

 const struct platform_device_id *id_entry;


 struct mfd_cell *mfd_cell;


 struct pdev_archdata archdata;
};
struct irq_domain;
struct software_node;
struct mfd_cell_acpi_match {
 const char *pnpid;
 const unsigned long long adr;
};
struct mfd_cell {
 const char *name;
 int id;
 int level;

 int (*suspend)(struct platform_device *dev);
 int (*resume)(struct platform_device *dev);


 const void *platform_data;
 size_t pdata_size;


 const struct mfd_cell_acpi_match *acpi_match;


 const struct software_node *swnode;





 const char *of_compatible;






 u64 of_reg;


 bool use_of_reg;





 int num_resources;
 const struct resource *resources;


 bool ignore_resource_conflicts;





 bool pm_runtime_no_callbacks;




 int num_parent_supplies;
 const char * const *parent_supplies;
};
struct amdgpu_acp {
 struct device *parent;
 struct cgs_device *cgs_device;
 struct amd_acp_private *private;
 struct mfd_cell *acp_cell;
 struct resource *acp_res;
 struct acp_pm_domain *acp_genpd;
};
struct amdgpu_uvd_inst {
 struct amdgpu_bo *vcpu_bo;
 void *cpu_addr;
 uint64_t gpu_addr;
 void *saved_bo;
 struct amdgpu_ring ring;
 struct amdgpu_ring ring_enc[2];
 struct amdgpu_irq_src irq;
 uint32_t srbm_soft_reset;
};
struct amdgpu_uvd {
 const struct firmware *fw;
 unsigned fw_version;
 unsigned max_handles;
 unsigned num_enc_rings;
 uint8_t num_uvd_inst;
 bool address_64_bit;
 bool use_ctx_buf;
 struct amdgpu_uvd_inst inst[2];
 struct drm_file *filp[40];
 atomic_t handles[40];
 struct drm_sched_entity entity;
 struct delayed_work idle_work;
 unsigned harvest_config;

 unsigned decode_image_width;
 uint32_t keyselect;
 struct amdgpu_bo *ib_bo;
};
struct amdgpu_vce {
 struct amdgpu_bo *vcpu_bo;
 uint64_t gpu_addr;
 void *cpu_addr;
 void *saved_bo;
 unsigned fw_version;
 unsigned fb_version;
 atomic_t handles[16];
 struct drm_file *filp[16];
 uint32_t img_size[16];
 struct delayed_work idle_work;
 struct mutex idle_mutex;
 const struct firmware *fw;
 struct amdgpu_ring ring[3];
 struct amdgpu_irq_src irq;
 unsigned harvest_config;
 struct drm_sched_entity entity;
 uint32_t srbm_soft_reset;
 unsigned num_rings;
};
struct amdgpu_hwip_reg_entry;
enum internal_dpg_state {
 VCN_DPG_STATE__UNPAUSE = 0,
 VCN_DPG_STATE__PAUSE,
};
struct dpg_pause_state {
 enum internal_dpg_state fw_based;
 enum internal_dpg_state jpeg;
};
struct amdgpu_vcn_reg{
 unsigned data0;
 unsigned data1;
 unsigned cmd;
 unsigned nop;
 unsigned context_id;
 unsigned ib_vmid;
 unsigned ib_bar_low;
 unsigned ib_bar_high;
 unsigned ib_size;
 unsigned gp_scratch8;
 unsigned scratch9;
};
struct amdgpu_vcn_fw_shared {
 void *cpu_addr;
 uint64_t gpu_addr;
 uint32_t mem_size;
 uint32_t log_offset;
};
struct amdgpu_vcn_inst {
 struct amdgpu_device *adev;
 int inst;
 struct amdgpu_bo *vcpu_bo;
 void *cpu_addr;
 uint64_t gpu_addr;
 void *saved_bo;
 struct amdgpu_ring ring_dec;
 struct amdgpu_ring ring_enc[3];
 atomic_t sched_score;
 struct amdgpu_irq_src irq;
 struct amdgpu_irq_src ras_poison_irq;
 struct amdgpu_vcn_reg external;
 struct amdgpu_bo *dpg_sram_bo;
 struct dpg_pause_state pause_state;
 void *dpg_sram_cpu_addr;
 uint64_t dpg_sram_gpu_addr;
 uint32_t *dpg_sram_curr_addr;
 atomic_t dpg_enc_submission_cnt;
 struct amdgpu_vcn_fw_shared fw_shared;
 uint8_t aid_id;
 const struct firmware *fw;
 uint8_t vcn_config;
 uint32_t vcn_codec_disable_mask;
 atomic_t total_submission_cnt;
 struct mutex vcn_pg_lock;
 enum amd_powergating_state cur_state;
 struct delayed_work idle_work;
 unsigned fw_version;
 unsigned num_enc_rings;
 bool indirect_sram;
 struct amdgpu_vcn_reg internal;
 struct mutex vcn1_jpeg1_workaround;
 int (*pause_dpg_mode)(struct amdgpu_vcn_inst *vinst,
         struct dpg_pause_state *new_state);
 int (*set_pg_state)(struct amdgpu_vcn_inst *vinst,
       enum amd_powergating_state state);
 int (*reset)(struct amdgpu_vcn_inst *vinst);
 bool using_unified_queue;
 struct mutex engine_reset_mutex;
};
struct amdgpu_vcn_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_vcn {
 uint8_t num_vcn_inst;
 struct amdgpu_vcn_inst inst[4];

 unsigned harvest_config;

 struct ras_common_if *ras_if;
 struct amdgpu_vcn_ras *ras;

 uint16_t inst_mask;
 uint8_t num_inst_per_aid;


 uint32_t *ip_dump;

 uint32_t supported_reset;
 uint32_t caps;

 bool per_inst_fw;
 unsigned fw_version;

 bool workload_profile_active;
 struct mutex workload_profile_mutex;
 u32 reg_count;
 const struct amdgpu_hwip_reg_entry *reg_list;
};
struct drm_gem_object;
struct drm_exec {



 u32 flags;




 struct ww_acquire_ctx ticket;




 unsigned int num_objects;




 unsigned int max_objects;




 struct drm_gem_object **objects;




 struct drm_gem_object *contended;




 struct drm_gem_object *prelocked;
};
struct amdgpu_fence;
enum amdgpu_ib_pool_type;
struct amdgpu_job {
 struct drm_sched_job base;
 struct amdgpu_vm *vm;
 struct amdgpu_sync explicit_sync;
 struct amdgpu_fence hw_fence;
 struct dma_fence *gang_submit;
 uint32_t preamble_status;
 uint32_t preemption_status;
 bool vm_needs_flush;
 bool gds_switch_needed;
 bool spm_update_needed;
 uint64_t vm_pd_addr;
 unsigned vmid;
 unsigned pasid;
 uint32_t gds_base, gds_size;
 uint32_t gws_base, gws_size;
 uint32_t oa_base, oa_size;
 uint64_t generation;


 uint64_t uf_addr;
 uint64_t uf_sequence;


 uint64_t shadow_va;
 uint64_t csa_va;
 uint64_t gds_va;
 bool init_shadow;


 uint32_t job_run_counter;


 bool enforce_isolation;
 bool run_cleaner_shader;

 uint32_t num_ibs;
 struct amdgpu_ib ibs[1];
};
struct hmm_range;
struct drm_file;
struct amdgpu_device;
struct amdgpu_bo;
struct amdgpu_bo_va;
struct amdgpu_bo_list_entry {
 struct amdgpu_bo *bo;
 struct amdgpu_bo_va *bo_va;
 uint32_t priority;
 struct hmm_range *range;
 bool user_invalidated;
};
struct amdgpu_bo_list {
 struct callback_head rhead;
 struct kref refcount;
 struct amdgpu_bo *gds_obj;
 struct amdgpu_bo *gws_obj;
 struct amdgpu_bo *oa_obj;
 unsigned first_userptr;
 unsigned num_entries;



 struct mutex bo_list_mutex;

 struct amdgpu_bo_list_entry entries[1] ;
};
struct amdgpu_cs_chunk {
 uint32_t chunk_id;
 uint32_t length_dw;
 void *kdata;
};
struct amdgpu_cs_post_dep {
 struct drm_syncobj *syncobj;
 struct dma_fence_chain *chain;
 u64 point;
};
struct amdgpu_cs_parser {
 struct amdgpu_device *adev;
 struct drm_file *filp;
 struct amdgpu_ctx *ctx;


 unsigned nchunks;
 struct amdgpu_cs_chunk *chunks;


 unsigned int gang_size;
 unsigned int gang_leader_idx;
 struct drm_sched_entity *entities[4];
 struct amdgpu_job *jobs[4];
 struct amdgpu_job *gang_leader;


 struct drm_exec exec;
 struct amdgpu_bo_list *bo_list;
 struct amdgpu_mn *mn;
 struct dma_fence *fence;
 uint64_t bytes_moved_threshold;
 uint64_t bytes_moved_vis_threshold;
 uint64_t bytes_moved;
 uint64_t bytes_moved_vis;


 struct amdgpu_bo *uf_bo;

 unsigned num_post_deps;
 struct amdgpu_cs_post_dep *post_deps;

 struct amdgpu_sync sync;
};
struct amdgpu_hwip_reg_entry;
struct amdgpu_jpeg_reg{
 unsigned jpeg_pitch[10];
};
struct amdgpu_jpeg_inst {
 struct amdgpu_ring ring_dec[10];
 struct amdgpu_irq_src irq;
 struct amdgpu_irq_src ras_poison_irq;
 struct amdgpu_jpeg_reg external;
 struct amdgpu_bo *dpg_sram_bo;
 struct dpg_pause_state pause_state;
 void *dpg_sram_cpu_addr;
 uint64_t dpg_sram_gpu_addr;
 uint32_t *dpg_sram_curr_addr;
 uint8_t aid_id;
};
struct amdgpu_jpeg_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_jpeg {
 uint8_t num_jpeg_inst;
 struct amdgpu_jpeg_inst inst[4];
 unsigned num_jpeg_rings;
 struct amdgpu_jpeg_reg internal;
 unsigned harvest_config;
 struct delayed_work idle_work;
 enum amd_powergating_state cur_state;
 struct mutex jpeg_pg_lock;
 atomic_t total_submission_cnt;
 struct ras_common_if *ras_if;
 struct amdgpu_jpeg_ras *ras;

 uint16_t inst_mask;
 uint8_t num_inst_per_aid;
 bool indirect_sram;
 uint32_t supported_reset;
 uint32_t caps;
 u32 *ip_dump;
 u32 reg_count;
 const struct amdgpu_hwip_reg_entry *reg_list;
};
struct amdgpu_vpe;
struct vpe_funcs {
 uint32_t (*get_reg_offset)(struct amdgpu_vpe *vpe, uint32_t inst, uint32_t offset);
 int (*set_regs)(struct amdgpu_vpe *vpe);
 int (*irq_init)(struct amdgpu_vpe *vpe);
 int (*init_microcode)(struct amdgpu_vpe *vpe);
 int (*load_microcode)(struct amdgpu_vpe *vpe);
 int (*ring_init)(struct amdgpu_vpe *vpe);
 int (*ring_start)(struct amdgpu_vpe *vpe);
 int (*ring_stop)(struct amdgpu_vpe *vpe);
 int (*ring_fini)(struct amdgpu_vpe *vpe);
};
struct vpe_regs {
 uint32_t queue0_rb_rptr_lo;
 uint32_t queue0_rb_rptr_hi;
 uint32_t queue0_rb_wptr_lo;
 uint32_t queue0_rb_wptr_hi;
 uint32_t queue0_preempt;

 uint32_t dpm_enable;
 uint32_t dpm_pratio;
 uint32_t dpm_request_interval;
 uint32_t dpm_decision_threshold;
 uint32_t dpm_busy_clamp_threshold;
 uint32_t dpm_idle_clamp_threshold;
 uint32_t dpm_request_lv;
 uint32_t context_indicator;
};
struct amdgpu_vpe {
 struct amdgpu_ring ring;
 struct amdgpu_irq_src trap_irq;

 const struct vpe_funcs *funcs;
 struct vpe_regs regs;

 const struct firmware *fw;
 uint32_t fw_version;
 uint32_t feature_version;

 struct amdgpu_bo *cmdbuf_obj;
 uint64_t cmdbuf_gpu_addr;
 uint32_t *cmdbuf_cpu_addr;
 struct delayed_work idle_work;
 bool context_started;

 uint32_t num_instances;
 bool collaborate_mode;
 uint32_t supported_reset;
};
enum UMSCH_SWIP_ENGINE_TYPE {
 UMSCH_SWIP_ENGINE_TYPE_VCN0 = 0,
 UMSCH_SWIP_ENGINE_TYPE_VCN1 = 1,
 UMSCH_SWIP_ENGINE_TYPE_VCN = 2,
 UMSCH_SWIP_ENGINE_TYPE_VPE = 3,
 UMSCH_SWIP_ENGINE_TYPE_MAX
};
enum UMSCH_CONTEXT_PRIORITY_LEVEL {
 CONTEXT_PRIORITY_LEVEL_IDLE = 0,
 CONTEXT_PRIORITY_LEVEL_NORMAL = 1,
 CONTEXT_PRIORITY_LEVEL_FOCUS = 2,
 CONTEXT_PRIORITY_LEVEL_REALTIME = 3,
 CONTEXT_PRIORITY_NUM_LEVELS
};
struct umsch_mm_add_queue_input {
 uint32_t process_id;
 uint64_t page_table_base_addr;
 uint64_t process_va_start;
 uint64_t process_va_end;
 uint64_t process_quantum;
 uint64_t process_csa_addr;
 uint64_t context_quantum;
 uint64_t context_csa_addr;
 uint32_t inprocess_context_priority;
 enum UMSCH_CONTEXT_PRIORITY_LEVEL context_global_priority_level;
 uint32_t doorbell_offset_0;
 uint32_t doorbell_offset_1;
 enum UMSCH_SWIP_ENGINE_TYPE engine_type;
 uint32_t affinity;
 uint64_t mqd_addr;
 uint64_t h_context;
 uint64_t h_queue;
 uint32_t vm_context_cntl;

 uint32_t process_csa_array_index;
 uint32_t context_csa_array_index;

 struct {
  uint32_t is_context_suspended : 1;
  uint32_t collaboration_mode : 1;
  uint32_t reserved : 30;
 };
};
struct umsch_mm_remove_queue_input {
 uint32_t doorbell_offset_0;
 uint32_t doorbell_offset_1;
 uint64_t context_csa_addr;
 uint32_t context_csa_array_index;
};
struct amdgpu_umsch_mm;
struct umsch_mm_funcs {
 int (*set_hw_resources)(struct amdgpu_umsch_mm *umsch);
 int (*add_queue)(struct amdgpu_umsch_mm *umsch,
    struct umsch_mm_add_queue_input *input);
 int (*remove_queue)(struct amdgpu_umsch_mm *umsch,
       struct umsch_mm_remove_queue_input *input);
 int (*set_regs)(struct amdgpu_umsch_mm *umsch);
 int (*init_microcode)(struct amdgpu_umsch_mm *umsch);
 int (*load_microcode)(struct amdgpu_umsch_mm *umsch);
 int (*ring_init)(struct amdgpu_umsch_mm *umsch);
 int (*ring_start)(struct amdgpu_umsch_mm *umsch);
 int (*ring_stop)(struct amdgpu_umsch_mm *umsch);
 int (*ring_fini)(struct amdgpu_umsch_mm *umsch);
};
struct amdgpu_umsch_mm {
 struct amdgpu_ring ring;

 uint32_t rb_wptr;
 uint32_t rb_rptr;

 const struct umsch_mm_funcs *funcs;

 const struct firmware *fw;
 uint32_t fw_version;
 uint32_t feature_version;

 struct amdgpu_bo *ucode_fw_obj;
 uint64_t ucode_fw_gpu_addr;
 uint32_t *ucode_fw_ptr;
 uint64_t irq_start_addr;
 uint64_t uc_start_addr;
 uint32_t ucode_size;

 struct amdgpu_bo *data_fw_obj;
 uint64_t data_fw_gpu_addr;
 uint32_t *data_fw_ptr;
 uint64_t data_start_addr;
 uint32_t data_size;

 struct amdgpu_bo *cmd_buf_obj;
 uint64_t cmd_buf_gpu_addr;
 uint32_t *cmd_buf_ptr;
 uint32_t *cmd_buf_curr_ptr;

 uint32_t wb_index;
 uint64_t sch_ctx_gpu_addr;
 uint32_t *sch_ctx_cpu_addr;

 uint32_t vmid_mask_mm_vcn;
 uint32_t vmid_mask_mm_vpe;
 uint32_t engine_mask;
 uint32_t vcn0_hqd_mask;
 uint32_t vcn1_hqd_mask;
 uint32_t vcn_hqd_mask[2];
 uint32_t vpe_hqd_mask;
 uint32_t agdb_index[CONTEXT_PRIORITY_NUM_LEVELS];

 struct mutex mutex_hidden;
 struct amdgpu_bo *dbglog_bo;
 void *log_cpu_addr;
 uint64_t log_gpu_addr;
 uint32_t mem_size;
 uint32_t log_offset;
};
struct task_barrier {
 unsigned int n;
 atomic_t count;
 struct semaphore enter_turnstile;
 struct semaphore exit_turnstile;
};
struct amdgpu_hive_info {
 struct kobject kobj;
 uint64_t hive_id;
 struct list_head device_list;
 struct list_head node;
 atomic_t number_devices;
 struct mutex hive_lock;
 int hi_req_count;
 struct amdgpu_device *hi_req_gpu;
 struct task_barrier tb;
 enum {
  AMDGPU_XGMI_PSTATE_MIN,
  AMDGPU_XGMI_PSTATE_MAX_VEGA20,
  AMDGPU_XGMI_PSTATE_UNKNOWN
 } pstate;

 struct amdgpu_reset_domain *reset_domain;
 atomic_t ras_recovery;
 struct ras_event_manager event_mgr;
 struct work_struct reset_on_init_work;
 atomic_t requested_nps_mode;
};
struct amdgpu_xgmi_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_xgmi {

 u64 node_id;
 u64 hive_id;

 u64 node_segment_size;

 unsigned physical_node_id;

 unsigned num_physical_nodes;

 struct list_head head;
 bool supported;
 struct ras_common_if *ras_if;
 bool connected_to_cpu;
 struct amdgpu_xgmi_ras *ras;
 uint16_t max_speed;
 uint8_t max_width;
};
struct firmware;
enum amdgpu_memory_partition {
 UNKNOWN_MEMORY_PARTITION_MODE = 0,
 AMDGPU_NPS1_PARTITION_MODE = 1,
 AMDGPU_NPS2_PARTITION_MODE = 2,
 AMDGPU_NPS3_PARTITION_MODE = 3,
 AMDGPU_NPS4_PARTITION_MODE = 4,
 AMDGPU_NPS6_PARTITION_MODE = 6,
 AMDGPU_NPS8_PARTITION_MODE = 8,
};
struct amdgpu_gmc_fault {
 uint64_t timestamp:48;
 uint64_t next:8;
 atomic64_t key;
 uint64_t timestamp_expiry:48;
};
struct amdgpu_vmhub_funcs {
 void (*print_l2_protection_fault_status)(struct amdgpu_device *adev,
       uint32_t status);
 uint32_t (*get_invalidate_req)(unsigned int vmid, uint32_t flush_type);
};
struct amdgpu_vmhub {
 uint32_t ctx0_ptb_addr_lo32;
 uint32_t ctx0_ptb_addr_hi32;
 uint32_t vm_inv_eng0_sem;
 uint32_t vm_inv_eng0_req;
 uint32_t vm_inv_eng0_ack;
 uint32_t vm_context0_cntl;
 uint32_t vm_l2_pro_fault_status;
 uint32_t vm_l2_pro_fault_cntl;





 uint32_t ctx_distance;
 uint32_t ctx_addr_distance;
 uint32_t eng_distance;
 uint32_t eng_addr_distance;

 uint32_t vm_cntx_cntl;
 uint32_t vm_cntx_cntl_vm_fault;
 uint32_t vm_l2_bank_select_reserved_cid2;

 uint32_t vm_contexts_disable;

 bool sdma_invalidation_workaround;

 const struct amdgpu_vmhub_funcs *vmhub_funcs;
};
struct amdgpu_gmc_funcs {

 void (*flush_gpu_tlb)(struct amdgpu_device *adev, uint32_t vmid,
    uint32_t vmhub, uint32_t flush_type);

 void (*flush_gpu_tlb_pasid)(struct amdgpu_device *adev, uint16_t pasid,
        uint32_t flush_type, bool all_hub,
        uint32_t inst);

 uint64_t (*emit_flush_gpu_tlb)(struct amdgpu_ring *ring, unsigned vmid,
           uint64_t pd_addr);

 void (*emit_pasid_mapping)(struct amdgpu_ring *ring, unsigned vmid,
       unsigned pasid);

 void (*set_prt)(struct amdgpu_device *adev, bool enable);

 void (*get_vm_pde)(struct amdgpu_device *adev, int level,
      u64 *dst, u64 *flags);

 void (*get_vm_pte)(struct amdgpu_device *adev,
      struct amdgpu_vm *vm,
      struct amdgpu_bo *bo,
      uint32_t vm_flags,
      uint64_t *pte_flags);

 void (*override_vm_pte_flags)(struct amdgpu_device *dev,
          struct amdgpu_vm *vm,
          uint64_t addr, uint64_t *flags);

 unsigned int (*get_vbios_fb_size)(struct amdgpu_device *adev);

 unsigned int (*get_dcc_alignment)(struct amdgpu_device *adev);

 enum amdgpu_memory_partition (*query_mem_partition_mode)(
  struct amdgpu_device *adev);

 int (*request_mem_partition_mode)(struct amdgpu_device *adev,
       int nps_mode);
 bool (*need_reset_on_init)(struct amdgpu_device *adev);
};
struct amdgpu_mem_partition_info {
 union {
  struct {
   uint32_t fpfn;
   uint32_t lpfn;
  } range;
  struct {
   int node;
  } numa;
 };
 uint64_t size;
};
struct amdgpu_gmc {





 resource_size_t aper_size;
 resource_size_t aper_base;


 u64 mc_vram_size;
 u64 visible_vram_size;
 u64 agp_size;
 u64 agp_start;
 u64 agp_end;
 u64 gart_size;
 u64 gart_start;
 u64 gart_end;
 u64 vram_start;
 u64 vram_end;






 u64 fb_start;
 u64 fb_end;
 unsigned vram_width;
 u64 real_vram_size;
 int vram_mtrr;
 u64 mc_mask;
 const struct firmware *fw;
 uint32_t fw_version;
 struct amdgpu_irq_src vm_fault;
 uint32_t vram_type;
 uint8_t vram_vendor;
 uint32_t srbm_soft_reset;
 bool prt_warning;
 uint32_t sdpif_register;

 u64 shared_aperture_start;
 u64 shared_aperture_end;
 u64 private_aperture_start;
 u64 private_aperture_end;

 spinlock_t invalidate_lock;
 bool translate_further;
 struct kfd_vm_fault_info *vm_fault_info;
 atomic_t vm_fault_info_updated;

 struct amdgpu_gmc_fault fault_ring[(1 << 8)];
 struct {
  uint64_t idx:8;
 } fault_hash[(1 << 8)];
 uint64_t last_fault:8;

 bool tmz_enabled;
 bool is_app_apu;

 struct amdgpu_mem_partition_info *mem_partitions;
 uint8_t num_mem_partitions;
 const struct amdgpu_gmc_funcs *gmc_funcs;
 enum amdgpu_memory_partition requested_nps_mode;
 uint32_t supported_nps_modes;
 uint32_t reset_flags;

 struct amdgpu_xgmi xgmi;
 struct amdgpu_irq_src ecc_irq;
 int noretry;
 uint32_t xnack_flags;

 uint32_t vmid0_page_table_block_size;
 uint32_t vmid0_page_table_depth;
 struct amdgpu_bo *pdb0_bo;

 void *ptr_pdb0;


 u64 mall_size;
 uint32_t m_half_use;


 int num_umc;

 u64 VM_L2_CNTL;
 u64 VM_L2_CNTL2;
 u64 VM_DUMMY_PAGE_FAULT_CNTL;
 u64 VM_DUMMY_PAGE_FAULT_ADDR_LO32;
 u64 VM_DUMMY_PAGE_FAULT_ADDR_HI32;
 u64 VM_L2_PROTECTION_FAULT_CNTL;
 u64 VM_L2_PROTECTION_FAULT_CNTL2;
 u64 VM_L2_PROTECTION_FAULT_MM_CNTL3;
 u64 VM_L2_PROTECTION_FAULT_MM_CNTL4;
 u64 VM_L2_PROTECTION_FAULT_ADDR_LO32;
 u64 VM_L2_PROTECTION_FAULT_ADDR_HI32;
 u64 VM_DEBUG;
 u64 VM_L2_MM_GROUP_RT_CLASSES;
 u64 VM_L2_BANK_SELECT_RESERVED_CID;
 u64 VM_L2_BANK_SELECT_RESERVED_CID2;
 u64 VM_L2_CACHE_PARITY_CNTL;
 u64 VM_L2_IH_LOG_CNTL;
 u64 VM_CONTEXT_CNTL[16];
 u64 VM_CONTEXT_PAGE_TABLE_BASE_ADDR_LO32[16];
 u64 VM_CONTEXT_PAGE_TABLE_BASE_ADDR_HI32[16];
 u64 VM_CONTEXT_PAGE_TABLE_START_ADDR_LO32[16];
 u64 VM_CONTEXT_PAGE_TABLE_START_ADDR_HI32[16];
 u64 VM_CONTEXT_PAGE_TABLE_END_ADDR_LO32[16];
 u64 VM_CONTEXT_PAGE_TABLE_END_ADDR_HI32[16];
 u64 MC_VM_MX_L1_TLB_CNTL;

 u64 noretry_flags;

 bool flush_tlb_needs_extra_type_0;
 bool flush_tlb_needs_extra_type_2;
 bool flush_pasid_uses_kiq;
};
struct amdgpu_sdma_funcs {
 int (*stop_kernel_queue)(struct amdgpu_ring *ring);
 int (*start_kernel_queue)(struct amdgpu_ring *ring);
 int (*soft_reset_kernel_queue)(struct amdgpu_device *adev, u32 instance_id);
};
struct amdgpu_sdma_instance {

 const struct firmware *fw;
 uint32_t fw_version;
 uint32_t feature_version;

 struct amdgpu_ring ring;
 struct amdgpu_ring page;
 bool burst_nop;
 uint32_t aid_id;

 struct amdgpu_bo *sdma_fw_obj;
 uint64_t sdma_fw_gpu_addr;
 uint32_t *sdma_fw_ptr;
 struct mutex engine_reset_mutex;

 bool gfx_guilty;
 bool page_guilty;
 const struct amdgpu_sdma_funcs *funcs;
};
struct amdgpu_sdma_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_sdma {
 struct amdgpu_sdma_instance instance[16];
 struct amdgpu_irq_src trap_irq;
 struct amdgpu_irq_src illegal_inst_irq;
 struct amdgpu_irq_src fence_irq;
 struct amdgpu_irq_src ecc_irq;
 struct amdgpu_irq_src vm_hole_irq;
 struct amdgpu_irq_src doorbell_invalid_irq;
 struct amdgpu_irq_src pool_timeout_irq;
 struct amdgpu_irq_src srbm_write_irq;
 struct amdgpu_irq_src ctxt_empty_irq;

 int num_instances;
 uint32_t sdma_mask;
 int num_inst_per_aid;
 uint32_t srbm_soft_reset;
 bool has_page_queue;
 struct ras_common_if *ras_if;
 struct amdgpu_sdma_ras *ras;
 uint32_t *ip_dump;
 uint32_t supported_reset;
 struct list_head reset_callback_list;
 bool no_user_submission;
 bool disable_uq;
};
struct amdgpu_buffer_funcs {

 uint32_t copy_max_bytes;


 unsigned copy_num_dw;


 void (*emit_copy_buffer)(struct amdgpu_ib *ib,

     uint64_t src_offset,

     uint64_t dst_offset,

     uint32_t byte_count,
     uint32_t copy_flags);


 uint32_t fill_max_bytes;


 unsigned fill_num_dw;


 void (*emit_fill_buffer)(struct amdgpu_ib *ib,

     uint32_t src_data,

     uint64_t dst_offset,

     uint32_t byte_count);
};
struct amdgpu_lsdma {
 const struct amdgpu_lsdma_funcs *funcs;
};
struct amdgpu_lsdma_funcs {
 int (*copy_mem)(struct amdgpu_device *adev, uint64_t src_addr,
   uint64_t dst_addr, uint64_t size);
 int (*fill_mem)(struct amdgpu_device *adev, uint64_t dst_addr,
   uint32_t data, uint64_t size);
 void (*update_memory_power_gating)(struct amdgpu_device *adev, bool enable);
};
struct nbio_hdp_flush_reg {
 u32 ref_and_mask_cp0;
 u32 ref_and_mask_cp1;
 u32 ref_and_mask_cp2;
 u32 ref_and_mask_cp3;
 u32 ref_and_mask_cp4;
 u32 ref_and_mask_cp5;
 u32 ref_and_mask_cp6;
 u32 ref_and_mask_cp7;
 u32 ref_and_mask_cp8;
 u32 ref_and_mask_cp9;
 u32 ref_and_mask_sdma0;
 u32 ref_and_mask_sdma1;
 u32 ref_and_mask_sdma2;
 u32 ref_and_mask_sdma3;
 u32 ref_and_mask_sdma4;
 u32 ref_and_mask_sdma5;
 u32 ref_and_mask_sdma6;
 u32 ref_and_mask_sdma7;
};
struct amdgpu_nbio_ras {
 struct amdgpu_ras_block_object ras_block;
 void (*handle_ras_controller_intr_no_bifring)(struct amdgpu_device *adev);
 void (*handle_ras_err_event_athub_intr_no_bifring)(struct amdgpu_device *adev);
 int (*init_ras_controller_interrupt)(struct amdgpu_device *adev);
 int (*init_ras_err_event_athub_interrupt)(struct amdgpu_device *adev);
};
struct amdgpu_nbio_funcs {
 const struct nbio_hdp_flush_reg *hdp_flush_reg;
 u32 (*get_hdp_flush_req_offset)(struct amdgpu_device *adev);
 u32 (*get_hdp_flush_done_offset)(struct amdgpu_device *adev);
 u32 (*get_pcie_index_offset)(struct amdgpu_device *adev);
 u32 (*get_pcie_data_offset)(struct amdgpu_device *adev);
 u32 (*get_pcie_index_hi_offset)(struct amdgpu_device *adev);
 u32 (*get_pcie_port_index_offset)(struct amdgpu_device *adev);
 u32 (*get_pcie_port_data_offset)(struct amdgpu_device *adev);
 u32 (*get_rev_id)(struct amdgpu_device *adev);
 void (*mc_access_enable)(struct amdgpu_device *adev, bool enable);
 u32 (*get_memsize)(struct amdgpu_device *adev);
 void (*sdma_doorbell_range)(struct amdgpu_device *adev, int instance,
   bool use_doorbell, int doorbell_index, int doorbell_size);
 void (*vpe_doorbell_range)(struct amdgpu_device *adev, int instance,
   bool use_doorbell, int doorbell_index, int doorbell_size);
 void (*vcn_doorbell_range)(struct amdgpu_device *adev, bool use_doorbell,
       int doorbell_index, int instance);
 void (*gc_doorbell_init)(struct amdgpu_device *adev);
 void (*enable_doorbell_aperture)(struct amdgpu_device *adev,
      bool enable);
 void (*enable_doorbell_selfring_aperture)(struct amdgpu_device *adev,
        bool enable);
 void (*ih_doorbell_range)(struct amdgpu_device *adev,
      bool use_doorbell, int doorbell_index);
 void (*enable_doorbell_interrupt)(struct amdgpu_device *adev,
       bool enable);
 void (*update_medium_grain_clock_gating)(struct amdgpu_device *adev,
       bool enable);
 void (*update_medium_grain_light_sleep)(struct amdgpu_device *adev,
      bool enable);
 void (*get_clockgating_state)(struct amdgpu_device *adev,
          u64 *flags);
 void (*ih_control)(struct amdgpu_device *adev);
 void (*init_registers)(struct amdgpu_device *adev);
 void (*remap_hdp_registers)(struct amdgpu_device *adev);
 void (*enable_aspm)(struct amdgpu_device *adev,
       bool enable);
 void (*program_aspm)(struct amdgpu_device *adev);
 void (*apply_lc_spc_mode_wa)(struct amdgpu_device *adev);
 void (*apply_l1_link_width_reconfig_wa)(struct amdgpu_device *adev);
 void (*clear_doorbell_interrupt)(struct amdgpu_device *adev);
 u32 (*get_rom_offset)(struct amdgpu_device *adev);
 int (*get_compute_partition_mode)(struct amdgpu_device *adev);
 u32 (*get_memory_partition_mode)(struct amdgpu_device *adev,
      u32 *supp_modes);
 bool (*is_nps_switch_requested)(struct amdgpu_device *adev);
 u64 (*get_pcie_replay_count)(struct amdgpu_device *adev);
 void (*set_reg_remap)(struct amdgpu_device *adev);
};
struct amdgpu_nbio {
 const struct nbio_hdp_flush_reg *hdp_flush_reg;
 struct amdgpu_irq_src ras_controller_irq;
 struct amdgpu_irq_src ras_err_event_athub_irq;
 struct ras_common_if *ras_if;
 const struct amdgpu_nbio_funcs *funcs;
 struct amdgpu_nbio_ras *ras;
};
struct amdgpu_hdp_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_hdp_funcs {
 void (*flush_hdp)(struct amdgpu_device *adev, struct amdgpu_ring *ring);
 void (*invalidate_hdp)(struct amdgpu_device *adev,
          struct amdgpu_ring *ring);
 void (*update_clock_gating)(struct amdgpu_device *adev, bool enable);
 void (*get_clock_gating_state)(struct amdgpu_device *adev, u64 *flags);
 void (*init_registers)(struct amdgpu_device *adev);
};
struct amdgpu_hdp {
 struct ras_common_if *ras_if;
 const struct amdgpu_hdp_funcs *funcs;
 struct amdgpu_hdp_ras *ras;
};
struct ddc;
struct drm_dp_mst_port;
struct drm_writeback_connector {



 struct drm_connector base;
 struct drm_encoder encoder;
 struct drm_property_blob *pixel_formats_blob_ptr;


 spinlock_t job_lock;
 struct list_head job_queue;






 unsigned int fence_context;





 spinlock_t fence_lock;






 unsigned long fence_seqno;





 char timeline_name[32];
};
struct drm_writeback_job {





 struct drm_writeback_connector *connector;






 bool prepared;







 struct work_struct cleanup_work;






 struct list_head list_entry;







 struct drm_framebuffer *fb;






 struct dma_fence *out_fence;






 void *priv;
};
struct dal_logger {
 struct drm_device *dev;
};
struct dc_context;
struct dc_link;
struct dc_state;
struct dmub_srv;
struct dc_dmub_srv;
struct dc_stream_state;
struct mod_vrr_params;
enum adaptive_sync_type {
 ADAPTIVE_SYNC_TYPE_NONE = 0,
 ADAPTIVE_SYNC_TYPE_DP = 1,
 FREESYNC_TYPE_PCON_IN_WHITELIST = 2,
 FREESYNC_TYPE_PCON_NOT_IN_WHITELIST = 3,
 ADAPTIVE_SYNC_TYPE_EDP = 4,
};
struct amdgpu_device;
struct amdgpu_crtc;
struct drm_device;
struct dc;
struct amdgpu_bo;
struct dmub_srv;
struct dmub_notification;
struct common_irq_params {
 struct amdgpu_device *adev;
 enum dc_irq_source irq_src;
 atomic64_t previous_timestamp;
};
struct dm_compressor_info {
 void *cpu_addr;
 struct amdgpu_bo *bo_ptr;
 uint64_t gpu_addr;
};
typedef void (*dmub_notify_interrupt_callback_t)(struct amdgpu_device *adev, struct dmub_notification *notify);
struct idle_workqueue {
 struct work_struct work;
 struct amdgpu_display_manager *dm;
 bool enable;
 bool running;
};
struct amdgpu_dm_luminance_data {
 u8 luminance;
 u8 input_signal;
} __attribute__((__packed__));
struct amdgpu_dm_backlight_caps {




 union dpcd_sink_ext_caps *ext_caps;



 u32 aux_min_input_signal;




 u32 aux_max_input_signal;



 int min_input_signal;



 int max_input_signal;



 bool caps_valid;



 bool aux_support;




 u32 brightness_mask;



 u8 ac_level;



 u8 dc_level;



 u8 data_points;



 struct amdgpu_dm_luminance_data luminance_data[99];
};
struct hpd_rx_irq_offload_work_queue {



 struct workqueue_struct *wq;



 spinlock_t offload_lock;




 bool is_handling_link_loss;




 bool is_handling_mst_msg_rdy_event;



 struct amdgpu_dm_connector *aconnector;
};
struct amdgpu_display_manager {

 struct dc *dc;
 struct dmub_srv *dmub_srv;







 struct dmub_notification *dmub_notify;







 dmub_notify_interrupt_callback_t dmub_callback[8];







 bool dmub_thread_offload[8];






 struct dmub_srv_fb_info *dmub_fb_info;






 const struct firmware *dmub_fw;






 struct amdgpu_bo *dmub_bo;






 u64 dmub_bo_gpu_addr;






 void *dmub_bo_cpu_addr;






 uint32_t dmcub_fw_version;







 struct cgs_device *cgs_device;

 struct amdgpu_device *adev;
 struct drm_device *ddev;
 u16 display_indexes_num;
 struct drm_private_obj atomic_obj;







 struct mutex dc_lock;






 struct mutex audio_lock;






 struct drm_audio_component *audio_component;







 bool audio_registered;
 struct list_head irq_handler_list_low_tab[DAL_IRQ_SOURCES_NUMBER];
 struct list_head irq_handler_list_high_tab[DAL_IRQ_SOURCES_NUMBER];







 struct common_irq_params
 pflip_params[DC_IRQ_SOURCE_PFLIP_LAST - DC_IRQ_SOURCE_PFLIP_FIRST + 1];







 struct common_irq_params
 vblank_params[DC_IRQ_SOURCE_VBLANK6 - DC_IRQ_SOURCE_VBLANK1 + 1];







 struct common_irq_params
 vline0_params[DC_IRQ_SOURCE_DC6_VLINE0 - DC_IRQ_SOURCE_DC1_VLINE0 + 1];







 struct common_irq_params
 vupdate_params[DC_IRQ_SOURCE_VUPDATE6 - DC_IRQ_SOURCE_VUPDATE1 + 1];
 spinlock_t irq_reg_lock;







 struct common_irq_params
 dmub_trace_params[1];

 struct common_irq_params
 dmub_outbox_params[1];

 spinlock_t irq_handler_list_table_lock;

 struct backlight_device *backlight_dev[2];

 const struct dc_link *backlight_link[2];

 uint8_t num_of_edps;

 struct amdgpu_dm_backlight_caps backlight_caps[2];

 struct mod_freesync *freesync_module;
 struct hdcp_workqueue *hdcp_workqueue;






 struct workqueue_struct *vblank_control_workqueue;






 struct idle_workqueue *idle_workqueue;

 struct drm_atomic_state *cached_state;
 struct dc_state *cached_dc_state;

 struct dm_compressor_info compressor;

 const struct firmware *fw_dmcu;
 uint32_t dmcu_fw_version;






 const struct gpu_info_soc_bounding_box_v1_0 *soc_bounding_box;






 uint32_t active_vblank_irq_count;
 struct secure_display_context secure_display_ctx;






 struct hpd_rx_irq_offload_work_queue *hpd_rx_offload_wq;





 struct amdgpu_encoder mst_encoders[6];
 bool force_timing_sync;
 bool disable_hpd_irq;
 bool dmcub_trace_event_en;





 struct list_head da_list;
 struct completion dmub_aux_transfer_done;
 struct workqueue_struct *delayed_hpd_wq;






 u32 brightness[2];





 u32 actual_brightness[2];







 bool aux_hpd_discon_quirk;






 bool edp0_on_dp1_quirk;






 struct mutex dpia_aux_lock;







 void *bb_from_dmub;






 void *i2c_devres_group;






 struct amdgpu_i2c_adapter *oem_i2c;






 struct fused_io_sync {
  struct completion replied;
  char reply_data[0x40];
 } fused_io[8];
};
enum dsc_clock_force_state {
 DSC_CLK_FORCE_DEFAULT = 0,
 DSC_CLK_FORCE_ENABLE,
 DSC_CLK_FORCE_DISABLE,
};
struct dsc_preferred_settings {
 enum dsc_clock_force_state dsc_force_enable;
 uint32_t dsc_num_slices_v;
 uint32_t dsc_num_slices_h;
 uint32_t dsc_bits_per_pixel;
 bool dsc_force_disable_passthrough;
};
struct amdgpu_hdmi_vsdb_info {




 unsigned int amd_vsdb_version;




 bool freesync_supported;




 unsigned int min_refresh_rate_hz;




 unsigned int max_refresh_rate_hz;




 bool replay_mode;
};
struct amdgpu_dm_connector {

 struct drm_connector base;
 uint32_t connector_id;
 int bl_idx;

 struct cec_notifier *notifier;



 const struct drm_edid *drm_edid;


 struct amdgpu_hpd hpd;


 int num_modes;



 struct dc_sink *dc_sink;
 struct dc_link *dc_link;




 struct dc_sink *dc_em_sink;


 struct drm_dp_mst_topology_mgr mst_mgr;
 struct amdgpu_dm_dp_aux dm_dp_aux;
 struct drm_dp_mst_port *mst_output_port;
 struct amdgpu_dm_connector *mst_root;
 struct drm_dp_aux *dsc_aux;
 uint32_t mst_local_bw;
 uint16_t vc_full_pbn;
 struct mutex handle_mst_msg_ready;


 uint32_t branch_ieee_oui;


 struct amdgpu_i2c_adapter *i2c;






 int min_vfreq;





 int max_vfreq ;


 int audio_inst;

 struct mutex hpd_lock;

 bool fake_enable;
 bool force_yuv420_output;
 bool force_yuv422_output;
 struct dsc_preferred_settings dsc_settings;
 union dp_downstream_port_present mst_downstream_port_present;

 struct drm_display_mode freesync_vid_base;

 int sr_skip_count;
 bool disallow_edp_enter_psr;
 bool disallow_edp_enter_replay;


 uint8_t mst_status;


 bool timing_changed;
 struct dc_crtc_timing *timing_requested;


 bool pack_sdp_v1_3;
 enum adaptive_sync_type as_type;
 struct amdgpu_hdmi_vsdb_info vsdb_info;


 unsigned int hdmi_hpd_debounce_delay_ms;
 struct delayed_work hdmi_hpd_debounce_work;
 struct dc_sink *hdmi_prev_sink;
};
union amd_sriov_ras_caps {
 struct {
  uint64_t block_umc : 1;
  uint64_t block_sdma : 1;
  uint64_t block_gfx : 1;
  uint64_t block_mmhub : 1;
  uint64_t block_athub : 1;
  uint64_t block_pcie_bif : 1;
  uint64_t block_hdp : 1;
  uint64_t block_xgmi_wafl : 1;
  uint64_t block_df : 1;
  uint64_t block_smn : 1;
  uint64_t block_sem : 1;
  uint64_t block_mp0 : 1;
  uint64_t block_mp1 : 1;
  uint64_t block_fuse : 1;
  uint64_t block_mca : 1;
  uint64_t block_vcn : 1;
  uint64_t block_jpeg : 1;
  uint64_t block_ih : 1;
  uint64_t block_mpio : 1;
  uint64_t poison_propogation_mode : 1;
  uint64_t reserved : 44;
 } bits;
 uint64_t all;
};
struct amd_sriov_msg_pf2vf_info_header {

 uint32_t size;

 uint32_t version;

 uint32_t reserved[2];
};
struct amd_sriov_msg_vf2pf_info_header {

 uint32_t size;

 uint32_t version;

 uint32_t reserved[2];
};
enum amd_sriov_ras_telemetry_gpu_block {
 RAS_TELEMETRY_GPU_BLOCK_UMC = 0,
 RAS_TELEMETRY_GPU_BLOCK_SDMA = 1,
 RAS_TELEMETRY_GPU_BLOCK_GFX = 2,
 RAS_TELEMETRY_GPU_BLOCK_MMHUB = 3,
 RAS_TELEMETRY_GPU_BLOCK_ATHUB = 4,
 RAS_TELEMETRY_GPU_BLOCK_PCIE_BIF = 5,
 RAS_TELEMETRY_GPU_BLOCK_HDP = 6,
 RAS_TELEMETRY_GPU_BLOCK_XGMI_WAFL = 7,
 RAS_TELEMETRY_GPU_BLOCK_DF = 8,
 RAS_TELEMETRY_GPU_BLOCK_SMN = 9,
 RAS_TELEMETRY_GPU_BLOCK_SEM = 10,
 RAS_TELEMETRY_GPU_BLOCK_MP0 = 11,
 RAS_TELEMETRY_GPU_BLOCK_MP1 = 12,
 RAS_TELEMETRY_GPU_BLOCK_FUSE = 13,
 RAS_TELEMETRY_GPU_BLOCK_MCA = 14,
 RAS_TELEMETRY_GPU_BLOCK_VCN = 15,
 RAS_TELEMETRY_GPU_BLOCK_JPEG = 16,
 RAS_TELEMETRY_GPU_BLOCK_IH = 17,
 RAS_TELEMETRY_GPU_BLOCK_MPIO = 18,
 RAS_TELEMETRY_GPU_BLOCK_COUNT = 19,
};
struct amd_sriov_ras_telemetry_error_count {
 struct {
  uint32_t ce_count;
  uint32_t ue_count;
  uint32_t de_count;
  uint32_t ce_overflow_count;
  uint32_t ue_overflow_count;
  uint32_t de_overflow_count;
  uint32_t reserved[6];
 } block[RAS_TELEMETRY_GPU_BLOCK_COUNT];
};
struct amdgpu_mm_table {
 struct amdgpu_bo *bo;
 uint32_t *cpu_addr;
 uint64_t gpu_addr;
};
struct amdgpu_vf_error_buffer {
 struct mutex lock;
 int read_count;
 int write_count;
 uint16_t code[16];
 uint16_t flags[16];
 uint64_t data[16];
};
enum idh_request;
struct amdgpu_virt_ops {
 int (*req_full_gpu)(struct amdgpu_device *adev, bool init);
 int (*rel_full_gpu)(struct amdgpu_device *adev, bool init);
 int (*req_init_data)(struct amdgpu_device *adev);
 int (*reset_gpu)(struct amdgpu_device *adev);
 void (*ready_to_reset)(struct amdgpu_device *adev);
 int (*wait_reset)(struct amdgpu_device *adev);
 void (*trans_msg)(struct amdgpu_device *adev, enum idh_request req,
     u32 data1, u32 data2, u32 data3);
 void (*ras_poison_handler)(struct amdgpu_device *adev,
     enum amdgpu_ras_block block);
 bool (*rcvd_ras_intr)(struct amdgpu_device *adev);
 int (*req_ras_err_count)(struct amdgpu_device *adev);
 int (*req_ras_cper_dump)(struct amdgpu_device *adev, u64 vf_rptr);
 int (*req_bad_pages)(struct amdgpu_device *adev);
 int (*req_ras_chk_criti)(struct amdgpu_device *adev, u64 addr);
};
struct amdgpu_virt_fw_reserve {
 struct amd_sriov_msg_pf2vf_info_header *p_pf2vf;
 struct amd_sriov_msg_vf2pf_info_header *p_vf2pf;
 void *ras_telemetry;
 unsigned int checksum_key;
};
struct amdgpu_virt_ras_err_handler_data {

 struct eeprom_table_record *bps;

 struct amdgpu_bo **bps_bo;

 int count;

 int last_reserved;
};
struct amdgpu_virt_ras {
 struct ratelimit_state ras_error_cnt_rs;
 struct ratelimit_state ras_cper_dump_rs;
 struct ratelimit_state ras_chk_criti_rs;
 struct mutex ras_telemetry_mutex;
 uint64_t cper_rptr;
};
enum amdgpu_virt_cap_id { AMDGPU_VIRT_CAP_POWER_LIMIT, amdgpu_virt_COUNT };
enum { amdgpu_virt_BITMAP_BITS = amdgpu_virt_COUNT * 2 };
struct amdgpu_virt_caps { unsigned long bmap[(((amdgpu_virt_BITMAP_BITS) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; };
struct amdgpu_virt {
 uint32_t caps;
 struct amdgpu_bo *csa_obj;
 void *csa_cpu_addr;
 bool chained_ib_support;
 uint32_t reg_val_offs;
 struct amdgpu_irq_src ack_irq;
 struct amdgpu_irq_src rcv_irq;

 struct work_struct flr_work;
 struct work_struct req_bad_pages_work;
 struct work_struct handle_bad_pages_work;

 struct amdgpu_mm_table mm_table;
 const struct amdgpu_virt_ops *ops;
 struct amdgpu_vf_error_buffer vf_errors;
 struct amdgpu_virt_fw_reserve fw_reserve;
 struct amdgpu_virt_caps virt_caps;
 uint32_t gim_feature;
 uint32_t reg_access_mode;
 int req_init_data_ver;
 bool tdr_debug;
 struct amdgpu_virt_ras_err_handler_data *virt_eh_data;
 bool ras_init_done;
 uint32_t reg_access;


 struct delayed_work vf2pf_work;
 uint32_t vf2pf_update_interval_ms;
 int vf2pf_update_retry_cnt;


 bool is_mm_bw_enabled;
 uint32_t decode_max_dimension_pixels;
 uint32_t decode_max_frame_pixels;
 uint32_t encode_max_dimension_pixels;
 uint32_t encode_max_frame_pixels;


 uint32_t autoload_ucode_id;


 spinlock_t rlcg_reg_lock;

 union amd_sriov_ras_caps ras_en_caps;
 union amd_sriov_ras_caps ras_telemetry_en_caps;
 struct amdgpu_virt_ras ras;
 struct amd_sriov_ras_telemetry_error_count count_cache;


 bool is_xgmi_node_migrate_enabled;
};
struct amdgpu_video_codec_info;
struct amdgpu_device;
struct amdgpu_bo;
struct amdgpu_gart {
 struct amdgpu_bo *bo;

 void *ptr;
 unsigned num_gpu_pages;
 unsigned num_cpu_pages;
 unsigned table_size;


 uint64_t gart_pte_flags;
};
struct amdgpu_doorbell {

 resource_size_t base;
 resource_size_t size;


 u32 num_kernel_doorbells;


 struct amdgpu_bo *kernel_doorbells;


 uint32_t *cpu_addr;
};
struct amdgpu_doorbell_index {
 uint32_t kiq;
 uint32_t mec_ring0;
 uint32_t mec_ring1;
 uint32_t mec_ring2;
 uint32_t mec_ring3;
 uint32_t mec_ring4;
 uint32_t mec_ring5;
 uint32_t mec_ring6;
 uint32_t mec_ring7;
 uint32_t userqueue_start;
 uint32_t userqueue_end;
 uint32_t gfx_ring0;
 uint32_t gfx_ring1;
 uint32_t gfx_userqueue_start;
 uint32_t gfx_userqueue_end;
 uint32_t sdma_engine[16];
 uint32_t mes_ring0;
 uint32_t mes_ring1;
 uint32_t ih;
 union {
  struct {
   uint32_t vcn_ring0_1;
   uint32_t vcn_ring2_3;
   uint32_t vcn_ring4_5;
   uint32_t vcn_ring6_7;
  } vcn;
  struct {
   uint32_t uvd_ring0_1;
   uint32_t uvd_ring2_3;
   uint32_t uvd_ring4_5;
   uint32_t uvd_ring6_7;
   uint32_t vce_ring0_1;
   uint32_t vce_ring2_3;
   uint32_t vce_ring4_5;
   uint32_t vce_ring6_7;
  } uvd_vce;
 };
 uint32_t vpe_ring;
 uint32_t first_non_cp;
 uint32_t last_non_cp;
 uint32_t max_assignment;

 uint32_t sdma_doorbell_range;

 uint32_t xcc_doorbell_range;
};
struct drm_client_dev;
struct drm_device;
struct drm_file;
struct drm_framebuffer;
struct drm_gem_object;
struct drm_minor;
struct module;
struct drm_client_funcs {



 struct module *owner;
 void (*unregister)(struct drm_client_dev *client);
 int (*restore)(struct drm_client_dev *client, bool force);
 int (*hotplug)(struct drm_client_dev *client);
 int (*suspend)(struct drm_client_dev *client);
 int (*resume)(struct drm_client_dev *client);
};
struct drm_client_dev {



 struct drm_device *dev;




 const char *name;







 struct list_head list;




 const struct drm_client_funcs *funcs;




 struct drm_file *file;




 struct mutex modeset_mutex;




 struct drm_mode_set *modesets;






 bool suspended;







 bool hotplug_pending;







 bool hotplug_failed;
};
struct amdgpu_device;
struct kgd_mem {
 struct mutex lock;
 struct amdgpu_bo *bo;
 struct dma_buf *dmabuf;
 struct hmm_range *range;
 struct list_head attachments;

 struct list_head validate_list;
 uint32_t domain;
 unsigned int mapped_to_gpu_memory;
 uint64_t va;

 uint32_t alloc_flags;

 uint32_t invalid;
 struct amdkfd_process_info *process_info;

 struct amdgpu_sync sync;

 uint32_t gem_handle;
 bool aql_queue;
 bool is_imported;
};
struct amdgpu_amdkfd_fence {
 struct dma_fence base;
 struct mm_struct *mm;
 spinlock_t lock;
 char timeline_name[TASK_COMM_LEN];
 struct svm_range_bo *svm_bo;
};
struct amdgpu_kfd_dev {
 struct kfd_dev *dev;
 int64_t vram_used[8];
 uint64_t vram_used_aligned[8];
 bool init_complete;
 struct work_struct reset_work;


 struct drm_client_dev client;




 struct dev_pagemap pgmap;
};
struct amdkfd_process_info {

 struct list_head vm_list_head;

 struct list_head kfd_bo_list;

 struct list_head userptr_valid_list;
 struct list_head userptr_inval_list;

 struct mutex lock;


 unsigned int n_vms;

 struct amdgpu_amdkfd_fence *eviction_fence;


 struct mutex notifier_lock;
 uint32_t evicted_bos;
 struct delayed_work restore_userptr_work;
 struct pid *pid;
 bool block_mmu_notifications;
};
enum amdgpu_mes_priority_level {
 AMDGPU_MES_PRIORITY_LEVEL_LOW = 0,
 AMDGPU_MES_PRIORITY_LEVEL_NORMAL = 1,
 AMDGPU_MES_PRIORITY_LEVEL_MEDIUM = 2,
 AMDGPU_MES_PRIORITY_LEVEL_HIGH = 3,
 AMDGPU_MES_PRIORITY_LEVEL_REALTIME = 4,
 AMDGPU_MES_PRIORITY_NUM_LEVELS
};
struct amdgpu_mes_funcs;
enum amdgpu_mes_pipe {
 AMDGPU_MES_SCHED_PIPE = 0,
 AMDGPU_MES_KIQ_PIPE,
 AMDGPU_MAX_MES_PIPES = 2,
};
struct amdgpu_mes {
 struct amdgpu_device *adev;

 struct mutex mutex_hidden;

 struct idr pasid_idr;
 struct idr gang_id_idr;
 struct idr queue_id_idr;
 struct ida doorbell_ida;

 spinlock_t queue_id_lock;

 uint32_t sched_version;
 uint32_t kiq_version;
 uint32_t fw_version[AMDGPU_MAX_MES_PIPES];
 bool enable_legacy_queue_map;

 uint32_t total_max_queue;
 uint32_t max_doorbell_slices;

 uint64_t default_process_quantum;
 uint64_t default_gang_quantum;

 struct amdgpu_ring ring[AMDGPU_MAX_MES_PIPES];
 spinlock_t ring_lock[AMDGPU_MAX_MES_PIPES];

 const struct firmware *fw[AMDGPU_MAX_MES_PIPES];


 struct amdgpu_bo *ucode_fw_obj[AMDGPU_MAX_MES_PIPES];
 uint64_t ucode_fw_gpu_addr[AMDGPU_MAX_MES_PIPES];
 uint32_t *ucode_fw_ptr[AMDGPU_MAX_MES_PIPES];
 uint64_t uc_start_addr[AMDGPU_MAX_MES_PIPES];


 struct amdgpu_bo *data_fw_obj[AMDGPU_MAX_MES_PIPES];
 uint64_t data_fw_gpu_addr[AMDGPU_MAX_MES_PIPES];
 uint32_t *data_fw_ptr[AMDGPU_MAX_MES_PIPES];
 uint64_t data_start_addr[AMDGPU_MAX_MES_PIPES];


 struct amdgpu_bo *eop_gpu_obj[AMDGPU_MAX_MES_PIPES];
 uint64_t eop_gpu_addr[AMDGPU_MAX_MES_PIPES];

 void *mqd_backup[AMDGPU_MAX_MES_PIPES];
 struct amdgpu_irq_src irq[AMDGPU_MAX_MES_PIPES];

 uint32_t vmid_mask_gfxhub;
 uint32_t vmid_mask_mmhub;
 uint32_t gfx_hqd_mask[2];
 uint32_t compute_hqd_mask[8];
 uint32_t sdma_hqd_mask[2];
 uint32_t aggregated_doorbells[AMDGPU_MES_PRIORITY_NUM_LEVELS];
 uint32_t sch_ctx_offs[AMDGPU_MAX_MES_PIPES];
 uint64_t sch_ctx_gpu_addr[AMDGPU_MAX_MES_PIPES];
 uint64_t *sch_ctx_ptr[AMDGPU_MAX_MES_PIPES];
 uint32_t query_status_fence_offs[AMDGPU_MAX_MES_PIPES];
 uint64_t query_status_fence_gpu_addr[AMDGPU_MAX_MES_PIPES];
 uint64_t *query_status_fence_ptr[AMDGPU_MAX_MES_PIPES];

 uint32_t saved_flags;


 int (*kiq_hw_init)(struct amdgpu_device *adev);
 int (*kiq_hw_fini)(struct amdgpu_device *adev);


 uint32_t db_start_dw_offset;
 uint32_t num_mes_dbs;
 unsigned long *doorbell_bitmap;


 uint32_t event_log_size;
 struct amdgpu_bo *event_log_gpu_obj;
 uint64_t event_log_gpu_addr;
 void *event_log_cpu_addr;


 const struct amdgpu_mes_funcs *funcs;


 struct amdgpu_bo *resource_1[AMDGPU_MAX_MES_PIPES];
 uint64_t resource_1_gpu_addr[AMDGPU_MAX_MES_PIPES];
 void *resource_1_addr[AMDGPU_MAX_MES_PIPES];

 int hung_queue_db_array_size;
 int hung_queue_hqd_info_offset;
 struct amdgpu_bo *hung_queue_db_array_gpu_obj;
 uint64_t hung_queue_db_array_gpu_addr;
 void *hung_queue_db_array_cpu_addr;
};
struct mes_add_queue_input {
 uint32_t process_id;
 uint64_t page_table_base_addr;
 uint64_t process_va_start;
 uint64_t process_va_end;
 uint64_t process_quantum;
 uint64_t process_context_addr;
 uint64_t gang_quantum;
 uint64_t gang_context_addr;
 uint32_t inprocess_gang_priority;
 uint32_t gang_global_priority_level;
 uint32_t doorbell_offset;
 uint64_t mqd_addr;
 uint64_t wptr_addr;
 uint64_t wptr_mc_addr;
 uint32_t queue_type;
 uint32_t paging;
 uint32_t gws_base;
 uint32_t gws_size;
 uint64_t tba_addr;
 uint64_t tma_addr;
 uint32_t trap_en;
 uint32_t skip_process_ctx_clear;
 uint32_t is_kfd_process;
 uint32_t is_aql_queue;
 uint32_t queue_size;
 uint32_t exclusively_scheduled;
};
struct mes_remove_queue_input {
 uint32_t doorbell_offset;
 uint64_t gang_context_addr;
};
struct mes_map_legacy_queue_input {
 uint32_t queue_type;
 uint32_t doorbell_offset;
 uint32_t pipe_id;
 uint32_t queue_id;
 uint64_t mqd_addr;
 uint64_t wptr_addr;
};
struct mes_unmap_legacy_queue_input {
 enum amdgpu_unmap_queues_action action;
 uint32_t queue_type;
 uint32_t doorbell_offset;
 uint32_t pipe_id;
 uint32_t queue_id;
 uint64_t trail_fence_addr;
 uint64_t trail_fence_data;
};
struct mes_suspend_gang_input {
 bool suspend_all_gangs;
 uint64_t gang_context_addr;
 uint64_t suspend_fence_addr;
 uint32_t suspend_fence_value;
};
struct mes_resume_gang_input {
 bool resume_all_gangs;
 uint64_t gang_context_addr;
};
struct mes_reset_queue_input {
 uint32_t queue_type;
 uint32_t doorbell_offset;
 bool use_mmio;
 uint32_t me_id;
 uint32_t pipe_id;
 uint32_t queue_id;
 uint64_t mqd_addr;
 uint64_t wptr_addr;
 uint32_t vmid;
 bool legacy_gfx;
 bool is_kq;
};
struct mes_detect_and_reset_queue_input {
 uint32_t queue_type;
 bool detect_only;
};
struct mes_inv_tlbs_pasid_input {
 uint32_t xcc_id;
 uint16_t pasid;
 uint8_t hub_id;
 uint8_t flush_type;
};
enum mes_misc_opcode {
 MES_MISC_OP_WRITE_REG,
 MES_MISC_OP_READ_REG,
 MES_MISC_OP_WRM_REG_WAIT,
 MES_MISC_OP_WRM_REG_WR_WAIT,
 MES_MISC_OP_SET_SHADER_DEBUGGER,
 MES_MISC_OP_CHANGE_CONFIG,
};
struct mes_misc_op_input {
 enum mes_misc_opcode op;

 union {
  struct {
   uint32_t reg_offset;
   uint64_t buffer_addr;
  } read_reg;

  struct {
   uint32_t reg_offset;
   uint32_t reg_value;
  } write_reg;

  struct {
   uint32_t ref;
   uint32_t mask;
   uint32_t reg0;
   uint32_t reg1;
  } wrm_reg;

  struct {
   uint64_t process_context_addr;
   union {
    struct {
     uint32_t single_memop : 1;
     uint32_t single_alu_op : 1;
     uint32_t reserved: 29;
     uint32_t process_ctx_flush: 1;
    };
    uint32_t u32all;
   } flags;
   uint32_t spi_gdbg_per_vmid_cntl;
   uint32_t tcp_watch_cntl[4];
   uint32_t trap_en;
  } set_shader_debugger;

  struct {
   union {
    struct {
     uint32_t limit_single_process : 1;
     uint32_t enable_hws_logging_buffer : 1;
     uint32_t reserved : 30;
    };
    uint32_t all;
   } option;
   struct {
    uint32_t tdr_level;
    uint32_t tdr_delay;
   } tdr_config;
  } change_config;
 };
};
struct amdgpu_mes_funcs {
 int (*add_hw_queue)(struct amdgpu_mes *mes,
       struct mes_add_queue_input *input);

 int (*remove_hw_queue)(struct amdgpu_mes *mes,
          struct mes_remove_queue_input *input);

 int (*map_legacy_queue)(struct amdgpu_mes *mes,
    struct mes_map_legacy_queue_input *input);

 int (*unmap_legacy_queue)(struct amdgpu_mes *mes,
      struct mes_unmap_legacy_queue_input *input);

 int (*suspend_gang)(struct amdgpu_mes *mes,
       struct mes_suspend_gang_input *input);

 int (*resume_gang)(struct amdgpu_mes *mes,
      struct mes_resume_gang_input *input);

 int (*misc_op)(struct amdgpu_mes *mes,
         struct mes_misc_op_input *input);

 int (*reset_hw_queue)(struct amdgpu_mes *mes,
         struct mes_reset_queue_input *input);

 int (*detect_and_reset_hung_queues)(struct amdgpu_mes *mes,
         struct mes_detect_and_reset_queue_input *input);


 int (*invalidate_tlbs_pasid)(struct amdgpu_mes *mes,
         struct mes_inv_tlbs_pasid_input *input);
};
enum amdgpu_mca_ip {
 AMDGPU_MCA_IP_UNKNOW = -1,
 AMDGPU_MCA_IP_PSP = 0,
 AMDGPU_MCA_IP_SDMA,
 AMDGPU_MCA_IP_GC,
 AMDGPU_MCA_IP_SMU,
 AMDGPU_MCA_IP_MP5,
 AMDGPU_MCA_IP_UMC,
 AMDGPU_MCA_IP_PCS_XGMI,
 AMDGPU_MCA_IP_COUNT,
};
enum amdgpu_mca_error_type {
 AMDGPU_MCA_ERROR_TYPE_UE = 0,
 AMDGPU_MCA_ERROR_TYPE_CE,
 AMDGPU_MCA_ERROR_TYPE_DE,
};
struct amdgpu_mca_ras_block {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_mca_ras {
 struct ras_common_if *ras_if;
 struct amdgpu_mca_ras_block *ras;
};
struct mca_bank_set {
 int nr_entries;
 struct list_head list;
};
struct mca_bank_cache {
 struct mca_bank_set mca_set;
 struct mutex lock;
};
struct amdgpu_mca {
 struct amdgpu_mca_ras mp0;
 struct amdgpu_mca_ras mp1;
 struct amdgpu_mca_ras mpio;
 const struct amdgpu_mca_smu_funcs *mca_funcs;
 struct mca_bank_cache mca_caches[AMDGPU_MCA_ERROR_TYPE_DE];
 atomic_t ue_update_flag;
};
struct mca_bank_info {
 int socket_id;
 int aid;
 int hwid;
 int mcatype;
};
struct mca_bank_entry {
 int idx;
 enum amdgpu_mca_error_type type;
 enum amdgpu_mca_ip ip;
 struct mca_bank_info info;
 uint64_t regs[(16)];
};
struct amdgpu_mca_smu_funcs {
 int max_ue_count;
 int max_ce_count;
 int (*mca_set_debug_mode)(struct amdgpu_device *adev, bool enable);
 int (*mca_parse_mca_error_count)(struct amdgpu_device *adev, enum amdgpu_ras_block blk, enum amdgpu_mca_error_type type,
      struct mca_bank_entry *entry, uint32_t *count);
 int (*mca_get_valid_mca_count)(struct amdgpu_device *adev, enum amdgpu_mca_error_type type,
           uint32_t *count);
 int (*mca_get_mca_entry)(struct amdgpu_device *adev, enum amdgpu_mca_error_type type,
     int idx, struct mca_bank_entry *entry);
};
struct amdgpu_umc_flip_bits {
 uint32_t flip_bits_in_pa[4];
 uint32_t flip_row_bit;
 uint32_t r13_in_pa;
 uint32_t bit_num;
};
struct amdgpu_umc_ras {
 struct amdgpu_ras_block_object ras_block;
 void (*err_cnt_init)(struct amdgpu_device *adev);
 bool (*query_ras_poison_mode)(struct amdgpu_device *adev);
 void (*ecc_info_query_ras_error_count)(struct amdgpu_device *adev,
          void *ras_error_status);
 void (*ecc_info_query_ras_error_address)(struct amdgpu_device *adev,
     void *ras_error_status);
 bool (*check_ecc_err_status)(struct amdgpu_device *adev,
   enum amdgpu_mca_error_type type, void *ras_error_status);
 int (*update_ecc_status)(struct amdgpu_device *adev,
   uint64_t status, uint64_t ipid, uint64_t addr);
 int (*convert_ras_err_addr)(struct amdgpu_device *adev,
   struct ras_err_data *err_data,
   struct ta_ras_query_address_input *addr_in,
   struct ta_ras_query_address_output *addr_out,
   bool dump_addr);
 uint32_t (*get_die_id_from_pa)(struct amdgpu_device *adev,
   uint64_t mca_addr, uint64_t retired_page);
 void (*get_retire_flip_bits)(struct amdgpu_device *adev);
};
struct amdgpu_umc_funcs {
 void (*init_registers)(struct amdgpu_device *adev);
};
struct amdgpu_umc {

 uint32_t max_ras_err_cnt_per_query;

 uint32_t channel_inst_num;

 uint32_t umc_inst_num;


 uint32_t node_inst_num;


 uint32_t channel_offs;

 uint32_t retire_unit;

 const uint32_t *channel_idx_tbl;
 struct ras_common_if *ras_if;

 const struct amdgpu_umc_funcs *funcs;
 struct amdgpu_umc_ras *ras;


 unsigned long active_mask;

 struct amdgpu_umc_flip_bits flip_bits;

 unsigned long err_addr_cnt;
};
struct amdgpu_mmhub_ras {
 struct amdgpu_ras_block_object ras_block;
};
struct amdgpu_mmhub_funcs {
 u64 (*get_fb_location)(struct amdgpu_device *adev);
 u64 (*get_mc_fb_offset)(struct amdgpu_device *adev);
 void (*init)(struct amdgpu_device *adev);
 int (*gart_enable)(struct amdgpu_device *adev);
 void (*set_fault_enable_default)(struct amdgpu_device *adev,
   bool value);
 void (*gart_disable)(struct amdgpu_device *adev);
 int (*set_clockgating)(struct amdgpu_device *adev,
          enum amd_clockgating_state state);
 void (*get_clockgating)(struct amdgpu_device *adev, u64 *flags);
 void (*setup_vm_pt_regs)(struct amdgpu_device *adev, uint32_t vmid,
    uint64_t page_table_base);
 void (*update_power_gating)(struct amdgpu_device *adev,
                                bool enable);
};
struct amdgpu_mmhub {
 struct ras_common_if *ras_if;
 const struct amdgpu_mmhub_funcs *funcs;
 struct amdgpu_mmhub_ras *ras;
};
struct amdgpu_gfxhub_funcs {
 u64 (*get_fb_location)(struct amdgpu_device *adev);
 u64 (*get_mc_fb_offset)(struct amdgpu_device *adev);
 void (*setup_vm_pt_regs)(struct amdgpu_device *adev, uint32_t vmid,
   uint64_t page_table_base);
 int (*gart_enable)(struct amdgpu_device *adev);

 void (*gart_disable)(struct amdgpu_device *adev);
 void (*set_fault_enable_default)(struct amdgpu_device *adev, bool value);
 void (*init)(struct amdgpu_device *adev);
 int (*get_xgmi_info)(struct amdgpu_device *adev);
 void (*utcl2_harvest)(struct amdgpu_device *adev);
 void (*mode2_save_regs)(struct amdgpu_device *adev);
 void (*mode2_restore_regs)(struct amdgpu_device *adev);
 void (*halt)(struct amdgpu_device *adev);
};
struct amdgpu_gfxhub {
 const struct amdgpu_gfxhub_funcs *funcs;
};
struct amdgpu_df_hash_status {
 bool hash_64k;
 bool hash_2m;
 bool hash_1g;
};
struct amdgpu_df_funcs {
 void (*sw_init)(struct amdgpu_device *adev);
 void (*sw_fini)(struct amdgpu_device *adev);
 void (*hw_init)(struct amdgpu_device *adev);
 void (*enable_broadcast_mode)(struct amdgpu_device *adev,
          bool enable);
 u32 (*get_fb_channel_number)(struct amdgpu_device *adev);
 u32 (*get_hbm_channel_number)(struct amdgpu_device *adev);
 void (*update_medium_grain_clock_gating)(struct amdgpu_device *adev,
       bool enable);
 void (*get_clockgating_state)(struct amdgpu_device *adev,
          u64 *flags);
 void (*enable_ecc_force_par_wr_rmw)(struct amdgpu_device *adev,
         bool enable);
 int (*pmc_start)(struct amdgpu_device *adev, uint64_t config,
      int counter_idx, int is_add);
 int (*pmc_stop)(struct amdgpu_device *adev, uint64_t config,
      int counter_idx, int is_remove);
 void (*pmc_get_count)(struct amdgpu_device *adev, uint64_t config,
      int counter_idx, uint64_t *count);
 uint64_t (*get_fica)(struct amdgpu_device *adev, uint32_t ficaa_val);
 void (*set_fica)(struct amdgpu_device *adev, uint32_t ficaa_val,
    uint32_t ficadl_val, uint32_t ficadh_val);
 bool (*query_ras_poison_mode)(struct amdgpu_device *adev);
};
struct amdgpu_df {
 struct amdgpu_df_hash_status hash_status;
 const struct amdgpu_df_funcs *funcs;
};
struct amdgpu_cper {
 bool enabled;

 atomic_t unique_id;
 struct mutex cper_lock;


 uint32_t count;
 uint32_t max_count;

 uint32_t wptr;

 void *ring[0x1000];
 struct amdgpu_ring ring_buf;
 struct mutex ring_lock;
};
struct amdgpu_seq64 {
 struct amdgpu_bo *sbo;
 u32 num_sem;
 u64 gpu_addr;
 u64 *cpu_base_addr;
 unsigned long used[(((((2ULL << 20) / sizeof(u64))) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
enum amdgpu_userq_state {
 AMDGPU_USERQ_STATE_UNMAPPED = 0,
 AMDGPU_USERQ_STATE_MAPPED,
 AMDGPU_USERQ_STATE_PREEMPTED,
 AMDGPU_USERQ_STATE_HUNG,
};
struct amdgpu_mqd_prop;
struct amdgpu_userq_obj {
 void *cpu_ptr;
 uint64_t gpu_addr;
 struct amdgpu_bo *obj;
};
struct amdgpu_usermode_queue {
 int queue_type;
 enum amdgpu_userq_state state;
 uint64_t doorbell_handle;
 uint64_t doorbell_index;
 uint64_t flags;
 struct amdgpu_mqd_prop *userq_prop;
 struct amdgpu_userq_mgr *userq_mgr;
 struct amdgpu_vm *vm;
 struct amdgpu_userq_obj mqd;
 struct amdgpu_userq_obj db_obj;
 struct amdgpu_userq_obj fw_obj;
 struct amdgpu_userq_obj wptr_obj;
 struct xarray fence_drv_xa;
 struct amdgpu_userq_fence_driver *fence_drv;
 struct dma_fence *last_fence;
 u32 xcp_id;
 int priority;
 struct dentry *debugfs_queue;

 struct list_head userq_va_list;
};
struct amdgpu_userq_funcs {
 int (*mqd_create)(struct amdgpu_userq_mgr *uq_mgr,
     struct drm_amdgpu_userq_in *args,
     struct amdgpu_usermode_queue *queue);
 void (*mqd_destroy)(struct amdgpu_userq_mgr *uq_mgr,
       struct amdgpu_usermode_queue *uq);
 int (*unmap)(struct amdgpu_userq_mgr *uq_mgr,
       struct amdgpu_usermode_queue *queue);
 int (*map)(struct amdgpu_userq_mgr *uq_mgr,
     struct amdgpu_usermode_queue *queue);
 int (*preempt)(struct amdgpu_userq_mgr *uq_mgr,
     struct amdgpu_usermode_queue *queue);
 int (*restore)(struct amdgpu_userq_mgr *uq_mgr,
     struct amdgpu_usermode_queue *queue);
 int (*detect_and_reset)(struct amdgpu_device *adev,
    int queue_type);
};
struct amdgpu_userq_mgr {
 struct idr userq_idr;
 struct mutex userq_mutex;
 struct amdgpu_device *adev;
 struct delayed_work resume_work;
 struct list_head list;
 struct drm_file *file;
};
struct device;
struct isp_platform_data {
 void *adev;
 u32 asic_type;
 resource_size_t base_rmmio_size;
};
enum gpd_status {
 GENPD_STATE_ON = 0,
 GENPD_STATE_OFF,
};
enum genpd_sync_state {
 GENPD_SYNC_STATE_OFF = 0,
 GENPD_SYNC_STATE_SIMPLE,
 GENPD_SYNC_STATE_ONECELL,
};
struct dev_power_governor {
 bool (*power_down_ok)(struct dev_pm_domain *domain);
 bool (*suspend_ok)(struct device *dev);
};
struct gpd_dev_ops {
 int (*start)(struct device *dev);
 int (*stop)(struct device *dev);
};
struct genpd_governor_data {
 s64 max_off_time_ns;
 bool max_off_time_changed;
 ktime_t next_wakeup;
 ktime_t next_hrtimer;
 ktime_t last_enter;
 bool reflect_residency;
 bool cached_power_down_ok;
 bool cached_power_down_state_idx;
};
struct genpd_power_state {
 const char *name;
 s64 power_off_latency_ns;
 s64 power_on_latency_ns;
 s64 residency_ns;
 u64 usage;
 u64 rejected;
 u64 above;
 u64 below;
 struct fwnode_handle *fwnode;
 u64 idle_time;
 void *data;
};
struct genpd_lock_ops;
struct opp_table;
struct generic_pm_domain {
 struct device dev;
 struct dev_pm_domain domain;
 struct list_head gpd_list_node;
 struct list_head parent_links;
 struct list_head child_links;
 struct list_head dev_list;
 struct dev_power_governor *gov;
 struct genpd_governor_data *gd;
 struct work_struct power_off_work;
 struct fwnode_handle *provider;
 bool has_provider;
 const char *name;
 atomic_t sd_count;
 enum gpd_status status;
 unsigned int device_count;
 unsigned int device_id;
 unsigned int suspended_count;
 unsigned int prepared_count;
 unsigned int performance_state;
 cpumask_var_t cpus;
 bool synced_poweroff;
 bool stay_on;
 enum genpd_sync_state sync_state;
 int (*power_off)(struct generic_pm_domain *domain);
 int (*power_on)(struct generic_pm_domain *domain);
 struct raw_notifier_head power_notifiers;
 struct opp_table *opp_table;
 int (*set_performance_state)(struct generic_pm_domain *genpd,
         unsigned int state);
 struct gpd_dev_ops dev_ops;
 int (*set_hwmode_dev)(struct generic_pm_domain *domain,
         struct device *dev, bool enable);
 bool (*get_hwmode_dev)(struct generic_pm_domain *domain,
         struct device *dev);
 int (*attach_dev)(struct generic_pm_domain *domain,
     struct device *dev);
 void (*detach_dev)(struct generic_pm_domain *domain,
      struct device *dev);
 unsigned int flags;
 struct genpd_power_state *states;
 void (*free_states)(struct genpd_power_state *states,
       unsigned int state_count);
 unsigned int state_count;
 unsigned int state_idx;
 u64 on_time;
 u64 accounting_time;
 const struct genpd_lock_ops *lock_ops;
 union {
  struct mutex mlock;
  struct {
   spinlock_t slock;
   unsigned long lock_flags;
  };
  struct {
   raw_spinlock_t raw_slock;
   unsigned long raw_lock_flags;
  };
 };
};
struct pm_domain_data {
 struct list_head list_node;
 struct device *dev;
};
struct of_device_id;
struct amdgpu_isp;
struct isp_funcs {
 int (*hw_init)(struct amdgpu_isp *isp);
 int (*hw_fini)(struct amdgpu_isp *isp);
};
struct amdgpu_isp {
 struct device *parent;
 struct amdgpu_device *adev;
 const struct isp_funcs *funcs;
 struct mfd_cell *isp_cell;
 struct resource *isp_res;
 struct resource *isp_i2c_res;
 struct resource *isp_gpio_res;
 struct isp_platform_data *isp_pdata;
 unsigned int harvest_config;
 const struct firmware *fw;
 struct generic_pm_domain ispgpd;
};
struct amdgpu_hwip_reg_entry {
 u32 hwip;
 u32 inst;
 u32 seg;
 u32 reg_offset;
 const char *reg_name;
};
extern int amdgpu_audio;
extern int amdgpu_dpm;
extern int amdgpu_mes;
extern int amdgpu_umsch_mm;
struct amdgpu_xcp_mgr;
struct amdgpu_device;
struct amdgpu_irq_src;
struct kfd_vm_fault_info;
struct amdgpu_hive_info;
struct amdgpu_reset_control;
struct amdgpu_ip_block_status {
 bool valid;
 bool sw;
 bool hw;
 bool late_initialized;
 bool hang;
};
struct amdgpu_ip_block_version {
 const enum amd_ip_block_type type;
 const u32 major;
 const u32 minor;
 const u32 rev;
 const struct amd_ip_funcs *funcs;
};
struct amdgpu_ip_block {
 struct amdgpu_ip_block_status status;
 const struct amdgpu_ip_block_version *version;
 struct amdgpu_device *adev;
};
struct amdgpu_clock {
 struct amdgpu_pll ppll[3];
 struct amdgpu_pll spll;
 struct amdgpu_pll mpll;

 uint32_t default_mclk;
 uint32_t default_sclk;
 uint32_t default_dispclk;
 uint32_t dp_extclk;
 uint32_t max_pixel_clock;
};
struct amdgpu_sa_manager {
 struct drm_suballoc_manager base;
 struct amdgpu_bo *bo;
 uint64_t gpu_addr;
 void *cpu_ptr;
};
struct amdgpu_flip_work {
 struct delayed_work flip_work;
 struct work_struct unpin_work;
 struct amdgpu_device *adev;
 int crtc_id;
 u32 target_vblank;
 uint64_t base;
 struct drm_pending_vblank_event *event;
 struct amdgpu_bo *old_abo;
 unsigned shared_count;
 struct dma_fence **shared;
 struct dma_fence_cb cb;
 bool async;
};
struct amdgpu_wb {






 struct amdgpu_bo *wb_obj;
 uint32_t *wb;






 uint64_t gpu_addr;






 u32 num_wb;






 unsigned long used[(((1024) + (64) - 1) / (64))];






 spinlock_t lock;
};
enum amd_reset_method {
 AMD_RESET_METHOD_NONE = -1,
 AMD_RESET_METHOD_LEGACY = 0,
 AMD_RESET_METHOD_MODE0,
 AMD_RESET_METHOD_MODE1,
 AMD_RESET_METHOD_MODE2,
 AMD_RESET_METHOD_LINK,
 AMD_RESET_METHOD_BACO,
 AMD_RESET_METHOD_PCI,
 AMD_RESET_METHOD_ON_INIT,
};
struct amdgpu_video_codec_info {
 u32 codec_type;
 u32 max_width;
 u32 max_height;
 u32 max_pixels_per_frame;
 u32 max_level;
};
struct amdgpu_video_codecs {
 const u32 codec_count;
 const struct amdgpu_video_codec_info *codec_array;
};
struct amdgpu_asic_funcs {
 bool (*read_disabled_bios)(struct amdgpu_device *adev);
 bool (*read_bios_from_rom)(struct amdgpu_device *adev,
       u8 *bios, u32 length_bytes);
 int (*read_register)(struct amdgpu_device *adev, u32 se_num,
        u32 sh_num, u32 reg_offset, u32 *value);
 void (*set_vga_state)(struct amdgpu_device *adev, bool state);
 int (*reset)(struct amdgpu_device *adev);
 enum amd_reset_method (*reset_method)(struct amdgpu_device *adev);

 u32 (*get_xclk)(struct amdgpu_device *adev);

 int (*set_uvd_clocks)(struct amdgpu_device *adev, u32 vclk, u32 dclk);
 int (*set_vce_clocks)(struct amdgpu_device *adev, u32 evclk, u32 ecclk);

 int (*get_pcie_lanes)(struct amdgpu_device *adev);
 void (*set_pcie_lanes)(struct amdgpu_device *adev, int lanes);

 u32 (*get_config_memsize)(struct amdgpu_device *adev);

 void (*flush_hdp)(struct amdgpu_device *adev, struct amdgpu_ring *ring);

 void (*invalidate_hdp)(struct amdgpu_device *adev,
          struct amdgpu_ring *ring);

 bool (*need_full_reset)(struct amdgpu_device *adev);

 void (*init_doorbell_index)(struct amdgpu_device *adev);

 void (*get_pcie_usage)(struct amdgpu_device *adev, uint64_t *count0,
          uint64_t *count1);

 bool (*need_reset_on_init)(struct amdgpu_device *adev);

 uint64_t (*get_pcie_replay_count)(struct amdgpu_device *adev);

 int (*supports_baco)(struct amdgpu_device *adev);

 void (*pre_asic_init)(struct amdgpu_device *adev);

 int (*update_umd_stable_pstate)(struct amdgpu_device *adev, bool enter);

 int (*query_video_codecs)(struct amdgpu_device *adev, bool encode,
      const struct amdgpu_video_codecs **codecs);

 u64 (*encode_ext_smn_addressing)(int ext_id);

 ssize_t (*get_reg_state)(struct amdgpu_device *adev,
     enum amdgpu_reg_state reg_state, void *buf,
     size_t max_size);
};
struct amdgpu_mem_scratch {
 struct amdgpu_bo *robj;
 uint32_t *ptr;
 u64 gpu_addr;
};
typedef uint32_t (*amdgpu_rreg_t)(struct amdgpu_device*, uint32_t);
typedef void (*amdgpu_wreg_t)(struct amdgpu_device*, uint32_t, uint32_t);
typedef uint32_t (*amdgpu_rreg_ext_t)(struct amdgpu_device*, uint64_t);
typedef void (*amdgpu_wreg_ext_t)(struct amdgpu_device*, uint64_t, uint32_t);
typedef uint64_t (*amdgpu_rreg64_t)(struct amdgpu_device*, uint32_t);
typedef void (*amdgpu_wreg64_t)(struct amdgpu_device*, uint32_t, uint64_t);
typedef uint64_t (*amdgpu_rreg64_ext_t)(struct amdgpu_device*, uint64_t);
typedef void (*amdgpu_wreg64_ext_t)(struct amdgpu_device*, uint64_t, uint64_t);
typedef uint32_t (*amdgpu_block_rreg_t)(struct amdgpu_device*, uint32_t, uint32_t);
typedef void (*amdgpu_block_wreg_t)(struct amdgpu_device*, uint32_t, uint32_t, uint32_t);
struct amdgpu_mmio_remap {
 u32 reg_offset;
 resource_size_t bus_addr;
 struct amdgpu_bo *bo;
};
enum amd_hw_ip_block_type {
 GC_HWIP = 1,
 HDP_HWIP,
 SDMA0_HWIP,
 SDMA1_HWIP,
 SDMA2_HWIP,
 SDMA3_HWIP,
 SDMA4_HWIP,
 SDMA5_HWIP,
 SDMA6_HWIP,
 SDMA7_HWIP,
 LSDMA_HWIP,
 MMHUB_HWIP,
 ATHUB_HWIP,
 NBIO_HWIP,
 MP0_HWIP,
 MP1_HWIP,
 UVD_HWIP,
 VCN_HWIP = UVD_HWIP,
 JPEG_HWIP = VCN_HWIP,
 VCN1_HWIP,
 VCE_HWIP,
 VPE_HWIP,
 DF_HWIP,
 DCE_HWIP,
 OSSSYS_HWIP,
 SMUIO_HWIP,
 PWR_HWIP,
 NBIF_HWIP,
 THM_HWIP,
 CLK_HWIP,
 UMC_HWIP,
 RSMU_HWIP,
 XGMI_HWIP,
 DCI_HWIP,
 PCIE_HWIP,
 ISP_HWIP,
 MAX_HWIP
};
struct amdgpu_ip_map_info {

 uint32_t dev_inst[MAX_HWIP][44];
 int8_t (*logical_to_dev_inst)(struct amdgpu_device *adev,
          enum amd_hw_ip_block_type block,
          int8_t inst);
 uint32_t (*logical_to_dev_mask)(struct amdgpu_device *adev,
     enum amd_hw_ip_block_type block,
     uint32_t mask);
};
enum amdgpu_uid_type {
 AMDGPU_UID_TYPE_XCD,
 AMDGPU_UID_TYPE_AID,
 AMDGPU_UID_TYPE_SOC,
 AMDGPU_UID_TYPE_MAX
};
struct amdgpu_uid {
 uint64_t uid[AMDGPU_UID_TYPE_MAX][8];
 struct amdgpu_device *adev;
};
struct amd_powerplay {
 void *pp_handle;
 const struct amd_pm_funcs *pp_funcs;
};
struct ip_discovery_top;
struct amdgpu_mqd_prop {
 uint64_t mqd_gpu_addr;
 uint64_t hqd_base_gpu_addr;
 uint64_t rptr_gpu_addr;
 uint64_t wptr_gpu_addr;
 uint32_t queue_size;
 bool use_doorbell;
 uint32_t doorbell_index;
 uint64_t eop_gpu_addr;
 uint32_t hqd_pipe_priority;
 uint32_t hqd_queue_priority;
 bool allow_tunneling;
 bool hqd_active;
 uint64_t shadow_addr;
 uint64_t gds_bkup_addr;
 uint64_t csa_addr;
 uint64_t fence_address;
 bool tmz_queue;
 bool kernel_queue;
};
struct amdgpu_mqd {
 unsigned mqd_size;
 int (*init_mqd)(struct amdgpu_device *adev, void *mqd,
   struct amdgpu_mqd_prop *p);
};
struct amdgpu_pcie_reset_ctx {
 bool in_link_reset;
 bool occurs_dpc;
 bool audio_suspended;
 struct pci_dev *swus;
 struct pci_saved_state *swus_pcistate;
 struct pci_saved_state *swds_pcistate;
};
enum amdgpu_init_lvl_id {
 AMDGPU_INIT_LEVEL_DEFAULT,
 AMDGPU_INIT_LEVEL_MINIMAL_XGMI,
 AMDGPU_INIT_LEVEL_RESET_RECOVERY,
};
struct amdgpu_init_level {
 enum amdgpu_init_lvl_id level;
 uint32_t hwini_ip_block_mask;
};
struct amdgpu_reset_domain;
struct amdgpu_fru_info;
enum amdgpu_enforce_isolation_mode {
 AMDGPU_ENFORCE_ISOLATION_DISABLE = 0,
 AMDGPU_ENFORCE_ISOLATION_ENABLE = 1,
 AMDGPU_ENFORCE_ISOLATION_ENABLE_LEGACY = 2,
 AMDGPU_ENFORCE_ISOLATION_NO_CLEANER_SHADER = 3,
};
struct amdgpu_device {
 struct device *dev;
 struct pci_dev *pdev;
 struct drm_device ddev;


 struct amdgpu_acp acp;

 struct amdgpu_hive_info *hive;
 struct amdgpu_xcp_mgr *xcp_mgr;

 enum amd_asic_type asic_type;
 uint32_t family;
 uint32_t rev_id;
 uint32_t external_rev_id;
 unsigned long flags;
 unsigned long apu_flags;
 int usec_timeout;
 const struct amdgpu_asic_funcs *asic_funcs;
 bool shutdown;
 bool need_swiotlb;
 bool accel_working;
 struct notifier_block acpi_nb;
 struct notifier_block pm_nb;
 struct amdgpu_i2c_chan *i2c_bus[16];
 struct debugfs_blob_wrapper debugfs_vbios_blob;
 struct debugfs_blob_wrapper debugfs_discovery_blob;
 struct mutex srbm_mutex;

 struct mutex grbm_idx_mutex;
 struct dev_pm_domain vga_pm_domain;
 bool have_disp_power_ref;
 bool have_atomics_support;


 bool is_atom_fw;
 uint8_t *bios;
 uint32_t bios_size;
 uint32_t bios_scratch_reg_offset;
 uint32_t bios_scratch[16];


 resource_size_t rmmio_base;
 resource_size_t rmmio_size;
 void *rmmio;

 spinlock_t mmio_idx_lock;
 struct amdgpu_mmio_remap rmmio_remap;

 spinlock_t smc_idx_lock;
 amdgpu_rreg_t smc_rreg;
 amdgpu_wreg_t smc_wreg;

 spinlock_t pcie_idx_lock;
 amdgpu_rreg_t pcie_rreg;
 amdgpu_wreg_t pcie_wreg;
 amdgpu_rreg_t pciep_rreg;
 amdgpu_wreg_t pciep_wreg;
 amdgpu_rreg_ext_t pcie_rreg_ext;
 amdgpu_wreg_ext_t pcie_wreg_ext;
 amdgpu_rreg64_t pcie_rreg64;
 amdgpu_wreg64_t pcie_wreg64;
 amdgpu_rreg64_ext_t pcie_rreg64_ext;
 amdgpu_wreg64_ext_t pcie_wreg64_ext;

 spinlock_t uvd_ctx_idx_lock;
 amdgpu_rreg_t uvd_ctx_rreg;
 amdgpu_wreg_t uvd_ctx_wreg;

 spinlock_t didt_idx_lock;
 amdgpu_rreg_t didt_rreg;
 amdgpu_wreg_t didt_wreg;

 spinlock_t gc_cac_idx_lock;
 amdgpu_rreg_t gc_cac_rreg;
 amdgpu_wreg_t gc_cac_wreg;

 spinlock_t se_cac_idx_lock;
 amdgpu_rreg_t se_cac_rreg;
 amdgpu_wreg_t se_cac_wreg;

 spinlock_t audio_endpt_idx_lock;
 amdgpu_block_rreg_t audio_endpt_rreg;
 amdgpu_block_wreg_t audio_endpt_wreg;
 struct amdgpu_doorbell doorbell;


 struct amdgpu_clock clock;


 struct amdgpu_gmc gmc;
 struct amdgpu_gart gart;
 dma_addr_t dummy_page_addr;
 struct amdgpu_vm_manager vm_manager;
 struct amdgpu_vmhub vmhub[13];
 unsigned long vmhubs_mask[(((13) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];


 struct amdgpu_mman mman;
 struct amdgpu_mem_scratch mem_scratch;
 struct amdgpu_wb wb;
 atomic64_t num_bytes_moved;
 atomic64_t num_evictions;
 atomic64_t num_vram_cpu_page_faults;
 atomic_t gpu_reset_counter;
 atomic_t vram_lost_counter;


 struct {
  spinlock_t lock;
  s64 last_update_us;
  s64 accum_us;
  s64 accum_us_vis;
  u32 log2_max_MBps;
 } mm_stats;


 bool enable_virtual_display;
 struct amdgpu_vkms_output *amdgpu_vkms_output;
 struct amdgpu_mode_info mode_info;

 struct delayed_work hotplug_work;
 struct amdgpu_irq_src crtc_irq;
 struct amdgpu_irq_src vline0_irq;
 struct amdgpu_irq_src vupdate_irq;
 struct amdgpu_irq_src pageflip_irq;
 struct amdgpu_irq_src hpd_irq;
 struct amdgpu_irq_src dmub_trace_irq;
 struct amdgpu_irq_src dmub_outbox_irq;


 u64 fence_context;
 unsigned num_rings;
 struct amdgpu_ring *rings[149];
 struct dma_fence *gang_submit;
 bool ib_pool_ready;
 struct amdgpu_sa_manager ib_pools[AMDGPU_IB_POOL_MAX];
 struct amdgpu_sched gpu_sched[10][AMDGPU_RING_PRIO_MAX];


 struct amdgpu_irq irq;


 struct amd_powerplay powerplay;
 struct amdgpu_pm pm;
 u64 cg_flags;
 u32 pg_flags;


 struct amdgpu_nbio nbio;


 struct amdgpu_hdp hdp;


 struct amdgpu_smuio smuio;


 struct amdgpu_mmhub mmhub;


 struct amdgpu_gfxhub gfxhub;


 struct amdgpu_gfx gfx;


 struct amdgpu_sdma sdma;


 struct amdgpu_lsdma lsdma;


 struct amdgpu_uvd uvd;


 struct amdgpu_vce vce;


 struct amdgpu_vcn vcn;


 struct amdgpu_jpeg jpeg;


 struct amdgpu_vpe vpe;


 struct amdgpu_umsch_mm umsch_mm;
 bool enable_umsch_mm;


 struct amdgpu_firmware firmware;


 struct psp_context psp;


 struct amdgpu_gds gds;


 struct amdgpu_seq64 seq64;


 struct amdgpu_umc umc;


 struct amdgpu_display_manager dm;



 struct amdgpu_isp isp;



 bool enable_mes;
 bool enable_mes_kiq;
 bool enable_uni_mes;
 struct amdgpu_mes mes;
 struct amdgpu_mqd mqds[10];
 const struct amdgpu_userq_funcs *userq_funcs[10];





 struct xarray userq_xa;


 struct amdgpu_df df;


 struct amdgpu_mca mca;


 struct amdgpu_aca aca;


 struct amdgpu_cper cper;

 struct amdgpu_ip_block ip_blocks[16];
 uint32_t harvest_ip_mask;
 int num_ip_blocks;
 struct mutex mn_lock;
 struct hlist_head mn_hash[1 << (7)];


 atomic64_t vram_pin_size;
 atomic64_t visible_pin_size;
 atomic64_t gart_pin_size;


 uint32_t *reg_offset[MAX_HWIP][44];
 struct amdgpu_ip_map_info ip_map;


 struct delayed_work delayed_init_work;

 struct amdgpu_virt virt;


 bool has_hw_reset;
 u8 reset_magic[64];


 bool in_suspend;
 bool in_s3;
 bool in_s4;
 bool in_s0ix;
 suspend_state_t last_suspend_state;

 enum pp_mp1_state mp1_state;
 struct amdgpu_doorbell_index doorbell_index;

 struct mutex notifier_lock;

 int asic_reset_res;
 struct work_struct xgmi_reset_work;
 struct list_head reset_list;

 long gfx_timeout;
 long sdma_timeout;
 long video_timeout;
 long compute_timeout;
 long psp_timeout;

 uint64_t unique_id;
 uint64_t df_perfmon_config_assign_mask[4];


 bool in_runpm;
 bool has_pr3;

 bool ucode_sysfs_en;

 struct amdgpu_fru_info *fru_info;
 atomic_t throttling_logging_enabled;
 struct ratelimit_state throttling_logging_rs;
 uint32_t ras_hw_enabled;
 uint32_t ras_enabled;
 bool ras_default_ecc_enabled;

 bool no_hw_access;
 struct pci_saved_state *pci_state;
 pci_channel_state_t pci_channel_state;

 struct amdgpu_pcie_reset_ctx pcie_reset_ctx;


 bool barrier_has_auto_waitcnt;

 struct amdgpu_reset_control *reset_cntl;
 uint32_t ip_versions[MAX_HWIP][44];

 bool ram_is_direct_mapped;

 struct list_head ras_list;

 struct ip_discovery_top *ip_top;

 struct amdgpu_reset_domain *reset_domain;

 struct mutex benchmark_mutex;

 bool scpm_enabled;
 uint32_t scpm_status;

 struct work_struct reset_work;

 bool dc_enabled;

 uint32_t aid_mask;


 bool debug_vm;
 bool debug_largebar;
 bool debug_disable_soft_recovery;
 bool debug_use_vram_fw_buf;
 bool debug_enable_ras_aca;
 bool debug_exp_resets;
 bool debug_disable_gpu_ring_reset;
 bool debug_vm_userptr;
 bool debug_disable_ce_logs;
 bool debug_enable_ce_cs;


 struct mutex enforce_isolation_mutex;
 enum amdgpu_enforce_isolation_mode enforce_isolation[8];
 struct amdgpu_isolation {
  void *owner;
  struct dma_fence *spearhead;
  struct amdgpu_sync active;
  struct amdgpu_sync prev;
 } isolation[8];

 struct amdgpu_init_level *init_lvl;




 bool apu_prefer_gtt;

 struct list_head userq_mgr_list;
 struct mutex userq_mutex;
 bool userq_halt_for_enforce_isolation;
 struct amdgpu_uid *uid_info;




 struct amdgpu_kfd_dev kfd;
};
struct amdgpu_bo_va {
 struct amdgpu_vm_bo_base base;


 unsigned ref_count;


 struct dma_fence *last_pt_update;


 struct list_head invalids;
 struct list_head valids;


 bool cleared;

 bool is_xgmi;





 unsigned int queue_refcount;
 atomic_t userq_va_mapped;
};
struct amdgpu_bo {

 u32 preferred_domains;
 u32 allowed_domains;
 struct ttm_place placements[3];
 struct ttm_placement placement;
 struct ttm_buffer_object tbo;
 struct ttm_bo_kmap_obj kmap;
 u64 flags;

 struct amdgpu_vm_bo_base *vm_bo;

 struct amdgpu_bo *parent;


 struct mmu_interval_notifier notifier;

 struct kgd_mem *kfd_bo;






 int8_t xcp_id;
};
struct amdgpu_bo_vm {
 struct amdgpu_bo bo;
 struct amdgpu_vm_bo_base entries[1];
};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct module;
struct tracepoint;
struct notifier_block;
struct trace_eval_map {
 const char *system;
 const char *eval_string;
 unsigned long eval_value;
};
struct amdgpu_userq_fence_driver {
 struct kref refcount;
 u64 va;
 u64 gpu_addr;
 u64 *cpu_addr;
 u64 context;




 spinlock_t fence_list_lock;
 struct list_head fences;
 struct amdgpu_device *adev;
 char timeline_name[TASK_COMM_LEN];
};
/*@ requires internal_offset <= 0x589a || internal_offset > 0x5880; ensures \result >= internal_offset; */

static u32 sdma_v7_0_get_reg_offset(struct amdgpu_device *adev, u32 instance, u32 internal_offset)
{
 u32 base;

 if (internal_offset >= 0x5880 &&
     internal_offset <= 0x589a) {
  base = adev->reg_offset[GC_HWIP][0][1];
  if (instance != 0)
   internal_offset += 0x20 * instance;
 } else {
  base = adev->reg_offset[GC_HWIP][0][0];
  if (instance == 1)
   internal_offset += 0x600;
 }

 return base + internal_offset;
}
