typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
typedef _Bool bool;
struct drm_pvr_heap {

 __u64 base;


 __u64 size;


 __u32 flags;


 __u32 page_size_log2;
};
/*@ requires start <= end; ensures \result == 1 <==> (pvr_heap->base <= start && end < pvr_heap->base + pvr_heap->size); */

static inline     bool
pvr_heap_contains_range(const struct drm_pvr_heap *pvr_heap, u64 start, u64 end)
{
 return pvr_heap->base <= start && end < pvr_heap->base + pvr_heap->size;
}
