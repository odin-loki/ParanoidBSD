typedef unsigned long __uint64_t;
typedef __uint64_t uint64_t;
/*@ requires \valid(p); ensures \result == \old(*p) && *p == \old(*p) + val; */

static __inline uint64_t
atomic_fetchadd_64(volatile uint64_t *p, uint64_t val)
{
 uint64_t ret;

 __asm volatile("amoadd.d %0, %2, %1"
   : "=&r" (ret), "+A" (*p)
   : "r" (val)
   : "memory");

 return (ret);
}
