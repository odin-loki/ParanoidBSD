typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef long long __kernel_loff_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
/*@ requires 0 <= off && 0 <= count; ensures \result <= count && (off > size ==> \result == 0) && (off + count <= size ==> \result == count) && (off <= size && off + count > size ==> \result == size - off); */

static inline    size_t w1_f2d_fix_count(loff_t off, size_t count, size_t size)
{
 if (off > size)
  return 0;

 if ((off + count) > size)
  return size - off;

 return count;
}
