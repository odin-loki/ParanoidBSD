void
_pthread_suspend_all_np(void)
;
/*@ requires true; ensures \result == 0; */

int
ref__pthread_single_np(void)
{


 _pthread_suspend_all_np();




 return (0);
}
