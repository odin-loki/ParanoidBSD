typedef char flag;
typedef signed char int8;
typedef int int16;
typedef signed int int32;
typedef unsigned int bits32;
typedef unsigned long long int bits64;
typedef bits64 float64;
void
 ref_shift64Right(
     bits32 a0, bits32 a1, int16 count, bits32 *z0Ptr, bits32 *z1Ptr )
;
int8 ref_countLeadingZeros32( bits32 a )
;
float64
 ref_packFloat64( flag zSign, int16 zExp, bits32 zSig0, bits32 zSig1 )
;
/*@ requires true; ensures (a == 0 ==> \result == 0); */

float64 ref_int32_to_float64( int32 a )
{
    flag zSign;
    bits32 absA;
    int8 shiftCount;
    bits32 zSig0, zSig1;

    if ( a == 0 ) return ref_packFloat64( 0, 0, 0, 0 );
    zSign = ( a < 0 );
    absA = zSign ? - a : a;
    shiftCount = ref_countLeadingZeros32( absA ) - 11;
    if ( 0 <= shiftCount ) {
        zSig0 = absA<<shiftCount;
        zSig1 = 0;
    }
    else {
        ref_shift64Right( absA, 0, - shiftCount, &zSig0, &zSig1 );
    }
    return ref_packFloat64( zSign, 0x412 - shiftCount, zSig0, zSig1 );

}
