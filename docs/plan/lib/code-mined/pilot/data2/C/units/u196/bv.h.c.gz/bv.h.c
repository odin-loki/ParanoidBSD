typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __u8 u8;
typedef __u16 u16;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct device;
struct qspinlock;
struct device;
typedef atomic64_t atomic_long_t;
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct device;
struct mutex;
struct address_space;
struct device_node;
typedef u64 acpi_io_address;
typedef u64 acpi_physical_address;
typedef u32 acpi_status;
typedef void *acpi_handle;
typedef u16 acpi_owner_id;
typedef
u32 (*acpi_gpe_handler) (acpi_handle gpe_device, u32 gpe_number, void *context);
typedef
void (*acpi_notify_handler) (acpi_handle device, u32 value, void *context);
typedef
void (*acpi_object_handler) (acpi_handle object, void *data);
typedef
acpi_status (*acpi_adr_space_handler) (u32 function,
           acpi_physical_address address,
           u32 bit_width,
           u64 *value,
           void *handler_context,
           void *region_context);
typedef
acpi_status (*acpi_adr_space_setup) (acpi_handle region_handle,
         u32 function,
         void *handler_context,
         void **region_context);
union acpi_name_union {
 u32 integer;
 char ascii[4];
};
extern u32 acpi_dbg_level;
extern u32 acpi_dbg_layer;
 void acpi_error(const char *module_name, u32 line_number, const char *format, ...);
 void acpi_debug_print(u32 requested_debug_level, u32 line_number, const char *function_name, const char *module_name, u32 component_id, const char *format, ...);
struct acpi_walk_state;
union acpi_parse_object;
struct acpi_namespace_node {
 union acpi_operand_object *object;
 u8 descriptor_type;
 u8 type;
 u16 flags;
 union acpi_name_union name;
 struct acpi_namespace_node *parent;
 struct acpi_namespace_node *child;
 struct acpi_namespace_node *peer;
 acpi_owner_id owner_id;
};
typedef
acpi_status (*acpi_internal_method) (struct acpi_walk_state * walk_state);
struct acpi_gpe_handler_info {
 acpi_gpe_handler address;
 void *context;
 struct acpi_namespace_node *method_node;
 u8 original_flags;
 u8 originally_enabled;
};
struct acpi_gpe_notify_info {
 struct acpi_namespace_node *device_node;
 struct acpi_gpe_notify_info *next;
};
union acpi_gpe_dispatch_info {
 struct acpi_namespace_node *method_node;
 struct acpi_gpe_handler_info *handler;
 struct acpi_gpe_notify_info *notify_list;
};
struct acpi_gpe_event_info {
 union acpi_gpe_dispatch_info dispatch;
 struct acpi_gpe_register_info *register_info;
 u8 flags;
 u8 gpe_number;
 u8 runtime_count;
 u8 disable_for_dispatch;
};
struct acpi_gpe_address {
 u8 space_id;
 u64 address;
};
struct acpi_gpe_register_info {
 struct acpi_gpe_address status_address;
 struct acpi_gpe_address enable_address;
 u16 base_gpe_number;
 u8 enable_for_wake;
 u8 enable_for_run;
 u8 mask_for_run;
 u8 enable_mask;
};
struct acpi_gpe_block_info {
 struct acpi_namespace_node *node;
 struct acpi_gpe_block_info *previous;
 struct acpi_gpe_block_info *next;
 struct acpi_gpe_xrupt_info *xrupt_block;
 struct acpi_gpe_register_info *register_info;
 struct acpi_gpe_event_info *event_info;
 u64 address;
 u32 register_count;
 u16 gpe_count;
 u16 block_base_number;
 u8 space_id;
 u8 initialized;
};
struct acpi_gpe_xrupt_info {
 struct acpi_gpe_xrupt_info *previous;
 struct acpi_gpe_xrupt_info *next;
 struct acpi_gpe_block_info *gpe_block_list_head;
 u32 interrupt_number;
};
struct acpi_common_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
};
struct acpi_update_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 union acpi_operand_object *object;
};
struct acpi_pkg_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 u32 index;
 union acpi_operand_object *source_object;
 union acpi_operand_object *dest_object;
 struct acpi_walk_state *walk_state;
 void *this_target_obj;
 u32 num_packages;
};
struct acpi_control_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 u16 opcode;
 union acpi_parse_object *predicate_op;
 u8 *aml_predicate_start;
 u8 *package_end;
 u64 loop_timeout;
};
struct acpi_scope_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 struct acpi_namespace_node *node;
};
struct acpi_pscope_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 u32 arg_count;
 union acpi_parse_object *op;
 u8 *arg_end;
 u8 *pkg_end;
 u32 arg_list;
};
struct acpi_thread_state {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 u8 current_sync_level;
 struct acpi_walk_state *walk_state_list;
 union acpi_operand_object *acquired_mutex_list;
 u64 thread_id;
};
struct acpi_result_values {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 union acpi_operand_object *obj_desc[8];
};
typedef
acpi_status (*acpi_parse_downwards) (struct acpi_walk_state * walk_state,
         union acpi_parse_object ** out_op);
typedef
acpi_status (*acpi_parse_upwards) (struct acpi_walk_state * walk_state);
struct acpi_global_notify_handler {
 acpi_notify_handler handler;
 void *context;
};
struct acpi_notify_info {
 void *next; u8 descriptor_type; u8 flags; u16 value; u16 state;
 u8 handler_list_id;
 struct acpi_namespace_node *node;
 union acpi_operand_object *handler_list_head;
 struct acpi_global_notify_handler *global;
};
union acpi_generic_state {
 struct acpi_common_state common;
 struct acpi_control_state control;
 struct acpi_update_state update;
 struct acpi_scope_state scope;
 struct acpi_pscope_state parse_scope;
 struct acpi_pkg_state pkg;
 struct acpi_thread_state thread;
 struct acpi_result_values results;
 struct acpi_notify_info notify;
};
struct acpi_opcode_info {

 char *name;

 u32 parse_args;
 u32 runtime_args;
 u16 flags;
 u8 object_type;
 u8 class;
 u8 type;
};
union acpi_parse_value {
 u64 integer;
 u32 size;
 char *string;
 u8 *buffer;
 char *name;
 union acpi_parse_object *arg;
};
struct acpi_parse_obj_common {
union acpi_parse_object *parent; u8 descriptor_type; u8 flags; u16 aml_opcode; u8 *aml; union acpi_parse_object *next; struct acpi_namespace_node *node; union acpi_parse_value value; u8 arg_list_length; u16 disasm_flags; u8 disasm_opcode; char *operator_symbol; char aml_op_name[16]; };
struct acpi_parse_obj_named {
 union acpi_parse_object *parent; u8 descriptor_type; u8 flags; u16 aml_opcode; u8 *aml; union acpi_parse_object *next; struct acpi_namespace_node *node; union acpi_parse_value value; u8 arg_list_length; u16 disasm_flags; u8 disasm_opcode; char *operator_symbol; char aml_op_name[16]; char *path;
 u8 *data;
 u32 length;
 u32 name;
};
struct acpi_parse_obj_asl {
 union acpi_parse_object *parent; u8 descriptor_type; u8 flags; u16 aml_opcode; u8 *aml; union acpi_parse_object *next; struct acpi_namespace_node *node; union acpi_parse_value value; u8 arg_list_length; u16 disasm_flags; u8 disasm_opcode; char *operator_symbol; char aml_op_name[16]; union acpi_parse_object *child;
 union acpi_parse_object *parent_method;
 char *filename;
 u8 file_changed;
 char *parent_filename;
 char *external_name;
 char *namepath;
 char name_seg[4];
 u32 extra_value;
 u32 column;
 u32 line_number;
 u32 logical_line_number;
 u32 logical_byte_offset;
 u32 end_line;
 u32 end_logical_line;
 u32 acpi_btype;
 u32 aml_length;
 u32 aml_subtree_length;
 u32 final_aml_length;
 u32 final_aml_offset;
 u32 compile_flags;
 u16 parse_opcode;
 u8 aml_opcode_length;
 u8 aml_pkg_len_bytes;
 u8 extra;
 char parse_op_name[20];
};
union acpi_parse_object {
 struct acpi_parse_obj_common common;
 struct acpi_parse_obj_named named;
 struct acpi_parse_obj_asl asl;
};
struct acpi_parse_state {
 u8 *aml_start;
 u8 *aml;
 u8 *aml_end;
 u8 *pkg_start;
 u8 *pkg_end;
 union acpi_parse_object *start_op;
 struct acpi_namespace_node *start_node;
 union acpi_generic_state *scope;
 union acpi_parse_object *start_scope;
 u32 aml_size;
};
struct acpi_object_common {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
};
struct acpi_object_integer {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 fill[3];
 u64 value;
};
struct acpi_object_string {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 char *pointer; u32 length;
};
struct acpi_object_buffer {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 *pointer; u32 length;
 u32 aml_length;
 u8 *aml_start;
 struct acpi_namespace_node *node;
};
struct acpi_object_package {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 struct acpi_namespace_node *node;
 union acpi_operand_object **elements;
 u8 *aml_start;
 u32 aml_length;
 u32 count;
};
struct acpi_object_event {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 void * os_semaphore;
};
struct acpi_object_mutex {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 sync_level;
 u16 acquisition_depth;
 void * os_mutex;
 u64 thread_id;
 struct acpi_thread_state *owner_thread;
 union acpi_operand_object *prev;
 union acpi_operand_object *next;
 struct acpi_namespace_node *node;
 u8 original_sync_level;
};
struct acpi_object_region {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 space_id;
 struct acpi_namespace_node *node;
 union acpi_operand_object *handler;
 union acpi_operand_object *next;
 acpi_physical_address address;
 u32 length;
 void *pointer;
};
struct acpi_object_method {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 info_flags;
 u8 param_count;
 u8 sync_level;
 union acpi_operand_object *mutex;
 union acpi_operand_object *node;
 u8 *aml_start;
 union {
  acpi_internal_method implementation;
  union acpi_operand_object *handler;
 } dispatch;

 u32 aml_length;
 acpi_owner_id owner_id;
 u8 thread_count;
};
struct acpi_object_notify_common {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 union acpi_operand_object *notify_list[2]; union acpi_operand_object *handler;
};
struct acpi_object_device {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 union acpi_operand_object *notify_list[2]; union acpi_operand_object *handler;
 struct acpi_gpe_block_info *gpe_block;
};
struct acpi_object_power_resource {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 union acpi_operand_object *notify_list[2]; union acpi_operand_object *handler;
 u32 system_level;
 u32 resource_order;
};
struct acpi_object_processor {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;



 u8 proc_id;
 u8 length;
 union acpi_operand_object *notify_list[2]; union acpi_operand_object *handler;
 acpi_io_address address;
};
struct acpi_object_thermal_zone {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 union acpi_operand_object *notify_list[2]; union acpi_operand_object *handler;
};
struct acpi_object_field_common {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 field_flags; u8 attribute; u8 access_byte_width; struct acpi_namespace_node *node; u32 bit_length; u32 base_byte_offset; u32 value; u8 start_field_bit_offset; u8 access_length;
 union acpi_operand_object *region_obj;
};
struct acpi_object_region_field {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 field_flags; u8 attribute; u8 access_byte_width; struct acpi_namespace_node *node; u32 bit_length; u32 base_byte_offset; u32 value; u8 start_field_bit_offset; u8 access_length;
 u16 resource_length;
 union acpi_operand_object *region_obj;
 u8 *resource_buffer;
 u16 pin_number_index;
 u8 *internal_pcc_buffer;
};
struct acpi_object_bank_field {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 field_flags; u8 attribute; u8 access_byte_width; struct acpi_namespace_node *node; u32 bit_length; u32 base_byte_offset; u32 value; u8 start_field_bit_offset; u8 access_length;
 union acpi_operand_object *region_obj;
 union acpi_operand_object *bank_obj;
};
struct acpi_object_index_field {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 field_flags; u8 attribute; u8 access_byte_width; struct acpi_namespace_node *node; u32 bit_length; u32 base_byte_offset; u32 value; u8 start_field_bit_offset; u8 access_length;





 union acpi_operand_object *index_obj;
 union acpi_operand_object *data_obj;
};
struct acpi_object_buffer_field {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 field_flags; u8 attribute; u8 access_byte_width; struct acpi_namespace_node *node; u32 bit_length; u32 base_byte_offset; u32 value; u8 start_field_bit_offset; u8 access_length;
 u8 is_create_field;
 union acpi_operand_object *buffer_obj;
};
struct acpi_object_notify_handler {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 struct acpi_namespace_node *node;
 u32 handler_type;
 acpi_notify_handler handler;
 void *context;
 union acpi_operand_object *next[2];
};
struct acpi_object_addr_handler {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 space_id;
 u8 handler_flags;
 acpi_adr_space_handler handler;
 struct acpi_namespace_node *node;
 void *context;
 void * context_mutex;
 acpi_adr_space_setup setup;
 union acpi_operand_object *region_list;
 union acpi_operand_object *next;
};
struct acpi_object_reference {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 u8 class;
 u8 target_type;
 u8 resolved;
 void *object;
 struct acpi_namespace_node *node;
 union acpi_operand_object **where;
 u8 *index_pointer;
 u8 *aml;
 u32 value;
};
struct acpi_object_extra {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 struct acpi_namespace_node *method_REG;
 struct acpi_namespace_node *scope_node;
 void *region_context;
 u8 *aml_start;
 u32 aml_length;
};
struct acpi_object_data {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 acpi_object_handler handler;
 void *pointer;
};
struct acpi_object_cache_list {
 union acpi_operand_object *next_object; u8 descriptor_type; u8 type; u16 reference_count; u8 flags;
 union acpi_operand_object *next;
};
union acpi_operand_object {
 struct acpi_object_common common;
 struct acpi_object_integer integer;
 struct acpi_object_string string;
 struct acpi_object_buffer buffer;
 struct acpi_object_package package;
 struct acpi_object_event event;
 struct acpi_object_method method;
 struct acpi_object_mutex mutex;
 struct acpi_object_region region;
 struct acpi_object_notify_common common_notify;
 struct acpi_object_device device;
 struct acpi_object_power_resource power_resource;
 struct acpi_object_processor processor;
 struct acpi_object_thermal_zone thermal_zone;
 struct acpi_object_field_common common_field;
 struct acpi_object_region_field field;
 struct acpi_object_buffer_field buffer_field;
 struct acpi_object_bank_field bank_field;
 struct acpi_object_index_field index_field;
 struct acpi_object_notify_handler notify;
 struct acpi_object_addr_handler address_space;
 struct acpi_object_reference reference;
 struct acpi_object_extra extra;
 struct acpi_object_data data;
 struct acpi_object_cache_list cache;






 struct acpi_namespace_node node;
};
struct acpi_walk_state {
 struct acpi_walk_state *next;
 u8 descriptor_type;
 u8 walk_type;
 u16 opcode;
 u8 next_op_info;
 u8 num_operands;
 u8 operand_index;
 acpi_owner_id owner_id;
 u8 last_predicate;
 u8 current_result;
 u8 return_used;
 u8 scope_depth;
 u8 pass_number;
 u8 namespace_override;
 u8 result_size;
 u8 result_count;
 u8 *aml;
 u32 arg_types;
 u32 method_breakpoint;
 u32 user_breakpoint;
 u32 parse_flags;

 struct acpi_parse_state parser_state;
 u32 prev_arg_types;
 u32 arg_count;
 u16 method_nesting_depth;
 u8 method_is_nested;

 struct acpi_namespace_node arguments[7];
 struct acpi_namespace_node local_variables[8];
 union acpi_operand_object *operands[8 + 1];
 union acpi_operand_object **params;

 u8 *aml_last_while;
 union acpi_operand_object **caller_return_desc;
 union acpi_generic_state *control_state;
 struct acpi_namespace_node *deferred_node;
 union acpi_operand_object *implicit_return_obj;
 struct acpi_namespace_node *method_call_node;
 union acpi_parse_object *method_call_op;
 union acpi_operand_object *method_desc;
 struct acpi_namespace_node *method_node;
 char *method_pathname;
 union acpi_parse_object *op;
 const struct acpi_opcode_info *op_info;
 union acpi_parse_object *origin;
 union acpi_operand_object *result_obj;
 union acpi_generic_state *results;
 union acpi_operand_object *return_desc;
 union acpi_generic_state *scope_info;
 union acpi_parse_object *prev_op;
 union acpi_parse_object *next_op;
 struct acpi_thread_state *thread;
 acpi_parse_downwards descending_callback;
 acpi_parse_upwards ascending_callback;
};
void
acpi_ut_trace_u32(u32 line_number,
    const char *function_name,
    const char *module_name, u32 component_id, u32 integer);
void
acpi_ut_status_exit(u32 line_number,
      const char *function_name,
      const char *module_name,
      u32 component_id, acpi_status status);
acpi_status
acpi_ex_write_with_update_rule(union acpi_operand_object *obj_desc,
          u64 mask,
          u64 field_value, u32 field_datum_byte_offset);
typedef enum {
 AML_FIELD_UPDATE_PRESERVE = 0x00,
 AML_FIELD_UPDATE_WRITE_AS_ONES = 0x20,
 AML_FIELD_UPDATE_WRITE_AS_ZEROS = 0x40
} AML_UPDATE_RULE;
static const char  _acpi_module_name[] = "exfldio";
static acpi_status
acpi_ex_field_datum_io(union acpi_operand_object *obj_desc,
         u32 field_datum_byte_offset, u64 *value, u32 read_write);
static acpi_status
acpi_ex_field_datum_io(union acpi_operand_object *obj_desc,
         u32 field_datum_byte_offset, u64 *value, u32 read_write)
;
/*@ requires mask <= (u64)(~((u64) 0)); ensures \result == 0 || \result == ((acpi_status) (0x0004 | 0x3000)) || \result == (acpi_status) 0x0000; */

acpi_status
acpi_ex_write_with_update_rule(union acpi_operand_object *obj_desc,
          u64 mask,
          u64 field_value, u32 field_datum_byte_offset)
{
 acpi_status status = (acpi_status) 0x0000;
 u64 merged_value;
 u64 current_value;

 acpi_ut_trace_u32 (552, __func__, _acpi_module_name, 0x00000080, (u32) (mask));



 merged_value = field_value;



 if (mask != (u64)(~((u64) 0))) {



  switch (obj_desc->common_field.
   field_flags & 0x60) {
  case AML_FIELD_UPDATE_PRESERVE:




   if ((~mask << (((u32) ((sizeof(mask)) << (3))) -
           ((u32) ((obj_desc->common_field. access_byte_width) << (3)))
                          )) != 0) {




    status =
        acpi_ex_field_datum_io(obj_desc,
          field_datum_byte_offset,
          &current_value,
          0);
    if ((status)) {
     do { register acpi_status _param = (acpi_status) (status); acpi_ut_status_exit (584, __func__, _acpi_module_name, 0x00000080, _param); return (_param); } while(0);
    }

    merged_value |= (current_value & ~mask);
   }
   break;

  case AML_FIELD_UPDATE_WRITE_AS_ONES:



   merged_value |= ~mask;
   break;

  case AML_FIELD_UPDATE_WRITE_AS_ZEROS:



   merged_value &= mask;
   break;

  default:

   acpi_error (_acpi_module_name, 607, "Unknown UpdateRule value: 0x%X", (obj_desc->common_field.field_flags & 0x60))


                                      ;
   do { register acpi_status _param = (acpi_status) (((acpi_status) (0x0004 | 0x3000))); acpi_ut_status_exit (611, __func__, _acpi_module_name, 0x00000080, _param); return (_param); } while(0);
  }
 }

 do { if ((((u32) 0x00001000 & acpi_dbg_level) && (0x00000080 & acpi_dbg_layer))) { acpi_debug_print ((u32) 0x00001000, 615, __func__, _acpi_module_name, 0x00000080, "Mask %8.8X%8.8X, DatumOffset %X, Width %X, " "Value %8.8X%8.8X, MergedValue %8.8X%8.8X\n", ((u32)(((u64)(mask)) >> 32)), ((u32) (u64)(mask)), field_datum_byte_offset, obj_desc->common_field.access_byte_width, ((u32)(((u64)(field_value)) >> 32)), ((u32) (u64)(field_value)), ((u32)(((u64)(merged_value)) >> 32)), ((u32) (u64)(merged_value))); } } while(0)






                                       ;



 status =
     acpi_ex_field_datum_io(obj_desc, field_datum_byte_offset,
       &merged_value, 1);

 do { register acpi_status _param = (acpi_status) (status); acpi_ut_status_exit (630, __func__, _acpi_module_name, 0x00000080, _param); return (_param); } while(0);
}

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
int main(void) {
  union acpi_operand_object * obj_desc;
  u64 mask;
  u64 field_value;
  u32 field_datum_byte_offset;
  __CPROVER_assume(((((__int128)(((__int128)(mask)) <= ((__int128)(u64)(((~(((__int128)(u64)(((__int128)0ULL))))))))))) != 0));
  extern void *malloc(unsigned long);
  { int c_obj_desc; obj_desc = c_obj_desc ? 0 : malloc(sizeof(union acpi_operand_object)); }
  acpi_status bv_r = acpi_ex_write_with_update_rule(obj_desc, mask, field_value, field_datum_byte_offset);
  __CPROVER_assert((((__int128)((((__int128)((((__int128)(((__int128)bv_r) == ((__int128)0ULL))) != 0) || (((__int128)(((__int128)bv_r) == (((__int128)(acpi_status)(((((__int128)0x0004ULL) | ((__int128)0x3000ULL)))))))) != 0))) != 0) || (((__int128)(((__int128)bv_r) == ((__int128)(acpi_status)(((__int128)0x0000ULL))))) != 0))) != 0), "ensures");
  return 0;
}
