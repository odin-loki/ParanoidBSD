__extension__ typedef unsigned long long __u64;
typedef __u64 u64;
/*@ requires fields >= 0; ensures \result == (((fields & 1) != 0 ? 0x1ff : 0) | ((fields & 2) != 0 ? (7 << 18) : 0) | ((fields & 4) != 0 ? (0xfffffe2aULL << 32) : 0)); */

static u64 knl_cha_filter_mask(int fields)
{
 u64 mask = 0;

 if (fields & 0x1)
  mask |= 0x1ff;
 if (fields & 0x2)
  mask |= (7 << 18);
 if (fields & 0x4)
  mask |= (0xfffffe2aULL << 32);
 return mask;
}
