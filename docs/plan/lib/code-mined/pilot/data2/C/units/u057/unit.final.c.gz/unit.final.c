typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u8 u8;
typedef __u16 u16;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
struct acpi_subtable_header {
 u8 type;
 u8 length;
};
struct acpi_cdat_header {
 u8 type;
 u8 reserved;
 u16 length;
};
struct acpi_cedt_header {
 u8 type;
 u8 reserved;
 u16 length;
};
struct acpi_hmat_structure {
 u16 type;
 u16 reserved;
 u32 length;
};
enum acpi_madt_type {
 ACPI_MADT_TYPE_LOCAL_APIC = 0,
 ACPI_MADT_TYPE_IO_APIC = 1,
 ACPI_MADT_TYPE_INTERRUPT_OVERRIDE = 2,
 ACPI_MADT_TYPE_NMI_SOURCE = 3,
 ACPI_MADT_TYPE_LOCAL_APIC_NMI = 4,
 ACPI_MADT_TYPE_LOCAL_APIC_OVERRIDE = 5,
 ACPI_MADT_TYPE_IO_SAPIC = 6,
 ACPI_MADT_TYPE_LOCAL_SAPIC = 7,
 ACPI_MADT_TYPE_INTERRUPT_SOURCE = 8,
 ACPI_MADT_TYPE_LOCAL_X2APIC = 9,
 ACPI_MADT_TYPE_LOCAL_X2APIC_NMI = 10,
 ACPI_MADT_TYPE_GENERIC_INTERRUPT = 11,
 ACPI_MADT_TYPE_GENERIC_DISTRIBUTOR = 12,
 ACPI_MADT_TYPE_GENERIC_MSI_FRAME = 13,
 ACPI_MADT_TYPE_GENERIC_REDISTRIBUTOR = 14,
 ACPI_MADT_TYPE_GENERIC_TRANSLATOR = 15,
 ACPI_MADT_TYPE_MULTIPROC_WAKEUP = 16,
 ACPI_MADT_TYPE_CORE_PIC = 17,
 ACPI_MADT_TYPE_LIO_PIC = 18,
 ACPI_MADT_TYPE_HT_PIC = 19,
 ACPI_MADT_TYPE_EIO_PIC = 20,
 ACPI_MADT_TYPE_MSI_PIC = 21,
 ACPI_MADT_TYPE_BIO_PIC = 22,
 ACPI_MADT_TYPE_LPC_PIC = 23,
 ACPI_MADT_TYPE_RINTC = 24,
 ACPI_MADT_TYPE_IMSIC = 25,
 ACPI_MADT_TYPE_APLIC = 26,
 ACPI_MADT_TYPE_PLIC = 27,
 ACPI_MADT_TYPE_RESERVED = 28,
 ACPI_MADT_TYPE_OEM_RESERVED = 0x80
};
struct acpi_prmt_module_header {
 u16 revision;
 u16 length;
};
union acpi_subtable_headers;
typedef int (*acpi_tbl_entry_handler)(union acpi_subtable_headers *header,
          const unsigned long end);
union acpi_subtable_headers {
 struct acpi_subtable_header common;
 struct acpi_hmat_structure hmat;
 struct acpi_prmt_module_header prmt;
 struct acpi_cedt_header cedt;
 struct acpi_cdat_header cdat;
};
union acpi_subtable_headers;
int acpi_table_parse_madt(enum acpi_madt_type id,
     acpi_tbl_entry_handler handler,
     unsigned int max_entries);
static int  pch_pic_parse_madt(union acpi_subtable_headers *header,
     const unsigned long end)
;
static int  pch_msi_parse_madt(union acpi_subtable_headers *header,
     const unsigned long end)
;
/*@ requires true; ensures \result == 0 || \result < 0; */

static int  acpi_cascade_irqdomain_init(void)
{
 int r;

 r = acpi_table_parse_madt(ACPI_MADT_TYPE_BIO_PIC, pch_pic_parse_madt, 0);
 if (r < 0)
  return r;

 r = acpi_table_parse_madt(ACPI_MADT_TYPE_MSI_PIC, pch_msi_parse_madt, 0);
 if (r < 0)
  return r;

 return 0;
}
