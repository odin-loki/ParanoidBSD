typedef unsigned short __u16;
__extension__ typedef unsigned long long __u64;
typedef __u16 u16;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == (num <= 65535); */

static bool is_unum_decimal(u64 num)
{
 return num <= ((u16)~0U);
}
