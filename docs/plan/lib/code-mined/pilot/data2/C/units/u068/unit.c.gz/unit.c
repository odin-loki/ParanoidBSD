typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __int64_t __intmax_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __size_t;
typedef __int64_t __register_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint32_t __gid_t;
typedef __int32_t __lwpid_t;
typedef __int64_t __off_t;
typedef __int32_t __pid_t;
typedef __int64_t __sbintime_t;
typedef __int64_t __rlim_t;
typedef long __suseconds_t;
typedef __uint32_t __uid_t;
typedef int __cpusetid_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __intmax_t intmax_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef char * caddr_t;
typedef __cpusetid_t cpusetid_t;
typedef __gid_t gid_t;
typedef __uint32_t in_addr_t;
typedef __lwpid_t lwpid_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __register_t register_t;
typedef __rlim_t rlim_t;
typedef __sbintime_t sbintime_t;
typedef __size_t size_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __vm_offset_t vm_offset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __register_t syscallarg_t;
typedef struct _device *device_t;
typedef _Bool bool;
typedef struct __sigset {
 __uint32_t __bits[4];
} __sigset_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
typedef __sigset_t sigset_t;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct lock_list_entry;
struct thread;
struct bintime {
 time_t sec;
 uint64_t frac;
};
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
void bintime(struct bintime *bt);
struct _cpuset { unsigned long __bits[(((((1)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
typedef struct _cpuset cpuset_t;
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
 long ru_maxrss;
 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;
};
struct system_segment_descriptor {
 u_int64_t sd_lolimit:16;
 u_int64_t sd_lobase:24;
 u_int64_t sd_type:5;
 u_int64_t sd_dpl:2;
 u_int64_t sd_p:1;
 u_int64_t sd_hilimit:4;
 u_int64_t sd_xx0:3;
 u_int64_t sd_gran:1;
 u_int64_t sd_hibase:40 __attribute__((__packed__));
 u_int64_t sd_xx1:8;
 u_int64_t sd_mbz:5;
 u_int64_t sd_xx2:19;
} __attribute__((__packed__));
struct region_descriptor {
 uint64_t rd_limit:16;
 uint64_t rd_base:64 __attribute__((__packed__));
} __attribute__((__packed__));
struct amd64tss {
 u_int32_t tss_rsvd0;
 u_int64_t tss_rsp0 __attribute__((__packed__));
 u_int64_t tss_rsp1 __attribute__((__packed__));
 u_int64_t tss_rsp2 __attribute__((__packed__));
 u_int32_t tss_rsvd1;
 u_int32_t tss_rsvd2;
 u_int64_t tss_ist1 __attribute__((__packed__));
 u_int64_t tss_ist2 __attribute__((__packed__));
 u_int64_t tss_ist3 __attribute__((__packed__));
 u_int64_t tss_ist4 __attribute__((__packed__));
 u_int64_t tss_ist5 __attribute__((__packed__));
 u_int64_t tss_ist6 __attribute__((__packed__));
 u_int64_t tss_ist7 __attribute__((__packed__));
 u_int32_t tss_rsvd3;
 u_int32_t tss_rsvd4;
 u_int16_t tss_rsvd5;
 u_int16_t tss_iobase;
};
struct lock_profile_object;
struct lpohead { struct lock_profile_object *lh_first; };
struct region_descriptor;
static __inline u_short
rss(void)
;
struct vnode;
struct thread;
struct proc;
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct inpcb;
struct lock_object;
struct malloc_type;
struct mtx;
struct proc;
struct socket;
struct thread;
struct tty;
struct ucred;
struct trapframe;
void log(int, const char *, ...) ;
static __inline u_int max(u_int a, u_int b) ;
struct malloc_type;
struct cdev;
struct malloc_type_stats {
 uint64_t mts_memalloced;
 uint64_t mts_memfreed;
 uint64_t mts_numallocs;
 uint64_t mts_numfrees;
 uint64_t mts_size;
 uint64_t _mts_reserved1;
 uint64_t _mts_reserved2;
 uint64_t _mts_reserved3;
};
struct malloc_type_internal {
 uint32_t mti_probes[2];

 u_char mti_zone;
 struct malloc_type_stats *mti_stats;
 u_long mti_spare[8];
};
struct malloc_type {
 struct malloc_type *ks_next;
 u_long ks_version;
 const char *ks_shortdesc;
 struct malloc_type_internal ks_mti;
};
struct domainset;
struct uma_zone;
typedef struct uma_zone * uma_zone_t;
struct mbuf;
struct m_tag {
 struct { struct m_tag *sle_next; } m_tag_link;
 u_int16_t m_tag_id;
 u_int16_t m_tag_len;
 u_int32_t m_tag_cookie;
 void (*m_tag_free)(struct m_tag *);
};
struct if_snd_tag_sw;
struct m_snd_tag {
 struct ifnet *ifp;
 const struct if_snd_tag_sw *sw;
 volatile u_int refcount;
};
struct pkthdr {
 union {
  struct m_snd_tag *snd_tag;
  struct ifnet *rcvif;
  struct {
   uint16_t rcvidx;
   uint16_t rcvgen;
  };
 };
 union {
  struct ifnet *leaf_rcvif;
  struct {
   uint16_t leaf_rcvidx;
   uint16_t leaf_rcvgen;
  };
 };
 struct packet_tags { struct m_tag *slh_first; } tags;
 int32_t len;


 uint32_t flowid;
 uint32_t csum_flags;
 uint16_t fibnum;
 uint8_t numa_domain;
 uint8_t rsstype;



 union {
  uint64_t rcv_tstmp;
  struct {
   uint8_t l2hlen;
   uint8_t l3hlen;
   uint8_t l4hlen;
   uint8_t l5hlen;
   uint8_t inner_l2hlen;
   uint8_t inner_l3hlen;
   uint8_t inner_l4hlen;
   uint8_t inner_l5hlen;
  };
 };
 union {
  uint8_t eight[8];
  uint16_t sixteen[4];
  uint32_t thirtytwo[2];
  uint64_t sixtyfour[1];
  uintptr_t unintptr[1];
  void *ptr;
 } PH_per;


 union {
  union {
   uint8_t eight[8];
   uint16_t sixteen[4];
   uint32_t thirtytwo[2];
   uint64_t sixtyfour[1];
   uintptr_t unintptr[1];
   void *ptr;
  } PH_loc;

  u_int memlen;
 };
};
struct ktls_session;
struct socket;
typedef void m_ext_free_t(struct mbuf *);
struct m_ext {
 union {
  volatile u_int ext_count;
  volatile u_int *ext_cnt;
 };
 uint32_t ext_size;
 uint32_t ext_type:8,
    ext_flags:24;
 union {
  struct {
   char *ext_buf;
   void *ext_arg2;
  };
  struct {







   vm_paddr_t extpg_pa[(40 / sizeof(vm_paddr_t))];
   char extpg_trail[64];
   char extpg_hdr[23];

  };
 };




 m_ext_free_t *ext_free;
 void *ext_arg1;
};
struct mbuf {







 union {
  struct mbuf *m_next;
  struct { struct mbuf *sle_next; } m_slist;
  struct { struct mbuf *stqe_next; } m_stailq;
 };
 union {
  struct mbuf *m_nextpkt;
  struct { struct mbuf *sle_next; } m_slistpkt;
  struct { struct mbuf *stqe_next; } m_stailqpkt;
 };
 caddr_t m_data;
 int32_t m_len;
 uint32_t m_type:8,
    m_flags:24;
 union {
  struct {
   union {

    struct pkthdr m_pkthdr;
    struct {


     uint8_t m_epg_npgs;
     uint8_t m_epg_nrdy;


     uint8_t m_epg_hdrlen;
     uint8_t m_epg_trllen;


     uint16_t m_epg_1st_off;
     uint16_t m_epg_last_len;
     uint8_t m_epg_flags;
     uint8_t m_epg_record_type;
     uint8_t __spare[2];
     int m_epg_enc_cnt;
     struct ktls_session *m_epg_tls;
     struct socket *m_epg_so;
     uint64_t m_epg_seqno;
     struct { struct mbuf *stqe_next; } m_epg_stailq;
    };
   };
   union {

    struct m_ext m_ext;

    char m_pktdat[1];
   };
  };
  char m_dat[1];
 };
};
static __inline void
m_tag_free(struct m_tag *t)
;
struct mbufq {
 struct { struct mbuf *stqh_first; struct mbuf **stqh_last; } mq_head;
 int mq_len;
 int mq_maxlen;
};
struct socket;
extern int tick;
typedef void task_fn_t(void *context, int pending);
struct task {
 struct { struct task *stqe_next; } ta_link;
 uint16_t ta_pending;
 uint8_t ta_priority;
 uint8_t ta_flags;
 task_fn_t *ta_func;
 void *ta_context;
};
struct taskqueue;
struct timeout_task {
 struct taskqueue *q;
 struct task t;
 struct callout c;
 int f;
};
struct tls_session_params {
 uint8_t *cipher_key;
 uint8_t *auth_key;
 uint8_t iv[16];
 int cipher_algorithm;
 int auth_algorithm;
 uint16_t cipher_key_len;
 uint16_t iv_len;
 uint16_t auth_key_len;
 uint16_t max_frame_len;
 uint8_t tls_vmajor;
 uint8_t tls_vminor;
 uint8_t tls_hlen;
 uint8_t tls_tlen;
 uint8_t tls_bs;
 uint8_t flags;
};
struct ktls_ocf_session;
struct ktls_session;
struct m_snd_tag;
struct mbuf;
struct sockbuf;
struct socket;
struct ktls_session {
 struct ktls_ocf_session *ocf_session;
 struct m_snd_tag *snd_tag;
 struct tls_session_params params;
 u_int wq_index;
 volatile u_int refcount;
 int mode;

 struct task reset_tag_task;
 struct task disable_ifnet_task;
 union {
  struct inpcb *inp;
  struct socket *so;
 };
 struct ifnet *rx_ifp;
 u_short rx_vlan_id;
 bool reset_pending;
 bool tx;
 bool sync_dispatch;
 bool sequential_records;
 union {

  uint64_t next_seqno;

  uint64_t initial_offload_seqno;
 };
 struct { struct mbuf *stqh_first; struct mbuf **stqh_last; } pending_records;


 struct task destroy_task;

 uint64_t gen;
} ;
struct taskqueue;
struct proc;
struct thread;
struct sglist_seg {
 vm_paddr_t ss_paddr;
 size_t ss_len;
};
struct sglist {
 struct sglist_seg *sg_segs;
 u_int sg_refs;
 u_short sg_nseg;
 u_short sg_maxseg;
};
struct mbuf;
struct thread;
struct thread;
struct sysctl_req {
 struct thread *td;
 int lock;
 void *oldptr;
 size_t oldlen;
 size_t oldidx;
 int (*oldfunc)(struct sysctl_req *, const void *, size_t);
 const void *newptr;
 size_t newlen;
 size_t newidx;
 int (*newfunc)(struct sysctl_req *, void *, size_t);
 size_t validlen;
 int flags;
};
struct sysctl_oid;
struct sysctl_oid_list { struct sysctl_oid *rbh_root; };
struct sysctl_oid {
 struct sysctl_oid_list oid_children;
 struct sysctl_oid_list* oid_parent;
 struct { struct sysctl_oid *rbe_link[3]; } oid_link;

 int oid_number;
 u_int oid_kind;
 void *oid_arg1;
 intmax_t oid_arg2;

 const char *oid_name;
 int (*oid_handler)(struct sysctl_oid *oidp, void *arg1, intmax_t arg2, struct sysctl_req *req);
 const char *oid_fmt;
 int oid_refcnt;
 u_int oid_running;
 const char *oid_descr;
 const char *oid_label;
};
struct sysctl_ctx_entry {
 struct sysctl_oid *entry;
 struct { struct sysctl_ctx_entry *tqe_next; struct sysctl_ctx_entry **tqe_prev; } link;
};
struct sysctl_ctx_list { struct sysctl_ctx_entry *tqh_first; struct sysctl_ctx_entry **tqh_last; };
struct setlist { struct cpuset *lh_first; };
struct cpuset {
 volatile u_int cs_ref;
 int cs_flags;
 struct { struct cpuset *le_next; struct cpuset **le_prev; } cs_link;
 struct { struct cpuset *le_next; struct cpuset **le_prev; } cs_siblings;
 struct setlist cs_children;
 struct domainset *cs_domain;
 cpusetid_t cs_id;
 struct cpuset *cs_parent;
 cpuset_t cs_mask;
};
struct prison;
struct proc;
struct thread;
struct pcb;
typedef uint64_t so_gen_t;
struct kevent {
 __uintptr_t ident;
 short filter;
 unsigned short flags;
 unsigned int fflags;
 __int64_t data;
 void *udata;
 __uint64_t ext[4];
};
struct knote;
struct klist { struct knote *slh_first; };
struct kqueue;
struct knlist {
 struct klist kl_list;
 void (*kl_lock)(void *);
 void (*kl_unlock)(void *);
 void (*kl_assert_lock)(void *, int);
 void *kl_lockarg;
 int kl_autodestroy;
};
struct kinfo_knote;
struct proc;
struct filterops {
 int f_isfd;
 int (*f_attach)(struct knote *kn);
 void (*f_detach)(struct knote *kn);
 int (*f_event)(struct knote *kn, long hint);
 void (*f_touch)(struct knote *kn, struct kevent *kev, u_long type);
 int (*f_userdump)(struct proc *p, struct knote *kn,
      struct kinfo_knote *kin);
 int (*f_copy)(struct knote *kn, struct proc *p1);
};
struct knote {
 struct { struct knote *sle_next; } kn_link;
 struct { struct knote *sle_next; } kn_selnext;
 struct knlist *kn_knlist;
 struct { struct knote *tqe_next; struct knote **tqe_prev; } kn_tqe;
 struct kqueue *kn_kq;
 struct kevent kn_kevent;
 void *kn_hook;
 int kn_hookid;
 int kn_status;
 int kn_influx;
 unsigned int kn_sfflags;
 int64_t kn_sdata;
 union {
  struct file *p_fp;
  struct proc *p_proc;
  struct kaiocb *p_aio;
  struct aioliojob *p_lio;
  struct prison *p_prison;
  void *p_v;
 } kn_ptr;
 const struct filterops *kn_fop;

};
struct thread;
struct proc;
struct knlist;
struct mtx;
struct rwlock;
void knote(struct knlist *list, long hint, int lockflags);
struct selfd;
struct selfdlist { struct selfd *tqh_first; struct selfd **tqh_last; };
struct selinfo {
 struct selfdlist si_tdlist;
 struct knlist si_note;
 struct mtx *si_mtx;
};
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
struct ktls_session;
struct mbuf;
struct socket;
struct thread;
struct selinfo;
struct sockbuf {
 struct selinfo *sb_sel;
 short sb_state;
 short sb_flags;
 u_int sb_acc;
 u_int sb_ccc;
 u_int sb_mbcnt;
 u_int sb_ctl;
 u_int sb_hiwat;
 u_int sb_lowat;
 u_int sb_mbmax;
 sbintime_t sb_timeo;
 int (*sb_upcall)(struct socket *, void *, int);
 void *sb_upcallarg;
 struct { struct kaiocb *tqh_first; struct kaiocb **tqh_last; } sb_aiojobq;
 struct task sb_aiotask;
 union {







  struct {

   struct mtx *sb_mtx;

   struct mbuf *sb_mb;
   struct mbuf *sb_mbtail;

   struct mbuf *sb_lastrecord;

   struct mbuf *sb_sndptr;

   struct mbuf *sb_fnrdy;

   u_int sb_sndptroff;

   u_int sb_tlscc;
   u_int sb_tlsdcc;
   struct mbuf *sb_mtls;
   struct mbuf *sb_mtlstail;
   uint64_t sb_tls_seqno;

   struct ktls_session *sb_tls_info;
  };




  struct {
   struct { struct mbuf *stqh_first; struct mbuf **stqh_last; } uxst_mbq;
   struct mbuf *uxst_fnrdy;
   struct socket *uxst_peer;
   u_int uxst_flags;
  };
  struct {






   struct { struct mbuf *stqh_first; struct mbuf **stqh_last; } uxdg_mb;

   struct mbuf *uxdg_peeked;





   union {
    struct { struct sockbuf *tqh_first; struct sockbuf **tqh_last; } uxdg_conns;
    struct { struct sockbuf *tqe_next; struct sockbuf **tqe_prev; } uxdg_clist;
   };

   u_int uxdg_cc;
   u_int uxdg_ctl;
   u_int uxdg_mbcnt;
  };



  struct {
   struct { struct nl_buf *tqh_first; struct nl_buf **tqh_last; } nl_queue;
  };
 };
};
struct thread;
struct socket;
struct vnet;
typedef int so_upcall_t(struct socket *, void *, int);
typedef void so_dtor_t(struct socket *);
struct socket;
enum socket_qstate {
 SQ_NONE = 0,
 SQ_INCOMP = 0x0800,
 SQ_COMP = 0x1000,
};
struct so_splice {
 struct socket *src;
 struct socket *dst;
 off_t max;
 struct mtx mtx;
 unsigned int wq_index;
 enum so_splice_state {
  SPLICE_INIT,
  SPLICE_IDLE,
  SPLICE_QUEUED,
  SPLICE_RUNNING,
  SPLICE_CLOSING,
  SPLICE_CLOSED,
  SPLICE_EXCEPTION,
 } state;
 struct timeout_task timeout;
 struct { struct so_splice *stqe_next; } next;
};
struct accept_queue { struct socket *tqh_first; struct socket **tqh_last; };
struct socket {
 struct mtx so_lock;
 volatile u_int so_count;
 struct selinfo so_rdsel;
 struct selinfo so_wrsel;
 int so_options;
 short so_type;
 short so_state;
 void *so_pcb;
 struct vnet *so_vnet;
 struct protosw *so_proto;
 short so_linger;
 short so_timeo;
 u_short so_error;
 u_short so_rerror;
 struct sigio *so_sigio;

 struct ucred *so_cred;
 struct label *so_label;

 so_gen_t so_gencnt;
 void *so_emuldata;
 so_dtor_t *so_dtor;
 struct osd osd;






 int so_fibnum;
 uint32_t so_user_cookie;

 int so_ts_clock;
 uint32_t so_max_pacing_rate;
 struct so_splice *so_splice;
 struct so_splice *so_splice_back;
 off_t so_splice_sent;





 struct sx so_snd_sx ;
 struct mtx so_snd_mtx;

 struct sx so_rcv_sx ;
 struct mtx so_rcv_mtx;

 union {

  struct {

   struct sockbuf so_rcv, so_snd;


   struct { struct socket *tqe_next; struct socket **tqe_prev; } so_list;
   struct socket *so_listen;
   enum socket_qstate so_qstate;

   struct label *so_peerlabel;
   u_long so_oobmark;


   struct { struct socket *stqe_next; } so_ktls_rx_list;
  };
  struct {

   struct accept_queue sol_incomp;

   struct accept_queue sol_comp;
   u_int sol_qlen;
   u_int sol_incqlen;
   u_int sol_qlimit;


   struct accept_filter *sol_accept_filter;
   void *sol_accept_filter_arg;
   char *sol_accept_filter_str;


   so_upcall_t *sol_upcall;
   void *sol_upcallarg;



   int sol_sbrcv_lowat;
   int sol_sbsnd_lowat;
   u_int sol_sbrcv_hiwat;
   u_int sol_sbsnd_hiwat;
   short sol_sbrcv_flags;
   short sol_sbsnd_flags;
   sbintime_t sol_sbrcv_timeo;
   sbintime_t sol_sbsnd_timeo;


   struct timeval sol_lastover;
   int sol_overcount;
  };
 };
};
struct accept_filter {
 char accf_name[16];
 int (*accf_callback)
  (struct socket *so, void *arg, int waitflag);
 void * (*accf_create)
  (struct socket *so, char *arg);
 void (*accf_destroy)
  (struct socket *so);
 struct { struct accept_filter *sle_next; } accf_next;
};
extern so_gen_t so_gencnt;
struct file;
struct filedesc;
struct mbuf;
struct ucred;
typedef uint64_t *counter_u64_t;
typedef u_int32_t bpf_u_int32;
struct ifnet;
struct bpf_program {
 u_int bf_len;
 struct bpf_insn *bf_insns;
};
struct bpf_insn {
 u_short code;
 u_char jt;
 u_char jf;
 bpf_u_int32 k;
};
struct ifnet;
struct mbuf;
struct ifnet;
struct mbuf;
struct ifmediareq {
 char ifm_name[16];
 int ifm_current;
 int ifm_mask;
 int ifm_status;
 int ifm_active;
 int ifm_count;
 int *ifm_ulist;
};
typedef struct ifnet *if_t;
struct in_addr {
 in_addr_t s_addr;
};
struct vnet {
 struct { struct vnet *le_next; struct vnet **le_prev; } vnet_le;
 u_int vnet_magic_n;
 u_int vnet_ifcnt;
 u_int vnet_sockcnt;
 u_int vnet_state;
 void *vnet_data_mem;
 uintptr_t vnet_data_base;
 bool vnet_shutdown;
} ;
struct ifnet;
struct mbuf;
struct in6_addr {
 union {
  uint8_t __u6_addr8[16];
  uint16_t __u6_addr16[8];
  uint32_t __u6_addr32[4];
 } __u6_addr;
};
struct ip6_hdr;
struct ip {

 u_char ip_hl:4,
  ip_v:4;





 u_char ip_tos;
 u_short ip_len;
 u_short ip_id;
 u_short ip_off;
 u_char ip_ttl;
 u_char ip_p;
 u_short ip_sum;
 struct in_addr ip_src,ip_dst;
} __attribute__((__packed__));
struct ip6_hdr {
 union {
  struct ip6_hdrctl {
   u_int32_t ip6_un1_flow;
   u_int16_t ip6_un1_plen;
   u_int8_t ip6_un1_nxt;
   u_int8_t ip6_un1_hlim;
  } ip6_un1;
  u_int8_t ip6_un2_vfc;
 } ip6_ctlun;
 struct in6_addr ip6_src;
 struct in6_addr ip6_dst;
} __attribute__((__packed__));
typedef u_int32_t tcp_seq;
struct tcphdr {
 u_short th_sport;
 u_short th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;

 u_char th_x2:4,
  th_off:4;





 u_char th_flags;

 u_short th_win;
 u_short th_sum;
 u_short th_urp;
} __attribute__((__packed__));
struct udphdr {
 u_short uh_sport;
 u_short uh_dport;
 u_short uh_ulen;
 u_short uh_sum;
} __attribute__((__packed__));
struct pcb;
struct thread;
struct trapframe;
struct savefpu;
struct sysentvec;
struct trapframe;
struct vm_map_entry;
struct ucred;
struct thread;
struct thread;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef uint8_t __u8;
typedef uint16_t __be16;
typedef uint32_t __be32;
typedef uint64_t __be64;
enum {
 NCHAN = 4,
 T6_NCHAN = 2,
 MAX_NCHAN = 4,
 MAX_MTU = 9600,
 EEPROMSIZE = 17408,
 EEPROMVSIZE = 32768,
 EEPROMPFSIZE = 1024,
 RSS_NENTRIES = 2048,
 T6_RSS_NENTRIES = 4096,
 T7_RSS_NENTRIES = 16384,
 TCB_SIZE = 128,
 NMTUS = 16,
 NCCTRL_WIN = 32,
 NTX_SCHED = 8,
 PM_NSTATS = 5,
 T6_PM_NSTATS = 7,
 MAX_PM_NSTATS = 7,
 T7_PM_RX_CACHE_NSTATS = 27,
 MBOX_LEN = 64,
 NTRACE = 4,
 TRACE_LEN = 112,
 FILTER_OPT_LEN = 36,
 T5_FILTER_OPT_LEN = 40,
 T7_FILTER_OPT_LEN = 63,
 NWOL_PAT = 8,
 WOL_PAT_LEN = 128,
 UDBS_SEG_SIZE = 128,
 UDBS_SEG_SHIFT = 7,
 UDBS_DB_OFFSET = 8,
 UDBS_WR_OFFSET = 64,
 MAX_UP_CORES = 8,
};
enum {
 SGE_MAX_WR_LEN = 512,
 SGE_CTXT_SIZE = 24,
 SGE_CTXT_SIZE_T7 = 28,
 SGE_NTIMERS = 6,
 SGE_NCOUNTERS = 4,
 SGE_NDBQTIMERS = 8,
 SGE_MAX_IQ_SIZE = 65520,
 SGE_FLBUF_SIZES = 16,
};
struct rsp_ctrl {
 __be32 hdrbuflen_pidx;
 __be32 pldbuflen_qid;
 union {
  u8 type_gen;
  __be64 last_flit;
 } u;
};
enum {
 MAX_NPORTS = 4,
 SERNUM_LEN = 24,
 EC_LEN = 16,
 ID_LEN = 16,
 PN_LEN = 16,
 MD_LEN = 16,
 MACADDR_LEN = 12,
};
struct port_stats {
 u64 tx_octets;
 u64 tx_frames;
 u64 tx_bcast_frames;
 u64 tx_mcast_frames;
 u64 tx_ucast_frames;
 u64 tx_error_frames;

 u64 tx_frames_64;
 u64 tx_frames_65_127;
 u64 tx_frames_128_255;
 u64 tx_frames_256_511;
 u64 tx_frames_512_1023;
 u64 tx_frames_1024_1518;
 u64 tx_frames_1519_max;

 u64 tx_drop;
 u64 tx_pause;
 u64 tx_ppp0;
 u64 tx_ppp1;
 u64 tx_ppp2;
 u64 tx_ppp3;
 u64 tx_ppp4;
 u64 tx_ppp5;
 u64 tx_ppp6;
 u64 tx_ppp7;

 u64 rx_octets;
 u64 rx_frames;
 u64 rx_bcast_frames;
 u64 rx_mcast_frames;
 u64 rx_ucast_frames;
 u64 rx_too_long;
 u64 rx_jabber;
 u64 rx_fcs_err;
 u64 rx_len_err;
 u64 rx_symbol_err;
 u64 rx_runt;

 u64 rx_frames_64;
 u64 rx_frames_65_127;
 u64 rx_frames_128_255;
 u64 rx_frames_256_511;
 u64 rx_frames_512_1023;
 u64 rx_frames_1024_1518;
 u64 rx_frames_1519_max;

 u64 rx_pause;
 u64 rx_ppp0;
 u64 rx_ppp1;
 u64 rx_ppp2;
 u64 rx_ppp3;
 u64 rx_ppp4;
 u64 rx_ppp5;
 u64 rx_ppp6;
 u64 rx_ppp7;

 u64 rx_ovflow0;
 u64 rx_ovflow1;
 u64 rx_ovflow2;
 u64 rx_ovflow3;
 u64 rx_trunc0;
 u64 rx_trunc1;
 u64 rx_trunc2;
 u64 rx_trunc3;
};
struct sge_params {
 int timer_val[SGE_NTIMERS];
 int counter_val[SGE_NCOUNTERS];
 int fl_starve_threshold;
 int fl_starve_threshold2;
 int page_shift;
 int eq_s_qpp;
 int iq_s_qpp;
 int spg_len;
 int pad_boundary;
 int pack_boundary;
 int fl_pktshift;
 u32 sge_control;
 u32 sge_fl_buffer_size[SGE_FLBUF_SIZES];
};
struct tp_params {
 unsigned int tre;
 unsigned int dack_re;
 unsigned int la_mask;

 uint16_t filter_mode;
 uint16_t filter_mask;
 int vnic_mode;
 uint32_t max_rx_pdu;
 uint32_t max_tx_pdu;
 bool rx_pkt_encap;
 uint8_t lb_mode;
 uint8_t lb_nchan;

 int8_t ipsecidx_shift;
 int8_t fcoe_shift;
 int8_t port_shift;
 int8_t vnic_shift;
 int8_t vlan_shift;
 int8_t tos_shift;
 int8_t protocol_shift;
 int8_t ethertype_shift;
 int8_t macmatch_shift;
 int8_t matchtype_shift;
 int8_t frag_shift;
 int8_t roce_shift;
 int8_t synonly_shift;
 int8_t tcpflags_shift;
};
struct vpd_params {
 unsigned int cclk;
 u8 ec[EC_LEN + 1];
 u8 sn[SERNUM_LEN + 1];
 u8 id[ID_LEN + 1];
 u8 pn[PN_LEN + 1];
 u8 na[MACADDR_LEN + 1];
 u8 md[MD_LEN + 1];
};
struct pf_resources {
 unsigned int nvi;
 unsigned int neq;
 unsigned int nethctrl;
 unsigned int niqflint;
 unsigned int niq;
 unsigned int tc;
 unsigned int pmask;
 unsigned int nexactf;
 unsigned int r_caps;
 unsigned int wx_caps;
};
struct pci_params {
 unsigned int vpd_cap_addr;
 unsigned int mps;
 unsigned short speed;
 unsigned short width;
};
struct devlog_params {
 u32 memtype;
 u32 start;
 u32 size;
 u32 addr;
};
struct chip_params {
 u8 nchan;
 u8 pm_stats_cnt;
 u8 cng_ch_bits_log;
 u8 nsched_cls;
 u8 cim_num_ibq;
 u8 cim_num_obq;
 u8 filter_opt_len;
 u8 filter_num_opt;
 u8 sge_ctxt_size;
 u16 mps_rplc_size;
 u16 vfcount;
 u32 sge_fl_db;
 u16 mps_tcam_size;
 u16 rss_nentries;
 u16 cim_la_size;
};
struct rss_params {
 unsigned int mode;
 union {
     struct {
  u_int synmapen:1;
  u_int syn4tupenipv6:1;
  u_int syn2tupenipv6:1;
  u_int syn4tupenipv4:1;
  u_int syn2tupenipv4:1;
  u_int ofdmapen:1;
  u_int tnlmapen:1;
  u_int tnlalllookup:1;
  u_int hashtoeplitz:1;
     } basicvirtual;
 } u;
};
struct vf_resources {
 unsigned int nvi;
 unsigned int neq;
 unsigned int nethctrl;
 unsigned int niqflint;
 unsigned int niq;
 unsigned int tc;
 unsigned int pmask;
 unsigned int nexactf;
 unsigned int r_caps;
 unsigned int wx_caps;
};
struct adapter_params {
 struct sge_params sge;
 struct tp_params tp;
 struct vpd_params vpd;
 struct pf_resources pfres;
 struct pci_params pci;
 struct devlog_params devlog;
 struct rss_params rss;
 struct vf_resources vfres;
 unsigned int core_vdd;

 unsigned int sf_size;
 unsigned int sf_nsec;

 unsigned int fw_vers;
 unsigned int bs_vers;
 unsigned int tp_vers;
 unsigned int er_vers;
 unsigned int scfg_vers;
 unsigned int vpd_vers;

 unsigned short mtus[NMTUS];
 unsigned short a_wnd[NCCTRL_WIN];
 unsigned short b_wnd[NCCTRL_WIN];

 unsigned int cim_la_size;

 uint8_t nports;
 uint8_t portvec;
 unsigned int chipid:4;
 unsigned int rev:4;
 unsigned int fpga:1;
 unsigned int offload:1;

 unsigned int bypass:1;
 unsigned int ethoffload:1;
 unsigned int hash_filter:1;
 unsigned int filter2_wr_support:1;
 unsigned int port_caps32:1;
 unsigned int smac_add_support:1;

 unsigned int ofldq_wr_cred;
 unsigned int eo_wr_cred;

 unsigned int max_ordird_qp;
 unsigned int max_ird_adapter;


 uint32_t mps_bg_map;
 uint32_t tp_ch_map;
 uint32_t tx_tp_ch_map;

 bool ulptx_memwrite_dsgl;
 bool fr_nsmr_tpte_wr_support;
 bool dev_512sgl_mr;
 bool viid_smt_extn_support;
 unsigned int max_pkts_per_eth_tx_pkts_wr;
 uint8_t nsched_cls;

 uint8_t ncores;
 uint32_t tid_qid_sel_mask;
};
struct link_config {

 int8_t requested_aneg;
 int8_t requested_fc;
 int8_t requested_fec;
 int8_t force_fec;
 u_int requested_speed;
 uint32_t requested_caps;


 uint32_t pcaps;
 uint32_t acaps;
 uint32_t lpacaps;
 u_int speed;
 int8_t fc;
 int8_t fec_hint;
 int8_t fec;
 bool link_ok;
 uint8_t link_down_rc;
};
typedef uint64_t bus_addr_t;
typedef uint64_t bus_size_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
struct malloc_type;
enum intr_type {
 INTR_TYPE_TTY = 1,
 INTR_TYPE_BIO = 2,
 INTR_TYPE_NET = 4,
 INTR_TYPE_CAM = 8,
 INTR_TYPE_MISC = 16,
 INTR_TYPE_CLK = 32,
 INTR_TYPE_AV = 64,
 INTR_EXCL = 256,
 INTR_MPSAFE = 512,
 INTR_ENTROPY = 1024,
 INTR_SLEEPABLE = 2048,
 INTR_MD1 = 4096,
 INTR_MD2 = 8192,
 INTR_MD3 = 16384,
 INTR_MD4 = 32768
};
struct resource;
struct _cpuset;
const char *device_get_nameunit(device_t dev);
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct rwlock {
 struct lock_object lock_object;
 volatile __uintptr_t rw_lock;
};
typedef uint32_t seqc_t;
struct trapframe {
 register_t tf_rdi;
 register_t tf_rsi;
 register_t tf_rdx;
 register_t tf_rcx;
 register_t tf_r8;
 register_t tf_r9;
 register_t tf_rax;
 register_t tf_rbx;
 register_t tf_rbp;
 register_t tf_r10;
 register_t tf_r11;
 register_t tf_r12;
 register_t tf_r13;
 register_t tf_r14;
 register_t tf_r15;
 uint32_t tf_trapno;
 uint16_t tf_fs;
 uint16_t tf_gs;
 register_t tf_addr;
 uint32_t tf_flags;
 uint16_t tf_es;
 uint16_t tf_ds;

 register_t tf_err;
 register_t tf_rip;
 uint16_t tf_cs;
 uint16_t tf_fred_evinfo3;
 uint32_t tf_fred_zero2;
 register_t tf_rflags;

 register_t tf_rsp;
 uint16_t tf_ss;
 uint16_t tf_fred_evinfo1;
 uint32_t tf_fred_evinfo2;
};
typedef struct vmem vmem_t;
struct mbuf;
struct socket;
struct vnet;
struct ifmedia;
struct ifnethead { struct ifnet *cstqh_first; struct ifnet **cstqh_last; };
struct ktls_session;
struct m_snd_tag;
struct if_snd_tag_rate_limit_params {
 uint64_t max_rate;
 uint32_t queue_level;
 uint32_t flags;
};
struct if_snd_tag_modify_tls_rx {

 uint32_t tls_hdr_tcp_sn;





 uint32_t tls_rec_length;


 uint64_t tls_seq_number;
};
union if_snd_tag_modify_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
 struct if_snd_tag_modify_tls_rx tls_rx;
};
union if_snd_tag_query_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
};
typedef int (if_snd_tag_modify_t)(struct m_snd_tag *, union if_snd_tag_modify_params *);
typedef int (if_snd_tag_query_t)(struct m_snd_tag *, union if_snd_tag_query_params *);
typedef void (if_snd_tag_free_t)(struct m_snd_tag *);
typedef struct m_snd_tag *(if_next_send_tag_t)(struct m_snd_tag *);
typedef int (if_snd_tag_status_str_t)(struct m_snd_tag *, char *buf, size_t *sz);
struct if_snd_tag_sw {
 if_snd_tag_modify_t *snd_tag_modify;
 if_snd_tag_query_t *snd_tag_query;
 if_snd_tag_free_t *snd_tag_free;
 if_next_send_tag_t *next_snd_tag;
 if_snd_tag_status_str_t *snd_tag_status_str;
 u_int type;
};
extern struct ifnethead ifnet;
struct ifnet;
typedef int (*ifm_change_cb_t)(struct ifnet *);
typedef void (*ifm_stat_cb_t)(struct ifnet *, struct ifmediareq *req);
struct ifmedia_entry {
 struct { struct ifmedia_entry *le_next; struct ifmedia_entry **le_prev; } ifm_list;
 int ifm_media;
 int ifm_data;
 void *ifm_aux;
};
struct ifmedia {
 int ifm_mask;
 int ifm_media;
 struct ifmedia_entry *ifm_cur;
 struct { struct ifmedia_entry *lh_first; } ifm_list;
 ifm_change_cb_t ifm_change;
 ifm_stat_cb_t ifm_status;
};
struct mbuf;
struct ifnet;
struct inpcb;
struct inpcb;
union lro_address {
 u_long raw[(((12 + 2 * sizeof(struct in6_addr))+((sizeof(u_long))-1))/(sizeof(u_long)))];
 struct {
  uint8_t lro_type;
  uint8_t lro_flags;
  uint16_t vlan_id;
  uint16_t s_port;
  uint16_t d_port;
  uint32_t vxlan_vni;
  union {
   struct in_addr v4;
   struct in6_addr v6;
  } s_addr;
  union {
   struct in_addr v4;
   struct in6_addr v6;
  } d_addr;
 };
};
struct lro_parser {
 union lro_address data;
 union {
  uint8_t *l3;
  struct ip *ip4;
  struct ip6_hdr *ip6;
 };
 union {
  uint8_t *l4;
  struct tcphdr *tcp;
  struct udphdr *udp;
 };
 uint16_t total_hdr_len;
};
struct lro_entry {
 struct { struct lro_entry *le_next; struct lro_entry **le_prev; } next;
 struct { struct lro_entry *le_next; struct lro_entry **le_prev; } hash_next;
 struct mbuf *m_head;
 struct mbuf *m_tail;
 struct mbuf *m_last_mbuf;
 struct lro_parser outer;
 struct lro_parser inner;
 uint32_t next_seq;
 uint32_t ack_seq;
 uint32_t tsval;
 uint32_t tsecr;
 uint16_t compressed;
 uint16_t uncompressed;
 uint16_t window;
 uint16_t flags : 12,
    timestamp : 1,
    needs_merge : 1,
    reserved : 2;
 struct bintime alloc_time;
};
struct lro_head { struct lro_entry *lh_first; };
struct lro_mbuf_sort {
 uint64_t seq;
 struct mbuf *mb;
};
struct lro_ctrl {
 struct ifnet *ifp;
 struct lro_mbuf_sort *lro_mbuf_data;
 struct bintime lro_last_queue_time;
 uint64_t lro_queued;
 uint64_t lro_flushed;
 uint64_t lro_bad_csum;
 unsigned lro_cnt;
 unsigned lro_mbuf_count;
 unsigned lro_mbuf_max;
 unsigned short lro_ackcnt_lim;
 unsigned short lro_cpu;
 unsigned lro_length_lim;
 u_long lro_hashsz;
 uint32_t lro_last_cpu;
 uint32_t lro_cnt_of_same_cpu;
 struct lro_head *lro_hash;
 struct lro_head lro_active;
 struct lro_head lro_free;
 uint8_t lro_cpu_is_set;
};
struct kexterr {
 int error;
 const char *msg;
 __uint64_t p1;
 __uint64_t p2;
 unsigned cat;
 unsigned src_line;
};
struct cv {
 const char *cv_description;
 int cv_waiters;
};
struct lock_object;
struct thread;
struct sigio {
 union {
  struct proc *siu_proc;
  struct pgrp *siu_pgrp;
 } sio_u;
 struct { struct sigio *sle_next; } sio_pgsigio;
 struct sigio **sio_myref;

 struct ucred *sio_ucred;
 pid_t sio_pgid;
};
struct sigiolst { struct sigio *slh_first; };
typedef struct sigaltstack stack_t;
struct sigaltstack {
 void *ss_sp;
 __size_t ss_size;
 int ss_flags;
};
union sigval {

 int sival_int;
 void *sival_ptr;

 int sigval_int;
 void *sigval_ptr;
};
typedef void __sighandler_t(int);
typedef struct __siginfo {
 int si_signo;
 int si_errno;






 int si_code;
 __pid_t si_pid;
 __uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 union {
  struct {
   int _trapno;
  } _fault;
  struct {
   int _timerid;
   int _overrun;
  } _timer;
  struct {
   int _mqd;
  } _mesgq;
  struct {
   long _band;
  } _poll;
  struct {
   int _syscall;



  } _capsicum;
  struct {
   long __spare1__;
   int __spare2__[7];
  } __spare__;
 } _reason;
} siginfo_t;
struct __siginfo;
typedef __sighandler_t *sig_t;
struct sigacts {
 sig_t ps_sigact[128];
 sigset_t ps_catchmask[128];
 sigset_t ps_sigonstack;
 sigset_t ps_sigintr;
 sigset_t ps_sigreset;
 sigset_t ps_signodefer;
 sigset_t ps_siginfo;
 sigset_t ps_sigignore;
 sigset_t ps_sigcatch;
 sigset_t ps_freebsd4;
 sigset_t ps_osigset;
 sigset_t ps_usertramp;
 int ps_flag;
 u_int ps_refcnt;
 struct mtx ps_mtx;
};
typedef struct ksiginfo {
 struct { struct ksiginfo *tqe_next; struct ksiginfo **tqe_prev; } ksi_link;
 siginfo_t ksi_info;
 int ksi_flags;
 struct sigqueue *ksi_sigq;
} ksiginfo_t;
typedef struct sigqueue {
 sigset_t sq_signals;
 sigset_t sq_kill;
 sigset_t sq_ptrace;
 struct { struct ksiginfo *tqh_first; struct ksiginfo **tqh_last; } sq_list;
 struct proc *sq_proc;
 int sq_flags;
} sigqueue_t;
struct pgrp;
struct proc;
struct sigio;
struct thread;
struct thread;
typedef uid_t au_id_t;
typedef pid_t au_asid_t;
typedef u_int64_t au_asflgs_t ;
struct au_tid_addr {
 u_int32_t at_port;
 u_int32_t at_type;
 u_int32_t at_addr[4];
};
typedef struct au_tid_addr au_tid_addr_t;
struct au_mask {
 unsigned int am_success;
 unsigned int am_failure;
};
typedef struct au_mask au_mask_t;
struct auditinfo_addr {
 au_id_t ai_auid;
 au_mask_t ai_mask;
 au_tid_addr_t ai_termid;
 au_asid_t ai_asid;
 au_asflgs_t ai_flags;
};
struct label;
struct loginclass;
struct prison;
struct uidinfo;
struct ucred {
 struct mtx cr_mtx;
 long cr_ref;
 u_int cr_users;
 u_int cr_flags;
 struct auditinfo_addr cr_audit;
 int cr_ngroups;
 uid_t cr_uid;
 uid_t cr_ruid;
 uid_t cr_svuid;
 gid_t cr_gid;
 gid_t cr_rgid;
 gid_t cr_svgid;
 struct uidinfo *cr_uidinfo;
 struct uidinfo *cr_ruidinfo;
 struct prison *cr_prison;
 struct loginclass *cr_loginclass;
 void *cr_pspare2[2];
 struct label *cr_label;
 gid_t *cr_groups;
 int cr_agroups;

 gid_t cr_smallgroups[16];
};
struct thread;
struct proc;
struct domainset;
struct domainset_ref {
 struct domainset * volatile dr_policy;
 unsigned int dr_iter;
};
struct fpacc87 {
 uint8_t fp_bytes[10];
};
struct xmmacc {
 uint8_t xmm_bytes[16];
};
struct envxmm {
 uint16_t en_cw;
 uint16_t en_sw;
 uint8_t en_tw;
 uint8_t en_zero;
 uint16_t en_opcode;
 uint64_t en_rip;
 uint64_t en_rdp;
 uint32_t en_mxcsr;
 uint32_t en_mxcsr_mask;
};
struct savefpu {
 struct envxmm sv_env;
 struct {
  struct fpacc87 fp_acc;
  uint8_t fp_pad[6];
 } sv_fp[8];
 struct xmmacc sv_xmm[16];
 uint8_t sv_pad[96];
} ;
struct pcb {
 register_t pcb_r15;
 register_t pcb_r14;
 register_t pcb_r13;
 register_t pcb_r12;
 register_t pcb_rbp;
 register_t pcb_rsp;
 register_t pcb_rbx;
 register_t pcb_rip;
 register_t pcb_fsbase;
 register_t pcb_gsbase;
 register_t pcb_kgsbase;
 register_t pcb_cr0;
 register_t pcb_cr2;
 register_t pcb_cr3;
 register_t pcb_cr4;
 register_t pcb_dr0;
 register_t pcb_dr1;
 register_t pcb_dr2;
 register_t pcb_dr3;
 register_t pcb_dr6;
 register_t pcb_dr7;

 struct region_descriptor pcb_gdt;
 struct region_descriptor pcb_idt;
 struct region_descriptor pcb_ldt;
 uint16_t pcb_tr;

 u_int pcb_flags;

 uint16_t pcb_initial_fpucw;


 caddr_t pcb_onfault;

 uint64_t pcb_saved_ucr3;


 struct amd64tss *pcb_tssp;


 register_t pcb_efer;
 register_t pcb_star;
 register_t pcb_lstar;
 register_t pcb_cstar;
 register_t pcb_sfmask;

 struct savefpu *pcb_save;

 register_t pcb_tlsbase;
 uint64_t pcb_pad[4];
};
struct trapframe;
struct proc_ldt {
 caddr_t ldt_base;
 int ldt_refcnt;
};
struct pmap_invl_gen {
 u_long gen;
 union {
  struct { struct pmap_invl_gen *le_next; struct pmap_invl_gen **le_prev; } link;
  struct {
   struct pmap_invl_gen *next;
   u_char saved_pri;
  };
 };
} ;
struct mdthread {
 int md_spinlock_count;
 register_t md_saved_flags;
 register_t md_spurflt_addr;
 struct pmap_invl_gen md_invl_gen;
 register_t md_efirt_tmp;
 int md_efirt_dis_pf;
 struct pcb md_pcb;
 vm_offset_t md_stack_base;
 void *md_usr_fpu_save;
};
struct mdproc {
 struct proc_ldt *md_ldt;
 struct system_segment_descriptor md_ldt_sd;
 u_int md_flags;
};
struct session {
 u_int s_count;
 struct proc *s_leader;
 struct vnode *s_ttyvp;
 struct cdev_priv *s_ttydp;
 struct tty *s_ttyp;
 pid_t s_sid;

 char s_login[((((33)+((sizeof(long))-1))/(sizeof(long)))*(sizeof(long)))];
 struct mtx s_mtx;
};
struct pgrp {
 struct { struct pgrp *le_next; struct pgrp **le_prev; } pg_hash;
 struct { struct proc *lh_first; } pg_members;
 struct session *pg_session;
 struct sigiolst pg_sigiolst;
 pid_t pg_id;
 struct mtx pg_mtx;
 int pg_flags;
 struct sx pg_killsx;

};
struct pargs {
 u_int ar_ref;
 u_int ar_length;
 u_char ar_args[1];
};
struct cpuset;
struct filemon;
struct kaioinfo;
struct kaudit_record;
struct kcov_info;
struct kdtrace_proc;
struct kdtrace_thread;
struct kmsan_td;
struct kq_timer_cb_data;
struct mqueue_notifier;
struct proc;
struct procdesc;
struct racct;
struct sleepqueue;
struct socket;
struct thread;
struct trapframe;
struct turnstile;
struct vm_map_entry;
struct syscall_args {
 u_int code;
 u_int original_code;
 struct sysent *callp;
 register_t args[8];
};
struct rusage_ext {
 uint64_t rux_runtime;
 uint64_t rux_uticks;
 uint64_t rux_sticks;
 uint64_t rux_iticks;
 uint64_t rux_uu;
 uint64_t rux_su;
 uint64_t rux_tu;
};
struct thread {
 struct mtx *volatile td_lock;
 struct proc *td_proc;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_plist;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_runq;
 union {
  struct { struct thread *tqe_next; struct thread **tqe_prev; } td_slpq;
  struct thread *td_zombie;
 };
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_lockq;
 struct { struct thread *le_next; struct thread **le_prev; } td_hash;
 struct cpuset *td_cpuset;
 struct domainset_ref td_domain;
 struct seltd *td_sel;
 struct sleepqueue *td_sleepqueue;
 struct turnstile *td_turnstile;
 void *td_pad1;
 struct umtx_q *td_umtxq;
 lwpid_t td_tid;
 sigqueue_t td_sigqueue;
 u_char td_lend_user_pri;
 u_char td_allocdomain;
 u_char td_base_ithread_pri;
 struct kmsan_td *td_kmsan;


 int td_flags;
 int td_ast;
 int td_inhibitors;
 int td_pflags;
 int td_pflags2;
 int td_dupfd;
 int td_sqqueue;
 const void *td_wchan;
 const char *td_wmesg;
 volatile u_char td_owepreempt;
 u_char td_tsqueue;
 u_char _td_pad0[2];
 int td_locks;
 int td_rw_rlocks;
 int td_sx_slocks;
 int td_lk_slocks;
 struct lock_object *td_wantedlock;
 struct turnstile *td_blocked;
 const char *td_lockname;
 struct { struct turnstile *lh_first; } td_contested;
 struct lock_list_entry *td_sleeplocks;
 int td_intr_nesting_level;
 int td_pinned;
 struct ucred *td_realucred;
 struct ucred *td_ucred;
 struct plimit *td_limit;
 int td_slptick;
 int td_blktick;
 int td_swvoltick;
 int td_swinvoltick;
 u_int td_cow;
 struct rusage td_ru;
 struct rusage_ext td_rux;
 uint64_t td_incruntime;
 uint64_t td_runtime;
 u_int td_pticks;
 u_int td_sticks;
 u_int td_iticks;
 u_int td_uticks;
 int td_intrval;
 sigset_t td_oldsigmask;
 volatile u_int td_generation;
 stack_t td_sigstk;
 int td_xsig;
 u_long td_profil_addr;
 u_int td_profil_ticks;
 char td_name[19 + 1];
 struct file *td_fpop;
 int td_dbgflags;
 siginfo_t td_si;
 int td_ng_outbound;
 struct osd td_osd;
 struct vm_map_entry *td_map_def_user;
 pid_t td_dbg_forked;
 u_int td_no_sleeping;
 struct vnode *td_vp_reserved;
 void *td_su;
 sbintime_t td_sleeptimo;
 int td_rtcgen;
 int td_errno;
 size_t td_vslock_sz;
 struct kcov_info *td_kcov_info;
 long td_ucredref;
 struct kexterr td_kexterr;


 sigset_t td_sigmask;
 u_char td_rqindex;
 u_char td_base_pri;
 u_char td_priority;
 u_char td_pri_class;
 u_char td_user_pri;
 u_char td_base_user_pri;
 uint32_t td_pax;
 uintptr_t td_rb_list;
 uintptr_t td_rbp_list;
 uintptr_t td_rb_inact;
 struct syscall_args td_sa;

 void *td_sigblock_ptr;
 uint32_t td_sigblock_val;

 void *td_exterr_ptr;





 struct pcb *td_pcb;
 enum td_states {
  TDS_INACTIVE = 0x0,
  TDS_INHIBITED,
  TDS_CAN_RUN,
  TDS_RUNQ,
  TDS_RUNNING
 } td_state;

 union {
  syscallarg_t tdu_retval[2];
  off_t tdu_off;
 } td_uretoff;
 u_int td_cowgen;

 struct callout td_slpcallout;
 struct trapframe *td_frame;
 vm_offset_t td_kstack;
 u_short td_kstack_pages;
 u_short td_kstack_domain;
 volatile u_int td_critnest;
 struct mdthread td_md;
 struct kaudit_record *td_ar;
 struct lpohead td_lprof[2];
 struct kdtrace_thread *td_dtrace;
 struct vnet *td_vnet;
 const char *td_vnet_lpush;
 struct trapframe *td_intr_frame;
 struct proc *td_rfppwait_p;
 struct vm_page **td_ma;
 int td_ma_cnt;

 void *td_emuldata;
 int td_lastcpu;
 int td_oncpu;
 void *td_lkpi_task;
 int td_pmcpend;
 void *td_remotereq;
 off_t td_ktr_io_lim;



};
struct proc {
 struct { struct proc *le_next; struct proc **le_prev; } p_list;
 struct { struct thread *tqh_first; struct thread **tqh_last; } p_threads;
 struct mtx p_slock;
 struct ucred *p_ucred;
 struct filedesc *p_fd;
 struct filedesc_to_leader *p_fdtol;
 struct pwddesc *p_pd;
 struct pstats *p_stats;
 struct plimit *p_limit;
 struct callout p_limco;
 struct sigacts *p_sigacts;

 int p_flag;
 int p_flag2;
 enum p_states {
  PRS_NEW = 0,
  PRS_NORMAL,
  PRS_ZOMBIE
 } p_state;
 pid_t p_pid;
 struct { struct proc *le_next; struct proc **le_prev; } p_hash;
 struct { struct proc *le_next; struct proc **le_prev; } p_pglist;
 struct proc *p_pptr;
 struct { struct proc *le_next; struct proc **le_prev; } p_sibling;
 struct { struct proc *lh_first; } p_children;
 struct proc *p_reaper;
 struct { struct proc *lh_first; } p_reaplist;

 struct { struct proc *le_next; struct proc **le_prev; } p_reapsibling;

 struct mtx p_mtx;
 struct mtx p_statmtx;
 struct mtx p_itimmtx;
 struct mtx p_profmtx;
 struct ksiginfo *p_ksi;
 sigqueue_t p_sigqueue;
 pid_t p_oppid;


 struct vmspace *p_vmspace;
 u_int p_swtick;
 u_int p_cowgen;
 struct itimerval p_realtimer;
 struct rusage p_ru;
 struct rusage_ext p_rux;
 struct rusage_ext p_crux;
 int p_profthreads;
 volatile int p_exitthreads;
 int p_traceflag;
 struct ktr_io_params *p_ktrioparms;
 struct vnode *p_textvp;
 struct vnode *p_textdvp;
 char *p_binname;
 u_int p_lock;
 struct sigiolst p_sigiolst;
 int p_sigparent;
 int p_sig;
 u_int p_ptevents;
 struct kaioinfo *p_aioinfo;
 struct thread *p_singlethread;
 int p_suspcount;
 struct thread *p_xthread;
 int p_boundary_count;
 int p_pendingcnt;
 struct itimers *p_itimers;
 struct procdesc *p_procdesc;
 u_int p_treeflag;
 int p_pendingexits;
 struct filemon *p_filemon;
 int p_pdeathsig;



 u_int p_magic;
 int p_osrel;

 uint32_t p_fctl0;
 char p_comm[19 + 1];
 struct sysentvec *p_sysent;
 struct pargs *p_args;
 rlim_t p_cpulimit;
 signed char p_nice;
 int p_fibnum;
 uint32_t p_pax;
 pid_t p_reapsubtree;


 vm_offset_t p_usrstack;
 vm_offset_t p_psstrings;
 vm_offset_t p_timekeep_base;
 vm_offset_t p_shared_page_base;
 vm_offset_t p_sigcode_base;
 vm_offset_t p_vdso_base;
 uint64_t p_elf_flags;
 const void *p_elf_brandinfo;

 sbintime_t p_umtx_min_timeout;


 u_int p_xexit;
 u_int p_xsig;
 struct pgrp *p_pgrp;
 struct knlist *p_klist;
 int p_numthreads;
 struct mdproc p_md;
 struct callout p_itcallout;
 u_short p_acflag;
 struct proc *p_peers;
 struct proc *p_leader;
 void *p_emuldata;
 struct label *p_label;
 struct { struct ktr_request *stqh_first; struct ktr_request **stqh_last; } p_ktr;
 struct { struct mqueue_notifier *lh_first; } p_mqnotifier;
 struct kdtrace_proc *p_dtrace;
 struct cv p_pwait;
 struct racct *p_racct;
 int p_throttled;






 struct { struct proc *le_next; struct proc **le_prev; } p_orphan;
 struct { struct proc *lh_first; } p_orphans;

 struct { struct kq_timer_cb_data *tqh_first; struct kq_timer_cb_data **tqh_last; } p_kqtim_stop;
 struct { struct proc *le_next; struct proc **le_prev; } p_jaillist;
 u_int p_asig;
 u_int p_tree_refcnt;
 u_int p_execblock;
};
typedef unsigned long bitstr_t;
union aopen_entry {
 void *data;
 union aopen_entry *next;
};
struct cxgbe_rate_tag {
 struct m_snd_tag com;
 struct adapter *adapter;
 u_int flags;
 struct mtx lock;
 int port_id;
 int etid;
 struct mbufq pending_tx, pending_fwack;
 int plen;
 struct sge_ofld_txq *eo_txq;
 uint32_t ctrl0;
 uint16_t iqid;
 int8_t schedcl;
 uint64_t max_rate;
 uint8_t tx_total;
 uint8_t tx_credits;
 uint8_t tx_nocompl;
 uint8_t ncompl;
};
union etid_entry {
 struct cxgbe_rate_tag *cst;
 union etid_entry *next;
};
struct tid_info {
 u_int nstids;
 u_int stid_base;

 u_int natids;

 u_int nftids;
 u_int ftid_base;
 u_int ftid_end;

 u_int nhpftids;
 u_int hpftid_base;
 u_int hpftid_end;

 u_int ntids;
 u_int tid_base;

 u_int netids;
 u_int etid_base;
 u_int etid_end;

 struct mtx stid_lock ;
 struct listen_ctx **stid_tab;
 bitstr_t *stid_bitmap;
 u_int stids_in_use;
 bool stid_tab_stopped;

 struct mtx atid_lock ;
 union aopen_entry *atid_tab;
 union aopen_entry *afree;
 u_int atids_in_use;
 bool atid_alloc_stopped;


 struct mtx ftid_lock ;
 struct cv ftid_cv;
 struct filter_entry *ftid_tab;
 struct filter_entry *hpftid_tab;
 u_int ftids_in_use;
 u_int hpftids_in_use;





 struct mtx hftid_lock ;
 struct cv hftid_cv;
 void **tid_tab;
 u_int tids_in_use;

 void *hftid_hash_4t;
 u_long hftid_4t_mask;
 void *hftid_hash_tid;
 u_long hftid_tid_mask;

 struct mtx etid_lock ;
 union etid_entry *etid_tab;
 union etid_entry *efree;
 u_int etids_in_use;
};
struct t4_range {
 u_int start;
 u_int size;
};
struct t4_virt_res {
 struct t4_range ddp;
 struct t4_range iscsi;
 struct t4_range stag;
 struct t4_range rq;
 struct t4_range pbl;
 struct t4_range qp;
 struct t4_range cq;
 struct t4_range srq;
 struct t4_range ocq;
 struct t4_range l2t;
 struct t4_range key;
};
struct adapter;
struct port_info;
struct tom_tunables {
 int cong_algorithm;
 int sndbuf;
 int ddp;
 int rx_coalesce;
 int tls;
 int tx_align;
 int tx_zcopy;
 int cop_managed_offloading;
 int autorcvbuf_inc;
 int update_hc_on_pmtu_change;
 int iso;
};
struct iw_tunables {
 int wc_en;
};
struct tls_tunables {
 int inline_keys;
 union {
  struct {

   int combo_wrs;
  };
  struct {

   int short_records;
   int partial_ghash;
  };
 };
};
struct offload_settings {
 int8_t offload;
 int8_t rx_coalesce;
 int8_t cong_algo;
 int8_t sched_class;
 int8_t tstamp;
 int8_t sack;
 int8_t nagle;
 int8_t ecn;
 int8_t ddp;
 int8_t tls;
 int16_t txq;
 int16_t rxq;
 int16_t mss;
};
struct offload_rule {
 char open_type;
 struct offload_settings settings;
 struct bpf_program bpf_prog;
};
struct t4_offload_policy {
 uint32_t nrules;
 struct offload_rule *rule;
};
struct rss_header {
 __u8 opcode;

 __u8 channel:2;
 __u8 filter_hit:1;
 __u8 filter_tid:1;
 __u8 hash_type:2;
 __u8 ipv6:1;
 __u8 send2fw:1;
 __be16 qid;
 __be32 hash_val;
};
enum fw_iq_iqtype {
 FW_IQ_IQTYPE_OTHER,
 FW_IQ_IQTYPE_NIC,
 FW_IQ_IQTYPE_OFLD,
};
struct fw_vi_stats_cmd {
 __be32 op_to_viid;
 __be32 retval_len16;
 union fw_vi_stats {
  struct fw_vi_stats_ctl {
   __be16 nstats_ix;
   __be16 r6;
   __be32 r7;
   __be64 stat0;
   __be64 stat1;
   __be64 stat2;
   __be64 stat3;
   __be64 stat4;
   __be64 stat5;
  } ctl;
  struct fw_vi_stats_pf {
   __be64 tx_bcast_bytes;
   __be64 tx_bcast_frames;
   __be64 tx_mcast_bytes;
   __be64 tx_mcast_frames;
   __be64 tx_ucast_bytes;
   __be64 tx_ucast_frames;
   __be64 tx_offload_bytes;
   __be64 tx_offload_frames;
   __be64 rx_pf_bytes;
   __be64 rx_pf_frames;
   __be64 rx_bcast_bytes;
   __be64 rx_bcast_frames;
   __be64 rx_mcast_bytes;
   __be64 rx_mcast_frames;
   __be64 rx_ucast_bytes;
   __be64 rx_ucast_frames;
   __be64 rx_err_frames;
  } pf;
  struct fw_vi_stats_vf {
   __be64 tx_bcast_bytes;
   __be64 tx_bcast_frames;
   __be64 tx_mcast_bytes;
   __be64 tx_mcast_frames;
   __be64 tx_ucast_bytes;
   __be64 tx_ucast_frames;
   __be64 tx_drop_frames;
   __be64 tx_offload_bytes;
   __be64 tx_offload_frames;
   __be64 rx_bcast_bytes;
   __be64 rx_bcast_frames;
   __be64 rx_mcast_bytes;
   __be64 rx_mcast_frames;
   __be64 rx_ucast_bytes;
   __be64 rx_ucast_frames;
   __be64 rx_err_frames;
  } vf;
 } u;
};
enum fw_sched_params_mode {
 FW_SCHED_PARAMS_MODE_CLASS = 0,
 FW_SCHED_PARAMS_MODE_FLOW = 1,
};
enum fw_sched_params_unit {
 FW_SCHED_PARAMS_UNIT_BITRATE = 0,
 FW_SCHED_PARAMS_UNIT_PKTRATE = 1,
};
enum fw_sched_params_rate {
 FW_SCHED_PARAMS_RATE_REL = 0,
 FW_SCHED_PARAMS_RATE_ABS = 1,
};
struct adapter;
enum {





 IQ_ESIZE = 64,


 FW_IQ_QSIZE = 256,
 RX_IQ_QSIZE = 1024,


 EQ_ESIZE = 64,


 CTRL_EQ_QSIZE = 1024,
 TX_EQ_QSIZE = 1024,


 SW_ZONE_SIZES = 4,



 CL_METADATA_SIZE = (1 << 6),

 SGE_MAX_WR_NDESC = SGE_MAX_WR_LEN / EQ_ESIZE,
 TX_SGL_SEGS = 39,
 TX_SGL_SEGS_TSO = 38,
 TX_SGL_SEGS_VM = 38,
 TX_SGL_SEGS_VM_TSO = 37,
 TX_SGL_SEGS_EO_TSO = 30,
 TX_SGL_SEGS_VXLAN_TSO = 37,
 TX_WR_FLITS = SGE_MAX_WR_LEN / 8
};
enum {

 FULL_INIT_DONE = (1 << 0),
 FW_OK = (1 << 1),
 CHK_MBOX_ACCESS = (1 << 2),
 MASTER_PF = (1 << 3),
 BUF_PACKING_OK = (1 << 6),
 IS_VF = (1 << 7),
 KERN_TLS_ON = (1 << 8),
 CXGBE_BUSY = (1 << 9),


 ADAP_STOPPED = (1 << 0),
 ADAP_FATAL_ERR = (1 << 1),
 HW_OFF_LIMITS = (1 << 2),
 ADAP_CIM_ERR = (1 << 3),


 HAS_TRACEQ = (1 << 3),
 FIXED_IFMEDIA = (1 << 4),


 VI_DETACHING = (1 << 0),
 VI_INIT_DONE = (1 << 1),

 TX_USES_VM_WR = (1 << 3),
 VI_SKIP_STATS = (1 << 4),


 DF_DUMP_MBOX = (1 << 0),
 DF_LOAD_FW_ANYTIME = (1 << 1),
 DF_DISABLE_TCB_CACHE = (1 << 2),
 DF_DISABLE_CFG_RETRY = (1 << 3),
 DF_VERBOSE_SLOWINTR = (1 << 4),
};
struct vi_info {
 device_t dev;
 struct port_info *pi;
 struct adapter *adapter;

 if_t ifp;
 struct pfil_head *pfil;

 unsigned long flags;
 int if_flags;

 uint16_t *rss, *nm_rss;
 uint16_t viid;
 uint16_t smt_idx;
 uint16_t vin;
 uint8_t vfvld;
 int16_t xact_addr_filt;
 uint16_t rss_size;
 uint16_t rss_base;
 int hashen;

 int nintr;
 int first_intr;


 int ntxq;
 int first_txq;
 int rsrv_noflowq;
 int nrxq;
 int first_rxq;
 int nofldtxq;
 int first_ofld_txq;
 int nofldrxq;
 int first_ofld_rxq;
 int nnmtxq;
 int first_nm_txq;
 int nnmrxq;
 int first_nm_rxq;
 int tmr_idx;
 int ofld_tmr_idx;
 int pktc_idx;
 int ofld_pktc_idx;
 int qsize_rxq;
 int qsize_txq;

 struct timeval last_refreshed;
 struct fw_vi_stats_vf stats;
 struct mtx tick_mtx;
 struct callout tick;

 struct sysctl_ctx_list ctx;
 struct sysctl_oid *rxq_oid;
 struct sysctl_oid *txq_oid;
 struct sysctl_oid *nm_rxq_oid;
 struct sysctl_oid *nm_txq_oid;
 struct sysctl_oid *ofld_rxq_oid;
 struct sysctl_oid *ofld_txq_oid;

 uint8_t hw_addr[6];
 u_int txq_rr;
 u_int rxq_rr;
};
struct tx_ch_rl_params {
 enum fw_sched_params_rate ratemode;
 uint32_t maxrate;
};
enum clrl_state {
 CS_UNINITIALIZED = 0,
 CS_PARAMS_SET,
 CS_HW_UPDATE_REQUESTED,
 CS_HW_UPDATE_IN_PROGRESS,
 CS_HW_CONFIGURED
};
struct tx_cl_rl_params {
 enum clrl_state state;
 int refcount;
 uint8_t flags;
 enum fw_sched_params_rate ratemode;
 enum fw_sched_params_unit rateunit;
 enum fw_sched_params_mode mode;
 uint32_t maxrate;
 uint16_t pktsize;
 uint16_t burstsize;
};
struct tx_sched_params {

 struct tx_ch_rl_params ch_rl;





 int pktsize;
 int burstsize;
 struct tx_cl_rl_params cl_rl[1];
};
struct port_info {
 device_t dev;
 struct adapter *adapter;

 struct vi_info *vi;
 int nvi;
 int up_vis;
 int uld_vis;
 bool vxlan_tcam_entry;

 struct tx_sched_params *sched_params;

 struct mtx pi_lock;
 char lockname[16];
 unsigned long flags;

 uint8_t hw_port;
 int8_t mdio_addr;
 uint8_t port_type;
 uint8_t mod_type;
 uint8_t port_id;
 uint8_t tx_chan;
 uint8_t rx_chan;
 uint8_t mps_bg_map;
 uint8_t rx_e_chan_map;

 struct link_config link_cfg;
 struct ifmedia media;

 struct port_stats stats;
 u_int tnl_cong_drops;
 u_int tx_parse_error;
 int fcs_reg;
 uint64_t fcs_base;

 struct sysctl_ctx_list ctx;
};
struct fl_sdesc {
 caddr_t cl;
 uint16_t nmbuf;
 int16_t moff;
 uint8_t zidx;
};
struct tx_desc {
 __be64 flit[8];
};
struct tx_sdesc {
 struct mbuf *m;
 uint8_t desc_used;
};
struct iq_desc {
 struct rss_header rss;
 uint8_t cpl[(IQ_ESIZE - sizeof(struct rsp_ctrl) - sizeof(struct rss_header))];
 struct rsp_ctrl rsp;
};
enum {

 IQ_OTHER = FW_IQ_IQTYPE_OTHER,
 IQ_ETH = FW_IQ_IQTYPE_NIC,
 IQ_OFLD = FW_IQ_IQTYPE_OFLD,


 IQ_SW_ALLOCATED = (1 << 0),
 IQ_HAS_FL = (1 << 1),
 IQ_RX_TIMESTAMP = (1 << 2),
 IQ_LRO_ENABLED = (1 << 3),
 IQ_ADJ_CREDIT = (1 << 4),
 IQ_HW_ALLOCATED = (1 << 5),


 IQS_DISABLED = 0,
 IQS_BUSY = 1,
 IQS_IDLE = 2,


 NM_OFF = 0,
 NM_ON = 1,
 NM_BUSY = 2,
};
struct sge_iq;
struct rss_header;
struct sge_iq {
 uint16_t flags;
 uint8_t qtype;
 volatile int state;
 struct adapter *adapter;
 struct iq_desc *desc;
 int8_t intr_pktc_idx;
 uint8_t gen;
 uint8_t intr_params;
 int8_t cong_drop;
 uint16_t qsize;
 uint16_t sidx;
 uint16_t cidx;
 uint16_t cntxt_id;
 uint16_t abs_id;
 int16_t intr_idx;

 struct { struct sge_iq *stqe_next; } link;

 bus_dma_tag_t desc_tag;
 bus_dmamap_t desc_map;
 bus_addr_t ba;
};
struct sge_eq {
 unsigned int flags;
 unsigned int cntxt_id;
 unsigned int abs_id;
 uint8_t type;
 uint8_t doorbells;
 uint8_t port_id;
 uint8_t tx_chan;
 uint8_t hw_port;
 struct mtx eq_lock;

 struct tx_desc *desc;
 volatile uint32_t *udb;
 u_int udb_qid;
 uint16_t sidx;
 uint16_t cidx;
 uint16_t pidx;
 uint16_t equeqidx;
 uint16_t dbidx;
 uint16_t iqid;
 volatile u_int equiq;
 struct sge_iq *iq;

 bus_dma_tag_t desc_tag;
 bus_dmamap_t desc_map;
 bus_addr_t ba;
 char lockname[16];
};
struct rx_buf_info {
 uma_zone_t zone;
 uint16_t size1;

 uint16_t size2;

 int8_t hwidx1;
 int8_t hwidx2;
 uint8_t type;
};
enum {
 NUM_MEMWIN = 3,

 MEMWIN0_APERTURE = 2048,
 MEMWIN0_BASE = 0x1b800,

 MEMWIN1_APERTURE = 32768,
 MEMWIN1_BASE = 0x28000,

 MEMWIN2_APERTURE_T4 = 65536,
 MEMWIN2_BASE_T4 = 0x30000,

 MEMWIN2_APERTURE_T5 = 128 * 1024,
 MEMWIN2_BASE_T5 = 0x60000,
};
struct memwin {
 struct rwlock mw_lock ;
 uint32_t mw_base;
 uint32_t mw_aperture;
 uint32_t mw_curpos;
};
struct sge_fl {
 struct mtx fl_lock;
 __be64 *desc;
 struct fl_sdesc *sdesc;
 uint16_t zidx;
 uint16_t safe_zidx;
 uint16_t lowat;
 int flags;
 uint16_t buf_boundary;


 uint16_t dbidx;
 uint16_t sidx;
 volatile uint16_t hw_cidx;


 uint32_t cidx;
 uint32_t pidx;

 uint32_t dbval;
 u_int rx_offset;
 volatile uint32_t *udb;

 uint64_t cl_allocated;
 uint64_t cl_recycled;
 uint64_t cl_fast_recycled;


 struct mbuf *m0;
 struct mbuf **pnext;
 u_int remaining;

 uint16_t qsize;
 uint16_t cntxt_id;
 struct { struct sge_fl *tqe_next; struct sge_fl **tqe_prev; } link;
 bus_dma_tag_t desc_tag;
 bus_dmamap_t desc_map;
 char lockname[16];
 bus_addr_t ba;
};
struct mp_ring;
struct txpkts {
 uint8_t wr_type;
 uint8_t npkt;
 uint8_t len16;
 uint8_t score;
 uint8_t max_npkt;
 uint16_t plen;


 __u8 ethmacdst[6];
 __u8 ethmacsrc[6];
 __be16 ethtype;
 __be16 vlantci;

 struct mbuf *mb[15];
};
struct sge_txq {
 struct sge_eq eq;

 if_t ifp;
 struct mp_ring *r;
 struct tx_sdesc *sdesc;
 struct sglist *gl;
 __be32 cpl_ctrl0;
 int tc_idx;
 uint64_t last_tx;
 struct txpkts txp;

 struct task tx_reclaim_task;


 uint64_t txcsum;
 uint64_t tso_wrs;
 uint64_t vlan_insertion;
 uint64_t imm_wrs;
 uint64_t sgl_wrs;
 uint64_t txpkt_wrs;
 uint64_t txpkts0_wrs;
 uint64_t txpkts1_wrs;
 uint64_t txpkts0_pkts;
 uint64_t txpkts1_pkts;
 uint64_t txpkts_flush;
 uint64_t raw_wrs;
 uint64_t vxlan_tso_wrs;
 uint64_t vxlan_txcsum;

 uint64_t kern_tls_records;
 uint64_t kern_tls_short;
 uint64_t kern_tls_partial;
 uint64_t kern_tls_full;
 uint64_t kern_tls_octets;
 uint64_t kern_tls_waste;
 uint64_t kern_tls_header;
 uint64_t kern_tls_fin_short;
 uint64_t kern_tls_cbc;
 uint64_t kern_tls_gcm;
 union {
  struct {

   uint64_t kern_tls_options;
   uint64_t kern_tls_fin;
  };
  struct {

   uint64_t kern_tls_ghash_received;
   uint64_t kern_tls_ghash_requested;
   uint64_t kern_tls_lso;
   uint64_t kern_tls_partial_ghash;
   uint64_t kern_tls_splitmode;
   uint64_t kern_tls_trailer;
  };
 };




 uint8_t ss[SGE_MAX_WR_LEN] ;
} ;
struct sge_rxq {
 struct sge_iq iq;
 struct sge_fl fl;

 if_t ifp;
 struct lro_ctrl lro;



 uint64_t rxcsum;
 uint64_t vlan_extraction;
 uint64_t vxlan_rxcsum;



} ;
struct sge_ofld_rxq {
 struct sge_iq iq;
 struct sge_fl fl;
 counter_u64_t rx_iscsi_ddp_setup_ok;
 counter_u64_t rx_iscsi_ddp_setup_error;
 uint64_t rx_iscsi_ddp_pdus;
 uint64_t rx_iscsi_ddp_octets;
 uint64_t rx_iscsi_fl_pdus;
 uint64_t rx_iscsi_fl_octets;
 uint64_t rx_iscsi_padding_errors;
 uint64_t rx_iscsi_header_digest_errors;
 uint64_t rx_iscsi_data_digest_errors;
 uint64_t rx_aio_ddp_jobs;
 uint64_t rx_aio_ddp_octets;
 u_long rx_toe_tls_records;
 u_long rx_toe_tls_octets;
 u_long rx_toe_ddp_octets;
 counter_u64_t ddp_buffer_alloc;
 counter_u64_t ddp_buffer_reuse;
 counter_u64_t ddp_buffer_free;
} ;
struct wrqe {
 struct { struct wrqe *stqe_next; } link;
 struct sge_wrq *wrq;
 int wr_len;
 char wr[1] ;
};
struct wrq_cookie {
 struct { struct wrq_cookie *tqe_next; struct wrq_cookie **tqe_prev; } link;
 int ndesc;
 int pidx;
};
struct sge_wrq {
 struct sge_eq eq;

 struct adapter *adapter;
 struct task wrq_tx_task;


 struct wrq_incomplete_wrs { struct wrq_cookie *tqh_first; struct wrq_cookie **tqh_last; } incomplete_wrs;


 struct { struct wrqe *stqh_first; struct wrqe **stqh_last; } wr_list;
 u_int nwr_pending;
 u_int ndesc_needed;



 uint64_t tx_wrs_direct;
 uint64_t tx_wrs_ss;
 uint64_t tx_wrs_copied;







 uint16_t ss_pidx;
 uint16_t ss_len;
 uint8_t ss[SGE_MAX_WR_LEN];

} ;
struct sge_ofld_txq {
 struct sge_wrq wrq;
 counter_u64_t tx_iscsi_pdus;
 counter_u64_t tx_iscsi_octets;
 counter_u64_t tx_iscsi_iso_wrs;
 counter_u64_t tx_aio_jobs;
 counter_u64_t tx_aio_octets;
 counter_u64_t tx_toe_tls_records;
 counter_u64_t tx_toe_tls_octets;
} ;
struct sge_nm_rxq {

 volatile int nm_state ;
 u_int nid;
 struct vi_info *vi;

 struct iq_desc *iq_desc;
 uint16_t iq_abs_id;
 uint16_t iq_cntxt_id;
 uint16_t iq_cidx;
 uint16_t iq_sidx;
 uint8_t iq_gen;
 uint32_t fl_sidx;


 __be64 *fl_desc ;
 uint16_t fl_cntxt_id;
 uint32_t fl_pidx;
 uint32_t fl_sidx2;
 uint32_t fl_db_val;
 u_int fl_db_saved;
 u_int fl_db_threshold;
 u_int fl_hwidx:4;





 uint32_t fl_cidx ;

 bus_dma_tag_t iq_desc_tag;
 bus_dmamap_t iq_desc_map;
 bus_addr_t iq_ba;
 int intr_idx;

 bus_dma_tag_t fl_desc_tag;
 bus_dmamap_t fl_desc_map;
 bus_addr_t fl_ba;
};
struct sge_nm_txq {
 struct tx_desc *desc;
 uint16_t cidx;
 uint16_t pidx;
 uint16_t sidx;
 uint16_t equiqidx;
 uint16_t equeqidx;
 uint16_t dbidx;
 uint8_t doorbells;
 volatile uint32_t *udb;
 u_int udb_qid;
 u_int cntxt_id;
 __be32 cpl_ctrl0;
 __be32 op_pkd;
 u_int nid;



 bus_dma_tag_t desc_tag;
 bus_dmamap_t desc_map;
 bus_addr_t ba;
 int iqidx;
} ;
struct sge {
 int nctrlq;
 int nrxq;
 int ntxq;
 int nofldrxq;
 int nofldtxq;
 int nnmrxq;
 int nnmtxq;
 int niq;
 int neq;

 struct sge_iq fwq;
 struct sge_wrq *ctrlq;
 struct sge_txq *txq;
 struct sge_rxq *rxq;
 struct sge_ofld_txq *ofld_txq;
 struct sge_ofld_rxq *ofld_rxq;
 struct sge_nm_txq *nm_txq;
 struct sge_nm_rxq *nm_rxq;

 uint16_t iq_start;
 uint16_t iq_base;
 int eq_start;
 int eq_base;
 int iqmap_sz;
 int eqmap_sz;
 struct sge_iq **iqmap;
 struct sge_eq **eqmap;

 int8_t safe_zidx;
 struct rx_buf_info rx_buf_info[SW_ZONE_SIZES];
};
struct devnames {
 const char *nexus_name;
 const char *ifnet_name;
 const char *vi_ifnet_name;
 const char *pf03_drv_name;
 const char *vf_nexus_name;
 const char *vf_ifnet_name;
};
struct clip_entry;
struct clock_sync {
 uint64_t hw_cur;
 uint64_t hw_prev;
 sbintime_t sbt_cur;
 sbintime_t sbt_prev;
 seqc_t gen;
};
struct adapter {
 struct { struct adapter *sle_next; } link;
 device_t dev;
 struct cdev *cdev;
 const struct devnames *names;


 int regs_rid;
 struct resource *regs_res;
 int msix_rid;
 struct resource *msix_res;
 bus_size_t mmio_len;
 int udbs_rid;
 struct resource *udbs_res;
 volatile uint8_t *udbs_base;

 unsigned int pf;
 unsigned int mbox;
 unsigned int vpd_busy;
 unsigned int vpd_flag;


 int intr_type;
 int intr_count;
 struct irq {
  struct resource *res;
  int rid;
  void *tag;
  struct sge_rxq *rxq;
  struct sge_nm_rxq *nm_rxq;
 }  *irq;
 int sge_gts_reg;
 int sge_kdoorbell_reg;

 bus_dma_tag_t dmat;

 struct sge sge;
 int lro_timeout;
 int sc_do_rxcopy;

 int vxlan_port;
 u_int vxlan_refcount;
 int rawf_base;
 int nrawf;
 u_int vlan_id;

 struct taskqueue *tq[MAX_NPORTS];
 struct port_info *port[MAX_NPORTS];
 uint8_t chan_map[MAX_NCHAN];
 uint8_t port_map[MAX_NPORTS];

 struct { struct clip_entry *lh_first; } *clip_table;
 struct { struct clip_entry *tqh_first; struct clip_entry **tqh_last; } clip_pending;
 u_long clip_mask;
 int clip_gen;
 struct timeout_task clip_task;

 void *tom_softc;
 struct tom_tunables tt;
 struct t4_offload_policy *policy;
 struct rwlock policy_lock;

 void *iwarp_softc;
 struct iw_tunables iwt;
 void *iscsi_ulp_softc;
 struct l2t_data *l2t;
 struct smt_data *smt;
 struct tid_info tids;
 vmem_t *key_map;
 struct tls_tunables tlst;

 vmem_t *pbl_arena;
 vmem_t *stag_arena;

 uint8_t doorbells;
 int offload_map;
 int bt_map;
 int active_ulds;
 int flags;
 int debug_flags;
 int error_flags;

 char ifp_lockname[16];
 struct mtx ifp_lock;
 if_t ifp;
 struct ifmedia media;
 int traceq;
 int tracer_valid;
 int tracer_enabled;

 char fw_version[16];
 char tp_version[16];
 char er_version[16];
 char bs_version[16];
 char cfg_file[32];
 u_int cfcsum;
 struct adapter_params params;
 const struct chip_params *chip_params;
 struct t4_virt_res vres;

 uint16_t nbmcaps;
 uint16_t linkcaps;
 uint16_t switchcaps;
 uint16_t nvmecaps;
 uint16_t niccaps;
 uint16_t toecaps;
 uint16_t rdmacaps;
 uint16_t cryptocaps;
 uint16_t iscsicaps;
 uint16_t fcoecaps;

 struct sysctl_ctx_list ctx;
 struct sysctl_oid *ctrlq_oid;
 struct sysctl_oid *fwq_oid;

 struct mtx sc_lock;
 char lockname[16];


 struct mtx sfl_lock;
 struct { struct sge_fl *tqh_first; struct sge_fl **tqh_last; } sfl;
 struct callout sfl_callout;
 struct callout cal_callout;
 struct clock_sync cal_info[3];
 int cal_current;
 int cal_count;
 uint32_t cal_gen;
 struct mtx reg_lock;

 struct memwin memwin[NUM_MEMWIN];

 struct mtx tc_lock;
 struct task tc_task;

 struct task fatal_error_task;
 struct task reset_task;
 const void *reset_thread;
 int num_resets;
 int incarnation;

 const char *last_op;
 const void *last_op_thr;
 int last_op_flags;

 int swintr;
 int sensor_resets;

 struct callout ktls_tick;
};
struct l2t_entry {
 uint16_t state;
 uint16_t idx;
 uint32_t addr[4];
 uint32_t iqid;
 struct sge_wrq *wrq;
 if_t ifp;
 uint16_t vlan;
 struct l2t_entry *first;
 struct l2t_entry *next;
 struct { struct wrqe *stqh_first; struct wrqe **stqh_last; } wr_list;
 struct mtx lock;
 volatile int refcnt;
 uint16_t hash;
 uint8_t ipv6;
 uint8_t hw_port;
 uint8_t dmac[6];
};
struct l2t_data {
 struct rwlock lock;
 u_int l2t_size;
 bool l2t_stopped;
 volatile int nfree;
 struct l2t_entry *rover;
 struct l2t_entry l2tab[1];
};
struct mp_ring;
typedef u_int (*ring_drain_t)(struct mp_ring *, u_int, u_int, bool *);
typedef u_int (*ring_can_drain_t)(struct mp_ring *);
struct mp_ring {
 volatile uint64_t state ;
 struct malloc_type * mt;

 int size ;
 void * cookie;
 ring_drain_t drain;
 ring_can_drain_t can_drain;
 struct mtx * cons_lock;
 counter_u64_t dropped;
 counter_u64_t consumer[4];
 counter_u64_t not_consumer;
 counter_u64_t abdications;
 counter_u64_t consumed;
 counter_u64_t cons_idle;
 counter_u64_t cons_idle2;
 counter_u64_t stalls;

 void * volatile items[1] ;
};
static int fl_pktshift = 0;
static int spg_len = -1;
static int cong_drop = 0;
static inline void init_iq(struct sge_iq *, struct adapter *, int, int, int,
    int, int, int);
static int alloc_iq_fl(struct vi_info *, struct sge_iq *, struct sge_fl *,
    struct sysctl_ctx_list *, struct sysctl_oid *);
static int alloc_iq_fl_hwq(struct vi_info *, struct sge_iq *, struct sge_fl *);
static int alloc_fwq(struct adapter *);
static inline void
init_iq(struct sge_iq *iq, struct adapter *sc, int tmr_idx, int pktc_idx,
    int qsize, int intr_idx, int cong, int qtype)
;
static int
alloc_iq_fl(struct vi_info *vi, struct sge_iq *iq, struct sge_fl *fl,
    struct sysctl_ctx_list *ctx, struct sysctl_oid *oid)
;
static int
alloc_iq_fl_hwq(struct vi_info *vi, struct sge_iq *iq, struct sge_fl *fl)
;
/*@ requires \true; ensures (\result == 0 ==> fwq->flags & (IQ_SW_ALLOCATED | IQ_HW_ALLOCATED)) && (\result != 0 ==> !(fwq->flags & IQ_HW_ALLOCATED)); */

static int
alloc_fwq(struct adapter *sc)
{
 int rc, intr_idx;
 struct sge_iq *fwq = &sc->sge.fwq;
 struct vi_info *vi = &sc->port[0]->vi[0];

 if (!(fwq->flags & IQ_SW_ALLOCATED)) {
  do { } while (0);

  if (sc->flags & IS_VF)
   intr_idx = 0;
  else
   intr_idx = sc->intr_count > 1 ? 1 : 0;
  init_iq(fwq, sc, 0, 0, FW_IQ_QSIZE, intr_idx, -1, IQ_OTHER);
  rc = alloc_iq_fl(vi, fwq, ((void *)0), &sc->ctx, sc->fwq_oid);
  if (rc != 0) {
   log(3, "%s: " "failed to allocate fwq: %d\n", device_get_nameunit((sc)->dev), rc);
   return (rc);
  }
  do { } while (0);
 }

 if (!(fwq->flags & IQ_HW_ALLOCATED)) {
  do { } while (0);

  rc = alloc_iq_fl_hwq(vi, fwq, ((void *)0));
  if (rc != 0) {
   log(3, "%s: " "failed to create hw fwq: %d\n", device_get_nameunit((sc)->dev), rc);
   return (rc);
  }
  do { } while (0);
 }

 return (0);
}
