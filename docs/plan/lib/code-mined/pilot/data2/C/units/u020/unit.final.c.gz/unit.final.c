typedef unsigned short __u16;
__extension__ typedef unsigned long long __u64;
typedef __u16 __be16;
typedef __u64 __be64;
typedef struct xfs_bmdr_block {
 __be16 bb_level;
 __be16 bb_numrecs;
} xfs_bmdr_block_t;
typedef struct xfs_bmbt_rec {
 __be64 l0, l1;
} xfs_bmbt_rec_t;
typedef xfs_bmbt_rec_t xfs_bmdr_rec_t;
typedef struct xfs_bmbt_key {
 __be64 br_startoff;
} xfs_bmbt_key_t, xfs_bmdr_key_t;
typedef __be64 xfs_bmbt_ptr_t, xfs_bmdr_ptr_t;
extern int xfs_bmdr_maxrecs(int blocklen, int leaf);
/*@ requires blocklen >= sizeof(xfs_bmdr_block_t); ensures leaf != 0 ==> \result == (blocklen - sizeof(xfs_bmdr_block_t)) / sizeof(xfs_bmdr_rec_t); ensures leaf == 0 ==> \result == (blocklen - sizeof(xfs_bmdr_block_t)) / (sizeof(xfs_bmdr_key_t) + sizeof(xfs_bmdr_ptr_t)); */

int
xfs_bmdr_maxrecs(
 int blocklen,
 int leaf)
{
 blocklen -= sizeof(xfs_bmdr_block_t);

 if (leaf)
  return blocklen / sizeof(xfs_bmdr_rec_t);
 return blocklen / (sizeof(xfs_bmdr_key_t) + sizeof(xfs_bmdr_ptr_t));
}
