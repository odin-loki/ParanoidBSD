typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u8 u8;
typedef __u16 u16;
typedef __u32 u32;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
static inline     bool
arch_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
struct cpuinfo_x86;
struct cpuinfo_topology {

 u32 apicid;

 u32 initial_apicid;


 u32 pkg_id;


 u32 die_id;


 u32 cu_id;


 u32 core_id;


 u32 logical_pkg_id;
 u32 logical_die_id;
 u32 logical_core_id;


 u32 amd_node_id;


 u32 llc_id;
 u32 l2c_id;


 union {
  u32 cpu_type;
  struct {

   u32 intel_native_model_id :24;

   u32 intel_type :8;
  };
  struct {

   u32 amd_num_processors :16,
    amd_power_eff_ranking :8,
    amd_native_model_id :4,
    amd_type :4;
  };
 };
};
struct cpuinfo_x86 {
 union {





  struct {
   __u8 x86_model;

   __u8 x86;

   __u8 x86_vendor;
   __u8 x86_reserved;
  };

  __u32 x86_vfm;
 };
 __u8 x86_stepping;


 int x86_tlbsize;


 __u32 vmx_capability[5];

 __u8 x86_virt_bits;
 __u8 x86_phys_bits;

 __u32 extended_cpuid_level;

 int cpuid_level;





 union {
  __u32 x86_capability[22 + 2];
  unsigned long x86_capability_alignment;
 };
 char x86_vendor_id[16];
 char x86_model_id[64];
 struct cpuinfo_topology topo;

 unsigned int x86_cache_size;
 int x86_cache_alignment;

 int x86_cache_max_rmid;
 int x86_cache_occ_scale;
 int x86_cache_mbm_width_offset;
 int x86_power;
 unsigned long loops_per_jiffy;

 u64 ppin;
 u16 x86_clflush_size;

 u16 booted_cores;

 u16 cpu_index;

 bool smt_active;
 u32 microcode;

 u8 x86_cache_bits;
 unsigned initialized : 1;
} ;
extern struct cpuinfo_x86 boot_cpu_data;
struct cpuinfo_x86;
struct cpuinfo_x86;
void  hugetlb_add_hstate(unsigned order);
/*@ requires true; ensures \result == 0; */

static  int gigantic_pages_init(void)
{

 if ((__builtin_constant_p(( 1*32+26)) && (( ((( 1*32+26)) >> 5) == 0 ? 0x07008161U : ((( 1*32+26)) >> 5) == 1 ? 0x20000000U : ((( 1*32+26)) >> 5) == 3 ? 0x02300000U : 0 ) & (1U << ((( 1*32+26)) & 31))) ? 1 : arch_test_bit(( 1*32+26), (unsigned long *)((&boot_cpu_data)->x86_capability))))
  hugetlb_add_hstate(30 - 12);
 return 0;
}
