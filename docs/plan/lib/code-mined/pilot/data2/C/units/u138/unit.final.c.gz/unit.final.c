typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
void *realloc(void *, size_t)  ;
typedef enum {cGLOBAL, cLOCAL} class;
typedef enum {tREAL, tINTEGER} type;
typedef char * name;
struct symbol { class c; type t; name id; };
typedef struct symbol symbol;
struct namelist { symbol *s; struct namelist *next; };
typedef struct namelist namelist;
typedef union YYSTYPE
{
    class cval;
    type tval;
    namelist * nlist;
    name id;
} YYSTYPE;
typedef int YYINT;
typedef struct {
    unsigned stacksize;
    YYINT *s_base;
    YYINT *s_mark;
    YYINT *s_last;
    YYSTYPE *l_base;
    YYSTYPE *l_mark;




} YYSTACKDATA;
/*@ requires data->stacksize <= 10000; ensures \result == 0 || \result == (-2); */

static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    YYINT *newss;
    YYSTYPE *newvs;




    if ((newsize = data->stacksize) == 0)
        newsize = 200;
    else if (newsize >= 10000)
        return (-2);
    else if ((newsize *= 2) > 10000)
        newsize = 10000;

    i = (int) (data->s_mark - data->s_base);
    newss = (YYINT *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == ((void *)0))
        return (-2);

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == ((void *)0))
        return (-2);

    data->l_base = newvs;
    data->l_mark = newvs + i;
    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;





    return 0;
}
