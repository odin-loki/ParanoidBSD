enum {
 false = 0,
 true = 1
};
typedef int (*get_char_func)(void);
extern get_char_func kdb_poll_funcs[];
static char remcom_in_buffer[1024];
static int gdbstub_use_prev_in_buf;
static int gdbstub_prev_in_buf_pos;
/*@ requires true; ensures \exists int c; c > 0 && c <= 255 && \result == c; */

static int gdbstub_read_wait(void)
{
 int ret = -1;
 int i;

 if (__builtin_expect(!!(gdbstub_use_prev_in_buf), 0)) {
  if (gdbstub_prev_in_buf_pos < gdbstub_use_prev_in_buf)
   return remcom_in_buffer[gdbstub_prev_in_buf_pos++];
  else
   gdbstub_use_prev_in_buf = 0;
 }


 while (ret < 0)
  for (i = 0; kdb_poll_funcs[i] != ((void *)0); i++) {
   ret = kdb_poll_funcs[i]();
   if (ret > 0)
    break;
  }
 return ret;
}
