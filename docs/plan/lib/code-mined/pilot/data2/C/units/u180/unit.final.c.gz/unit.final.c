/*@ requires \valid_read(value); ensures *value == \old(*value) + 1; */

static inline void atomic_inc(long *value)
{
 (void)__atomic_add_fetch(value, 1, 0);
}
