/*@ requires \valid_read(list + (*head)) || *head == 0xffff; ensures \result == \old(*head) && (\result != 0xffff ==> (*head == \old(list[\result]) && list[\result] == 0xffff)); */

static unsigned short get_id_from_list(unsigned *head, unsigned short *list)
{
 unsigned int id = *head;

 if (id != 0xffff) {
  *head = list[id];
  list[id] = 0xffff;
 }
 return id;
}
