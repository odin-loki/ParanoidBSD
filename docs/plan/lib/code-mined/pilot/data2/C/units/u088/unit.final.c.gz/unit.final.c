typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
struct kvm_cpuid_entry2 {
 __u32 function;
 __u32 index;
 __u32 flags;
 __u32 eax;
 __u32 ebx;
 __u32 ecx;
 __u32 edx;
 __u32 padding[3];
};
static int cpuid_func_emulated(struct kvm_cpuid_entry2 *entry, u32 func,
          bool include_partially_emulated);
struct kvm_cpuid_array {
 struct kvm_cpuid_entry2 *entries;
 int maxnent;
 int nent;
};
static int cpuid_func_emulated(struct kvm_cpuid_entry2 *entry, u32 func,
          bool include_partially_emulated)
;
/*@ requires \valid_read(array) && array->nent <= array->maxnent; ensures (\old(array->nent) < array->maxnent ==> \result == 0 && array->nent == \old(array->nent)+1) && (\old(array->nent) >= array->maxnent ==> \result == -7 && array->nent == \old(array->nent)); */

static int __do_cpuid_func_emulated(struct kvm_cpuid_array *array, u32 func)
{
 if (array->nent >= array->maxnent)
  return -7;

 array->nent += cpuid_func_emulated(&array->entries[array->nent], func, false);
 return 0;
}
