typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
extern unsigned long simple_strtoul(const char *,char **,unsigned int);
extern int strncmp(const char *,const char *,__kernel_size_t);
extern char * strsep(char **,const char *);
static int default_vmode = 0;
static int default_cmode = -1;
/*@ requires options == \null || \valid_read(options); ensures \result == 0; */

static int  platinumfb_setup(char *options)
{
 char *this_opt;

 if (!options || !*options)
  return 0;

 while ((this_opt = strsep(&options, ",")) != ((void *)0)) {
  if (!strncmp(this_opt, "vmode:", 6)) {
       int vmode = simple_strtoul(this_opt+6, ((void *)0), 0);
   if (vmode > 0 && vmode <= 22)
    default_vmode = vmode;
  } else if (!strncmp(this_opt, "cmode:", 6)) {
   int depth = simple_strtoul(this_opt+6, ((void *)0), 0);
   switch (depth) {
    case 0:
    case 8:
       default_cmode = 0;
       break;
    case 15:
    case 16:
       default_cmode = 1;
       break;
    case 24:
    case 32:
       default_cmode = 2;
       break;
   }
  }
 }
 return 0;
}
