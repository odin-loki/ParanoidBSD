extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
      __attribute__((__noreturn__));
typedef int __pid_t;
typedef long int __ssize_t;
typedef long unsigned int size_t;
typedef __ssize_t ssize_t;
extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
      ;
extern void perror (const char *__s) ;
typedef __pid_t pid_t;
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
       ;
extern size_t strlen (const char *__s)
       ;
extern int open (const char *__file, int __oflag, ...) ;
extern int close (int __fd);
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    ;
static volatile int g_vsyscall;
static const char *g_proc_pid_maps_vsyscall;
/*@ requires pid > 0; ensures \result == 0 || \result == 1; */

static int test_proc_pid_maps(pid_t pid)
{
 char buf[4096];
 snprintf(buf, sizeof(buf), "/proc/%u/maps", pid);
 int fd = open(buf, 
                   00
                           );
 if (fd == -1) {
  perror("open /proc/${pid}/maps");
  return 
        1
                    ;
 } else {
  ssize_t rv = read(fd, buf, sizeof(buf));
  close(fd);
  if (g_vsyscall == 0) {
   
  ((void) sizeof ((
  rv == 0
  ) ? 1 : 0), __extension__ ({ if (
  rv == 0
  ) ; else __assert_fail (
  "rv == 0"
  , "/home/odin/pbsd-ref/linux/tools/testing/selftests/proc/proc-empty-vm.c", 228, __extension__ __PRETTY_FUNCTION__); }))
                 ;
  } else {
   size_t len = strlen(g_proc_pid_maps_vsyscall);
   
  ((void) sizeof ((
  rv == len
  ) ? 1 : 0), __extension__ ({ if (
  rv == len
  ) ; else __assert_fail (
  "rv == len"
  , "/home/odin/pbsd-ref/linux/tools/testing/selftests/proc/proc-empty-vm.c", 231, __extension__ __PRETTY_FUNCTION__); }))
                   ;
   
  ((void) sizeof ((
  memcmp(buf, g_proc_pid_maps_vsyscall, len) == 0
  ) ? 1 : 0), __extension__ ({ if (
  memcmp(buf, g_proc_pid_maps_vsyscall, len) == 0
  ) ; else __assert_fail (
  "memcmp(buf, g_proc_pid_maps_vsyscall, len) == 0"
  , "/home/odin/pbsd-ref/linux/tools/testing/selftests/proc/proc-empty-vm.c", 232, __extension__ __PRETTY_FUNCTION__); }))
                                                         ;
  }
  return 
        0
                    ;
 }
}
