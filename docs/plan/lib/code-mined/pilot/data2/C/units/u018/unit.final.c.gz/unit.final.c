typedef unsigned long __uint64_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint64_t u_int64_t;
typedef __vm_paddr_t vm_paddr_t;
extern char brwsection[];
extern char btext[];
extern char _end[];
extern char etext[];
typedef u_int64_t pt_entry_t;
typedef u_int64_t pdp_entry_t;
typedef u_int64_t pml4_entry_t;
extern pt_entry_t pg_nx;
extern vm_paddr_t kernphys;
pt_entry_t pg_nx;
vm_paddr_t kernphys;
/*@ requires pa >= 0; ensures (\result & 1) == 0 && ((\result & 2) != 0 || (\result & 0x8000000000000000ul) != 0 || \result == 0); */

static inline pt_entry_t
bootaddr_rwx(vm_paddr_t pa)
{







 if (pa < ((unsigned long)(kernphys + btext - (( ((unsigned long)-1 << 56) | ((unsigned long)(-1) << 48) | ((unsigned long)((((1<<12)/(sizeof (pml4_entry_t)))-1)) << 39) | ((unsigned long)((((1<<12)/(sizeof (pdp_entry_t)))-2)) << 30) | ((unsigned long)(0) << 21) | ((unsigned long)(0) << 12)) + (1<<21))) & ~((1<<21)-1)) ||
     pa >= ((unsigned long)(kernphys + _end - (( ((unsigned long)-1 << 56) | ((unsigned long)(-1) << 48) | ((unsigned long)((((1<<12)/(sizeof (pml4_entry_t)))-1)) << 39) | ((unsigned long)((((1<<12)/(sizeof (pdp_entry_t)))-2)) << 30) | ((unsigned long)(0) << 21) | ((unsigned long)(0) << 12)) + (1<<21))) & ~((1<<21)-1)))
  return (0x002 | pg_nx);







 if (pa >= ((unsigned long)(kernphys + brwsection - (( ((unsigned long)-1 << 56) | ((unsigned long)(-1) << 48) | ((unsigned long)((((1<<12)/(sizeof (pml4_entry_t)))-1)) << 39) | ((unsigned long)((((1<<12)/(sizeof (pdp_entry_t)))-2)) << 30) | ((unsigned long)(0) << 21) | ((unsigned long)(0) << 12)) + (1<<21))) & ~((1<<21)-1)))
  return (0x002 | pg_nx);
 if (pa < ((((unsigned long)(kernphys + etext - (( ((unsigned long)-1 << 56) | ((unsigned long)(-1) << 48) | ((unsigned long)((((1<<12)/(sizeof (pml4_entry_t)))-1)) << 39) | ((unsigned long)((((1<<12)/(sizeof (pdp_entry_t)))-2)) << 30) | ((unsigned long)(0) << 21) | ((unsigned long)(0) << 12)) + (1<<21)))) + ((1<<21)-1)) & ~((1<<21)-1)))
  return (0);
 return (pg_nx);
}
