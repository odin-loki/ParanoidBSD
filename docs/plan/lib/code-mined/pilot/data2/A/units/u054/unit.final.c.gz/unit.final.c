enum {
 false = 0,
 true = 1
};
int aoedev_init(void);
/*@ requires true; ensures \result == 0; */

int 
aoedev_init(void)
{
 return 0;
}
