typedef unsigned int __uint32_t;
typedef __uint32_t uint32_t;
/*@ requires lim > 0; ensures \result == (i == 0 ? lim : i - 1); */

static inline uint32_t
nm_prev(uint32_t i, uint32_t lim)
{
 return __builtin_expect((long)!!(i == 0), 0L) ? lim : i - 1;
}
