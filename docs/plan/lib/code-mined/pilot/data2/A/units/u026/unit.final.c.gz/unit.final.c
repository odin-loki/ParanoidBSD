extern int iic2errno(int);
/*@ requires 1; ensures iic_status == 0x0 ? \result == 0 : (iic_status & (-0x7fffffff - 1)) == 0 ? \result == 5 : ((iic_status & 0xFFFF0000) != 0 ? \result == iic_status : \result == (iic_status & ~(-0x7fffffff - 1))); */

int
iic2errno(int iic_status)
{
 switch (iic_status) {
 case 0x0: return (0);
 case 0x1: return (37);
 case 0x2: return (5);
 case 0x3: return (60);
 case 0x4: return (35);
 case 0x5: return (92);
 case 0x6: return (5);
 case 0x7: return (84);
 case 0x8: return (45);
 case 0x9: return (49);
 case 0xa: return (12);
 default:
  if ((iic_status & (-0x7fffffff - 1)) == 0)
   return (5);
  if ((iic_status & 0xFFFF0000) != 0)
   return (iic_status);
  return (iic_status & ~(-0x7fffffff - 1));
 }
}
