typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintmax_t;
typedef __uintmax_t __rman_res_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __rman_res_t rman_res_t;
typedef struct _device *device_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
struct resource;
struct resource_list_entry {
 struct { struct resource_list_entry *stqe_next; } link;
 int type;
 int rid;
 int flags;
 struct resource *res;
 rman_res_t start;
 rman_res_t end;
 rman_res_t count;
};
struct resource_list { struct resource_list_entry *stqh_first; struct resource_list_entry **stqh_last; };
void *device_get_ivars(device_t dev);
const char *device_get_nameunit(device_t dev);
int device_printf(device_t dev, const char *, ...) ;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct gpiobus_ivar
{
 struct resource_list rl;
 uint32_t npins;
 uint32_t *pins;
};
void gpiobus_free_ivars(struct gpiobus_ivar *);
int gpiobus_acquire_pin(device_t, uint32_t);
void gpiobus_release_pin(device_t, uint32_t);
static __inline int GPIOBUS_PIN_SETNAME(device_t dev, uint32_t pin_num,
                                        const char *name)
;
void
gpiobus_free_ivars(struct gpiobus_ivar *devi)
;
int
gpiobus_acquire_pin(device_t bus, uint32_t pin)
;
void
gpiobus_release_pin(device_t bus, uint32_t pin)
;
/*@ requires devi->npins >= 0; ensures \result == 0 || \result == 16; */

static int
gpiobus_acquire_child_pins(device_t dev, device_t child)
{
 struct gpiobus_ivar *devi = (struct gpiobus_ivar *) device_get_ivars(child);
 int i;

 for (i = 0; i < devi->npins; i++) {

  if (gpiobus_acquire_pin(dev, devi->pins[i]) != 0) {
   device_printf(child, "cannot acquire pin %d\n",
       devi->pins[i]);
   while (--i >= 0) {
    gpiobus_release_pin(dev, devi->pins[i]);
   }
   gpiobus_free_ivars(devi);
   return (16);
  }
 }
 for (i = 0; i < devi->npins; i++) {

  GPIOBUS_PIN_SETNAME(dev, devi->pins[i],
      device_get_nameunit(child));

 }
 return (0);
}
