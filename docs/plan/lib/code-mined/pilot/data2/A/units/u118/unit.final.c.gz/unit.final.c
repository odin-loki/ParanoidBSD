enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == ((flags & (((1UL)) << (9))) == 0); */

static inline     int arch_irqs_disabled_flags(unsigned long flags)
{
 return !(flags & (((1UL)) << (9)));
}
