typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u16 u16;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
typedef u16 uint16_t;
typedef u32 uint32_t;
static inline    bool is_pcie_gen3_supported(uint32_t pcie_link_speed_cap)
;
static inline    bool is_pcie_gen2_supported(uint32_t pcie_link_speed_cap)
;
/*@ requires true; ensures (\result == PP_PCIEGen1 || \result == PP_PCIEGen2 || \result == PP_PCIEGen3) && ((pcie_link_speed_cap & 0x0000FFFF) == 0x00000004 ==> \result == PP_PCIEGen3); */

static inline    uint16_t get_pcie_gen_support(uint32_t pcie_link_speed_cap,
         uint16_t ns_pcie_gen)
{
 uint32_t asic_pcie_link_speed_cap = (pcie_link_speed_cap &
  0x0000FFFF);
 uint32_t sys_pcie_link_speed_cap = (pcie_link_speed_cap &
  0xFFFF0000);

 switch (asic_pcie_link_speed_cap) {
 case 0x00000001:
  return PP_PCIEGen1;

 case 0x00000002:
  return PP_PCIEGen2;

 case 0x00000004:
  return PP_PCIEGen3;

 default:
  if (is_pcie_gen3_supported(sys_pcie_link_speed_cap) &&
   (ns_pcie_gen == PP_PCIEGen3)) {
   return PP_PCIEGen3;
  } else if (is_pcie_gen2_supported(sys_pcie_link_speed_cap) &&
   ((ns_pcie_gen == PP_PCIEGen3) || (ns_pcie_gen == PP_PCIEGen2))) {
   return PP_PCIEGen2;
  }
 }

 return PP_PCIEGen1;
}
