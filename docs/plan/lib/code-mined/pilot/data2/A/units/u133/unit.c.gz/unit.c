typedef long long int sqlite_int64;
typedef sqlite_int64 sqlite3_int64;
sqlite3_int64 sqlite3_memory_highwater(int resetFlag);
int sqlite3_status64(
  int op,
  sqlite3_int64 *pCurrent,
  sqlite3_int64 *pHighwater,
  int resetFlag
);
int sqlite3_status64(
  int op,
  sqlite3_int64 *pCurrent,
  sqlite3_int64 *pHighwater,
  int resetFlag
);
/*@ requires true; ensures \result >= 0; */

sqlite3_int64 sqlite3_memory_highwater(int resetFlag){
  sqlite3_int64 res, mx;
  sqlite3_status64(0, &res, &mx, resetFlag);
  return mx;
}
