typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == ((cfg & (0x1 << 0)) != 0); */

static inline    bool at_xdmac_chan_is_peripheral_xfer(u32 cfg)
{
 return cfg & (0x1 << 0);
}
