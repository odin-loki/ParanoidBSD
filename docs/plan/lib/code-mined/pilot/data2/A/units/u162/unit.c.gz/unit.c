typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __size_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __int64_t __sbintime_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int8_t int8_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef char * caddr_t;
typedef __uint32_t in_addr_t;
typedef __size_t size_t;
typedef __time_t time_t;
typedef __vm_offset_t vm_offset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __uint64_t vm_pindex_t;
typedef struct _device *device_t;
typedef struct vm_page *vm_page_t;
typedef _Bool bool;
struct bintime {
 time_t sec;
 uint64_t frac;
};
void bintime(struct bintime *bt);
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
static __inline u_int atomic_load_acq_int(const volatile u_int *p) ;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct lock_object;
struct mtx;
struct socket;
static __inline char *
index(const char *p, int ch)
;
typedef uint64_t bus_addr_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
struct resource;
struct mbuf;
struct m_tag {
 struct { struct m_tag *sle_next; } m_tag_link;
 u_int16_t m_tag_id;
 u_int16_t m_tag_len;
 u_int32_t m_tag_cookie;
 void (*m_tag_free)(struct m_tag *);
};
struct if_snd_tag_sw;
struct m_snd_tag {
 struct ifnet *ifp;
 const struct if_snd_tag_sw *sw;
 volatile u_int refcount;
};
struct pkthdr {
 union {
  struct m_snd_tag *snd_tag;
  struct ifnet *rcvif;
  struct {
   uint16_t rcvidx;
   uint16_t rcvgen;
  };
 };
 union {
  struct ifnet *leaf_rcvif;
  struct {
   uint16_t leaf_rcvidx;
   uint16_t leaf_rcvgen;
  };
 };
 struct packet_tags { struct m_tag *slh_first; } tags;
 int32_t len;


 uint32_t flowid;
 uint32_t csum_flags;
 uint16_t fibnum;
 uint8_t numa_domain;
 uint8_t rsstype;



 union {
  uint64_t rcv_tstmp;
  struct {
   uint8_t l2hlen;
   uint8_t l3hlen;
   uint8_t l4hlen;
   uint8_t l5hlen;
   uint8_t inner_l2hlen;
   uint8_t inner_l3hlen;
   uint8_t inner_l4hlen;
   uint8_t inner_l5hlen;
  };
 };
 union {
  uint8_t eight[8];
  uint16_t sixteen[4];
  uint32_t thirtytwo[2];
  uint64_t sixtyfour[1];
  uintptr_t unintptr[1];
  void *ptr;
 } PH_per;


 union {
  union {
   uint8_t eight[8];
   uint16_t sixteen[4];
   uint32_t thirtytwo[2];
   uint64_t sixtyfour[1];
   uintptr_t unintptr[1];
   void *ptr;
  } PH_loc;

  u_int memlen;
 };
};
struct ktls_session;
struct socket;
typedef void m_ext_free_t(struct mbuf *);
struct m_ext {
 union {
  volatile u_int ext_count;
  volatile u_int *ext_cnt;
 };
 uint32_t ext_size;
 uint32_t ext_type:8,
    ext_flags:24;
 union {
  struct {
   char *ext_buf;
   void *ext_arg2;
  };
  struct {







   vm_paddr_t extpg_pa[(40 / sizeof(vm_paddr_t))];
   char extpg_trail[64];
   char extpg_hdr[23];

  };
 };




 m_ext_free_t *ext_free;
 void *ext_arg1;
};
struct mbuf {







 union {
  struct mbuf *m_next;
  struct { struct mbuf *sle_next; } m_slist;
  struct { struct mbuf *stqe_next; } m_stailq;
 };
 union {
  struct mbuf *m_nextpkt;
  struct { struct mbuf *sle_next; } m_slistpkt;
  struct { struct mbuf *stqe_next; } m_stailqpkt;
 };
 caddr_t m_data;
 int32_t m_len;
 uint32_t m_type:8,
    m_flags:24;
 union {
  struct {
   union {

    struct pkthdr m_pkthdr;
    struct {


     uint8_t m_epg_npgs;
     uint8_t m_epg_nrdy;


     uint8_t m_epg_hdrlen;
     uint8_t m_epg_trllen;


     uint16_t m_epg_1st_off;
     uint16_t m_epg_last_len;
     uint8_t m_epg_flags;
     uint8_t m_epg_record_type;
     uint8_t __spare[2];
     int m_epg_enc_cnt;
     struct ktls_session *m_epg_tls;
     struct socket *m_epg_so;
     uint64_t m_epg_seqno;
     struct { struct mbuf *stqe_next; } m_epg_stailq;
    };
   };
   union {

    struct m_ext m_ext;

    char m_pktdat[1];
   };
  };
  char m_dat[1];
 };
};
static __inline void
m_tag_free(struct m_tag *t)
;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct socket;
typedef void task_fn_t(void *context, int pending);
struct task {
 struct { struct task *stqe_next; } ta_link;
 uint16_t ta_pending;
 uint8_t ta_priority;
 uint8_t ta_flags;
 task_fn_t *ta_func;
 void *ta_context;
};
struct taskqueue;
struct taskqueue;
struct ifnet;
struct ifnet;
struct mbuf;
struct ifnet;
struct mbuf;
struct ifmediareq {
 char ifm_name[16];
 int ifm_current;
 int ifm_mask;
 int ifm_status;
 int ifm_active;
 int ifm_count;
 int *ifm_ulist;
};
typedef struct ifnet *if_t;
typedef uint64_t *counter_u64_t;
struct ifnet;
struct ifnet;
typedef int (*ifm_change_cb_t)(struct ifnet *);
typedef void (*ifm_stat_cb_t)(struct ifnet *, struct ifmediareq *req);
struct ifmedia_entry {
 struct { struct ifmedia_entry *le_next; struct ifmedia_entry **le_prev; } ifm_list;
 int ifm_media;
 int ifm_data;
 void *ifm_aux;
};
struct ifmedia {
 int ifm_mask;
 int ifm_media;
 struct ifmedia_entry *ifm_cur;
 struct { struct ifmedia_entry *lh_first; } ifm_list;
 ifm_change_cb_t ifm_change;
 ifm_stat_cb_t ifm_status;
};
struct socket;
struct ifmedia;
struct buf_ring {
 uint32_t br_prod_head;
 uint32_t br_prod_tail;
 int br_prod_size;
 int br_prod_mask;
 uint64_t br_drops;
 uint32_t br_cons_head ;
 uint32_t br_cons_tail;
 int br_cons_size;
 int br_cons_mask;



 void *br_ring[1] ;
};
struct mtx;
struct ifnethead { struct ifnet *cstqh_first; struct ifnet **cstqh_last; };
struct ktls_session;
struct m_snd_tag;
struct if_snd_tag_rate_limit_params {
 uint64_t max_rate;
 uint32_t queue_level;
 uint32_t flags;
};
struct if_snd_tag_modify_tls_rx {

 uint32_t tls_hdr_tcp_sn;





 uint32_t tls_rec_length;


 uint64_t tls_seq_number;
};
union if_snd_tag_modify_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
 struct if_snd_tag_modify_tls_rx tls_rx;
};
union if_snd_tag_query_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
};
typedef int (if_snd_tag_modify_t)(struct m_snd_tag *, union if_snd_tag_modify_params *);
typedef int (if_snd_tag_query_t)(struct m_snd_tag *, union if_snd_tag_query_params *);
typedef void (if_snd_tag_free_t)(struct m_snd_tag *);
typedef struct m_snd_tag *(if_next_send_tag_t)(struct m_snd_tag *);
typedef int (if_snd_tag_status_str_t)(struct m_snd_tag *, char *buf, size_t *sz);
struct if_snd_tag_sw {
 if_snd_tag_modify_t *snd_tag_modify;
 if_snd_tag_query_t *snd_tag_query;
 if_snd_tag_free_t *snd_tag_free;
 if_next_send_tag_t *next_snd_tag;
 if_snd_tag_status_str_t *snd_tag_status_str;
 u_int type;
};
extern struct ifnethead ifnet;
struct in_addr {
 in_addr_t s_addr;
};
struct ifnet;
struct mbuf;
struct in6_addr {
 union {
  uint8_t __u6_addr8[16];
  uint16_t __u6_addr16[8];
  uint32_t __u6_addr32[4];
 } __u6_addr;
};
struct ip6_hdr;
struct ip {

 u_char ip_hl:4,
  ip_v:4;





 u_char ip_tos;
 u_short ip_len;
 u_short ip_id;
 u_short ip_off;
 u_char ip_ttl;
 u_char ip_p;
 u_short ip_sum;
 struct in_addr ip_src,ip_dst;
} __attribute__((__packed__));
struct ip6_hdr {
 union {
  struct ip6_hdrctl {
   u_int32_t ip6_un1_flow;
   u_int16_t ip6_un1_plen;
   u_int8_t ip6_un1_nxt;
   u_int8_t ip6_un1_hlim;
  } ip6_un1;
  u_int8_t ip6_un2_vfc;
 } ip6_ctlun;
 struct in6_addr ip6_src;
 struct in6_addr ip6_dst;
} __attribute__((__packed__));
typedef u_int32_t tcp_seq;
struct tcphdr {
 u_short th_sport;
 u_short th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;

 u_char th_x2:4,
  th_off:4;





 u_char th_flags;

 u_short th_win;
 u_short th_sum;
 u_short th_urp;
} __attribute__((__packed__));
union lro_address {
 u_long raw[(((12 + 2 * sizeof(struct in6_addr))+((sizeof(u_long))-1))/(sizeof(u_long)))];
 struct {
  uint8_t lro_type;
  uint8_t lro_flags;
  uint16_t vlan_id;
  uint16_t s_port;
  uint16_t d_port;
  uint32_t vxlan_vni;
  union {
   struct in_addr v4;
   struct in6_addr v6;
  } s_addr;
  union {
   struct in_addr v4;
   struct in6_addr v6;
  } d_addr;
 };
};
struct lro_parser {
 union lro_address data;
 union {
  uint8_t *l3;
  struct ip *ip4;
  struct ip6_hdr *ip6;
 };
 union {
  uint8_t *l4;
  struct tcphdr *tcp;
  struct udphdr *udp;
 };
 uint16_t total_hdr_len;
};
struct lro_entry {
 struct { struct lro_entry *le_next; struct lro_entry **le_prev; } next;
 struct { struct lro_entry *le_next; struct lro_entry **le_prev; } hash_next;
 struct mbuf *m_head;
 struct mbuf *m_tail;
 struct mbuf *m_last_mbuf;
 struct lro_parser outer;
 struct lro_parser inner;
 uint32_t next_seq;
 uint32_t ack_seq;
 uint32_t tsval;
 uint32_t tsecr;
 uint16_t compressed;
 uint16_t uncompressed;
 uint16_t window;
 uint16_t flags : 12,
    timestamp : 1,
    needs_merge : 1,
    reserved : 2;
 struct bintime alloc_time;
};
struct lro_head { struct lro_entry *lh_first; };
struct lro_mbuf_sort {
 uint64_t seq;
 struct mbuf *mb;
};
struct lro_ctrl {
 struct ifnet *ifp;
 struct lro_mbuf_sort *lro_mbuf_data;
 struct bintime lro_last_queue_time;
 uint64_t lro_queued;
 uint64_t lro_flushed;
 uint64_t lro_bad_csum;
 unsigned lro_cnt;
 unsigned lro_mbuf_count;
 unsigned lro_mbuf_max;
 unsigned short lro_ackcnt_lim;
 unsigned short lro_cpu;
 unsigned lro_length_lim;
 u_long lro_hashsz;
 uint32_t lro_last_cpu;
 uint32_t lro_cnt_of_same_cpu;
 struct lro_head *lro_hash;
 struct lro_head lro_active;
 struct lro_head lro_free;
 uint8_t lro_cpu_is_set;
};
struct udphdr {
 u_short uh_sport;
 u_short uh_dport;
 u_short uh_ulen;
 u_short uh_sum;
} __attribute__((__packed__));
struct vm_object;
typedef struct vm_object *vm_object_t;
typedef struct pv_entry {
 vm_offset_t pv_va;
 struct { struct pv_entry *tqe_next; struct pv_entry **tqe_prev; } pv_next;
} *pv_entry_t;
struct md_page {
 struct { struct pv_entry *tqh_first; struct pv_entry **tqh_last; } pv_list;
 int pv_gen;
 int pat_mode;
};
struct vm_page;
typedef uint8_t vm_page_bits_t;
typedef union vm_page_astate {
 struct {
  uint16_t flags;
  uint8_t queue;
  uint8_t act_count;
 };
 uint32_t _bits;
} vm_page_astate_t;
struct vm_page {
 union {
  struct { struct vm_page *tqe_next; struct vm_page **tqe_prev; } q;
  struct {
   struct { struct vm_page *sle_next; } ss;
  } s;
  struct {
   u_long p;
   u_long v;
  } memguard;
  struct {
   void *slab;
   void *zone;
  } uma;
 } plinks;
 vm_object_t object;
 vm_pindex_t pindex;
 vm_paddr_t phys_addr;
 struct md_page md;
 u_int ref_count;
 u_int busy_lock;
 union vm_page_astate a;
 uint8_t order;
 uint8_t pool;
 uint8_t flags;
 uint8_t oflags;
 int8_t psind;
 int8_t segind;


 vm_page_bits_t valid;
 vm_page_bits_t dirty;
};
struct mbuf;
typedef uint16_t __be16;
typedef uint32_t __be32;
typedef uint64_t __be64;
typedef uint16_t __le16;
typedef uint32_t __le32;
typedef uint64_t __le64;
struct gve_tx_pkt_desc {
 uint8_t type_flags;
 uint8_t l4_csum_offset;
 uint8_t l4_hdr_offset;
 uint8_t desc_cnt;
 __be16 len;
 __be16 seg_len;
 __be64 seg_addr;
} __attribute__((__packed__));
struct gve_tx_mtd_desc {
 uint8_t type_flags;
 uint8_t path_state;
 __be16 reserved0;
 __be32 path_hash;
 __be64 reserved1;
} __attribute__((__packed__));
struct gve_tx_seg_desc {
 uint8_t type_flags;
 uint8_t l3_offset;
 __be16 reserved;
 __be16 mss;
 __be16 seg_len;
 __be64 seg_addr;
} __attribute__((__packed__));
struct gve_rx_desc {
 uint8_t padding[48];
 __be32 rss_hash;
 __be16 mss;
 __be16 reserved;
 uint8_t hdr_len;
 uint8_t hdr_off;
 uint16_t csum;
 __be16 len;
 __be16 flags_seq;
} __attribute__((__packed__));
union gve_rx_data_slot {
 __be64 qpl_offset;
 __be64 addr;
};
struct gve_dma_handle {
 bus_addr_t bus_addr;
 void *cpu_addr;
 bus_dma_tag_t tag;
 bus_dmamap_t map;
};
union gve_tx_desc {
 struct gve_tx_pkt_desc pkt;
 struct gve_tx_mtd_desc mtd;
 struct gve_tx_seg_desc seg;
};
struct gve_tx_iovec {
 uint32_t iov_offset;
 uint32_t iov_len;
 uint32_t iov_padding;
};
struct gve_queue_config {
 uint16_t max_queues;
 uint16_t num_queues;
};
struct gve_irq_db {
 __be32 index;
} ;
enum gve_queue_format {
 GVE_QUEUE_FORMAT_UNSPECIFIED = 0x0,
 GVE_GQI_RDA_FORMAT = 0x1,
 GVE_GQI_QPL_FORMAT = 0x2,
 GVE_DQO_RDA_FORMAT = 0x3,
 GVE_DQO_QPL_FORMAT = 0x4,
};
enum gve_state_flags_bit {
 GVE_STATE_FLAG_ADMINQ_OK,
 GVE_STATE_FLAG_RESOURCES_OK,
 GVE_STATE_FLAG_QPLREG_OK,
 GVE_STATE_FLAG_RX_RINGS_OK,
 GVE_STATE_FLAG_TX_RINGS_OK,
 GVE_STATE_FLAG_QUEUES_UP,
 GVE_STATE_FLAG_LINK_UP,
 GVE_STATE_FLAG_DO_RESET,
 GVE_STATE_FLAG_IN_RESET,
 GVE_NUM_STATE_FLAGS
};
struct gve_state_flags { unsigned long __bits[(((((GVE_NUM_STATE_FLAGS)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
struct gve_queue_page_list {
 uint32_t id;
 uint32_t num_dmas;
 uint32_t num_pages;
 vm_offset_t kva;
 vm_page_t *pages;
 struct gve_dma_handle *dmas;
};
struct gve_irq {
 struct resource *res;
 void *cookie;
};
struct gve_rx_slot_page_info {
 void *page_address;
 vm_page_t page;
 uint32_t page_offset;
 uint16_t pad;
};
struct gve_rx_ctx {

 struct mbuf *mbuf_head;
 struct mbuf *mbuf_tail;
 uint32_t total_size;
 uint8_t frag_cnt;
 bool is_tcp;
 bool drop_pkt;
};
struct gve_ring_com {
 struct gve_priv *priv;
 uint32_t id;







 struct gve_queue_resources *q_resources;
 struct gve_dma_handle q_resources_mem;


 uint32_t irq_db_offset;

 uint32_t db_offset;




 uint32_t counter_idx;
 int ntfy_id;






 struct gve_queue_page_list *qpl;

 struct task cleanup_task;
 struct taskqueue *cleanup_tq;
} ;
struct gve_rxq_stats {
 counter_u64_t rbytes;
 counter_u64_t rpackets;
 counter_u64_t rx_dropped_pkt;
 counter_u64_t rx_copybreak_cnt;
 counter_u64_t rx_frag_flip_cnt;
 counter_u64_t rx_frag_copy_cnt;
 counter_u64_t rx_dropped_pkt_desc_err;
 counter_u64_t rx_dropped_pkt_buf_post_fail;
 counter_u64_t rx_dropped_pkt_mbuf_alloc_fail;
 counter_u64_t rx_mbuf_dmamap_err;
 counter_u64_t rx_mbuf_mclget_null;
};
struct gve_rx_buf_dqo {
 union {

  struct {
   struct mbuf *mbuf;
   bus_dmamap_t dmamap;
   uint64_t addr;
   bool mapped;
  };

  struct {
   uint8_t num_nic_frags;
   uint8_t next_idx;

   struct { struct gve_rx_buf_dqo *stqe_next; } stailq_entry;
  };
 };

 struct { struct gve_rx_buf_dqo *sle_next; } slist_entry;
};
struct gve_rx_ring {
 struct gve_ring_com com;
 struct gve_dma_handle desc_ring_mem;
 uint32_t cnt;
 uint32_t fill_cnt;

 union {

  struct {
   struct gve_dma_handle data_ring_mem;


   struct gve_rx_desc *desc_ring;
   union gve_rx_data_slot *data_ring;
   struct gve_rx_slot_page_info *page_info;
   uint32_t mask;
   uint8_t seq_no;
  };


  struct {
   struct gve_dma_handle compl_ring_mem;

   struct gve_rx_compl_desc_dqo *compl_ring;
   struct gve_rx_desc_dqo *desc_ring;
   struct gve_rx_buf_dqo *bufs;
   bus_dma_tag_t buf_dmatag;

   uint32_t buf_cnt;
   uint32_t mask;
   uint32_t head;
   uint32_t tail;
   uint8_t cur_gen_bit;
   struct { struct gve_rx_buf_dqo *slh_first; } free_bufs;






   struct { struct gve_rx_buf_dqo *stqh_first; struct gve_rx_buf_dqo **stqh_last; } used_bufs;
  } dqo;
 };

 struct lro_ctrl lro;
 struct gve_rx_ctx ctx;
 struct gve_rxq_stats stats;

} ;
struct gve_tx_fifo {
 vm_offset_t base;
 uint32_t size;
 volatile int available;
 uint32_t head;
};
struct gve_tx_buffer_state {
 struct mbuf *mbuf;






 int64_t enqueue_time_sec;

 struct gve_tx_iovec iov[4];
};
struct gve_txq_stats {
 counter_u64_t tbytes;
 counter_u64_t tpackets;
 counter_u64_t tso_packet_cnt;
 counter_u64_t tx_dropped_pkt;
 counter_u64_t tx_delayed_pkt_nospace_device;
 counter_u64_t tx_dropped_pkt_nospace_bufring;
 counter_u64_t tx_delayed_pkt_nospace_descring;
 counter_u64_t tx_delayed_pkt_nospace_compring;
 counter_u64_t tx_delayed_pkt_nospace_qpl_bufs;
 counter_u64_t tx_delayed_pkt_tsoerr;
 counter_u64_t tx_dropped_pkt_vlan;
 counter_u64_t tx_mbuf_collapse;
 counter_u64_t tx_mbuf_defrag;
 counter_u64_t tx_mbuf_defrag_err;
 counter_u64_t tx_mbuf_dmamap_enomem_err;
 counter_u64_t tx_mbuf_dmamap_err;
 counter_u64_t tx_timeout;
};
struct gve_tx_pending_pkt_dqo {
 struct mbuf *mbuf;






 int64_t enqueue_time_sec;

 union {

  bus_dmamap_t dmamap;

  struct {




   int32_t qpl_buf_head;
   uint32_t num_qpl_bufs;
  };
 };
 uint8_t state;
 int next;
};
struct gve_tx_ring {
 struct gve_ring_com com;
 struct gve_dma_handle desc_ring_mem;

 struct task xmit_task;
 struct taskqueue *xmit_tq;
 bool stopped;


 struct buf_ring *br;
 struct mtx ring_mtx;

 uint32_t req;
 uint32_t done;

 int64_t last_kicked;

 union {

  struct {
   union gve_tx_desc *desc_ring;
   struct gve_tx_buffer_state *info;

   struct gve_tx_fifo fifo;

   uint32_t mask;
  };


  struct {
   struct gve_dma_handle compl_ring_mem;


   struct {
    union gve_tx_desc_dqo *desc_ring;
    uint32_t desc_mask;
    uint32_t desc_head;
    uint32_t desc_tail;
    uint32_t last_re_idx;







    int32_t free_pending_pkts_csm;
    int32_t free_qpl_bufs_csm;
    uint32_t qpl_bufs_consumed;
    uint32_t qpl_bufs_produced_cached;


    bus_dma_tag_t buf_dmatag;
   } ;


   struct {
    struct gve_tx_compl_desc_dqo *compl_ring;
    uint32_t compl_mask;
    uint32_t compl_head;
    uint8_t cur_gen_bit;
    uint32_t hw_tx_head;







    int32_t free_pending_pkts_prd;
    int32_t free_qpl_bufs_prd;
    uint32_t qpl_bufs_produced;
   } ;


   struct {

    struct gve_tx_pending_pkt_dqo *pending_pkts;
    uint16_t num_pending_pkts;
    int32_t *qpl_bufs;
   } ;
  } dqo;
 };
 struct gve_txq_stats stats;
} ;
struct gve_ptype {
 uint8_t l3_type;
 uint8_t l4_type;
};
struct gve_ptype_lut {
 struct gve_ptype ptypes[1024];
};
struct gve_priv {
 if_t ifp;
 device_t dev;
 struct ifmedia media;

 uint8_t mac[6];

 struct gve_dma_handle aq_mem;

 struct resource *reg_bar;
 struct resource *db_bar;
 struct resource *msix_table;

 uint32_t mgmt_msix_idx;
 uint32_t rx_copybreak;

 uint16_t num_event_counters;
 uint16_t default_num_queues;
 uint16_t tx_desc_cnt;
 uint16_t max_tx_desc_cnt;
 uint16_t min_tx_desc_cnt;
 uint16_t rx_desc_cnt;
 uint16_t max_rx_desc_cnt;
 uint16_t min_rx_desc_cnt;
 uint16_t rx_pages_per_qpl;
 uint64_t max_registered_pages;
 uint64_t num_registered_pages;
 uint32_t supported_features;
 uint16_t max_mtu;
 bool modify_ringsize_enabled;

 struct gve_dma_handle counter_array_mem;
 __be32 *counters;
 struct gve_dma_handle irqs_db_mem;
 struct gve_irq_db *irq_db_indices;

 enum gve_queue_format queue_format;
 struct gve_queue_config tx_cfg;
 struct gve_queue_config rx_cfg;
 uint32_t num_queues;

 struct gve_irq *irq_tbl;
 struct gve_tx_ring *tx;
 struct gve_rx_ring *rx;

 struct gve_ptype_lut *ptype_lut_dqo;





 struct gve_adminq_command *adminq;
 vm_paddr_t adminq_bus_addr;
 uint32_t adminq_mask;
 uint32_t adminq_prod_cnt;
 uint32_t adminq_cmd_fail;
 uint32_t adminq_timeouts;

 uint32_t adminq_describe_device_cnt;
 uint32_t adminq_cfg_device_resources_cnt;
 uint32_t adminq_register_page_list_cnt;
 uint32_t adminq_unregister_page_list_cnt;
 uint32_t adminq_create_tx_queue_cnt;
 uint32_t adminq_create_rx_queue_cnt;
 uint32_t adminq_destroy_tx_queue_cnt;
 uint32_t adminq_destroy_rx_queue_cnt;
 uint32_t adminq_dcfg_device_resources_cnt;
 uint32_t adminq_set_driver_parameter_cnt;
 uint32_t adminq_verify_driver_compatibility_cnt;
 uint32_t adminq_get_ptype_map_cnt;

 uint32_t interface_up_cnt;
 uint32_t interface_down_cnt;
 uint32_t reset_cnt;

 struct task service_task;
 struct taskqueue *service_tq;

 struct gve_state_flags state_flags;
 struct sx gve_iface_lock;

 struct callout tx_timeout_service;

 uint16_t check_tx_queue_idx;

 uint16_t rx_buf_size_dqo;
};
extern char gve_queue_format[8];
struct gve_tx_pkt_desc_dqo {
 __le64 buf_addr;


 uint8_t dtype:5;


 uint8_t end_of_packet:1;
 uint8_t checksum_offload_enable:1;


 uint8_t report_event:1;
 uint8_t reserved0;
 __le16 reserved1;


 __le16 compl_tag;
 uint16_t buf_size:14;
 uint16_t reserved2:2;
} __attribute__((__packed__));
struct gve_tx_context_cmd_dtype {
 uint8_t dtype:5;
 uint8_t tso:1;
 uint8_t reserved1:2;
 uint8_t reserved2;
};
struct gve_tx_tso_context_desc_dqo {

 uint32_t tso_total_len:24;
 uint32_t flex10:8;


 uint16_t mss:14;
 uint16_t reserved:2;

 uint8_t header_len;
 uint8_t flex11;
 struct gve_tx_context_cmd_dtype cmd_dtype;
 uint8_t flex0;
 uint8_t flex5;
 uint8_t flex6;
 uint8_t flex7;
 uint8_t flex8;
 uint8_t flex9;
} __attribute__((__packed__));
struct gve_tx_general_context_desc_dqo {
 uint8_t flex4;
 uint8_t flex5;
 uint8_t flex6;
 uint8_t flex7;
 uint8_t flex8;
 uint8_t flex9;
 uint8_t flex10;
 uint8_t flex11;
 struct gve_tx_context_cmd_dtype cmd_dtype;
 uint16_t reserved;
 uint8_t flex0;
 uint8_t flex1;
 uint8_t flex2;
 uint8_t flex3;
} __attribute__((__packed__));
struct gve_tx_compl_desc_dqo {




 uint16_t id:11;


 uint16_t type:3;
 uint16_t reserved0:1;


 uint16_t generation:1;
 union {




  __le16 tx_head;





  __le16 completion_tag;
 };
 __le32 reserved1;
} __attribute__((__packed__));
union gve_tx_desc_dqo {
 struct gve_tx_pkt_desc_dqo pkt;
 struct gve_tx_tso_context_desc_dqo tso_ctx;
 struct gve_tx_general_context_desc_dqo general_ctx;
};
struct gve_rx_desc_dqo {
 __le16 buf_id;
 __le16 reserved0;
 __le32 reserved1;
 __le64 buf_addr;
 __le64 header_buf_addr;
 __le64 reserved2;
} __attribute__((__packed__));
struct gve_rx_compl_desc_dqo {

 uint8_t rxdid:4;
 uint8_t reserved0:4;


 uint8_t loopback:1;




 uint8_t ipv6_ex_add:1;

 uint8_t rx_error:1;
 uint8_t reserved1:5;

 uint16_t packet_type:10;
 uint16_t ip_hdr_err:1;
 uint16_t udp_len_err:1;
 uint16_t raw_cs_invalid:1;
 uint16_t reserved2:3;

 uint16_t packet_len:14;

 uint16_t generation:1;

 uint16_t buffer_queue_id:1;

 uint16_t header_len:10;
 uint16_t rsc:1;
 uint16_t split_header:1;
 uint16_t reserved3:4;

 uint8_t descriptor_done:1;
 uint8_t end_of_packet:1;
 uint8_t header_buffer_overflow:1;
 uint8_t l3_l4_processed:1;
 uint8_t csum_ip_err:1;
 uint8_t csum_l4_err:1;
 uint8_t csum_external_ip_err:1;
 uint8_t csum_external_udp_err:1;

 uint8_t status_error1;

 __le16 reserved5;
 __le16 buf_id;

 union {

  __le16 raw_cs;

  __le16 rsc_seg_len;
 };
 __le32 hash;
 __le32 reserved6;
 __le64 reserved7;
} __attribute__((__packed__));
/*@ requires 0 <= num_bufs; ensures \result == (available >= num_bufs); */

static bool
gve_tx_have_enough_qpl_bufs(struct gve_tx_ring *tx, int num_bufs)
{
 uint32_t available = tx->dqo.qpl_bufs_produced_cached -
     tx->dqo.qpl_bufs_consumed;

 if (__builtin_expect((available >= num_bufs), 1))
  return (1);

 tx->dqo.qpl_bufs_produced_cached = atomic_load_acq_int(
     &tx->dqo.qpl_bufs_produced);
 available = tx->dqo.qpl_bufs_produced_cached -
     tx->dqo.qpl_bufs_consumed;

 if (__builtin_expect((available >= num_bufs), 1))
  return (1);
 return (0);
}
