typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == 0xb; */

static inline    u32 host1x_uclass_load_syncpt_base_r(void)
{
 return 0xb;
}
