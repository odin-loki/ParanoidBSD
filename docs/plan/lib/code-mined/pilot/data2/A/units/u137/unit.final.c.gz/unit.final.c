typedef struct sqlite3 sqlite3;
typedef long long int sqlite_int64;
typedef unsigned long long int sqlite_uint64;
typedef sqlite_int64 sqlite3_int64;
typedef sqlite_uint64 sqlite3_uint64;
typedef struct sqlite3_file sqlite3_file;
struct sqlite3_file {
  const struct sqlite3_io_methods *pMethods;
};
typedef struct sqlite3_io_methods sqlite3_io_methods;
struct sqlite3_io_methods {
  int iVersion;
  int (*xClose)(sqlite3_file*);
  int (*xRead)(sqlite3_file*, void*, int iAmt, sqlite3_int64 iOfst);
  int (*xWrite)(sqlite3_file*, const void*, int iAmt, sqlite3_int64 iOfst);
  int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
  int (*xSync)(sqlite3_file*, int flags);
  int (*xFileSize)(sqlite3_file*, sqlite3_int64 *pSize);
  int (*xLock)(sqlite3_file*, int);
  int (*xUnlock)(sqlite3_file*, int);
  int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
  int (*xFileControl)(sqlite3_file*, int op, void *pArg);
  int (*xSectorSize)(sqlite3_file*);
  int (*xDeviceCharacteristics)(sqlite3_file*);

  int (*xShmMap)(sqlite3_file*, int iPg, int pgsz, int, void volatile**);
  int (*xShmLock)(sqlite3_file*, int offset, int n, int flags);
  void (*xShmBarrier)(sqlite3_file*);
  int (*xShmUnmap)(sqlite3_file*, int deleteFlag);

  int (*xFetch)(sqlite3_file*, sqlite3_int64 iOfst, int iAmt, void **pp);
  int (*xUnfetch)(sqlite3_file*, sqlite3_int64 iOfst, void *p);


};
typedef struct sqlite3_mutex sqlite3_mutex;
typedef const char *sqlite3_filename;
typedef struct sqlite3_vfs sqlite3_vfs;
typedef void (*sqlite3_syscall_ptr)(void);
struct sqlite3_vfs {
  int iVersion;
  int szOsFile;
  int mxPathname;
  sqlite3_vfs *pNext;
  const char *zName;
  void *pAppData;
  int (*xOpen)(sqlite3_vfs*, sqlite3_filename zName, sqlite3_file*,
               int flags, int *pOutFlags);
  int (*xDelete)(sqlite3_vfs*, const char *zName, int syncDir);
  int (*xAccess)(sqlite3_vfs*, const char *zName, int flags, int *pResOut);
  int (*xFullPathname)(sqlite3_vfs*, const char *zName, int nOut, char *zOut);
  void *(*xDlOpen)(sqlite3_vfs*, const char *zFilename);
  void (*xDlError)(sqlite3_vfs*, int nByte, char *zErrMsg);
  void (*(*xDlSym)(sqlite3_vfs*,void*, const char *zSymbol))(void);
  void (*xDlClose)(sqlite3_vfs*, void*);
  int (*xRandomness)(sqlite3_vfs*, int nByte, char *zOut);
  int (*xSleep)(sqlite3_vfs*, int microseconds);
  int (*xCurrentTime)(sqlite3_vfs*, double*);
  int (*xGetLastError)(sqlite3_vfs*, int, char *);




  int (*xCurrentTimeInt64)(sqlite3_vfs*, sqlite3_int64*);




  int (*xSetSystemCall)(sqlite3_vfs*, const char *zName, sqlite3_syscall_ptr);
  sqlite3_syscall_ptr (*xGetSystemCall)(sqlite3_vfs*, const char *zName);
  const char *(*xNextSystemCall)(sqlite3_vfs*, const char *zName);





};
typedef struct sqlite3_value sqlite3_value;
typedef struct sqlite3_context sqlite3_context;
typedef struct sqlite3_vtab sqlite3_vtab;
typedef struct sqlite3_index_info sqlite3_index_info;
typedef struct sqlite3_vtab_cursor sqlite3_vtab_cursor;
typedef struct sqlite3_module sqlite3_module;
struct sqlite3_module {
  int iVersion;
  int (*xCreate)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xConnect)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xBestIndex)(sqlite3_vtab *pVTab, sqlite3_index_info*);
  int (*xDisconnect)(sqlite3_vtab *pVTab);
  int (*xDestroy)(sqlite3_vtab *pVTab);
  int (*xOpen)(sqlite3_vtab *pVTab, sqlite3_vtab_cursor **ppCursor);
  int (*xClose)(sqlite3_vtab_cursor*);
  int (*xFilter)(sqlite3_vtab_cursor*, int idxNum, const char *idxStr,
                int argc, sqlite3_value **argv);
  int (*xNext)(sqlite3_vtab_cursor*);
  int (*xEof)(sqlite3_vtab_cursor*);
  int (*xColumn)(sqlite3_vtab_cursor*, sqlite3_context*, int);
  int (*xRowid)(sqlite3_vtab_cursor*, sqlite3_int64 *pRowid);
  int (*xUpdate)(sqlite3_vtab *, int, sqlite3_value **, sqlite3_int64 *);
  int (*xBegin)(sqlite3_vtab *pVTab);
  int (*xSync)(sqlite3_vtab *pVTab);
  int (*xCommit)(sqlite3_vtab *pVTab);
  int (*xRollback)(sqlite3_vtab *pVTab);
  int (*xFindFunction)(sqlite3_vtab *pVtab, int nArg, const char *zName,
                       void (**pxFunc)(sqlite3_context*,int,sqlite3_value**),
                       void **ppArg);
  int (*xRename)(sqlite3_vtab *pVtab, const char *zNew);


  int (*xSavepoint)(sqlite3_vtab *pVTab, int);
  int (*xRelease)(sqlite3_vtab *pVTab, int);
  int (*xRollbackTo)(sqlite3_vtab *pVTab, int);


  int (*xShadowName)(const char*);


  int (*xIntegrity)(sqlite3_vtab *pVTab, const char *zSchema,
                    const char *zTabName, int mFlags, char **pzErr);
};
struct sqlite3_index_info {

  int nConstraint;
  struct sqlite3_index_constraint {
     int iColumn;
     unsigned char op;
     unsigned char usable;
     int iTermOffset;
  } *aConstraint;
  int nOrderBy;
  struct sqlite3_index_orderby {
     int iColumn;
     unsigned char desc;
  } *aOrderBy;

  struct sqlite3_index_constraint_usage {
    int argvIndex;
    unsigned char omit;
  } *aConstraintUsage;
  int idxNum;
  char *idxStr;
  int needToFreeIdxStr;
  int orderByConsumed;
  double estimatedCost;

  sqlite3_int64 estimatedRows;

  int idxFlags;

  sqlite3_uint64 colUsed;
};
struct sqlite3_vtab {
  const sqlite3_module *pModule;
  int nRef;
  char *zErrMsg;

};
struct sqlite3_vtab_cursor {
  sqlite3_vtab *pVtab;

};
typedef struct sqlite3_str sqlite3_str;
void sqlite3_str_reset(sqlite3_str*);
typedef struct sqlite3_pcache sqlite3_pcache;
typedef struct sqlite3_pcache_page sqlite3_pcache_page;
struct sqlite3_pcache_page {
  void *pBuf;
  void *pExtra;
};
typedef struct sqlite3_backup sqlite3_backup;
typedef struct Hash Hash;
typedef struct HashElem HashElem;
struct Hash {
  unsigned int htsize;
  unsigned int count;
  HashElem *first;
  struct _ht {
    unsigned int count;
    HashElem *chain;
  } *ht;
};
struct HashElem {
  HashElem *next, *prev;
  void *data;
  const char *pKey;
  unsigned int h;
};
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
void *(memcpy)(void * restrict, const void * restrict, size_t);
typedef sqlite_int64 i64;
typedef sqlite_uint64 u64;
typedef unsigned int u32;
typedef unsigned short int u16;
typedef short int i16;
typedef unsigned char u8;
typedef signed char i8;
typedef unsigned bft;
typedef short int LogEst;
typedef struct BusyHandler BusyHandler;
struct BusyHandler {
  int (*xBusyHandler)(void *,int);
  void *pBusyArg;
  int nBusy;
};
typedef struct AggInfo AggInfo;
typedef struct AutoincInfo AutoincInfo;
typedef struct Bitvec Bitvec;
typedef struct CollSeq CollSeq;
typedef struct Column Column;
typedef struct Cte Cte;
typedef struct CteUse CteUse;
typedef struct Db Db;
typedef struct DbClientData DbClientData;
typedef struct Schema Schema;
typedef struct Expr Expr;
typedef struct ExprList ExprList;
typedef struct FKey FKey;
typedef struct FuncDestructor FuncDestructor;
typedef struct FuncDef FuncDef;
typedef struct IdList IdList;
typedef struct Index Index;
typedef struct IndexedExpr IndexedExpr;
typedef struct KeyInfo KeyInfo;
typedef struct Lookaside Lookaside;
typedef struct LookasideSlot LookasideSlot;
typedef struct Module Module;
typedef struct Parse Parse;
typedef struct ParseCleanup ParseCleanup;
typedef struct RenameToken RenameToken;
typedef struct Returning Returning;
typedef struct Savepoint Savepoint;
typedef struct Select Select;
typedef struct SQLiteThread SQLiteThread;
typedef struct Subquery Subquery;
typedef struct SrcItem SrcItem;
typedef struct SrcList SrcList;
typedef struct sqlite3_str StrAccum;
typedef struct Table Table;
typedef struct TableLock TableLock;
typedef struct Token Token;
typedef struct Trigger Trigger;
typedef struct TriggerPrg TriggerPrg;
typedef struct TriggerStep TriggerStep;
typedef struct UnpackedRecord UnpackedRecord;
typedef struct Upsert Upsert;
typedef struct VTable VTable;
typedef struct VtabCtx VtabCtx;
typedef struct Window Window;
typedef struct With With;
typedef u64 Bitmask;
typedef int VList;
typedef u32 Pgno;
typedef struct Pager Pager;
typedef struct PgHdr DbPage;
typedef struct Btree Btree;
typedef struct BtCursor BtCursor;
typedef struct BtShared BtShared;
typedef struct Vdbe Vdbe;
typedef struct sqlite3_value Mem;
typedef struct SubProgram SubProgram;
typedef struct SubrtnSig SubrtnSig;
struct SubrtnSig {
  int selId;
  u8 bComplete;
  char *zAff;
  int iTable;
  int iAddr;
  int regReturn;
};
struct VdbeOp {
  u8 opcode;
  signed char p4type;
  u16 p5;
  int p1;
  int p2;
  int p3;
  union p4union {
    int i;
    void *p;
    char *z;
    i64 *pI64;
    double *pReal;
    FuncDef *pFunc;
    sqlite3_context *pCtx;
    CollSeq *pColl;
    Mem *pMem;
    VTable *pVtab;
    KeyInfo *pKeyInfo;
    u32 *ai;
    SubProgram *pProgram;
    Table *pTab;
    SubrtnSig *pSubrtnSig;



  } p4;
};
typedef struct VdbeOp VdbeOp;
struct SubProgram {
  VdbeOp *aOp;
  int nOp;
  int nMem;
  int nCsr;
  u8 *aOnce;
  void *token;
  SubProgram *pNext;
};
typedef struct PgHdr PgHdr;
typedef struct PCache PCache;
struct PgHdr {
  sqlite3_pcache_page *pPage;
  void *pData;
  void *pExtra;
  PCache *pCache;
  PgHdr *pDirty;
  Pager *pPager;
  Pgno pgno;



  u16 flags;






  i64 nRef;
  PgHdr *pDirtyNext;
  PgHdr *pDirtyPrev;


};
struct Db {
  char *zDbSName;
  Btree *pBt;
  u8 safety_level;
  u8 bSyncSet;
  Schema *pSchema;
};
struct Schema {
  int schema_cookie;
  int iGeneration;
  Hash tblHash;
  Hash idxHash;
  Hash trigHash;
  Hash fkeyHash;
  Table *pSeqTab;
  u8 file_format;
  u8 enc;
  u16 schemaFlags;
  int cache_size;
};
struct Lookaside {
  u32 bDisable;
  u16 sz;
  u16 szTrue;
  u8 bMalloced;
  u32 nSlot;
  u32 anStat[3];
  LookasideSlot *pInit;
  LookasideSlot *pFree;

  LookasideSlot *pSmallInit;
  LookasideSlot *pSmallFree;
  void *pMiddle;


  void *pStart;
  void *pEnd;
  void *pTrueEnd;
};
struct LookasideSlot {
  LookasideSlot *pNext;
};
typedef int (*sqlite3_xauth)(void*,int,const char*,const char*,const char*,
                             const char*);
struct sqlite3 {
  sqlite3_vfs *pVfs;
  struct Vdbe *pVdbe;
  CollSeq *pDfltColl;
  sqlite3_mutex *mutex;
  Db *aDb;
  int nDb;
  u32 mDbFlags;
  u64 flags;
  i64 lastRowid;
  i64 szMmap;
  u32 nSchemaLock;
  unsigned int openFlags;
  int errCode;
  int errByteOffset;
  int errMask;
  int iSysErrno;
  u32 dbOptFlags;
  u8 enc;
  u8 autoCommit;
  u8 temp_store;
  u8 mallocFailed;
  u8 bBenignMalloc;
  u8 dfltLockMode;
  signed char nextAutovac;
  u8 suppressErr;
  u8 vtabOnConflict;
  u8 isTransactionSavepoint;
  u8 mTrace;
  u8 noSharedCache;
  u8 nSqlExec;
  u8 eOpenState;
  int nextPagesize;
  i64 nChange;
  i64 nTotalChange;
  int aLimit[(11 +1)];
  int nMaxSorterMmap;
  struct sqlite3InitInfo {
    Pgno newTnum;
    u8 iDb;
    u8 busy;
    unsigned orphanTrigger : 1;
    unsigned imposterTable : 1;
    unsigned reopenMemdb : 1;
    const char **azInit;
  } init;
  int nVdbeActive;
  int nVdbeRead;
  int nVdbeWrite;
  int nVdbeExec;
  int nVDestroy;
  int nExtension;
  void **aExtension;
  union {
    void (*xLegacy)(void*,const char*);
    int (*xV2)(u32,void*,void*,void*);
  } trace;
  void *pTraceArg;

  void (*xProfile)(void*,const char*,u64);
  void *pProfileArg;

  void *pCommitArg;
  int (*xCommitCallback)(void*);
  void *pRollbackArg;
  void (*xRollbackCallback)(void*);
  void *pUpdateArg;
  void (*xUpdateCallback)(void*,int, const char*,const char*,sqlite_int64);
  void *pAutovacPagesArg;
  void (*xAutovacDestr)(void*);
  unsigned int (*xAutovacPages)(void*,const char*,u32,u32,u32);
  Parse *pParse;
  int (*xWalCallback)(void *, sqlite3 *, const char *, int);
  void *pWalArg;

  void(*xCollNeeded)(void*,sqlite3*,int eTextRep,const char*);
  void(*xCollNeeded16)(void*,sqlite3*,int eTextRep,const void*);
  void *pCollNeededArg;
  sqlite3_value *pErr;
  union {
    volatile int isInterrupted;
    double notUsed1;
  } u1;
  Lookaside lookaside;

  sqlite3_xauth xAuth;
  void *pAuthArg;


  int (*xProgress)(void *);
  void *pProgressArg;
  unsigned nProgressOps;


  int nVTrans;
  Hash aModule;
  VtabCtx *pVtabCtx;
  VTable **aVTrans;
  VTable *pDisconnect;

  Hash aFunc;
  Hash aCollSeq;
  BusyHandler busyHandler;
  Db aDbStatic[2];
  Savepoint *pSavepoint;
  int nAnalysisLimit;
  int busyTimeout;




  int nSavepoint;
  int nStatement;
  i64 nDeferredCons;
  i64 nDeferredImmCons;
  int *pnBytesFreed;
  DbClientData *pDbData;
};
struct FuncDef {
  i16 nArg;
  u32 funcFlags;
  void *pUserData;
  FuncDef *pNext;
  void (*xSFunc)(sqlite3_context*,int,sqlite3_value**);
  void (*xFinalize)(sqlite3_context*);
  void (*xValue)(sqlite3_context*);
  void (*xInverse)(sqlite3_context*,int,sqlite3_value**);
  const char *zName;
  union {
    FuncDef *pHash;
    FuncDestructor *pDestructor;
  } u;
};
struct FuncDestructor {
  int nRef;
  void (*xDestroy)(void *);
  void *pUserData;
};
struct Savepoint {
  char *zName;
  i64 nDeferredCons;
  i64 nDeferredImmCons;
  Savepoint *pNext;
};
struct Module {
  const sqlite3_module *pModule;
  const char *zName;
  int nRefModule;
  void *pAux;
  void (*xDestroy)(void *);
  Table *pEpoTab;
};
struct Column {
  char *zCnName;
  unsigned notNull :4;
  unsigned eCType :4;
  char affinity;
  u8 szEst;
  u8 hName;
  u16 iDflt;
  u16 colFlags;
};
struct CollSeq {
  char *zName;
  u8 enc;
  void *pUser;
  int (*xCmp)(void*,int, const void*, int, const void*);
  void (*xDel)(void*);
};
struct VTable {
  sqlite3 *db;
  Module *pMod;
  sqlite3_vtab *pVtab;
  int nRef;
  u8 bConstraint;
  u8 bAllSchemas;
  u8 eVtabRisk;
  int iSavepoint;
  VTable *pNext;
};
struct Table {
  char *zName;
  Column *aCol;
  Index *pIndex;
  char *zColAff;
  ExprList *pCheck;

  Pgno tnum;
  u32 nTabRef;
  u32 tabFlags;
  i16 iPKey;
  i16 nCol;
  i16 nNVCol;
  LogEst nRowLogEst;
  LogEst szTabRow;



  u8 keyConf;
  u8 eTabType;
  union {
    struct {
      int addColOffset;
      FKey *pFKey;
      ExprList *pDfltList;

    } tab;
    struct {
      Select *pSelect;
    } view;
    struct {
      int nArg;
      char **azArg;
      VTable *p;
    } vtab;
  } u;
  Trigger *pTrigger;
  Schema *pSchema;
  u8 aHx[16];
};
struct FKey {
  Table *pFrom;
  FKey *pNextFrom;
  char *zTo;
  FKey *pNextTo;
  FKey *pPrevTo;
  int nCol;

  u8 isDeferred;
  u8 aAction[2];
  Trigger *apTrigger[2];
  struct sColMap {
    int iFrom;
    char *zCol;
  } aCol[1];
};
struct KeyInfo {
  u32 nRef;
  u8 enc;
  u16 nKeyField;
  u16 nAllField;
  sqlite3 *db;
  u8 *aSortFlags;
  CollSeq *aColl[1];
};
struct UnpackedRecord {
  KeyInfo *pKeyInfo;
  Mem *aMem;
  union {
    char *z;
    i64 i;
  } u;
  int n;
  u16 nField;
  i8 default_rc;
  u8 errCode;
  i8 r1;
  i8 r2;
  u8 eqSeen;
};
struct Index {
  char *zName;
  i16 *aiColumn;
  LogEst *aiRowLogEst;
  Table *pTable;
  char *zColAff;
  Index *pNext;
  Schema *pSchema;
  u8 *aSortOrder;
  const char **azColl;
  Expr *pPartIdxWhere;
  ExprList *aColExpr;
  Pgno tnum;
  LogEst szIdxRow;
  u16 nKeyCol;
  u16 nColumn;
  u8 onError;
  unsigned idxType:2;
  unsigned bUnordered:1;
  unsigned uniqNotNull:1;
  unsigned isResized:1;
  unsigned isCovering:1;
  unsigned noSkipScan:1;
  unsigned hasStat1:1;
  unsigned bNoQuery:1;
  unsigned bAscKeyBug:1;
  unsigned bHasVCol:1;
  unsigned bHasExpr:1;
  Bitmask colNotIdxed;
};
struct Token {
  const char *z;
  unsigned int n;
};
struct AggInfo {
  u8 directMode;

  u8 useSortingIdx;

  u32 nSortingColumn;
  int sortingIdx;
  int sortingIdxPTab;
  int iFirstReg;
  ExprList *pGroupBy;
  struct AggInfo_col {
    Table *pTab;
    Expr *pCExpr;
    int iTable;
    int iColumn;
    int iSorterColumn;
  } *aCol;
  int nColumn;
  int nAccumulator;


  struct AggInfo_func {
    Expr *pFExpr;
    FuncDef *pFunc;
    int iDistinct;
    int iDistAddr;
    int iOBTab;
    u8 bOBPayload;
    u8 bOBUnique;
    u8 bUseSubtype;
  } *aFunc;
  int nFunc;
  u32 selId;



};
typedef i16 ynVar;
struct Expr {
  u8 op;
  char affExpr;
  u8 op2;






  u32 flags;
  union {
    char *zToken;
    int iValue;
  } u;






  Expr *pLeft;
  Expr *pRight;
  union {
    ExprList *pList;
    Select *pSelect;
  } x;







  int nHeight;

  int iTable;






  ynVar iColumn;


  i16 iAgg;
  union {
    int iJoin;
    int iOfst;
  } w;
  AggInfo *pAggInfo;
  union {
    Table *pTab;

    Window *pWin;
    int nReg;
    struct {
      int iAddr;
      int regReturn;
    } sub;
  } y;
};
struct ExprList {
  int nExpr;
  int nAlloc;
  struct ExprList_item {
    Expr *pExpr;
    char *zEName;
    struct {
      u8 sortFlags;
      unsigned eEName :2;
      unsigned done :1;
      unsigned reusable :1;
      unsigned bSorterRef :1;
      unsigned bNulls :1;
      unsigned bUsed :1;
      unsigned bUsingTerm:1;
      unsigned bNoExpand: 1;

    } fg;
    union {
      struct {
        u16 iOrderByCol;
        u16 iAlias;
      } x;
      int iConstExprReg;

    } u;
  } a[1];
};
struct IdList {
  int nId;
  struct IdList_item {
    char *zName;
  } a[1];
};
struct Subquery {
  Select *pSelect;
  int addrFillSub;
  int regReturn;
  int regResult;
};
struct SrcItem {
  char *zName;
  char *zAlias;
  Table *pSTab;
  struct {
    u8 jointype;
    unsigned notIndexed :1;
    unsigned isIndexedBy :1;
    unsigned isSubquery :1;
    unsigned isTabFunc :1;
    unsigned isCorrelated :1;
    unsigned isMaterialized:1;
    unsigned viaCoroutine :1;
    unsigned isRecursive :1;
    unsigned fromDDL :1;
    unsigned isCte :1;
    unsigned notCte :1;
    unsigned isUsing :1;
    unsigned isOn :1;
    unsigned isSynthUsing :1;
    unsigned isNestedFrom :1;
    unsigned rowidUsed :1;
    unsigned fixedSchema :1;
    unsigned hadSchema :1;
  } fg;
  int iCursor;
  Bitmask colUsed;
  union {
    char *zIndexedBy;
    ExprList *pFuncArg;
    u32 nRow;
  } u1;
  union {
    Index *pIBIndex;
    CteUse *pCteUse;
  } u2;
  union {
    Expr *pOn;
    IdList *pUsing;
  } u3;
  union {
    Schema *pSchema;
    char *zDatabase;
    Subquery *pSubq;
  } u4;
};
struct SrcList {
  int nSrc;
  u32 nAlloc;
  SrcItem a[1];
};
struct Upsert {
  ExprList *pUpsertTarget;
  Expr *pUpsertTargetWhere;
  ExprList *pUpsertSet;
  Expr *pUpsertWhere;
  Upsert *pNextUpsert;
  u8 isDoUpdate;
  u8 isDup;


  void *pToFree;





  Index *pUpsertIdx;
  SrcList *pUpsertSrc;
  int regData;
  int iDataCur;
  int iIdxCur;
};
struct Select {
  u8 op;
  LogEst nSelectRow;
  u32 selFlags;
  int iLimit, iOffset;
  u32 selId;
  int addrOpenEphm[2];
  ExprList *pEList;
  SrcList *pSrc;
  Expr *pWhere;
  ExprList *pGroupBy;
  Expr *pHaving;
  ExprList *pOrderBy;
  Select *pPrior;
  Select *pNext;
  Expr *pLimit;
  With *pWith;

  Window *pWin;
  Window *pWinDefn;

};
struct AutoincInfo {
  AutoincInfo *pNext;
  Table *pTab;
  int iDb;
  int regCtr;
};
struct TriggerPrg {
  Trigger *pTrigger;
  TriggerPrg *pNext;
  SubProgram *pProgram;
  int orconf;
  u32 aColmask[2];
};
typedef unsigned int yDbMask;
struct IndexedExpr {
  Expr *pExpr;
  int iDataCur;
  int iIdxCur;
  int iIdxCol;
  u8 bMaybeNullRow;
  u8 aff;
  IndexedExpr *pIENext;



};
struct ParseCleanup {
  ParseCleanup *pNext;
  void *pPtr;
  void (*xCleanup)(sqlite3*,void*);
};
struct Parse {
  sqlite3 *db;
  char *zErrMsg;
  Vdbe *pVdbe;
  int rc;
  LogEst nQueryLoop;
  u8 nested;
  u8 nTempReg;
  u8 isMultiWrite;
  u8 mayAbort;
  u8 hasCompound;
  u8 disableLookaside;
  u8 prepFlags;
  u8 withinRJSubrtn;
  u8 mSubrtnSig;
  u8 eTriggerOp;
  u8 bReturning;
  u8 eOrconf;
  u8 disableTriggers;
  bft colNamesSet :1;
  bft bHasWith :1;
  bft okConstFactor :1;
  bft checkSchema :1;
  int nRangeReg;
  int iRangeReg;
  int nErr;
  int nTab;
  int nMem;
  int szOpAlloc;
  int iSelfTab;

  int nLabel;
  int nLabelAlloc;
  int *aLabel;
  ExprList *pConstExpr;
  IndexedExpr *pIdxEpr;
  IndexedExpr *pIdxPartExpr;
  yDbMask writeMask;
  yDbMask cookieMask;
  int nMaxArg;
  int nSelect;

  u32 nProgressSteps;


  int nTableLock;
  TableLock *aTableLock;

  AutoincInfo *pAinc;
  Parse *pToplevel;
  Table *pTriggerTab;
  TriggerPrg *pTriggerPrg;
  ParseCleanup *pCleanup;
  int aTempReg[8];
  Parse *pOuterParse;
  Token sNameToken;
  u32 oldmask;
  u32 newmask;
  union {
    struct {
      int addrCrTab;
      int regRowid;
      int regRoot;
      Token constraintName;
    } cr;
    struct {
      Returning *pReturning;
    } d;
  } u1;
  Token sLastToken;
  ynVar nVar;
  u8 iPkSortOrder;
  u8 explain;
  u8 eParseMode;

  int nVtabLock;

  int nHeight;
  int addrExplain;
  VList *pVList;
  Vdbe *pReprepare;
  const char *zTail;
  Table *pNewTable;
  Index *pNewIndex;


  Trigger *pNewTrigger;
  const char *zAuthContext;

  Token sArg;
  Table **apVtabLock;

  With *pWith;

  RenameToken *pRename;

};
struct Trigger {
  char *zName;
  char *table;
  u8 op;
  u8 tr_tm;
  u8 bReturning;
  Expr *pWhen;
  IdList *pColumns;

  Schema *pSchema;
  Schema *pTabSchema;
  TriggerStep *step_list;
  Trigger *pNext;
};
struct TriggerStep {
  u8 op;

  u8 orconf;
  Trigger *pTrig;
  Select *pSelect;
  char *zTarget;
  SrcList *pFrom;
  Expr *pWhere;
  ExprList *pExprList;
  IdList *pIdList;
  Upsert *pUpsert;
  char *zSpan;
  TriggerStep *pNext;
  TriggerStep *pLast;
};
struct Returning {
  Parse *pParse;
  ExprList *pReturnEL;
  Trigger retTrig;
  TriggerStep retTStep;
  int iRetCur;
  int nRetCol;
  int iRetReg;
  char zName[40];
};
struct sqlite3_str {
  sqlite3 *db;
  char *zText;
  u32 nAlloc;
  u32 mxAlloc;
  u32 nChar;
  u8 accError;
  u8 printfFlags;
};
struct Cte {
  char *zName;
  ExprList *pCols;
  Select *pSelect;
  const char *zCteErr;
  CteUse *pUse;
  u8 eM10d;
};
struct With {
  int nCte;
  int bView;
  With *pOuter;
  Cte a[1];
};
struct CteUse {
  int nUse;
  int addrM9e;
  int regRtn;
  int iCur;
  LogEst nRowEst;
  u8 eM10d;
};
struct DbClientData {
  DbClientData *pNext;
  void *pData;
  void (*xDestructor)(void*);
  char zName[1];
};
struct Window {
  char *zName;
  char *zBase;
  ExprList *pPartition;
  ExprList *pOrderBy;
  u8 eFrmType;
  u8 eStart;
  u8 eEnd;
  u8 bImplicitFrame;
  u8 eExclude;
  Expr *pStart;
  Expr *pEnd;
  Window **ppThis;
  Window *pNextWin;
  Expr *pFilter;
  FuncDef *pWFunc;
  int iEphCsr;
  int regAccum;
  int regResult;
  int csrApp;
  int regApp;
  int regPart;
  Expr *pOwner;
  int nBufferCol;
  int iArgCol;
  int regOne;
  int regStartRowid;
  int regEndRowid;
  u8 bExprArgs;

};
static void *sqlite3Realloc(void*, u64);
static void *sqlite3DbRealloc(sqlite3 *, void *, u64);
static int sqlite3DbMallocSize(sqlite3*, const void*);
static int sqlite3StrAccumEnlarge(StrAccum*, i64);
static void sqlite3StrAccumSetError(StrAccum*, u8);
typedef struct VdbeOp Op;
typedef unsigned Bool;
typedef struct VdbeSorter VdbeSorter;
typedef struct AuxData AuxData;
typedef struct VdbeTxtBlbCache VdbeTxtBlbCache;
typedef struct VdbeCursor VdbeCursor;
struct VdbeCursor {
  u8 eCurType;
  i8 iDb;
  u8 nullRow;
  u8 deferredMoveto;
  u8 isTable;




  Bool isEphemeral:1;
  Bool useRandomRowid:1;
  Bool isOrdered:1;
  Bool noReuse:1;
  Bool colCache:1;
  u16 seekHit;
  union {
    Btree *pBtx;
    u32 *aAltMap;
  } ub;
  i64 seqCount;





  u32 cacheStatus;
  int seekResult;
  VdbeCursor *pAltCursor;
  union {
    BtCursor *pCursor;
    sqlite3_vtab_cursor *pVCur;
    VdbeSorter *pSorter;
  } uc;
  KeyInfo *pKeyInfo;
  u32 iHdrOffset;
  Pgno pgnoRoot;
  i16 nField;
  u16 nHdrParsed;
  i64 movetoTarget;
  u32 *aOffset;
  const u8 *aRow;
  u32 payloadSize;
  u32 szRow;



  VdbeTxtBlbCache *pCache;



  u32 aType[1];
};
struct VdbeTxtBlbCache {
  char *pCValue;
  i64 iOffset;
  int iCol;
  u32 cacheStatus;
  u32 colCacheCtr;
};
typedef struct VdbeFrame VdbeFrame;
struct VdbeFrame {
  Vdbe *v;
  VdbeFrame *pParent;
  Op *aOp;
  Mem *aMem;
  VdbeCursor **apCsr;
  u8 *aOnce;
  void *token;
  i64 lastRowid;
  AuxData *pAuxData;



  int nCursor;
  int pc;
  int nOp;
  int nMem;
  int nChildMem;
  int nChildCsr;
  i64 nChange;
  i64 nDbChange;
};
struct sqlite3_value {
  union MemValue {
    double r;
    i64 i;
    int nZero;
    const char *zPType;
    FuncDef *pDef;
  } u;
  char *z;
  int n;
  u16 flags;
  u8 enc;
  u8 eSubtype;

  sqlite3 *db;
  int szMalloc;
  u32 uTemp;
  char *zMalloc;
  void (*xDel)(void*);





};
struct AuxData {
  int iAuxOp;
  int iAuxArg;
  void *pAux;
  void (*xDeleteAux)(void*);
  AuxData *pNextAux;
};
struct sqlite3_context {
  Mem *pOut;
  FuncDef *pFunc;
  Mem *pMem;
  Vdbe *pVdbe;
  int iOp;
  int isError;
  u8 enc;
  u8 skipFlag;
  u16 argc;
  sqlite3_value *argv[1];
};
struct Vdbe {
  sqlite3 *db;
  Vdbe **ppVPrev,*pVNext;
  Parse *pParse;
  ynVar nVar;
  int nMem;
  int nCursor;
  u32 cacheCtr;
  int pc;
  int rc;
  i64 nChange;
  int iStatement;
  i64 iCurrentTime;
  i64 nFkConstraint;
  i64 nStmtDefCons;
  i64 nStmtDefImmCons;
  Mem *aMem;
  Mem **apArg;
  VdbeCursor **apCsr;
  Mem *aVar;




  Op *aOp;
  int nOp;
  int nOpAlloc;
  Mem *aColName;
  Mem *pResultRow;
  char *zErrMsg;
  VList *pVList;

  i64 startTime;






  u16 nResColumn;
  u16 nResAlloc;
  u8 errorAction;
  u8 minWriteFileFormat;
  u8 prepFlags;
  u8 eVdbeState;
  bft expired:2;
  bft explain:2;
  bft changeCntOn:1;
  bft usesStmtJournal:1;
  bft readOnly:1;
  bft bIsReader:1;
  bft haveEqpOps:1;
  yDbMask btreeMask;
  yDbMask lockMask;
  u32 aCounter[9];
  char *zSql;




  void *pFree;
  VdbeFrame *pFrame;
  VdbeFrame *pDelFrame;
  int nFrame;
  u32 expmask;
  SubProgram *pProgram;
  AuxData *pAuxData;




};
struct pthread;
struct pthread_mutex;
typedef struct pthread *pthread_t;
typedef struct pthread_mutex *pthread_mutex_t;
struct sqlite3_mutex {
  pthread_mutex_t mutex;
};
static int sqlite3DbMallocSize(sqlite3 *db, const void *p);
static void *sqlite3Realloc(void *pOld, u64 nBytes);
static void *sqlite3DbRealloc(sqlite3 *db, void *p, u64 n);
static void sqlite3StrAccumSetError(StrAccum *p, u8 eError);
/*@ requires N >= 0; ensures (\result == 0 && p->accError != 0) || (\result == N && p->nAlloc >= p->nChar + N + 1); */

static int sqlite3StrAccumEnlarge(StrAccum *p, i64 N){
  char *zNew;
  ((void)0);
  if( p->accError ){
    ;
    ;
    return 0;
  }
  if( p->mxAlloc==0 ){
    sqlite3StrAccumSetError(p, 18);
    return p->nAlloc - p->nChar - 1;
  }else{
    char *zOld = (((p)->printfFlags & 0x04)!=0) ? p->zText : 0;
    i64 szNew = p->nChar + N + 1;
    if( szNew+p->nChar<=p->mxAlloc ){


      szNew += p->nChar;
    }
    if( szNew > p->mxAlloc ){
      sqlite3_str_reset(p);
      sqlite3StrAccumSetError(p, 18);
      return 0;
    }else{
      p->nAlloc = (int)szNew;
    }
    if( p->db ){
      zNew = sqlite3DbRealloc(p->db, zOld, p->nAlloc);
    }else{
      zNew = sqlite3Realloc(zOld, p->nAlloc);
    }
    if( zNew ){
      ((void)0);
      if( !(((p)->printfFlags & 0x04)!=0) && p->nChar>0 ) memcpy(zNew, p->zText, p->nChar);
      p->zText = zNew;
      p->nAlloc = sqlite3DbMallocSize(p->db, zNew);
      p->printfFlags |= 0x04;
    }else{
      sqlite3_str_reset(p);
      sqlite3StrAccumSetError(p, 7);
      return 0;
    }
  }
  ((void)0);
  return (int)N;
}
void sqlite3_str_reset(StrAccum *p);
struct SQLiteThread {
  pthread_t tid;
  int done;
  void *pOut;
  void *(*xTask)(void*);
  void *pIn;
};
struct Bitvec {
  u32 iSize;
  u32 nSet;


  u32 iDivisor;



  union {
    u8 aBitmap[((((512 -(3*sizeof(u32)))/sizeof(Bitvec*))*sizeof(Bitvec*))/sizeof(u8))];
    u32 aHash[((((512 -(3*sizeof(u32)))/sizeof(Bitvec*))*sizeof(Bitvec*))/sizeof(u32))];
    Bitvec *apSub[((u32)((((512 -(3*sizeof(u32)))/sizeof(Bitvec*))*sizeof(Bitvec*))/sizeof(Bitvec *)))];
  } u;
};
struct PCache {
  PgHdr *pDirty, *pDirtyTail;
  PgHdr *pSynced;
  i64 nRefSum;
  int szCache;
  int szSpill;
  int szPage;
  int szExtra;
  u8 bPurgeable;
  u8 eCreate;
  int (*xStress)(void*,PgHdr*);
  void *pStress;
  sqlite3_pcache *pCache;
};
typedef struct Wal Wal;
typedef struct PagerSavepoint PagerSavepoint;
struct PagerSavepoint {
  i64 iOffset;
  i64 iHdrOffset;
  Bitvec *pInSavepoint;
  Pgno nOrig;
  Pgno iSubRec;
  int bTruncateOnRelease;

  u32 aWalData[4];

};
struct Pager {
  sqlite3_vfs *pVfs;
  u8 exclusiveMode;
  u8 journalMode;
  u8 useJournal;
  u8 noSync;
  u8 fullSync;
  u8 extraSync;
  u8 syncFlags;
  u8 walSyncFlags;
  u8 tempFile;
  u8 noLock;
  u8 readOnly;
  u8 memDb;
  u8 memVfs;
  u8 eState;
  u8 eLock;
  u8 changeCountDone;
  u8 setSuper;
  u8 doNotSpill;
  u8 subjInMemory;
  u8 bUseFetch;
  u8 hasHeldSharedLock;
  Pgno dbSize;
  Pgno dbOrigSize;
  Pgno dbFileSize;
  Pgno dbHintSize;
  int errCode;
  int nRec;
  u32 cksumInit;
  u32 nSubRec;
  Bitvec *pInJournal;
  sqlite3_file *fd;
  sqlite3_file *jfd;
  sqlite3_file *sjfd;
  i64 journalOff;
  i64 journalHdr;
  sqlite3_backup *pBackup;
  PagerSavepoint *aSavepoint;
  int nSavepoint;
  u32 iDataVersion;
  char dbFileVers[16];

  int nMmapOut;
  sqlite3_int64 szMmap;
  PgHdr *pMmapFreelist;




  u16 nExtra;
  i16 nReserve;
  u32 vfsFlags;
  u32 sectorSize;
  Pgno mxPgno;
  Pgno lckPgno;
  i64 pageSize;
  i64 journalSizeLimit;
  char *zFilename;
  char *zJournal;
  int (*xBusyHandler)(void*);
  void *pBusyHandlerArg;
  u32 aStat[4];



  void (*xReiniter)(DbPage*);
  int (*xGet)(Pager*,Pgno,DbPage**,int);
  char *pTmpSpace;
  PCache *pPCache;

  Wal *pWal;
  char *zWal;




};
typedef struct WalIndexHdr WalIndexHdr;
struct WalIndexHdr {
  u32 iVersion;
  u32 unused;
  u32 iChange;
  u8 isInit;
  u8 bigEndCksum;
  u16 szPage;
  u32 mxFrame;
  u32 nPage;
  u32 aFrameCksum[2];
  u32 aSalt[2];
  u32 aCksum[2];
};
struct Wal {
  sqlite3_vfs *pVfs;
  sqlite3_file *pDbFd;
  sqlite3_file *pWalFd;
  u32 iCallback;
  i64 mxWalSize;
  int nWiData;
  int szFirstBlock;
  volatile u32 **apWiData;
  u32 szPage;
  i16 readLock;
  u8 syncFlags;
  u8 exclusiveMode;
  u8 writeLock;
  u8 ckptLock;
  u8 readOnly;
  u8 truncateOnCommit;
  u8 syncHeader;
  u8 padToSectorBoundary;
  u8 bShmUnreliable;
  WalIndexHdr hdr;
  u32 minFrame;
  u32 iReCksum;
  const char *zWalName;
  u32 nCkpt;
};
typedef struct MemPage MemPage;
typedef struct BtLock BtLock;
typedef struct CellInfo CellInfo;
struct MemPage {
  u8 isInit;
  u8 intKey;
  u8 intKeyLeaf;
  Pgno pgno;


  u8 leaf;
  u8 hdrOffset;
  u8 childPtrSize;
  u8 max1bytePayload;
  u8 nOverflow;
  u16 maxLocal;
  u16 minLocal;
  u16 cellOffset;
  int nFree;
  u16 nCell;
  u16 maskPage;
  u16 aiOvfl[4];

  u8 *apOvfl[4];
  BtShared *pBt;
  u8 *aData;
  u8 *aDataEnd;


  u8 *aCellIdx;
  u8 *aDataOfst;
  DbPage *pDbPage;
  u16 (*xCellSize)(MemPage*,u8*);
  void (*xParseCell)(MemPage*,u8*,CellInfo*);
};
struct BtLock {
  Btree *pBtree;
  Pgno iTable;
  u8 eLock;
  BtLock *pNext;
};
struct Btree {
  sqlite3 *db;
  BtShared *pBt;
  u8 inTrans;
  u8 sharable;
  u8 locked;
  u8 hasIncrblobCur;
  int wantToLock;
  int nBackup;
  u32 iBDataVersion;
  Btree *pNext;
  Btree *pPrev;




  BtLock lock;

};
struct BtShared {
  Pager *pPager;
  sqlite3 *db;
  BtCursor *pCursor;
  MemPage *pPage1;
  u8 openFlags;

  u8 autoVacuum;
  u8 incrVacuum;
  u8 bDoTruncate;

  u8 inTransaction;
  u8 max1bytePayload;
  u8 nReserveWanted;
  u16 btsFlags;
  u16 maxLocal;
  u16 minLocal;
  u16 maxLeaf;
  u16 minLeaf;
  u32 pageSize;
  u32 usableSize;
  int nTransaction;
  u32 nPage;
  void *pSchema;
  void (*xFreeSchema)(void*);
  sqlite3_mutex *mutex;
  Bitvec *pHasContent;

  int nRef;
  BtShared *pNext;
  BtLock *pLock;
  Btree *pWriter;

  u8 *pTmpSpace;
  int nPreformatSize;
};
struct CellInfo {
  i64 nKey;
  u8 *pPayload;
  u32 nPayload;
  u16 nLocal;
  u16 nSize;
};
struct BtCursor {
  u8 eState;
  u8 curFlags;
  u8 curPagerFlags;
  u8 hints;
  int skipNext;

  Btree *pBtree;
  Pgno *aOverflow;
  void *pKey;



  BtShared *pBt;
  BtCursor *pNext;
  CellInfo info;
  i64 nKey;
  Pgno pgnoRoot;
  i8 iPage;
  u8 curIntKey;
  u16 ix;
  u16 aiIdx[20 -1];
  struct KeyInfo *pKeyInfo;
  MemPage *pPage;
  MemPage *apPage[20 -1];
};
struct sqlite3_backup {
  sqlite3* pDestDb;
  Btree *pDest;
  u32 iDestSchema;
  int bDestLocked;

  Pgno iNext;
  sqlite3* pSrcDb;
  Btree *pSrc;

  int rc;




  Pgno nRemaining;
  Pgno nPagecount;

  int isAttached;
  sqlite3_backup *pNext;
};
typedef struct MergeEngine MergeEngine;
typedef struct PmaReader PmaReader;
typedef struct SorterRecord SorterRecord;
typedef struct SortSubtask SortSubtask;
typedef struct SorterFile SorterFile;
typedef struct SorterList SorterList;
typedef struct IncrMerger IncrMerger;
struct SorterFile {
  sqlite3_file *pFd;
  i64 iEof;
};
struct SorterList {
  SorterRecord *pList;
  u8 *aMemory;
  i64 szPMA;
};
struct MergeEngine {
  int nTree;
  SortSubtask *pTask;
  int *aTree;
  PmaReader *aReadr;
};
typedef int (*SorterCompare)(SortSubtask*,int*,const void*,int,const void*,int);
struct SortSubtask {
  SQLiteThread *pThread;
  int bDone;
  int nPMA;
  VdbeSorter *pSorter;
  UnpackedRecord *pUnpacked;
  SorterList list;
  SorterCompare xCompare;
  SorterFile file;
  SorterFile file2;
};
struct VdbeSorter {
  int mnPmaSize;
  int mxPmaSize;
  int mxKeysize;
  int pgsz;
  PmaReader *pReader;
  MergeEngine *pMerger;
  sqlite3 *db;
  KeyInfo *pKeyInfo;
  UnpackedRecord *pUnpacked;
  SorterList list;
  int iMemory;
  int nMemory;
  u8 bUsePMA;
  u8 bUseThreads;
  u8 iPrev;
  u8 nTask;
  u8 typeMask;
  SortSubtask aTask[1];
};
struct PmaReader {
  i64 iReadOff;
  i64 iEof;
  int nAlloc;
  int nKey;
  sqlite3_file *pFd;
  u8 *aAlloc;
  u8 *aKey;
  u8 *aBuffer;
  int nBuffer;
  u8 *aMap;
  IncrMerger *pIncr;
};
struct IncrMerger {
  SortSubtask *pTask;
  MergeEngine *pMerger;
  i64 iStartOff;
  int mxSz;
  int bEof;
  int bUseThread;
  SorterFile aFile[2];
};
struct SorterRecord {
  int nVal;
  union {
    SorterRecord *pNext;
    int iNext;
  } u;

};
struct RenameToken {
  const void *p;
  Token t;
  RenameToken *pNext;
};
struct TableLock {
  int iDb;
  Pgno iTab;
  u8 isWriteLock;
  const char *zLockName;
};
struct VtabCtx {
  VTable *pVTable;
  Table *pTab;
  VtabCtx *pPrior;
  int bDeclared;
};
static void disableLookaside(Parse *pParse);
