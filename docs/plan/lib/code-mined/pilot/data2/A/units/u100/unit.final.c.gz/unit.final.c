typedef unsigned int __u32;
typedef __u32 u32;
int strcmp(const char *cs, const char *ct);
extern int strcmp(const char *,const char *);
/*@ requires val != ((void *)0); ensures \result == 0 ==> mode != 0; ensures \result != 0 ==> (\result == -22 && mode == 0); */

static int parse_mode(char *val, u32 *mode)
{
 *mode = 0;

 if (!strcmp(val, "idle"))
  *mode = (1 << 1);
 if (!strcmp(val, "huge"))
  *mode = (1 << 0);
 if (!strcmp(val, "huge_idle"))
  *mode = (1 << 1) | (1 << 0);
 if (!strcmp(val, "incompressible"))
  *mode = (1 << 2);

 if (*mode == 0)
  return -22;
 return 0;
}
