struct drm_device;
struct drm_file;
typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef s32 int32_t;
typedef u32 uint32_t;
typedef u64 uint64_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef u64 dma_addr_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef u64 phys_addr_t;
typedef phys_addr_t resource_size_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
typedef __builtin_va_list va_list;
struct pt_regs;
void abort(void);
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct va_format {
 const char *fmt;
 va_list *va;
};
struct module;
struct pi_entry {
 const char *fmt;
 const char *func;
 const char *file;
 unsigned int line;
 const char *level;
 const char *subsys_fmt_prefix;
} __attribute__((__packed__));
struct static_key {
 atomic_t enabled;
 union {
  unsigned long type;
  struct jump_entry *entries;
  struct static_key_mod *next;
 };

};
struct jump_entry {
 s32 code;
 s32 target;
 long key;
};
struct module;
static inline     bool static_key_false(struct static_key *key)
;
static inline     bool static_key_true(struct static_key *key)
;
struct static_key_true {
 struct static_key key;
};
struct static_key_false {
 struct static_key key;
};
struct _ddebug {




 const char *modname;
 const char *function;
 const char *filename;
 const char *format;
 unsigned int lineno:18;
 unsigned int class_id:6;














 unsigned int flags:8;

 union {
  struct static_key_true dd_key_true;
  struct static_key_false dd_key_false;
 } key;

} ;
enum class_map_type {
 DD_CLASS_TYPE_DISJOINT_BITS,




 DD_CLASS_TYPE_LEVEL_NUM,




 DD_CLASS_TYPE_DISJOINT_NAMES,




 DD_CLASS_TYPE_LEVEL_NAMES,





};
struct ddebug_class_map {
 struct list_head link;
 struct module *mod;
 const char *mod_name;
 const char **class_names;
 const int length;
 const int base;
 enum class_map_type map_type;
};
struct _ddebug_info {
 struct _ddebug *descs;
 struct ddebug_class_map *classes;
 unsigned int num_descs;
 unsigned int num_classes;
};
struct device;
struct net_device;
struct kernel_param;
struct pt_regs;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
struct module;
struct task_struct;
typedef unsigned int drm_magic_t;
struct drm_mode_fb_cmd2 {

 __u32 fb_id;

 __u32 width;

 __u32 height;




 __u32 pixel_format;




 __u32 flags;





 __u32 handles[4];

 __u32 pitches[4];

 __u32 offsets[4];





 __u64 modifier[4];
};
enum drm_xe_oa_unit_type {




 DRM_XE_OA_UNIT_TYPE_OAG,


 DRM_XE_OA_UNIT_TYPE_OAM,


 DRM_XE_OA_UNIT_TYPE_OAM_SAG,
};
struct drm_xe_madvise {

 __u64 extensions;


 __u64 start;


 __u64 range;


 __u32 vm_id;


 __u32 type;

 union {
  struct {

   __u32 devmem_fd;


   __u16 migration_policy;


   __u16 pad;


   __u64 reserved;
  } preferred_mem_loc;
  struct {

   __u32 val;


   __u32 pad;


   __u64 reserved;
  } atomic;






  struct {

   __u32 val;


   __u32 pad;


   __u64 reserved;
  } pat_index;
 };


 __u64 reserved[2];
};
struct cacheline_padding {
 char x[1];
} ;
struct task_struct;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct static_call_site {
 s32 addr;
 s32 key;
};
struct static_call_key {
 void *func;
 union {

  unsigned long type;
  struct static_call_mod *mods;
  struct static_call_site *sites;
 };
};
struct completion;
struct user;
static inline     u64 field_mask(u64 field)
;
struct pt_regs;
struct device;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct notifier_block;
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct task_struct;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct page;
struct range {
 u64 start;
 u64 end;
};
struct task_struct;
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct fred_cs {

 u64 cs : 16,

  sl : 2,

  wfe : 1,
   : 45;
};
struct fred_ss {

 u64 ss : 16,

  sti : 1,

  swevent : 1,

  nmi : 1,
   : 13,

  vector : 8,
   : 8,

  type : 4,
   : 4,

  enclave : 1,

  lm : 1,




  nested : 1,
   : 1,





  insnlen : 4;
};
struct pt_regs {





 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;


 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;


 unsigned long ip;

 union {

  u16 cs;

  u64 csx;

  struct fred_cs fred_cs;
 };

 unsigned long flags;
 unsigned long sp;

 union {

  u16 ss;

  u64 ssx;

  struct fred_ss fred_ss;
 };






};
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long p4dval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { p4dval_t p4d; } p4d_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct task_struct;
struct task_struct;
struct mm_struct;
struct static_key;
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
static inline    void prefetch(const void *x)
;
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
struct pt_regs;
extern  __typeof__(unsigned int) lockdep_recursion;
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct device;
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
struct task_cputime {
 u64 stime;
 u64 utime;
 unsigned long long sum_exec_runtime;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct static_call_key;
struct tracepoint_func {
 void *func;
 void *data;
 int prio;
};
struct tracepoint_ext {
 int (*regfunc)(void);
 void (*unregfunc)(void);

 unsigned int faultable:1;
};
struct tracepoint {
 const char *name;
 struct static_key_false key;
 struct static_call_key *static_call_key;
 void *static_call_tramp;
 void *iterator;
 void *probestub;
 struct tracepoint_func *funcs;
 struct tracepoint_ext *ext;
};
typedef const int tracepoint_ptr_t;
struct bpf_raw_event_map {
 struct tracepoint *tp;
 void *bpf_func;
 u32 num_args;
 u32 writable_size;
} ;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
struct task_struct;
struct page;
struct vm_area_struct;
struct mm_struct;
struct hlist_nulls_head {
 struct hlist_nulls_node *first;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
typedef struct wait_queue_entry wait_queue_entry_t;
typedef int (*wait_queue_func_t)(struct wait_queue_entry *wq_entry, unsigned mode, int flags, void *key);
struct wait_queue_entry {
 unsigned int flags;
 void *private;
 wait_queue_func_t func;
 struct list_head entry;
};
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
struct page;
struct mutex;
struct kref {
 refcount_t refcount;
};
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
extern void complete(struct completion *);
typedef __s64 time64_t;
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct module;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct notifier_block;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct delayed_work {
 struct work_struct work;
 struct timer_list timer;


 struct workqueue_struct *wq;
 int cpu;
};
struct rcu_work {
 struct work_struct work;
 struct callback_head rcu;


 struct workqueue_struct *wq;
};
struct rcu_segcblist {
 struct callback_head *head;
 struct callback_head **tails[4];
 unsigned long gp_seq[4];

 atomic_long_t len;



 long seglen[4];
 u8 flags;
};
struct srcu_struct;
struct srcu_node;
struct srcu_struct;
struct srcu_ctr {
 atomic_long_t srcu_locks;
 atomic_long_t srcu_unlocks;
};
struct srcu_data {

 struct srcu_ctr srcu_ctrs[2];
 int srcu_reader_flavor;



 spinlock_t lock ;
 struct rcu_segcblist srcu_cblist;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 bool srcu_cblist_invoking;
 struct timer_list delay_work;
 struct work_struct work;
 struct callback_head srcu_barrier_head;
 struct srcu_node *mynode;
 unsigned long grpmask;

 int cpu;
 struct srcu_struct *ssp;
};
struct srcu_node {
 spinlock_t lock;
 unsigned long srcu_have_cbs[4];

 unsigned long srcu_data_have_cbs[4];
 unsigned long srcu_gp_seq_needed_exp;
 struct srcu_node *srcu_parent;
 int grplo;
 int grphi;
};
struct srcu_usage {
 struct srcu_node *node;
 struct srcu_node *level[3 + 1];

 int srcu_size_state;
 struct mutex srcu_cb_mutex;
 spinlock_t lock;
 struct mutex srcu_gp_mutex;
 unsigned long srcu_gp_seq;
 unsigned long srcu_gp_seq_needed;
 unsigned long srcu_gp_seq_needed_exp;
 unsigned long srcu_gp_start;
 unsigned long srcu_last_gp_end;
 unsigned long srcu_size_jiffies;
 unsigned long srcu_n_lock_retries;
 unsigned long srcu_n_exp_nodelay;
 bool sda_is_static;
 unsigned long srcu_barrier_seq;
 struct mutex srcu_barrier_mutex;
 struct completion srcu_barrier_completion;

 atomic_t srcu_barrier_cpu_cnt;


 unsigned long reschedule_jiffies;
 unsigned long reschedule_count;
 struct delayed_work work;
 struct srcu_struct *srcu_ssp;
};
struct srcu_struct {
 struct srcu_ctr *srcu_ctrp;
 struct srcu_data *sda;
 struct lockdep_map dep_map;
 struct srcu_usage *srcu_sup;
};
struct notifier_block;
typedef int (*notifier_fn_t)(struct notifier_block *nb,
   unsigned long action, void *data);
struct notifier_block {
 notifier_fn_t notifier_call;
 struct notifier_block *next;
 int priority;
};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct lru_gen_mm_list {

 struct list_head fifo;

 spinlock_t lock;
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct lruvec;
struct zswap_lruvec_state {
 atomic_long_t nr_disk_swapins;
};
enum migratetype {
 MIGRATE_UNMOVABLE,
 MIGRATE_MOVABLE,
 MIGRATE_RECLAIMABLE,
 MIGRATE_PCPTYPES,
 MIGRATE_HIGHATOMIC = MIGRATE_PCPTYPES,
 MIGRATE_CMA,
 __MIGRATE_TYPE_END = MIGRATE_CMA,




 MIGRATE_ISOLATE,

 MIGRATE_TYPES
};
struct free_area {
 struct list_head free_list[MIGRATE_TYPES];
 unsigned long nr_free;
};
struct pglist_data;
enum numa_stat_item {
 NUMA_HIT,
 NUMA_MISS,
 NUMA_FOREIGN,
 NUMA_INTERLEAVE_HIT,
 NUMA_LOCAL,
 NUMA_OTHER,
 NR_VM_NUMA_EVENT_ITEMS
};
enum zone_stat_item {

 NR_FREE_PAGES,
 NR_FREE_PAGES_BLOCKS,
 NR_ZONE_LRU_BASE,
 NR_ZONE_INACTIVE_ANON = NR_ZONE_LRU_BASE,
 NR_ZONE_ACTIVE_ANON,
 NR_ZONE_INACTIVE_FILE,
 NR_ZONE_ACTIVE_FILE,
 NR_ZONE_UNEVICTABLE,
 NR_ZONE_WRITE_PENDING,
 NR_MLOCK,


 NR_ZSPAGES,

 NR_FREE_CMA_PAGES,

 NR_UNACCEPTED,

 NR_VM_ZONE_STAT_ITEMS };
enum node_stat_item {
 NR_LRU_BASE,
 NR_INACTIVE_ANON = NR_LRU_BASE,
 NR_ACTIVE_ANON,
 NR_INACTIVE_FILE,
 NR_ACTIVE_FILE,
 NR_UNEVICTABLE,
 NR_SLAB_RECLAIMABLE_B,
 NR_SLAB_UNRECLAIMABLE_B,
 NR_ISOLATED_ANON,
 NR_ISOLATED_FILE,
 WORKINGSET_NODES,
 WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_ANON = WORKINGSET_REFAULT_BASE,
 WORKINGSET_REFAULT_FILE,
 WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_ANON = WORKINGSET_ACTIVATE_BASE,
 WORKINGSET_ACTIVATE_FILE,
 WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_ANON = WORKINGSET_RESTORE_BASE,
 WORKINGSET_RESTORE_FILE,
 WORKINGSET_NODERECLAIM,
 NR_ANON_MAPPED,
 NR_FILE_MAPPED,

 NR_FILE_PAGES,
 NR_FILE_DIRTY,
 NR_WRITEBACK,
 NR_SHMEM,
 NR_SHMEM_THPS,
 NR_SHMEM_PMDMAPPED,
 NR_FILE_THPS,
 NR_FILE_PMDMAPPED,
 NR_ANON_THPS,
 NR_VMSCAN_WRITE,
 NR_VMSCAN_IMMEDIATE,
 NR_DIRTIED,
 NR_WRITTEN,
 NR_THROTTLED_WRITTEN,
 NR_KERNEL_MISC_RECLAIMABLE,
 NR_FOLL_PIN_ACQUIRED,
 NR_FOLL_PIN_RELEASED,
 NR_KERNEL_STACK_KB,



 NR_PAGETABLE,
 NR_SECONDARY_PAGETABLE,

 NR_IOMMU_PAGES,


 NR_SWAPCACHE,


 PGPROMOTE_SUCCESS,





 PGPROMOTE_CANDIDATE,
 PGPROMOTE_CANDIDATE_NRL,


 PGDEMOTE_KSWAPD,
 PGDEMOTE_DIRECT,
 PGDEMOTE_KHUGEPAGED,
 PGDEMOTE_PROACTIVE,

 NR_HUGETLB,

 NR_BALLOON_PAGES,
 NR_KERNEL_FILE_PAGES,
 NR_VM_NODE_STAT_ITEMS
};
enum lru_list {
 LRU_INACTIVE_ANON = 0,
 LRU_ACTIVE_ANON = 0 + 1,
 LRU_INACTIVE_FILE = 0 + 2,
 LRU_ACTIVE_FILE = 0 + 2 + 1,
 LRU_UNEVICTABLE,
 NR_LRU_LISTS
};
enum vmscan_throttle_state {
 VMSCAN_THROTTLE_WRITEBACK,
 VMSCAN_THROTTLE_ISOLATED,
 VMSCAN_THROTTLE_NOPROGRESS,
 VMSCAN_THROTTLE_CONGESTED,
 NR_VMSCAN_THROTTLE,
};
struct lruvec;
struct lru_gen_folio {

 unsigned long max_seq;

 unsigned long min_seq[2];

 unsigned long timestamps[4U];

 struct list_head folios[4U][2][5];

 long nr_pages[4U][2][5];

 unsigned long avg_refaulted[2][4U];

 unsigned long avg_total[2][4U];

 unsigned long protected[4U][2][4U];

 atomic_long_t evicted[4U][2][4U];
 atomic_long_t refaulted[4U][2][4U];

 bool enabled;

 u8 gen;

 u8 seg;

 struct hlist_nulls_node list;
};
enum {
 MM_LEAF_TOTAL,
 MM_LEAF_YOUNG,
 MM_NONLEAF_FOUND,
 MM_NONLEAF_ADDED,
 NR_MM_STATS
};
struct lru_gen_mm_state {

 unsigned long seq;

 struct list_head *head;

 struct list_head *tail;

 unsigned long *filters[2];

 unsigned long stats[4U][NR_MM_STATS];
};
struct lru_gen_mm_walk {

 struct lruvec *lruvec;

 unsigned long seq;

 unsigned long next_addr;

 int nr_pages[4U][2][5];

 int mm_stats[NR_MM_STATS];

 int batched;
 int swappiness;
 bool force_scan;
};
struct lru_gen_memcg {

 unsigned long seq;

 unsigned long nr_memcgs[3];

 struct hlist_nulls_head fifo[3][8];

 spinlock_t lock;
};
struct lruvec {
 struct list_head lists[NR_LRU_LISTS];

 spinlock_t lru_lock;





 unsigned long anon_cost;
 unsigned long file_cost;

 atomic_long_t nonresident_age;

 unsigned long refaults[2];

 unsigned long flags;


 struct lru_gen_folio lrugen;


 struct lru_gen_mm_state mm_state;



 struct pglist_data *pgdat;

 struct zswap_lruvec_state zswap_lruvec_state;
};
enum zone_watermarks {
 WMARK_MIN,
 WMARK_LOW,
 WMARK_HIGH,
 WMARK_PROMO,
 NR_WMARK
};
struct per_cpu_pages {
 spinlock_t lock;
 int count;
 int high;
 int high_min;
 int high_max;
 int batch;
 u8 flags;
 u8 alloc_factor;

 u8 expire;

 short free_count;


 struct list_head lists[((MIGRATE_PCPTYPES * (3 + 1)) + 2)];
} ;
struct per_cpu_zonestat {

 s8 vm_stat_diff[NR_VM_ZONE_STAT_ITEMS];
 s8 stat_threshold;







 unsigned long vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];

};
struct per_cpu_nodestat {
 s8 stat_threshold;
 s8 vm_node_stat_diff[NR_VM_NODE_STAT_ITEMS];
};
enum zone_type {
 ZONE_DMA,


 ZONE_DMA32,






 ZONE_NORMAL,
 ZONE_MOVABLE,

 ZONE_DEVICE,

 __MAX_NR_ZONES

};
struct zone {



 unsigned long _watermark[NR_WMARK];
 unsigned long watermark_boost;

 unsigned long nr_reserved_highatomic;
 unsigned long nr_free_highatomic;
 long lowmem_reserve[5];


 int node;

 struct pglist_data *zone_pgdat;
 struct per_cpu_pages *per_cpu_pageset;
 struct per_cpu_zonestat *per_cpu_zonestats;




 int pageset_high_min;
 int pageset_high_max;
 int pageset_batch;
 unsigned long zone_start_pfn;
 atomic_long_t managed_pages;
 unsigned long spanned_pages;
 unsigned long present_pages;

 unsigned long present_early_pages;


 unsigned long cma_pages;


 const char *name;







 unsigned long nr_isolate_pageblock;




 seqlock_t span_seqlock;


 int initialized;


 struct cacheline_padding _pad1_;


 struct free_area free_area[(10 + 1)];



 struct list_head unaccepted_pages;


 struct work_struct unaccepted_cleanup;



 unsigned long flags;


 spinlock_t lock;


 struct llist_head trylock_free_pages;


 struct cacheline_padding _pad2_;






 unsigned long percpu_drift_mark;



 unsigned long compact_cached_free_pfn;

 unsigned long compact_cached_migrate_pfn[2];
 unsigned long compact_init_migrate_pfn;
 unsigned long compact_init_free_pfn;
 unsigned int compact_considered;
 unsigned int compact_defer_shift;
 int compact_order_failed;




 bool compact_blockskip_flush;


 bool contiguous;

 struct cacheline_padding _pad3_;

 atomic_long_t vm_stat[NR_VM_ZONE_STAT_ITEMS];
 atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
} ;
enum {
 ZONELIST_FALLBACK,





 ZONELIST_NOFALLBACK,

 MAX_ZONELISTS
};
struct zoneref {
 struct zone *zone;
 int zone_idx;
};
struct zonelist {
 struct zoneref _zonerefs[((1 << 10) * 5) + 1];
};
struct deferred_split {
 spinlock_t split_queue_lock;
 struct list_head split_queue;
 unsigned long split_queue_len;
};
struct memory_failure_stats {






 unsigned long total;






 unsigned long ignored;
 unsigned long failed;
 unsigned long delayed;
 unsigned long recovered;
};
typedef struct pglist_data {





 struct zone node_zones[5];






 struct zonelist node_zonelists[MAX_ZONELISTS];

 int nr_zones;
 spinlock_t node_size_lock;

 unsigned long node_start_pfn;
 unsigned long node_present_pages;
 unsigned long node_spanned_pages;

 int node_id;
 wait_queue_head_t kswapd_wait;
 wait_queue_head_t pfmemalloc_wait;


 wait_queue_head_t reclaim_wait[NR_VMSCAN_THROTTLE];

 atomic_t nr_writeback_throttled;
 unsigned long nr_reclaim_start;


 struct mutex kswapd_lock;

 struct task_struct *kswapd;
 int kswapd_order;
 enum zone_type kswapd_highest_zoneidx;

 atomic_t kswapd_failures;


 int kcompactd_max_order;
 enum zone_type kcompactd_highest_zoneidx;
 wait_queue_head_t kcompactd_wait;
 struct task_struct *kcompactd;
 bool proactive_compact_trigger;





 unsigned long totalreserve_pages;





 unsigned long min_unmapped_pages;
 unsigned long min_slab_pages;



 struct cacheline_padding _pad1_;






 unsigned long first_deferred_pfn;



 struct deferred_split deferred_split_queue;




 unsigned int nbp_rl_start;

 unsigned long nbp_rl_nr_cand;

 unsigned int nbp_threshold;

 unsigned int nbp_th_start;




 unsigned long nbp_th_nr_cand;
 struct lruvec __lruvec;

 unsigned long flags;



 struct lru_gen_mm_walk mm_walk;

 struct lru_gen_memcg memcg_lru;


 struct cacheline_padding _pad2_;


 struct per_cpu_nodestat *per_cpu_nodestats;
 atomic_long_t vm_stat[NR_VM_NODE_STAT_ITEMS];

 struct memory_tier *memtier;


 struct memory_failure_stats mf_stats;

} pg_data_t;
struct page;
struct zone;
struct pglist_data;
struct resource;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct device_node;
struct pt_regs;
struct irq_domain;
struct timespec64;
extern  __typeof__(int) numa_node;
struct vm_area_struct;
struct mempolicy;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct shrinker_info_unit {
 atomic_long_t nr_deferred[64];
 unsigned long map[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct shrinker_info {
 struct callback_head rcu;
 int map_nr_max;
 struct shrinker_info_unit *unit[1];
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct pglist_data;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
struct file;
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct resource {
 resource_size_t start;
 resource_size_t end;
 const char *name;
 unsigned long flags;
 unsigned long desc;
 struct resource *parent, *sibling, *child;
};
struct device;
struct resource;
struct device;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct list_lru;
struct mem_cgroup;
struct device;
struct device_node;
struct attribute;
struct task_struct;
struct pt_regs;
enum pid_type;
struct seq_file;
struct task_struct;
struct exception_table_entry {
 int insn, fixup, data;
};
struct pt_regs;
struct interval_tree_node {
 struct rb_node rb;
 unsigned long start;
 unsigned long last;
 unsigned long __subtree_last;
};
struct mmu_notifier_subscriptions;
struct mmu_notifier_range;
struct mmu_interval_notifier;
enum mmu_notifier_event {
 MMU_NOTIFY_UNMAP = 0,
 MMU_NOTIFY_CLEAR,
 MMU_NOTIFY_PROTECTION_VMA,
 MMU_NOTIFY_PROTECTION_PAGE,
 MMU_NOTIFY_SOFT_DIRTY,
 MMU_NOTIFY_RELEASE,
 MMU_NOTIFY_MIGRATE,
 MMU_NOTIFY_EXCLUSIVE,
};
struct mmu_interval_notifier_ops {
 bool (*invalidate)(struct mmu_interval_notifier *interval_sub,
      const struct mmu_notifier_range *range,
      unsigned long cur_seq);
};
struct mmu_interval_notifier {
 struct interval_tree_node interval_tree;
 const struct mmu_interval_notifier_ops *ops;
 struct mm_struct *mm;
 struct hlist_node deferred_item;
 unsigned long invalidate_seq;
};
struct mmu_notifier_range {
 struct mm_struct *mm;
 unsigned long start;
 unsigned long end;
 unsigned flags;
 enum mmu_notifier_event event;
 void *owner;
};
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct user_namespace;
struct uid_gid_map;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
extern bool capable(int cap);
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
extern bool hrtimer_active(const struct hrtimer *timer);
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct pt_regs;
struct folio_batch;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct inode;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
typedef int __kernel_rwf_t;
struct backing_dev_info;
struct bdi_writeback;
struct bio;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct iovec;
struct kiocb;
struct kobject;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
struct fasync_struct {
 rwlock_t fa_lock;
 int magic;
 int fa_fd;
 struct fasync_struct *fa_next;
 struct file *fa_file;
 struct callback_head fa_rcu;
};
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct idr {
 struct xarray idr_rt;
 unsigned int idr_base;
 unsigned int idr_next;
};
struct ida {
 struct xarray xa;
};
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct kernfs_open_node;
struct kernfs_iattrs;
struct kernfs_elem_dir {
 unsigned long subdirs;

 struct rb_root children;





 struct kernfs_root *root;




 unsigned long rev;
};
struct kernfs_elem_symlink {
 struct kernfs_node *target_kn;
};
struct kernfs_elem_attr {
 const struct kernfs_ops *ops;
 struct kernfs_open_node *open;
 loff_t size;
 struct kernfs_node *notify_next;
};
struct kernfs_node {
 atomic_t count;
 atomic_t active;

 struct lockdep_map dep_map;







 struct kernfs_node *__parent;
 const char *name;

 struct rb_node rb;

 const void *ns;
 unsigned int hash;
 unsigned short flags;
 umode_t mode;

 union {
  struct kernfs_elem_dir dir;
  struct kernfs_elem_symlink symlink;
  struct kernfs_elem_attr attr;
 };





 u64 id;

 void *priv;
 struct kernfs_iattrs *iattr;

 struct callback_head rcu;
};
struct kernfs_open_file {

 struct kernfs_node *kn;
 struct file *file;
 struct seq_file *seq_file;
 void *priv;


 struct mutex mutex;
 struct mutex prealloc_mutex;
 int event;
 struct list_head list;
 char *prealloc_buf;

 size_t atomic_write_len;
 bool mmapped:1;
 bool released:1;
 const struct vm_operations_struct *vm_ops;
};
struct kernfs_ops {




 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);
 int (*seq_show)(struct seq_file *sf, void *v);

 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);

 ssize_t (*read)(struct kernfs_open_file *of, char *buf, size_t bytes,
   loff_t off);
 size_t atomic_write_len;






 bool prealloc;
 ssize_t (*write)(struct kernfs_open_file *of, char *buf, size_t bytes,
    loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 int (*mmap)(struct kernfs_open_file *of, struct vm_area_struct *vma);
 loff_t (*llseek)(struct kernfs_open_file *of, loff_t offset, int whence);
};
struct sock;
struct kobject;
enum kobj_ns_type {
 KOBJ_NS_TYPE_NONE = 0,
 KOBJ_NS_TYPE_NET,
 KOBJ_NS_TYPES
};
struct kobj_ns_type_operations {
 enum kobj_ns_type type;
 bool (*current_may_mount)(void);
 void *(*grab_current_ns)(void);
 const void *(*netlink_ns)(struct sock *sk);
 const void *(*initial_ns)(void);
 void (*drop_ns)(void *);
};
struct kobject;
struct module;
struct bin_attribute;
enum kobj_ns_type;
struct attribute {
 const char *name;
 umode_t mode;

 bool ignore_lockdep:1;
 struct lock_class_key *key;
 struct lock_class_key skey;

};
struct attribute_group {
 const char *name;
 umode_t (*is_visible)(struct kobject *,
           struct attribute *, int);
 umode_t (*is_bin_visible)(struct kobject *,
        const struct bin_attribute *, int);
 size_t (*bin_size)(struct kobject *,
         const struct bin_attribute *,
         int);
 struct attribute **attrs;
 const struct bin_attribute *const *bin_attrs;
};
struct file;
struct vm_area_struct;
struct address_space;
struct bin_attribute {
 struct attribute attr;
 size_t size;
 void *private;
 struct address_space *(*f_mapping)(void);
 ssize_t (*read)(struct file *, struct kobject *, const struct bin_attribute *,
   char *, loff_t, size_t);
 ssize_t (*write)(struct file *, struct kobject *, const struct bin_attribute *,
    char *, loff_t, size_t);
 loff_t (*llseek)(struct file *, struct kobject *, const struct bin_attribute *,
    loff_t, int);
 int (*mmap)(struct file *, struct kobject *, const struct bin_attribute *attr,
      struct vm_area_struct *vma);
};
struct sysfs_ops {
 ssize_t (*show)(struct kobject *, struct attribute *, char *);
 ssize_t (*store)(struct kobject *, struct attribute *, const char *, size_t);
};
struct kobject {
 const char *name;
 struct list_head entry;
 struct kobject *parent;
 struct kset *kset;
 const struct kobj_type *ktype;
 struct kernfs_node *sd;
 struct kref kref;

 unsigned int state_initialized:1;
 unsigned int state_in_sysfs:1;
 unsigned int state_add_uevent_sent:1;
 unsigned int state_remove_uevent_sent:1;
 unsigned int uevent_suppress:1;


 struct delayed_work release;

};
struct kobj_type {
 void (*release)(struct kobject *kobj);
 const struct sysfs_ops *sysfs_ops;
 const struct attribute_group **default_groups;
 const struct kobj_ns_type_operations *(*child_ns_type)(const struct kobject *kobj);
 const void *(*namespace)(const struct kobject *kobj);
 void (*get_ownership)(const struct kobject *kobj, kuid_t *uid, kgid_t *gid);
};
struct kobj_uevent_env {
 char *argv[3];
 char *envp[64];
 int envp_idx;
 char buf[2048];
 int buflen;
};
struct kset_uevent_ops {
 int (* const filter)(const struct kobject *kobj);
 const char *(* const name)(const struct kobject *kobj);
 int (* const uevent)(const struct kobject *kobj, struct kobj_uevent_env *env);
};
struct sock;
struct kset {
 struct list_head list;
 spinlock_t list_lock;
 struct kobject kobj;
 const struct kset_uevent_ops *uevent_ops;
} ;
struct kobject;
extern atomic_long_t vm_numa_event[NR_VM_NUMA_EVENT_ITEMS];
struct mmu_notifier_range;
struct kvec;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
enum dev_dma_attr {
 DEV_DMA_NOT_SUPPORTED,
 DEV_DMA_NON_COHERENT,
 DEV_DMA_COHERENT,
};
struct fwnode_operations;
struct device;
struct fwnode_handle {
 struct fwnode_handle *secondary;
 const struct fwnode_operations *ops;


 struct device *dev;
 struct list_head suppliers;
 struct list_head consumers;
 unsigned long flags;
};
struct fwnode_endpoint {
 unsigned int port;
 unsigned int id;
 const struct fwnode_handle *local_fwnode;
};
struct fwnode_reference_args {
 struct fwnode_handle *fwnode;
 unsigned int nargs;
 u64 args[16];
};
struct fwnode_operations {
 struct fwnode_handle *(*get)(struct fwnode_handle *fwnode);
 void (*put)(struct fwnode_handle *fwnode);
 bool (*device_is_available)(const struct fwnode_handle *fwnode);
 const void *(*device_get_match_data)(const struct fwnode_handle *fwnode,
          const struct device *dev);
 bool (*device_dma_supported)(const struct fwnode_handle *fwnode);
 enum dev_dma_attr
 (*device_get_dma_attr)(const struct fwnode_handle *fwnode);
 bool (*property_present)(const struct fwnode_handle *fwnode,
     const char *propname);
 bool (*property_read_bool)(const struct fwnode_handle *fwnode,
       const char *propname);
 int (*property_read_int_array)(const struct fwnode_handle *fwnode,
           const char *propname,
           unsigned int elem_size, void *val,
           size_t nval);
 int
 (*property_read_string_array)(const struct fwnode_handle *fwnode_handle,
          const char *propname, const char **val,
          size_t nval);
 const char *(*get_name)(const struct fwnode_handle *fwnode);
 const char *(*get_name_prefix)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *(*get_parent)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*get_next_child_node)(const struct fwnode_handle *fwnode,
          struct fwnode_handle *child);
 struct fwnode_handle *
 (*get_named_child_node)(const struct fwnode_handle *fwnode,
    const char *name);
 int (*get_reference_args)(const struct fwnode_handle *fwnode,
      const char *prop, const char *nargs_prop,
      unsigned int nargs, unsigned int index,
      struct fwnode_reference_args *args);
 struct fwnode_handle *
 (*graph_get_next_endpoint)(const struct fwnode_handle *fwnode,
       struct fwnode_handle *prev);
 struct fwnode_handle *
 (*graph_get_remote_endpoint)(const struct fwnode_handle *fwnode);
 struct fwnode_handle *
 (*graph_get_port_parent)(struct fwnode_handle *fwnode);
 int (*graph_parse_endpoint)(const struct fwnode_handle *fwnode,
        struct fwnode_endpoint *endpoint);
 void *(*iomap)(struct fwnode_handle *fwnode, int index);
 int (*irq_get)(const struct fwnode_handle *fwnode, unsigned int index);
 int (*add_links)(struct fwnode_handle *fwnode);
};
struct scatterlist {
 unsigned long page_link;
 unsigned int offset;
 unsigned int length;
 dma_addr_t dma_address;

 unsigned int dma_length;


 unsigned int dma_flags;

};
struct sg_table {
 struct scatterlist *sgl;
 unsigned int nents;
 unsigned int orig_nents;
};
struct drm_prime_file_private {

 struct mutex lock;
 struct rb_root dmabufs;
 struct rb_root handles;
};
struct device;
struct dma_buf;
struct dma_buf_attachment;
struct iosys_map;
enum dma_data_direction;
struct drm_device;
struct drm_gem_object;
struct drm_file;
struct mm_struct;
struct vm_area_struct;
struct page;
struct address_space;
struct folio;
enum dma_data_direction {
 DMA_BIDIRECTIONAL = 0,
 DMA_TO_DEVICE = 1,
 DMA_FROM_DEVICE = 2,
 DMA_NONE = 3,
};
struct page;
struct kmem_cache;
struct task_struct;
struct scatterlist;
static inline    void *kmap(struct page *page)
;
static inline    void *kmap(struct page *page);
struct folio_batch;
static inline    loff_t page_offset(struct page *page)
;
struct wait_page_queue {
 struct folio *folio;
 int bit_nr;
 wait_queue_entry_t wait;
};
struct readahead_control {
 struct file *file;
 struct address_space *mapping;
 struct file_ra_state *ra;

 unsigned long _index;
 unsigned int _nr_pages;
 unsigned int _batch_count;
 bool dropbehind;
 bool _workingset;
 unsigned long _pflags;
};
enum ttm_caching {




 ttm_uncached,





 ttm_write_combined,





 ttm_cached
};
struct iosys_map;
struct ttm_device;
struct ttm_tt;
struct ttm_resource;
struct ttm_buffer_object;
struct ttm_operation_ctx;
struct ttm_pool_tt_restore;
struct ttm_tt {

 struct page **pages;

 uint32_t page_flags;

 uint32_t num_pages;

 struct sg_table *sg;

 dma_addr_t *dma_address;

 struct file *swap_storage;






 struct file *backup;




 enum ttm_caching caching;

 struct ttm_pool_tt_restore *restore;
};
int ttm_tt_create(struct ttm_buffer_object *bo, bool zero_alloc);
void ttm_tt_destroy(struct ttm_device *bdev, struct ttm_tt *ttm);
int ttm_tt_populate(struct ttm_device *bdev, struct ttm_tt *ttm,
      struct ttm_operation_ctx *ctx);
void ttm_tt_unpopulate(struct ttm_device *bdev, struct ttm_tt *ttm);
struct pt_regs;
struct bio_vec;
struct page;
struct device;
struct iosys_map {
 union {
  void *vaddr_iomem;
  void *vaddr;
 };
 bool is_iomem;
};
struct dev_pagemap_ops;
struct drm_device;
struct drm_gpusvm;
struct drm_gpusvm_notifier;
struct drm_gpusvm_ops;
struct drm_gpusvm_range;
struct drm_pagemap;
struct drm_pagemap_addr;
struct drm_gpusvm_ops {







 struct drm_gpusvm_notifier *(*notifier_alloc)(void);







 void (*notifier_free)(struct drm_gpusvm_notifier *notifier);
 struct drm_gpusvm_range *(*range_alloc)(struct drm_gpusvm *gpusvm);







 void (*range_free)(struct drm_gpusvm_range *range);
 void (*invalidate)(struct drm_gpusvm *gpusvm,
      struct drm_gpusvm_notifier *notifier,
      const struct mmu_notifier_range *mmu_range);
};
struct drm_gpusvm_notifier {
 struct drm_gpusvm *gpusvm;
 struct mmu_interval_notifier notifier;
 struct interval_tree_node itree;
 struct list_head entry;
 struct rb_root_cached root;
 struct list_head range_list;
 struct {
  u32 removed : 1;
 } flags;
};
struct drm_gpusvm_pages_flags {
 union {
  struct {

   u16 migrate_devmem : 1;

   u16 unmapped : 1;
   u16 partial_unmap : 1;
   u16 has_devmem_pages : 1;
   u16 has_dma_mapping : 1;
  };
  u16 __flags;
 };
};
struct drm_gpusvm_pages {
 struct drm_pagemap_addr *dma_addr;
 struct drm_pagemap *dpagemap;
 unsigned long notifier_seq;
 struct drm_gpusvm_pages_flags flags;
};
struct drm_gpusvm_range {
 struct drm_gpusvm *gpusvm;
 struct drm_gpusvm_notifier *notifier;
 struct kref refcount;
 struct interval_tree_node itree;
 struct list_head entry;
 struct drm_gpusvm_pages pages;
};
struct drm_gpusvm {
 const char *name;
 struct drm_device *drm;
 struct mm_struct *mm;
 unsigned long mm_start;
 unsigned long mm_range;
 unsigned long notifier_size;
 const struct drm_gpusvm_ops *ops;
 const unsigned long *chunk_sizes;
 int num_chunks;
 struct rw_semaphore notifier_lock;
 struct rb_root_cached root;
 struct list_head notifier_list;





 struct lockdep_map *lock_dep_map;

};
struct mmu_interval_notifier;
struct dma_fence;
struct drm_pagemap;
struct device;
struct drm_pagemap_addr {
 dma_addr_t addr;
 u64 proto : 54;
 u64 order : 8;
 u64 dir : 2;
};
struct drm_pagemap_ops {
 struct drm_pagemap_addr (*device_map)(struct drm_pagemap *dpagemap,
           struct device *dev,
           struct page *page,
           unsigned int order,
           enum dma_data_direction dir);
 void (*device_unmap)(struct drm_pagemap *dpagemap,
        struct device *dev,
        struct drm_pagemap_addr addr);
 int (*populate_mm)(struct drm_pagemap *dpagemap,
      unsigned long start, unsigned long end,
      struct mm_struct *mm,
      unsigned long timeslice_ms);
};
struct drm_pagemap {
 const struct drm_pagemap_ops *ops;
 struct device *dev;
};
struct drm_pagemap_devmem;
struct drm_pagemap_devmem_ops {







 void (*devmem_release)(struct drm_pagemap_devmem *devmem_allocation);
 int (*populate_devmem_pfn)(struct drm_pagemap_devmem *devmem_allocation,
       unsigned long npages, unsigned long *pfn);
 int (*copy_to_devmem)(struct page **pages,
         struct drm_pagemap_addr *pagemap_addr,
         unsigned long npages,
         struct dma_fence *pre_migrate_fence);
 int (*copy_to_ram)(struct page **pages,
      struct drm_pagemap_addr *pagemap_addr,
      unsigned long npages,
      struct dma_fence *pre_migrate_fence);
};
struct drm_pagemap_devmem {
 struct device *dev;
 struct mm_struct *mm;
 struct completion detached;
 const struct drm_pagemap_devmem_ops *ops;
 struct drm_pagemap *dpagemap;
 size_t size;
 u64 timeslice_expiration;
 struct dma_fence *pre_migrate_fence;
};
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct fd {
 unsigned long word;
};
struct device;
struct em_perf_state {
 unsigned long performance;
 unsigned long frequency;
 unsigned long power;
 unsigned long cost;
 unsigned long flags;
};
struct em_perf_table {
 struct callback_head rcu;
 struct kref kref;
 struct em_perf_state state[1];
};
struct em_perf_domain {
 struct em_perf_table *em_table;
 int nr_perf_states;
 int min_perf_state;
 int max_perf_state;
 unsigned long flags;
 unsigned long cpus[1];
};
struct device;
typedef struct pm_message {
 int event;
} pm_message_t;
struct dev_pm_ops {
 int (*prepare)(struct device *dev);
 void (*complete)(struct device *dev);
 int (*suspend)(struct device *dev);
 int (*resume)(struct device *dev);
 int (*freeze)(struct device *dev);
 int (*thaw)(struct device *dev);
 int (*poweroff)(struct device *dev);
 int (*restore)(struct device *dev);
 int (*suspend_late)(struct device *dev);
 int (*resume_early)(struct device *dev);
 int (*freeze_late)(struct device *dev);
 int (*thaw_early)(struct device *dev);
 int (*poweroff_late)(struct device *dev);
 int (*restore_early)(struct device *dev);
 int (*suspend_noirq)(struct device *dev);
 int (*resume_noirq)(struct device *dev);
 int (*freeze_noirq)(struct device *dev);
 int (*thaw_noirq)(struct device *dev);
 int (*poweroff_noirq)(struct device *dev);
 int (*restore_noirq)(struct device *dev);
 int (*runtime_suspend)(struct device *dev);
 int (*runtime_resume)(struct device *dev);
 int (*runtime_idle)(struct device *dev);
};
enum rpm_status {
 RPM_INVALID = -1,
 RPM_ACTIVE = 0,
 RPM_RESUMING,
 RPM_SUSPENDED,
 RPM_SUSPENDING,
 RPM_BLOCKED,
};
enum rpm_request {
 RPM_REQ_NONE = 0,
 RPM_REQ_IDLE,
 RPM_REQ_SUSPEND,
 RPM_REQ_AUTOSUSPEND,
 RPM_REQ_RESUME,
};
struct wakeup_source;
struct wake_irq;
struct pm_domain_data;
struct pm_subsys_data {
 spinlock_t lock;
 unsigned int refcount;

 unsigned int clock_op_might_sleep;
 struct mutex clock_mutex;
 struct list_head clock_list;


 struct pm_domain_data *domain_data;

};
struct dev_pm_info {
 pm_message_t power_state;
 bool can_wakeup:1;
 bool async_suspend:1;
 bool in_dpm_list:1;
 bool is_prepared:1;
 bool is_suspended:1;
 bool is_noirq_suspended:1;
 bool is_late_suspended:1;
 bool no_pm:1;
 bool early_init:1;
 bool direct_complete:1;
 u32 driver_flags;
 spinlock_t lock;

 struct list_head entry;
 struct completion completion;
 struct wakeup_source *wakeup;
 bool work_in_progress;
 bool wakeup_path:1;
 bool syscore:1;
 bool no_pm_callbacks:1;
 bool smart_suspend:1;
 bool must_resume:1;
 bool may_skip_resume:1;
 bool strict_midlayer:1;




 struct hrtimer suspend_timer;
 u64 timer_expires;
 struct work_struct work;
 wait_queue_head_t wait_queue;
 struct wake_irq *wakeirq;
 atomic_t usage_count;
 atomic_t child_count;
 unsigned int disable_depth:3;
 bool idle_notification:1;
 bool request_pending:1;
 bool deferred_resume:1;
 bool needs_force_resume:1;
 bool runtime_auto:1;
 bool ignore_children:1;
 bool no_callbacks:1;
 bool irq_safe:1;
 bool use_autosuspend:1;
 bool timer_autosuspends:1;
 bool memalloc_noio:1;
 unsigned int links_count;
 enum rpm_request request;
 enum rpm_status runtime_status;
 enum rpm_status last_status;
 int runtime_error;
 int autosuspend_delay;
 u64 last_busy;
 u64 active_time;
 u64 suspended_time;
 u64 accounting_timestamp;

 struct pm_subsys_data *subsys_data;
 void (*set_latency_tolerance)(struct device *, s32);
 struct dev_pm_qos *qos;
 bool detach_power_off:1;
};
struct dev_pm_domain {
 struct dev_pm_ops ops;
 int (*start)(struct device *dev);
 void (*detach)(struct device *dev, bool power_off);
 int (*activate)(struct device *dev);
 void (*sync)(struct device *dev);
 void (*dismiss)(struct device *dev);
 int (*set_performance_state)(struct device *dev, unsigned int state);
};
struct device_driver;
struct fwnode_handle;
struct bus_type {
 const char *name;
 const char *dev_name;
 const struct attribute_group **bus_groups;
 const struct attribute_group **dev_groups;
 const struct attribute_group **drv_groups;

 int (*match)(struct device *dev, const struct device_driver *drv);
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 int (*probe)(struct device *dev);
 void (*sync_state)(struct device *dev);
 void (*remove)(struct device *dev);
 void (*shutdown)(struct device *dev);
 const struct cpumask *(*irq_get_affinity)(struct device *dev,
   unsigned int irq_vec);

 int (*online)(struct device *dev);
 int (*offline)(struct device *dev);

 int (*suspend)(struct device *dev, pm_message_t state);
 int (*resume)(struct device *dev);

 int (*num_vf)(struct device *dev);

 int (*dma_configure)(struct device *dev);
 void (*dma_cleanup)(struct device *dev);

 const struct dev_pm_ops *pm;

 bool driver_override;
 bool need_parent_lock;
};
struct notifier_block;
struct device;
struct fwnode_handle;
struct class {
 const char *name;

 const struct attribute_group **class_groups;
 const struct attribute_group **dev_groups;

 int (*dev_uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode);

 void (*class_release)(const struct class *class);
 void (*dev_release)(struct device *dev);

 int (*shutdown_pre)(struct device *dev);

 const struct kobj_ns_type_operations *ns_type;
 const void *(*namespace)(const struct device *dev);

 void (*get_ownership)(const struct device *dev, kuid_t *uid, kgid_t *gid);

 const struct dev_pm_ops *pm;
};
struct device;
struct device_node;
struct resource;
struct vm_area_struct;
struct file;
struct cred;
struct file;
struct rhash_head {
 struct rhash_head *next;
};
struct rhlist_head {
 struct rhash_head rhead;
 struct rhlist_head *next;
};
struct task_struct;
struct iovec
{
 void *iov_base;
 __kernel_size_t iov_len;
};
struct page;
struct folio_queue;
struct kvec {
 void *iov_base;
 size_t iov_len;
};
enum iter_type {

 ITER_UBUF,
 ITER_IOVEC,
 ITER_BVEC,
 ITER_KVEC,
 ITER_FOLIOQ,
 ITER_XARRAY,
 ITER_DISCARD,
};
struct iov_iter {
 u8 iter_type;
 bool nofault;
 bool data_source;
 size_t iov_offset;
 union {





  struct iovec __ubuf_iovec;
  struct {
   union {

    const struct iovec *__iov;
    const struct kvec *kvec;
    const struct bio_vec *bvec;
    const struct folio_queue *folioq;
    struct xarray *xarray;
    void *ubuf;
   };
   size_t count;
  };
 };
 union {
  unsigned long nr_segs;
  u8 folioq_slot;
  loff_t xarray_start;
 };
};
struct sg_table;
struct file;
struct pid;
struct cred;
struct sock;
struct seq_file;
struct timespec64;
struct __kernel_timespec;
struct old_timespec32;
struct iocb {

 __u64 aio_data;


 __u32 aio_key;
 __kernel_rwf_t aio_rw_flags;
 __u16 aio_lio_opcode;
 __s16 aio_reqprio;
 __u32 aio_fildes;

 __u64 aio_buf;
 __u64 aio_nbytes;
 __s64 aio_offset;


 __u64 aio_reserved2;


 __u32 aio_flags;





 __u32 aio_resfd;
};
typedef s32 compat_long_t;
typedef u32 compat_uptr_t;
struct compat_robust_list {
 compat_uptr_t next;
};
struct compat_robust_list_head {
 struct compat_robust_list list;
 compat_long_t futex_offset;
 compat_uptr_t list_op_pending;
};
struct user_i387_struct {
 unsigned short cwd;
 unsigned short swd;
 unsigned short twd;

 unsigned short fop;
 __u64 rip;
 __u64 rdp;
 __u32 mxcsr;
 __u32 mxcsr_mask;
 __u32 st_space[32];
 __u32 xmm_space[64];
 __u32 padding[24];
};
struct user_regs_struct {
 unsigned long r15;
 unsigned long r14;
 unsigned long r13;
 unsigned long r12;
 unsigned long bp;
 unsigned long bx;
 unsigned long r11;
 unsigned long r10;
 unsigned long r9;
 unsigned long r8;
 unsigned long ax;
 unsigned long cx;
 unsigned long dx;
 unsigned long si;
 unsigned long di;
 unsigned long orig_ax;
 unsigned long ip;
 unsigned long cs;
 unsigned long flags;
 unsigned long sp;
 unsigned long ss;
 unsigned long fs_base;
 unsigned long gs_base;
 unsigned long ds;
 unsigned long es;
 unsigned long fs;
 unsigned long gs;
};
struct user {


  struct user_regs_struct regs;

  int u_fpvalid;

  int pad0;
  struct user_i387_struct i387;

  unsigned long int u_tsize;
  unsigned long int u_dsize;
  unsigned long int u_ssize;
  unsigned long start_code;
  unsigned long start_stack;



  long int signal;
  int reserved;
  int pad1;
  unsigned long u_ar0;

  struct user_i387_struct *u_fpstate;
  unsigned long magic;
  char u_comm[32];
  unsigned long u_debugreg[8];
  unsigned long error_code;
  unsigned long fault_address;
};
struct vdso_image {
 void *data;
 unsigned long size;

 unsigned long alt, alt_len;
 unsigned long extable_base, extable_len;
 const void *extable;

 long sym___kernel_sigreturn;
 long sym___kernel_rt_sigreturn;
 long sym___kernel_vsyscall;
 long sym_int80_landing_pad;
 long sym_vdso32_sigreturn_landing_pad;
 long sym_vdso32_rt_sigreturn_landing_pad;
};
struct task_struct;
typedef __u64 Elf64_Addr;
typedef __u16 Elf64_Half;
typedef __u32 Elf64_Word;
typedef __u64 Elf64_Xword;
typedef struct elf64_sym {
  Elf64_Word st_name;
  unsigned char st_info;
  unsigned char st_other;
  Elf64_Half st_shndx;
  Elf64_Addr st_value;
  Elf64_Xword st_size;
} Elf64_Sym;
struct file;
struct kernel_param;
struct kernel_param_ops {

 unsigned int flags;

 int (*set)(const char *val, const struct kernel_param *kp);

 int (*get)(char *buffer, const struct kernel_param *kp);

 void (*free)(void *arg);
};
struct kernel_param {
 const char *name;
 struct module *mod;
 const struct kernel_param_ops *ops;
 const u16 perm;
 s8 level;
 u8 flags;
 union {
  void *arg;
  const struct kparam_string *str;
  const struct kparam_array *arr;
 };
};
struct kparam_string {
 unsigned int maxlen;
 char *string;
};
struct kparam_array
{
 unsigned int max;
 unsigned int elemsize;
 unsigned int *num;
 const struct kernel_param_ops *ops;
 void *elem;
};
struct module;
struct latch_tree_node {
 struct rb_node node[2];
};
struct error_injection_entry {
 unsigned long addr;
 int etype;
};
struct pt_regs;
struct its_array {

 void **pages;
 int num;

};
struct mod_arch_specific {





 struct its_array its_pages;
};
struct module;
struct exception_table_entry;
struct module_kobject {
 struct kobject kobj;
 struct module *mod;
 struct kobject *drivers_dir;
 struct module_param_attrs *mp;
 struct completion *kobj_completion;
} ;
struct module_attribute {
 struct attribute attr;
 ssize_t (*show)(const struct module_attribute *, struct module_kobject *,
   char *);
 ssize_t (*store)(const struct module_attribute *, struct module_kobject *,
    const char *, size_t count);
 void (*setup)(struct module *, const char *);
 int (*test)(struct module *);
 void (*free)(struct module *);
};
struct notifier_block;
enum module_state {
 MODULE_STATE_LIVE,
 MODULE_STATE_COMING,
 MODULE_STATE_GOING,
 MODULE_STATE_UNFORMED,
};
struct mod_tree_node {
 struct module *mod;
 struct latch_tree_node node;
};
enum mod_mem_type {
 MOD_TEXT = 0,
 MOD_DATA,
 MOD_RODATA,
 MOD_RO_AFTER_INIT,
 MOD_INIT_TEXT,
 MOD_INIT_DATA,
 MOD_INIT_RODATA,

 MOD_MEM_NUM_TYPES,
 MOD_INVALID = -1,
};
struct module_memory {
 void *base;
 bool is_rox;
 unsigned int size;


 struct mod_tree_node mtn;

};
struct mod_kallsyms {
 Elf64_Sym *symtab;
 unsigned int num_symtab;
 char *strtab;
 char *typetab;
};
struct module {
 enum module_state state;


 struct list_head list;


 char name[(64 - sizeof(unsigned long))];



 unsigned char build_id[20];



 struct module_kobject mkobj;
 struct module_attribute *modinfo_attrs;
 const char *version;
 const char *srcversion;
 struct kobject *holders_dir;


 const struct kernel_symbol *syms;
 const u32 *crcs;
 unsigned int num_syms;
 struct mutex param_lock;

 struct kernel_param *kp;
 unsigned int num_kp;


 unsigned int num_gpl_syms;
 const struct kernel_symbol *gpl_syms;
 const u32 *gpl_crcs;
 bool using_gplonly_symbols;



 bool sig_ok;


 bool async_probe_requested;


 unsigned int num_exentries;
 struct exception_table_entry *extable;


 int (*init)(void);

 struct module_memory mem[MOD_MEM_NUM_TYPES] ;


 struct mod_arch_specific arch;

 unsigned long taints;



 unsigned num_bugs;
 struct list_head bug_list;
 struct bug_entry *bug_table;




 struct mod_kallsyms *kallsyms;
 struct mod_kallsyms core_kallsyms;


 struct module_sect_attrs *sect_attrs;


 struct module_notes_attrs *notes_attrs;




 char *args;



 void *percpu;
 unsigned int percpu_size;

 void *noinstr_text_start;
 unsigned int noinstr_text_size;


 unsigned int num_tracepoints;
 tracepoint_ptr_t *tracepoints_ptrs;


 unsigned int num_srcu_structs;
 struct srcu_struct **srcu_struct_ptrs;


 unsigned int num_bpf_raw_events;
 struct bpf_raw_event_map *bpf_raw_events;
 struct jump_entry *jump_entries;
 unsigned int num_jump_entries;


 unsigned int num_trace_bprintk_fmt;
 const char **trace_bprintk_fmt_start;


 struct trace_event_call **trace_events;
 unsigned int num_trace_events;
 struct trace_eval_map **trace_evals;
 unsigned int num_trace_evals;


 unsigned int num_ftrace_callsites;
 unsigned long *ftrace_callsites;


 void *kprobes_text_start;
 unsigned int kprobes_text_size;
 unsigned long *kprobe_blacklist;
 unsigned int num_kprobe_blacklist;


 int num_static_call_sites;
 struct static_call_site *static_call_sites;


 int num_kunit_init_suites;
 struct kunit_suite **kunit_init_suites;
 int num_kunit_suites;
 struct kunit_suite **kunit_suites;
 unsigned int printk_index_size;
 struct pi_entry **printk_index_start;




 struct list_head source_list;

 struct list_head target_list;


 void (*exit)(void);

 atomic_t refcnt;
 struct error_injection_entry *ei_funcs;
 unsigned int num_ei_funcs;


 struct _ddebug_info dyndbg_info;

}  ;
enum probe_type {
 PROBE_DEFAULT_STRATEGY,
 PROBE_PREFER_ASYNCHRONOUS,
 PROBE_FORCE_SYNCHRONOUS,
};
struct device_driver {
 const char *name;
 const struct bus_type *bus;

 struct module *owner;
 const char *mod_name;

 bool suppress_bind_attrs;
 enum probe_type probe_type;

 const struct of_device_id *of_match_table;
 const struct acpi_device_id *acpi_match_table;

 int (*probe) (struct device *dev);
 void (*sync_state)(struct device *dev);
 int (*remove) (struct device *dev);
 void (*shutdown) (struct device *dev);
 int (*suspend) (struct device *dev, pm_message_t state);
 int (*resume) (struct device *dev);
 const struct attribute_group **groups;
 const struct attribute_group **dev_groups;

 const struct dev_pm_ops *pm;
 void (*coredump) (struct device *dev);

 struct driver_private *p;
};
struct dev_archdata {
};
struct device;
struct device_private;
struct device_driver;
struct driver_private;
struct module;
struct class;
struct device_node;
struct fwnode_handle;
struct iommu_group;
struct dev_pin_info;
struct dev_iommu;
struct msi_device_data;
struct device_type {
 const char *name;
 const struct attribute_group **groups;
 int (*uevent)(const struct device *dev, struct kobj_uevent_env *env);
 char *(*devnode)(const struct device *dev, umode_t *mode,
    kuid_t *uid, kgid_t *gid);
 void (*release)(struct device *dev);

 const struct dev_pm_ops *pm;
};
struct device_dma_parameters {




 unsigned int max_segment_size;
 unsigned int min_align_mask;
 unsigned long segment_boundary_mask;
};
enum dl_dev_state {
 DL_DEV_NO_DRIVER = 0,
 DL_DEV_PROBING,
 DL_DEV_DRIVER_BOUND,
 DL_DEV_UNBINDING,
};
enum device_removable {
 DEVICE_REMOVABLE_NOT_SUPPORTED = 0,
 DEVICE_REMOVABLE_UNKNOWN,
 DEVICE_FIXED,
 DEVICE_REMOVABLE,
};
struct dev_links_info {
 struct list_head suppliers;
 struct list_head consumers;
 struct list_head defer_sync;
 enum dl_dev_state status;
};
struct dev_msi_info {

 struct irq_domain *domain;
 struct msi_device_data *data;

};
enum device_physical_location_panel {
 DEVICE_PANEL_TOP,
 DEVICE_PANEL_BOTTOM,
 DEVICE_PANEL_LEFT,
 DEVICE_PANEL_RIGHT,
 DEVICE_PANEL_FRONT,
 DEVICE_PANEL_BACK,
 DEVICE_PANEL_UNKNOWN,
};
enum device_physical_location_vertical_position {
 DEVICE_VERT_POS_UPPER,
 DEVICE_VERT_POS_CENTER,
 DEVICE_VERT_POS_LOWER,
};
enum device_physical_location_horizontal_position {
 DEVICE_HORI_POS_LEFT,
 DEVICE_HORI_POS_CENTER,
 DEVICE_HORI_POS_RIGHT,
};
struct device_physical_location {
 enum device_physical_location_panel panel;
 enum device_physical_location_vertical_position vertical_position;
 enum device_physical_location_horizontal_position horizontal_position;
 bool dock;
 bool lid;
};
enum struct_device_flags {
 DEV_FLAG_READY_TO_PROBE = 0,
 DEV_FLAG_CAN_MATCH = 1,

 DEV_FLAG_COUNT
};
struct device {
 struct kobject kobj;
 struct device *parent;

 struct device_private *p;

 const char *init_name;
 const struct device_type *type;

 const struct bus_type *bus;
 struct device_driver *driver;

 void *platform_data;

 void *driver_data;

 struct {
  const char *name;
  spinlock_t lock;
 } driver_override;
 struct mutex mutex;



 struct dev_links_info links;
 struct dev_pm_info power;
 struct dev_pm_domain *pm_domain;


 struct em_perf_domain *em_pd;



 struct dev_pin_info *pins;

 struct dev_msi_info msi;

 const struct dma_map_ops *dma_ops;

 u64 *dma_mask;
 u64 coherent_dma_mask;




 u64 bus_dma_limit;
 const struct bus_dma_region *dma_range_map;

 struct device_dma_parameters *dma_parms;

 struct list_head dma_pools;


 struct dma_coherent_mem *dma_mem;



 struct cma *cma_area;



 struct io_tlb_mem *dma_io_tlb_mem;


 struct list_head dma_io_tlb_pools;
 spinlock_t dma_io_tlb_lock;
 bool dma_uses_io_tlb;


 struct dev_archdata archdata;

 struct device_node *of_node;
 struct fwnode_handle *fwnode;


 int numa_node;

 dev_t devt;
 u32 id;

 spinlock_t devres_lock;
 struct list_head devres_head;

 const struct class *class;
 const struct attribute_group **groups;

 void (*release)(struct device *dev);
 struct iommu_group *iommu_group;
 struct dev_iommu *iommu;

 struct device_physical_location *physical_location;

 enum device_removable removable;

 bool offline_disabled:1;
 bool offline:1;
 bool of_node_reused:1;
 bool state_synced:1;
 bool dma_skip_sync:1;


 bool dma_iommu:1;


 unsigned long flags[(((DEV_FLAG_COUNT) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
struct wake_irq;
struct wakeup_source {
 const char *name;
 int id;
 struct list_head entry;
 spinlock_t lock;
 struct wake_irq *wakeirq;
 struct timer_list timer;
 unsigned long timer_expires;
 ktime_t total_time;
 ktime_t max_time;
 ktime_t last_time;
 ktime_t start_prevent_time;
 ktime_t prevent_sleep_time;
 unsigned long event_count;
 unsigned long active_count;
 unsigned long relax_count;
 unsigned long expire_count;
 unsigned long wakeup_count;
 struct device *dev;
 bool active:1;
 bool autosleep_enabled:1;
};
static inline    const char *dev_name(const struct device *dev)
;
struct dma_fence;
struct dma_fence_ops;
struct dma_fence_cb;
struct seq_file;
struct dma_fence {
 spinlock_t *lock;
 const struct dma_fence_ops *ops;
 union {
  struct list_head cb_list;

  ktime_t timestamp;

  struct callback_head rcu;
 };
 u64 context;
 u64 seqno;
 unsigned long flags;
 struct kref refcount;
 int error;
};
typedef void (*dma_fence_func_t)(struct dma_fence *fence,
     struct dma_fence_cb *cb);
struct dma_fence_cb {
 struct list_head node;
 dma_fence_func_t func;
};
struct dma_fence_ops {
 const char * (*get_driver_name)(struct dma_fence *fence);
 const char * (*get_timeline_name)(struct dma_fence *fence);
 bool (*enable_signaling)(struct dma_fence *fence);
 bool (*signaled)(struct dma_fence *fence);
 signed long (*wait)(struct dma_fence *fence,
       bool intr, signed long timeout);
 void (*release)(struct dma_fence *fence);
 void (*set_deadline)(struct dma_fence *fence, ktime_t deadline);
};
struct device;
struct dma_buf;
struct dma_buf_attachment;
struct dma_buf_ops {
 int (*attach)(struct dma_buf *, struct dma_buf_attachment *);
 void (*detach)(struct dma_buf *, struct dma_buf_attachment *);
 int (*pin)(struct dma_buf_attachment *attach);
 void (*unpin)(struct dma_buf_attachment *attach);
 struct sg_table * (*map_dma_buf)(struct dma_buf_attachment *,
      enum dma_data_direction);
 void (*unmap_dma_buf)(struct dma_buf_attachment *,
         struct sg_table *,
         enum dma_data_direction);
 void (*release)(struct dma_buf *);
 int (*begin_cpu_access)(struct dma_buf *, enum dma_data_direction);
 int (*end_cpu_access)(struct dma_buf *, enum dma_data_direction);
 int (*mmap)(struct dma_buf *, struct vm_area_struct *vma);

 int (*vmap)(struct dma_buf *dmabuf, struct iosys_map *map);
 void (*vunmap)(struct dma_buf *dmabuf, struct iosys_map *map);
};
struct dma_buf {





 size_t size;







 struct file *file;







 struct list_head attachments;


 const struct dma_buf_ops *ops;







 unsigned vmapping_counter;





 struct iosys_map vmap_ptr;






 const char *exp_name;
 const char *name;


 spinlock_t name_lock;







 struct module *owner;


 struct list_head list_node;


 void *priv;
 struct dma_resv *resv;


 wait_queue_head_t poll;



 struct dma_buf_poll_cb_t {
  struct dma_fence_cb cb;
  wait_queue_head_t *poll;

  __poll_t active;
 } cb_in, cb_out;







 struct dma_buf_sysfs_entry {
  struct kobject kobj;
  struct dma_buf *dmabuf;
 } *sysfs_entry;

};
struct dma_buf_attach_ops {






 bool allow_peer2peer;
 void (*move_notify)(struct dma_buf_attachment *attach);
};
struct dma_buf_attachment {
 struct dma_buf *dmabuf;
 struct device *dev;
 struct list_head node;
 bool peer2peer;
 const struct dma_buf_attach_ops *importer_ops;
 void *importer_priv;
 void *priv;
};
struct rt_mutex_waiter;
struct ww_class {
 atomic_long_t stamp;
 struct lock_class_key acquire_key;
 struct lock_class_key mutex_key;
 const char *acquire_name;
 const char *mutex_name;
 unsigned int is_wait_die;
};
struct ww_mutex {
 struct mutex base;
 struct ww_acquire_ctx *ctx;

 struct ww_class *ww_class;

};
struct ww_acquire_ctx {
 struct task_struct *task;
 unsigned long stamp;
 unsigned int acquired;
 unsigned short wounded;
 unsigned short is_wait_die;

 unsigned int done_acquire;
 struct ww_class *ww_class;
 void *contending_lock;


 struct lockdep_map dep_map;
 struct lockdep_map first_lock_dep_map;


 unsigned int deadlock_inject_interval;
 unsigned int deadlock_inject_countdown;

};
struct dma_resv_list;
struct dma_resv {
 struct ww_mutex lock;
 struct dma_resv_list *fences;
};
typedef u32 depot_stack_handle_t;
struct drm_modeset_lock;
struct drm_modeset_acquire_ctx {

 struct ww_acquire_ctx ww_ctx;






 struct drm_modeset_lock *contended;





 depot_stack_handle_t stack_depot;




 struct list_head locked;




 bool trylock_only;


 bool interruptible;
};
struct drm_modeset_lock {



 struct ww_mutex mutex;





 struct list_head head;
};
int drm_modeset_lock(struct drm_modeset_lock *lock,
  struct drm_modeset_acquire_ctx *ctx);
struct drm_device;
struct drm_file;
struct drm_device;
struct drm_atomic_state;
struct drm_mode_fb_cmd2;
struct drm_format_info;
struct drm_display_mode;
struct drm_mode_config_funcs {
 struct drm_framebuffer *(*fb_create)(struct drm_device *dev,
          struct drm_file *file_priv,
          const struct drm_format_info *info,
          const struct drm_mode_fb_cmd2 *mode_cmd);
 const struct drm_format_info *(*get_format_info)(u32 pixel_format, u64 modifier);
 enum drm_mode_status (*mode_valid)(struct drm_device *dev,
        const struct drm_display_mode *mode);
 int (*atomic_check)(struct drm_device *dev,
       struct drm_atomic_state *state);
 int (*atomic_commit)(struct drm_device *dev,
        struct drm_atomic_state *state,
        bool nonblock);
 struct drm_atomic_state *(*atomic_state_alloc)(struct drm_device *dev);
 void (*atomic_state_clear)(struct drm_atomic_state *state);
 void (*atomic_state_free)(struct drm_atomic_state *state);
};
struct drm_mode_config {
 struct mutex mutex;
 struct drm_modeset_lock connection_mutex;
 struct drm_modeset_acquire_ctx *acquire_ctx;







 struct mutex idr_mutex;







 struct idr object_idr;







 struct idr tile_idr;


 struct mutex fb_lock;

 int num_fb;

 struct list_head fb_list;





 spinlock_t connector_list_lock;




 int num_connector;



 struct ida connector_ida;







 struct list_head connector_list;
 struct llist_head connector_free_list;



 struct work_struct connector_free_work;







 int num_encoder;







 struct list_head encoder_list;
 int num_total_plane;






 struct list_head plane_list;
 struct raw_spinlock panic_lock;







 int num_crtc;






 struct list_head crtc_list;
 struct list_head property_list;
 struct list_head privobj_list;

 unsigned int min_width, min_height;
 unsigned int max_width, max_height;
 const struct drm_mode_config_funcs *funcs;


 bool poll_enabled;
 bool poll_running;
 bool delayed_event;
 struct delayed_work output_poll_work;







 struct mutex blob_lock;







 struct list_head property_blob_list;







 struct drm_property *edid_property;




 struct drm_property *dpms_property;




 struct drm_property *path_property;





 struct drm_property *tile_property;




 struct drm_property *link_status_property;




 struct drm_property *plane_type_property;




 struct drm_property *prop_src_x;




 struct drm_property *prop_src_y;




 struct drm_property *prop_src_w;




 struct drm_property *prop_src_h;




 struct drm_property *prop_crtc_x;




 struct drm_property *prop_crtc_y;




 struct drm_property *prop_crtc_w;




 struct drm_property *prop_crtc_h;




 struct drm_property *prop_fb_id;




 struct drm_property *prop_in_fence_fd;





 struct drm_property *prop_out_fence_ptr;




 struct drm_property *prop_crtc_id;
 struct drm_property *prop_fb_damage_clips;





 struct drm_property *prop_active;





 struct drm_property *prop_mode_id;




 struct drm_property *prop_vrr_enabled;





 struct drm_property *dvi_i_subconnector_property;




 struct drm_property *dvi_i_select_subconnector_property;





 struct drm_property *dp_subconnector_property;





 struct drm_property *tv_subconnector_property;




 struct drm_property *tv_select_subconnector_property;







 struct drm_property *legacy_tv_mode_property;





 struct drm_property *tv_mode_property;





 struct drm_property *tv_left_margin_property;




 struct drm_property *tv_right_margin_property;




 struct drm_property *tv_top_margin_property;




 struct drm_property *tv_bottom_margin_property;




 struct drm_property *tv_brightness_property;




 struct drm_property *tv_contrast_property;




 struct drm_property *tv_flicker_reduction_property;




 struct drm_property *tv_overscan_property;




 struct drm_property *tv_saturation_property;



 struct drm_property *tv_hue_property;





 struct drm_property *scaling_mode_property;




 struct drm_property *aspect_ratio_property;




 struct drm_property *content_type_property;




 struct drm_property *degamma_lut_property;




 struct drm_property *degamma_lut_size_property;





 struct drm_property *ctm_property;





 struct drm_property *gamma_lut_property;




 struct drm_property *gamma_lut_size_property;





 struct drm_property *suggested_x_property;




 struct drm_property *suggested_y_property;






 struct drm_property *non_desktop_property;






 struct drm_property *panel_orientation_property;






 struct drm_property *writeback_fb_id_property;







 struct drm_property *writeback_pixel_formats_property;







 struct drm_property *writeback_out_fence_ptr_property;






 struct drm_property *hdr_output_metadata_property;





 struct drm_property *content_protection_property;





 struct drm_property *hdcp_content_type_property;


 uint32_t preferred_depth, prefer_shadow;







 bool quirk_addfb_prefer_xbgr_30bpp;
 bool quirk_addfb_prefer_host_byte_order;





 bool async_page_flip;
 bool fb_modifiers_not_supported;







 bool normalize_zpos;





 struct drm_property *modifiers_property;





 struct drm_property *async_modifiers_property;




 struct drm_property *size_hints_property;


 uint32_t cursor_width, cursor_height;
 struct drm_atomic_state *suspend_state;

 const struct drm_mode_config_helper_funcs *helper_private;
};
struct drm_driver;
struct drm_minor;
struct drm_master;
struct drm_vblank_crtc;
struct drm_vma_offset_manager;
struct drm_vram_mm;
struct drm_fb_helper;
struct inode;
enum switch_power_state {

 DRM_SWITCH_POWER_ON = 0,


 DRM_SWITCH_POWER_OFF = 1,


 DRM_SWITCH_POWER_CHANGING = 2,


 DRM_SWITCH_POWER_DYNAMIC_OFF = 3,
};
struct drm_device {

 int if_version;


 struct kref ref;


 struct device *dev;
 struct device *dma_dev;







 struct {

  struct list_head resources;

  void *final_kfree;

  spinlock_t lock;
 } managed;


 const struct drm_driver *driver;
 void *dev_private;
 struct drm_minor *primary;
 struct drm_minor *render;


 struct drm_minor *accel;






 bool registered;







 struct drm_master *master;
 u32 driver_features;







 bool unplugged;


 struct inode *anon_inode;


 char *unique;






 struct mutex master_mutex;







 atomic_t open_count;


 struct mutex filelist_mutex;





 struct list_head filelist;







 struct list_head filelist_internal;






 struct mutex clientlist_mutex;






 struct list_head clientlist;
 bool vblank_disable_immediate;
 struct drm_vblank_crtc *vblank;






 spinlock_t vblank_time_lock;




 spinlock_t vbl_lock;
 u32 max_vblank_count;


 struct list_head vblank_event_list;







 spinlock_t event_lock;


 unsigned int num_crtcs;


 struct drm_mode_config mode_config;


 struct mutex object_name_lock;


 struct idr object_name_idr;


 struct drm_vma_offset_manager *vma_offset_manager;


 struct drm_vram_mm *vram_mm;
 enum switch_power_state switch_power_state;







 struct drm_fb_helper *fb_helper;






 struct dentry *debugfs_root;
};
struct drm_device;
struct seq_file;
enum drm_debug_category {





 DRM_UT_CORE,




 DRM_UT_DRIVER,



 DRM_UT_KMS,



 DRM_UT_PRIME,



 DRM_UT_ATOMIC,



 DRM_UT_VBL,



 DRM_UT_STATE,



 DRM_UT_LEASE,



 DRM_UT_DP,



 DRM_UT_DRMRES
};
struct drm_printer {

 void (*printfn)(struct drm_printer *p, struct va_format *vaf);
 void (*puts)(struct drm_printer *p, const char *str);
 void *arg;
 const void *origin;
 const char *prefix;
 struct {
  unsigned int series;
  unsigned int counter;
 } line;
 enum drm_debug_category category;
};
struct _ddebug;

void __drm_dev_dbg(struct _ddebug *desc, const struct device *dev,
     enum drm_debug_category category, const char *format, ...);
static inline    struct device *__drm_to_dev(const struct drm_device *drm)
;
struct drm_mm_node {

 unsigned long color;

 u64 start;

 u64 size;

 struct drm_mm *mm;
 struct list_head node_list;
 struct list_head hole_stack;
 struct rb_node rb;
 struct rb_node rb_hole_size;
 struct rb_node rb_hole_addr;
 u64 __subtree_last;
 u64 hole_size;
 u64 subtree_max_hole;
 unsigned long flags;

 depot_stack_handle_t stack;

};
struct drm_mm {
 void (*color_adjust)(const struct drm_mm_node *node,
        unsigned long color,
        u64 *start, u64 *end);



 struct list_head hole_stack;


 struct drm_mm_node head_node;

 struct rb_root_cached interval_tree;
 struct rb_root_cached holes_size;
 struct rb_root holes_addr;

 unsigned long scan_active;
};
struct drm_file;
struct drm_vma_offset_node {
 rwlock_t vm_lock;
 struct drm_mm_node vm_node;
 struct rb_root vm_files;
 void *driver_private;
};
struct drm_vma_offset_manager {
 rwlock_t vm_lock;
 struct drm_mm vm_addr_space_mm;
};
struct iosys_map;
struct drm_gem_object;
enum drm_gem_object_status {
 DRM_GEM_OBJECT_RESIDENT = ((((1UL))) << (0)),
 DRM_GEM_OBJECT_PURGEABLE = ((((1UL))) << (1)),
 DRM_GEM_OBJECT_ACTIVE = ((((1UL))) << (2)),
};
struct drm_gem_object_funcs {







 void (*free)(struct drm_gem_object *obj);
 int (*open)(struct drm_gem_object *obj, struct drm_file *file);
 void (*close)(struct drm_gem_object *obj, struct drm_file *file);
 void (*print_info)(struct drm_printer *p, unsigned int indent,
      const struct drm_gem_object *obj);
 struct dma_buf *(*export)(struct drm_gem_object *obj, int flags);
 int (*pin)(struct drm_gem_object *obj);
 void (*unpin)(struct drm_gem_object *obj);
 struct sg_table *(*get_sg_table)(struct drm_gem_object *obj);
 int (*vmap)(struct drm_gem_object *obj, struct iosys_map *map);
 void (*vunmap)(struct drm_gem_object *obj, struct iosys_map *map);
 int (*mmap)(struct drm_gem_object *obj, struct vm_area_struct *vma);
 int (*evict)(struct drm_gem_object *obj);
 enum drm_gem_object_status (*status)(struct drm_gem_object *obj);
 size_t (*rss)(struct drm_gem_object *obj);
 const struct vm_operations_struct *vm_ops;
};
struct drm_gem_lru {







 struct mutex *lock;







 long count;






 struct list_head list;
};
struct drm_gem_object {
 struct kref refcount;
 unsigned handle_count;




 struct drm_device *dev;
 struct file *filp;
 struct drm_vma_offset_node vma_node;







 size_t size;
 int name;
 struct dma_buf *dma_buf;
 struct dma_buf_attachment *import_attach;
 struct dma_resv *resv;
 struct dma_resv _resv;
 struct {







  struct list_head list;
  struct mutex lock;
 } gpuva;
 const struct drm_gem_object_funcs *funcs;






 struct list_head lru_node;






 struct drm_gem_lru *lru;
};
struct ttm_device;
struct ttm_resource_manager;
struct ttm_resource;
struct ttm_place;
struct ttm_buffer_object;
struct ttm_placement;
struct iosys_map;
struct sg_table;
struct scatterlist;
enum ttm_lru_item_type {

 TTM_LRU_RESOURCE,

 TTM_LRU_HITCH
};
struct ttm_lru_item {
 struct list_head link;
 enum ttm_lru_item_type type;
};
struct ttm_resource_manager_func {
 int (*alloc)(struct ttm_resource_manager *man,
        struct ttm_buffer_object *bo,
        const struct ttm_place *place,
        struct ttm_resource **res);
 void (*free)(struct ttm_resource_manager *man,
       struct ttm_resource *res);
 bool (*intersects)(struct ttm_resource_manager *man,
      struct ttm_resource *res,
      const struct ttm_place *place,
      size_t size);
 bool (*compatible)(struct ttm_resource_manager *man,
      struct ttm_resource *res,
      const struct ttm_place *place,
      size_t size);
 void (*debug)(struct ttm_resource_manager *man,
        struct drm_printer *printer);
};
struct ttm_resource_manager {



 bool use_type;
 bool use_tt;
 struct ttm_device *bdev;
 uint64_t size;
 const struct ttm_resource_manager_func *func;
 spinlock_t move_lock;




 struct dma_fence *move;




 struct list_head lru[4U];





 uint64_t usage;




 struct dmem_cgroup_region *cg;
};
struct ttm_bus_placement {
 void *addr;
 phys_addr_t offset;
 bool is_iomem;
 enum ttm_caching caching;
};
struct ttm_resource {
 unsigned long start;
 size_t size;
 uint32_t mem_type;
 uint32_t placement;
 struct ttm_bus_placement bus;
 struct ttm_buffer_object *bo;

 struct dmem_cgroup_pool_state *css;




 struct ttm_lru_item lru;
};
struct ttm_lru_bulk_move_pos {
 struct ttm_resource *first;
 struct ttm_resource *last;
};
struct ttm_lru_bulk_move {
 struct ttm_lru_bulk_move_pos pos[9][4U];
 struct list_head cursor_list;
};
struct device;
struct seq_file;
struct ttm_operation_ctx;
struct ttm_pool;
struct ttm_tt;
struct ttm_pool_type {
 struct ttm_pool *pool;
 unsigned int order;
 enum ttm_caching caching;

 struct list_head shrinker_list;

 spinlock_t lock;
 struct list_head pages;
};
struct ttm_pool {
 struct device *dev;
 int nid;

 bool use_dma_alloc;
 bool use_dma32;

 struct {
  struct ttm_pool_type orders[(10 + 1)];
 } caching[3];
};
struct ttm_device;
struct ttm_placement;
struct ttm_buffer_object;
struct ttm_operation_ctx;
struct ttm_device_funcs {
 struct ttm_tt *(*ttm_tt_create)(struct ttm_buffer_object *bo,
     uint32_t page_flags);
 int (*ttm_tt_populate)(struct ttm_device *bdev,
          struct ttm_tt *ttm,
          struct ttm_operation_ctx *ctx);
 void (*ttm_tt_unpopulate)(struct ttm_device *bdev,
      struct ttm_tt *ttm);
 void (*ttm_tt_destroy)(struct ttm_device *bdev, struct ttm_tt *ttm);
 bool (*eviction_valuable)(struct ttm_buffer_object *bo,
      const struct ttm_place *place);
 void (*evict_flags)(struct ttm_buffer_object *bo,
       struct ttm_placement *placement);
 int (*move)(struct ttm_buffer_object *bo, bool evict,
      struct ttm_operation_ctx *ctx,
      struct ttm_resource *new_mem,
      struct ttm_place *hop);




 void (*delete_mem_notify)(struct ttm_buffer_object *bo);




 void (*swap_notify)(struct ttm_buffer_object *bo);







 int (*io_mem_reserve)(struct ttm_device *bdev,
         struct ttm_resource *mem);
 void (*io_mem_free)(struct ttm_device *bdev,
       struct ttm_resource *mem);







 unsigned long (*io_mem_pfn)(struct ttm_buffer_object *bo,
        unsigned long page_offset);
 int (*access_memory)(struct ttm_buffer_object *bo, unsigned long offset,
        void *buf, int len, int write);
 void (*release_notify)(struct ttm_buffer_object *bo);
};
struct ttm_device {




 struct list_head device_list;





 const struct ttm_device_funcs *funcs;





 struct ttm_resource_manager sysman;




 struct ttm_resource_manager *man_drv[9];




 struct drm_vma_offset_manager *vma_manager;




 struct ttm_pool pool;




 spinlock_t lru_lock;





 struct list_head unevictable;





 struct address_space *dev_mapping;




 struct workqueue_struct *wq;
};
struct iosys_map;
struct ttm_device;
struct ttm_placement;
struct ttm_place;
struct ttm_resource;
struct ttm_resource_manager;
struct ttm_tt;
enum ttm_bo_type {
 ttm_bo_type_device,
 ttm_bo_type_kernel,
 ttm_bo_type_sg
};
struct ttm_buffer_object {
 struct drm_gem_object base;




 struct ttm_device *bdev;
 enum ttm_bo_type type;
 uint32_t page_alignment;
 void (*destroy) (struct ttm_buffer_object *);




 struct kref kref;




 struct ttm_resource *resource;
 struct ttm_tt *ttm;
 bool deleted;
 struct ttm_lru_bulk_move *bulk_move;
 unsigned priority;
 unsigned pin_count;





 struct work_struct delayed_delete;





 struct sg_table *sg;
};
struct ttm_bo_kmap_obj {
 void *virtual;
 struct page *page;
 enum {
  ttm_bo_map_iomap = 1 | 0x80,
  ttm_bo_map_vmap = 2,
  ttm_bo_map_kmap = 3,
  ttm_bo_map_premapped = 4 | 0x80,
 } bo_kmap_type;
 struct ttm_buffer_object *bo;
};
struct ttm_operation_ctx {
 bool interruptible;
 bool no_wait_gpu;
 bool gfp_retry_mayfail;
 bool allow_res_evict;
 struct dma_resv *resv;
 uint64_t bytes_moved;
};
struct ttm_place {
 unsigned fpfn;
 unsigned lpfn;
 uint32_t mem_type;
 uint32_t flags;
};
struct ttm_placement {
 unsigned num_placement;
 const struct ttm_place *placement;
};
typedef unsigned long kernel_ulong_t;
struct acpi_device_id {
 __u8 id[16];
 kernel_ulong_t driver_data;
 __u32 cls;
 __u32 cls_msk;
};
struct of_device_id {
 char name[32];
 char type[32];
 char compatible[128];
 const void *data;
};
extern char _data[], _sdata[], _edata[];
struct device;
enum
{
 HI_SOFTIRQ=0,
 TIMER_SOFTIRQ,
 NET_TX_SOFTIRQ,
 NET_RX_SOFTIRQ,
 BLOCK_SOFTIRQ,
 IRQ_POLL_SOFTIRQ,
 TASKLET_SOFTIRQ,
 SCHED_SOFTIRQ,
 HRTIMER_SOFTIRQ,
 RCU_SOFTIRQ,

 NR_SOFTIRQS
};
struct seq_file;
struct device;
struct module;
struct device;
struct device_node;
struct irq_domain;
struct dma_fence;
struct drm_file;
struct drm_device;
struct drm_printer;
struct device;
struct file;
struct drm_minor {

 int index;
 int type;
 struct device *kdev;
 struct drm_device *dev;

 struct dentry *debugfs_symlink;
 struct dentry *debugfs_root;
};
struct drm_file {
 bool authenticated;






 bool stereo_allowed;







 bool universal_planes;


 bool atomic;







 bool aspect_ratio_allowed;






 bool writeback_connectors;
 bool was_master;
 bool is_master;
 bool supports_virtualized_cursor_plane;
 struct drm_master *master;


 spinlock_t master_lookup_lock;
 struct pid *pid;


 u64 client_id;


 drm_magic_t magic;







 struct list_head lhead;


 struct drm_minor *minor;
 struct idr object_idr;


 spinlock_t table_lock;


 struct idr syncobj_idr;

 spinlock_t syncobj_table_lock;


 struct file *filp;







 void *driver_priv;
 struct list_head fbs;


 struct mutex fbs_lock;
 struct list_head blobs;


 wait_queue_head_t event_wait;
 struct list_head pending_event_list;
 struct list_head event_list;
 int event_space;


 struct mutex event_read_lock;






 struct drm_prime_file_private prime;






 const char *client_name;




 struct mutex client_name_lock;






 struct dentry *debugfs_client;
};
enum drm_gem_object_status;
struct xe_reg {
 union {
  struct {

   u32 addr: 22 ;





   u32 masked:1;
   u32 mcr:1;



   u32 vf:1;
  };

  u32 raw;
 };
};
enum xe_force_wake_domain_id {
 XE_FW_DOMAIN_ID_GT = 0,
 XE_FW_DOMAIN_ID_RENDER,
 XE_FW_DOMAIN_ID_MEDIA,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX0,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX1,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX2,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX3,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX4,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX5,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX6,
 XE_FW_DOMAIN_ID_MEDIA_VDBOX7,
 XE_FW_DOMAIN_ID_MEDIA_VEBOX0,
 XE_FW_DOMAIN_ID_MEDIA_VEBOX1,
 XE_FW_DOMAIN_ID_MEDIA_VEBOX2,
 XE_FW_DOMAIN_ID_MEDIA_VEBOX3,
 XE_FW_DOMAIN_ID_GSC,
 XE_FW_DOMAIN_ID_COUNT
};
enum xe_force_wake_domains {
 XE_FW_GT = ((((1UL))) << (XE_FW_DOMAIN_ID_GT)),
 XE_FW_RENDER = ((((1UL))) << (XE_FW_DOMAIN_ID_RENDER)),
 XE_FW_MEDIA = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA)),
 XE_FW_MEDIA_VDBOX0 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX0)),
 XE_FW_MEDIA_VDBOX1 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX1)),
 XE_FW_MEDIA_VDBOX2 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX2)),
 XE_FW_MEDIA_VDBOX3 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX3)),
 XE_FW_MEDIA_VDBOX4 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX4)),
 XE_FW_MEDIA_VDBOX5 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX5)),
 XE_FW_MEDIA_VDBOX6 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX6)),
 XE_FW_MEDIA_VDBOX7 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VDBOX7)),
 XE_FW_MEDIA_VEBOX0 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VEBOX0)),
 XE_FW_MEDIA_VEBOX1 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VEBOX1)),
 XE_FW_MEDIA_VEBOX2 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VEBOX2)),
 XE_FW_MEDIA_VEBOX3 = ((((1UL))) << (XE_FW_DOMAIN_ID_MEDIA_VEBOX3)),
 XE_FW_GSC = ((((1UL))) << (XE_FW_DOMAIN_ID_GSC)),
 XE_FORCEWAKE_ALL = ((((1UL))) << (XE_FW_DOMAIN_ID_COUNT))
};
struct xe_force_wake_domain {

 enum xe_force_wake_domain_id id;

 struct xe_reg reg_ctl;

 struct xe_reg reg_ack;

 u32 val;

 u32 mask;

 u32 ref;
};
struct xe_force_wake {

 struct xe_gt *gt;

 spinlock_t lock;

 unsigned int awake_domains;

 unsigned int initialized_domains;

 struct xe_force_wake_domain domains[XE_FW_DOMAIN_ID_COUNT];
};
struct irq_work {
 struct __call_single_node node;
 void (*func)(struct irq_work *);
 struct rcuwait irqwait;
};
struct xe_device;
struct xe_gt;
struct xe_hw_fence_irq {

 spinlock_t lock;

 struct irq_work work;

 struct list_head pending;

 bool enabled;
};
struct xe_bo;
struct xe_reg_sr {
 struct xarray xa;
 const char *name;


 unsigned int errors;

};
enum xe_engine_class {
 XE_ENGINE_CLASS_RENDER = 0,
 XE_ENGINE_CLASS_VIDEO_DECODE = 1,
 XE_ENGINE_CLASS_VIDEO_ENHANCE = 2,
 XE_ENGINE_CLASS_COPY = 3,
 XE_ENGINE_CLASS_OTHER = 4,
 XE_ENGINE_CLASS_COMPUTE = 5,
 XE_ENGINE_CLASS_MAX = 6,
};
enum xe_hw_engine_id {
 XE_HW_ENGINE_RCS0,
 XE_HW_ENGINE_BCS0,
 XE_HW_ENGINE_BCS1,
 XE_HW_ENGINE_BCS2,
 XE_HW_ENGINE_BCS3,
 XE_HW_ENGINE_BCS4,
 XE_HW_ENGINE_BCS5,
 XE_HW_ENGINE_BCS6,
 XE_HW_ENGINE_BCS7,
 XE_HW_ENGINE_BCS8,
 XE_HW_ENGINE_VCS0,
 XE_HW_ENGINE_VCS1,
 XE_HW_ENGINE_VCS2,
 XE_HW_ENGINE_VCS3,
 XE_HW_ENGINE_VCS4,
 XE_HW_ENGINE_VCS5,
 XE_HW_ENGINE_VCS6,
 XE_HW_ENGINE_VCS7,
 XE_HW_ENGINE_VECS0,
 XE_HW_ENGINE_VECS1,
 XE_HW_ENGINE_VECS2,
 XE_HW_ENGINE_VECS3,
 XE_HW_ENGINE_CCS0,
 XE_HW_ENGINE_CCS1,
 XE_HW_ENGINE_CCS2,
 XE_HW_ENGINE_CCS3,
 XE_HW_ENGINE_GSCCS0,
 XE_NUM_HW_ENGINES,
};
struct xe_bo;
struct xe_execlist_port;
struct xe_gt;
struct xe_hw_engine_class_intf {




 struct {

  u32 job_timeout_ms;

  u32 job_timeout_min;

  u32 job_timeout_max;

  u32 timeslice_us;

  u32 timeslice_min;

  u32 timeslice_max;

  u32 preempt_timeout_us;

  u32 preempt_timeout_min;

  u32 preempt_timeout_max;
 } sched_props, defaults;
};
struct xe_hw_engine {

 struct xe_gt *gt;

 const char *name;

 enum xe_engine_class class;

 u16 instance;

 u16 logical_instance;

 u16 irq_offset;

 u32 mmio_base;



 struct xe_reg_sr reg_sr;



 struct xe_reg_sr reg_whitelist;



 struct xe_reg_sr oa_whitelist;



 struct xe_reg_sr oa_sr;



 struct xe_reg_sr reg_lrc;

 enum xe_force_wake_domains domain;

 struct xe_bo *hwsp;

 struct xe_execlist_port *exl_port;

 struct xe_hw_fence_irq *fence_irq;

 void (*irq_handler)(struct xe_hw_engine *hwe, u16 intr_vec);

 enum xe_hw_engine_id engine_id;

 struct xe_hw_engine_class_intf *eclass;

 struct xe_oa_unit *oa_unit;

 struct xe_hw_engine_group *hw_engine_group;
};
struct xe_hw_engine_snapshot {

 char *name;

 struct xe_hw_engine *hwe;

 u16 logical_instance;

 struct {

  enum xe_force_wake_domains domain;

  int ref;
 } forcewake;

 u32 mmio_base;

 bool kernel_reserved;
};
struct xe_device;
struct xe_gt;
struct xe_devcoredump_snapshot {

 ktime_t snapshot_time;

 ktime_t boot_time;

 char process_name[TASK_COMM_LEN];

 pid_t pid;

 char *reason;


 struct xe_gt *gt;

 struct work_struct work;


 struct {

  struct xe_guc_ct_snapshot *ct;

  struct xe_guc_log_snapshot *log;
 } guc;


 struct xe_guc_submit_exec_queue_snapshot *ge;


 struct xe_hw_engine_snapshot *hwe[XE_NUM_HW_ENGINES];

 struct xe_sched_job_snapshot *job;





 struct __guc_capture_parsed_output *matched_node;

 struct xe_vm_snapshot *vm;


 struct {

  ssize_t size;

  ssize_t chunk_position;

  char *buffer;
 } read;
};
struct xe_devcoredump {

 struct mutex lock;

 bool captured;

 struct xe_devcoredump_snapshot snapshot;
};
struct xe_device;
struct mei_aux_device;
struct xe_heci_gsc {
 struct mei_aux_device *adev;
 int irq;
};
struct gsc_version {
 u16 major;
 u16 minor;
 u16 hotfix;
 u16 build;
} __attribute__((__packed__));
enum xe_late_bind_fw_id {

 XE_LB_FW_FAN_CONTROL = 0,

 XE_LB_FW_MAX_ID
};
struct xe_late_bind_fw {

 u32 id;

 char blob_path[4096];

 u32 type;

 u32 flags;

 const u8 *payload;

 size_t payload_size;

 struct work_struct work;

 struct gsc_version version;
};
struct xe_late_bind_component {
 struct device *mei_dev;
 const struct intel_lb_component_ops *ops;
};
struct xe_late_bind {

 struct xe_late_bind_component component;

 struct xe_late_bind_fw late_bind_fw[XE_LB_FW_MAX_ID];

 struct workqueue_struct *wq;

 bool component_added;

 bool disable;
};
struct xe_bo;
struct xe_lmtt;
struct xe_lmtt_pt;
struct xe_lmtt_ops;
struct xe_lmtt {

 struct xe_lmtt_pt *pd;


 const struct xe_lmtt_ops *ops;
};
struct xe_lmtt_pt {

 unsigned int level;


 struct xe_bo *bo;


 struct xe_lmtt_pt *entries[1];
};
struct xe_lmtt_ops {

 unsigned int (*lmtt_root_pd_level)(void);
 unsigned int (*lmtt_pte_num)(unsigned int level);
 unsigned int (*lmtt_pte_size)(unsigned int level);
 unsigned int (*lmtt_pte_shift)(unsigned int level);
 unsigned int (*lmtt_pte_index)(u64 addr, unsigned int level);
 u64 (*lmtt_pte_encode)(unsigned long offset, unsigned int level);
};
struct xe_bo;
struct xe_memirq {
 struct xe_bo *bo;
 struct iosys_map source;
 struct iosys_map status;
 struct iosys_map mask;
 bool enabled;
};
struct drm_syncobj;
enum xe_oa_report_header {
 HDR_32_BIT = 0,
 HDR_64_BIT,
};
enum xe_oa_format_name {
 XE_OA_FORMAT_C4_B8,


 XE_OA_FORMAT_A12,
 XE_OA_FORMAT_A12_B8_C8,
 XE_OA_FORMAT_A32u40_A4u32_B8_C8,


 XE_OAR_FORMAT_A32u40_A4u32_B8_C8,
 XE_OA_FORMAT_A24u40_A14u32_B8_C8,


 XE_OAC_FORMAT_A24u64_B8_C8,
 XE_OAC_FORMAT_A22u32_R2u32_B8_C8,


 XE_OAM_FORMAT_MPEC8u64_B8_C8,
 XE_OAM_FORMAT_MPEC8u32_B8_C8,


 XE_OA_FORMAT_PEC64u64,
 XE_OA_FORMAT_PEC64u64_B8_C8,
 XE_OA_FORMAT_PEC64u32,
 XE_OA_FORMAT_PEC32u64_G1,
 XE_OA_FORMAT_PEC32u32_G1,
 XE_OA_FORMAT_PEC32u64_G2,
 XE_OA_FORMAT_PEC32u32_G2,
 XE_OA_FORMAT_PEC36u64_G1_32_G2_4,
 XE_OA_FORMAT_PEC36u64_G1_4_G2_32,

 __XE_OA_FORMAT_MAX,
};
struct xe_oa_format {

 u32 counter_select;

 int size;

 int type;

 enum xe_oa_report_header header;

 u16 counter_size;

 u16 bc_report;
};
struct xe_oa_regs {
 u32 base;
 struct xe_reg oa_head_ptr;
 struct xe_reg oa_tail_ptr;
 struct xe_reg oa_buffer;
 struct xe_reg oa_ctx_ctrl;
 struct xe_reg oa_ctrl;
 struct xe_reg oa_debug;
 struct xe_reg oa_status;
 u32 oa_ctrl_counter_select_mask;
};
struct xe_oa_unit {

 u16 oa_unit_id;


 struct xe_gt *gt;


 enum drm_xe_oa_unit_type type;


 struct xe_oa_regs regs;


 u32 num_engines;


 struct xe_oa_stream *exclusive_stream;
};
struct xe_oa_gt {

 struct mutex gt_lock;


 u32 num_oa_units;


 struct xe_oa_unit *oa_unit;


 u32 whitelist_count;
};
struct xe_oa {

 struct xe_device *xe;


 struct kobject *metrics_kobj;


 struct mutex metrics_lock;


 struct idr metrics_idr;


 const struct xe_oa_format *oa_formats;


 unsigned long format_mask[(((__XE_OA_FORMAT_MAX) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];


 u16 oa_unit_ids;
};
struct xe_oa_buffer {

 const struct xe_oa_format *format;


 struct xe_bo *bo;


 u8 *vaddr;


 spinlock_t ptr_lock;


 u32 head;


 u32 tail;


 u32 circ_size;
};
struct xe_oa_stream {

 struct xe_oa *oa;


 struct xe_gt *gt;


 struct xe_oa_unit *oa_unit;


 struct xe_hw_engine *hwe;


 struct mutex stream_lock;


 bool sample;


 struct xe_exec_queue *exec_q;


 struct xe_exec_queue *k_exec_q;


 bool enabled;


 struct xe_oa_config *oa_config;


 struct llist_head oa_config_bos;


 struct hrtimer poll_check_timer;


 wait_queue_head_t poll_wq;


 bool pollin;


 int wait_num_reports;


 bool periodic;


 int period_exponent;


 struct xe_oa_buffer oa_buffer;


 u64 poll_period_ns;


 bool override_gucrc;


 u32 oa_status;


 u32 no_preempt;


 struct xe_file *xef;


 struct drm_syncobj *ufence_syncobj;


 u64 ufence_timeline_value;


 struct dma_fence *last_fence;


 u32 num_syncs;


 struct xe_sync_entry *syncs;
};
enum xe_platform {
 XE_PLATFORM_UNINITIALIZED = 0,
 XE_TIGERLAKE,
 XE_ROCKETLAKE,
 XE_ALDERLAKE_S,
 XE_ALDERLAKE_P,
 XE_ALDERLAKE_N,
 XE_DG1,
 XE_DG2,
 XE_PVC,
 XE_METEORLAKE,
 XE_LUNARLAKE,
 XE_BATTLEMAGE,
 XE_PANTHERLAKE,
};
enum xe_subplatform {
 XE_SUBPLATFORM_UNINITIALIZED = 0,
 XE_SUBPLATFORM_NONE,
 XE_SUBPLATFORM_ALDERLAKE_P_RPLU,
 XE_SUBPLATFORM_ALDERLAKE_S_RPLS,
 XE_SUBPLATFORM_DG2_G10,
 XE_SUBPLATFORM_DG2_G11,
 XE_SUBPLATFORM_DG2_G12,
};
struct perf_event_attr {




 __u32 type;




 __u32 size;




 __u64 config;

 union {
  __u64 sample_period;
  __u64 sample_freq;
 };

 __u64 sample_type;
 __u64 read_format;

 __u64 disabled : 1,
    inherit : 1,
    pinned : 1,
    exclusive : 1,
    exclude_user : 1,
    exclude_kernel : 1,
    exclude_hv : 1,
    exclude_idle : 1,
    mmap : 1,
    comm : 1,
    freq : 1,
    inherit_stat : 1,
    enable_on_exec : 1,
    task : 1,
    watermark : 1,
    precise_ip : 2,
    mmap_data : 1,
    sample_id_all : 1,

    exclude_host : 1,
    exclude_guest : 1,

    exclude_callchain_kernel : 1,
    exclude_callchain_user : 1,
    mmap2 : 1,
    comm_exec : 1,
    use_clockid : 1,
    context_switch : 1,
    write_backward : 1,
    namespaces : 1,
    ksymbol : 1,
    bpf_event : 1,
    aux_output : 1,
    cgroup : 1,
    text_poke : 1,
    build_id : 1,
    inherit_thread : 1,
    remove_on_exec : 1,
    sigtrap : 1,
    __reserved_1 : 26;

 union {
  __u32 wakeup_events;
  __u32 wakeup_watermark;
 };

 __u32 bp_type;
 union {
  __u64 bp_addr;
  __u64 kprobe_func;
  __u64 uprobe_path;
  __u64 config1;
 };
 union {
  __u64 bp_len;
  __u64 kprobe_addr;
  __u64 probe_offset;
  __u64 config2;
 };
 __u64 branch_sample_type;





 __u64 sample_regs_user;




 __u32 sample_stack_user;

 __s32 clockid;
 __u64 sample_regs_intr;




 __u32 aux_watermark;
 __u16 sample_max_stack;

 __u16 __reserved_2;
 __u32 aux_sample_size;

 union {
  __u32 aux_action;
  struct {
   __u32 aux_start_paused : 1,
    aux_pause : 1,
    aux_resume : 1,
    __reserved_3 : 29;
  };
 };







 __u64 sig_data;

 __u64 config3;
};
union perf_mem_data_src {
 __u64 val;
 struct {
  __u64 mem_op : 5,
   mem_lvl : 14,
   mem_snoop : 5,
   mem_lock : 2,
   mem_dtlb : 7,
   mem_lvl_num : 4,
   mem_remote : 1,
   mem_snoopx : 2,
   mem_blk : 3,
   mem_hops : 3,
   mem_rsvd : 18;
 };
};
struct perf_branch_entry {
 __u64 from;
 __u64 to;
 __u64 mispred : 1,
  predicted : 1,
  in_tx : 1,
  abort : 1,
  cycles : 16,
  type : 4,
  spec : 2,
  new_type : 4,
  priv : 3,
  reserved : 31;
};
union perf_sample_weight {
 __u64 full;

 struct {
  __u32 var1_dw;
  __u16 var2_w;
  __u16 var3_w;
 };
};
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct fs_pin;
struct pid_namespace {
 struct idr idr;
 struct callback_head rcu;
 unsigned int pid_allocated;
 struct task_struct *child_reaper;
 struct kmem_cache *pid_cachep;
 unsigned int level;
 int pid_max;
 struct pid_namespace *parent;

 struct fs_pin *bacct;

 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 int reboot;
 struct ns_common ns;
 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 int memfd_noexec_scope;


} ;
struct seq_file;
struct pid_namespace;
struct pid;
struct node {
 struct device dev;
 struct list_head access_list;

 struct list_head cache_attrs;
 struct device *cache_dev;

};
struct task_struct;
struct device;
struct device_node;
struct attribute_group;
struct cpu {
 int node_id;
 int hotpluggable;
 struct device dev;
};
extern void *text_poke(void *addr, const void *opcode, size_t len);
struct static_call_mod {
 struct static_call_mod *next;
 struct module *mod;
 struct static_call_site *sites;
};
struct pt_regs;
struct task_struct;
typedef struct {
 atomic_long_t a;
} local_t;
typedef struct {
 local_t a;
} local64_t;
struct arch_hw_breakpoint {
 unsigned long address;
 unsigned long mask;
 u8 len;
 u8 type;
};
struct pt_regs;
struct notifier_block;
struct perf_event_attr;
struct perf_event;
struct pmu;
struct cred;
struct module;
struct ftrace_regs;
struct ftrace_ops;
struct ftrace_ops;
struct ftrace_regs;
struct module;
struct ftrace_hash;
struct ftrace_regs {

};
typedef void (*ftrace_func_t)(unsigned long ip, unsigned long parent_ip,
         struct ftrace_ops *op, struct ftrace_regs *fregs);
enum ftrace_ops_cmd {
 FTRACE_OPS_CMD_ENABLE_SHARE_IPMODIFY_SELF,
 FTRACE_OPS_CMD_ENABLE_SHARE_IPMODIFY_PEER,
 FTRACE_OPS_CMD_DISABLE_SHARE_IPMODIFY_PEER,
};
typedef int (*ftrace_ops_func_t)(struct ftrace_ops *op, enum ftrace_ops_cmd cmd);
struct ftrace_ops_hash {
 struct ftrace_hash *notrace_hash;
 struct ftrace_hash *filter_hash;
 struct mutex regex_lock;
};
struct ftrace_ops {
 ftrace_func_t func;
 struct ftrace_ops *next;
 unsigned long flags;
 void *private;
 ftrace_func_t saved_func;

 struct ftrace_ops_hash local_hash;
 struct ftrace_ops_hash *func_hash;
 struct ftrace_ops_hash old_hash;
 unsigned long trampoline;
 unsigned long trampoline_size;
 struct list_head list;
 struct list_head subop_list;
 ftrace_ops_func_t ops_func;
 struct ftrace_ops *managed;

 unsigned long direct_call;


};
struct seq_file;
struct perf_regs {
 __u64 abi;
 struct pt_regs *regs;
};
struct taskstats {





 __u16 version;
 __u32 ac_exitcode;





 __u8 ac_flag;
 __u8 ac_nice;
 __u64 cpu_count ;
 __u64 cpu_delay_total;






 __u64 blkio_count;
 __u64 blkio_delay_total;


 __u64 swapin_count;
 __u64 swapin_delay_total;







 __u64 cpu_run_real_total;







 __u64 cpu_run_virtual_total;




 char ac_comm[32];
 __u8 ac_sched ;

 __u8 ac_pad[3];
 __u32 ac_uid ;

 __u32 ac_gid;
 __u32 ac_pid;
 __u32 ac_ppid;

 __u32 ac_btime;
 __u64 ac_etime ;

 __u64 ac_utime;
 __u64 ac_stime;
 __u64 ac_minflt;
 __u64 ac_majflt;
 __u64 coremem;



 __u64 virtmem;




 __u64 hiwater_rss;
 __u64 hiwater_vm;


 __u64 read_char;
 __u64 write_char;
 __u64 read_syscalls;
 __u64 write_syscalls;



 __u64 read_bytes;
 __u64 write_bytes;
 __u64 cancelled_write_bytes;

 __u64 nvcsw;
 __u64 nivcsw;


 __u64 ac_utimescaled;
 __u64 ac_stimescaled;
 __u64 cpu_scaled_run_real_total;


 __u64 freepages_count;
 __u64 freepages_delay_total;



 __u64 thrashing_count;
 __u64 thrashing_delay_total;


 __u64 ac_btime64;


 __u64 compact_count;
 __u64 compact_delay_total;


 __u32 ac_tgid;



 __u64 ac_tgetime ;







 __u64 ac_exe_dev;
 __u64 ac_exe_inode;



 __u64 wpcopy_count;
 __u64 wpcopy_delay_total;


 __u64 irq_count;
 __u64 irq_delay_total;




 __u64 cpu_delay_max;
 __u64 cpu_delay_min;

 __u64 blkio_delay_max;
 __u64 blkio_delay_min;

 __u64 swapin_delay_max;
 __u64 swapin_delay_min;

 __u64 freepages_delay_max;
 __u64 freepages_delay_min;

 __u64 thrashing_delay_max;
 __u64 thrashing_delay_min;

 __u64 compact_delay_max;
 __u64 compact_delay_min;

 __u64 wpcopy_delay_max;
 __u64 wpcopy_delay_min;

 __u64 irq_delay_max;
 __u64 irq_delay_min;
};
struct device;
struct file;
struct task_struct;
struct seq_operations;
struct seq_file {
 char *buf;
 size_t size;
 size_t from;
 size_t count;
 size_t pad_until;
 loff_t index;
 loff_t read_pos;
 struct mutex lock;
 const struct seq_operations *op;
 int poll_event;
 const struct file *file;
 void *private;
};
struct seq_operations {
 void * (*start) (struct seq_file *m, loff_t *pos);
 void (*stop) (struct seq_file *m, void *v);
 void * (*next) (struct seq_file *m, void *v, loff_t *pos);
 int (*show) (struct seq_file *m, void *v);
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct seq_operations;
struct kernel_stat {
 unsigned long irqs_sum;
 unsigned int softirqs[NR_SOFTIRQS];
};
extern  __typeof__(struct kernel_stat) kstat;
struct u64_stats_sync {



};
struct bpf_prog_array;
enum cgroup_bpf_attach_type {
 CGROUP_BPF_ATTACH_TYPE_INVALID = -1,
 CGROUP_INET_INGRESS = 0,
 CGROUP_INET_EGRESS,
 CGROUP_INET_SOCK_CREATE,
 CGROUP_SOCK_OPS,
 CGROUP_DEVICE,
 CGROUP_INET4_BIND,
 CGROUP_INET6_BIND,
 CGROUP_INET4_CONNECT,
 CGROUP_INET6_CONNECT,
 CGROUP_UNIX_CONNECT,
 CGROUP_INET4_POST_BIND,
 CGROUP_INET6_POST_BIND,
 CGROUP_UDP4_SENDMSG,
 CGROUP_UDP6_SENDMSG,
 CGROUP_UNIX_SENDMSG,
 CGROUP_SYSCTL,
 CGROUP_UDP4_RECVMSG,
 CGROUP_UDP6_RECVMSG,
 CGROUP_UNIX_RECVMSG,
 CGROUP_GETSOCKOPT,
 CGROUP_SETSOCKOPT,
 CGROUP_INET4_GETPEERNAME,
 CGROUP_INET6_GETPEERNAME,
 CGROUP_UNIX_GETPEERNAME,
 CGROUP_INET4_GETSOCKNAME,
 CGROUP_INET6_GETSOCKNAME,
 CGROUP_UNIX_GETSOCKNAME,
 CGROUP_INET_SOCK_RELEASE,
 CGROUP_LSM_START,
 CGROUP_LSM_END = CGROUP_LSM_START + 10 - 1,
 MAX_CGROUP_BPF_ATTACH_TYPE
};
struct cgroup_bpf {

 struct bpf_prog_array *effective[MAX_CGROUP_BPF_ATTACH_TYPE];






 struct hlist_head progs[MAX_CGROUP_BPF_ATTACH_TYPE];
 u8 flags[MAX_CGROUP_BPF_ATTACH_TYPE];
 u64 revisions[MAX_CGROUP_BPF_ATTACH_TYPE];


 struct list_head storages;


 struct bpf_prog_array *inactive;


 struct percpu_ref refcnt;


 struct work_struct release_work;
};
struct mm_struct;
struct cgroup_subsys_state;
enum psi_task_count {
 NR_IOWAIT,
 NR_MEMSTALL,
 NR_RUNNING,
 NR_MEMSTALL_RUNNING,
 NR_PSI_TASK_COUNTS = 4,
};
enum psi_res {
 PSI_IO,
 PSI_MEM,
 PSI_CPU,

 PSI_IRQ,

 NR_PSI_RESOURCES,
};
enum psi_states {
 PSI_IO_SOME,
 PSI_IO_FULL,
 PSI_MEM_SOME,
 PSI_MEM_FULL,
 PSI_CPU_SOME,
 PSI_CPU_FULL,

 PSI_IRQ_FULL,


 PSI_NONIDLE,
 NR_PSI_STATES,
};
enum psi_aggregators {
 PSI_AVGS = 0,
 PSI_POLL,
 NR_PSI_AGGREGATORS,
};
struct psi_group_cpu {



 unsigned int tasks[NR_PSI_TASK_COUNTS]
   ;


 u32 state_mask;


 u32 times[NR_PSI_STATES];


 u64 state_start;




 u32 times_prev[NR_PSI_AGGREGATORS][NR_PSI_STATES]
   ;
};
struct psi_group {
 struct psi_group *parent;
 bool enabled;


 struct mutex avgs_lock;


 struct psi_group_cpu *pcpu;


 u64 avg_total[NR_PSI_STATES - 1];
 u64 avg_last_update;
 u64 avg_next_update;


 struct delayed_work avgs_work;


 struct list_head avg_triggers;
 u32 avg_nr_triggers[NR_PSI_STATES - 1];


 u64 total[NR_PSI_AGGREGATORS][NR_PSI_STATES - 1];
 unsigned long avg[NR_PSI_STATES - 1][3];


 struct task_struct *rtpoll_task;
 struct timer_list rtpoll_timer;
 wait_queue_head_t rtpoll_wait;
 atomic_t rtpoll_wakeup;
 atomic_t rtpoll_scheduled;


 struct mutex rtpoll_trigger_lock;


 struct list_head rtpoll_triggers;
 u32 rtpoll_nr_triggers[NR_PSI_STATES - 1];
 u32 rtpoll_states;
 u64 rtpoll_min_period;


 u64 rtpoll_total[NR_PSI_STATES - 1];
 u64 rtpoll_next_update;
 u64 rtpoll_until;
};
struct cgroup;
struct cgroup_root;
struct cgroup_subsys;
struct cgroup_taskset;
struct kernfs_node;
struct kernfs_ops;
struct kernfs_open_file;
struct seq_file;
struct poll_table_struct;
enum cgroup_subsys_id {
cpuset_cgrp_id,



cpu_cgrp_id,



cpuacct_cgrp_id,



io_cgrp_id,



memory_cgrp_id,



devices_cgrp_id,



freezer_cgrp_id,



net_cls_cgrp_id,



perf_event_cgrp_id,



net_prio_cgrp_id,



hugetlb_cgrp_id,



pids_cgrp_id,



rdma_cgrp_id,



misc_cgrp_id,



dmem_cgrp_id,






debug_cgrp_id,
 CGROUP_SUBSYS_COUNT,
};
struct cgroup_file {

 struct kernfs_node *kn;
 unsigned long notified_at;
 struct timer_list notify_timer;
};
struct cgroup_subsys_state {

 struct cgroup *cgroup;


 struct cgroup_subsys *ss;


 struct percpu_ref refcnt;
 struct css_rstat_cpu *rstat_cpu;






 struct list_head sibling;
 struct list_head children;





 int id;

 unsigned int flags;







 u64 serial_nr;





 atomic_t online_cnt;


 struct work_struct destroy_work;
 struct rcu_work destroy_rwork;





 struct cgroup_subsys_state *parent;







 int nr_descendants;
 struct cgroup_subsys_state *rstat_flush_next;
};
struct css_set {





 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];


 refcount_t refcount;







 struct css_set *dom_cset;


 struct cgroup *dfl_cgrp;


 int nr_tasks;
 struct list_head tasks;
 struct list_head mg_tasks;
 struct list_head dying_tasks;


 struct list_head task_iters;
 struct list_head e_cset_node[CGROUP_SUBSYS_COUNT];


 struct list_head threaded_csets;
 struct list_head threaded_csets_node;





 struct hlist_node hlist;





 struct list_head cgrp_links;





 struct list_head mg_src_preload_node;
 struct list_head mg_dst_preload_node;
 struct list_head mg_node;
 struct cgroup *mg_src_cgrp;
 struct cgroup *mg_dst_cgrp;
 struct css_set *mg_dst_cset;


 bool dead;


 struct callback_head callback_head;
};
struct cgroup_base_stat {
 struct task_cputime cputime;


 u64 forceidle_sum;

 u64 ntime;
};
struct css_rstat_cpu {





 struct cgroup_subsys_state *updated_children;
 struct cgroup_subsys_state *updated_next;

 struct llist_node lnode;
 struct cgroup_subsys_state *owner;
};
struct cgroup_rstat_base_cpu {




 struct u64_stats_sync bsync;
 struct cgroup_base_stat bstat;





 struct cgroup_base_stat last_bstat;







 struct cgroup_base_stat subtree_bstat;





 struct cgroup_base_stat last_subtree_bstat;
};
struct cgroup_freezer_state {

 bool freeze;


 bool e_freeze;




 int nr_frozen_descendants;





 int nr_frozen_tasks;


 seqcount_spinlock_t freeze_seq;






 u64 freeze_start_nsec;






 u64 frozen_nsec;
};
struct cgroup {

 struct cgroup_subsys_state self;

 unsigned long flags;







 int level;


 int max_depth;
 int nr_descendants;
 int nr_dying_descendants;
 int max_descendants;
 int nr_populated_csets;
 int nr_populated_domain_children;
 int nr_populated_threaded_children;

 int nr_threaded_children;





 unsigned int kill_seq;

 struct kernfs_node *kn;
 struct cgroup_file procs_file;
 struct cgroup_file events_file;


 struct cgroup_file psi_files[NR_PSI_RESOURCES];
 u16 subtree_control;
 u16 subtree_ss_mask;
 u16 old_subtree_control;
 u16 old_subtree_ss_mask;


 struct cgroup_subsys_state *subsys[CGROUP_SUBSYS_COUNT];





 int nr_dying_subsys[CGROUP_SUBSYS_COUNT];

 struct cgroup_root *root;





 struct list_head cset_links;
 struct list_head e_csets[CGROUP_SUBSYS_COUNT];
 struct cgroup *dom_cgrp;
 struct cgroup *old_dom_cgrp;
 struct cgroup_rstat_base_cpu *rstat_base_cpu;






 struct cacheline_padding _pad_;


 struct cgroup_base_stat last_bstat;
 struct cgroup_base_stat bstat;
 struct prev_cputime prev_cputime;





 struct list_head pidlists;
 struct mutex pidlist_mutex;


 wait_queue_head_t offline_waitq;


 struct work_struct release_agent_work;


 struct psi_group *psi;


 struct cgroup_bpf bpf;


 struct cgroup_freezer_state freezer;


 struct bpf_local_storage *bpf_cgrp_storage;



 struct cgroup *ancestors[1];
};
struct cgroup_root {
 struct kernfs_root *kf_root;


 unsigned int subsys_mask;


 int hierarchy_id;


 struct list_head root_list;
 struct callback_head rcu;






 struct cgroup cgrp;


 struct cgroup *cgrp_ancestor_storage;


 atomic_t nr_cgrps;


 unsigned int flags;


 char release_agent_path[4096];


 char name[64];
};
struct cftype {




 char name[64];
 unsigned long private;





 size_t max_write_len;


 unsigned int flags;







 unsigned int file_offset;





 struct cgroup_subsys *ss;
 struct list_head node;
 struct kernfs_ops *kf_ops;

 int (*open)(struct kernfs_open_file *of);
 void (*release)(struct kernfs_open_file *of);





 u64 (*read_u64)(struct cgroup_subsys_state *css, struct cftype *cft);



 s64 (*read_s64)(struct cgroup_subsys_state *css, struct cftype *cft);


 int (*seq_show)(struct seq_file *sf, void *v);


 void *(*seq_start)(struct seq_file *sf, loff_t *ppos);
 void *(*seq_next)(struct seq_file *sf, void *v, loff_t *ppos);
 void (*seq_stop)(struct seq_file *sf, void *v);






 int (*write_u64)(struct cgroup_subsys_state *css, struct cftype *cft,
    u64 val);



 int (*write_s64)(struct cgroup_subsys_state *css, struct cftype *cft,
    s64 val);







 ssize_t (*write)(struct kernfs_open_file *of,
    char *buf, size_t nbytes, loff_t off);

 __poll_t (*poll)(struct kernfs_open_file *of,
    struct poll_table_struct *pt);

 struct lock_class_key lockdep_key;
};
struct cgroup_subsys {
 struct cgroup_subsys_state *(*css_alloc)(struct cgroup_subsys_state *parent_css);
 int (*css_online)(struct cgroup_subsys_state *css);
 void (*css_offline)(struct cgroup_subsys_state *css);
 void (*css_released)(struct cgroup_subsys_state *css);
 void (*css_free)(struct cgroup_subsys_state *css);
 void (*css_reset)(struct cgroup_subsys_state *css);
 void (*css_killed)(struct cgroup_subsys_state *css);
 void (*css_rstat_flush)(struct cgroup_subsys_state *css, int cpu);
 int (*css_extra_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);
 int (*css_local_stat_show)(struct seq_file *seq,
       struct cgroup_subsys_state *css);

 int (*can_attach)(struct cgroup_taskset *tset);
 void (*cancel_attach)(struct cgroup_taskset *tset);
 void (*attach)(struct cgroup_taskset *tset);
 int (*can_fork)(struct task_struct *task,
   struct css_set *cset);
 void (*cancel_fork)(struct task_struct *task, struct css_set *cset);
 void (*fork)(struct task_struct *task);
 void (*exit)(struct task_struct *task);
 void (*release)(struct task_struct *task);
 void (*bind)(struct cgroup_subsys_state *root_css);

 bool early_init:1;
 bool implicit_on_dfl:1;
 bool threaded:1;


 int id;
 const char *name;


 const char *legacy_name;


 struct cgroup_root *root;


 struct idr css_idr;





 struct list_head cfts;





 struct cftype *dfl_cftypes;
 struct cftype *legacy_cftypes;
 unsigned int depends_on;

 spinlock_t rstat_ss_lock;
 struct llist_head *lhead;
};
extern struct percpu_rw_semaphore cgroup_threadgroup_rwsem;
struct cgroup_namespace {
 struct ns_common ns;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct css_set *root_cset;
};
static inline    u64 cgroup_id(const struct cgroup *cgrp)
;
void css_rstat_flush(struct cgroup_subsys_state *css);
struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};
enum bpf_cgroup_iter_order {
 BPF_CGROUP_ITER_ORDER_UNSPEC = 0,
 BPF_CGROUP_ITER_SELF_ONLY,
 BPF_CGROUP_ITER_DESCENDANTS_PRE,
 BPF_CGROUP_ITER_DESCENDANTS_POST,
 BPF_CGROUP_ITER_ANCESTORS_UP,
};
enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 __MAX_BPF_MAP_TYPE
};
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};
enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 __MAX_BPF_ATTACH_TYPE
};
enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};
union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64  excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64  key;
  union {
   __u64  value;
   __u64  next_key;
  };
  __u64 flags;
 };

 struct {
  __u64  in_batch;


  __u64  out_batch;
  __u64  keys;
  __u64  values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64  insns;
  __u64  license;
  __u32 log_level;
  __u32 log_size;
  __u64  log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64  func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64  line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64  fd_array;
  __u64  core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
  __u32 fd_array_cnt;



  __u64  signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64  pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64  data_in;
  __u64  data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64  ctx_in;
  __u64  ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64  info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64  prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64  prog_attach_flags;
  __u64  link_ids;
  __u64  link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64  cookie;
 } raw_tracepoint;

 struct {
  __u64  btf;
  __u64  btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64  buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64  iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64  syms;
    __u64  addrs;
    __u64  cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64  path;
    __u64  offsets;
    __u64  ref_ctr_offsets;
    __u64  cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64  stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

} ;
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};
struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64  tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64  target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64  addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64  cookies;
  } kprobe_multi;
  struct {
   __u64  path;
   __u64  offsets;
   __u64  ref_ctr_offsets;
   __u64  cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64  file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64  func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64  tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} ;
struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};
struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};
struct sock_filter {
 __u16 code;
 __u8 jt;
 __u8 jf;
 __u32 k;
};
struct btf_type {
 __u32 name_off;
 __u32 info;







 union {
  __u32 size;
  __u32 type;
 };
};
struct btf_member {
 __u32 name_off;
 __u32 type;






 __u32 offset;
};
struct btf;
struct btf_member;
struct btf_type;
union bpf_attr;
struct bpf_prog;
struct bpf_verifier_log;
struct bpf_struct_ops;
struct page_counter {




 atomic_long_t usage;
 unsigned long failcnt;

 struct cacheline_padding _pad1_;


 unsigned long emin;
 atomic_long_t min_usage;
 atomic_long_t children_min_usage;


 unsigned long elow;
 atomic_long_t low_usage;
 atomic_long_t children_low_usage;

 unsigned long watermark;

 unsigned long local_watermark;


 struct cacheline_padding _pad2_;

 bool protection_support;
 bool track_failcnt;
 unsigned long min;
 unsigned long low;
 unsigned long high;
 unsigned long max;
 struct page_counter *parent;
} ;
struct eventfd_ctx;
struct file;
struct vmpressure {
 unsigned long scanned;
 unsigned long reclaimed;

 unsigned long tree_scanned;
 unsigned long tree_reclaimed;

 spinlock_t sr_lock;


 struct list_head events;

 struct mutex events_lock;

 struct work_struct work;
};
struct mem_cgroup;
extern void vmpressure(gfp_t gfp, struct mem_cgroup *memcg, bool tree,
         unsigned long scanned, unsigned long reclaimed);
struct fprop_global {

 struct percpu_counter events;

 unsigned int period;

 seqcount_t sequence;
};
struct fprop_local_percpu {

 struct percpu_counter events;

 unsigned int period;
 raw_spinlock_t lock;
};
struct page;
struct device;
struct dentry;
enum wb_stat_item {
 WB_RECLAIMABLE,
 WB_WRITEBACK,
 WB_DIRTIED,
 WB_WRITTEN,
 NR_WB_STAT_ITEMS
};
enum wb_reason {
 WB_REASON_BACKGROUND,
 WB_REASON_VMSCAN,
 WB_REASON_SYNC,
 WB_REASON_PERIODIC,
 WB_REASON_LAPTOP_TIMER,
 WB_REASON_FS_FREE_SPACE,






 WB_REASON_FORKER_THREAD,
 WB_REASON_FOREIGN_FLUSH,

 WB_REASON_MAX,
};
struct wb_completion {
 atomic_t cnt;
 wait_queue_head_t *waitq;
};
struct bdi_writeback {
 struct backing_dev_info *bdi;

 unsigned long state;
 unsigned long last_old_flush;

 struct list_head b_dirty;
 struct list_head b_io;
 struct list_head b_more_io;
 struct list_head b_dirty_time;
 spinlock_t list_lock;

 atomic_t writeback_inodes;
 struct percpu_counter stat[NR_WB_STAT_ITEMS];

 unsigned long bw_time_stamp;
 unsigned long dirtied_stamp;
 unsigned long written_stamp;
 unsigned long write_bandwidth;
 unsigned long avg_write_bandwidth;







 unsigned long dirty_ratelimit;
 unsigned long balanced_dirty_ratelimit;

 struct fprop_local_percpu completions;
 int dirty_exceeded;
 enum wb_reason start_all_reason;

 spinlock_t work_lock;
 struct list_head work_list;
 struct delayed_work dwork;
 struct delayed_work bw_dwork;

 struct list_head bdi_node;


 struct percpu_ref refcnt;
 struct fprop_local_percpu memcg_completions;
 struct cgroup_subsys_state *memcg_css;
 struct cgroup_subsys_state *blkcg_css;
 struct list_head memcg_node;
 struct list_head blkcg_node;
 struct list_head b_attached;
 struct list_head offline_node;
 struct work_struct switch_work;

 struct llist_head switch_wbs_ctxs;


 union {
  struct work_struct release_work;
  struct callback_head rcu;
 };

};
struct backing_dev_info {
 u64 id;
 struct rb_node rb_node;
 struct list_head bdi_list;
 unsigned long ra_pages;
 unsigned long io_pages;

 struct kref refcnt;
 unsigned int capabilities;
 unsigned int min_ratio;
 unsigned int max_ratio, max_prop_frac;





 atomic_long_t tot_write_bandwidth;




 unsigned long last_bdp_sleep;

 struct bdi_writeback wb;
 struct list_head wb_list;

 struct xarray cgwb_tree;
 struct mutex cgwb_release_mutex;
 struct rw_semaphore wb_switch_rwsem;

 wait_queue_head_t wb_waitq;

 struct device *dev;
 char dev_name[64];
 struct device *owner;

 struct timer_list laptop_mode_wb_timer;


 struct dentry *debug_dir;

};
struct page;
struct bio_vec {
 struct page *bv_page;
 unsigned int bv_len;
 unsigned int bv_offset;
};
struct bvec_iter {
 sector_t bi_sector;

 unsigned int bi_size;

 unsigned int bi_idx;

 unsigned int bi_bvec_done;

} __attribute__((__packed__)) ;
struct bio_set;
struct bio;
struct bio_integrity_payload;
struct page;
struct io_context;
struct cgroup_subsys_state;
typedef void (bio_end_io_t) (struct bio *);
struct bio_crypt_ctx;
struct block_device {
 sector_t bd_start_sect;
 sector_t bd_nr_sectors;
 struct gendisk * bd_disk;
 struct request_queue * bd_queue;
 struct disk_stats *bd_stats;
 unsigned long bd_stamp;
 atomic_t __bd_flags;


 dev_t bd_dev;
 struct address_space *bd_mapping;

 atomic_t bd_openers;
 spinlock_t bd_size_lock;
 void * bd_claiming;
 void * bd_holder;
 const struct blk_holder_ops *bd_holder_ops;
 struct mutex bd_holder_lock;
 int bd_holders;
 struct kobject *bd_holder_dir;

 atomic_t bd_fsfreeze_count;
 struct mutex bd_fsfreeze_mutex;

 struct partition_meta_info *bd_meta_info;
 int bd_writers;

 void *bd_security;





 struct device bd_device;
} ;
typedef u8 blk_status_t;
typedef __u32 blk_opf_t;
typedef unsigned int blk_qc_t;
struct bio {
 struct bio *bi_next;
 struct block_device *bi_bdev;
 blk_opf_t bi_opf;


 unsigned short bi_flags;
 unsigned short bi_ioprio;
 enum rw_hint bi_write_hint;
 u8 bi_write_stream;
 blk_status_t bi_status;
 u8 bi_bvec_gap_bit;

 atomic_t __bi_remaining;

 struct bvec_iter bi_iter;

 union {

  blk_qc_t bi_cookie;

  unsigned int __bi_nr_segments;
 };
 bio_end_io_t *bi_end_io;
 void *bi_private;







 struct blkcg_gq *bi_blkg;

 u64 issue_time_ns;

 u64 bi_iocost_cost;




 struct bio_crypt_ctx *bi_crypt_context;



 struct bio_integrity_payload *bi_integrity;


 unsigned short bi_vcnt;





 unsigned short bi_max_vecs;

 atomic_t __bi_cnt;

 struct bio_vec *bi_io_vec;

 struct bio_set *bi_pool;
};
struct folio;
struct folio_batch {
 unsigned char nr;
 unsigned char i;
 bool percpu_pvec_drained;
 struct folio *folios[31];
};
struct bio;
struct backing_dev_info;
enum writeback_sync_modes {
 WB_SYNC_NONE,
 WB_SYNC_ALL,
};
struct writeback_control {

 long nr_to_write;

 long pages_skipped;






 loff_t range_start;
 loff_t range_end;

 enum writeback_sync_modes sync_mode;

 unsigned for_kupdate:1;
 unsigned for_background:1;
 unsigned tagged_writepages:1;
 unsigned range_cyclic:1;
 unsigned for_sync:1;
 unsigned unpinned_netfs_wb:1;







 unsigned no_cgroup_owner:1;


 struct folio_batch fbatch;
 unsigned long index;
 int saved_err;


 struct bdi_writeback *wb;
 struct inode *inode;


 int wb_id;
 int wb_lcand_id;
 int wb_tcand_id;
 size_t wb_bytes;
 size_t wb_lcand_bytes;
 size_t wb_tcand_bytes;

};
struct wb_domain {
 spinlock_t lock;
 struct fprop_global completions;
 struct timer_list period_timer;
 unsigned long period_time;
 unsigned long dirty_limit_tstamp;
 unsigned long dirty_limit;
};
struct bdi_writeback;
struct kmem_cache;
typedef void * (mempool_alloc_t)(gfp_t gfp_mask, void *pool_data);
typedef void (mempool_free_t)(void *element, void *pool_data);
typedef struct mempool {
 spinlock_t lock;
 int min_nr;
 int curr_nr;
 void **elements;

 void *pool_data;
 mempool_alloc_t *alloc;
 mempool_free_t *free;
 wait_queue_head_t wait;
} mempool_t;
struct request_queue;
struct bio_list {
 struct bio *head;
 struct bio *tail;
};
struct bio_set {
 struct kmem_cache *bio_slab;
 unsigned int front_pad;




 struct bio_alloc_cache *cache;

 mempool_t bio_pool;
 mempool_t bvec_pool;

 unsigned int back_pad;




 spinlock_t rescue_lock;
 struct bio_list rescue_list;
 struct work_struct rescue_work;
 struct workqueue_struct *rescue_workqueue;




 struct hlist_node cpuhp_dead;
};
struct mem_cgroup;
struct obj_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;
enum memcg_memory_event {
 MEMCG_LOW,
 MEMCG_HIGH,
 MEMCG_MAX,
 MEMCG_OOM,
 MEMCG_OOM_KILL,
 MEMCG_OOM_GROUP_KILL,
 MEMCG_SWAP_HIGH,
 MEMCG_SWAP_MAX,
 MEMCG_SWAP_FAIL,
 MEMCG_NR_MEMORY_EVENTS,
};
struct mem_cgroup_id {
 int id;
 refcount_t ref;
};
struct memcg_vmstats_percpu;
struct memcg1_events_percpu;
struct memcg_vmstats;
struct lruvec_stats_percpu;
struct lruvec_stats;
struct mem_cgroup_reclaim_iter {
 struct mem_cgroup *position;

 atomic_t generation;
};
struct mem_cgroup_per_node {

 struct mem_cgroup *memcg;


 struct lruvec_stats_percpu *lruvec_stats_percpu;
 struct lruvec_stats *lruvec_stats;
 struct shrinker_info *shrinker_info;
 struct rb_node tree_node;
 unsigned long usage_in_excess;

 bool on_tree;





 struct lruvec lruvec;
 struct cacheline_padding _pad2_;
 unsigned long lru_zone_size[5][NR_LRU_LISTS];
 struct mem_cgroup_reclaim_iter iter;






};
struct mem_cgroup_threshold {
 struct eventfd_ctx *eventfd;
 unsigned long threshold;
};
struct mem_cgroup_threshold_ary {

 int current_threshold;

 unsigned int size;

 struct mem_cgroup_threshold entries[1] ;
};
struct mem_cgroup_thresholds {

 struct mem_cgroup_threshold_ary *primary;





 struct mem_cgroup_threshold_ary *spare;
};
struct memcg_cgwb_frn {
 u64 bdi_id;
 int memcg_id;
 u64 at;
 struct wb_completion done;
};
struct obj_cgroup {
 struct percpu_ref refcnt;
 struct mem_cgroup *memcg;
 atomic_t nr_charged_bytes;
 union {
  struct list_head list;
  struct callback_head rcu;
 };
};
struct mem_cgroup {
 struct cgroup_subsys_state css;


 struct mem_cgroup_id id;


 struct page_counter memory;

 union {
  struct page_counter swap;
  struct page_counter memsw;
 };


 struct list_head memory_peaks;
 struct list_head swap_peaks;
 spinlock_t peaks_lock;


 struct work_struct high_work;


 unsigned long zswap_max;





 bool zswap_writeback;



 struct vmpressure vmpressure;




 bool oom_group;

 int swappiness;


 struct cgroup_file events_file;
 struct cgroup_file events_local_file;


 struct cgroup_file swap_events_file;


 struct memcg_vmstats *vmstats;


 atomic_long_t memory_events[MEMCG_NR_MEMORY_EVENTS];
 atomic_long_t memory_events_local[MEMCG_NR_MEMORY_EVENTS];
 u64 socket_pressure;



 int kmemcg_id;





 struct obj_cgroup *objcg;
 struct obj_cgroup *orig_objcg;

 struct list_head objcg_list;

 struct memcg_vmstats_percpu *vmstats_percpu;


 struct list_head cgwb_list;
 struct wb_domain cgwb_domain;
 struct memcg_cgwb_frn cgwb_frn[4];



 struct deferred_split deferred_split_queue;




 struct lru_gen_mm_list mm_list;




 struct page_counter kmem;
 struct page_counter tcpmem;

 struct memcg1_events_percpu *events_percpu;

 unsigned long soft_limit;


 bool oom_lock;
 int under_oom;


 int oom_kill_disable;


 struct mutex thresholds_lock;


 struct mem_cgroup_thresholds thresholds;


 struct mem_cgroup_thresholds memsw_thresholds;


 struct list_head oom_notify;


 bool tcpmem_active;
 int tcpmem_pressure;


 struct list_head event_list;
 spinlock_t event_list_lock;


 struct mem_cgroup_per_node *nodeinfo[1];
};
static inline    unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
;
static inline    void memcg_memory_event(struct mem_cgroup *memcg,
          enum memcg_memory_event event)
;
struct sock;
static inline    int shrinker_id(struct shrinker *shrinker)
;
struct pt_regs;
struct qspinlock;
struct bpf_verifier_env;
struct bpf_verifier_log;
struct perf_event;
struct bpf_prog;
struct bpf_prog_aux;
struct bpf_map;
struct bpf_arena;
struct sock;
struct seq_file;
struct btf;
struct btf_type;
struct exception_table_entry;
struct seq_operations;
struct bpf_iter_aux_info;
struct bpf_local_storage;
struct bpf_local_storage_map;
struct kobject;
struct mem_cgroup;
struct module;
struct bpf_func_state;
struct ftrace_ops;
struct cgroup;
struct bpf_token;
struct user_namespace;
struct super_block;
struct inode;
typedef u64 (*bpf_callback_t)(u64, u64, u64, u64, u64);
typedef int (*bpf_iter_init_seq_priv_t)(void *private_data,
     struct bpf_iter_aux_info *aux);
typedef void (*bpf_iter_fini_seq_priv_t)(void *private_data);
struct bpf_iter_seq_info {
 const struct seq_operations *seq_ops;
 bpf_iter_init_seq_priv_t init_seq_private;
 bpf_iter_fini_seq_priv_t fini_seq_private;
 u32 seq_priv_size;
};
struct bpf_map_ops {

 int (*map_alloc_check)(union bpf_attr *attr);
 struct bpf_map *(*map_alloc)(union bpf_attr *attr);
 void (*map_release)(struct bpf_map *map, struct file *map_file);
 void (*map_free)(struct bpf_map *map);
 int (*map_get_next_key)(struct bpf_map *map, void *key, void *next_key);
 void (*map_release_uref)(struct bpf_map *map);
 void *(*map_lookup_elem_sys_only)(struct bpf_map *map, void *key);
 int (*map_lookup_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_lookup_and_delete_elem)(struct bpf_map *map, void *key,
       void *value, u64 flags);
 int (*map_lookup_and_delete_batch)(struct bpf_map *map,
        const union bpf_attr *attr,
        union bpf_attr *uattr);
 int (*map_update_batch)(struct bpf_map *map, struct file *map_file,
    const union bpf_attr *attr,
    union bpf_attr *uattr);
 int (*map_delete_batch)(struct bpf_map *map, const union bpf_attr *attr,
    union bpf_attr *uattr);


 void *(*map_lookup_elem)(struct bpf_map *map, void *key);
 long (*map_update_elem)(struct bpf_map *map, void *key, void *value, u64 flags);
 long (*map_delete_elem)(struct bpf_map *map, void *key);
 long (*map_push_elem)(struct bpf_map *map, void *value, u64 flags);
 long (*map_pop_elem)(struct bpf_map *map, void *value);
 long (*map_peek_elem)(struct bpf_map *map, void *value);
 void *(*map_lookup_percpu_elem)(struct bpf_map *map, void *key, u32 cpu);
 int (*map_get_hash)(struct bpf_map *map, u32 hash_buf_size, void *hash_buf);


 void *(*map_fd_get_ptr)(struct bpf_map *map, struct file *map_file,
    int fd);




 void (*map_fd_put_ptr)(struct bpf_map *map, void *ptr, bool need_defer);
 int (*map_gen_lookup)(struct bpf_map *map, struct bpf_insn *insn_buf);
 u32 (*map_fd_sys_lookup_elem)(void *ptr);
 void (*map_seq_show_elem)(struct bpf_map *map, void *key,
      struct seq_file *m);
 int (*map_check_btf)(const struct bpf_map *map,
        const struct btf *btf,
        const struct btf_type *key_type,
        const struct btf_type *value_type);


 int (*map_poke_track)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_untrack)(struct bpf_map *map, struct bpf_prog_aux *aux);
 void (*map_poke_run)(struct bpf_map *map, u32 key, struct bpf_prog *old,
        struct bpf_prog *new);


 int (*map_direct_value_addr)(const struct bpf_map *map,
         u64 *imm, u32 off);
 int (*map_direct_value_meta)(const struct bpf_map *map,
         u64 imm, u32 *off);
 int (*map_mmap)(struct bpf_map *map, struct vm_area_struct *vma);
 __poll_t (*map_poll)(struct bpf_map *map, struct file *filp,
        struct poll_table_struct *pts);
 unsigned long (*map_get_unmapped_area)(struct file *filep, unsigned long addr,
            unsigned long len, unsigned long pgoff,
            unsigned long flags);


 int (*map_local_storage_charge)(struct bpf_local_storage_map *smap,
     void *owner, u32 size);
 void (*map_local_storage_uncharge)(struct bpf_local_storage_map *smap,
        void *owner, u32 size);
 struct bpf_local_storage ** (*map_owner_storage_ptr)(void *owner);


 long (*map_redirect)(struct bpf_map *map, u64 key, u64 flags);
 bool (*map_meta_equal)(const struct bpf_map *meta0,
          const struct bpf_map *meta1);


 int (*map_set_for_each_callback_args)(struct bpf_verifier_env *env,
           struct bpf_func_state *caller,
           struct bpf_func_state *callee);
 long (*map_for_each_callback)(struct bpf_map *map,
         bpf_callback_t callback_fn,
         void *callback_ctx, u64 flags);

 u64 (*map_mem_usage)(const struct bpf_map *map);


 int *map_btf_id;


 const struct bpf_iter_seq_info *iter_seq_info;
};
enum btf_field_type {
 BPF_SPIN_LOCK = (1 << 0),
 BPF_TIMER = (1 << 1),
 BPF_KPTR_UNREF = (1 << 2),
 BPF_KPTR_REF = (1 << 3),
 BPF_KPTR_PERCPU = (1 << 4),
 BPF_KPTR = BPF_KPTR_UNREF | BPF_KPTR_REF | BPF_KPTR_PERCPU,
 BPF_LIST_HEAD = (1 << 5),
 BPF_LIST_NODE = (1 << 6),
 BPF_RB_ROOT = (1 << 7),
 BPF_RB_NODE = (1 << 8),
 BPF_GRAPH_NODE = BPF_RB_NODE | BPF_LIST_NODE,
 BPF_GRAPH_ROOT = BPF_RB_ROOT | BPF_LIST_HEAD,
 BPF_REFCOUNT = (1 << 9),
 BPF_WORKQUEUE = (1 << 10),
 BPF_UPTR = (1 << 11),
 BPF_RES_SPIN_LOCK = (1 << 12),
 BPF_TASK_WORK = (1 << 13),
};
enum bpf_cgroup_storage_type {
 BPF_CGROUP_STORAGE_SHARED,
 BPF_CGROUP_STORAGE_PERCPU,
 __BPF_CGROUP_STORAGE_MAX
};
typedef void (*btf_dtor_kfunc_t)(void *);
struct btf_field_kptr {
 struct btf *btf;
 struct module *module;



 btf_dtor_kfunc_t dtor;
 u32 btf_id;
};
struct btf_field_graph_root {
 struct btf *btf;
 u32 value_btf_id;
 u32 node_offset;
 struct btf_record *value_rec;
};
struct btf_field {
 u32 offset;
 u32 size;
 enum btf_field_type type;
 union {
  struct btf_field_kptr kptr;
  struct btf_field_graph_root graph_root;
 };
};
struct btf_record {
 u32 cnt;
 u32 field_mask;
 int spin_lock_off;
 int res_spin_lock_off;
 int timer_off;
 int wq_off;
 int refcount_off;
 int task_work_off;
 struct btf_field fields[1];
};
struct bpf_map_owner {
 enum bpf_prog_type type;
 bool jited;
 bool xdp_has_frags;
 u64 storage_cookie[__BPF_CGROUP_STORAGE_MAX];
 const struct btf_type *attach_func_proto;
 enum bpf_attach_type expected_attach_type;
};
struct bpf_map {
 u8 sha[32];
 u32 excl;
 const struct bpf_map_ops *ops;
 struct bpf_map *inner_map_meta;

 void *security;

 enum bpf_map_type map_type;
 u32 key_size;
 u32 value_size;
 u32 max_entries;
 u64 map_extra;
 u32 map_flags;
 u32 id;
 struct btf_record *record;
 int numa_node;
 u32 btf_key_type_id;
 u32 btf_value_type_id;
 u32 btf_vmlinux_value_type_id;
 struct btf *btf;

 struct obj_cgroup *objcg;

 char name[16U];
 struct mutex freeze_mutex;
 atomic64_t refcnt;
 atomic64_t usercnt;

 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 atomic64_t writecnt;
 spinlock_t owner_lock;
 struct bpf_map_owner *owner;
 bool bypass_spec_v1;
 bool frozen;
 bool free_after_mult_rcu_gp;
 bool free_after_rcu_gp;
 atomic64_t sleepable_refcnt;
 s64 *elem_count;
 u64 cookie;
 char *excl_prog_sha;
};
struct bpf_offload_dev;
enum bpf_type_flag {

 PTR_MAYBE_NULL = ((((1UL))) << (0 + 8)),




 MEM_RDONLY = ((((1UL))) << (1 + 8)),


 MEM_RINGBUF = ((((1UL))) << (2 + 8)),


 MEM_USER = ((((1UL))) << (3 + 8)),







 MEM_PERCPU = ((((1UL))) << (4 + 8)),


 OBJ_RELEASE = ((((1UL))) << (5 + 8)),







 PTR_UNTRUSTED = ((((1UL))) << (6 + 8)),


 MEM_UNINIT = ((((1UL))) << (7 + 8)),


 DYNPTR_TYPE_LOCAL = ((((1UL))) << (8 + 8)),


 DYNPTR_TYPE_RINGBUF = ((((1UL))) << (9 + 8)),


 MEM_FIXED_SIZE = ((((1UL))) << (10 + 8)),




 MEM_ALLOC = ((((1UL))) << (11 + 8)),
 PTR_TRUSTED = ((((1UL))) << (12 + 8)),


 MEM_RCU = ((((1UL))) << (13 + 8)),





 NON_OWN_REF = ((((1UL))) << (14 + 8)),


 DYNPTR_TYPE_SKB = ((((1UL))) << (15 + 8)),


 DYNPTR_TYPE_XDP = ((((1UL))) << (16 + 8)),




 MEM_ALIGNED = ((((1UL))) << (17 + 8)),






 MEM_WRITE = ((((1UL))) << (18 + 8)),


 DYNPTR_TYPE_SKB_META = ((((1UL))) << (19 + 8)),

 __BPF_TYPE_FLAG_MAX,
 __BPF_TYPE_LAST_FLAG = __BPF_TYPE_FLAG_MAX - 1,
};
enum bpf_arg_type {
 ARG_DONTCARE = 0,




 ARG_CONST_MAP_PTR,
 ARG_PTR_TO_MAP_KEY,
 ARG_PTR_TO_MAP_VALUE,




 ARG_PTR_TO_MEM,
 ARG_PTR_TO_ARENA,

 ARG_CONST_SIZE,
 ARG_CONST_SIZE_OR_ZERO,

 ARG_PTR_TO_CTX,
 ARG_ANYTHING,
 ARG_SCALAR,
 ARG_PTR_TO_SPIN_LOCK,
 ARG_PTR_TO_SOCK_COMMON,
 ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_BTF_ID,
 ARG_PTR_TO_RINGBUF_MEM,
 ARG_CONST_ALLOC_SIZE_OR_ZERO,
 ARG_PTR_TO_BTF_ID_SOCK_COMMON,
 ARG_PTR_TO_PERCPU_BTF_ID,
 ARG_PTR_TO_FUNC,
 ARG_PTR_TO_STACK,
 ARG_PTR_TO_CONST_STR,
 ARG_PTR_TO_TIMER,
 ARG_KPTR_XCHG_DEST,
 ARG_PTR_TO_DYNPTR,
 __BPF_ARG_TYPE_MAX,


 ARG_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MAP_VALUE,
 ARG_PTR_TO_MEM_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_MEM,
 ARG_PTR_TO_CTX_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_CTX,
 ARG_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_SOCKET,
 ARG_PTR_TO_STACK_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_STACK,
 ARG_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | ARG_PTR_TO_BTF_ID,



 ARG_PTR_TO_UNINIT_MEM = MEM_UNINIT | MEM_WRITE | ARG_PTR_TO_MEM,

 ARG_PTR_TO_FIXED_SIZE_MEM = MEM_FIXED_SIZE | ARG_PTR_TO_MEM,




 __BPF_ARG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
enum bpf_return_type {
 RET_INTEGER,
 RET_VOID,
 RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_MEM,
 RET_PTR_TO_MEM_OR_BTF_ID,
 RET_PTR_TO_BTF_ID,
 __BPF_RET_TYPE_MAX,


 RET_PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MAP_VALUE,
 RET_PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCKET,
 RET_PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_TCP_SOCK,
 RET_PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_SOCK_COMMON,
 RET_PTR_TO_RINGBUF_MEM_OR_NULL = PTR_MAYBE_NULL | MEM_RINGBUF | RET_PTR_TO_MEM,
 RET_PTR_TO_DYNPTR_MEM_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_MEM,
 RET_PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | RET_PTR_TO_BTF_ID,
 RET_PTR_TO_BTF_ID_TRUSTED = PTR_TRUSTED | RET_PTR_TO_BTF_ID,




 __BPF_RET_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_func_proto {
 u64 (*func)(u64 r1, u64 r2, u64 r3, u64 r4, u64 r5);
 bool gpl_only;
 bool pkt_access;
 bool might_sleep;





 bool allow_fastcall;
 enum bpf_return_type ret_type;
 union {
  struct {
   enum bpf_arg_type arg1_type;
   enum bpf_arg_type arg2_type;
   enum bpf_arg_type arg3_type;
   enum bpf_arg_type arg4_type;
   enum bpf_arg_type arg5_type;
  };
  enum bpf_arg_type arg_type[5];
 };
 union {
  struct {
   u32 *arg1_btf_id;
   u32 *arg2_btf_id;
   u32 *arg3_btf_id;
   u32 *arg4_btf_id;
   u32 *arg5_btf_id;
  };
  u32 *arg_btf_id[5];
  struct {
   size_t arg1_size;
   size_t arg2_size;
   size_t arg3_size;
   size_t arg4_size;
   size_t arg5_size;
  };
  size_t arg_size[5];
 };
 int *ret_btf_id;
 bool (*allowed)(const struct bpf_prog *prog);
};
enum bpf_access_type {
 BPF_READ = 1,
 BPF_WRITE = 2
};
enum bpf_reg_type {
 NOT_INIT = 0,
 SCALAR_VALUE,
 PTR_TO_CTX,
 CONST_PTR_TO_MAP,
 PTR_TO_MAP_VALUE,
 PTR_TO_MAP_KEY,
 PTR_TO_STACK,
 PTR_TO_PACKET_META,
 PTR_TO_PACKET,
 PTR_TO_PACKET_END,
 PTR_TO_FLOW_KEYS,
 PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK,
 PTR_TO_TP_BUFFER,
 PTR_TO_XDP_SOCK,
 PTR_TO_BTF_ID,
 PTR_TO_MEM,
 PTR_TO_ARENA,
 PTR_TO_BUF,
 PTR_TO_FUNC,
 CONST_PTR_TO_DYNPTR,
 __BPF_REG_TYPE_MAX,


 PTR_TO_MAP_VALUE_OR_NULL = PTR_MAYBE_NULL | PTR_TO_MAP_VALUE,
 PTR_TO_SOCKET_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCKET,
 PTR_TO_SOCK_COMMON_OR_NULL = PTR_MAYBE_NULL | PTR_TO_SOCK_COMMON,
 PTR_TO_TCP_SOCK_OR_NULL = PTR_MAYBE_NULL | PTR_TO_TCP_SOCK,




 PTR_TO_BTF_ID_OR_NULL = PTR_MAYBE_NULL | PTR_TO_BTF_ID,




 __BPF_REG_TYPE_LIMIT = (__BPF_TYPE_LAST_FLAG | (__BPF_TYPE_LAST_FLAG - 1)),
};
struct bpf_insn_access_aux {
 enum bpf_reg_type reg_type;
 bool is_ldsx;
 union {
  int ctx_field_size;
  struct {
   struct btf *btf;
   u32 btf_id;
   u32 ref_obj_id;
  };
 };
 struct bpf_verifier_log *log;
 bool is_retval;
};
struct bpf_prog_ops {
 int (*test_run)(struct bpf_prog *prog, const union bpf_attr *kattr,
   union bpf_attr *uattr);
};
struct bpf_reg_state;
struct bpf_verifier_ops {

 const struct bpf_func_proto *
 (*get_func_proto)(enum bpf_func_id func_id,
     const struct bpf_prog *prog);




 bool (*is_valid_access)(int off, int size, enum bpf_access_type type,
    const struct bpf_prog *prog,
    struct bpf_insn_access_aux *info);
 int (*gen_prologue)(struct bpf_insn *insn, bool direct_write,
       const struct bpf_prog *prog);
 int (*gen_epilogue)(struct bpf_insn *insn, const struct bpf_prog *prog,
       s16 ctx_stack_off);
 int (*gen_ld_abs)(const struct bpf_insn *orig,
     struct bpf_insn *insn_buf);
 u32 (*convert_ctx_access)(enum bpf_access_type type,
      const struct bpf_insn *src,
      struct bpf_insn *dst,
      struct bpf_prog *prog, u32 *target_size);
 int (*btf_struct_access)(struct bpf_verifier_log *log,
     const struct bpf_reg_state *reg,
     int off, int size);
};
struct bpf_prog_offload {
 struct bpf_prog *prog;
 struct net_device *netdev;
 struct bpf_offload_dev *offdev;
 void *dev_priv;
 struct list_head offloads;
 bool dev_state;
 bool opt_failed;
 void *jited_image;
 u32 jited_len;
};
struct btf_func_model {
 u8 ret_size;
 u8 ret_flags;
 u8 nr_args;
 u8 arg_size[12];
 u8 arg_flags[12];
};
struct bpf_tramp_image;
struct bpf_ksym {
 unsigned long start;
 unsigned long end;
 char name[512];
 struct list_head lnode;
 struct latch_tree_node tnode;
 bool prog;
};
enum bpf_tramp_prog_type {
 BPF_TRAMP_FENTRY,
 BPF_TRAMP_FEXIT,
 BPF_TRAMP_MODIFY_RETURN,
 BPF_TRAMP_MAX,
 BPF_TRAMP_REPLACE,
};
struct bpf_tramp_image {
 void *image;
 int size;
 struct bpf_ksym ksym;
 struct percpu_ref pcref;
 void *ip_after_call;
 void *ip_epilogue;
 union {
  struct callback_head rcu;
  struct work_struct work;
 };
};
struct bpf_trampoline {

 struct hlist_node hlist;
 struct ftrace_ops *fops;

 struct mutex mutex;
 refcount_t refcnt;
 u32 flags;
 u64 key;
 struct {
  struct btf_func_model model;
  void *addr;
  bool ftrace_managed;
 } func;




 struct bpf_prog *extension_prog;

 struct hlist_head progs_hlist[BPF_TRAMP_MAX];

 int progs_cnt[BPF_TRAMP_MAX];

 struct bpf_tramp_image *cur_image;
};
struct bpf_func_info_aux {
 u16 linkage;
 bool unreliable;
 bool called : 1;
 bool verified : 1;
};
struct bpf_jit_poke_descriptor {
 void *tailcall_target;
 void *tailcall_bypass;
 void *bypass_addr;
 void *aux;
 union {
  struct {
   struct bpf_map *map;
   u32 key;
  } tail_call;
 };
 bool tailcall_target_stable;
 u8 adj_off;
 u16 reason;
 u32 insn_idx;
};
struct bpf_ctx_arg_aux {
 u32 offset;
 enum bpf_reg_type reg_type;
 struct btf *btf;
 u32 btf_id;
 u32 ref_obj_id;
 bool refcounted;
};
struct btf_mod_pair {
 struct btf *btf;
 struct module *module;
};
struct bpf_kfunc_desc_tab;
struct bpf_stream {
 atomic_t capacity;
 struct llist_head log;

 struct mutex lock;
 struct llist_node *backlog_head;
 struct llist_node *backlog_tail;
};
struct bpf_prog_aux {
 atomic64_t refcnt;
 u32 used_map_cnt;
 u32 used_btf_cnt;
 u32 max_ctx_offset;
 u32 max_pkt_offset;
 u32 max_tp_access;
 u32 stack_depth;
 u32 id;
 u32 func_cnt;
 u32 real_func_cnt;
 u32 func_idx;
 u32 attach_btf_id;
 u32 attach_st_ops_member_off;
 u32 ctx_arg_info_size;
 u32 max_rdonly_access;
 u32 max_rdwr_access;
 struct btf *attach_btf;
 struct bpf_ctx_arg_aux *ctx_arg_info;
 void *priv_stack_ptr;
 struct mutex dst_mutex;
 struct bpf_prog *dst_prog;
 struct bpf_trampoline *dst_trampoline;
 enum bpf_prog_type saved_dst_prog_type;
 enum bpf_attach_type saved_dst_attach_type;
 bool verifier_zext;
 bool dev_bound;
 bool offload_requested;
 bool attach_btf_trace;
 bool attach_tracing_prog;
 bool func_proto_unreliable;
 bool tail_call_reachable;
 bool xdp_has_frags;
 bool exception_cb;
 bool exception_boundary;
 bool is_extended;
 bool jits_use_priv_stack;
 bool priv_stack_requested;
 bool changes_pkt_data;
 bool might_sleep;
 bool kprobe_write_ctx;
 u64 prog_array_member_cnt;
 struct mutex ext_mutex;
 struct bpf_arena *arena;
 void (*recursion_detected)(struct bpf_prog *prog);

 const struct btf_type *attach_func_proto;

 const char *attach_func_name;
 struct bpf_prog **func;
 struct bpf_prog_aux *main_prog_aux;
 void *jit_data;
 struct bpf_jit_poke_descriptor *poke_tab;
 struct bpf_kfunc_desc_tab *kfunc_tab;
 struct bpf_kfunc_btf_tab *kfunc_btf_tab;
 u32 size_poke_tab;



 struct bpf_ksym ksym;
 const struct bpf_prog_ops *ops;
 const struct bpf_struct_ops *st_ops;
 struct bpf_map **used_maps;
 struct mutex used_maps_mutex;
 struct btf_mod_pair *used_btfs;
 struct bpf_prog *prog;
 struct user_struct *user;
 u64 load_time;
 u32 verified_insns;
 int cgroup_atype;
 struct bpf_map *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
 char name[16U];
 u64 (*bpf_exception_cb)(u64 cookie, u64 sp, u64 bp, u64, u64);

 void *security;

 struct bpf_token *token;
 struct bpf_prog_offload *offload;
 struct btf *btf;
 struct bpf_func_info *func_info;
 struct bpf_func_info_aux *func_info_aux;






 struct bpf_line_info *linfo;







 void **jited_linfo;
 u32 func_info_cnt;
 u32 nr_linfo;




 u32 linfo_idx;
 struct module *mod;
 u32 num_exentries;
 struct exception_table_entry *extable;
 union {
  struct work_struct work;
  struct callback_head rcu;
 };
 struct bpf_stream stream[2];
};
struct bpf_prog {
 u16 pages;
 u16 jited:1,
    jit_requested:1,
    gpl_compatible:1,
    cb_access:1,
    dst_needed:1,
    blinding_requested:1,
    blinded:1,
    is_func:1,
    kprobe_override:1,
    has_callchain_buf:1,
    enforce_expected_attach_type:1,
    call_get_stack:1,
    call_get_func_ip:1,
    tstamp_type_access:1,
    sleepable:1;
 enum bpf_prog_type type;
 enum bpf_attach_type expected_attach_type;
 u32 len;
 u32 jited_len;
 union {
  u8 digest[32];
  u8 tag[8];
 };
 struct bpf_prog_stats *stats;
 int *active;
 unsigned int (*bpf_func)(const void *ctx,
         const struct bpf_insn *insn);
 struct bpf_prog_aux *aux;
 struct sock_fprog_kern *orig_prog;

 union {
  struct { struct { } __empty_insns; struct sock_filter insns[1]; };
  struct { struct { } __empty_insnsi; struct bpf_insn insnsi[1]; };
 };
};
struct bpf_link {
 atomic64_t refcnt;
 u32 id;
 enum bpf_link_type type;
 const struct bpf_link_ops *ops;
 struct bpf_prog *prog;

 u32 flags;
 enum bpf_attach_type attach_type;




 union {
  struct callback_head rcu;
  struct work_struct work;
 };




 bool sleepable;
};
struct bpf_link_ops {
 void (*release)(struct bpf_link *link);



 void (*dealloc)(struct bpf_link *link);






 void (*dealloc_deferred)(struct bpf_link *link);
 int (*detach)(struct bpf_link *link);
 int (*update_prog)(struct bpf_link *link, struct bpf_prog *new_prog,
      struct bpf_prog *old_prog);
 void (*show_fdinfo)(const struct bpf_link *link, struct seq_file *seq);
 int (*fill_link_info)(const struct bpf_link *link,
         struct bpf_link_info *info);
 int (*update_map)(struct bpf_link *link, struct bpf_map *new_map,
     struct bpf_map *old_map);
 __poll_t (*poll)(struct file *file, struct poll_table_struct *pts);
};
struct bpf_token {
 struct work_struct work;
 atomic64_t refcnt;
 struct user_namespace *userns;
 u64 allowed_cmds;
 u64 allowed_maps;
 u64 allowed_progs;
 u64 allowed_attachs;

 void *security;

};
struct btf_member;
struct bpf_struct_ops {
 const struct bpf_verifier_ops *verifier_ops;
 int (*init)(struct btf *btf);
 int (*check_member)(const struct btf_type *t,
       const struct btf_member *member,
       const struct bpf_prog *prog);
 int (*init_member)(const struct btf_type *t,
      const struct btf_member *member,
      void *kdata, const void *udata);
 int (*reg)(void *kdata, struct bpf_link *link);
 void (*unreg)(void *kdata, struct bpf_link *link);
 int (*update)(void *kdata, void *old_kdata, struct bpf_link *link);
 int (*validate)(void *kdata);
 void *cfi_stubs;
 struct module *owner;
 const char *name;
 struct btf_func_model func_models[64];
};
struct bpf_prog_array_item {
 struct bpf_prog *prog;
 union {
  struct bpf_cgroup_storage *cgroup_storage[__BPF_CGROUP_STORAGE_MAX];
  u64 bpf_cookie;
 };
};
struct bpf_prog_array {
 struct callback_head rcu;
 struct bpf_prog_array_item items[1];
};
struct bpf_run_ctx {};
enum bpf_iter_task_type {
 BPF_TASK_ITER_ALL = 0,
 BPF_TASK_ITER_TID,
 BPF_TASK_ITER_TGID,
};
struct bpf_iter_aux_info {

 struct bpf_map *map;


 struct {
  struct cgroup *start;
  enum bpf_cgroup_iter_order order;
 } cgroup;
 struct {
  enum bpf_iter_task_type type;
  u32 pid;
 } task;
};
int map_set_for_each_callback_args(struct bpf_verifier_env *env,
       struct bpf_func_state *caller,
       struct bpf_func_state *callee);
int btf_struct_access(struct bpf_verifier_log *log,
        const struct bpf_reg_state *reg,
        int off, int size, enum bpf_access_type atype,
        u32 *next_btf_id, enum bpf_type_flag *flag, const char **field_name);
struct bpf_reg_state;
struct key;
struct cred;
struct rlimit;
struct kernel_siginfo;
struct audit_context;
struct super_block;
struct inode;
struct dentry;
struct file;
struct vfsmount;
struct path;
struct qstr;
struct iattr;
struct fown_struct;
struct file_operations;
struct kernfs_node;
struct mm_struct;
struct fs_context;
struct ctl_table;
struct user_namespace;
struct sock;
struct seq_file;
union bpf_attr;
struct bpf_map;
struct bpf_prog;
struct bpf_token;
struct perf_event_attr;
struct perf_event;
struct perf_callchain_entry {
 u64 nr;
 u64 ip[1];
};
typedef unsigned long (*perf_copy_f)(void *dst, const void *src,
         unsigned long off, unsigned long len);
struct perf_raw_frag {
 union {
  struct perf_raw_frag *next;
  unsigned long pad;
 };
 perf_copy_f copy;
 void *data;
 u32 size;
} __attribute__((__packed__));
struct perf_raw_record {
 struct perf_raw_frag frag;
 u32 size;
};
struct perf_branch_stack {
 u64 nr;
 u64 hw_idx;
 struct perf_branch_entry entries[1];
};
struct task_struct;
struct hw_perf_event_extra {
 u64 config;
 unsigned int reg;
 int alloc;
 int idx;
};
struct hw_perf_event {

 union {
  struct {
   u64 config;
   u64 config1;
   u64 last_tag;
   u64 dyn_constraint;
   unsigned long config_base;
   unsigned long event_base;
   int event_base_rdpmc;
   int idx;
   int last_cpu;
   int flags;

   struct hw_perf_event_extra extra_reg;
   struct hw_perf_event_extra branch_reg;
  };
  struct {
   u64 aux_config;





   unsigned int aux_paused;
  };
  struct {
   struct hrtimer hrtimer;
  };
  struct {

   struct list_head tp_list;
  };
  struct {
   u64 pwr_acc;
   u64 ptsc;
  };

  struct {





   struct arch_hw_breakpoint info;
   struct rhlist_head bp_list;
  };

  struct {
   u8 iommu_bank;
   u8 iommu_cntr;
   u16 padding;
   u64 conf;
   u64 conf1;
  };
 };




 struct task_struct *target;





 void *addr_filters;


 unsigned long addr_filters_gen;










 int state;





 local64_t prev_count;




 u64 sample_period;

 union {
  struct {



   u64 last_period;







   local64_t period_left;
  };
  struct {
   u64 saved_metric;
   u64 saved_slots;
  };
 };





 u64 interrupts_seq;
 u64 interrupts;





 u64 freq_time_stamp;
 u64 freq_count_stamp;

};
struct perf_event;
struct perf_event_pmu_context;
struct perf_output_handle;
struct pmu {
 struct list_head entry;

 spinlock_t events_lock;
 struct list_head events;

 struct module *module;
 struct device *dev;
 struct device *parent;
 const struct attribute_group **attr_groups;
 const struct attribute_group **attr_update;
 const char *name;
 int type;




 int capabilities;




 unsigned int scope;

 struct perf_cpu_pmu_context * *cpu_pmu_context;
 atomic_t exclusive_cnt;
 int task_ctx_nr;
 int hrtimer_interval_ms;


 unsigned int nr_addr_filters;





 void (*pmu_enable) (struct pmu *pmu);
 void (*pmu_disable) (struct pmu *pmu);
 int (*event_init) (struct perf_event *event);





 void (*event_mapped) (struct perf_event *event, struct mm_struct *mm);
 void (*event_unmapped) (struct perf_event *event, struct mm_struct *mm);















 int (*add) (struct perf_event *event, int flags);
 void (*del) (struct perf_event *event, int flags);
 void (*start) (struct perf_event *event, int flags);
 void (*stop) (struct perf_event *event, int flags);







 void (*read) (struct perf_event *event);
 void (*start_txn) (struct pmu *pmu, unsigned int txn_flags);
 int (*commit_txn) (struct pmu *pmu);






 void (*cancel_txn) (struct pmu *pmu);






 int (*event_idx) (struct perf_event *event);




 void (*sched_task) (struct perf_event_pmu_context *pmu_ctx,
      struct task_struct *task, bool sched_in);




 struct kmem_cache *task_ctx_cache;




 void *(*setup_aux) (struct perf_event *event, void **pages,
      int nr_pages, bool overwrite);





 void (*free_aux) (void *aux);
 long (*snapshot_aux) (struct perf_event *event,
      struct perf_output_handle *handle,
      unsigned long size);
 int (*addr_filters_validate) (struct list_head *filters);
 void (*addr_filters_sync) (struct perf_event *event);
 int (*aux_output_match) (struct perf_event *event);






 bool (*filter) (struct pmu *pmu, int cpu);




 int (*check_period) (struct perf_event *event, u64 value);
};
struct perf_addr_filters_head {
 struct list_head list;
 raw_spinlock_t lock;
 unsigned int nr_file_filters;
};
struct perf_addr_filter_range {
 unsigned long start;
 unsigned long size;
};
enum perf_event_state {
 PERF_EVENT_STATE_DEAD = -5,
 PERF_EVENT_STATE_REVOKED = -4,
 PERF_EVENT_STATE_EXIT = -3,
 PERF_EVENT_STATE_ERROR = -2,
 PERF_EVENT_STATE_OFF = -1,
 PERF_EVENT_STATE_INACTIVE = 0,
 PERF_EVENT_STATE_ACTIVE = 1,
};
struct file;
struct perf_sample_data;
typedef void (*perf_overflow_handler_t)(struct perf_event *,
     struct perf_sample_data *,
     struct pt_regs *regs);
struct bpf_prog;
struct perf_cgroup;
struct perf_buffer;
struct perf_event {






 struct list_head event_entry;





 struct list_head sibling_list;
 struct list_head active_list;



 struct rb_node group_node;
 u64 group_index;





 struct list_head migrate_entry;

 struct hlist_node hlist_entry;
 struct list_head active_entry;
 int nr_siblings;


 int event_caps;

 int group_caps;

 unsigned int group_generation;
 struct perf_event *group_leader;





 struct pmu *pmu;
 void *pmu_private;

 enum perf_event_state state;
 unsigned int attach_state;
 local64_t count;
 atomic64_t child_count;







 u64 total_time_enabled;
 u64 total_time_running;
 u64 tstamp;

 struct perf_event_attr attr;
 u16 header_size;
 u16 id_header_size;
 u16 read_size;
 struct hw_perf_event hw;

 struct perf_event_context *ctx;





 struct perf_event_pmu_context *pmu_ctx;
 atomic_long_t refcount;





 atomic64_t child_total_time_enabled;
 atomic64_t child_total_time_running;




 struct mutex child_mutex;
 struct list_head child_list;
 struct perf_event *parent;

 int oncpu;
 int cpu;

 struct list_head owner_entry;
 struct task_struct *owner;


 struct mutex mmap_mutex;
 refcount_t mmap_count;

 struct perf_buffer *rb;
 struct list_head rb_entry;
 unsigned long rcu_batches;
 int rcu_pending;


 wait_queue_head_t waitq;
 struct fasync_struct *fasync;


 unsigned int pending_wakeup;
 unsigned int pending_kill;
 unsigned int pending_disable;
 unsigned long pending_addr;
 struct irq_work pending_irq;
 struct irq_work pending_disable_irq;
 struct callback_head pending_task;
 unsigned int pending_work;

 atomic_t event_limit;


 struct perf_addr_filters_head addr_filters;

 struct perf_addr_filter_range *addr_filter_ranges;
 unsigned long addr_filters_gen;


 struct perf_event *aux_event;

 void (*destroy)(struct perf_event *);
 struct callback_head callback_head;

 struct pid_namespace *ns;
 u64 id;

 atomic64_t lost_samples;

 u64 (*clock)(void);
 perf_overflow_handler_t overflow_handler;
 void *overflow_handler_context;
 struct bpf_prog *prog;
 u64 bpf_cookie;


 struct trace_event_call *tp_event;
 struct event_filter *filter;

 struct ftrace_ops ftrace_ops;




 struct perf_cgroup *cgrp;



 void *security;

 struct list_head sb_list;
 struct list_head pmu_list;







 u32 orig_type;

};
struct perf_event_pmu_context {
 struct pmu *pmu;
 struct perf_event_context *ctx;

 struct list_head pmu_ctx_entry;

 struct list_head pinned_active;
 struct list_head flexible_active;


 unsigned int embedded : 1;

 unsigned int nr_events;
 unsigned int nr_cgroups;
 unsigned int nr_freq;

 atomic_t refcount;
 struct callback_head callback_head;







 int rotate_necessary;
};
struct perf_event_groups {
 struct rb_root tree;
 u64 index;
};
struct perf_event_context {




 raw_spinlock_t lock;





 struct mutex mutex;

 struct list_head pmu_ctx_list;
 struct perf_event_groups pinned_groups;
 struct perf_event_groups flexible_groups;
 struct list_head event_list;

 int nr_events;
 int nr_user;
 int is_active;

 int nr_stat;
 int nr_freq;
 int rotate_disable;

 refcount_t refcount;
 struct task_struct *task;




 u64 time;
 u64 timestamp;
 u64 timeoffset;





 struct perf_event_context *parent_ctx;
 u64 parent_gen;
 u64 generation;
 int pin_count;

 int nr_cgroups;

 struct callback_head callback_head;
 local_t nr_no_switch_fast;
};
struct perf_ctx_data {
 struct callback_head callback_head;
 refcount_t refcount;
 int global;
 struct kmem_cache *ctx_cache;
 void *data;
};
struct perf_cpu_pmu_context {
 struct perf_event_pmu_context epc;
 struct perf_event_pmu_context *task_epc;

 struct list_head sched_cb_entry;
 int sched_cb_usage;

 int active_oncpu;
 int exclusive;
 int pmu_disable_count;

 raw_spinlock_t hrtimer_lock;
 struct hrtimer hrtimer;
 ktime_t hrtimer_interval;
 unsigned int hrtimer_active;
};
struct perf_output_handle {
 struct perf_event *event;
 struct perf_buffer *rb;
 unsigned long wakeup;
 unsigned long size;
 union {
  u64 flags;
  u64 aux_flags;
  struct {
   u64 skip_read : 1;
  };
 };
 union {
  void *addr;
  unsigned long head;
 };
 int page;
};
struct perf_cgroup_info {
 u64 time;
 u64 timestamp;
 u64 timeoffset;
 int active;
};
struct perf_cgroup {
 struct cgroup_subsys_state css;
 struct perf_cgroup_info *info;
};
static inline    bool branch_sample_type(const struct perf_event *event)
;
struct perf_sample_data {




 u64 sample_flags;
 u64 period;
 u64 dyn_size;





 u64 type;
 struct {
  u32 pid;
  u32 tid;
 } tid_entry;
 u64 time;
 u64 id;
 struct {
  u32 cpu;
  u32 reserved;
 } cpu_entry;





 u64 ip;
 struct perf_callchain_entry *callchain;
 struct perf_raw_record *raw;
 struct perf_branch_stack *br_stack;
 u64 *br_stack_cntr;
 union perf_sample_weight weight;
 union perf_mem_data_src data_src;
 u64 txn;

 struct perf_regs regs_user;
 struct perf_regs regs_intr;
 u64 stack_user_size;

 u64 stream_id;
 u64 cgroup;
 u64 addr;
 u64 phys_addr;
 u64 data_page_size;
 u64 code_page_size;
 u64 aux_size;
} ;
extern  __typeof__(struct perf_callchain_entry) perf_callchain_entry;
struct xe_pmu {



 struct pmu base;



 bool registered;



 const char *name;



 u64 supported_events;
};
struct mm_walk;
enum page_walk_lock {

 PGWALK_RDLOCK = 0,

 PGWALK_WRLOCK = 1,

 PGWALK_WRLOCK_VERIFY = 2,

 PGWALK_VMA_RDLOCK_VERIFY = 3,
};
struct mm_walk_ops {
 int (*pgd_entry)(pgd_t *pgd, unsigned long addr,
    unsigned long next, struct mm_walk *walk);
 int (*p4d_entry)(p4d_t *p4d, unsigned long addr,
    unsigned long next, struct mm_walk *walk);
 int (*pud_entry)(pud_t *pud, unsigned long addr,
    unsigned long next, struct mm_walk *walk);
 int (*pmd_entry)(pmd_t *pmd, unsigned long addr,
    unsigned long next, struct mm_walk *walk);
 int (*pte_entry)(pte_t *pte, unsigned long addr,
    unsigned long next, struct mm_walk *walk);
 int (*pte_hole)(unsigned long addr, unsigned long next,
   int depth, struct mm_walk *walk);
 int (*hugetlb_entry)(pte_t *pte, unsigned long hmask,
        unsigned long addr, unsigned long next,
        struct mm_walk *walk);
 int (*test_walk)(unsigned long addr, unsigned long next,
   struct mm_walk *walk);
 int (*pre_vma)(unsigned long start, unsigned long end,
         struct mm_walk *walk);
 void (*post_vma)(struct mm_walk *walk);
 int (*install_pte)(unsigned long addr, unsigned long next,
      pte_t *ptep, struct mm_walk *walk);
 enum page_walk_lock walk_lock;
};
enum page_walk_action {

 ACTION_SUBTREE = 0,

 ACTION_CONTINUE = 1,

 ACTION_AGAIN = 2
};
struct mm_walk {
 const struct mm_walk_ops *ops;
 struct mm_struct *mm;
 pgd_t *pgd;
 struct vm_area_struct *vma;
 enum page_walk_action action;
 bool no_vma;
 void *private;
};
struct xe_ptw {
 struct xe_ptw **children;
 struct xe_ptw **staging;
};
struct xe_bo;
struct xe_device;
struct xe_vma;
enum xe_cache_level {
 XE_CACHE_NONE,
 XE_CACHE_WT,
 XE_CACHE_WB,
 XE_CACHE_NONE_COMPRESSION,
 __XE_CACHE_LEVEL_COUNT,
};
struct xe_pt {
 struct xe_ptw base;
 struct xe_bo *bo;
 unsigned int level;
 unsigned int num_live;
 bool rebind;
 bool is_compact;


 u64 addr;

};
struct xe_pt_ops {
 u64 (*pte_encode_bo)(struct xe_bo *bo, u64 bo_offset,
        u16 pat_index, u32 pt_level);
 u64 (*pte_encode_vma)(u64 pte, struct xe_vma *vma,
         u16 pat_index, u32 pt_level);
 u64 (*pte_encode_addr)(struct xe_device *xe, u64 addr,
          u16 pat_index,
          u32 pt_level, bool devmem, u64 flags);
 u64 (*pde_encode_bo)(struct xe_bo *bo, u64 bo_offset);
};
struct xe_sriov_pf_service_version {
 u16 major;
 u16 minor;
};
struct xe_sriov_pf_service {
 struct {
  struct xe_sriov_pf_service_version base;
  struct xe_sriov_pf_service_version latest;
 } version;
};
struct xe_sriov_metadata {

 struct xe_sriov_pf_service_version version;
};
struct xe_device_pf {

 u16 device_total_vfs;


 u16 driver_max_vfs;


 struct mutex master_lock;


 struct xe_sriov_pf_service service;


 struct xe_sriov_metadata *vfs;
};
enum xe_sriov_mode {




 XE_SRIOV_MODE_NONE = 1,
 XE_SRIOV_MODE_PF,
 XE_SRIOV_MODE_VF,
};
enum xe_sriov_vf_ccs_rw_ctxs {
 XE_SRIOV_VF_CCS_READ_CTX,
 XE_SRIOV_VF_CCS_WRITE_CTX,
 XE_SRIOV_VF_CCS_CTX_COUNT
};
struct xe_migrate;
struct xe_sa_manager;
struct xe_sriov_vf_ccs_ctx {

 enum xe_sriov_vf_ccs_rw_ctxs ctx_id;


 struct xe_exec_queue *mig_q;


 struct {

  struct xe_sa_manager *ccs_bb_pool;
 } mem;
};
struct xe_sriov_vf_ccs {

 struct xe_sriov_vf_ccs_ctx contexts[XE_SRIOV_VF_CCS_CTX_COUNT];


 bool initialized;
};
struct xe_sriov_vf_relay_version {

 u16 major;

 u16 minor;
};
struct xe_device_vf {

 struct xe_sriov_vf_relay_version pf_version;


 struct {

  struct work_struct worker;

  unsigned long gt_flags;




  bool enabled;
 } migration;


 struct xe_sriov_vf_ccs ccs;
};
struct xe_step_info {
 u8 graphics;
 u8 media;
 u8 basedie;
};
enum xe_survivability_type {
 XE_SURVIVABILITY_TYPE_BOOT,
 XE_SURVIVABILITY_TYPE_RUNTIME,
};
struct xe_survivability_info {
 char name[255];
 u32 reg;
 u32 value;
};
struct xe_survivability {

 struct xe_survivability_info *info;


 u32 size;


 u8 boot_status;


 bool mode;


 enum xe_survivability_type type;
};
struct drm_exec;
struct drm_gem_object;
struct xe_device;
struct xe_validation_device {
 struct rw_semaphore lock;
};
struct intel_dg_nvm_dev;
struct xe_ggtt;
struct xe_i2c;
struct xe_pat_ops;
struct xe_pxp;
struct xe_vram_region;
struct xe_mmio {

 struct xe_tile *tile;


 void *regs;







 struct xe_gt *sriov_vf_gt;
 size_t regs_size;


 u32 adj_limit;


 u32 adj_offset;
};
struct xe_tile {

 struct xe_device *xe;


 u8 id;




 struct xe_gt *primary_gt;






 struct xe_gt *media_gt;
 struct xe_mmio mmio;


 struct {






  struct xe_vram_region *vram;


  struct xe_ggtt *ggtt;






  struct xe_sa_manager *kernel_bb_pool;
 } mem;


 union {
  struct {

   struct xe_lmtt lmtt;
  } pf;
  struct {

   struct xe_ggtt_node *ggtt_balloon[2];
  } vf;
 } sriov;


 struct xe_memirq memirq;


 struct work_struct csc_hw_error_work;


 struct {

  struct mutex lock;
 } pcode;


 struct xe_migrate *migrate;


 struct kobject *sysfs;


 struct dentry *debugfs;
};
struct xe_device {

 struct drm_device drm;


 struct xe_devcoredump devcoredump;


 struct intel_device_info {

  const char *platform_name;

  const char *graphics_name;

  const char *media_name;

  u32 graphics_verx100;

  u32 media_verx100;

  u32 mem_region_mask;

  enum xe_platform platform;

  enum xe_subplatform subplatform;

  u16 devid;

  u8 revid;

  struct xe_step_info step;

  u8 dma_mask_size;

  u8 vram_flags;

  u8 tile_count;

  u8 max_gt_per_tile;

  u8 gt_count;

  u8 vm_max_level;

  u8 va_bits;






  u8 force_execlist:1;

  u8 has_asid:1;

  u8 has_atomic_enable_pte_bit:1;

  u8 has_device_atomics_on_smem:1;

  u8 has_fan_control:1;

  u8 has_flat_ccs:1;

  u8 has_gsc_nvm:1;

  u8 has_heci_cscfi:1;

  u8 has_heci_gscfi:1;

  u8 has_late_bind:1;

  u8 has_llc:1;



  u8 has_mbx_power_limits:1;

  u8 has_page_reclaim_hw_assist:1;

  u8 has_pxp:1;

  u8 has_range_tlb_inval:1;

  u8 has_sriov:1;

  u8 has_usm:1;

  u8 has_64bit_timestamp:1;

  u8 is_dgfx:1;

  u8 needs_scratch:1;
  u8 probe_display:1;

  u8 skip_guc_pc:1;

  u8 skip_mtcfg:1;

  u8 skip_pcode:1;
 } info;


 struct {

  unsigned long *oob;






  bool oob_initialized;
 } wa_active;


 struct xe_survivability survivability;


 struct {

  spinlock_t lock;


  atomic_t enabled;


  struct {

   u16 nvec;

   struct xarray indexes;
  } msix;
 } irq;


 struct ttm_device ttm;


 struct {

  size_t size;

  void *regs;
 } mmio;


 struct {

  struct xe_vram_region *vram;

  struct ttm_resource_manager sys_mgr;

  struct xe_shrinker *shrinker;
 } mem;


 struct {

  enum xe_sriov_mode __mode;

  union {

   struct xe_device_pf pf;

   struct xe_device_vf vf;
  };


  struct workqueue_struct *wq;
 } sriov;


 struct {

  struct xarray asid_to_vm;

  u32 next_asid;

  struct rw_semaphore lock;
 } usm;


 struct {

  spinlock_t lock;

  struct {

   struct list_head kernel_bo_present;

   struct list_head evicted;
  } early;

  struct {

   struct list_head kernel_bo_present;

   struct list_head evicted;

   struct list_head external;
  } late;
 } pinned;


 wait_queue_head_t ufence_wq;


 struct workqueue_struct *preempt_fence_wq;


 struct workqueue_struct *ordered_wq;


 struct workqueue_struct *unordered_wq;


 struct workqueue_struct *destroy_wq;


 struct xe_tile tiles[(1 + 1)];





 struct {




  struct {






   struct mutex lock;






   struct list_head list;
  } vram_userfault;
 } mem_access;




 struct {

  const struct xe_pat_ops *ops;

  const struct xe_pat_table_entry *table;

  int n_entries;

  const struct xe_pat_table_entry *pat_ats;

  const struct xe_pat_table_entry *pat_pta;
  u32 idx[__XE_CACHE_LEVEL_COUNT];
 } pat;


 struct {

  bool capable;


  bool allowed;
  u32 vram_threshold;

  struct mutex lock;
 } d3cold;


 struct notifier_block pm_notifier;

 struct completion pm_block;

 struct list_head rebind_resume_list;

 struct mutex rebind_resume_lock;


 struct {

  struct mutex lock;
 } pmt;





 struct task_struct *pm_callback_task;


 struct xe_hwmon *hwmon;


 struct xe_heci_gsc heci_gsc;


 struct intel_dg_nvm_dev *nvm;


 struct xe_late_bind late_bind;


 struct xe_oa oa;


 struct xe_pxp *pxp;


 bool needs_flr_on_fini;


 struct {

  atomic_t flag;

  int mode;

  unsigned long method;

  bool inconsistent_reset;
 } wedged;


 struct xe_bo_dev {

  struct work_struct async_free;

  struct llist_head async_list;
 } bo_device;


 struct xe_pmu pmu;


 struct xe_i2c *i2c;


 u32 atomic_svm_timeslice_ms;
 atomic64_t global_total_pages;


 struct xe_validation_device val;


 struct {

  struct xe_bo *capture_obj[(1 + 1) + 1];

  u8 region_mask;
 } psmi;



 u32 *g2g_test_array;

 atomic_t g2g_test_count;
};
struct xe_file {

 struct xe_device *xe;


 struct drm_file *drm;


 struct {

  struct xarray xa;





  struct mutex lock;
 } vm;


 struct {

  struct xarray xa;





  struct mutex lock;




  atomic_t pending_removal;
 } exec_queue;


 u64 run_ticks[XE_ENGINE_CLASS_MAX];


 struct xe_drm_client *client;





 char *process_name;





 pid_t pid;


 struct kref refcount;
};
struct xe_bo;
struct xe_gt;
struct xe_ggtt {

 struct xe_tile *tile;

 u64 size;








 unsigned int flags;

 struct xe_bo *scratch;

 struct mutex lock;




 u64 *gsm;

 const struct xe_ggtt_pt_ops *pt_ops;

 struct drm_mm mm;

 unsigned int access_count;

 struct workqueue_struct *wq;
};
struct xe_ggtt_node {

 struct xe_ggtt *ggtt;

 struct drm_mm_node base;

 struct work_struct delayed_removal_work;

 bool invalidate_on_remove;
};
struct xe_ggtt_pt_ops {

 u64 (*pte_encode_flags)(struct xe_bo *bo, u16 pat_index);

 void (*ggtt_set_pte)(struct xe_ggtt *ggtt, u64 addr, u64 pte);
};
struct xe_device;
struct xe_vm;
struct xe_bo {

 struct ttm_buffer_object ttm;

 struct xe_bo *backup_obj;

 struct xe_bo *parent_obj;

 struct dma_buf *dma_buf;

 u32 flags;

 struct xe_vm *vm;

 struct xe_tile *tile;

 struct ttm_place placements[3];

 struct ttm_placement placement;

 struct xe_ggtt_node *ggtt_node[(1 + 1)];

 struct iosys_map vmap;

 struct ttm_bo_kmap_obj kmap;

 struct list_head pinned_link;




 struct xe_drm_client *client;



 struct list_head client_link;


 struct {




  u32 atomic_access;
 } attr;




 u32 pxp_key_instance;


 struct llist_node freed;

 int update_index;

 bool created;


 bool ccs_cleared;


 struct xe_bb *bb_ccs[XE_SRIOV_VF_CCS_CTX_COUNT];






 u16 cpu_caching;


 struct drm_pagemap_devmem devmem_allocation;


 struct list_head vram_userfault_link;





 u64 min_align;





 u32 madv_purgeable;
};
struct drm_gem_object;
struct drm_exec {



 u32 flags;




 struct ww_acquire_ctx ticket;




 unsigned int num_objects;




 unsigned int max_objects;




 struct drm_gem_object **objects;




 struct drm_gem_object *contended;




 struct drm_gem_object *prelocked;
};
struct drm_gpuvm;
struct drm_gpuvm_bo;
struct drm_gpuvm_ops;
enum drm_gpuva_flags {





 DRM_GPUVA_INVALIDATED = (1 << 0),






 DRM_GPUVA_SPARSE = (1 << 1),




 DRM_GPUVA_USERBITS = (1 << 2),
};
struct drm_gpuva {



 struct drm_gpuvm *vm;





 struct drm_gpuvm_bo *vm_bo;




 enum drm_gpuva_flags flags;




 struct {



  u64 addr;




  u64 range;
 } va;




 struct {



  u64 offset;




  struct drm_gem_object *obj;




  struct list_head entry;
 } gem;




 struct {



  struct rb_node node;
  struct list_head entry;




  u64 __subtree_last;
 } rb;
};
enum drm_gpuvm_flags {




 DRM_GPUVM_RESV_PROTECTED = ((((1UL))) << (0)),
 DRM_GPUVM_IMMEDIATE_MODE = ((((1UL))) << (1)),




 DRM_GPUVM_USERBITS = ((((1UL))) << (2)),
};
struct drm_gpuvm {



 const char *name;




 enum drm_gpuvm_flags flags;




 struct drm_device *drm;




 u64 mm_start;




 u64 mm_range;




 struct {



  struct rb_root_cached tree;




  struct list_head list;
 } rb;




 struct kref kref;







 struct drm_gpuva kernel_alloc_node;




 const struct drm_gpuvm_ops *ops;




 struct drm_gem_object *r_obj;




 struct {




  struct list_head list;





  struct list_head *local_list;




  spinlock_t lock;
 } extobj;




 struct {




  struct list_head list;





  struct list_head *local_list;




  spinlock_t lock;
 } evict;
};
struct drm_gpuvm_bo {




 struct drm_gpuvm *vm;





 struct drm_gem_object *obj;





 bool evicted;




 struct kref kref;




 struct {






  struct list_head gpuva;





  struct {




   struct list_head gem;





   struct list_head extobj;





   struct list_head evict;
  } entry;
 } list;
};
enum drm_gpuva_op_type {



 DRM_GPUVA_OP_MAP,




 DRM_GPUVA_OP_REMAP,




 DRM_GPUVA_OP_UNMAP,




 DRM_GPUVA_OP_PREFETCH,




 DRM_GPUVA_OP_DRIVER,
};
struct drm_gpuva_op_map {




 struct {



  u64 addr;




  u64 range;
 } va;




 struct {



  u64 offset;




  struct drm_gem_object *obj;
 } gem;
};
struct drm_gpuva_op_unmap {



 struct drm_gpuva *va;
 bool keep;
};
struct drm_gpuva_op_remap {



 struct drm_gpuva_op_map *prev;




 struct drm_gpuva_op_map *next;




 struct drm_gpuva_op_unmap *unmap;
};
struct drm_gpuva_op_prefetch {



 struct drm_gpuva *va;
};
struct drm_gpuva_op {






 struct list_head entry;




 enum drm_gpuva_op_type op;

 union {



  struct drm_gpuva_op_map map;




  struct drm_gpuva_op_remap remap;




  struct drm_gpuva_op_unmap unmap;




  struct drm_gpuva_op_prefetch prefetch;
 };
};
struct drm_gpuvm_ops {






 void (*vm_free)(struct drm_gpuvm *gpuvm);
 struct drm_gpuva_op *(*op_alloc)(void);
 void (*op_free)(struct drm_gpuva_op *op);
 struct drm_gpuvm_bo *(*vm_bo_alloc)(void);
 void (*vm_bo_free)(struct drm_gpuvm_bo *vm_bo);
 int (*vm_bo_validate)(struct drm_gpuvm_bo *vm_bo,
         struct drm_exec *exec);
 int (*sm_step_map)(struct drm_gpuva_op *op, void *priv);
 int (*sm_step_remap)(struct drm_gpuva_op *op, void *priv);
 int (*sm_step_unmap)(struct drm_gpuva_op *op, void *priv);
};
struct xe_range_fence_tree;
struct xe_range_fence_tree {

 struct rb_root_cached root;

 struct llist_head list;
};
struct xe_vm;
struct xe_vma;
struct xe_userptr_vm {




 struct list_head repin_list;




 spinlock_t invalidated_lock;
 struct list_head invalidated;
};
struct xe_bo;
struct xe_sync_entry;
struct xe_user_fence;
struct xe_vm;
struct xe_vma_mem_attr {

 struct {

  u32 migration_policy;







  u32 devmem_fd;
 } preferred_loc;







 u32 atomic_access;




 u16 default_pat_index;





 u16 pat_index;
};
struct xe_vma {

 struct drm_gpuva gpuva;






 union {

  struct list_head rebind;

  struct list_head destroy;
 } combined_links;

 union {

  struct dma_fence_cb destroy_cb;

  struct work_struct destroy_work;
 };
 u8 tile_invalidated;


 u8 tile_mask;
 u8 tile_present;


 u8 tile_staged;





 bool skip_invalidation;





 struct xe_user_fence *ufence;





 struct xe_vma_mem_attr attr;
};
struct xe_device;
struct xe_vm {

 struct drm_gpuvm gpuvm;


 struct {

  struct drm_gpusvm gpusvm;




  struct {

   spinlock_t lock;




   struct list_head range_list;




   struct work_struct work;
  } garbage_collector;
 } svm;

 struct xe_device *xe;


 struct xe_exec_queue *q[(1 + 1)];


 struct ttm_lru_bulk_move lru_bulk_move;

 u64 size;

 struct xe_pt *pt_root[(1 + 1)];
 struct xe_pt *scratch_pt[(1 + 1)][4];





 unsigned long flags;


 u64 composite_fence_ctx;

 u32 composite_fence_seqno;





 struct rw_semaphore lock;




 struct mutex snap_mutex;






 struct list_head rebind_list;






 struct work_struct destroy_work;





 struct xe_range_fence_tree rftree[(1 + 1)];

 const struct xe_pt_ops *pt_ops;


 struct xe_userptr_vm userptr;


 struct {




  unsigned int min_run_period_ms;

  struct list_head exec_queues;

  int num_exec_queues;




  bool rebind_deactivated;




  struct work_struct rebind_work;




  struct list_head pm_activate_link;
 } preempt;


 struct {

  u32 asid;




  struct xe_vma *last_fault_vma;
 } usm;


 struct {

  bool capture_once;
 } error_capture;
 struct {
  struct task_struct *validating;




  struct drm_exec *_exec;
 } validation;





 u64 tlb_flush_seqno;

 bool batch_invalidate_tlb;

 struct xe_file *xef;
};
struct xe_guc_pc;
enum xe_gt_idle_state {
 GT_IDLE_C0,
 GT_IDLE_C6,
 GT_IDLE_UNKNOWN,
};
struct xe_gt_idle {

 char name[16];

 u32 powergate_enable;

 u32 residency_multiplier;

 u64 cur_residency;

 u64 prev_residency;

 raw_spinlock_t lock;

 enum xe_gt_idle_state (*idle_status)(struct xe_guc_pc *pc);

 u64 (*idle_residency)(struct xe_guc_pc *pc);
};
struct xe_bo;
struct xe_gt_sriov_config {

 struct xe_ggtt_node *ggtt_region;

 struct xe_bo *lmem_obj;

 u16 num_ctxs;

 u16 begin_ctx;

 u16 num_dbs;

 u16 begin_db;

 u32 exec_quantum;

 u32 preempt_timeout;

 u32 sched_priority;

 u32 thresholds[(7 - 1)];
};
struct xe_gt_sriov_spare_config {

 u64 ggtt_size;

 u64 lmem_size;

 u16 num_ctxs;

 u16 num_dbs;
};
struct xe_gt_sriov_control_state {

 unsigned long state;


 struct completion done;


 struct list_head link;
};
struct xe_gt_sriov_pf_control {

 struct work_struct worker;


 struct list_head list;


 spinlock_t lock;
};
struct xe_gt_sriov_state_snapshot {

 struct {

  u32 *buff;

  u32 size;
 } guc;
};
struct xe_gt_sriov_pf_migration {

 bool supported;


 struct mutex snapshot_lock;
};
struct xe_gt_sriov_monitor {

 struct {

  unsigned int events[(7 - 1)];
 } guc;
};
struct xe_gt_sriov_guc_policies {
 bool sched_if_idle;
 bool reset_engine;
 u32 sample_period;
};
struct xe_gt_sriov_pf_policy {
 struct xe_gt_sriov_guc_policies guc;
};
struct xe_reg;
struct xe_gt_sriov_pf_service_version {
 u16 major;
 u16 minor;
};
struct xe_gt_sriov_pf_service_runtime_regs {
 const struct xe_reg *regs;
 u32 *values;
 u32 size;
};
struct xe_gt_sriov_pf_service {
 struct {
  struct xe_gt_sriov_pf_service_version base;
  struct xe_gt_sriov_pf_service_version latest;
 } version;
 struct xe_gt_sriov_pf_service_runtime_regs runtime;
};
struct xe_gt_sriov_metadata {

 struct xe_gt_sriov_config config;


 struct xe_gt_sriov_monitor monitor;


 struct xe_gt_sriov_control_state control;


 struct xe_gt_sriov_pf_service_version version;


 struct xe_gt_sriov_state_snapshot snapshot;
};
struct xe_gt_sriov_pf_workers {

 struct work_struct restart;
};
struct xe_gt_sriov_pf {
 struct xe_gt_sriov_pf_workers workers;
 struct xe_gt_sriov_pf_service service;
 struct xe_gt_sriov_pf_control control;
 struct xe_gt_sriov_pf_policy policy;
 struct xe_gt_sriov_pf_migration migration;
 struct xe_gt_sriov_spare_config spare;
 struct xe_gt_sriov_metadata *vfs;
};
struct xe_bo;
enum xe_uc_fw_status {
 XE_UC_FIRMWARE_NOT_SUPPORTED = -1,
 XE_UC_FIRMWARE_UNINITIALIZED = 0,
 XE_UC_FIRMWARE_DISABLED,
 XE_UC_FIRMWARE_SELECTED,
 XE_UC_FIRMWARE_MISSING,
 XE_UC_FIRMWARE_ERROR,
 XE_UC_FIRMWARE_AVAILABLE,
 XE_UC_FIRMWARE_INIT_FAIL,
 XE_UC_FIRMWARE_LOADABLE,
 XE_UC_FIRMWARE_LOAD_FAIL,
 XE_UC_FIRMWARE_TRANSFERRED,
 XE_UC_FIRMWARE_RUNNING,
 XE_UC_FIRMWARE_PRELOADED,
};
enum xe_uc_fw_type {
 XE_UC_FW_TYPE_GUC = 0,
 XE_UC_FW_TYPE_HUC,
 XE_UC_FW_TYPE_GSC,
 XE_UC_FW_NUM_TYPES
};
struct xe_uc_fw_version {

 u16 branch;

 u16 major;

 u16 minor;

 u16 patch;

 u16 build;
};
enum xe_uc_fw_version_types {
 XE_UC_FW_VER_RELEASE,
 XE_UC_FW_VER_COMPATIBILITY,
 XE_UC_FW_VER_TYPE_COUNT
};
struct xe_uc_fw {

 enum xe_uc_fw_type type;
 union {

  const enum xe_uc_fw_status status;




  enum xe_uc_fw_status __status;
 };

 const char *path;

 bool user_overridden;






 bool full_ver_required;

 size_t size;


 struct xe_bo *bo;


 bool has_gsc_headers;
 struct {

  struct xe_uc_fw_version wanted;




  enum xe_uc_fw_version_types wanted_type;

  struct xe_uc_fw_version found[XE_UC_FW_VER_TYPE_COUNT];
 } versions;


 u32 rsa_size;

 u32 ucode_size;

 u32 css_offset;


 u32 private_data_size;


 u32 build_type;
};
struct xe_gt_sriov_vf_selfconfig {

 u64 ggtt_base;

 u64 ggtt_size;

 s64 ggtt_shift;

 u64 lmem_size;

 u16 num_ctxs;

 u16 num_dbs;
};
struct xe_gt_sriov_vf_runtime {

 u32 gmdid;

 u32 regs_size;

 u32 num_regs;

 struct vf_runtime_reg {

  u32 offset;

  u32 value;
 } *regs;
};
struct xe_gt_sriov_vf {

 struct xe_uc_fw_version wanted_guc_version;

 struct xe_uc_fw_version guc_version;

 struct xe_gt_sriov_vf_selfconfig self_config;

 struct xe_gt_sriov_vf_runtime runtime;
};
enum xe_gt_stats_id {
 XE_GT_STATS_ID_SVM_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_TLB_INVAL,
 XE_GT_STATS_ID_SVM_TLB_INVAL_COUNT,
 XE_GT_STATS_ID_SVM_TLB_INVAL_US,
 XE_GT_STATS_ID_VMA_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_VMA_PAGEFAULT_KB,
 XE_GT_STATS_ID_SVM_4K_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_64K_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_2M_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_4K_VALID_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_64K_VALID_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_2M_VALID_PAGEFAULT_COUNT,
 XE_GT_STATS_ID_SVM_4K_PAGEFAULT_US,
 XE_GT_STATS_ID_SVM_64K_PAGEFAULT_US,
 XE_GT_STATS_ID_SVM_2M_PAGEFAULT_US,
 XE_GT_STATS_ID_SVM_4K_MIGRATE_COUNT,
 XE_GT_STATS_ID_SVM_64K_MIGRATE_COUNT,
 XE_GT_STATS_ID_SVM_2M_MIGRATE_COUNT,
 XE_GT_STATS_ID_SVM_4K_MIGRATE_US,
 XE_GT_STATS_ID_SVM_64K_MIGRATE_US,
 XE_GT_STATS_ID_SVM_2M_MIGRATE_US,
 XE_GT_STATS_ID_SVM_DEVICE_COPY_US,
 XE_GT_STATS_ID_SVM_4K_DEVICE_COPY_US,
 XE_GT_STATS_ID_SVM_64K_DEVICE_COPY_US,
 XE_GT_STATS_ID_SVM_2M_DEVICE_COPY_US,
 XE_GT_STATS_ID_SVM_CPU_COPY_US,
 XE_GT_STATS_ID_SVM_4K_CPU_COPY_US,
 XE_GT_STATS_ID_SVM_64K_CPU_COPY_US,
 XE_GT_STATS_ID_SVM_2M_CPU_COPY_US,
 XE_GT_STATS_ID_SVM_DEVICE_COPY_KB,
 XE_GT_STATS_ID_SVM_CPU_COPY_KB,
 XE_GT_STATS_ID_SVM_4K_GET_PAGES_US,
 XE_GT_STATS_ID_SVM_64K_GET_PAGES_US,
 XE_GT_STATS_ID_SVM_2M_GET_PAGES_US,
 XE_GT_STATS_ID_SVM_4K_BIND_US,
 XE_GT_STATS_ID_SVM_64K_BIND_US,
 XE_GT_STATS_ID_SVM_2M_BIND_US,

 __XE_GT_STATS_NUM_IDS,
};
struct drm_suballoc_manager {
 wait_queue_head_t wq;
 struct list_head *hole;
 struct list_head olist;
 struct list_head flist[32];
 size_t size;
 size_t align;
};
struct xe_bo;
struct xe_sa_manager {
 struct drm_suballoc_manager base;
 struct xe_bo *bo;
 struct xe_bo *shadow;

 struct mutex swap_guard;
 void *cpu_ptr;
 bool is_iomem;
};
struct xe_tlb_inval;
struct xe_tlb_inval_ops {
 int (*all)(struct xe_tlb_inval *tlb_inval, u32 seqno);
 int (*ggtt)(struct xe_tlb_inval *tlb_inval, u32 seqno);
 int (*ppgtt)(struct xe_tlb_inval *tlb_inval, u32 seqno, u64 start,
       u64 end, u32 asid);







 bool (*initialized)(struct xe_tlb_inval *tlb_inval);





 void (*flush)(struct xe_tlb_inval *tlb_inval);







 long (*timeout_delay)(struct xe_tlb_inval *tlb_inval);
};
struct xe_tlb_inval {

 void *private;

 struct xe_device *xe;

 const struct xe_tlb_inval_ops *ops;

 int seqno;

 struct mutex seqno_lock;




 int seqno_recv;




 struct list_head pending_fences;



 spinlock_t pending_lock;




 struct delayed_work fence_tdr;

 struct workqueue_struct *job_wq;

 spinlock_t lock;
};
struct xe_bo;
struct xe_exec_queue;
struct i915_gsc_proxy_component;
struct xe_gsc {

 struct xe_uc_fw fw;


 u32 security_version;


 struct xe_bo *private;


 struct xe_exec_queue *q;


 struct workqueue_struct *wq;


 struct work_struct work;


 spinlock_t lock;


 u32 work_actions;


 struct {

  struct i915_gsc_proxy_component *component;

  struct mutex mutex;

  bool component_added;

  bool started;

  struct xe_bo *bo;

  struct iosys_map to_gsc;

  struct iosys_map from_gsc;

  void *to_csme;

  void *from_csme;
 } proxy;
};
struct xe_bo;
struct xe_guc_ads {

 struct xe_bo *bo;




 struct xe_bo *um_queue_bo;

 size_t golden_lrc_size;

 u32 regset_size;

 u32 ads_waklv_size;

 u32 capture_size;
};
struct xe_sa_manager;
struct xe_guc_buf_cache {

 struct xe_sa_manager *sam;
};
struct guc_ct_buffer_desc {
 u32 head;
 u32 tail;
 u32 status;
 u32 reserved[13];
} __attribute__((__packed__));
struct xe_bo;
struct guc_ctb_info {

 u32 size;

 u32 resv_space;

 u32 head;

 u32 tail;

 u32 space;

 bool broken;
};
struct guc_ctb {

 struct iosys_map desc;

 struct iosys_map cmds;

 struct guc_ctb_info info;
};
struct guc_ctb_snapshot {

 struct guc_ct_buffer_desc desc;

 struct guc_ctb_info info;
};
struct xe_guc_ct_snapshot {

 bool ct_enabled;

 u32 g2h_outstanding;

 struct guc_ctb_snapshot g2h;

 struct guc_ctb_snapshot h2g;

 size_t ctb_size;

 u32 *ctb;
};
enum xe_guc_ct_state {
 XE_GUC_CT_STATE_NOT_INITIALIZED = 0,
 XE_GUC_CT_STATE_DISABLED,
 XE_GUC_CT_STATE_STOPPED,
 XE_GUC_CT_STATE_ENABLED,
};
struct xe_guc_ct {

 struct xe_bo *bo;

 struct mutex lock;

 spinlock_t fast_lock;

 struct {

  struct guc_ctb h2g;

  struct guc_ctb g2h;
 } ctbs;

 u32 g2h_outstanding;

 struct work_struct g2h_worker;

 struct delayed_work safe_mode_worker;

 enum xe_guc_ct_state state;

 u32 fence_seqno;

 struct xarray fence_lookup;

 wait_queue_head_t wq;

 wait_queue_head_t g2h_fence_wq;

 struct workqueue_struct *g2h_wq;

 u32 msg[(1u + 255)];

 u32 fast_msg[(1u + 255)];







};
struct guc_engine_activity {
 u16 change_num;
 u16 quanta_ratio;
 u32 last_update_tick;
 u64 active_ticks;
} __attribute__((__packed__));
struct guc_engine_activity_metadata {
 u32 guc_tsc_frequency_hz;
 u32 lag_latency_usec;
 u32 global_change_num;
 u32 reserved;
} __attribute__((__packed__));
struct engine_activity {

 u64 active;


 u64 last_cpu_ts;


 u64 quanta;


 u64 quanta_ns;






 u64 quanta_remainder_ns;


 u64 total;


 bool running;


 struct guc_engine_activity_metadata metadata;


 struct guc_engine_activity activity;
};
struct engine_activity_group {

 struct engine_activity engine[16][32];
};
struct engine_activity_buffer {

 struct xe_bo *activity_bo;


 struct xe_bo *metadata_bo;
};
struct xe_guc_engine_activity {

 u32 gpm_timestamp_shift;


 u32 num_activity_group;


 u32 num_functions;


 bool supported;






 struct engine_activity_group *eag;


 struct engine_activity_buffer device_buffer;


 struct engine_activity_buffer function_buffer;
};
struct xe_bo;
struct xe_guc_log_snapshot {

 size_t size;

 void **copy;

 int num_chunks;

 u64 ktime;

 u64 stamp;

 u32 level;

 struct xe_uc_fw_version ver_found;

 struct xe_uc_fw_version ver_want;

 const char *path;
};
struct xe_guc_log {

 u32 level;

 struct xe_bo *bo;

 struct {
  u32 sampled_overflow;
  u32 overflow;
  u32 flush;
 } stats[3];
};
struct xe_guc_pc {

 struct xe_bo *bo;

 atomic_t flush_freq_limit;

 u32 rp0_freq;

 u32 rpa_freq;

 u32 rpe_freq;

 u32 rpn_freq;

 u32 user_requested_min;

 u32 user_requested_max;

 u32 stashed_min_freq;

 u32 stashed_max_freq;

 struct mutex freq_lock;

 bool freq_ready;

 u32 power_profile;
};
struct xe_guc_relay {

 spinlock_t lock;


 struct work_struct worker;


 struct list_head pending_relays;


 struct list_head incoming_actions;


 mempool_t pool;


 u32 last_rid;
};
struct xe_guc_db_mgr {

 unsigned int count;

 unsigned long *bitmap;
};
struct xe_guc_id_mgr {

 unsigned long *bitmap;

 unsigned int total;

 unsigned int used;
};
struct xe_guc {

 struct xe_uc_fw fw;

 struct xe_guc_log log;

 struct xe_guc_ads ads;

 struct xe_guc_ct ct;

 struct xe_guc_buf_cache buf;

 struct xe_guc_state_capture *capture;

 struct xe_guc_pc pc;

 struct xe_guc_db_mgr dbm;


 struct {

  struct xe_bo *bo;

  bool owned;
 } g2g;


 struct {

  struct xe_guc_id_mgr idm;

  struct xarray exec_queue_lookup;

  atomic_t stopped;





  atomic_t reset_blocked;

  struct mutex lock;

  bool enabled;




  bool initialized;
 } submission_state;


 struct {

  struct xe_bo *bo;

  u32 size;
 } hwconfig;


 struct xe_guc_relay relay;


 struct xe_guc_engine_activity engine_activity;




 struct xe_reg notify_reg;

 u32 params[14];
};
struct xe_bo;
struct xe_huc {

 struct xe_uc_fw fw;


 struct xe_bo *gsc_pkt;
};
struct xe_wopcm {

 u32 size;

 struct {

  u32 base;

  u32 size;
 } guc;
};
struct xe_uc {

 struct xe_guc guc;

 struct xe_huc huc;

 struct xe_gsc gsc;

 struct xe_wopcm wopcm;
};
struct xe_exec_queue_ops;
struct xe_migrate;
struct xe_ring_ops;
enum xe_gt_type {
 XE_GT_TYPE_UNINITIALIZED,
 XE_GT_TYPE_MAIN,
 XE_GT_TYPE_MEDIA,
};
enum xe_gt_eu_type {
 XE_GT_EU_TYPE_SIMD8,
 XE_GT_EU_TYPE_SIMD16,
};
typedef unsigned long xe_dss_mask_t[((((32 * 3)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
typedef unsigned long xe_eu_mask_t[((((32 * 1)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
typedef unsigned long xe_l3_bank_mask_t[(((64) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
struct xe_mmio_range {
 u32 start;
 u32 end;
};
enum xe_steering_type {
 L3BANK,
 MSLICE,
 LNCF,
 DSS,
 OADDRM,
 SQIDI_PSMI,






 INSTANCE0,







 IMPLICIT_STEERING,
 NUM_STEERING_TYPES
};
struct xe_gt {

 struct xe_tile *tile;


 struct {

  enum xe_gt_type type;

  u32 reference_clock;

  u32 timestamp_base;





  u64 engine_mask;

  u32 gmdid;

  u8 id;

  u8 has_indirect_ring_state:1;
 } info;



 struct {

  atomic64_t counters[__XE_GT_STATS_NUM_IDS];
 } stats;







 struct xe_mmio mmio;







 struct {

  struct xe_force_wake fw;
 } pm;


 union {

  struct xe_gt_sriov_pf pf;

  struct xe_gt_sriov_vf vf;
 } sriov;




 struct xe_reg_sr reg_sr;


 struct {




  struct work_struct worker;
 } reset;


 struct xe_tlb_inval tlb_inval;







 u32 ccs_mode;


 struct {







  struct xe_sa_manager *bb_pool;




  u16 reserved_bcs_instance;

  struct workqueue_struct *pf_wq;

  struct workqueue_struct *acc_wq;







  struct pf_queue {

   struct xe_gt *gt;

   u32 *data;





   u32 num_dw;




   u16 tail;




   u16 head;

   spinlock_t lock;

   struct work_struct worker;
  } pf_queue[4];




  struct acc_queue {

   struct xe_gt *gt;

   u32 data[128];





   u16 tail;




   u16 head;

   spinlock_t lock;

   struct work_struct worker;
  } acc_queue[4];
 } usm;


 struct workqueue_struct *ordered_wq;


 struct xe_uc uc;


 struct xe_gt_idle gtidle;


 const struct xe_exec_queue_ops *exec_queue_ops;




 const struct xe_ring_ops *ring_ops[XE_ENGINE_CLASS_MAX];


 struct xe_hw_fence_irq fence_irq[XE_ENGINE_CLASS_MAX];


 void *default_lrc[XE_ENGINE_CLASS_MAX];


 struct xe_hw_engine hw_engines[XE_NUM_HW_ENGINES];


 struct xe_hw_engine_class_intf eclass[XE_ENGINE_CLASS_MAX];


 struct kobject *sysfs;


 struct kobject *freq;


 struct {

  u8 uc_index;

  u8 wb_index;
 } mocs;


 struct {

  xe_dss_mask_t g_dss_mask;


  xe_dss_mask_t c_dss_mask;


  xe_eu_mask_t eu_mask_per_dss;


  xe_l3_bank_mask_t l3_bank_mask;





  enum xe_gt_eu_type eu_type;
 } fuse_topo;


 struct {

  const struct xe_mmio_range *ranges;


  u16 group_target;

  u16 instance_target;

  bool initialized;
 } steering[NUM_STEERING_TYPES];





 unsigned int steering_dss_per_grp;





 spinlock_t mcr_lock;





 spinlock_t global_invl_lock;


 struct {

  unsigned long *gt;

  unsigned long *engine;

  unsigned long *lrc;

  unsigned long *oob;





  bool oob_initialized;
 } wa_active;


 struct {

  unsigned long *gt;

  unsigned long *engine;

  unsigned long *lrc;
 } tuning_active;


 struct {




  u64 mask;





  u8 instances_per_class[XE_ENGINE_CLASS_MAX];
 } user_engines;


 struct xe_oa_gt oa;


 struct xe_eu_stall_gt *eu_stall;
};
struct xe_device;
struct xe_device;
struct xe_vram_region;
typedef unsigned int insn_attr_t;
typedef unsigned char insn_byte_t;
typedef signed int insn_value_t;
struct insn_field {
 union {
  insn_value_t value;
  insn_byte_t bytes[4];
 };

 unsigned char got;
 unsigned char nbytes;
};
struct insn {
 struct insn_field prefixes;



 struct insn_field rex_prefix;
 union {
  struct insn_field vex_prefix;
  struct insn_field xop_prefix;
 };
 struct insn_field opcode;




 struct insn_field modrm;
 struct insn_field sib;
 struct insn_field displacement;
 union {
  struct insn_field immediate;
  struct insn_field moffset1;
  struct insn_field immediate1;
 };
 union {
  struct insn_field moffset2;
  struct insn_field immediate2;
 };

 int emulate_prefix_size;
 insn_attr_t attr;
 unsigned char opnd_bytes;
 unsigned char addr_bytes;
 unsigned char length;
 unsigned char x86_64;

 const insn_byte_t *kaddr;
 const insn_byte_t *end_kaddr;
 const insn_byte_t *next_byte;
};
struct pt_regs;
struct kprobe;
typedef u8 kprobe_opcode_t;
struct arch_specific_insn {

 kprobe_opcode_t *insn;







 unsigned boostable:1;
 unsigned char size;
 union {
  unsigned char opcode;
  struct {
   unsigned char type;
  } jcc;
  struct {
   unsigned char type;
   unsigned char asize;
  } loop;
  struct {
   unsigned char reg;
  } indirect;
 };
 s32 rel32;
 void (*emulate_op)(struct kprobe *p, struct pt_regs *regs);

 int tp_len;
};
struct kprobe;
struct pt_regs;
typedef int (*kprobe_pre_handler_t) (struct kprobe *, struct pt_regs *);
typedef void (*kprobe_post_handler_t) (struct kprobe *, struct pt_regs *,
           unsigned long flags);
struct kprobe {
 struct hlist_node hlist;


 struct list_head list;


 unsigned long nmissed;


 kprobe_opcode_t *addr;


 const char *symbol_name;


 unsigned int offset;


 kprobe_pre_handler_t pre_handler;


 kprobe_post_handler_t post_handler;


 kprobe_opcode_t opcode;


 struct arch_specific_insn ainsn;





 u32 flags;
};
struct pt_regs;
struct task_struct;
struct drm_printer;
struct drm_device;
struct drm_printer;
struct drm_file;
struct ttm_buffer_object;
struct dma_fence;
struct xe_exec_queue;
struct xe_file;
struct xe_sync_entry;
struct drm_exec;
struct gpu_buddy_block {

 u64 header;

 struct gpu_buddy_block *left;
 struct gpu_buddy_block *right;
 struct gpu_buddy_block *parent;

 void *private;







 union {
  struct rb_node rb;
  struct list_head link;
 };

 struct list_head tmp_link;
};
struct gpu_buddy {

 struct rb_root **free_trees;
 struct gpu_buddy_block **roots;





 unsigned int n_roots;
 unsigned int max_order;


 u64 chunk_size;
 u64 size;
 u64 avail;
 u64 clear_avail;
};
struct xe_ttm_vram_mgr {

 struct ttm_resource_manager manager;

 struct gpu_buddy mm;

 u64 visible_size;

 u64 visible_avail;

 u64 default_page_size;

 struct mutex lock;

 u32 mem_type;
};
struct xe_device;
struct xe_migrate;
struct xe_vram_region {

 struct xe_device *xe;





 u8 id;

 resource_size_t io_start;
 resource_size_t io_size;

 resource_size_t dpa_base;






 resource_size_t usable_size;






 resource_size_t actual_physical_size;

 void *mapping;

 struct xe_ttm_vram_mgr ttm;

 u32 placement;


 struct xe_migrate *migrate;

 struct dev_pagemap pagemap;




 struct drm_pagemap dpagemap;





 resource_size_t hpa_base;

};
struct sg_table;
struct drm_printer;
struct xe_device;
struct xe_gt;
struct xe_pat_table_entry {





 u32 value;




 u16 coh_mode;
};
u16 xe_pat_index_get_coh_mode(struct xe_device *xe, u16 pat_index);
struct dma_fence;
struct drm_exec;
struct xe_bo;
struct xe_device;
struct xe_exec_queue;
struct xe_sync_entry;
struct xe_tile;
struct xe_vm;
struct xe_vma;
struct xe_device;
struct xe_bo;
struct xe_gt;
struct xe_tile;
struct xe_vm;
struct xe_vma;
struct xe_vram_region;
/*@ requires \true; ensures \result == 0 || \result == 1; */

static bool madvise_args_are_sane(struct xe_device *xe, const struct drm_xe_madvise *args)
{
 if (({ int cond__ = !!(!args); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 227, "!args"); cond__; }))
  return false;

 if (({ int cond__ = !!(!(((args->start) & ((typeof(args->start))(0x00001000) - 1)) == 0)); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 230, "!IS_ALIGNED(args->start, SZ_4K)"); cond__; }))
  return false;

 if (({ int cond__ = !!(!(((args->range) & ((typeof(args->range))(0x00001000) - 1)) == 0)); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 233, "!IS_ALIGNED(args->range, SZ_4K)"); cond__; }))
  return false;

 if (({ int cond__ = !!(args->range < 0x00001000); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 236, "args->range < SZ_4K"); cond__; }))
  return false;

 switch (args->type) {
 case 0:
 {
  s32 fd = (s32)args->preferred_mem_loc.devmem_fd;

  if (({ int cond__ = !!(fd < -1); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 244, "fd < DRM_XE_PREFERRED_LOC_DEFAULT_SYSTEM"); cond__; }))
   return false;

  if (({ int cond__ = !!(args->preferred_mem_loc.migration_policy > 1); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 247, "args->preferred_mem_loc.migration_policy > DRM_XE_MIGRATE_ONLY_SYSTEM_PAGES"); cond__; })
                                          )
   return false;

  if (({ int cond__ = !!(args->preferred_mem_loc.pad); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 251, "args->preferred_mem_loc.pad"); cond__; }))
   return false;

  if (({ int cond__ = !!(args->preferred_mem_loc.reserved); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 254, "args->preferred_mem_loc.reserved"); cond__; }))
   return false;
  break;
 }
 case 1:
  if (({ int cond__ = !!(args->atomic.val > 3); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 259, "args->atomic.val > DRM_XE_ATOMIC_CPU"); cond__; }))
   return false;

  if (({ int cond__ = !!(args->atomic.pad); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 262, "args->atomic.pad"); cond__; }))
   return false;

  if (({ int cond__ = !!(args->atomic.reserved); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 265, "args->atomic.reserved"); cond__; }))
   return false;

  break;
 case 2:
 {
  u16 pat_index, coh_mode;

  if (({ int cond__ = !!(args->pat_index.val >= xe->pat.n_entries); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 273, "args->pat_index.val >= xe->pat.n_entries"); cond__; }))
   return false;

  pat_index = ({ typeof(args->pat_index.val) _i = (args->pat_index.val); typeof(xe->pat.n_entries) _s = (xe->pat.n_entries); unsigned long _mask = ({ typeof((_i)+(_s)) __idx = (_i); typeof(__idx) __sz = (_s); unsigned long __mask; asm volatile ("cmp %1,%2; sbb %0,%0" :"=r" (__mask) :"g" (__sz), "r" (__idx) :"cc"); __mask; }); do { __attribute__((__noreturn__)) extern void __compiletime_assert_1581(void) ; if (!(!(sizeof(_i) > sizeof(long)))) __compiletime_assert_1581(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_1582(void) ; if (!(!(sizeof(_s) > sizeof(long)))) __compiletime_assert_1582(); } while (0); (typeof(_i)) (_i & _mask); });
  coh_mode = xe_pat_index_get_coh_mode(xe, pat_index);
  if (({ int cond__ = !!(!coh_mode); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 278, "!coh_mode"); cond__; }))
   return false;

  if (({ int __ret_warn_on = !!(coh_mode > 2); if (__builtin_expect(!!(__ret_warn_on), 0)) do { __typeof__( (1 << 0)|(((9) << 8))) __flags = (1 << 0)|(((9) << 8)); ({ asm volatile("1583" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1583b" " - .\n\t" ".long " "3" "\n\t" ".popsection\n\t" : : "i" (1583)); }); do { asm volatile("1:\t" " " "ud2" " " "\n" ".pushsection __bug_table,\"aw\"\n" "2:\t" ".long " "1b" " - ." "\t# bug_entry::bug_addr\n" "\t" ".long " "%c0" " - ." "\t# bug_entry::file\n" "\t.word " "%c1" "\t# bug_entry::line\n" "\t.word " "%c2" "\t# bug_entry::flags\n" "\t.org 2b + " "%c3" "\n" ".popsection\n" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1b" " - .\n\t" ".long " "8" "\n\t" ".popsection\n\t" : : "i" ("drivers/gpu/drm/xe/xe_vm_madvise.c"), "i" (281), "i" (__flags), "i" (sizeof(struct bug_entry))); } while (0); ({ asm volatile("1584" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1584b" " - .\n\t" ".long " "4" "\n\t" ".popsection\n\t" : : "i" (1584)); }); } while (0); __builtin_expect(!!(__ret_warn_on), 0); }))
   return false;

  if (({ int cond__ = !!(args->pat_index.pad); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 284, "args->pat_index.pad"); cond__; }))
   return false;

  if (({ int cond__ = !!(args->pat_index.reserved); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 287, "args->pat_index.reserved"); cond__; }))
   return false;
  break;
 }
 default:
  if (({ int cond__ = !!(1); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 292, "1"); cond__; }))
   return false;
 }

 if (({ int cond__ = !!(args->reserved[0] || args->reserved[1]); if (cond__) __drm_dev_dbg(((void *)0), __drm_to_dev(&(xe)->drm), DRM_UT_DRIVER, "Ioctl argument check failed at %s:%d: %s", "drivers/gpu/drm/xe/xe_vm_madvise.c", 296, "args->reserved[0] || args->reserved[1]"); cond__; }))
  return false;

 return true;
}

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
int main(void) {
  struct xe_device * xe;
  const struct drm_xe_madvise * args;
  __CPROVER_assume(((((__int128)1)) != 0));
  extern void *malloc(unsigned long);
  { int c_args; args = c_args ? 0 : malloc(sizeof(struct drm_xe_madvise)); }
  { int c_xe; xe = c_xe ? 0 : malloc(sizeof(struct xe_device)); }
  bool bv_r = madvise_args_are_sane(xe, args);
  __CPROVER_assert((((__int128)((((__int128)(((__int128)bv_r) == ((__int128)0ULL))) != 0) || (((__int128)(((__int128)bv_r) == ((__int128)1ULL))) != 0))) != 0), "ensures");
  return 0;
}
