typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __size_t;
typedef unsigned char u_char;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int32_t int32_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __size_t size_t;
typedef _Bool bool;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct thread;
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct _cpuset { unsigned long __bits[(((((1)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
typedef struct _cpuset cpuset_t;
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rm_queue {
 struct rm_queue *volatile rmq_next;
 struct rm_queue *volatile rmq_prev;
};
struct rmlock {
 struct lock_object lock_object;
 volatile cpuset_t rm_writecpus;
 struct { struct rm_priotracker *lh_first; } rm_activeReaders;
 union {
  struct lock_object _rm_wlock_object;
  struct mtx _rm_lock_mtx;
  struct sx _rm_lock_sx;
 } _rm_lock;
};
struct rm_priotracker {
 struct rm_queue rmp_cpuQueue;
 struct rmlock *rmp_rmlock;
 struct thread *rmp_thread;
 int rmp_flags;
 struct { struct rm_priotracker *le_next; struct rm_priotracker **le_prev; } rmp_qentry;
};
static __inline  struct thread *
__curthread(void)
;
static __inline int atomic_fcmpset_long(volatile u_long *dst, u_long *expect, u_long src) ;
void __mtx_lock_sleep(volatile uintptr_t *c, uintptr_t v);
void __mtx_unlock_sleep(volatile uintptr_t *c, uintptr_t v);
struct helper;
struct osd;
typedef int (*hhook_func_t)(int32_t hhook_type, int32_t hhook_id, void *udata,
    void *ctx_data, void *hdata, struct osd *hosd);
struct hookinfo {
 hhook_func_t hook_func;
 struct helper *hook_helper;
 void *hook_udata;
 int32_t hook_id;
 int32_t hook_type;
};
struct hhook_head {
 struct hhook_list { struct hhook *stqh_first; struct hhook **stqh_last; } hhh_hooks;
 struct rmlock hhh_lock;
 uintptr_t hhh_vid;
 int32_t hhh_id;
 int32_t hhh_nhooks;
 int32_t hhh_type;
 uint32_t hhh_flags;
 volatile uint32_t hhh_refcount;
 struct { struct hhook_head *le_next; struct hhook_head **le_prev; } hhh_next;
 struct { struct hhook_head *le_next; struct hhook_head **le_prev; } hhh_vnext;
};
int hhook_add_hook(struct hhook_head *hhh, const struct hookinfo *hki,
    uint32_t flags);
int hhook_add_hook_lookup(const struct hookinfo *hki, uint32_t flags);
struct helper;
struct hookinfo;
struct osd;
struct lock_object;
struct lock_object;
struct malloc_type;
struct mtx;
struct thread;
struct malloc_type;
struct malloc_type_stats {
 uint64_t mts_memalloced;
 uint64_t mts_memfreed;
 uint64_t mts_numallocs;
 uint64_t mts_numfrees;
 uint64_t mts_size;
 uint64_t _mts_reserved1;
 uint64_t _mts_reserved2;
 uint64_t _mts_reserved3;
};
struct malloc_type_internal {
 uint32_t mti_probes[2];

 u_char mti_zone;
 struct malloc_type_stats *mti_stats;
 u_long mti_spare[8];
};
struct malloc_type {
 struct malloc_type *ks_next;
 u_long ks_version;
 const char *ks_shortdesc;
 struct malloc_type_internal ks_mti;
};
void free(void *addr, struct malloc_type *type);
void *malloc(size_t size, struct malloc_type *type, int flags) 
      ;
struct uma_zone;
typedef struct uma_zone * uma_zone_t;
struct helper {
 int (*mod_init) (void);
 int (*mod_destroy) (void);
 char h_name[16];
 uma_zone_t h_zone;
 struct hookinfo *h_hooks;
 uint32_t h_nhooks;
 uint32_t h_classes;
 int32_t h_id;
 volatile uint32_t h_refcount;
 uint16_t h_flags;
 struct { struct helper *tqe_next; struct helper **tqe_prev; } h_next;
};
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
static __inline u_int
refcount_acquire(volatile u_int *count)
;
static __inline bool
refcount_release(volatile u_int *count)
;
struct hhook {
 hhook_func_t hhk_func;
 struct helper *hhk_helper;
 void *hhk_udata;
 struct { struct hhook *stqe_next; } hhk_next;
};
static struct malloc_type M_HHOOK[1] = { { .ks_next = ((void *)0), .ks_version = 2024073001, .ks_shortdesc = "hhook", } };
struct hhookheadhead { struct hhook_head *lh_first; };
struct hhookheadhead hhook_head_list;
static struct mtx hhook_head_list_lock;
static uint32_t n_hhookheads;
int
hhook_add_hook(struct hhook_head *hhh, const struct hookinfo *hki, uint32_t flags)
;
/*@ requires hki != ((void *)0); ensures \result == 0 || (\result >= 1 && \result <= 134); */

int
hhook_add_hook_lookup(const struct hookinfo *hki, uint32_t flags)
{
 struct hhook_head **heads_to_hook, *hhh;
 int error, i, n_heads_to_hook;

tryagain:
 error = i = 0;





 n_heads_to_hook = n_hhookheads;
 heads_to_hook = ({ void *_malloc_item; size_t _size = (n_heads_to_hook * sizeof(struct hhook_head *)); if (__builtin_constant_p(n_heads_to_hook * sizeof(struct hhook_head *)) && __builtin_constant_p(flags & 0x00000001 ? 0x0002 : 0x0001) && ((flags & 0x00000001 ? 0x0002 : 0x0001) & 0x0100) != 0) { _malloc_item = malloc(_size, M_HHOOK, (flags & 0x00000001 ? 0x0002 : 0x0001) &~ 0x0100); if (((flags & 0x00000001 ? 0x0002 : 0x0001) & 0x0002) != 0 || __builtin_expect((_malloc_item != ((void *)0)), 1)) __builtin_memset((_malloc_item), (0), (_size)); } else { _malloc_item = malloc(_size, M_HHOOK, flags & 0x00000001 ? 0x0002 : 0x0001); } _malloc_item; })
                                                         ;
 if (heads_to_hook == ((void *)0))
  return (12);

 __extension__ ({ uintptr_t _tid = (uintptr_t)((__curthread())); uintptr_t _v = 0x00000000; if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&hhook_head_list_lock)))))->mtx_lock, &_v, (_tid))), 0)) __mtx_lock_sleep(&(((((&hhook_head_list_lock)))))->mtx_lock, _v); (void)0; });
 for ((hhh) = (((&hhook_head_list))->lh_first); (hhh); (hhh) = (((hhh))->hhh_next.le_next)) {
  if (hhh->hhh_type == hki->hook_type &&
      hhh->hhh_id == hki->hook_id) {
   if (i < n_heads_to_hook) {
    heads_to_hook[i] = hhh;
    refcount_acquire(&heads_to_hook[i]->hhh_refcount);
    i++;
   } else {






    for (i--; i >= 0; i--)
     refcount_release(&heads_to_hook[i]->hhh_refcount);
    free(heads_to_hook, M_HHOOK);
    __extension__ ({ uintptr_t _v = (uintptr_t)((__curthread())); if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&hhook_head_list_lock)))))->mtx_lock, (&_v), 0x00000000)), 0)) __mtx_unlock_sleep(&(((((&hhook_head_list_lock)))))->mtx_lock, _v); (void)0; });
    goto tryagain;
   }
  }
 }
 __extension__ ({ uintptr_t _v = (uintptr_t)((__curthread())); if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&hhook_head_list_lock)))))->mtx_lock, (&_v), 0x00000000)), 0)) __mtx_unlock_sleep(&(((((&hhook_head_list_lock)))))->mtx_lock, _v); (void)0; });

 for (i--; i >= 0; i--) {
  if (!error)
   error = hhook_add_hook(heads_to_hook[i], hki, flags);
  refcount_release(&heads_to_hook[i]->hhh_refcount);
 }

 free(heads_to_hook, M_HHOOK);

 return (error);
}
