typedef unsigned int u_int;
static u_int db_raw_cnt;
static int db_raw_space(void);
/*@ requires 1; ensures \result == (db_raw_cnt < 512); */

static int
db_raw_space(void)
{

 return (db_raw_cnt < 512);
}
