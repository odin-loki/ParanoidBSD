typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
typedef u32 uint32_t;
typedef u64 uint64_t;
/*@ requires usec <= 4294967295; ensures \result == (32768 * usec + 999999) / 1000000; */

static inline    u32 omap_usec_to_32k(u32 usec)
{
 return ({ unsigned long long _tmp = ((unsigned long long)(32768ULL * (u64)usec) + (1000000ULL) - 1); ({ uint32_t __base = ((1000000ULL)); uint32_t __rem; __rem = ((uint64_t)(_tmp)) % __base; (_tmp) = ((uint64_t)(_tmp)) / __base; __rem; }); _tmp; });
}
