typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __int64_t __off_t;
typedef union {
 char __mbstate8[128];
 __int64_t _mbstateL;
} __mbstate_t;
int * __error(void);
typedef __size_t size_t;
struct pthread;
struct pthread_mutex;
struct pthread;
typedef __off_t fpos_t;
typedef __off_t off_t;
struct __sbuf {
 unsigned char *_base;
 int _size;
};
struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (* _close)(void *);
 int (* _read)(void *, char *, int);
 fpos_t (* _seek)(void *, fpos_t, int);
 int (* _write)(void *, const char *, int);


 struct __sbuf _ub;
 unsigned char *_up;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;

 struct pthread_mutex *_fl_mutex;
 struct pthread *_fl_owner;
 int _fl_count;
 int _orientation;
 __mbstate_t _mbstate;
 int _flags2;
};
typedef struct __sFILE FILE;
extern FILE *__stderrp;
int fprintf(FILE * restrict, const char * restrict, ...);
void *realloc(void *, size_t)  ;
void *(memcpy)(void * restrict, const void * restrict, size_t);
char *strerror(int);
typedef struct line {
 struct line *q_forw;
 struct line *q_back;
 off_t seek;
 int len;
} line_t;
typedef struct undo {
 int type;
 line_t *h;
 line_t *t;
} undo_t;
int modified;
int mutex;
int sigflags;
long addr_last;
long current_addr;
const char *errmsg = "";
undo_t *ref_push_undo_stack(int type, long from, long to);
char *ref_get_sbuf_line(line_t *lp);
const char *ref_put_sbuf_line(const char *cs);
line_t *ref_get_addressed_line_node(long n);
int ref_join_lines(long from, long to);
int ref_delete_lines(long from, long to);
void ref_handle_hup(int signo);
void ref_handle_int(int signo);
undo_t *
ref_push_undo_stack(int type, long from, long to)
;
char *
ref_get_sbuf_line(line_t *lp)
;
const char *
ref_put_sbuf_line(const char *cs)
;
line_t *
ref_get_addressed_line_node(long n)
;
/*@ requires 1 <= from && from <= to && to <= addr_last; ensures (\result == 0) || (\result == (-2)); */

int
ref_join_lines(long from, long to)
{
 static char *buf = ((void *)0);
 static int n;

 char *s;
 int size = 0;
 line_t *bp, *ep;

 ep = ref_get_addressed_line_node(((to) + 1 > (addr_last) ? 0 : (to) + 1));
 bp = ref_get_addressed_line_node(from);
 for (; bp != ep; bp = bp->q_forw) {
  if ((s = ref_get_sbuf_line(bp)) == ((void *)0))
   return (-2);
  if ((size + bp->len) > (n)) { size_t ti = (n); char *ts; mutex++; if ((ts = (char *) realloc((buf), ti += (((size + bp->len)) > (512) ? ((size + bp->len)) : (512)))) == ((void *)0)) { fprintf(__stderrp, "%s\n", strerror((* __error()))); errmsg = "out of memory"; if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); }; return (-2); } (n) = ti; (buf) = ts; if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); }; };
  memcpy(buf + size, s, bp->len);
  size += bp->len;
 }
 if ((size + 2) > (n)) { size_t ti = (n); char *ts; mutex++; if ((ts = (char *) realloc((buf), ti += (((size + 2)) > (512) ? ((size + 2)) : (512)))) == ((void *)0)) { fprintf(__stderrp, "%s\n", strerror((* __error()))); errmsg = "out of memory"; if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); }; return (-2); } (n) = ti; (buf) = ts; if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); }; };
 memcpy(buf + size, "\n", 2);
 if (ref_delete_lines(from, to) < 0)
  return (-2);
 current_addr = from - 1;
 mutex++;
 if (ref_put_sbuf_line(buf) == ((void *)0) ||
     ref_push_undo_stack(0, current_addr, current_addr) == ((void *)0)) {
  if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); };
  return (-2);
 }
 modified = 1;
 if (--mutex == 0) { if (sigflags & (1 << (1 - 1))) ref_handle_hup(1); if (sigflags & (1 << (2 - 1))) ref_handle_int(2); };
 return 0;
}
int
ref_delete_lines(long from, long to)
;
void
ref_handle_hup(int signo)
;
void
ref_handle_int(int signo)
;
