typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u16 u16;
typedef __u32 u32;
/*@ requires 0 <= port_id <= 65534; ensures \result == (u32)port_id + 1; */

static inline    u32 __to_ib_port_num(u16 port_id)
{
 return (u32)port_id + 1;
}
