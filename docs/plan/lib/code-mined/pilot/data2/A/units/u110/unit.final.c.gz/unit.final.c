typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef _Bool bool;
typedef __kernel_ssize_t ssize_t;
enum _cache_table_type {
 CACHE_L1_INST = 1,
 CACHE_L1_DATA,
 CACHE_L2,
 CACHE_L3

} __attribute__((__packed__));
_Static_assert(sizeof(enum _cache_table_type) == 1, "sizeof(enum _cache_table_type) == 1");
enum _tlb_table_type {
 TLB_INST_4K = (CACHE_L3 + 1),
 TLB_INST_4M,
 TLB_INST_2M_4M,
 TLB_INST_ALL,

 TLB_DATA_4K,
 TLB_DATA_4M,
 TLB_DATA_2M_4M,
 TLB_DATA_4K_4M,
 TLB_DATA_1G,
 TLB_DATA_1G_2M_4M,

 TLB_DATA0_4K,
 TLB_DATA0_4M,
 TLB_DATA0_2M_4M,

 STLB_4K,
 STLB_4K_2M,
} __attribute__((__packed__));
_Static_assert(sizeof(enum _tlb_table_type) == 1, "sizeof(enum _tlb_table_type) == 1");
static inline     void
generic___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
generic___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
generic_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
generic_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
const_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
arch___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
arch___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
arch_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
arch_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
static inline     void
___set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     void
___change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_set_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_clear_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
___test_and_change_bit(unsigned long nr, volatile unsigned long *addr)
;
static inline     bool
_test_bit(unsigned long nr, const volatile unsigned long *addr)
;
static inline     bool
_test_bit_acquire(unsigned long nr, const volatile unsigned long *addr)
;
_Static_assert(__builtin_types_compatible_p(typeof(arch___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(generic___set_bit), typeof(generic___set_bit)) && __builtin_types_compatible_p(typeof(___set_bit), typeof(generic___set_bit)), "__same_type(arch___set_bit, generic___set_bit) && __same_type(const___set_bit, generic___set_bit) && __same_type(___set_bit, generic___set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(generic___clear_bit), typeof(generic___clear_bit)) && __builtin_types_compatible_p(typeof(___clear_bit), typeof(generic___clear_bit)), "__same_type(arch___clear_bit, generic___clear_bit) && __same_type(const___clear_bit, generic___clear_bit) && __same_type(___clear_bit, generic___clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(generic___change_bit), typeof(generic___change_bit)) && __builtin_types_compatible_p(typeof(___change_bit), typeof(generic___change_bit)), "__same_type(arch___change_bit, generic___change_bit) && __same_type(const___change_bit, generic___change_bit) && __same_type(___change_bit, generic___change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_set_bit), typeof(generic___test_and_set_bit)) && __builtin_types_compatible_p(typeof(___test_and_set_bit), typeof(generic___test_and_set_bit)), "__same_type(arch___test_and_set_bit, generic___test_and_set_bit) && __same_type(const___test_and_set_bit, generic___test_and_set_bit) && __same_type(___test_and_set_bit, generic___test_and_set_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_clear_bit), typeof(generic___test_and_clear_bit)) && __builtin_types_compatible_p(typeof(___test_and_clear_bit), typeof(generic___test_and_clear_bit)), "__same_type(arch___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(const___test_and_clear_bit, generic___test_and_clear_bit) && __same_type(___test_and_clear_bit, generic___test_and_clear_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(generic___test_and_change_bit), typeof(generic___test_and_change_bit)) && __builtin_types_compatible_p(typeof(___test_and_change_bit), typeof(generic___test_and_change_bit)), "__same_type(arch___test_and_change_bit, generic___test_and_change_bit) && __same_type(const___test_and_change_bit, generic___test_and_change_bit) && __same_type(___test_and_change_bit, generic___test_and_change_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(const_test_bit), typeof(generic_test_bit)) && __builtin_types_compatible_p(typeof(_test_bit), typeof(generic_test_bit)), "__same_type(arch_test_bit, generic_test_bit) && __same_type(const_test_bit, generic_test_bit) && __same_type(_test_bit, generic_test_bit)");
_Static_assert(__builtin_types_compatible_p(typeof(arch_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(generic_test_bit_acquire), typeof(generic_test_bit_acquire)) && __builtin_types_compatible_p(typeof(_test_bit_acquire), typeof(generic_test_bit_acquire)), "__same_type(arch_test_bit_acquire, generic_test_bit_acquire) && __same_type(const_test_bit_acquire, generic_test_bit_acquire) && __same_type(_test_bit_acquire, generic_test_bit_acquire)");
enum mcu_msg_type {
 MCU_MSG_TYPE_INIT = 0x0000,
 MCU_MSG_TYPE_CREATE_CHANNEL = 0x0005,
 MCU_MSG_TYPE_DESTROY_CHANNEL = 0x0006,
 MCU_MSG_TYPE_ENCODE_FRAME = 0x0007,
 MCU_MSG_TYPE_PUT_STREAM_BUFFER = 0x0012,
 MCU_MSG_TYPE_PUSH_BUFFER_INTERMEDIATE = 0x000e,
 MCU_MSG_TYPE_PUSH_BUFFER_REFERENCE = 0x000f,
};
enum mcu_msg_version {
 MCU_MSG_VERSION_2018_2,
 MCU_MSG_VERSION_2019_2,
};
struct mcu_msg_header {
 enum mcu_msg_type type;
 enum mcu_msg_version version;
};
struct mcu_msg_create_channel_response {
 struct mcu_msg_header header;
 u32 channel_id;
 u32 user_id;
 u32 options;
 u32 num_core;
 u32 num_ref_idx_l0;
 u32 num_ref_idx_l1;
 u32 int_buffers_count;
 u32 int_buffers_size;
 u32 rec_buffers_count;
 u32 rec_buffers_size;
 u32 reserved;
 u32 error_code;
};
/*@ requires \true; ensures \result >= 10 * sizeof(u32); */

static ssize_t
allegro_dec_create_channel(struct mcu_msg_create_channel_response *msg,
      u32 *src)
{
 enum mcu_msg_version version = msg->header.version;
 unsigned int i = 0;

 msg->channel_id = src[i++];
 msg->user_id = src[i++];




 if (version < MCU_MSG_VERSION_2019_2) {
  msg->options = src[i++];
  msg->num_core = src[i++];
  msg->num_ref_idx_l0 = ({ ({ do { __attribute__((__noreturn__)) extern void __compiletime_assert_637(void) ; if (!(!(!__builtin_constant_p(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))))))) __compiletime_assert_637(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_638(void) ; if (!(!((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))) == 0))) __compiletime_assert_638(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_639(void) ; if (!(!(__builtin_constant_p(0U) ? ~((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))) >> __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))))) & (0 + (0U)) : 0))) __compiletime_assert_639(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_640(void) ; if (!(!(((typeof( _Generic((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))), char: (unsigned char)0, unsigned char: (unsigned char)0, signed char: (unsigned char)0, unsigned short: (unsigned short)0, signed short: (unsigned short)0, unsigned int: (unsigned int)0, signed int: (unsigned int)0, unsigned long: (unsigned long)0, signed long: (unsigned long)0, unsigned long long: (unsigned long long)0, signed long long: (unsigned long long)0, default: (((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))))))(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))))) > ((typeof( _Generic((src[i]), char: (unsigned char)0, unsigned char: (unsigned char)0, signed char: (unsigned char)0, unsigned short: (unsigned short)0, signed short: (unsigned short)0, unsigned int: (unsigned int)0, signed int: (unsigned int)0, unsigned long: (unsigned long)0, signed long: (unsigned long)0, unsigned long long: (unsigned long long)0, signed long long: (unsigned long long)0, default: (src[i]))))(~0ull))))) __compiletime_assert_640(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_641(void) ; if (!(!((((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))) + (1ULL << __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))))) & (((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))) + (1ULL << __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))))) - 1)) != 0))) __compiletime_assert_641(); } while (0); }); (typeof(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7)))))))(((src[i]) & (((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))))) >> __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((4) > (7)) * 0l)) : (int *)8))), (4) > (7), false)), "const_true((4) > (7))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (4) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (7))))))); });
  msg->num_ref_idx_l1 = ({ ({ do { __attribute__((__noreturn__)) extern void __compiletime_assert_642(void) ; if (!(!(!__builtin_constant_p(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11))))))))) __compiletime_assert_642(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_643(void) ; if (!(!((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))) == 0))) __compiletime_assert_643(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_644(void) ; if (!(!(__builtin_constant_p(0U) ? ~((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))) >> __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11))))))) & (0 + (0U)) : 0))) __compiletime_assert_644(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_645(void) ; if (!(!(((typeof( _Generic((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))), char: (unsigned char)0, unsigned char: (unsigned char)0, signed char: (unsigned char)0, unsigned short: (unsigned short)0, signed short: (unsigned short)0, unsigned int: (unsigned int)0, signed int: (unsigned int)0, unsigned long: (unsigned long)0, signed long: (unsigned long)0, unsigned long long: (unsigned long long)0, signed long long: (unsigned long long)0, default: (((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))))))(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11))))))) > ((typeof( _Generic((src[i++]), char: (unsigned char)0, unsigned char: (unsigned char)0, signed char: (unsigned char)0, unsigned short: (unsigned short)0, signed short: (unsigned short)0, unsigned int: (unsigned int)0, signed int: (unsigned int)0, unsigned long: (unsigned long)0, signed long: (unsigned long)0, unsigned long long: (unsigned long long)0, signed long long: (unsigned long long)0, default: (src[i++]))))(~0ull))))) __compiletime_assert_645(); } while (0); do { __attribute__((__noreturn__)) extern void __compiletime_assert_646(void) ; if (!(!((((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))) + (1ULL << __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))))) & (((((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))) + (1ULL << __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))))) - 1)) != 0))) __compiletime_assert_646(); } while (0); }); (typeof(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11)))))))(((src[i++]) & (((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11))))))) >> __builtin_ctzll(((unsigned long)(((int)sizeof(struct {_Static_assert(!(__builtin_choose_expr((sizeof(int) == sizeof(*(8 ? ((void *)((long)((8) > (11)) * 0l)) : (int *)8))), (8) > (11), false)), "const_true((8) > (11))" " is true");})) + (((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) << (8) & ((typeof(unsigned long))((((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))) - 1) + ((typeof(unsigned long))1 << (8*sizeof(typeof(unsigned long)) - 1 - (((typeof(unsigned long))(-1)) < ( typeof(unsigned long))1))))) >> ((sizeof(unsigned long) * 8) - 1 - (11))))))); });
 }
 msg->int_buffers_count = src[i++];
 msg->int_buffers_size = src[i++];
 msg->rec_buffers_count = src[i++];
 msg->rec_buffers_size = src[i++];
 msg->reserved = src[i++];
 msg->error_code = src[i++];

 return i * sizeof(*src);
}
