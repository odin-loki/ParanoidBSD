enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == (value <= 123 && value >= -128); */

static bool is_imm8_jmp_offset(int value)
{
 return value <= 123 && value >= -128;
}
