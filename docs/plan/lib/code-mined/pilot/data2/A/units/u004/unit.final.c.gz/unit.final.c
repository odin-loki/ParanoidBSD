typedef unsigned char __uint8_t;
typedef unsigned short int __uint16_t;
typedef unsigned int __uint32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint16_t u_int16_t;
extern uint16_t ntohs (uint16_t __netshort)
      ;
/*@ requires len >= 0; ensures \result <= 0xffff; */

static uint32_t raw_checksum(uint8_t *buf, int len, uint32_t sum)
{
 int i;

 for (i = 0; i < (len & ~1U); i += 2) {
  sum += (u_int16_t)ntohs(*((u_int16_t *)(buf + i)));
  if (sum > 0xffff)
   sum -= 0xffff;
 }

 if (i < len) {
  sum += buf[i] << 8;
  if (sum > 0xffff)
   sum -= 0xffff;
 }

 return sum;
}
