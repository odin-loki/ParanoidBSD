int sqlite3_release_memory(int);
/*@ requires n >= 0; ensures \result >= 0; */

int sqlite3_release_memory(int n){






  (void)(n);
  return 0;

}
