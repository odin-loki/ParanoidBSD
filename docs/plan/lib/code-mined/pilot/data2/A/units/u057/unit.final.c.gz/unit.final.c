enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == 0; */

static inline    int zswap_swapon(int type, unsigned long nr_pages)
{
 return 0;
}
