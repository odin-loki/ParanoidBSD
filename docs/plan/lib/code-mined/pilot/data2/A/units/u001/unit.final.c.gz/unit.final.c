enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == (val < (1UL << 10)); */

static inline    bool is_10b_uint(unsigned long val)
{
 return val < (1UL << 10);
}
