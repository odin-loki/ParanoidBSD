typedef struct ocs_list_s ocs_list_t;
struct ocs_list_s {
 uint32_t magic;
 ocs_list_t *next;
 ocs_list_t *prev;
 uint32_t offset;
};
typedef ocs_list_t ocs_list_link_t;
/*@ requires link != NULL; ensures \result == (link->next != NULL); */

static inline int32_t
ocs_list_on_list(ocs_list_link_t *link)
{
 return (link->next != NULL);
}
