typedef __signed__ char __s8;
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __s8 s8;
typedef __u8 u8;
typedef __u16 u16;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef __u16 __be16;
typedef __u32 __be32;
typedef __u64 __be64;
struct stat {
 __kernel_ulong_t st_dev;
 __kernel_ulong_t st_ino;
 __kernel_ulong_t st_nlink;

 unsigned int st_mode;
 unsigned int st_uid;
 unsigned int st_gid;
 unsigned int __pad0;
 __kernel_ulong_t st_rdev;
 __kernel_long_t st_size;
 __kernel_long_t st_blksize;
 __kernel_long_t st_blocks;

 __kernel_ulong_t st_atime;
 __kernel_ulong_t st_atime_nsec;
 __kernel_ulong_t st_mtime;
 __kernel_ulong_t st_mtime_nsec;
 __kernel_ulong_t st_ctime;
 __kernel_ulong_t st_ctime_nsec;
 __kernel_long_t __unused[3];
};
struct qm_fd {
 union {
  struct {
   u8 cfg8b_w1;
   u8 bpid;
   u8 cfg8b_w3;
   u8 addr_hi;
   __be32 addr_lo;
  } __attribute__((__packed__));
  __be64 data;
 };
 __be32 cfg;
 union {
  __be32 cmd;
  __be32 status;
 };
} ;
struct qm_dqrr_entry {
 u8 verb;
 u8 stat;
 __be16 seqnum;
 u8 tok;
 u8 __reserved2[3];
 __be32 fqid;
 __be32 context_b;
 struct qm_fd fd;
 u8 __reserved4[32];
} __attribute__((__packed__)) ;
union qm_mr_entry {
 struct {
  u8 verb;
  u8 __reserved[63];
 };
 struct {
  u8 verb;
  u8 dca;
  __be16 seqnum;
  u8 rc;
  u8 __reserved[3];
  __be32 fqid;
  __be32 tag;
  struct qm_fd fd;
  u8 __reserved1[32];
 } __attribute__((__packed__))  ern;
 struct {
  u8 verb;
  u8 fqs;
  u8 __reserved1[6];
  __be32 fqid;
  __be32 context_b;
  u8 __reserved2[48];
 } __attribute__((__packed__)) fq;
};
struct qm_fqd_stashing {

 u8 exclusive;

 u8 cl;
};
struct qm_fqd_oac {

 u8 oac;

 s8 oal;
};
struct qm_fqd {

 u8 orpc;
 u8 cgid;
 __be16 fq_ctrl;
 __be16 dest_wq;
 __be16 ics_cred;






 union {
  __be16 td;
  struct qm_fqd_oac oac_init;
 };
 __be32 context_b;
 union {

  __be64 opaque;
  struct {
   __be32 hi;
   __be32 lo;
  };


  struct {
   struct qm_fqd_stashing stashing;




   __be16 context_hi;
   __be32 context_lo;
  } __attribute__((__packed__));
 } context_a;
 struct qm_fqd_oac oac_query;
} __attribute__((__packed__));
struct qm_cgr_wr_parm {

 __be32 word;
};
struct qm_cgr_cs_thres {

 __be16 word;
};
struct __qm_mc_cgr {
 struct qm_cgr_wr_parm wr_parm_g;
 struct qm_cgr_wr_parm wr_parm_y;
 struct qm_cgr_wr_parm wr_parm_r;
 u8 wr_en_g;
 u8 wr_en_y;
 u8 wr_en_r;
 u8 cscn_en;
 union {
  struct {
   __be16 cscn_targ_upd_ctrl;
   __be16 cscn_targ_dcp_low;
  };
  __be32 cscn_targ;
 };
 u8 cstd_en;
 u8 cs;
 struct qm_cgr_cs_thres cs_thres;
 u8 mode;
} __attribute__((__packed__));
struct qm_mcc_initfq {
 u8 __reserved1[2];
 __be16 we_mask;
 __be32 fqid;
 __be16 count;
 struct qm_fqd fqd;
 u8 __reserved2[30];
} __attribute__((__packed__));
struct qm_mcc_initcgr {
 u8 __reserve1[2];
 __be16 we_mask;
 struct __qm_mc_cgr cgr;
 u8 __reserved2[2];
 u8 cgid;
 u8 __reserved3[32];
} __attribute__((__packed__));
struct qm_mcr_queryfq_np {
 u8 verb;
 u8 result;
 u8 __reserved1;
 u8 state;
 u32 fqd_link;
 u16 odp_seq;
 u16 orp_nesn;
 u16 orp_ea_hseq;
 u16 orp_ea_tseq;
 u32 orp_ea_hptr;
 u32 orp_ea_tptr;
 u32 pfdr_hptr;
 u32 pfdr_tptr;
 u8 __reserved2[5];
 u8 is;
 u16 ics_surp;
 u32 byte_cnt;
 u32 frm_cnt;
 u32 __reserved3;
 u16 ra1_sfdr;
 u16 ra2_sfdr;
 u16 __reserved4;
 u16 od1_sfdr;
 u16 od2_sfdr;
 u16 od3_sfdr;
} __attribute__((__packed__));
struct qm_mcr_querywq {
 u8 verb;
 u8 result;
 u16 channel_wq;
 u8 __reserved[28];
 u32 wq_len[8];
} __attribute__((__packed__));
struct __qm_mcr_querycongestion {
 u32 state[8];
};
struct qm_mcr_querycongestion {
 u8 verb;
 u8 result;
 u8 __reserved[30];

 struct __qm_mcr_querycongestion state;
} __attribute__((__packed__));
struct qm_mcr_querycgr {
 u8 verb;
 u8 result;
 u16 __reserved1;
 struct __qm_mc_cgr cgr;
 u8 __reserved2[6];
 u8 i_bcnt_hi;
 __be32 i_bcnt_lo;
 u8 __reserved3[3];
 u8 a_bcnt_hi;
 __be32 a_bcnt_lo;
 __be32 cscn_targ_swp[4];
} __attribute__((__packed__));
enum qm_eqcr_pmode {
 qm_eqcr_pci = 0,
 qm_eqcr_pce = 1,
 qm_eqcr_pvb = 2
};
enum qm_dqrr_dmode {
 qm_dqrr_dpush = 0,
 qm_dqrr_dpull = 1
};
enum qm_dqrr_pmode {
 qm_dqrr_pci,
 qm_dqrr_pce,
 qm_dqrr_pvb
};
enum qm_dqrr_cmode {
 qm_dqrr_cci = 0,
 qm_dqrr_cce = 1,
 qm_dqrr_cdc = 2
};
enum qm_mr_pmode {
 qm_mr_pci,
 qm_mr_pce,
 qm_mr_pvb
};
enum qm_mr_cmode {
 qm_mr_cci = 0,
 qm_mr_cce = 1
};
struct qm_eqcr_entry {
 u8 _ncw_verb;
 u8 dca;
 __be16 seqnum;
 u8 __reserved[4];
 __be32 fqid;
 __be32 tag;
 struct qm_fd fd;
 u8 __reserved3[32];
} __attribute__((__packed__)) ;
struct qm_eqcr {
 struct qm_eqcr_entry *ring, *cursor;
 u8 ci, available, ithresh, vbit;

 u32 busy;
 enum qm_eqcr_pmode pmode;

};
struct qm_dqrr {
 const struct qm_dqrr_entry *ring, *cursor;
 u8 pi, ci, fill, ithresh, vbit;

 enum qm_dqrr_dmode dmode;
 enum qm_dqrr_pmode pmode;
 enum qm_dqrr_cmode cmode;

};
struct qm_mr {
 union qm_mr_entry *ring, *cursor;
 u8 pi, ci, fill, ithresh, vbit;

 enum qm_mr_pmode pmode;
 enum qm_mr_cmode cmode;

};
struct qm_mcc_fq {
 u8 _ncw_verb;
 u8 __reserved1[3];
 __be32 fqid;
 u8 __reserved2[56];
} __attribute__((__packed__));
struct qm_mcc_cgr {
 u8 _ncw_verb;
 u8 __reserved1[30];
 u8 cgid;
 u8 __reserved2[32];
};
union qm_mc_command {
 struct {
  u8 _ncw_verb;
  u8 __reserved[63];
 };
 struct qm_mcc_initfq initfq;
 struct qm_mcc_initcgr initcgr;
 struct qm_mcc_fq fq;
 struct qm_mcc_cgr cgr;
};
struct qm_mcr_queryfq {
 u8 verb;
 u8 result;
 u8 __reserved1[8];
 struct qm_fqd fqd;
 u8 __reserved2[30];
} __attribute__((__packed__));
struct qm_mcr_alterfq {
 u8 verb;
 u8 result;
 u8 fqs;
 u8 __reserved1[61];
};
union qm_mc_result {
 struct {
  u8 verb;
  u8 result;
  u8 __reserved1[62];
 };
 struct qm_mcr_queryfq queryfq;
 struct qm_mcr_alterfq alterfq;
 struct qm_mcr_querycgr querycgr;
 struct qm_mcr_querycongestion querycongestion;
 struct qm_mcr_querywq querywq;
 struct qm_mcr_queryfq_np queryfq_np;
};
struct qm_mc {
 union qm_mc_command *cr;
 union qm_mc_result *rr;
 u8 rridx, vbit;

 enum {

  qman_mc_idle,

  qman_mc_user,

  qman_mc_hw
 } state;

};
struct qm_addr {
 void *ce;
 __be32 *ce_be;
 void *ci;
};
struct qm_portal {






 struct qm_addr addr;
 struct qm_eqcr eqcr;
 struct qm_dqrr dqrr;
 struct qm_mr mr;
 struct qm_mc mc;
} ;
/*@ requires \true; ensures \result == eqcr->available; */

static inline    u8 qm_eqcr_get_avail(struct qm_portal *portal)
{
 struct qm_eqcr *eqcr = &portal->eqcr;

 return eqcr->available;
}
static inline    union qm_mc_result *qm_mc_result(struct qm_portal *portal)
;
