typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef struct _device *device_t;
/*@ requires 1; ensures (vector > 0 ==> \result == 0) && (vector == 0 ==> \result == (1LL << 16) - 1); */

static uint64_t
ntb_plx_db_vector_mask(device_t dev, uint32_t vector)
{

 if (vector > 0)
  return (0);
 return ((1LL << 16) - 1);
}
