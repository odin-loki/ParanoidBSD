static int isu8cont(unsigned char);
/*@ requires 0 <= c <= 255; ensures \result == ((c & 0xC0) == 0x80); */

static int
isu8cont(unsigned char c)
{
 return (c & (0x80 | 0x40)) == 0x80;
}
