typedef unsigned int __u32;
typedef __u32 u32;
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_size_t size_t;
static inline    u32 get_random_u32_below(u32 ceil)
;
/*@ requires size == 256 || size != 256; ensures \result < 24 && (size != 256 || (\result != 16 && \result != 17)); */

static unsigned int random_ecc_bit(size_t size)
{
 unsigned int offset = get_random_u32_below(3 * 8);

 if (size == 256) {




  while (offset == 16 || offset == 17)
   offset = get_random_u32_below(3 * 8);
 }

 return offset;
}
