typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __vm_size_t;
typedef __uint64_t __size_t;
typedef __uintptr_t uintptr_t;
typedef __size_t size_t;
typedef __vm_offset_t vm_offset_t;
typedef __vm_size_t vm_size_t;
typedef struct vmem vmem_t;
typedef uintptr_t vmem_addr_t;
typedef size_t vmem_size_t;
int vmem_xalloc(vmem_t *vm, vmem_size_t size, vmem_size_t align,
    vmem_size_t phase, vmem_size_t nocross, vmem_addr_t minaddr,
    vmem_addr_t maxaddr, int flags, vmem_addr_t *addrp);
extern struct vmem *kernel_arena;
struct vmem;
vm_offset_t kva_alloc(vm_size_t);
/*@ requires size > 0; ensures \result == 0 || (\result != 0 && \result % (1<<12) == 0); */

vm_offset_t
kva_alloc(vm_size_t size)
{
 vm_offset_t addr;

 ;
 size = ((__typeof__(size))(((__uintptr_t)(size)+(((1<<12))-1))&(~(((1<<12))-1))));
 if (vmem_xalloc(kernel_arena, size, 0, 0, 0, 0,
     (~(vmem_addr_t)0), 0x2000 | 0x0001, &addr))
  return (0);
 ;

 return (addr);
}
