typedef _Bool bool;
/*@ requires 0 <= mask <= 4294967295; ensures \result == 1 <==> (mask & 0x3f) != 0; */

static inline    bool test_compression_spec(unsigned int mask)
{
 return mask & ((1 << 15)
   | (1 << 16)
   | (1 << 17)
   | (1 << 18)
   | (1 << 19)
   | (1 << 20));
}
