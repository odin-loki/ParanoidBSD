typedef unsigned char __uint8_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __int64_t __sbintime_t;
typedef unsigned long u_long;
typedef __uint8_t uint8_t;
typedef __uint32_t uint32_t;
typedef __uintptr_t uintptr_t;
typedef __sbintime_t sbintime_t;
typedef unsigned int boolean_t;
typedef struct _device *device_t;
extern sbintime_t tick_sbt;
struct lock_object;
static __inline int atomic_fcmpset_long(volatile u_long *dst, u_long *expect, u_long src) ;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct thread;
static __inline  struct thread *
__curthread(void)
;
struct lock_object;
struct mtx;
struct thread;
int _sleep(const void * chan, struct lock_object *lock, int pri,
    const char *wmesg, sbintime_t sbt, sbintime_t pr, int flags);
void *device_get_ivars(device_t dev);
int device_printf(device_t dev, const char *, ...) ;
struct thread;
struct thread;
void __mtx_lock_sleep(volatile uintptr_t *c, uintptr_t v);
void __mtx_unlock_sleep(volatile uintptr_t *c, uintptr_t v);
struct thread;
enum mmc_vdd {
 vdd_150 = 0, vdd_155, vdd_160, vdd_165, vdd_170, vdd_180,
 vdd_190, vdd_200, vdd_210, vdd_220, vdd_230, vdd_240, vdd_250,
 vdd_260, vdd_270, vdd_280, vdd_290, vdd_300, vdd_310, vdd_320,
 vdd_330, vdd_340, vdd_350, vdd_360
};
enum mmc_vccq {
 vccq_120 = 0, vccq_180, vccq_330
};
enum mmc_power_mode {
 power_off = 0, power_up, power_on
};
enum mmc_bus_mode {
 opendrain = 1, pushpull
};
enum mmc_chip_select {
 cs_dontcare = 0, cs_high, cs_low
};
enum mmc_bus_type {
 bus_type_default = 0, bus_type_spi
};
enum mmc_bus_width {
 bus_width_1 = 0, bus_width_4 = 2, bus_width_8 = 3
};
enum mmc_drv_type {
 drv_type_b = 0, drv_type_a, drv_type_c, drv_type_d
};
enum mmc_bus_timing {
 bus_timing_normal = 0, bus_timing_hs, bus_timing_uhs_sdr12,
 bus_timing_uhs_sdr25, bus_timing_uhs_sdr50, bus_timing_uhs_ddr50,
 bus_timing_uhs_sdr104, bus_timing_mmc_ddr52, bus_timing_mmc_hs200,
 bus_timing_mmc_hs400, bus_timing_mmc_hs400es, bus_timing_max =
 bus_timing_mmc_hs400es
};
struct mmc_ios {
 uint32_t clock;
 enum mmc_vdd vdd;
 enum mmc_vccq vccq;
 enum mmc_bus_type bus_type;
 enum mmc_bus_mode bus_mode;
 enum mmc_chip_select chip_select;
 enum mmc_bus_width bus_width;
 enum mmc_power_mode power_mode;
 enum mmc_bus_timing timing;
 enum mmc_drv_type drv_type;
};
enum mmc_card_mode {
 mode_mmc, mode_sd
};
struct mmc_host {
 int f_min;
 int f_max;
 uint32_t host_ocr;
 uint32_t ocr;
 uint32_t caps;
 enum mmc_card_mode mode;
 struct mmc_ios ios;
};
struct mmcspi_slot {
 struct mmcspi_softc *sc;
 device_t dev;
 boolean_t bus_busy;
 struct mmc_host host;
 struct mtx mtx;
 uint8_t last_ocr[4];
 uint32_t last_opcode;
 uint32_t last_flags;
 unsigned int crc_enabled;
 unsigned int crc_init_done;

 uint8_t ldata_buf[16];
};
struct mmcspi_softc {
 device_t dev;
 device_t busdev;
 struct mmcspi_slot slot;
 unsigned int use_crc;
};
static unsigned int trace_zone_mask = (1ul << 4);
/*@ requires 1; ensures \result == 0; */

static int
mmcspi_acquire_host(device_t brdev, device_t reqdev)
{
 struct mmcspi_slot *slot;
 int err;

 if ((trace_zone_mask & (1ul << 0))) { device_printf(brdev, "%s: enter\n", __func__); };
 err = 0;

 slot = device_get_ivars(reqdev);

 __extension__ ({ uintptr_t _tid = (uintptr_t)((__curthread())); uintptr_t _v = 0x00000000; if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&(slot)->mtx)))))->mtx_lock, &_v, (_tid))), 0)) __mtx_lock_sleep(&(((((&(slot)->mtx)))))->mtx_lock, _v); (void)0; });
 while (slot->bus_busy)
  _sleep((slot), &(&slot->mtx)->lock_object, (0), ("mmcspiah"), tick_sbt * (0), 0, 0x0100);
 slot->bus_busy++;
 __extension__ ({ uintptr_t _v = (uintptr_t)((__curthread())); if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&(slot)->mtx)))))->mtx_lock, (&_v), 0x00000000)), 0)) __mtx_unlock_sleep(&(((((&(slot)->mtx)))))->mtx_lock, _v); (void)0; });

 if ((trace_zone_mask & (1ul << 1))) { device_printf(brdev, "%s: exit\n", __func__); };

 return (err);
}
