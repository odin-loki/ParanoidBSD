long _atomic_lock_stub(volatile long *);
/*@ requires true; ensures \result == 0; */

long
_atomic_lock_stub(volatile long *lck )
{
 return (0L);
}
