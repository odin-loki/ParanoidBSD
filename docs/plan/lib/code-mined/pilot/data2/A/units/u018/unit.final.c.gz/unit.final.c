typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
bool iwl_he_is_sgi(u32 rate_n_flags);
/*@ requires true; ensures \result == ((rate_n_flags & (3 << 23)) == (0 << 23) || (rate_n_flags & (3 << 23)) == (1 << 23)) && ((rate_n_flags & (0x7 << 20)) == 4); */

bool iwl_he_is_sgi(u32 rate_n_flags)
{
 u32 type = rate_n_flags & (3 << 23);
 u32 ltf_gi = rate_n_flags & (0x7 << 20);

 if (type == (0 << 23) ||
     type == (1 << 23))
  return ltf_gi == 4;
 return false;
}
