typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __int64_t __intmax_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_size_t;
typedef __uint64_t __size_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint32_t __gid_t;
typedef __uint16_t __mode_t;
typedef __int64_t __sbintime_t;
typedef __uint32_t __uid_t;
typedef unsigned char u_char;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int32_t int32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __intmax_t intmax_t;
typedef char * caddr_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __sbintime_t sbintime_t;
typedef __size_t size_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __uint64_t vm_ooffset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __vm_size_t vm_size_t;
typedef char vm_memattr_t;
typedef _Bool bool;
struct timespec {
 time_t tv_sec;
 long tv_nsec;
};
struct bintime {
 time_t sec;
 uint64_t frac;
};
void bintime(struct bintime *bt);
struct priority {
 u_char pri_class;
 u_char pri_level;
 u_char pri_native;
 u_char pri_user;
};
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
extern const char version[];
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct mtx_padalign {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
} ;
struct thread;
struct lock_object;
struct malloc_type;
struct mtx;
struct proc;
struct thread;
struct ucred;
struct uio;
int printf(const char *, ...) ;
struct malloc_type;
static __inline char *
index(const char *p, int ch)
;
struct cdev;
struct thread;
struct lock_object;
struct malloc_type_stats {
 uint64_t mts_memalloced;
 uint64_t mts_memfreed;
 uint64_t mts_numallocs;
 uint64_t mts_numfrees;
 uint64_t mts_size;
 uint64_t _mts_reserved1;
 uint64_t _mts_reserved2;
 uint64_t _mts_reserved3;
};
struct malloc_type_internal {
 uint32_t mti_probes[2];

 u_char mti_zone;
 struct malloc_type_stats *mti_stats;
 u_long mti_spare[8];
};
struct malloc_type {
 struct malloc_type *ks_next;
 u_long ks_version;
 const char *ks_shortdesc;
 struct malloc_type_internal ks_mti;
};
void *malloc(size_t size, struct malloc_type *type, int flags) 
      ;
struct snapdata;
struct cdevsw;
struct file;
struct cdev {
 void *si_spare0;
 u_int si_flags;
 struct timespec si_atime;
 struct timespec si_ctime;
 struct timespec si_mtime;
 uid_t si_uid;
 gid_t si_gid;
 mode_t si_mode;
 struct ucred *si_cred;
 int si_drv0;
 int si_refcount;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_list;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_clone;
 struct { struct cdev *lh_first; } si_children;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_siblings;
 struct cdev *si_parent;
 struct mount *si_mountpt;
 void *si_drv1, *si_drv2;
 struct cdevsw *si_devsw;
 int si_iosize_max;
 u_long si_usecount;
 u_long si_threadcount;
 union {
  struct snapdata *__sid_snapdata;
 } __si_u;
 char si_name[255 + 1];
};
struct bio;
struct thread;
struct uio;
struct knote;
struct vm_object;
typedef int d_open_t(struct cdev *dev, int oflags, int devtype, struct thread *td);
typedef int d_fdopen_t(struct cdev *dev, int oflags, struct thread *td, struct file *fp);
typedef int d_close_t(struct cdev *dev, int fflag, int devtype, struct thread *td);
typedef void d_strategy_t(struct bio *bp);
typedef int d_ioctl_t(struct cdev *dev, u_long cmd, caddr_t data,
        int fflag, struct thread *td);
typedef int d_read_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_write_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_poll_t(struct cdev *dev, int events, struct thread *td);
typedef int d_kqfilter_t(struct cdev *dev, struct knote *kn);
typedef int d_mmap_t(struct cdev *dev, vm_ooffset_t offset, vm_paddr_t *paddr,
       int nprot, vm_memattr_t *memattr);
typedef int d_mmap_single_t(struct cdev *cdev, vm_ooffset_t *offset,
    vm_size_t size, struct vm_object **object, int nprot);
typedef void d_purge_t(struct cdev *dev);
struct cdevsw {
 int d_version;
 u_int d_flags;
 const char *d_name;
 d_open_t *d_open;
 d_fdopen_t *d_fdopen;
 d_close_t *d_close;
 d_read_t *d_read;
 d_write_t *d_write;
 d_ioctl_t *d_ioctl;
 d_poll_t *d_poll;
 d_mmap_t *d_mmap;
 d_strategy_t *d_strategy;
 void *d_spare0;
 d_kqfilter_t *d_kqfilter;
 d_purge_t *d_purge;
 d_mmap_single_t *d_mmap_single;

 int32_t d_spare1[3];
 void *d_spare2[3];


 struct { struct cdev *lh_first; } d_devs;
 int d_spare3;
 union {
  struct cdevsw *gianttrick;
  struct { struct cdevsw *sle_next; } postfree_list;
 } __d_giant;
};
struct thread;
struct sysctl_req {
 struct thread *td;
 int lock;
 void *oldptr;
 size_t oldlen;
 size_t oldidx;
 int (*oldfunc)(struct sysctl_req *, const void *, size_t);
 const void *newptr;
 size_t newlen;
 size_t newidx;
 int (*newfunc)(struct sysctl_req *, void *, size_t);
 size_t validlen;
 int flags;
};
struct sysctl_oid;
struct sysctl_oid_list { struct sysctl_oid *rbh_root; };
struct sysctl_oid {
 struct sysctl_oid_list oid_children;
 struct sysctl_oid_list* oid_parent;
 struct { struct sysctl_oid *rbe_link[3]; } oid_link;

 int oid_number;
 u_int oid_kind;
 void *oid_arg1;
 intmax_t oid_arg2;

 const char *oid_name;
 int (*oid_handler)(struct sysctl_oid *oidp, void *arg1, intmax_t arg2, struct sysctl_req *req);
 const char *oid_fmt;
 int oid_refcnt;
 u_int oid_running;
 const char *oid_descr;
 const char *oid_label;
};
struct sysctl_ctx_entry {
 struct sysctl_oid *entry;
 struct { struct sysctl_ctx_entry *tqe_next; struct sysctl_ctx_entry **tqe_prev; } link;
};
struct sysctl_ctx_list { struct sysctl_ctx_entry *tqh_first; struct sysctl_ctx_entry **tqh_last; };
struct sbuf;
struct sbuf;
struct scsi_transportid_spi
{
 uint8_t format_protocol;
 uint8_t reserved1;
 uint8_t scsi_addr[2];
 uint8_t obsolete[2];
 uint8_t rel_trgt_port_id[2];
 uint8_t reserved2[16];
};
struct scsi_log_param_header {
 uint8_t param_code[2];
 uint8_t param_control;
 uint8_t param_len;
};
struct scsi_log_stat_and_perf {
 struct scsi_log_param_header hdr;
 uint8_t read_num[8];
 uint8_t write_num[8];
 uint8_t recvieved_lba[8];
 uint8_t transmitted_lba[8];
 uint8_t read_int[8];
 uint8_t write_int[8];
 uint8_t weighted_num[8];
 uint8_t weighted_int[8];
};
struct scsi_log_idle_time {
 struct scsi_log_param_header hdr;
 uint8_t idle_int[8];
};
struct scsi_log_time_interval {
 struct scsi_log_param_header hdr;
 uint8_t exponent[4];
 uint8_t integer[4];
};
struct scsi_log_informational_exceptions {
 struct scsi_log_param_header hdr;
 uint8_t ie_asc;
 uint8_t ie_ascq;
 uint8_t temperature;
};
struct scsi_log_temperature {
 struct scsi_log_param_header hdr;
 uint8_t reserved;
 uint8_t temperature;
};
struct scsi_control_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t rlec;


 uint8_t queue_flags;
 uint8_t eca_and_aen;
 uint8_t flags4;
 uint8_t aen_holdoff_period[2];
 uint8_t busy_timeout_period[2];
 uint8_t extended_selftest_completion_time[2];
};
struct scsi_control_ext_page {
 uint8_t page_code;
 uint8_t subpage_code;
 uint8_t page_length[2];
 uint8_t flags;
 uint8_t prio;
 uint8_t max_sense;
 uint8_t reserve[25];
};
struct scsi_caching_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t flags1;
 uint8_t ret_priority;
 uint8_t disable_pf_transfer_len[2];
 uint8_t min_prefetch[2];
 uint8_t max_prefetch[2];
 uint8_t max_pf_ceiling[2];
 uint8_t flags2;
 uint8_t cache_segments;
 uint8_t cache_seg_size[2];
 uint8_t reserved;
 uint8_t non_cache_seg_size[3];
};
struct scsi_info_exceptions_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t info_flags;
 uint8_t mrie;
 uint8_t interval_timer[4];
 uint8_t report_count[4];
};
struct scsi_logical_block_provisioning_page_descr {
 uint8_t flags;
 uint8_t resource;
 uint8_t reserved[2];
 uint8_t count[4];
};
struct scsi_logical_block_provisioning_page {
 uint8_t page_code;
 uint8_t subpage_code;
 uint8_t page_length[2];
 uint8_t flags;
 uint8_t reserved[11];
 struct scsi_logical_block_provisioning_page_descr descr[1];
};
struct sbuf;
struct scsi_sense_data
{
 uint8_t error_code;




 uint8_t sense_buf[252 - 1];






};
static __inline void
scsi_ulto2b(uint32_t val, uint8_t *bytes)
;
struct scsi_da_rw_recovery_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t byte3;
 uint8_t read_retry_count;
 uint8_t correction_span;
 uint8_t head_offset_count;
 uint8_t data_strobe_offset_cnt;
 uint8_t byte8;
 uint8_t write_retry_count;
 uint8_t reserved2;
 uint8_t recovery_time_limit[2];
};
struct scsi_da_verify_recovery_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t byte3;
 uint8_t read_retry_count;
 uint8_t reserved[6];
 uint8_t recovery_time_limit[2];
};
struct sbuf;
struct nvme_sgl_descriptor {
 uint64_t address;
 uint32_t length;
 uint8_t reserved[3];
 uint8_t type;
};
struct nvme_command {

 uint8_t opc;
 uint8_t fuse;
 uint16_t cid;


 uint32_t nsid;


 uint32_t rsvd2;
 uint32_t rsvd3;


 uint64_t mptr;


 union {
  struct {
   uint64_t prp1;
   uint64_t prp2;
  };
  struct nvme_sgl_descriptor sgl;
 };


 uint32_t cdw10;
 uint32_t cdw11;
 uint32_t cdw12;
 uint32_t cdw13;
 uint32_t cdw14;
 uint32_t cdw15;
} ;
struct nvme_completion {

 uint32_t cdw0;


 uint32_t rsvd1;


 uint16_t sqhd;
 uint16_t sqid;


 uint16_t cid;
 uint16_t status;
} ;
struct nvlist;
struct bio;
struct thread;
struct ctl_lba_len {
 uint64_t lba;
 uint32_t len;
};
union ctl_priv {
 uint8_t bytes[sizeof(uint64_t) * 2];
 uint64_t integer;
 uint64_t integers[2];
 void *ptr;
 void *ptrs[2];
};
typedef enum {
 CTL_IO_NONE,
 CTL_IO_SCSI,
 CTL_IO_TASK,
 CTL_IO_NVME,
 CTL_IO_NVME_ADMIN,
} ctl_io_type;
struct ctl_nexus {
 uint32_t initid;
 uint32_t targ_port;
 uint32_t targ_lun;
 uint32_t targ_mapped_lun;
};
typedef enum {
 CTL_MSG_SERIALIZE,
 CTL_MSG_R2R,
 CTL_MSG_FINISH_IO,
 CTL_MSG_BAD_JUJU,
 CTL_MSG_MANAGE_TASKS,
 CTL_MSG_PERS_ACTION,
 CTL_MSG_DATAMOVE,
 CTL_MSG_DATAMOVE_DONE,
 CTL_MSG_UA,
 CTL_MSG_PORT_SYNC,
 CTL_MSG_LUN_SYNC,
 CTL_MSG_IID_SYNC,
 CTL_MSG_LOGIN,
 CTL_MSG_MODE_SYNC,
 CTL_MSG_FAILOVER
} ctl_msg_type;
struct ctl_scsiio;
struct ctl_io_hdr {
 uint32_t version;
 ctl_io_type io_type;
 ctl_msg_type msg_type;
 struct ctl_nexus nexus;
 uint32_t iid_indx;
 uint32_t flags;
 uint32_t status;
 uint32_t port_status;
 uint32_t timeout;
 uint32_t retries;




 time_t start_time;
 struct bintime start_bt;
 struct bintime dma_start_bt;
 struct bintime dma_bt;

 uint32_t num_dmas;
 union ctl_io *remote_io;
 union ctl_io *blocker;
 void *pool;
 union ctl_priv ctl_private[6];
 struct { struct ctl_io_hdr *tqh_first; struct ctl_io_hdr **tqh_last; } blocked_queue;
 struct { struct ctl_io_hdr *stqe_next; } links;
 struct { struct ctl_io_hdr *le_next; struct ctl_io_hdr **le_prev; } ooa_links;
 struct { struct ctl_io_hdr *tqe_next; struct ctl_io_hdr **tqe_prev; } blocked_links;
};
typedef enum {
 CTL_TAG_UNTAGGED,
 CTL_TAG_SIMPLE,
 CTL_TAG_ORDERED,
 CTL_TAG_HEAD_OF_QUEUE,
 CTL_TAG_ACA
} ctl_tag_type;
union ctl_io;
typedef void (*ctl_ref)(void *arg, int diff);
typedef int (*ctl_be_move_done_t)(union ctl_io *io, bool samethr);
typedef int (*ctl_io_cont)(union ctl_io *io);
struct ctl_scsiio {
 struct ctl_io_hdr io_hdr;





 uint32_t ext_sg_entries;
 uint8_t *ext_data_ptr;
 uint32_t ext_data_len;
 uint32_t ext_data_filled;





 uint32_t kern_sg_entries;

 uint32_t rem_sg_entries;




 uint8_t *kern_data_ptr;
 uint32_t kern_data_len;





 uint32_t kern_total_len;




 uint32_t kern_data_resid;






 uint32_t kern_rel_offset;

 struct scsi_sense_data sense_data;
 uint8_t sense_len;
 uint8_t scsi_status;
 uint8_t seridx;
 uint8_t priority;
 uint64_t tag_num;
 ctl_tag_type tag_type;
 uint8_t cdb_len;
 uint8_t cdb[32];
 ctl_be_move_done_t be_move_done;
 ctl_io_cont io_cont;
 ctl_ref kern_data_ref;
 void *kern_data_arg;
};
typedef enum {
 CTL_TASK_ABORT_TASK,
 CTL_TASK_ABORT_TASK_SET,
 CTL_TASK_CLEAR_ACA,
 CTL_TASK_CLEAR_TASK_SET,
 CTL_TASK_I_T_NEXUS_RESET,
 CTL_TASK_LUN_RESET,
 CTL_TASK_TARGET_RESET,
 CTL_TASK_BUS_RESET,
 CTL_TASK_PORT_LOGIN,
 CTL_TASK_PORT_LOGOUT,
 CTL_TASK_QUERY_TASK,
 CTL_TASK_QUERY_TASK_SET,
 CTL_TASK_QUERY_ASYNC_EVENT
} ctl_task_type;
struct ctl_taskio {
 struct ctl_io_hdr io_hdr;
 ctl_task_type task_action;
 uint64_t tag_num;
 ctl_tag_type tag_type;
 uint8_t task_status;
 uint8_t task_resp[3];
};
struct ctl_nvmeio {
 struct ctl_io_hdr io_hdr;





 uint32_t ext_sg_entries;
 uint8_t *ext_data_ptr;
 uint32_t ext_data_len;
 uint32_t ext_data_filled;





 uint32_t kern_sg_entries;




 uint8_t *kern_data_ptr;
 uint32_t kern_data_len;





 uint32_t kern_total_len;




 uint32_t kern_data_resid;






 uint32_t kern_rel_offset;

 struct nvme_command cmd;
 struct nvme_completion cpl;
 bool success_sent;
 ctl_be_move_done_t be_move_done;
 ctl_io_cont io_cont;
 ctl_ref kern_data_ref;
 void *kern_data_arg;
};
typedef enum {
 CTL_PR_REG_KEY,
 CTL_PR_UNREG_KEY,
 CTL_PR_PREEMPT,
 CTL_PR_CLEAR,
 CTL_PR_RESERVE,
 CTL_PR_RELEASE
} ctl_pr_action;
struct ctl_pr_info {
 ctl_pr_action action;
 uint8_t sa_res_key[8];
 uint8_t res_type;
 uint32_t residx;
};
struct ctl_ha_msg_hdr {
 ctl_msg_type msg_type;
 uint32_t status;
 union ctl_io *original_sc;
 union ctl_io *serializing_sc;
 struct ctl_nexus nexus;
};
struct ctl_ha_msg_pr {
 struct ctl_ha_msg_hdr hdr;
 struct ctl_pr_info pr_info;
};
struct ctl_prio {
 struct ctl_io_hdr io_hdr;
 struct ctl_ha_msg_pr pr_msg;
};
union ctl_io {
 struct ctl_io_hdr io_hdr;
 struct ctl_scsiio scsiio;
 struct ctl_taskio taskio;
 struct ctl_nvmeio nvmeio;
 struct ctl_prio presio;
};
typedef enum {
 CTL_PORT_NONE = 0x00,
 CTL_PORT_FC = 0x01,
 CTL_PORT_SCSI = 0x02,
 CTL_PORT_IOCTL = 0x04,
 CTL_PORT_INTERNAL = 0x08,
 CTL_PORT_ISCSI = 0x10,
 CTL_PORT_SAS = 0x20,
 CTL_PORT_UMASS = 0x40,
 CTL_PORT_NVMF = 0x80,
 CTL_PORT_ALL = 0xff,
 CTL_PORT_ISC = 0x100
} ctl_port_type;
typedef enum {
 CTL_UA_NONE = 0x0000,
 CTL_UA_POWERON = 0x0001,
 CTL_UA_BUS_RESET = 0x0002,
 CTL_UA_TARG_RESET = 0x0004,
 CTL_UA_I_T_NEXUS_LOSS = 0x0008,
 CTL_UA_LUN_RESET = 0x0010,
 CTL_UA_LUN_CHANGE = 0x0020,
 CTL_UA_MODE_CHANGE = 0x0040,
 CTL_UA_LOG_CHANGE = 0x0080,
 CTL_UA_INQ_CHANGE = 0x0100,
 CTL_UA_RES_PREEMPT = 0x0400,
 CTL_UA_RES_RELEASE = 0x0800,
 CTL_UA_REG_PREEMPT = 0x1000,
 CTL_UA_ASYM_ACC_CHANGE = 0x2000,
 CTL_UA_CAPACITY_CHANGE = 0x4000,
 CTL_UA_THIN_PROV_THRES = 0x8000,
 CTL_UA_MEDIUM_CHANGE = 0x10000,
 CTL_UA_IE = 0x20000
} ctl_ua_type;
extern struct malloc_type M_CTL[1];
struct ctl_page_index;
struct cdev;
struct ctl_lun;
struct ctl_port;
struct ctl_softc;
struct ctl_scsiio;
struct sbuf;
union ctl_io;
int ctl_default_page_handler(struct ctl_scsiio *ctsio,
        struct ctl_page_index *page_index,
        uint8_t *page_ptr);
int ctl_ie_page_handler(struct ctl_scsiio *ctsio,
   struct ctl_page_index *page_index,
   uint8_t *page_ptr);
int ctl_temp_log_sense_handler(struct ctl_scsiio *ctsio,
       struct ctl_page_index *page_index,
       int pc);
int ctl_lbp_log_sense_handler(struct ctl_scsiio *ctsio,
       struct ctl_page_index *page_index,
       int pc);
int ctl_sap_log_sense_handler(struct ctl_scsiio *ctsio,
       struct ctl_page_index *page_index,
       int pc);
int ctl_ie_log_sense_handler(struct ctl_scsiio *ctsio,
       struct ctl_page_index *page_index,
       int pc);
struct nvlist;
typedef struct nvlist nvlist_t;
typedef enum {
 CTL_DELAY_TYPE_NONE,
 CTL_DELAY_TYPE_CONT,
 CTL_DELAY_TYPE_ONESHOT
} ctl_delay_type;
struct ctl_io_stats {
 uint32_t item;
 uint64_t bytes[3];
 uint64_t operations[3];
 uint64_t dmas[3];
 struct bintime time[3];
 struct bintime dma_time[3];
};
typedef u_int ctl_lun_error;
typedef u_int ctl_lun_error_pattern;
struct ctl_error_desc_cmd {
 uint8_t cdb_pattern[32];
 uint32_t cdb_valid_bytes;
 uint32_t flags;
};
struct ctl_error_desc {
 uint32_t lun_id;
 ctl_lun_error lun_error;
 ctl_lun_error_pattern error_pattern;
 struct ctl_error_desc_cmd cmd_desc;
 struct ctl_lba_len lba_range;
 struct scsi_sense_data custom_sense;
 uint64_t serial;
 struct { struct ctl_error_desc *stqe_next; } links;
};
typedef u_int ctl_backend_lun_flags;
typedef enum {
 CTL_PORT_STATUS_NONE = 0x00,
 CTL_PORT_STATUS_ONLINE = 0x01,
 CTL_PORT_STATUS_HA_SHARED = 0x02
} ctl_port_status;
typedef int (*fe_init_t)(void);
typedef int (*fe_shutdown_t)(void);
typedef void (*port_func_t)(void *onoff_arg);
typedef int (*port_info_func_t)(void *onoff_arg, struct sbuf *sb);
typedef int (*lun_func_t)(void *arg, int lun_id);
typedef int (*fe_ioctl_t)(struct cdev *dev, u_long cmd, caddr_t addr, int flag,
     struct thread *td);
struct ctl_wwpn_iid {
 int in_use;
 time_t last_use;
 uint64_t wwpn;
 char *name;
};
struct ctl_port {
 struct ctl_softc *ctl_softc;
 struct ctl_frontend *frontend;
 ctl_port_type port_type;
 int num_requested_ctl_io;
 char *port_name;
 int physical_port;
 int virtual_port;
 port_func_t port_online;
 port_func_t port_offline;
 port_info_func_t port_info;
 void *onoff_arg;
 lun_func_t lun_enable;
 lun_func_t lun_disable;
 int lun_map_size;
 uint32_t *lun_map;
 void *targ_lun_arg;
 void (*fe_datamove)(union ctl_io *io);
 void (*fe_done)(union ctl_io *io);
 int32_t targ_port;
 void *ctl_pool_ref;
 uint32_t max_initiators;
 struct ctl_wwpn_iid *wwpn_iid;
 uint64_t wwnn;
 uint64_t wwpn;
 ctl_port_status status;
 nvlist_t *options;
 struct ctl_devid *port_devid;
 struct ctl_devid *target_devid;
 struct ctl_devid *init_devid;
 struct ctl_io_stats stats;
 struct mtx port_lock;
 struct { struct ctl_port *stqe_next; } fe_links;
 struct { struct ctl_port *stqe_next; } links;
};
struct ctl_frontend {
 char name[32];
 fe_init_t init;
 fe_ioctl_t ioctl;
 void (*fe_dump)(void);
 fe_shutdown_t shutdown;
 struct { struct ctl_port *stqh_first; struct ctl_port **stqh_last; } port_list;
 struct { struct ctl_frontend *stqe_next; } links;
};
int ctl_port_register(struct ctl_port *port);
void ctl_port_online(struct ctl_port *fe);
typedef enum {
 CTL_LUN_SERSEQ_OFF,
 CTL_LUN_SERSEQ_SOFT,
 CTL_LUN_SERSEQ_READ,
 CTL_LUN_SERSEQ_ON
} ctl_lun_serseq;
struct ctl_be_lun;
typedef void (*be_callback_t)(struct ctl_be_lun *be_lun);
struct ctl_be_lun {
 uint8_t lun_type;
 ctl_backend_lun_flags flags;
 ctl_lun_serseq serseq;
 uint64_t maxlba;
 uint32_t blocksize;
 uint16_t pblockexp;
 uint16_t pblockoff;
 uint16_t ublockexp;
 uint16_t ublockoff;
 uint32_t atomicblock;
 uint32_t opttxferlen;
 uint32_t req_lun_id;
 uint32_t lun_id;
 uint8_t serial_num[16];
 uint8_t device_id[64];
 be_callback_t lun_shutdown;
 struct ctl_backend_driver *be;
 void *ctl_lun;
 nvlist_t *options;
 struct { struct ctl_be_lun *stqe_next; } links;
};
typedef enum {
 CTL_BE_FLAG_NONE = 0x00,
 CTL_BE_FLAG_HAS_CONFIG = 0x01,
} ctl_backend_flags;
typedef int (*be_init_t)(void);
typedef int (*be_shutdown_t)(void);
typedef int (*be_func_t)(union ctl_io *io);
typedef int (*be_ioctl_t)(struct cdev *dev, u_long cmd, caddr_t addr, int flag,
     struct thread *td);
typedef int (*be_luninfo_t)(struct ctl_be_lun *be_lun, struct sbuf *sb);
typedef uint64_t (*be_lunattr_t)(struct ctl_be_lun *be_lun, const char *attrname);
struct ctl_backend_driver {
 char name[32];
 ctl_backend_flags flags;
 be_init_t init;
 be_shutdown_t shutdown;
 be_func_t data_submit;
 be_func_t config_read;
 be_func_t config_write;
 be_ioctl_t ioctl;
 be_luninfo_t lun_info;
 be_lunattr_t lun_attr;






 struct { struct ctl_backend_driver *stqe_next; } links;
};
typedef enum {
 CTL_HA_MODE_ACT_STBY,
 CTL_HA_MODE_SER_ONLY,
 CTL_HA_MODE_XFER
} ctl_ha_mode;
struct ctl_softc;
typedef enum {
 CTL_HA_LINK_OFFLINE = 0x00,
 CTL_HA_LINK_UNKNOWN = 0x01,
 CTL_HA_LINK_ONLINE = 0x02
} ctl_ha_link_state;
struct scsi_cddvd_capabilities_page_sd {
 uint8_t reserved;
 uint8_t rotation_control;
 uint8_t write_speed_supported[2];
};
struct scsi_cddvd_capabilities_page {
 uint8_t page_code;
 uint8_t page_length;
 uint8_t caps1;
 uint8_t caps2;
 uint8_t caps3;
 uint8_t caps4;
 uint8_t caps5;
 uint8_t caps6;
 uint8_t obsolete[2];
 uint8_t nvol_levels[2];
 uint8_t buffer_size[2];
 uint8_t obsolete2[2];
 uint8_t reserved;
 uint8_t digital;
 uint8_t obsolete3;
 uint8_t copy_management;
 uint8_t reserved2;
 uint8_t rotation_control;
 uint8_t cur_write_speed;
 uint8_t num_speed_descr;
 struct scsi_cddvd_capabilities_page_sd speed_descr[1];
};
typedef enum {
 CTL_LUN_NONE = 0x000,
 CTL_LUN_CONTROL = 0x001,
 CTL_LUN_RESERVED = 0x002,
 CTL_LUN_INVALID = 0x004,
 CTL_LUN_DISABLED = 0x008,
 CTL_LUN_STOPPED = 0x020,
 CTL_LUN_NO_MEDIA = 0x040,
 CTL_LUN_EJECTED = 0x080,
 CTL_LUN_PR_RESERVED = 0x100,
 CTL_LUN_PRIMARY_SC = 0x200,
 CTL_LUN_READONLY = 0x800,
 CTL_LUN_PEER_SC_PRIMARY = 0x1000,
 CTL_LUN_REMOVABLE = 0x2000
} ctl_lun_flags;
struct ctl_page_index;
typedef int ctl_modesen_handler(struct ctl_scsiio *ctsio,
        struct ctl_page_index *page_index,
        int pc);
typedef int ctl_modesel_handler(struct ctl_scsiio *ctsio,
        struct ctl_page_index *page_index,
        uint8_t *page_ptr);
typedef enum {
 CTL_PAGE_FLAG_NONE = 0x00,
 CTL_PAGE_FLAG_DIRECT = 0x01,
 CTL_PAGE_FLAG_PROC = 0x02,
 CTL_PAGE_FLAG_CDROM = 0x04,
 CTL_PAGE_FLAG_ALL = 0x07
} ctl_page_flags;
struct ctl_page_index {
 uint8_t page_code;
 uint8_t subpage;
 uint16_t page_len;
 uint8_t *page_data;
 ctl_page_flags page_flags;
 ctl_modesen_handler *sense_handler;
 ctl_modesel_handler *select_handler;
};
struct ctl_logical_block_provisioning_page {
 struct scsi_logical_block_provisioning_page main;
 struct scsi_logical_block_provisioning_page_descr descr[4];
};
static const struct ctl_page_index page_index_template[] = {
 {0x01, 0, sizeof(struct scsi_da_rw_recovery_page), ((void *)0),
  CTL_PAGE_FLAG_DIRECT | CTL_PAGE_FLAG_CDROM, ((void *)0), ctl_default_page_handler},
 {0x07, 0, sizeof(struct scsi_da_verify_recovery_page), ((void *)0),
  CTL_PAGE_FLAG_DIRECT | CTL_PAGE_FLAG_CDROM, ((void *)0), ctl_default_page_handler},
 {0x08, 0, sizeof(struct scsi_caching_page), ((void *)0),
  CTL_PAGE_FLAG_DIRECT | CTL_PAGE_FLAG_CDROM,
  ((void *)0), ctl_default_page_handler},
 {0x0A, 0, sizeof(struct scsi_control_page), ((void *)0),
  CTL_PAGE_FLAG_ALL, ((void *)0), ctl_default_page_handler},
 {0x0A | 0x40, 0x01,
  sizeof(struct scsi_control_ext_page), ((void *)0),
  CTL_PAGE_FLAG_ALL, ((void *)0), ctl_default_page_handler},
 {0x1C, 0, sizeof(struct scsi_info_exceptions_page), ((void *)0),
  CTL_PAGE_FLAG_ALL, ((void *)0), ctl_ie_page_handler},
 {0x1C | 0x40, 0x02,
  sizeof(struct ctl_logical_block_provisioning_page), ((void *)0),
  CTL_PAGE_FLAG_DIRECT, ((void *)0), ctl_default_page_handler},
 {0x2a, 0,
  sizeof(struct scsi_cddvd_capabilities_page), ((void *)0),
  CTL_PAGE_FLAG_CDROM, ((void *)0), ((void *)0)},
};
struct ctl_mode_pages {
 struct scsi_da_rw_recovery_page rw_er_page[4];
 struct scsi_da_verify_recovery_page verify_er_page[4];
 struct scsi_caching_page caching_page[4];
 struct scsi_control_page control_page[4];
 struct scsi_control_ext_page control_ext_page[4];
 struct scsi_info_exceptions_page ie_page[4];
 struct ctl_logical_block_provisioning_page lbp_page[4];
 struct scsi_cddvd_capabilities_page cddvd_page[4];
 struct ctl_page_index index[sizeof(page_index_template)/ sizeof(page_index_template[0])];
};
static const struct ctl_page_index log_page_index_template[] = {
 {0x00, 0, 0, ((void *)0),
  CTL_PAGE_FLAG_ALL, ((void *)0), ((void *)0)},
 {0x00, 0xff, 0, ((void *)0),
  CTL_PAGE_FLAG_ALL, ((void *)0), ((void *)0)},
 {0x0d, 0, 0, ((void *)0),
  CTL_PAGE_FLAG_DIRECT, ctl_temp_log_sense_handler, ((void *)0)},
 {0x0c, 0, 0, ((void *)0),
  CTL_PAGE_FLAG_DIRECT, ctl_lbp_log_sense_handler, ((void *)0)},
 {0x19, 0, 0, ((void *)0),
  CTL_PAGE_FLAG_ALL, ctl_sap_log_sense_handler, ((void *)0)},
 {0x2f, 0, 0, ((void *)0),
  CTL_PAGE_FLAG_ALL, ctl_ie_log_sense_handler, ((void *)0)},
};
struct ctl_log_pages {
 uint8_t pages_page[sizeof(log_page_index_template)/ sizeof(log_page_index_template[0])];
 uint8_t subpages_page[sizeof(log_page_index_template)/ sizeof(log_page_index_template[0]) * 2];
 uint8_t lbp_page[12*4];
 struct stat_page {
  struct scsi_log_stat_and_perf sap;
  struct scsi_log_idle_time it;
  struct scsi_log_time_interval ti;
 } stat_page;
 struct scsi_log_temperature temp_page[2];
 struct scsi_log_informational_exceptions ie_page;
 struct ctl_page_index index[sizeof(log_page_index_template)/ sizeof(log_page_index_template[0])];
};
struct ctl_lun_delay_info {
 ctl_delay_type datamove_type;
 uint32_t datamove_delay;
 ctl_delay_type done_type;
 uint32_t done_delay;
};
struct ctl_devid {
 int len;
 uint8_t data[1];
};
struct tpc_list;
struct ctl_lun {
 struct mtx lun_lock;
 uint64_t lun;
 ctl_lun_flags flags;
 struct { struct ctl_error_desc *stqh_first; struct ctl_error_desc **stqh_last; } error_list;
 uint64_t error_serial;
 struct ctl_softc *ctl_softc;
 struct ctl_be_lun *be_lun;
 struct ctl_backend_driver *backend;
 struct ctl_lun_delay_info delay_info;

 sbintime_t idle_time;
 sbintime_t last_busy;

 struct ctl_ooaq { struct ctl_io_hdr *lh_first; } ooa_queue;
 struct { struct ctl_lun *stqe_next; } links;
 struct scsi_sense_data **pending_sense;
 ctl_ua_type **pending_ua;
 uint8_t ua_tpt_info[8];
 time_t lasttpt;
 uint8_t ie_asc;
 uint8_t ie_ascq;
 int ie_reported;
 uint32_t ie_reportcnt;
 struct callout ie_callout;
 struct ctl_mode_pages mode_pages;
 struct ctl_log_pages log_pages;
 struct ctl_io_stats stats;
 uint32_t res_idx;
 uint32_t pr_generation;
 uint64_t **pr_keys;
 int pr_key_count;
 uint32_t pr_res_idx;
 uint8_t pr_res_type;
 int prevent_count;
 uint32_t *prevent;
 uint8_t *write_buffer;
 struct ctl_devid *lun_devid;
 struct tpc_lists { struct tpc_list *tqh_first; struct tpc_list **tqh_last; } tpc_lists;
};
typedef enum {
 CTL_FLAG_ACTIVE_SHELF = 0x04
} ctl_gen_flags;
struct ctl_thread {
 struct mtx_padalign queue_lock;
 struct ctl_softc *ctl_softc;
 struct thread *thread;
 struct { struct ctl_io_hdr *stqh_first; struct ctl_io_hdr **stqh_last; } incoming_queue;
 struct { struct ctl_io_hdr *stqh_first; struct ctl_io_hdr **stqh_last; } rtr_queue;
 struct { struct ctl_io_hdr *stqh_first; struct ctl_io_hdr **stqh_last; } done_queue;
 struct { struct ctl_io_hdr *stqh_first; struct ctl_io_hdr **stqh_last; } isc_queue;
};
struct tpc_token;
struct ctl_softc {
 struct mtx ctl_lock;
 struct cdev *dev;
 int num_luns;
 ctl_gen_flags flags;
 ctl_ha_mode ha_mode;
 int ha_id;
 int is_single;
 ctl_ha_link_state ha_link;
 int port_min;
 int port_max;
 int port_cnt;
 int init_min;
 int init_max;
 struct sysctl_ctx_list sysctl_ctx;
 struct sysctl_oid *sysctl_tree;
 void *othersc_pool;
 struct proc *ctl_proc;
 uint32_t *ctl_lun_mask;
 struct ctl_lun **ctl_luns;
 uint32_t *ctl_port_mask;
 struct { struct ctl_lun *stqh_first; struct ctl_lun **stqh_last; } lun_list;
 uint32_t num_frontends;
 struct { struct ctl_frontend *stqh_first; struct ctl_frontend **stqh_last; } fe_list;
 uint32_t num_ports;
 struct { struct ctl_port *stqh_first; struct ctl_port **stqh_last; } port_list;
 struct ctl_port **ctl_ports;
 uint32_t num_backends;
 struct { struct ctl_backend_driver *stqh_first; struct ctl_backend_driver **stqh_last; } be_list;
 struct uma_zone *io_zone;
 uint32_t cur_pool_id;
 int shutdown;
 struct ctl_thread threads[16];
 struct thread *thresh_thread;
 struct tpc_tokens { struct tpc_token *tqh_first; struct tpc_token **tqh_last; } tpc_tokens;
 struct callout tpc_timeout;
 struct mtx tpc_lock;
};
struct ctl_lun;
struct tpcl_softc {
 struct ctl_port port;
 u_int cur_tag_num;
};
static struct tpcl_softc tpcl_softc;
static int tpcl_init(void);
static int tpcl_shutdown(void);
static void tpcl_datamove(union ctl_io *io);
static void tpcl_done(union ctl_io *io);
static struct ctl_frontend tpcl_frontend =
{
 .name = "tpc",
 .init = tpcl_init,
 .shutdown = tpcl_shutdown,
};
/*@ requires 1; ensures \result == 0 || \result == -1; */

static int
tpcl_init(void)
{
 struct tpcl_softc *tsoftc = &tpcl_softc;
 struct ctl_port *port;
 struct scsi_transportid_spi *tid;
 int error, len;

 __builtin_memset((tsoftc), (0), (sizeof(*tsoftc)));

 port = &tsoftc->port;
 port->frontend = &tpcl_frontend;
 port->port_type = CTL_PORT_INTERNAL;
 port->num_requested_ctl_io = 100;
 port->port_name = "tpc";
 port->fe_datamove = tpcl_datamove;
 port->fe_done = tpcl_done;
 port->targ_port = -1;
 port->max_initiators = 1;

 if ((error = ctl_port_register(port)) != 0) {
  printf("%s: tpc port registration failed\n", __func__);
  return (error);
 }

 len = sizeof(struct scsi_transportid_spi);
 port->init_devid = ({ void *_malloc_item; size_t _size = (sizeof(struct ctl_devid) + len); if (__builtin_constant_p(sizeof(struct ctl_devid) + len) && __builtin_constant_p(0x0002 | 0x0100) && ((0x0002 | 0x0100) & 0x0100) != 0) { _malloc_item = malloc(_size, M_CTL, (0x0002 | 0x0100) &~ 0x0100); if (((0x0002 | 0x0100) & 0x0002) != 0 || __builtin_expect((_malloc_item != ((void *)0)), 1)) __builtin_memset((_malloc_item), (0), (_size)); } else { _malloc_item = malloc(_size, M_CTL, 0x0002 | 0x0100); } _malloc_item; })
                              ;
 port->init_devid->len = len;
 tid = (struct scsi_transportid_spi *)port->init_devid->data;
 tid->format_protocol = 0x00 | 0x01;
 scsi_ulto2b(0, tid->scsi_addr);
 scsi_ulto2b(port->targ_port, tid->rel_trgt_port_id);

 ctl_port_online(port);
 return (0);
}
static int
tpcl_shutdown(void)
;
static void
tpcl_datamove(union ctl_io *io)
;
static void
tpcl_done(union ctl_io *io)
;

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
int main(void) {
  __CPROVER_assume(((((__int128)1ULL)) != 0));
  int bv_r = tpcl_init();
  __CPROVER_assert((((__int128)((((__int128)(((__int128)bv_r) == ((__int128)0ULL))) != 0) || (((__int128)(((__int128)bv_r) == bv_neg(((__int128)1ULL)))) != 0))) != 0), "ensures");
  return 0;
}
