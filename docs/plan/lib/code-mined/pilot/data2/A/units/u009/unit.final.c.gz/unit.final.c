typedef unsigned short __u16;
typedef __u16 u16;
struct bug_entry {



 signed int bug_addr_disp;





 signed int file_disp;

 unsigned short line;

 unsigned short flags;
};
extern  void __warn_printk(const char *fmt, ...);
static int skl_get_dimm_size(u16 val)
;
/*@ requires val >= 0; ensures \result == 0 || \result == 8 << ((val & (0x3 << 8)) >> 8); */

static int skl_get_dimm_width(u16 val)
{
 if (skl_get_dimm_size(val) == 0)
  return 0;

 switch (val & (0x3 << 8)) {
 case (0x0 << 8):
 case (0x1 << 8):
 case (0x2 << 8):
  val = (val & (0x3 << 8)) >> 8;
  return 8 << val;
 default:
  ({ int __ret_warn_on = !!(1); if (__builtin_expect(!!(__ret_warn_on), 0)) do { ({ asm volatile("1648" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1648b" " - .\n\t" ".long " "3" "\n\t" ".popsection\n\t" : : "i" (1648)); }); __warn_printk("Missing case (%s == %ld)\n", "val", (long)(val)); do { __typeof__( (1 << 0)|((1 << 3) | ((9) << 8))) __flags = (1 << 0)|((1 << 3) | ((9) << 8)); ({ asm volatile("1649" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1649b" " - .\n\t" ".long " "3" "\n\t" ".popsection\n\t" : : "i" (1649)); }); do { asm volatile("1:\t" " " "ud2" " " "\n" ".pushsection __bug_table,\"aw\"\n" "2:\t" ".long " "1b" " - ." "\t# bug_entry::bug_addr\n" "\t" ".long " "%c0" " - ." "\t# bug_entry::file\n" "\t.word " "%c1" "\t# bug_entry::line\n" "\t.word " "%c2" "\t# bug_entry::flags\n" "\t.org 2b + " "%c3" "\n" ".popsection\n" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1b" " - .\n\t" ".long " "8" "\n\t" ".popsection\n\t" : : "i" ("drivers/gpu/drm/i915/soc/intel_dram.c"), "i" (286), "i" (__flags), "i" (sizeof(struct bug_entry))); } while (0); ({ asm volatile("1650" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1650b" " - .\n\t" ".long " "4" "\n\t" ".popsection\n\t" : : "i" (1650)); }); } while (0); ({ asm volatile("1651" ": nop\n\t" ".pushsection .discard.annotate_insn,\"M\",@progbits,8\n\t" ".long " "1651b" " - .\n\t" ".long " "4" "\n\t" ".popsection\n\t" : : "i" (1651)); }); } while (0); __builtin_expect(!!(__ret_warn_on), 0); });
  return 0;
 }
}
