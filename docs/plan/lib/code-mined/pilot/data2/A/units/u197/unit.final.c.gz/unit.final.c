enum {
 false = 0,
 true = 1
};
extern int is_uv_hubbed(int uvtype);
static int uv_hubbed_system;
/*@ requires true; ensures \result == (uv_hubbed_system & uvtype); */

int is_uv_hubbed(int uvtype)
{
 return (uv_hubbed_system & uvtype);
}
extern typeof(is_uv_hubbed) is_uv_hubbed;
