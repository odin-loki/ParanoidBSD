typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __vm_size_t;
typedef __uint64_t __size_t;
typedef __int64_t __register_t;
typedef __int64_t __segsz_t;
typedef __int64_t __time_t;
typedef __uint32_t __gid_t;
typedef __int32_t __lwpid_t;
typedef __int64_t __off_t;
typedef __int32_t __pid_t;
typedef __int64_t __sbintime_t;
typedef __int64_t __rlim_t;
typedef long __suseconds_t;
typedef __uint32_t __uid_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int16_t int16_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef char * caddr_t;
typedef __gid_t gid_t;
typedef __lwpid_t lwpid_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __register_t register_t;
typedef __rlim_t rlim_t;
typedef __sbintime_t sbintime_t;
typedef __segsz_t segsz_t;
typedef __size_t size_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __vm_offset_t vm_offset_t;
typedef __uint64_t vm_ooffset_t;
typedef __vm_size_t vm_size_t;
typedef __register_t syscallarg_t;
typedef struct __sigset {
 __uint32_t __bits[4];
} __sigset_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
typedef __sigset_t sigset_t;
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
enum efi_reset {
 EFI_RESET_COLD = 0,
 EFI_RESET_WARM = 1,
 EFI_RESET_SHUTDOWN = 2,
};
typedef uint16_t efi_char;
typedef unsigned long efi_status;
typedef struct efi_guid {
 uint32_t Data1;
 uint16_t Data2;
 uint16_t Data3;
 uint8_t Data4[8];
} efi_guid_t;
struct efi_md {
 uint32_t md_type;
 uint32_t __pad;
 uint64_t md_phys;
 uint64_t md_virt;
 uint64_t md_pages;
 uint64_t md_attr;

};
struct efi_tm {
 uint16_t tm_year;
 uint8_t tm_mon;
 uint8_t tm_mday;
 uint8_t tm_hour;
 uint8_t tm_min;
 uint8_t tm_sec;
 uint8_t __pad1;
 uint32_t tm_nsec;
 int16_t tm_tz;
 uint8_t tm_dst;
 uint8_t __pad2;
};
struct efi_tmcap {
 uint32_t tc_res;
 uint32_t tc_prec;
 uint8_t tc_stz;
};
struct efi_tblhdr {
 uint64_t th_sig;
 uint32_t th_rev;
 uint32_t th_hdrsz;
 uint32_t th_crc32;
 uint32_t __res;
};
struct efi_rt {
 struct efi_tblhdr rt_hdr;
 efi_status (*rt_gettime)(struct efi_tm *, struct efi_tmcap *)
     ;
 efi_status (*rt_settime)(struct efi_tm *) ;
 efi_status (*rt_getwaketime)(uint8_t *, uint8_t *,
     struct efi_tm *) ;
 efi_status (*rt_setwaketime)(uint8_t, struct efi_tm *)
     ;
 efi_status (*rt_setvirtual)(u_long, u_long, uint32_t,
     struct efi_md *) ;
 efi_status (*rt_cvtptr)(u_long, void **) ;
 efi_status (*rt_getvar)(efi_char *, efi_guid_t *, uint32_t *,
     u_long *, void *) ;
 efi_status (*rt_scanvar)(u_long *, efi_char *, efi_guid_t *)
     ;
 efi_status (*rt_setvar)(efi_char *, efi_guid_t *, uint32_t,
     u_long, void *) ;
 efi_status (*rt_gethicnt)(uint32_t *) ;
 efi_status (*rt_reset)(enum efi_reset, efi_status, u_long,
     efi_char *) ;
};
int efi_arch_enter(void);
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct lock_list_entry;
struct thread;
struct _cpuset { unsigned long __bits[(((((1)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
typedef struct _cpuset cpuset_t;
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
 long ru_maxrss;
 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;
};
struct pmap_pcid {
 uint32_t pm_pcid;
 uint32_t pm_gen;
};
struct system_segment_descriptor {
 u_int64_t sd_lolimit:16;
 u_int64_t sd_lobase:24;
 u_int64_t sd_type:5;
 u_int64_t sd_dpl:2;
 u_int64_t sd_p:1;
 u_int64_t sd_hilimit:4;
 u_int64_t sd_xx0:3;
 u_int64_t sd_gran:1;
 u_int64_t sd_hibase:40 __attribute__((__packed__));
 u_int64_t sd_xx1:8;
 u_int64_t sd_mbz:5;
 u_int64_t sd_xx2:19;
} __attribute__((__packed__));
struct region_descriptor {
 uint64_t rd_limit:16;
 uint64_t rd_base:64 __attribute__((__packed__));
} __attribute__((__packed__));
struct amd64tss {
 u_int32_t tss_rsvd0;
 u_int64_t tss_rsp0 __attribute__((__packed__));
 u_int64_t tss_rsp1 __attribute__((__packed__));
 u_int64_t tss_rsp2 __attribute__((__packed__));
 u_int32_t tss_rsvd1;
 u_int32_t tss_rsvd2;
 u_int64_t tss_ist1 __attribute__((__packed__));
 u_int64_t tss_ist2 __attribute__((__packed__));
 u_int64_t tss_ist3 __attribute__((__packed__));
 u_int64_t tss_ist4 __attribute__((__packed__));
 u_int64_t tss_ist5 __attribute__((__packed__));
 u_int64_t tss_ist6 __attribute__((__packed__));
 u_int64_t tss_ist7 __attribute__((__packed__));
 u_int32_t tss_rsvd3;
 u_int32_t tss_rsvd4;
 u_int16_t tss_rsvd5;
 u_int16_t tss_iobase;
};
static __inline  struct thread *
__curthread(void)
;
struct lock_profile_object;
struct lpohead { struct lock_profile_object *lh_first; };
static __inline int atomic_fcmpset_long(volatile u_long *dst, u_long *expect, u_long src) ;
struct region_descriptor;
void __mtx_lock_sleep(volatile uintptr_t *c, uintptr_t v);
void __mtx_unlock_sleep(volatile uintptr_t *c, uintptr_t v);
struct vnode;
struct thread;
struct proc;
typedef char vm_inherit_t;
typedef u_char vm_prot_t;
union vm_map_object;
struct vm_map_entry;
typedef struct vm_map_entry *vm_map_entry_t;
struct vm_map;
struct vm_object;
struct ucred;
struct prison;
struct proc;
struct thread;
struct vm_offset_t;
struct vnode;
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct lock_object;
struct mtx;
struct proc;
struct thread;
struct tty;
struct ucred;
struct trapframe;
struct domainset;
struct kevent {
 __uintptr_t ident;
 short filter;
 unsigned short flags;
 unsigned int fflags;
 __int64_t data;
 void *udata;
 __uint64_t ext[4];
};
struct knote;
struct klist { struct knote *slh_first; };
struct kqueue;
struct knlist {
 struct klist kl_list;
 void (*kl_lock)(void *);
 void (*kl_unlock)(void *);
 void (*kl_assert_lock)(void *, int);
 void *kl_lockarg;
 int kl_autodestroy;
};
struct kinfo_knote;
struct proc;
struct filterops {
 int f_isfd;
 int (*f_attach)(struct knote *kn);
 void (*f_detach)(struct knote *kn);
 int (*f_event)(struct knote *kn, long hint);
 void (*f_touch)(struct knote *kn, struct kevent *kev, u_long type);
 int (*f_userdump)(struct proc *p, struct knote *kn,
      struct kinfo_knote *kin);
 int (*f_copy)(struct knote *kn, struct proc *p1);
};
struct knote {
 struct { struct knote *sle_next; } kn_link;
 struct { struct knote *sle_next; } kn_selnext;
 struct knlist *kn_knlist;
 struct { struct knote *tqe_next; struct knote **tqe_prev; } kn_tqe;
 struct kqueue *kn_kq;
 struct kevent kn_kevent;
 void *kn_hook;
 int kn_hookid;
 int kn_status;
 int kn_influx;
 unsigned int kn_sfflags;
 int64_t kn_sdata;
 union {
  struct file *p_fp;
  struct proc *p_proc;
  struct kaiocb *p_aio;
  struct aioliojob *p_lio;
  struct prison *p_prison;
  void *p_v;
 } kn_ptr;
 const struct filterops *kn_fop;

};
struct thread;
struct proc;
struct knlist;
struct mtx;
void knote(struct knlist *list, long hint, int lockflags);
struct kexterr {
 int error;
 const char *msg;
 __uint64_t p1;
 __uint64_t p2;
 unsigned cat;
 unsigned src_line;
};
struct cv {
 const char *cv_description;
 int cv_waiters;
};
struct lock_object;
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
struct thread;
struct sigio {
 union {
  struct proc *siu_proc;
  struct pgrp *siu_pgrp;
 } sio_u;
 struct { struct sigio *sle_next; } sio_pgsigio;
 struct sigio **sio_myref;

 struct ucred *sio_ucred;
 pid_t sio_pgid;
};
struct sigiolst { struct sigio *slh_first; };
typedef struct sigaltstack stack_t;
struct sigaltstack {
 void *ss_sp;
 __size_t ss_size;
 int ss_flags;
};
union sigval {

 int sival_int;
 void *sival_ptr;

 int sigval_int;
 void *sigval_ptr;
};
typedef void __sighandler_t(int);
typedef struct __siginfo {
 int si_signo;
 int si_errno;






 int si_code;
 __pid_t si_pid;
 __uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 union {
  struct {
   int _trapno;
  } _fault;
  struct {
   int _timerid;
   int _overrun;
  } _timer;
  struct {
   int _mqd;
  } _mesgq;
  struct {
   long _band;
  } _poll;
  struct {
   int _syscall;



  } _capsicum;
  struct {
   long __spare1__;
   int __spare2__[7];
  } __spare__;
 } _reason;
} siginfo_t;
struct __siginfo;
typedef __sighandler_t *sig_t;
struct sigacts {
 sig_t ps_sigact[128];
 sigset_t ps_catchmask[128];
 sigset_t ps_sigonstack;
 sigset_t ps_sigintr;
 sigset_t ps_sigreset;
 sigset_t ps_signodefer;
 sigset_t ps_siginfo;
 sigset_t ps_sigignore;
 sigset_t ps_sigcatch;
 sigset_t ps_freebsd4;
 sigset_t ps_osigset;
 sigset_t ps_usertramp;
 int ps_flag;
 u_int ps_refcnt;
 struct mtx ps_mtx;
};
typedef struct ksiginfo {
 struct { struct ksiginfo *tqe_next; struct ksiginfo **tqe_prev; } ksi_link;
 siginfo_t ksi_info;
 int ksi_flags;
 struct sigqueue *ksi_sigq;
} ksiginfo_t;
typedef struct sigqueue {
 sigset_t sq_signals;
 sigset_t sq_kill;
 sigset_t sq_ptrace;
 struct { struct ksiginfo *tqh_first; struct ksiginfo **tqh_last; } sq_list;
 struct proc *sq_proc;
 int sq_flags;
} sigqueue_t;
struct pgrp;
struct proc;
struct sigio;
struct thread;
struct thread;
typedef uid_t au_id_t;
typedef pid_t au_asid_t;
typedef u_int64_t au_asflgs_t ;
struct au_tid_addr {
 u_int32_t at_port;
 u_int32_t at_type;
 u_int32_t at_addr[4];
};
typedef struct au_tid_addr au_tid_addr_t;
struct au_mask {
 unsigned int am_success;
 unsigned int am_failure;
};
typedef struct au_mask au_mask_t;
struct auditinfo_addr {
 au_id_t ai_auid;
 au_mask_t ai_mask;
 au_tid_addr_t ai_termid;
 au_asid_t ai_asid;
 au_asflgs_t ai_flags;
};
struct label;
struct loginclass;
struct prison;
struct uidinfo;
struct ucred {
 struct mtx cr_mtx;
 long cr_ref;
 u_int cr_users;
 u_int cr_flags;
 struct auditinfo_addr cr_audit;
 int cr_ngroups;
 uid_t cr_uid;
 uid_t cr_ruid;
 uid_t cr_svuid;
 gid_t cr_gid;
 gid_t cr_rgid;
 gid_t cr_svgid;
 struct uidinfo *cr_uidinfo;
 struct uidinfo *cr_ruidinfo;
 struct prison *cr_prison;
 struct loginclass *cr_loginclass;
 void *cr_pspare2[2];
 struct label *cr_label;
 gid_t *cr_groups;
 int cr_agroups;

 gid_t cr_smallgroups[16];
};
struct thread;
struct proc;
struct _domainset { unsigned long __bits[(((((8)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
typedef struct _domainset domainset_t;
struct domainset;
struct domainset_ref {
 struct domainset * volatile dr_policy;
 unsigned int dr_iter;
};
struct fpacc87 {
 uint8_t fp_bytes[10];
};
struct xmmacc {
 uint8_t xmm_bytes[16];
};
struct envxmm {
 uint16_t en_cw;
 uint16_t en_sw;
 uint8_t en_tw;
 uint8_t en_zero;
 uint16_t en_opcode;
 uint64_t en_rip;
 uint64_t en_rdp;
 uint32_t en_mxcsr;
 uint32_t en_mxcsr_mask;
};
struct savefpu {
 struct envxmm sv_env;
 struct {
  struct fpacc87 fp_acc;
  uint8_t fp_pad[6];
 } sv_fp[8];
 struct xmmacc sv_xmm[16];
 uint8_t sv_pad[96];
} ;
struct fpu_kern_ctx;
void fpu_kern_enter(struct thread *td, struct fpu_kern_ctx *ctx,
     u_int flags);
int fpu_kern_leave(struct thread *td, struct fpu_kern_ctx *ctx);
struct pcb {
 register_t pcb_r15;
 register_t pcb_r14;
 register_t pcb_r13;
 register_t pcb_r12;
 register_t pcb_rbp;
 register_t pcb_rsp;
 register_t pcb_rbx;
 register_t pcb_rip;
 register_t pcb_fsbase;
 register_t pcb_gsbase;
 register_t pcb_kgsbase;
 register_t pcb_cr0;
 register_t pcb_cr2;
 register_t pcb_cr3;
 register_t pcb_cr4;
 register_t pcb_dr0;
 register_t pcb_dr1;
 register_t pcb_dr2;
 register_t pcb_dr3;
 register_t pcb_dr6;
 register_t pcb_dr7;

 struct region_descriptor pcb_gdt;
 struct region_descriptor pcb_idt;
 struct region_descriptor pcb_ldt;
 uint16_t pcb_tr;

 u_int pcb_flags;

 uint16_t pcb_initial_fpucw;


 caddr_t pcb_onfault;

 uint64_t pcb_saved_ucr3;


 struct amd64tss *pcb_tssp;


 register_t pcb_efer;
 register_t pcb_star;
 register_t pcb_lstar;
 register_t pcb_cstar;
 register_t pcb_sfmask;

 struct savefpu *pcb_save;

 register_t pcb_tlsbase;
 uint64_t pcb_pad[4];
};
struct trapframe;
struct proc_ldt {
 caddr_t ldt_base;
 int ldt_refcnt;
};
struct pmap_invl_gen {
 u_long gen;
 union {
  struct { struct pmap_invl_gen *le_next; struct pmap_invl_gen **le_prev; } link;
  struct {
   struct pmap_invl_gen *next;
   u_char saved_pri;
  };
 };
} ;
struct mdthread {
 int md_spinlock_count;
 register_t md_saved_flags;
 register_t md_spurflt_addr;
 struct pmap_invl_gen md_invl_gen;
 register_t md_efirt_tmp;
 int md_efirt_dis_pf;
 struct pcb md_pcb;
 vm_offset_t md_stack_base;
 void *md_usr_fpu_save;
};
struct mdproc {
 struct proc_ldt *md_ldt;
 struct system_segment_descriptor md_ldt_sd;
 u_int md_flags;
};
struct trapframe {
 register_t tf_rdi;
 register_t tf_rsi;
 register_t tf_rdx;
 register_t tf_rcx;
 register_t tf_r8;
 register_t tf_r9;
 register_t tf_rax;
 register_t tf_rbx;
 register_t tf_rbp;
 register_t tf_r10;
 register_t tf_r11;
 register_t tf_r12;
 register_t tf_r13;
 register_t tf_r14;
 register_t tf_r15;
 uint32_t tf_trapno;
 uint16_t tf_fs;
 uint16_t tf_gs;
 register_t tf_addr;
 uint32_t tf_flags;
 uint16_t tf_es;
 uint16_t tf_ds;

 register_t tf_err;
 register_t tf_rip;
 uint16_t tf_cs;
 uint16_t tf_fred_evinfo3;
 uint32_t tf_fred_zero2;
 register_t tf_rflags;

 register_t tf_rsp;
 uint16_t tf_ss;
 uint16_t tf_fred_evinfo1;
 uint32_t tf_fred_evinfo2;
};
struct session {
 u_int s_count;
 struct proc *s_leader;
 struct vnode *s_ttyvp;
 struct cdev_priv *s_ttydp;
 struct tty *s_ttyp;
 pid_t s_sid;

 char s_login[((((33)+((sizeof(long))-1))/(sizeof(long)))*(sizeof(long)))];
 struct mtx s_mtx;
};
struct pgrp {
 struct { struct pgrp *le_next; struct pgrp **le_prev; } pg_hash;
 struct { struct proc *lh_first; } pg_members;
 struct session *pg_session;
 struct sigiolst pg_sigiolst;
 pid_t pg_id;
 struct mtx pg_mtx;
 int pg_flags;
 struct sx pg_killsx;

};
struct pargs {
 u_int ar_ref;
 u_int ar_length;
 u_char ar_args[1];
};
struct cpuset;
struct filemon;
struct kaioinfo;
struct kaudit_record;
struct kcov_info;
struct kdtrace_proc;
struct kdtrace_thread;
struct kmsan_td;
struct kq_timer_cb_data;
struct mqueue_notifier;
struct proc;
struct procdesc;
struct racct;
struct sleepqueue;
struct thread;
struct trapframe;
struct turnstile;
struct vm_map;
struct vm_map_entry;
struct syscall_args {
 u_int code;
 u_int original_code;
 struct sysent *callp;
 register_t args[8];
};
struct rusage_ext {
 uint64_t rux_runtime;
 uint64_t rux_uticks;
 uint64_t rux_sticks;
 uint64_t rux_iticks;
 uint64_t rux_uu;
 uint64_t rux_su;
 uint64_t rux_tu;
};
struct thread {
 struct mtx *volatile td_lock;
 struct proc *td_proc;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_plist;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_runq;
 union {
  struct { struct thread *tqe_next; struct thread **tqe_prev; } td_slpq;
  struct thread *td_zombie;
 };
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_lockq;
 struct { struct thread *le_next; struct thread **le_prev; } td_hash;
 struct cpuset *td_cpuset;
 struct domainset_ref td_domain;
 struct seltd *td_sel;
 struct sleepqueue *td_sleepqueue;
 struct turnstile *td_turnstile;
 void *td_pad1;
 struct umtx_q *td_umtxq;
 lwpid_t td_tid;
 sigqueue_t td_sigqueue;
 u_char td_lend_user_pri;
 u_char td_allocdomain;
 u_char td_base_ithread_pri;
 struct kmsan_td *td_kmsan;


 int td_flags;
 int td_ast;
 int td_inhibitors;
 int td_pflags;
 int td_pflags2;
 int td_dupfd;
 int td_sqqueue;
 const void *td_wchan;
 const char *td_wmesg;
 volatile u_char td_owepreempt;
 u_char td_tsqueue;
 u_char _td_pad0[2];
 int td_locks;
 int td_rw_rlocks;
 int td_sx_slocks;
 int td_lk_slocks;
 struct lock_object *td_wantedlock;
 struct turnstile *td_blocked;
 const char *td_lockname;
 struct { struct turnstile *lh_first; } td_contested;
 struct lock_list_entry *td_sleeplocks;
 int td_intr_nesting_level;
 int td_pinned;
 struct ucred *td_realucred;
 struct ucred *td_ucred;
 struct plimit *td_limit;
 int td_slptick;
 int td_blktick;
 int td_swvoltick;
 int td_swinvoltick;
 u_int td_cow;
 struct rusage td_ru;
 struct rusage_ext td_rux;
 uint64_t td_incruntime;
 uint64_t td_runtime;
 u_int td_pticks;
 u_int td_sticks;
 u_int td_iticks;
 u_int td_uticks;
 int td_intrval;
 sigset_t td_oldsigmask;
 volatile u_int td_generation;
 stack_t td_sigstk;
 int td_xsig;
 u_long td_profil_addr;
 u_int td_profil_ticks;
 char td_name[19 + 1];
 struct file *td_fpop;
 int td_dbgflags;
 siginfo_t td_si;
 int td_ng_outbound;
 struct osd td_osd;
 struct vm_map_entry *td_map_def_user;
 pid_t td_dbg_forked;
 u_int td_no_sleeping;
 struct vnode *td_vp_reserved;
 void *td_su;
 sbintime_t td_sleeptimo;
 int td_rtcgen;
 int td_errno;
 size_t td_vslock_sz;
 struct kcov_info *td_kcov_info;
 long td_ucredref;
 struct kexterr td_kexterr;


 sigset_t td_sigmask;
 u_char td_rqindex;
 u_char td_base_pri;
 u_char td_priority;
 u_char td_pri_class;
 u_char td_user_pri;
 u_char td_base_user_pri;
 uint32_t td_pax;
 uintptr_t td_rb_list;
 uintptr_t td_rbp_list;
 uintptr_t td_rb_inact;
 struct syscall_args td_sa;

 void *td_sigblock_ptr;
 uint32_t td_sigblock_val;

 void *td_exterr_ptr;





 struct pcb *td_pcb;
 enum td_states {
  TDS_INACTIVE = 0x0,
  TDS_INHIBITED,
  TDS_CAN_RUN,
  TDS_RUNQ,
  TDS_RUNNING
 } td_state;

 union {
  syscallarg_t tdu_retval[2];
  off_t tdu_off;
 } td_uretoff;
 u_int td_cowgen;

 struct callout td_slpcallout;
 struct trapframe *td_frame;
 vm_offset_t td_kstack;
 u_short td_kstack_pages;
 u_short td_kstack_domain;
 volatile u_int td_critnest;
 struct mdthread td_md;
 struct kaudit_record *td_ar;
 struct lpohead td_lprof[2];
 struct kdtrace_thread *td_dtrace;
 struct vnet *td_vnet;
 const char *td_vnet_lpush;
 struct trapframe *td_intr_frame;
 struct proc *td_rfppwait_p;
 struct vm_page **td_ma;
 int td_ma_cnt;

 void *td_emuldata;
 int td_lastcpu;
 int td_oncpu;
 void *td_lkpi_task;
 int td_pmcpend;
 void *td_remotereq;
 off_t td_ktr_io_lim;



};
struct proc {
 struct { struct proc *le_next; struct proc **le_prev; } p_list;
 struct { struct thread *tqh_first; struct thread **tqh_last; } p_threads;
 struct mtx p_slock;
 struct ucred *p_ucred;
 struct filedesc *p_fd;
 struct filedesc_to_leader *p_fdtol;
 struct pwddesc *p_pd;
 struct pstats *p_stats;
 struct plimit *p_limit;
 struct callout p_limco;
 struct sigacts *p_sigacts;

 int p_flag;
 int p_flag2;
 enum p_states {
  PRS_NEW = 0,
  PRS_NORMAL,
  PRS_ZOMBIE
 } p_state;
 pid_t p_pid;
 struct { struct proc *le_next; struct proc **le_prev; } p_hash;
 struct { struct proc *le_next; struct proc **le_prev; } p_pglist;
 struct proc *p_pptr;
 struct { struct proc *le_next; struct proc **le_prev; } p_sibling;
 struct { struct proc *lh_first; } p_children;
 struct proc *p_reaper;
 struct { struct proc *lh_first; } p_reaplist;

 struct { struct proc *le_next; struct proc **le_prev; } p_reapsibling;

 struct mtx p_mtx;
 struct mtx p_statmtx;
 struct mtx p_itimmtx;
 struct mtx p_profmtx;
 struct ksiginfo *p_ksi;
 sigqueue_t p_sigqueue;
 pid_t p_oppid;


 struct vmspace *p_vmspace;
 u_int p_swtick;
 u_int p_cowgen;
 struct itimerval p_realtimer;
 struct rusage p_ru;
 struct rusage_ext p_rux;
 struct rusage_ext p_crux;
 int p_profthreads;
 volatile int p_exitthreads;
 int p_traceflag;
 struct ktr_io_params *p_ktrioparms;
 struct vnode *p_textvp;
 struct vnode *p_textdvp;
 char *p_binname;
 u_int p_lock;
 struct sigiolst p_sigiolst;
 int p_sigparent;
 int p_sig;
 u_int p_ptevents;
 struct kaioinfo *p_aioinfo;
 struct thread *p_singlethread;
 int p_suspcount;
 struct thread *p_xthread;
 int p_boundary_count;
 int p_pendingcnt;
 struct itimers *p_itimers;
 struct procdesc *p_procdesc;
 u_int p_treeflag;
 int p_pendingexits;
 struct filemon *p_filemon;
 int p_pdeathsig;



 u_int p_magic;
 int p_osrel;

 uint32_t p_fctl0;
 char p_comm[19 + 1];
 struct sysentvec *p_sysent;
 struct pargs *p_args;
 rlim_t p_cpulimit;
 signed char p_nice;
 int p_fibnum;
 uint32_t p_pax;
 pid_t p_reapsubtree;


 vm_offset_t p_usrstack;
 vm_offset_t p_psstrings;
 vm_offset_t p_timekeep_base;
 vm_offset_t p_shared_page_base;
 vm_offset_t p_sigcode_base;
 vm_offset_t p_vdso_base;
 uint64_t p_elf_flags;
 const void *p_elf_brandinfo;

 sbintime_t p_umtx_min_timeout;


 u_int p_xexit;
 u_int p_xsig;
 struct pgrp *p_pgrp;
 struct knlist *p_klist;
 int p_numthreads;
 struct mdproc p_md;
 struct callout p_itcallout;
 u_short p_acflag;
 struct proc *p_peers;
 struct proc *p_leader;
 void *p_emuldata;
 struct label *p_label;
 struct { struct ktr_request *stqh_first; struct ktr_request **stqh_last; } p_ktr;
 struct { struct mqueue_notifier *lh_first; } p_mqnotifier;
 struct kdtrace_proc *p_dtrace;
 struct cv p_pwait;
 struct racct *p_racct;
 int p_throttled;






 struct { struct proc *le_next; struct proc **le_prev; } p_orphan;
 struct { struct proc *lh_first; } p_orphans;

 struct { struct kq_timer_cb_data *tqh_first; struct kq_timer_cb_data **tqh_last; } p_kqtim_stop;
 struct { struct proc *le_next; struct proc **le_prev; } p_jaillist;
 u_int p_asig;
 u_int p_tree_refcnt;
 u_int p_execblock;
};
struct proc;
struct thread;
struct thread;
struct vm_object;
struct vm_page;
typedef uint8_t domainid_t;
struct domainset {
 struct { struct domainset *le_next; struct domainset **le_prev; } ds_link;
 domainset_t ds_mask;
 uint16_t ds_policy;
 domainid_t ds_prefer;
 domainid_t ds_cnt;
 domainid_t ds_order[8];
};
struct pmap_statistics {
 long resident_count;
 long wired_count;
};
struct pctrie_node;
struct pctrie {
 struct pctrie_node *pt_root;
};
struct pmap;
typedef struct pv_entry {
 vm_offset_t pv_va;
 struct { struct pv_entry *tqe_next; struct pv_entry **tqe_prev; } pv_next;
} *pv_entry_t;
struct pv_chunk {
 struct pmap *pc_pmap; struct { struct pv_chunk *tqe_next; struct pv_chunk **tqe_prev; } pc_list; unsigned long pc_map[(((168)+((64)-1))/(64))]; struct { struct pv_chunk *tqe_next; struct pv_chunk **tqe_prev; } pc_lru;
 struct pv_entry pc_pventry[168];
 unsigned long pc_pad[1];
};
typedef void *(*rs_dup_data_t)(void *ctx, void *data);
typedef void (*rs_free_data_t)(void *ctx, void *data);
struct rangeset {
 struct pctrie rs_trie;
 rs_dup_data_t rs_dup_data;
 rs_free_data_t rs_free_data;
 void *rs_data_ctx;
 u_int rs_alloc_flags;
};
typedef struct smr *smr_t;
struct vm_radix {
 struct pctrie rt_trie;
};
typedef u_int64_t pml4_entry_t;
enum pmap_type {
 PT_X86,
 PT_EPT,
 PT_RVI,
};
struct pmap {
 struct mtx pm_mtx;
 pml4_entry_t *pm_pmltop;
 pml4_entry_t *pm_pmltopu;
 uint64_t pm_cr3;
 uint64_t pm_ucr3;
 struct { struct pv_chunk *tqh_first; struct pv_chunk **tqh_last; } pm_pvchunk;
 cpuset_t pm_active;
 enum pmap_type pm_type;
 struct pmap_statistics pm_stats;
 struct vm_radix pm_root;
 long pm_eptgen;
 smr_t pm_eptsmr;
 int pm_flags;
 struct pmap_pcid *pm_pcidp;
 struct rangeset pm_pkru;
};
typedef struct pmap *pmap_t;
struct thread;
struct thread;
typedef u_int vm_eflags_t;
union vm_map_object {
 struct vm_object *vm_object;
 struct vm_map *sub_map;
};
struct vm_map_entry {
 struct vm_map_entry *left;
 struct vm_map_entry *right;
 vm_offset_t start;
 vm_offset_t end;
 vm_offset_t next_read;
 vm_size_t max_free;
 union vm_map_object object;
 vm_ooffset_t offset;
 vm_eflags_t eflags;
 vm_prot_t protection;
 vm_prot_t max_protection;
 vm_inherit_t inheritance;
 uint8_t read_ahead;
 int wired_count;
 struct ucred *cred;
 struct thread *wiring_thread;
};
struct vm_map {
 struct vm_map_entry header;
 union {
  struct sx lock;
  struct mtx system_mtx;
 };
 int nentries;
 vm_size_t size;
 u_int timestamp;
 u_int flags;
 vm_map_entry_t root;
 pmap_t pmap;
 vm_offset_t anon_loc;
 int busy;



};
struct vmspace {
 struct vm_map vm_map;
 struct shmmap_state *vm_shm;
 segsz_t vm_swrss;
 segsz_t vm_tsize;
 segsz_t vm_dsize;
 segsz_t vm_ssize;
 caddr_t vm_taddr;
 caddr_t vm_daddr;
 caddr_t vm_maxsaddr;
 vm_offset_t vm_aslr_delta_mmap;
 vm_offset_t vm_aslr_delta_rtld;
 vm_offset_t vm_aslr_delta_stack;
 vm_offset_t vm_aslr_delta_thr_stack;
 vm_offset_t vm_aslr_delta_exec;
 vm_offset_t vm_aslr_delta_vdso;

 vm_offset_t vm_aslr_delta_map32bit;

 u_int vm_refcnt;





 struct pmap vm_pmap;
};
static struct efi_rt *efi_runtime;
static int efi_enter(void);
static struct mtx efi_lock;
/*@ requires 1; ensures \result == 0 ==> (td->td_pflags & 0x20000000) != 0; */

static int
efi_enter(void)
{
 struct thread *td;
 pmap_t curpmap;
 int error;

 if (efi_runtime == ((void *)0))
  return (6);
 td = (__curthread());
 curpmap = &td->td_proc->p_vmspace->vm_pmap;
 __extension__ ({ uintptr_t _tid = (uintptr_t)((__curthread())); uintptr_t _v = 0x00000000; if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&(curpmap)->pm_mtx)))))->mtx_lock, &_v, (_tid))), 0)) __mtx_lock_sleep(&(((((&(curpmap)->pm_mtx)))))->mtx_lock, _v); (void)0; });
 __extension__ ({ uintptr_t _tid = (uintptr_t)((__curthread())); uintptr_t _v = 0x00000000; if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&efi_lock)))))->mtx_lock, &_v, (_tid))), 0)) __mtx_lock_sleep(&(((((&efi_lock)))))->mtx_lock, _v); (void)0; });
 fpu_kern_enter(td, ((void *)0), 0x0004);
 error = efi_arch_enter();
 if (error != 0) {
  fpu_kern_leave(td, ((void *)0));
  __extension__ ({ uintptr_t _v = (uintptr_t)((__curthread())); if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&efi_lock)))))->mtx_lock, (&_v), 0x00000000)), 0)) __mtx_unlock_sleep(&(((((&efi_lock)))))->mtx_lock, _v); (void)0; });
  __extension__ ({ uintptr_t _v = (uintptr_t)((__curthread())); if (__builtin_expect((0 || !atomic_fcmpset_long(&(((((&(curpmap)->pm_mtx)))))->mtx_lock, (&_v), 0x00000000)), 0)) __mtx_unlock_sleep(&(((((&(curpmap)->pm_mtx)))))->mtx_lock, _v); (void)0; });
 } else {
  do { } while (0);
  td->td_pflags |= 0x20000000;
 }
 return (error);
}
