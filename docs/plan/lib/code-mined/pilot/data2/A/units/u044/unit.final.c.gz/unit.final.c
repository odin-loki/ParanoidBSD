typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
u64 idpf_ptp_tstamp_extend_32b_to_64b(u64 cached_phc_time, u32 in_timestamp);
/*@ requires true; ensures \exists u32 d; d == (u32)in_timestamp - (u32)cached_phc_time && (d <= ((u32)~0U)/2 ==> \result == cached_phc_time + d) && (d > ((u32)~0U)/2 ==> \result == cached_phc_time - ((u32)cached_phc_time - in_timestamp)); */

u64 idpf_ptp_tstamp_extend_32b_to_64b(u64 cached_phc_time, u32 in_timestamp)
{
 u32 delta, phc_time_lo;
 u64 ns;


 phc_time_lo = (u32)cached_phc_time;




 delta = in_timestamp - phc_time_lo;

 if (delta > ((u32)~0U) / 2) {

  delta = phc_time_lo - in_timestamp;
  ns = cached_phc_time - delta;
 } else {
  ns = cached_phc_time + delta;
 }

 return ns;
}
