typedef unsigned int __u32;
typedef __u32 u32;
/*@ requires channel <= 0xffff; ensures \result == 0x720 + channel * 4; */

static inline    u32 host1x_sync_cbread_r(unsigned int channel)
{
 return 0x720 + channel * 4;
}
