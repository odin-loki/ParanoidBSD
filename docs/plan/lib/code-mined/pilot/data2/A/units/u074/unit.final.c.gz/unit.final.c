typedef long unsigned int size_t;
typedef long int __off_t;
typedef long int __off64_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;
typedef void _IO_lock_t;
struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
extern FILE *stdout;
extern int fflush (FILE *__stream);
extern int printf (const char *__restrict __format, ...);
extern int close (int __fd);
__extension__ typedef unsigned long long __u64;
extern int ioctl (int __fd, unsigned long int __request, ...) ;
struct uffdio_api {

 __u64 api;
 __u64 features;

 __u64 ioctls;
};
static inline void ksft_inc_fail_cnt(void) ;
int uffd_open_dev(unsigned int flags);
int uffd_open_sys(unsigned int flags);
static void uffd_test_pass(void)
;
static void uffd_test_skip(const char *message)
;
/*@ requires 1; ensures (\result == 1 || \result == 0); */

static int test_uffd_api(
                        _Bool 
                             use_dev)
{
 struct uffdio_api uffdio_api;
 int uffd;

 do { printf("Testing "); printf("UFFDIO_API (with %s)", use_dev ? "/dev/userfaultfd" : "syscall"); printf("... "); fflush(
stdout
); } while (0)
                                            ;

 if (use_dev)
  uffd = uffd_open_dev((
                      02000000 
                      | 
                      04000 
                      | 1));
 else
  uffd = uffd_open_sys((
                      02000000 
                      | 
                      04000 
                      | 1));
 if (uffd < 0) {
  uffd_test_skip("cannot open userfaultfd handle");
  return 0;
 }


 uffdio_api.api = 0xab;
 uffdio_api.features = 0;
 if (ioctl(uffd, 
                (((2U|1U) << (((0 +8)+8)+14)) | (((
                0xAA
                )) << (0 +8)) | (((
                (0x3F)
                )) << 0) | ((((sizeof(
                struct uffdio_api
                )))) << ((0 +8)+8)))
                          , &uffdio_api) == 0) {
  do { printf("failed [reason: "); printf("UFFDIO_API should fail with wrong api but didn't"); printf("]\n"); ksft_inc_fail_cnt(); } while (0);
  goto out;
 }


 uffdio_api.api = ((__u64)0xAA);
 uffdio_api.features = (1ULL << (63));
 if (ioctl(uffd, 
                (((2U|1U) << (((0 +8)+8)+14)) | (((
                0xAA
                )) << (0 +8)) | (((
                (0x3F)
                )) << 0) | ((((sizeof(
                struct uffdio_api
                )))) << ((0 +8)+8)))
                          , &uffdio_api) == 0) {
  do { printf("failed [reason: "); printf("UFFDIO_API should fail with wrong feature but didn't"); printf("]\n"); ksft_inc_fail_cnt(); } while (0);
  goto out;
 }


 uffdio_api.api = ((__u64)0xAA);
 uffdio_api.features = 0;
 if (ioctl(uffd, 
                (((2U|1U) << (((0 +8)+8)+14)) | (((
                0xAA
                )) << (0 +8)) | (((
                (0x3F)
                )) << 0) | ((((sizeof(
                struct uffdio_api
                )))) << ((0 +8)+8)))
                          , &uffdio_api)) {
  do { printf("failed [reason: "); printf("UFFDIO_API should succeed but failed"); printf("]\n"); ksft_inc_fail_cnt(); } while (0);
  goto out;
 }


 uffdio_api.features = (1ULL << (0));
 if (ioctl(uffd, 
                (((2U|1U) << (((0 +8)+8)+14)) | (((
                0xAA
                )) << (0 +8)) | (((
                (0x3F)
                )) << 0) | ((((sizeof(
                struct uffdio_api
                )))) << ((0 +8)+8)))
                          , &uffdio_api) == 0) {
  do { printf("failed [reason: "); printf("UFFDIO_API should reject initialized uffd"); printf("]\n"); ksft_inc_fail_cnt(); } while (0);
  goto out;
 }

 uffd_test_pass();
out:
 close(uffd);

 return 1;
}
