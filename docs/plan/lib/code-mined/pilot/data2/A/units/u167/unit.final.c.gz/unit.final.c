typedef unsigned int __u32;
typedef __u32 u32;
typedef _Bool bool;
struct debug_data_s {
 u32 enable;
 u32 bufmode;
 u32 head;
 u32 tail;
 u32 buf[1024];
};
typedef struct debug_data_s debug_data_t;
extern debug_data_t *debug_data_ptr;
extern bool is_debug_buffer_empty(void);
/*@ requires 0 <= debug_data_ptr->head < 1024 && 0 <= debug_data_ptr->tail < 1024; ensures \result == (debug_data_ptr->head == debug_data_ptr->tail); */

bool is_debug_buffer_empty(void)
{
 return (debug_data_ptr->head == debug_data_ptr->tail);
}
static debug_data_t debug_data;
debug_data_t *debug_data_ptr = &debug_data;
