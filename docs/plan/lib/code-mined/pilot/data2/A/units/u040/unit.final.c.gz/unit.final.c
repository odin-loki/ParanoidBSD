typedef unsigned int __u32;
typedef __u32 u32;
/*@ requires 0 <= rx_desc_cnt && rx_desc_cnt <= 0x7FFFFFFF; ensures \result == 2 * rx_desc_cnt; */

static inline    u32 gve_get_rx_pages_per_qpl_dqo(u32 rx_desc_cnt)
{



 return 2 * rx_desc_cnt;
}
