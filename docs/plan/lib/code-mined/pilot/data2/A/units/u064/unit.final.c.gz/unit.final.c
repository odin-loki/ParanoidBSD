typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef _Bool bool;
typedef __kernel_size_t size_t;
typedef u32 uint32_t;
typedef enum {
 INPUT_SYSTEM_ERR_NO_ERROR = 0,

 INPUT_SYSTEM_ERR_CREATE_CHANNEL_FAIL,
 INPUT_SYSTEM_ERR_CONFIGURE_CHANNEL_FAIL,
 INPUT_SYSTEM_ERR_OPEN_CHANNEL_FAIL,
 INPUT_SYSTEM_ERR_TRANSFER_FAIL,
 INPUT_SYSTEM_ERR_CREATE_INPUT_PORT_FAIL,
 INPUT_SYSTEM_ERR_CONFIGURE_INPUT_PORT_FAIL,
 INPUT_SYSTEM_ERR_OPEN_INPUT_PORT_FAIL,

 INPUT_SYSTEM_ERR_GENERIC,
 INPUT_SYSTEM_ERR_CHANNEL_ALREADY_SET,
 INPUT_SYSTEM_ERR_CONFLICT_ON_RESOURCE,
 INPUT_SYSTEM_ERR_PARAMETER_NOT_SUPPORTED,
} input_system_err_t;
typedef enum {
 INPUT_SYSTEM_PORT_A = 0,
 INPUT_SYSTEM_PORT_B,
 INPUT_SYSTEM_PORT_C,
 N_INPUT_SYSTEM_PORTS
} input_system_csi_port_t;
typedef struct target_cfg2400_s target_cfg2400_t;
typedef struct backend_channel_cfg_s backend_channel_cfg_t;
typedef struct input_switch_cfg_channel_s input_switch_cfg_channel_t;
typedef struct {

 u32 dummy_parameter;
} target_isp_cfg_t;
typedef struct {

 u32 dummy_parameter;
} target_sp_cfg_t;
typedef struct {

 u32 dummy_parameter;
} target_strm2mem_cfg_t;
struct input_switch_cfg_channel_s {
 u32 hsync_data_reg[2];
 u32 vsync_data_reg;
};
struct backend_channel_cfg_s {
 u32 fmt_control_word_1;
 u32 fmt_control_word_2;
 u32 no_side_band;
};
struct target_cfg2400_s {
 input_switch_cfg_channel_t input_switch_channel_cfg;
 target_isp_cfg_t target_isp_cfg;
 target_sp_cfg_t target_sp_cfg;
 target_strm2mem_cfg_t target_strm2mem_cfg;
};
input_system_err_t input_system_configuration_reset(void);
input_system_err_t input_system_configuration_commit(void);
input_system_err_t input_system_csi_xmem_channel_cfg(
    u32 ch_id,
    input_system_csi_port_t port,
    backend_channel_cfg_t backend_ch,
    u32 mem_region_size,
    u32 nof_mem_regions,
    u32 acq_mem_region_size,
    u32 acq_nof_mem_regions,
    target_cfg2400_t target,
    uint32_t nof_xmem_buffers
);
extern inline      bool fortify_memset_chk(__kernel_size_t size,
      const size_t p_size,
      const size_t p_size_field)
;
/*@ requires true; ensures \result == INPUT_SYSTEM_ERR_NO_ERROR || \result == INPUT_SYSTEM_ERR_GENERIC; */

static input_system_err_t ia_css_isys_2400_init(void)
{
 backend_channel_cfg_t backend_ch0;
 backend_channel_cfg_t backend_ch1;
 target_cfg2400_t targetB;
 target_cfg2400_t targetC;
 u32 acq_mem_region_size = 24;
 u32 acq_nof_mem_regions = 2;
 input_system_err_t error = INPUT_SYSTEM_ERR_NO_ERROR;

 ({ size_t __fortify_size = (size_t)(sizeof(backend_channel_cfg_t)); fortify_memset_chk(__fortify_size, __builtin_dynamic_object_size(&backend_ch0, 0), __builtin_dynamic_object_size(&backend_ch0, 1)), __builtin_memset(&backend_ch0, 0, __fortify_size); });
 ({ size_t __fortify_size = (size_t)(sizeof(backend_channel_cfg_t)); fortify_memset_chk(__fortify_size, __builtin_dynamic_object_size(&backend_ch1, 0), __builtin_dynamic_object_size(&backend_ch1, 1)), __builtin_memset(&backend_ch1, 0, __fortify_size); });
 ({ size_t __fortify_size = (size_t)(sizeof(targetB)); fortify_memset_chk(__fortify_size, __builtin_dynamic_object_size(&targetB, 0), __builtin_dynamic_object_size(&targetB, 1)), __builtin_memset(&targetB, 0, __fortify_size); });
 ({ size_t __fortify_size = (size_t)(sizeof(targetC)); fortify_memset_chk(__fortify_size, __builtin_dynamic_object_size(&targetC, 0), __builtin_dynamic_object_size(&targetC, 1)), __builtin_memset(&targetC, 0, __fortify_size); });

 error = input_system_configuration_reset();
 if (error != INPUT_SYSTEM_ERR_NO_ERROR)
  return error;

 error = input_system_csi_xmem_channel_cfg(
      0,
      INPUT_SYSTEM_PORT_A,
      backend_ch0,
      32,
      6,
      acq_mem_region_size,
      acq_nof_mem_regions,
      targetB,
      3);
 if (error != INPUT_SYSTEM_ERR_NO_ERROR)
  return error;

 error = input_system_csi_xmem_channel_cfg(
      1,
      INPUT_SYSTEM_PORT_B,
      backend_ch0,
      16,
      3,
      acq_mem_region_size,
      acq_nof_mem_regions,
      targetB,
      3);
 if (error != INPUT_SYSTEM_ERR_NO_ERROR)
  return error;

 error = input_system_csi_xmem_channel_cfg(
      2,
      INPUT_SYSTEM_PORT_C,
      backend_ch1,
      32,
      3,
      acq_mem_region_size,
      acq_nof_mem_regions,
      targetC,
      2);
 if (error != INPUT_SYSTEM_ERR_NO_ERROR)
  return error;

 error = input_system_configuration_commit();

 return error;
}
