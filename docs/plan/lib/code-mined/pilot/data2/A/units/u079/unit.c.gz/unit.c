typedef unsigned char __uint8_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
void free(void *);
void *malloc(size_t)   ;
typedef __uint8_t uint8_t;
typedef uint8_t u8;
struct wpabuf {
 size_t size;
 size_t used;
 u8 *buf;
 unsigned int flags;

};
int wpabuf_resize(struct wpabuf **buf, size_t add_len);
struct wpabuf * wpabuf_alloc(size_t len);
struct wpabuf * wpabuf_alloc_ext_data(u8 *data, size_t len);
void wpabuf_free(struct wpabuf *buf);
void * wpabuf_put(struct wpabuf *buf, size_t len);
struct wpabuf * wpabuf_concat(struct wpabuf *a, struct wpabuf *b);
struct wpabuf * wpabuf_zeropad(struct wpabuf *buf, size_t len);
enum {
 MSG_EXCESSIVE, MSG_MSGDUMP, MSG_DEBUG, MSG_INFO, MSG_WARNING, MSG_ERROR
};
void wpa_printf(int level, const char *fmt, ...)
;
/*@ requires \true; ensures (errors == 0 ==> \result == 0) && (errors > 0 ==> \result == -1); */

static int wpabuf_tests(void)
{
 int errors = 0;
 void *ptr;
 struct wpabuf *buf;

 wpa_printf(MSG_INFO, "wpabuf tests");

 ptr = malloc((100));
 if (ptr) {
  buf = wpabuf_alloc_ext_data(ptr, 100);
  if (buf) {
   if (wpabuf_resize(&buf, 100) < 0)
    errors++;
   else
    wpabuf_put(buf, 100);
   wpabuf_free(buf);
  } else {
   errors++;
   free((ptr));
  }
 } else {
  errors++;
 }

 buf = wpabuf_alloc(100);
 if (buf) {
  struct wpabuf *buf2;

  wpabuf_put(buf, 100);
  if (wpabuf_resize(&buf, 100) < 0)
   errors++;
  else
   wpabuf_put(buf, 100);
  buf2 = wpabuf_concat(buf, ((void *)0));
  if (buf2 != buf)
   errors++;
  wpabuf_free(buf2);
 } else {
  errors++;
 }

 buf = ((void *)0);
 buf = wpabuf_zeropad(buf, 10);
 if (buf != ((void *)0))
  errors++;

 if (errors) {
  wpa_printf(MSG_ERROR, "%d wpabuf test(s) failed", errors);
  return -1;
 }

 return 0;
}
