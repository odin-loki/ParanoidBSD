typedef unsigned char __uint8_t;
typedef unsigned short int __uint16_t;
typedef unsigned int __uint32_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef long unsigned int size_t;
typedef unsigned short int sa_family_t;
struct sockaddr
  {
    sa_family_t sa_family;
    char sa_data[14];
  };
struct sockaddr_storage
  {
    sa_family_t ss_family;
    char __ss_padding[(128 - (sizeof (unsigned short int)) - sizeof (unsigned long int))];
    unsigned long int __ss_align;
  };
typedef uint32_t in_addr_t;
struct in_addr
  {
    in_addr_t s_addr;
  };
enum
  {
    IPPROTO_IP = 0,
    IPPROTO_ICMP = 1,
    IPPROTO_IGMP = 2,
    IPPROTO_IPIP = 4,
    IPPROTO_TCP = 6,
    IPPROTO_EGP = 8,
    IPPROTO_PUP = 12,
    IPPROTO_UDP = 17,
    IPPROTO_IDP = 22,
    IPPROTO_TP = 29,
    IPPROTO_DCCP = 33,
    IPPROTO_IPV6 = 41,
    IPPROTO_RSVP = 46,
    IPPROTO_GRE = 47,
    IPPROTO_ESP = 50,
    IPPROTO_AH = 51,
    IPPROTO_MTP = 92,
    IPPROTO_BEETPH = 94,
    IPPROTO_ENCAP = 98,
    IPPROTO_PIM = 103,
    IPPROTO_COMP = 108,
    IPPROTO_L2TP = 115,
    IPPROTO_SCTP = 132,
    IPPROTO_UDPLITE = 136,
    IPPROTO_MPLS = 137,
    IPPROTO_ETHERNET = 143,
    IPPROTO_RAW = 255,
    IPPROTO_MPTCP = 262,
    IPPROTO_MAX
  };
typedef uint16_t in_port_t;
struct sockaddr_in
  {
    sa_family_t sin_family;
    in_port_t sin_port;
    struct in_addr sin_addr;


    unsigned char sin_zero[sizeof (struct sockaddr)
      - (sizeof (unsigned short int))
      - sizeof (in_port_t)
      - sizeof (struct in_addr)];
  };
extern uint16_t htons (uint16_t __hostshort)
      ;
struct iphdr
  {

    unsigned int ihl:4;
    unsigned int version:4;






    uint8_t tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag_off;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t check;
    uint32_t saddr;
    uint32_t daddr;

  };
extern void *memset (void *__s, int __c, size_t __n)  ;
static struct sockaddr_storage cfg_dst_addr;
static struct sockaddr_storage cfg_src_addr;
static uint16_t get_ip_csum(const uint16_t *start, int num_words)
;
/*@ requires \valid(iph); ensures \result == 20; */

static int setup_iph(struct iphdr *iph, uint16_t payload_len)
{
 struct sockaddr_in *daddr = (void *) &cfg_dst_addr;
 struct sockaddr_in *saddr = (void *) &cfg_src_addr;

 memset(iph, 0, sizeof(*iph));

 iph->version = 4;
 iph->tos = 0;
 iph->ihl = 5;
 iph->ttl = 2;
 iph->saddr = saddr->sin_addr.s_addr;
 iph->daddr = daddr->sin_addr.s_addr;
 iph->protocol = 
                IPPROTO_EGP
                           ;
 iph->tot_len = htons(sizeof(*iph) + payload_len);
 iph->check = get_ip_csum((void *) iph, iph->ihl << 1);

 return sizeof(*iph);
}
