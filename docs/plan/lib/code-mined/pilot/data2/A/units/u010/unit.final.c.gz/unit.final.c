typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == ((v & 0xffff) << 2); */

static inline    u32 host1x_uclass_indoff_indroffset_f(u32 v)
{
 return (v & 0xffff) << 2;
}
