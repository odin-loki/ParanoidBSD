enum {
 false = 0,
 true = 1
};
extern void preempt_count_add(int val);
/*@ requires \true; ensures \result == 0; */

static int rcu_torture_read_lock_trivial(void)
{
 do { preempt_count_add(1); __asm__ volatile("": : :"memory"); } while (0);
 return 0;
}
