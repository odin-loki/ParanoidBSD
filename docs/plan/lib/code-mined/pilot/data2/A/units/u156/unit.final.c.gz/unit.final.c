typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __int64_t __intmax_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __size_t;
typedef __int64_t __register_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint32_t __gid_t;
typedef __int32_t __lwpid_t;
typedef __int64_t __off_t;
typedef __int32_t __pid_t;
typedef __int64_t __sbintime_t;
typedef __int64_t __rlim_t;
typedef long __suseconds_t;
typedef __uint32_t __uid_t;
typedef int __cpusetid_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __intmax_t intmax_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef char * caddr_t;
typedef __cpusetid_t cpusetid_t;
typedef __gid_t gid_t;
typedef __lwpid_t lwpid_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __register_t register_t;
typedef __rlim_t rlim_t;
typedef __sbintime_t sbintime_t;
typedef __size_t size_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __vm_offset_t vm_offset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __register_t syscallarg_t;
typedef struct _device *device_t;
typedef _Bool bool;
typedef struct __sigset {
 __uint32_t __bits[4];
} __sigset_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
typedef __sigset_t sigset_t;
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
struct priority {
 u_char pri_class;
 u_char pri_level;
 u_char pri_native;
 u_char pri_user;
};
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct region_descriptor;
static __inline u_short
rss(void)
;
extern const char version[];
struct _cpuset { unsigned long __bits[(((((1)) + (((sizeof(unsigned long) * 8)) - 1)) / ((sizeof(unsigned long) * 8))))]; };
typedef struct _cpuset cpuset_t;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
 long ru_maxrss;
 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;
};
struct system_segment_descriptor {
 u_int64_t sd_lolimit:16;
 u_int64_t sd_lobase:24;
 u_int64_t sd_type:5;
 u_int64_t sd_dpl:2;
 u_int64_t sd_p:1;
 u_int64_t sd_hilimit:4;
 u_int64_t sd_xx0:3;
 u_int64_t sd_gran:1;
 u_int64_t sd_hibase:40 __attribute__((__packed__));
 u_int64_t sd_xx1:8;
 u_int64_t sd_mbz:5;
 u_int64_t sd_xx2:19;
} __attribute__((__packed__));
struct region_descriptor {
 uint64_t rd_limit:16;
 uint64_t rd_base:64 __attribute__((__packed__));
} __attribute__((__packed__));
struct amd64tss {
 u_int32_t tss_rsvd0;
 u_int64_t tss_rsp0 __attribute__((__packed__));
 u_int64_t tss_rsp1 __attribute__((__packed__));
 u_int64_t tss_rsp2 __attribute__((__packed__));
 u_int32_t tss_rsvd1;
 u_int32_t tss_rsvd2;
 u_int64_t tss_ist1 __attribute__((__packed__));
 u_int64_t tss_ist2 __attribute__((__packed__));
 u_int64_t tss_ist3 __attribute__((__packed__));
 u_int64_t tss_ist4 __attribute__((__packed__));
 u_int64_t tss_ist5 __attribute__((__packed__));
 u_int64_t tss_ist6 __attribute__((__packed__));
 u_int64_t tss_ist7 __attribute__((__packed__));
 u_int32_t tss_rsvd3;
 u_int32_t tss_rsvd4;
 u_int16_t tss_rsvd5;
 u_int16_t tss_iobase;
};
struct lock_object;
struct mtx;
struct proc;
struct socket;
struct thread;
struct tty;
struct ucred;
struct trapframe;
struct trapframe {
 register_t tf_rdi;
 register_t tf_rsi;
 register_t tf_rdx;
 register_t tf_rcx;
 register_t tf_r8;
 register_t tf_r9;
 register_t tf_rax;
 register_t tf_rbx;
 register_t tf_rbp;
 register_t tf_r10;
 register_t tf_r11;
 register_t tf_r12;
 register_t tf_r13;
 register_t tf_r14;
 register_t tf_r15;
 uint32_t tf_trapno;
 uint16_t tf_fs;
 uint16_t tf_gs;
 register_t tf_addr;
 uint32_t tf_flags;
 uint16_t tf_es;
 uint16_t tf_ds;

 register_t tf_err;
 register_t tf_rip;
 uint16_t tf_cs;
 uint16_t tf_fred_evinfo3;
 uint32_t tf_fred_zero2;
 register_t tf_rflags;

 register_t tf_rsp;
 uint16_t tf_ss;
 uint16_t tf_fred_evinfo1;
 uint32_t tf_fred_evinfo2;
};
struct domainset;
struct mbuf;
struct m_tag {
 struct { struct m_tag *sle_next; } m_tag_link;
 u_int16_t m_tag_id;
 u_int16_t m_tag_len;
 u_int32_t m_tag_cookie;
 void (*m_tag_free)(struct m_tag *);
};
struct if_snd_tag_sw;
struct m_snd_tag {
 struct ifnet *ifp;
 const struct if_snd_tag_sw *sw;
 volatile u_int refcount;
};
struct pkthdr {
 union {
  struct m_snd_tag *snd_tag;
  struct ifnet *rcvif;
  struct {
   uint16_t rcvidx;
   uint16_t rcvgen;
  };
 };
 union {
  struct ifnet *leaf_rcvif;
  struct {
   uint16_t leaf_rcvidx;
   uint16_t leaf_rcvgen;
  };
 };
 struct packet_tags { struct m_tag *slh_first; } tags;
 int32_t len;


 uint32_t flowid;
 uint32_t csum_flags;
 uint16_t fibnum;
 uint8_t numa_domain;
 uint8_t rsstype;



 union {
  uint64_t rcv_tstmp;
  struct {
   uint8_t l2hlen;
   uint8_t l3hlen;
   uint8_t l4hlen;
   uint8_t l5hlen;
   uint8_t inner_l2hlen;
   uint8_t inner_l3hlen;
   uint8_t inner_l4hlen;
   uint8_t inner_l5hlen;
  };
 };
 union {
  uint8_t eight[8];
  uint16_t sixteen[4];
  uint32_t thirtytwo[2];
  uint64_t sixtyfour[1];
  uintptr_t unintptr[1];
  void *ptr;
 } PH_per;


 union {
  union {
   uint8_t eight[8];
   uint16_t sixteen[4];
   uint32_t thirtytwo[2];
   uint64_t sixtyfour[1];
   uintptr_t unintptr[1];
   void *ptr;
  } PH_loc;

  u_int memlen;
 };
};
struct ktls_session;
struct socket;
typedef void m_ext_free_t(struct mbuf *);
struct m_ext {
 union {
  volatile u_int ext_count;
  volatile u_int *ext_cnt;
 };
 uint32_t ext_size;
 uint32_t ext_type:8,
    ext_flags:24;
 union {
  struct {
   char *ext_buf;
   void *ext_arg2;
  };
  struct {







   vm_paddr_t extpg_pa[(40 / sizeof(vm_paddr_t))];
   char extpg_trail[64];
   char extpg_hdr[23];

  };
 };




 m_ext_free_t *ext_free;
 void *ext_arg1;
};
struct mbuf {







 union {
  struct mbuf *m_next;
  struct { struct mbuf *sle_next; } m_slist;
  struct { struct mbuf *stqe_next; } m_stailq;
 };
 union {
  struct mbuf *m_nextpkt;
  struct { struct mbuf *sle_next; } m_slistpkt;
  struct { struct mbuf *stqe_next; } m_stailqpkt;
 };
 caddr_t m_data;
 int32_t m_len;
 uint32_t m_type:8,
    m_flags:24;
 union {
  struct {
   union {

    struct pkthdr m_pkthdr;
    struct {


     uint8_t m_epg_npgs;
     uint8_t m_epg_nrdy;


     uint8_t m_epg_hdrlen;
     uint8_t m_epg_trllen;


     uint16_t m_epg_1st_off;
     uint16_t m_epg_last_len;
     uint8_t m_epg_flags;
     uint8_t m_epg_record_type;
     uint8_t __spare[2];
     int m_epg_enc_cnt;
     struct ktls_session *m_epg_tls;
     struct socket *m_epg_so;
     uint64_t m_epg_seqno;
     struct { struct mbuf *stqe_next; } m_epg_stailq;
    };
   };
   union {

    struct m_ext m_ext;

    char m_pktdat[1];
   };
  };
  char m_dat[1];
 };
};
static __inline void
m_tag_free(struct m_tag *t)
;
struct socket;
struct thread;
struct ifnet;
struct mbuf;
struct ucred;
struct kaiocb;
struct knote;
struct socket;
struct lock_list_entry;
struct thread;
struct lock_profile_object;
struct lpohead { struct lock_profile_object *lh_first; };
struct vnode;
struct thread;
struct proc;
struct thread;
struct ucred;
typedef unsigned long bitstr_t;
struct ifmediareq {
 char ifm_name[16];
 int ifm_current;
 int ifm_mask;
 int ifm_status;
 int ifm_active;
 int ifm_count;
 int *ifm_ulist;
};
typedef struct ifnet *if_t;
struct socket;
struct vnet;
struct ifmedia;
struct vnet {
 struct { struct vnet *le_next; struct vnet **le_prev; } vnet_le;
 u_int vnet_magic_n;
 u_int vnet_ifcnt;
 u_int vnet_sockcnt;
 u_int vnet_state;
 void *vnet_data_mem;
 uintptr_t vnet_data_base;
 bool vnet_shutdown;
} ;
struct kevent {
 __uintptr_t ident;
 short filter;
 unsigned short flags;
 unsigned int fflags;
 __int64_t data;
 void *udata;
 __uint64_t ext[4];
};
struct knote;
struct klist { struct knote *slh_first; };
struct kqueue;
struct knlist {
 struct klist kl_list;
 void (*kl_lock)(void *);
 void (*kl_unlock)(void *);
 void (*kl_assert_lock)(void *, int);
 void *kl_lockarg;
 int kl_autodestroy;
};
struct kinfo_knote;
struct proc;
struct filterops {
 int f_isfd;
 int (*f_attach)(struct knote *kn);
 void (*f_detach)(struct knote *kn);
 int (*f_event)(struct knote *kn, long hint);
 void (*f_touch)(struct knote *kn, struct kevent *kev, u_long type);
 int (*f_userdump)(struct proc *p, struct knote *kn,
      struct kinfo_knote *kin);
 int (*f_copy)(struct knote *kn, struct proc *p1);
};
struct knote {
 struct { struct knote *sle_next; } kn_link;
 struct { struct knote *sle_next; } kn_selnext;
 struct knlist *kn_knlist;
 struct { struct knote *tqe_next; struct knote **tqe_prev; } kn_tqe;
 struct kqueue *kn_kq;
 struct kevent kn_kevent;
 void *kn_hook;
 int kn_hookid;
 int kn_status;
 int kn_influx;
 unsigned int kn_sfflags;
 int64_t kn_sdata;
 union {
  struct file *p_fp;
  struct proc *p_proc;
  struct kaiocb *p_aio;
  struct aioliojob *p_lio;
  struct prison *p_prison;
  void *p_v;
 } kn_ptr;
 const struct filterops *kn_fop;

};
struct thread;
struct proc;
struct knlist;
struct mtx;
void knote(struct knlist *list, long hint, int lockflags);
struct ifnethead { struct ifnet *cstqh_first; struct ifnet **cstqh_last; };
struct ktls_session;
struct m_snd_tag;
struct if_snd_tag_rate_limit_params {
 uint64_t max_rate;
 uint32_t queue_level;
 uint32_t flags;
};
struct if_snd_tag_modify_tls_rx {

 uint32_t tls_hdr_tcp_sn;





 uint32_t tls_rec_length;


 uint64_t tls_seq_number;
};
union if_snd_tag_modify_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
 struct if_snd_tag_modify_tls_rx tls_rx;
};
union if_snd_tag_query_params {
 struct if_snd_tag_rate_limit_params rate_limit;
 struct if_snd_tag_rate_limit_params unlimited;
 struct if_snd_tag_rate_limit_params tls_rate_limit;
};
typedef int (if_snd_tag_modify_t)(struct m_snd_tag *, union if_snd_tag_modify_params *);
typedef int (if_snd_tag_query_t)(struct m_snd_tag *, union if_snd_tag_query_params *);
typedef void (if_snd_tag_free_t)(struct m_snd_tag *);
typedef struct m_snd_tag *(if_next_send_tag_t)(struct m_snd_tag *);
typedef int (if_snd_tag_status_str_t)(struct m_snd_tag *, char *buf, size_t *sz);
struct if_snd_tag_sw {
 if_snd_tag_modify_t *snd_tag_modify;
 if_snd_tag_query_t *snd_tag_query;
 if_snd_tag_free_t *snd_tag_free;
 if_next_send_tag_t *next_snd_tag;
 if_snd_tag_status_str_t *snd_tag_status_str;
 u_int type;
};
extern struct ifnethead ifnet;
struct ifnet;
struct ifnet;
struct mbuf;
struct ifnet;
struct mbuf;
struct ifnet;
struct ifnet;
typedef int (*ifm_change_cb_t)(struct ifnet *);
typedef void (*ifm_stat_cb_t)(struct ifnet *, struct ifmediareq *req);
struct ifmedia_entry {
 struct { struct ifmedia_entry *le_next; struct ifmedia_entry **le_prev; } ifm_list;
 int ifm_media;
 int ifm_data;
 void *ifm_aux;
};
struct ifmedia {
 int ifm_mask;
 int ifm_media;
 struct ifmedia_entry *ifm_cur;
 struct { struct ifmedia_entry *lh_first; } ifm_list;
 ifm_change_cb_t ifm_change;
 ifm_stat_cb_t ifm_status;
};
typedef uint64_t bus_addr_t;
typedef uint64_t bus_size_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
struct resource;
struct _cpuset;
struct setlist { struct cpuset *lh_first; };
struct cpuset {
 volatile u_int cs_ref;
 int cs_flags;
 struct { struct cpuset *le_next; struct cpuset **le_prev; } cs_link;
 struct { struct cpuset *le_next; struct cpuset **le_prev; } cs_siblings;
 struct setlist cs_children;
 struct domainset *cs_domain;
 cpusetid_t cs_id;
 struct cpuset *cs_parent;
 cpuset_t cs_mask;
};
struct prison;
struct proc;
struct thread;
struct mbuf;
typedef struct bus_dma_segment {
 bus_addr_t ds_addr;
 bus_size_t ds_len;
} bus_dma_segment_t;
struct proc;
struct thread;
typedef uint16_t qidx_t;
struct iflib_ctx;
typedef struct iflib_ctx *if_ctx_t;
typedef struct if_rxd_frag {
 uint8_t irf_flid;
 qidx_t irf_idx;
 uint16_t irf_len;
} *if_rxd_frag_t;
typedef struct if_rxd_info {

 uint16_t iri_qsidx;
 uint16_t iri_vtag;

 uint16_t iri_len;
 qidx_t iri_cidx;
 if_t iri_ifp;


 if_rxd_frag_t iri_frags;
 uint32_t iri_flowid;
 uint32_t iri_csum_flags;

 uint32_t iri_csum_data;
 uint8_t iri_flags;
 uint8_t iri_nfrags;
 uint8_t iri_rsstype;
 uint8_t iri_pad;
} *if_rxd_info_t;
typedef struct if_rxd_update {
 uint64_t *iru_paddrs;
 qidx_t *iru_idxs;
 qidx_t iru_pidx;
 uint16_t iru_qsidx;
 uint16_t iru_count;
 uint16_t iru_buf_size;
 uint8_t iru_flidx;
} *if_rxd_update_t;
typedef struct if_pkt_info {
 bus_dma_segment_t *ipi_segs;
 uint32_t ipi_len;
 uint16_t ipi_qsidx;
 qidx_t ipi_nsegs;

 qidx_t ipi_ndescs;
 uint16_t ipi_flags;
 qidx_t ipi_pidx;
 qidx_t ipi_new_pidx;

 uint8_t ipi_ehdrlen;
 uint8_t ipi_ip_hlen;
 uint8_t ipi_tcp_hlen;
 uint8_t ipi_ipproto;

 uint32_t ipi_csum_flags;
 uint16_t ipi_tso_segsz;
 uint16_t ipi_vtag;
 uint16_t ipi_etype;
 uint16_t ipi_tcp_hflags;

 uint32_t ipi_tcp_seq;
 uint8_t ipi_ip_tos;
 uint8_t ipi_mflags;
 uint8_t __spare0__;
 uint8_t __spare1__;
 struct mbuf *ipi_mbuf;
} *if_pkt_info_t;
typedef struct if_irq {
 struct resource *ii_res;
 int __spare0__;
 void *ii_tag;
} *if_irq_t;
typedef enum {
 IFLIB_INTR_LEGACY,
 IFLIB_INTR_MSI,
 IFLIB_INTR_MSIX
} iflib_intr_mode_t;
typedef struct if_txrx {
 int (*ift_txd_encap) (void *, if_pkt_info_t);
 void (*ift_txd_flush) (void *, uint16_t, qidx_t pidx);
 int (*ift_txd_credits_update) (void *, uint16_t qsidx, bool clear);

 int (*ift_rxd_available) (void *, uint16_t qsidx, qidx_t pidx, qidx_t budget);
 int (*ift_rxd_pkt_get) (void *, if_rxd_info_t ri);
 void (*ift_rxd_refill) (void * , if_rxd_update_t iru);
 void (*ift_rxd_flush) (void *, uint16_t qsidx, uint8_t flidx, qidx_t pidx);
 int (*ift_legacy_intr) (void *);
 qidx_t (*ift_txq_select) (void *, struct mbuf *);
 qidx_t (*ift_txq_select_v2) (void *, struct mbuf *, if_pkt_info_t);
} *if_txrx_t;
typedef struct if_softc_ctx {
 int isc_vectors;
 int isc_nrxqsets;
 int isc_ntxqsets;
 uint16_t isc_tx_pad;
 uint32_t __spare1__;
 int isc_msix_bar;
 int isc_tx_nsegments;
 int isc_ntxd[8];
 int isc_nrxd[8];

 uint32_t isc_txqsizes[8];
 uint32_t isc_rxqsizes[8];

 uint8_t isc_txd_size[8];
 uint8_t isc_rxd_size[8];

 int isc_tx_tso_segments_max;
 int isc_tx_tso_size_max;
 int isc_tx_tso_segsize_max;
 int isc_tx_csum_flags;
 int isc_capabilities;
 int isc_capenable;
 int isc_rss_table_size;
 int isc_rss_table_mask;
 int isc_nrxqsets_max;
 int isc_ntxqsets_max;
 uint32_t __spare2__;

 iflib_intr_mode_t isc_intr;
 uint16_t isc_rxd_buf_size[8];


 uint16_t isc_max_frame_size;
 uint16_t isc_min_frame_size;

 uint32_t isc_pause_frames;
 uint32_t __spare3__;
 uint32_t __spare4__;
 uint32_t __spare5__;
 uint32_t __spare6__;
 uint32_t __spare7__;
 uint32_t __spare8__;
 caddr_t __spare9__;
 int isc_disable_msix;
 if_txrx_t isc_txrx;
 struct ifmedia *isc_media;
 bus_size_t isc_dma_width;

} *if_softc_ctx_t;
struct ucred;
struct thread;
struct ifnet;
struct mbuf;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct vm_map_entry;
struct ucred;
struct thread;
struct thread;
struct kexterr {
 int error;
 const char *msg;
 __uint64_t p1;
 __uint64_t p2;
 unsigned cat;
 unsigned src_line;
};
struct cv {
 const char *cv_description;
 int cv_waiters;
};
struct lock_object;
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
struct thread;
struct sigio {
 union {
  struct proc *siu_proc;
  struct pgrp *siu_pgrp;
 } sio_u;
 struct { struct sigio *sle_next; } sio_pgsigio;
 struct sigio **sio_myref;

 struct ucred *sio_ucred;
 pid_t sio_pgid;
};
struct sigiolst { struct sigio *slh_first; };
typedef struct sigaltstack stack_t;
struct sigaltstack {
 void *ss_sp;
 __size_t ss_size;
 int ss_flags;
};
union sigval {

 int sival_int;
 void *sival_ptr;

 int sigval_int;
 void *sigval_ptr;
};
typedef void __sighandler_t(int);
typedef struct __siginfo {
 int si_signo;
 int si_errno;






 int si_code;
 __pid_t si_pid;
 __uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 union {
  struct {
   int _trapno;
  } _fault;
  struct {
   int _timerid;
   int _overrun;
  } _timer;
  struct {
   int _mqd;
  } _mesgq;
  struct {
   long _band;
  } _poll;
  struct {
   int _syscall;



  } _capsicum;
  struct {
   long __spare1__;
   int __spare2__[7];
  } __spare__;
 } _reason;
} siginfo_t;
struct __siginfo;
typedef __sighandler_t *sig_t;
struct sigacts {
 sig_t ps_sigact[128];
 sigset_t ps_catchmask[128];
 sigset_t ps_sigonstack;
 sigset_t ps_sigintr;
 sigset_t ps_sigreset;
 sigset_t ps_signodefer;
 sigset_t ps_siginfo;
 sigset_t ps_sigignore;
 sigset_t ps_sigcatch;
 sigset_t ps_freebsd4;
 sigset_t ps_osigset;
 sigset_t ps_usertramp;
 int ps_flag;
 u_int ps_refcnt;
 struct mtx ps_mtx;
};
typedef struct ksiginfo {
 struct { struct ksiginfo *tqe_next; struct ksiginfo **tqe_prev; } ksi_link;
 siginfo_t ksi_info;
 int ksi_flags;
 struct sigqueue *ksi_sigq;
} ksiginfo_t;
typedef struct sigqueue {
 sigset_t sq_signals;
 sigset_t sq_kill;
 sigset_t sq_ptrace;
 struct { struct ksiginfo *tqh_first; struct ksiginfo **tqh_last; } sq_list;
 struct proc *sq_proc;
 int sq_flags;
} sigqueue_t;
struct pgrp;
struct proc;
struct sigio;
struct thread;
struct thread;
typedef uid_t au_id_t;
typedef pid_t au_asid_t;
typedef u_int64_t au_asflgs_t ;
struct au_tid_addr {
 u_int32_t at_port;
 u_int32_t at_type;
 u_int32_t at_addr[4];
};
typedef struct au_tid_addr au_tid_addr_t;
struct au_mask {
 unsigned int am_success;
 unsigned int am_failure;
};
typedef struct au_mask au_mask_t;
struct auditinfo_addr {
 au_id_t ai_auid;
 au_mask_t ai_mask;
 au_tid_addr_t ai_termid;
 au_asid_t ai_asid;
 au_asflgs_t ai_flags;
};
struct label;
struct loginclass;
struct prison;
struct uidinfo;
struct ucred {
 struct mtx cr_mtx;
 long cr_ref;
 u_int cr_users;
 u_int cr_flags;
 struct auditinfo_addr cr_audit;
 int cr_ngroups;
 uid_t cr_uid;
 uid_t cr_ruid;
 uid_t cr_svuid;
 gid_t cr_gid;
 gid_t cr_rgid;
 gid_t cr_svgid;
 struct uidinfo *cr_uidinfo;
 struct uidinfo *cr_ruidinfo;
 struct prison *cr_prison;
 struct loginclass *cr_loginclass;
 void *cr_pspare2[2];
 struct label *cr_label;
 gid_t *cr_groups;
 int cr_agroups;

 gid_t cr_smallgroups[16];
};
struct mac;
struct thread;
struct proc;
struct domainset;
struct domainset_ref {
 struct domainset * volatile dr_policy;
 unsigned int dr_iter;
};
struct fpacc87 {
 uint8_t fp_bytes[10];
};
struct xmmacc {
 uint8_t xmm_bytes[16];
};
struct envxmm {
 uint16_t en_cw;
 uint16_t en_sw;
 uint8_t en_tw;
 uint8_t en_zero;
 uint16_t en_opcode;
 uint64_t en_rip;
 uint64_t en_rdp;
 uint32_t en_mxcsr;
 uint32_t en_mxcsr_mask;
};
struct savefpu {
 struct envxmm sv_env;
 struct {
  struct fpacc87 fp_acc;
  uint8_t fp_pad[6];
 } sv_fp[8];
 struct xmmacc sv_xmm[16];
 uint8_t sv_pad[96];
} ;
struct pcb {
 register_t pcb_r15;
 register_t pcb_r14;
 register_t pcb_r13;
 register_t pcb_r12;
 register_t pcb_rbp;
 register_t pcb_rsp;
 register_t pcb_rbx;
 register_t pcb_rip;
 register_t pcb_fsbase;
 register_t pcb_gsbase;
 register_t pcb_kgsbase;
 register_t pcb_cr0;
 register_t pcb_cr2;
 register_t pcb_cr3;
 register_t pcb_cr4;
 register_t pcb_dr0;
 register_t pcb_dr1;
 register_t pcb_dr2;
 register_t pcb_dr3;
 register_t pcb_dr6;
 register_t pcb_dr7;

 struct region_descriptor pcb_gdt;
 struct region_descriptor pcb_idt;
 struct region_descriptor pcb_ldt;
 uint16_t pcb_tr;

 u_int pcb_flags;

 uint16_t pcb_initial_fpucw;


 caddr_t pcb_onfault;

 uint64_t pcb_saved_ucr3;


 struct amd64tss *pcb_tssp;


 register_t pcb_efer;
 register_t pcb_star;
 register_t pcb_lstar;
 register_t pcb_cstar;
 register_t pcb_sfmask;

 struct savefpu *pcb_save;

 register_t pcb_tlsbase;
 uint64_t pcb_pad[4];
};
struct trapframe;
struct proc_ldt {
 caddr_t ldt_base;
 int ldt_refcnt;
};
struct pmap_invl_gen {
 u_long gen;
 union {
  struct { struct pmap_invl_gen *le_next; struct pmap_invl_gen **le_prev; } link;
  struct {
   struct pmap_invl_gen *next;
   u_char saved_pri;
  };
 };
} ;
struct mdthread {
 int md_spinlock_count;
 register_t md_saved_flags;
 register_t md_spurflt_addr;
 struct pmap_invl_gen md_invl_gen;
 register_t md_efirt_tmp;
 int md_efirt_dis_pf;
 struct pcb md_pcb;
 vm_offset_t md_stack_base;
 void *md_usr_fpu_save;
};
struct mdproc {
 struct proc_ldt *md_ldt;
 struct system_segment_descriptor md_ldt_sd;
 u_int md_flags;
};
struct session {
 u_int s_count;
 struct proc *s_leader;
 struct vnode *s_ttyvp;
 struct cdev_priv *s_ttydp;
 struct tty *s_ttyp;
 pid_t s_sid;

 char s_login[((((33)+((sizeof(long))-1))/(sizeof(long)))*(sizeof(long)))];
 struct mtx s_mtx;
};
struct pgrp {
 struct { struct pgrp *le_next; struct pgrp **le_prev; } pg_hash;
 struct { struct proc *lh_first; } pg_members;
 struct session *pg_session;
 struct sigiolst pg_sigiolst;
 pid_t pg_id;
 struct mtx pg_mtx;
 int pg_flags;
 struct sx pg_killsx;

};
struct pargs {
 u_int ar_ref;
 u_int ar_length;
 u_char ar_args[1];
};
struct cpuset;
struct filemon;
struct kaioinfo;
struct kaudit_record;
struct kcov_info;
struct kdtrace_proc;
struct kdtrace_thread;
struct kmsan_td;
struct kq_timer_cb_data;
struct mqueue_notifier;
struct proc;
struct procdesc;
struct racct;
struct sleepqueue;
struct socket;
struct thread;
struct trapframe;
struct turnstile;
struct vm_map_entry;
struct syscall_args {
 u_int code;
 u_int original_code;
 struct sysent *callp;
 register_t args[8];
};
struct rusage_ext {
 uint64_t rux_runtime;
 uint64_t rux_uticks;
 uint64_t rux_sticks;
 uint64_t rux_iticks;
 uint64_t rux_uu;
 uint64_t rux_su;
 uint64_t rux_tu;
};
struct thread {
 struct mtx *volatile td_lock;
 struct proc *td_proc;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_plist;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_runq;
 union {
  struct { struct thread *tqe_next; struct thread **tqe_prev; } td_slpq;
  struct thread *td_zombie;
 };
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_lockq;
 struct { struct thread *le_next; struct thread **le_prev; } td_hash;
 struct cpuset *td_cpuset;
 struct domainset_ref td_domain;
 struct seltd *td_sel;
 struct sleepqueue *td_sleepqueue;
 struct turnstile *td_turnstile;
 void *td_pad1;
 struct umtx_q *td_umtxq;
 lwpid_t td_tid;
 sigqueue_t td_sigqueue;
 u_char td_lend_user_pri;
 u_char td_allocdomain;
 u_char td_base_ithread_pri;
 struct kmsan_td *td_kmsan;


 int td_flags;
 int td_ast;
 int td_inhibitors;
 int td_pflags;
 int td_pflags2;
 int td_dupfd;
 int td_sqqueue;
 const void *td_wchan;
 const char *td_wmesg;
 volatile u_char td_owepreempt;
 u_char td_tsqueue;
 u_char _td_pad0[2];
 int td_locks;
 int td_rw_rlocks;
 int td_sx_slocks;
 int td_lk_slocks;
 struct lock_object *td_wantedlock;
 struct turnstile *td_blocked;
 const char *td_lockname;
 struct { struct turnstile *lh_first; } td_contested;
 struct lock_list_entry *td_sleeplocks;
 int td_intr_nesting_level;
 int td_pinned;
 struct ucred *td_realucred;
 struct ucred *td_ucred;
 struct plimit *td_limit;
 int td_slptick;
 int td_blktick;
 int td_swvoltick;
 int td_swinvoltick;
 u_int td_cow;
 struct rusage td_ru;
 struct rusage_ext td_rux;
 uint64_t td_incruntime;
 uint64_t td_runtime;
 u_int td_pticks;
 u_int td_sticks;
 u_int td_iticks;
 u_int td_uticks;
 int td_intrval;
 sigset_t td_oldsigmask;
 volatile u_int td_generation;
 stack_t td_sigstk;
 int td_xsig;
 u_long td_profil_addr;
 u_int td_profil_ticks;
 char td_name[19 + 1];
 struct file *td_fpop;
 int td_dbgflags;
 siginfo_t td_si;
 int td_ng_outbound;
 struct osd td_osd;
 struct vm_map_entry *td_map_def_user;
 pid_t td_dbg_forked;
 u_int td_no_sleeping;
 struct vnode *td_vp_reserved;
 void *td_su;
 sbintime_t td_sleeptimo;
 int td_rtcgen;
 int td_errno;
 size_t td_vslock_sz;
 struct kcov_info *td_kcov_info;
 long td_ucredref;
 struct kexterr td_kexterr;


 sigset_t td_sigmask;
 u_char td_rqindex;
 u_char td_base_pri;
 u_char td_priority;
 u_char td_pri_class;
 u_char td_user_pri;
 u_char td_base_user_pri;
 uint32_t td_pax;
 uintptr_t td_rb_list;
 uintptr_t td_rbp_list;
 uintptr_t td_rb_inact;
 struct syscall_args td_sa;

 void *td_sigblock_ptr;
 uint32_t td_sigblock_val;

 void *td_exterr_ptr;





 struct pcb *td_pcb;
 enum td_states {
  TDS_INACTIVE = 0x0,
  TDS_INHIBITED,
  TDS_CAN_RUN,
  TDS_RUNQ,
  TDS_RUNNING
 } td_state;

 union {
  syscallarg_t tdu_retval[2];
  off_t tdu_off;
 } td_uretoff;
 u_int td_cowgen;

 struct callout td_slpcallout;
 struct trapframe *td_frame;
 vm_offset_t td_kstack;
 u_short td_kstack_pages;
 u_short td_kstack_domain;
 volatile u_int td_critnest;
 struct mdthread td_md;
 struct kaudit_record *td_ar;
 struct lpohead td_lprof[2];
 struct kdtrace_thread *td_dtrace;
 struct vnet *td_vnet;
 const char *td_vnet_lpush;
 struct trapframe *td_intr_frame;
 struct proc *td_rfppwait_p;
 struct vm_page **td_ma;
 int td_ma_cnt;

 void *td_emuldata;
 int td_lastcpu;
 int td_oncpu;
 void *td_lkpi_task;
 int td_pmcpend;
 void *td_remotereq;
 off_t td_ktr_io_lim;



};
struct proc {
 struct { struct proc *le_next; struct proc **le_prev; } p_list;
 struct { struct thread *tqh_first; struct thread **tqh_last; } p_threads;
 struct mtx p_slock;
 struct ucred *p_ucred;
 struct filedesc *p_fd;
 struct filedesc_to_leader *p_fdtol;
 struct pwddesc *p_pd;
 struct pstats *p_stats;
 struct plimit *p_limit;
 struct callout p_limco;
 struct sigacts *p_sigacts;

 int p_flag;
 int p_flag2;
 enum p_states {
  PRS_NEW = 0,
  PRS_NORMAL,
  PRS_ZOMBIE
 } p_state;
 pid_t p_pid;
 struct { struct proc *le_next; struct proc **le_prev; } p_hash;
 struct { struct proc *le_next; struct proc **le_prev; } p_pglist;
 struct proc *p_pptr;
 struct { struct proc *le_next; struct proc **le_prev; } p_sibling;
 struct { struct proc *lh_first; } p_children;
 struct proc *p_reaper;
 struct { struct proc *lh_first; } p_reaplist;

 struct { struct proc *le_next; struct proc **le_prev; } p_reapsibling;

 struct mtx p_mtx;
 struct mtx p_statmtx;
 struct mtx p_itimmtx;
 struct mtx p_profmtx;
 struct ksiginfo *p_ksi;
 sigqueue_t p_sigqueue;
 pid_t p_oppid;


 struct vmspace *p_vmspace;
 u_int p_swtick;
 u_int p_cowgen;
 struct itimerval p_realtimer;
 struct rusage p_ru;
 struct rusage_ext p_rux;
 struct rusage_ext p_crux;
 int p_profthreads;
 volatile int p_exitthreads;
 int p_traceflag;
 struct ktr_io_params *p_ktrioparms;
 struct vnode *p_textvp;
 struct vnode *p_textdvp;
 char *p_binname;
 u_int p_lock;
 struct sigiolst p_sigiolst;
 int p_sigparent;
 int p_sig;
 u_int p_ptevents;
 struct kaioinfo *p_aioinfo;
 struct thread *p_singlethread;
 int p_suspcount;
 struct thread *p_xthread;
 int p_boundary_count;
 int p_pendingcnt;
 struct itimers *p_itimers;
 struct procdesc *p_procdesc;
 u_int p_treeflag;
 int p_pendingexits;
 struct filemon *p_filemon;
 int p_pdeathsig;



 u_int p_magic;
 int p_osrel;

 uint32_t p_fctl0;
 char p_comm[19 + 1];
 struct sysentvec *p_sysent;
 struct pargs *p_args;
 rlim_t p_cpulimit;
 signed char p_nice;
 int p_fibnum;
 uint32_t p_pax;
 pid_t p_reapsubtree;


 vm_offset_t p_usrstack;
 vm_offset_t p_psstrings;
 vm_offset_t p_timekeep_base;
 vm_offset_t p_shared_page_base;
 vm_offset_t p_sigcode_base;
 vm_offset_t p_vdso_base;
 uint64_t p_elf_flags;
 const void *p_elf_brandinfo;

 sbintime_t p_umtx_min_timeout;


 u_int p_xexit;
 u_int p_xsig;
 struct pgrp *p_pgrp;
 struct knlist *p_klist;
 int p_numthreads;
 struct mdproc p_md;
 struct callout p_itcallout;
 u_short p_acflag;
 struct proc *p_peers;
 struct proc *p_leader;
 void *p_emuldata;
 struct label *p_label;
 struct { struct ktr_request *stqh_first; struct ktr_request **stqh_last; } p_ktr;
 struct { struct mqueue_notifier *lh_first; } p_mqnotifier;
 struct kdtrace_proc *p_dtrace;
 struct cv p_pwait;
 struct racct *p_racct;
 int p_throttled;






 struct { struct proc *le_next; struct proc **le_prev; } p_orphan;
 struct { struct proc *lh_first; } p_orphans;

 struct { struct kq_timer_cb_data *tqh_first; struct kq_timer_cb_data **tqh_last; } p_kqtim_stop;
 struct { struct proc *le_next; struct proc **le_prev; } p_jaillist;
 u_int p_asig;
 u_int p_tree_refcnt;
 u_int p_execblock;
};
struct thread;
struct sysctl_req {
 struct thread *td;
 int lock;
 void *oldptr;
 size_t oldlen;
 size_t oldidx;
 int (*oldfunc)(struct sysctl_req *, const void *, size_t);
 const void *newptr;
 size_t newlen;
 size_t newidx;
 int (*newfunc)(struct sysctl_req *, void *, size_t);
 size_t validlen;
 int flags;
};
struct sysctl_oid;
struct sysctl_oid_list { struct sysctl_oid *rbh_root; };
struct sysctl_oid {
 struct sysctl_oid_list oid_children;
 struct sysctl_oid_list* oid_parent;
 struct { struct sysctl_oid *rbe_link[3]; } oid_link;

 int oid_number;
 u_int oid_kind;
 void *oid_arg1;
 intmax_t oid_arg2;

 const char *oid_name;
 int (*oid_handler)(struct sysctl_oid *oidp, void *arg1, intmax_t arg2, struct sysctl_req *req);
 const char *oid_fmt;
 int oid_refcnt;
 u_int oid_running;
 const char *oid_descr;
 const char *oid_label;
};
struct sysctl_ctx_entry {
 struct sysctl_oid *entry;
 struct { struct sysctl_ctx_entry *tqe_next; struct sysctl_ctx_entry **tqe_prev; } link;
};
struct sysctl_ctx_list { struct sysctl_ctx_entry *tqh_first; struct sysctl_ctx_entry **tqh_last; };
struct pcb;
struct trapframe;
typedef uint8_t u8;
typedef uint16_t u16;
typedef int16_t s16;
typedef uint32_t u32;
typedef uint64_t u64;
struct i40e_spinlock {
        struct mtx mutex;
};
struct i40e_dma_mem {
 void *va;
 u64 pa;
 bus_dma_tag_t tag;
 bus_dmamap_t map;
 bus_size_t size;
};
struct i40e_virt_mem {
 void *va;
 u32 size;
};
struct i40e_hw;
struct i40e_aq_desc {
 u16 flags;
 u16 opcode;
 u16 datalen;
 u16 retval;
 u32 cookie_high;
 u32 cookie_low;
 union {
  struct {
   u32 param0;
   u32 param1;
   u32 param2;
   u32 param3;
  } internal;
  struct {
   u32 param0;
   u32 param1;
   u32 addr_high;
   u32 addr_low;
  } external;
  u8 raw[16];
 } params;
};
enum i40e_admin_queue_err {
 I40E_AQ_RC_OK = 0,
 I40E_AQ_RC_EPERM = 1,
 I40E_AQ_RC_ENOENT = 2,
 I40E_AQ_RC_ESRCH = 3,
 I40E_AQ_RC_EINTR = 4,
 I40E_AQ_RC_EIO = 5,
 I40E_AQ_RC_ENXIO = 6,
 I40E_AQ_RC_E2BIG = 7,
 I40E_AQ_RC_EAGAIN = 8,
 I40E_AQ_RC_ENOMEM = 9,
 I40E_AQ_RC_EACCES = 10,
 I40E_AQ_RC_EFAULT = 11,
 I40E_AQ_RC_EBUSY = 12,
 I40E_AQ_RC_EEXIST = 13,
 I40E_AQ_RC_EINVAL = 14,
 I40E_AQ_RC_ENOTTY = 15,
 I40E_AQ_RC_ENOSPC = 16,
 I40E_AQ_RC_ENOSYS = 17,
 I40E_AQ_RC_ERANGE = 18,
 I40E_AQ_RC_EFLUSHED = 19,
 I40E_AQ_RC_BAD_ADDR = 20,
 I40E_AQ_RC_EMODE = 21,
 I40E_AQ_RC_EFBIG = 22,
};
struct i40e_aqc_vsi_properties_data {

 u16 valid_sections;

 u16 switch_id;
 u8 sw_reserved[2];

 u8 sec_flags;
 u8 sec_reserved;

 u16 pvid;
 u16 outer_vlan;
 u8 port_vlan_flags;


 u8 outer_vlan_flags;



 u8 pvlan_reserved[2];

 u32 ingress_table;








 u32 egress_table;

 u16 cas_pv_tag;
 u8 cas_pv_flags;

 u8 cas_pv_reserved;

 u16 mapping_flags;
 u16 queue_mapping[16];
 u16 tc_mapping[8];



 u8 queueing_opt_flags;
 u8 queueing_opt_reserved[3];

 u8 up_enable_bits;
 u8 sched_reserved;

 u32 outer_up_table;
 u8 cmd_reserved[8];

 u16 qs_handle[8];
 u16 stat_counter_idx;
 u16 sched_id;
 u8 resp_reserved[12];
};
enum i40e_aq_phy_type {
 I40E_PHY_TYPE_SGMII = 0x0,
 I40E_PHY_TYPE_1000BASE_KX = 0x1,
 I40E_PHY_TYPE_10GBASE_KX4 = 0x2,
 I40E_PHY_TYPE_10GBASE_KR = 0x3,
 I40E_PHY_TYPE_40GBASE_KR4 = 0x4,
 I40E_PHY_TYPE_XAUI = 0x5,
 I40E_PHY_TYPE_XFI = 0x6,
 I40E_PHY_TYPE_SFI = 0x7,
 I40E_PHY_TYPE_XLAUI = 0x8,
 I40E_PHY_TYPE_XLPPI = 0x9,
 I40E_PHY_TYPE_40GBASE_CR4_CU = 0xA,
 I40E_PHY_TYPE_10GBASE_CR1_CU = 0xB,
 I40E_PHY_TYPE_10GBASE_AOC = 0xC,
 I40E_PHY_TYPE_40GBASE_AOC = 0xD,
 I40E_PHY_TYPE_UNRECOGNIZED = 0xE,
 I40E_PHY_TYPE_UNSUPPORTED = 0xF,
 I40E_PHY_TYPE_100BASE_TX = 0x11,
 I40E_PHY_TYPE_1000BASE_T = 0x12,
 I40E_PHY_TYPE_10GBASE_T = 0x13,
 I40E_PHY_TYPE_10GBASE_SR = 0x14,
 I40E_PHY_TYPE_10GBASE_LR = 0x15,
 I40E_PHY_TYPE_10GBASE_SFPP_CU = 0x16,
 I40E_PHY_TYPE_10GBASE_CR1 = 0x17,
 I40E_PHY_TYPE_40GBASE_CR4 = 0x18,
 I40E_PHY_TYPE_40GBASE_SR4 = 0x19,
 I40E_PHY_TYPE_40GBASE_LR4 = 0x1A,
 I40E_PHY_TYPE_1000BASE_SX = 0x1B,
 I40E_PHY_TYPE_1000BASE_LX = 0x1C,
 I40E_PHY_TYPE_1000BASE_T_OPTICAL = 0x1D,
 I40E_PHY_TYPE_20GBASE_KR2 = 0x1E,
 I40E_PHY_TYPE_25GBASE_KR = 0x1F,
 I40E_PHY_TYPE_25GBASE_CR = 0x20,
 I40E_PHY_TYPE_25GBASE_SR = 0x21,
 I40E_PHY_TYPE_25GBASE_LR = 0x22,
 I40E_PHY_TYPE_25GBASE_AOC = 0x23,
 I40E_PHY_TYPE_25GBASE_ACC = 0x24,
 I40E_PHY_TYPE_2_5GBASE_T = 0x26,
 I40E_PHY_TYPE_5GBASE_T = 0x27,
 I40E_PHY_TYPE_2_5GBASE_T_LINK_STATUS = 0x30,
 I40E_PHY_TYPE_5GBASE_T_LINK_STATUS = 0x31,
 I40E_PHY_TYPE_MAX,
 I40E_PHY_TYPE_NOT_SUPPORTED_HIGH_TEMP = 0xFD,
 I40E_PHY_TYPE_EMPTY = 0xFE,
 I40E_PHY_TYPE_DEFAULT = 0xFF,
};
enum i40e_aq_link_speed {
 I40E_LINK_SPEED_UNKNOWN = 0,
 I40E_LINK_SPEED_100MB = (1 << 0x1),
 I40E_LINK_SPEED_1GB = (1 << 0x2),
 I40E_LINK_SPEED_2_5GB = (1 << 0x0),
 I40E_LINK_SPEED_5GB = (1 << 0x7),
 I40E_LINK_SPEED_10GB = (1 << 0x3),
 I40E_LINK_SPEED_40GB = (1 << 0x4),
 I40E_LINK_SPEED_20GB = (1 << 0x5),
 I40E_LINK_SPEED_25GB = (1 << 0x6),
};
struct i40e_adminq_ring {
 struct i40e_virt_mem dma_head;
 struct i40e_dma_mem desc_buf;
 struct i40e_virt_mem cmd_buf;

 union {
  struct i40e_dma_mem *asq_bi;
  struct i40e_dma_mem *arq_bi;
 } r;

 u16 count;
 u16 rx_buf_len;


 u16 next_to_use;
 u16 next_to_clean;


 u32 head;
 u32 tail;
 u32 len;
 u32 bah;
 u32 bal;
};
struct i40e_adminq_info {
 struct i40e_adminq_ring arq;
 struct i40e_adminq_ring asq;
 u32 asq_cmd_timeout;
 u16 num_arq_entries;
 u16 num_asq_entries;
 u16 arq_buf_size;
 u16 asq_buf_size;
 u16 fw_maj_ver;
 u16 fw_min_ver;
 u32 fw_build;
 u16 api_maj_ver;
 u16 api_min_ver;

 struct i40e_spinlock asq_spinlock;
 struct i40e_spinlock arq_spinlock;


 enum i40e_admin_queue_err asq_last_status;
 enum i40e_admin_queue_err arq_last_status;
};
struct i40e_hw;
struct i40e_hmc_obj_info {
 u64 base;
 u32 max_cnt;
 u32 cnt;
 u64 size;
};
enum i40e_sd_entry_type {
 I40E_SD_TYPE_INVALID = 0,
 I40E_SD_TYPE_PAGED = 1,
 I40E_SD_TYPE_DIRECT = 2
};
struct i40e_hmc_bp {
 enum i40e_sd_entry_type entry_type;
 struct i40e_dma_mem addr;
 u32 sd_pd_index;
 u32 ref_cnt;
};
struct i40e_hmc_pd_entry {
 struct i40e_hmc_bp bp;
 u32 sd_index;
 bool rsrc_pg;
 bool valid;
};
struct i40e_hmc_pd_table {
 struct i40e_dma_mem pd_page_addr;
 struct i40e_hmc_pd_entry *pd_entry;
 struct i40e_virt_mem pd_entry_virt_mem;

 u32 ref_cnt;
 u32 sd_index;
};
struct i40e_hmc_sd_entry {
 enum i40e_sd_entry_type entry_type;
 bool valid;

 union {
  struct i40e_hmc_pd_table pd_table;
  struct i40e_hmc_bp bp;
 } u;
};
struct i40e_hmc_sd_table {
 struct i40e_virt_mem addr;
 u32 sd_cnt;
 u32 ref_cnt;
 struct i40e_hmc_sd_entry *sd_entry;
};
struct i40e_hmc_info {
 u32 signature;

 u8 hmc_fn_id;
 u16 first_sd_index;


 struct i40e_hmc_obj_info *hmc_obj;
 struct i40e_virt_mem hmc_obj_virt_mem;
 struct i40e_hmc_sd_table sd_table;
};
struct i40e_hw;
struct i40e_hw;
enum i40e_mac_type {
 I40E_MAC_UNKNOWN = 0,
 I40E_MAC_XL710,
 I40E_MAC_VF,
 I40E_MAC_X722,
 I40E_MAC_X722_VF,
 I40E_MAC_GENERIC,
};
enum i40e_media_type {
 I40E_MEDIA_TYPE_UNKNOWN = 0,
 I40E_MEDIA_TYPE_FIBER,
 I40E_MEDIA_TYPE_BASET,
 I40E_MEDIA_TYPE_BACKPLANE,
 I40E_MEDIA_TYPE_CX4,
 I40E_MEDIA_TYPE_DA,
 I40E_MEDIA_TYPE_VIRTUAL
};
enum i40e_fc_mode {
 I40E_FC_NONE = 0,
 I40E_FC_RX_PAUSE,
 I40E_FC_TX_PAUSE,
 I40E_FC_FULL,
 I40E_FC_PFC,
 I40E_FC_DEFAULT
};
enum i40e_vsi_type {
 I40E_VSI_MAIN = 0,
 I40E_VSI_VMDQ1 = 1,
 I40E_VSI_VMDQ2 = 2,
 I40E_VSI_CTRL = 3,
 I40E_VSI_FCOE = 4,
 I40E_VSI_MIRROR = 5,
 I40E_VSI_SRIOV = 6,
 I40E_VSI_FDIR = 7,
 I40E_VSI_IWARP = 8,
 I40E_VSI_TYPE_UNKNOWN
};
struct i40e_link_status {
 enum i40e_aq_phy_type phy_type;
 enum i40e_aq_link_speed link_speed;
 u8 link_info;
 u8 an_info;
 u8 req_fec_info;
 u8 fec_info;
 u8 ext_info;
 u8 loopback;

 bool lse_enable;
 u16 max_frame_size;
 bool crc_enable;
 u8 pacing;
 u8 requested_speeds;
 u8 module_type[3];



};
struct i40e_phy_info {
 struct i40e_link_status link_info;
 struct i40e_link_status link_info_old;
 bool get_link_info;
 enum i40e_media_type media_type;

 u64 phy_types;
};
enum i40e_acpi_programming_method {
 I40E_ACPI_PROGRAMMING_METHOD_HW_FVL = 0,
 I40E_ACPI_PROGRAMMING_METHOD_AQC_FPK = 1
};
struct i40e_hw_capabilities {
 u32 switch_mode;







 u32 management_mode;
 u32 mng_protocols_over_mctp;
 u32 npar_enable;
 u32 os2bmc;
 u32 valid_functions;
 bool sr_iov_1_1;
 bool vmdq;
 bool evb_802_1_qbg;
 bool evb_802_1_qbh;
 bool dcb;
 bool fcoe;
 bool iscsi;
 bool flex10_enable;
 bool flex10_capable;
 u32 flex10_mode;

 u32 flex10_status;

 bool sec_rev_disabled;
 bool update_disabled;

 bool mgmt_cem;
 bool ieee_1588;
 bool iwarp;
 bool fd;
 u32 fd_filters_guaranteed;
 u32 fd_filters_best_effort;
 bool rss;
 u32 rss_table_size;
 u32 rss_table_entry_width;
 bool led[30];
 bool sdp[30];
 u32 nvm_image_type;
 u32 num_flow_director_filters;
 u32 num_vfs;
 u32 vf_base_id;
 u32 num_vsis;
 u32 num_rx_qp;
 u32 num_tx_qp;
 u32 base_queue;
 u32 num_msix_vectors;
 u32 num_msix_vectors_vf;
 u32 led_pin_num;
 u32 sdp_pin_num;
 u32 mdio_port_num;
 u32 mdio_port_mode;
 u8 rx_buf_chain_len;
 u32 enabled_tcmap;
 u32 maxtc;
 u64 wr_csr_prot;
 bool dis_unused_ports;
 bool apm_wol_support;
 enum i40e_acpi_programming_method acpi_prog_method;
 bool proxy_support;
};
struct i40e_mac_info {
 enum i40e_mac_type type;
 u8 addr[6];
 u8 perm_addr[6];
 u8 san_addr[6];
 u8 port_addr[6];
 u16 max_fcoeq;
};
struct i40e_nvm_info {
 u64 hw_semaphore_timeout;
 u32 timeout;
 u16 sr_size;
 bool blank_nvm_mode;
 u16 version;
 u32 eetrack;
 u32 oem_ver;
};
enum i40e_nvmupd_state {
 I40E_NVMUPD_STATE_INIT,
 I40E_NVMUPD_STATE_READING,
 I40E_NVMUPD_STATE_WRITING,
 I40E_NVMUPD_STATE_INIT_WAIT,
 I40E_NVMUPD_STATE_WRITE_WAIT,
 I40E_NVMUPD_STATE_ERROR
};
struct i40e_nvmupd_features {
 u8 major;
 u8 minor;
 u16 size;
 u8 features[12];
};
enum i40e_bus_type {
 i40e_bus_type_unknown = 0,
 i40e_bus_type_pci,
 i40e_bus_type_pcix,
 i40e_bus_type_pci_express,
 i40e_bus_type_reserved
};
enum i40e_bus_speed {
 i40e_bus_speed_unknown = 0,
 i40e_bus_speed_33 = 33,
 i40e_bus_speed_66 = 66,
 i40e_bus_speed_100 = 100,
 i40e_bus_speed_120 = 120,
 i40e_bus_speed_133 = 133,
 i40e_bus_speed_2500 = 2500,
 i40e_bus_speed_5000 = 5000,
 i40e_bus_speed_8000 = 8000,
 i40e_bus_speed_reserved
};
enum i40e_bus_width {
 i40e_bus_width_unknown = 0,
 i40e_bus_width_pcie_x1 = 1,
 i40e_bus_width_pcie_x2 = 2,
 i40e_bus_width_pcie_x4 = 4,
 i40e_bus_width_pcie_x8 = 8,
 i40e_bus_width_32 = 32,
 i40e_bus_width_64 = 64,
 i40e_bus_width_reserved
};
struct i40e_bus_info {
 enum i40e_bus_speed speed;
 enum i40e_bus_width width;
 enum i40e_bus_type type;

 u16 func;
 u16 device;
 u16 lan_id;
 u16 bus_id;
};
struct i40e_fc_info {
 enum i40e_fc_mode current_mode;
 enum i40e_fc_mode requested_mode;
};
struct i40e_dcb_ets_config {
 u8 willing;
 u8 cbs;
 u8 maxtcs;
 u8 prioritytable[8];
 u8 tcbwtable[8];
 u8 tsatable[8];
};
struct i40e_dcb_pfc_config {
 u8 willing;
 u8 mbc;
 u8 pfccap;
 u8 pfcenable;
};
struct i40e_dcb_app_priority_table {
 u8 priority;
 u8 selector;
 u16 protocolid;
};
struct i40e_dcbx_config {
 u8 dcbx_mode;
 u8 app_mode;
 u32 numapps;
 u32 tlv_status;
 struct i40e_dcb_ets_config etscfg;
 struct i40e_dcb_ets_config etsrec;
 struct i40e_dcb_pfc_config pfc;
 struct i40e_dcb_app_priority_table app[32];
};
struct i40e_hw {
 u8 *hw_addr;
 void *back;


 struct i40e_phy_info phy;
 struct i40e_mac_info mac;
 struct i40e_bus_info bus;
 struct i40e_nvm_info nvm;
 struct i40e_fc_info fc;


 u16 device_id;
 u16 vendor_id;
 u16 subsystem_device_id;
 u16 subsystem_vendor_id;
 u8 revision_id;
 u8 port;
 bool adapter_stopped;


 struct i40e_hw_capabilities dev_caps;
 struct i40e_hw_capabilities func_caps;


 u16 fdir_shared_filter_count;


 u8 pf_id;
 u16 main_vsi_seid;


 u16 partition_id;
 u16 num_partitions;
 u16 num_ports;


 u16 numa_node;


 struct i40e_adminq_info aq;


 enum i40e_nvmupd_state nvmupd_state;
 struct i40e_aq_desc nvm_wb_desc;
 struct i40e_aq_desc nvm_aq_event_desc;
 struct i40e_virt_mem nvm_buff;
 bool nvm_release_on_done;
 u16 nvm_wait_opcode;


 struct i40e_hmc_info hmc;


 u16 dcbx_status;


 struct i40e_dcbx_config local_dcbx_config;
 struct i40e_dcbx_config remote_dcbx_config;
 struct i40e_dcbx_config desired_dcbx_config;


 u16 num_wol_proxy_filters;
 u16 wol_proxy_vsi_seid;

 u64 flags;


 u16 switch_tag;
 u16 first_tag;
 u16 second_tag;


 struct i40e_nvmupd_features nvmupd_features;


 u32 debug_mask;
 char err_str[16];
};
union i40e_32byte_rx_desc {
 struct {
  u64 pkt_addr;
  u64 hdr_addr;

  u64 rsvd1;
  u64 rsvd2;
 } read;
 struct {
  struct {
   struct {
    union {
     u16 mirroring_status;
     u16 fcoe_ctx_id;
    } mirr_fcoe;
    u16 l2tag1;
   } lo_dword;
   union {
    u32 rss;
    u32 fcoe_param;



    u32 fd_id;
   } hi_dword;
  } qword0;
  struct {

   u64 status_error_len;
  } qword1;
  struct {
   u16 ext_status;
   u16 rsvd;
   u16 l2tag2_1;
   u16 l2tag2_2;
  } qword2;
  struct {
   union {
    u32 flex_bytes_lo;
    u32 pe_status;
   } lo_dword;
   union {
    u32 flex_bytes_hi;
    u32 fd_id;
   } hi_dword;
  } qword3;
 } wb;
};
enum i40e_rx_desc_status_bits {

 I40E_RX_DESC_STATUS_DD_SHIFT = 0,
 I40E_RX_DESC_STATUS_EOF_SHIFT = 1,
 I40E_RX_DESC_STATUS_L2TAG1P_SHIFT = 2,
 I40E_RX_DESC_STATUS_L3L4P_SHIFT = 3,
 I40E_RX_DESC_STATUS_CRCP_SHIFT = 4,
 I40E_RX_DESC_STATUS_TSYNINDX_SHIFT = 5,
 I40E_RX_DESC_STATUS_TSYNVALID_SHIFT = 7,
 I40E_RX_DESC_STATUS_EXT_UDP_0_SHIFT = 8,

 I40E_RX_DESC_STATUS_UMBCAST_SHIFT = 9,
 I40E_RX_DESC_STATUS_FLM_SHIFT = 11,
 I40E_RX_DESC_STATUS_FLTSTAT_SHIFT = 12,
 I40E_RX_DESC_STATUS_LPBK_SHIFT = 14,
 I40E_RX_DESC_STATUS_IPV6EXADD_SHIFT = 15,
 I40E_RX_DESC_STATUS_RESERVED2_SHIFT = 16,
 I40E_RX_DESC_STATUS_INT_UDP_0_SHIFT = 18,
 I40E_RX_DESC_STATUS_LAST
};
struct i40e_tx_desc {
 u64 buffer_addr;
 u64 cmd_type_offset_bsz;
};
struct i40e_eth_stats {
 u64 rx_bytes;
 u64 rx_unicast;
 u64 rx_multicast;
 u64 rx_broadcast;
 u64 rx_discards;
 u64 rx_unknown_protocol;
 u64 tx_bytes;
 u64 tx_unicast;
 u64 tx_multicast;
 u64 tx_broadcast;
 u64 tx_discards;
 u64 tx_errors;
};
struct i40e_hw;
struct ixl_mac_filter {
 struct { struct ixl_mac_filter *le_next; struct ixl_mac_filter **le_prev; } ftle;
 u8 macaddr[6];
 s16 vlan;
 u16 flags;
};
struct tx_ring {
        struct ixl_tx_queue *que;
 u32 tail;
 struct i40e_tx_desc *tx_base;
 u64 tx_paddr;
 u32 latency;
 u32 packets;
 u32 me;




 qidx_t *tx_rsq;
 qidx_t tx_rs_cidx;
 qidx_t tx_rs_pidx;
 qidx_t tx_cidx_processed;


 u32 itr;
 u32 bytes;


 u64 tx_bytes;
 u64 tx_packets;
 u64 mss_too_small;
};
struct rx_ring {
        struct ixl_rx_queue *que;
 union i40e_32byte_rx_desc *rx_base;
 uint64_t rx_paddr;
 bool discard;
 u32 itr;
 u32 latency;
 u32 mbuf_sz;
 u32 tail;
 u32 me;


 u32 packets;
 u32 bytes;


 u64 rx_packets;
 u64 rx_bytes;
 u64 desc_errs;
 u64 csum_errs;
};
struct ixl_tx_queue {
 struct ixl_vsi *vsi;
 struct tx_ring txr;
 struct if_irq que_irq;
 u32 msix;

 u64 irqs;
 u64 tso;
};
struct ixl_rx_queue {
 struct ixl_vsi *vsi;
 struct rx_ring rxr;
 struct if_irq que_irq;
 u32 msix;

 u64 irqs;
};
struct ixl_ftl_head { struct ixl_mac_filter *lh_first; };
struct ixl_vsi {
 if_ctx_t ctx;
 if_softc_ctx_t shared;
 if_t ifp;
 device_t dev;
 struct i40e_hw *hw;
 struct ifmedia *media;

 int num_rx_queues;
 int num_tx_queues;

 void *back;
 enum i40e_vsi_type type;
 int id;
 u32 rx_itr_setting;
 u32 tx_itr_setting;
 bool enable_head_writeback;

 u16 vsi_num;
 bool link_active;
 u16 seid;
 u16 uplink_seid;
 u16 downlink_seid;

 struct ixl_tx_queue *tx_queues;
 struct ixl_rx_queue *rx_queues;
 struct if_irq irq;
 u32 link_speed;


 struct ixl_ftl_head ftl;
 u16 num_macs;
 u64 num_hw_filters;


 struct i40e_aqc_vsi_properties_data info;

 bitstr_t ((vlans_map)[((((size_t)((0x0FFF + 1)) + ((sizeof(bitstr_t) * 8)) - 1) & ~((size_t)((sizeof(bitstr_t) * 8)) - 1)) / 8) / sizeof(bitstr_t)]);
 u16 num_vlans;


 struct i40e_eth_stats eth_stats;
 struct i40e_eth_stats eth_stats_offsets;
 bool stat_offsets_loaded;

 u64 ipackets;
 u64 ierrors;
 u64 opackets;
 u64 oerrors;
 u64 ibytes;
 u64 obytes;
 u64 imcasts;
 u64 omcasts;
 u64 iqdrops;
 u64 oqdrops;
 u64 noproto;


 u64 flags;

 struct sysctl_oid *vsi_node;
 struct sysctl_ctx_list sysctl_ctx;
};
static int ixl_isc_rxd_available(void *arg, uint16_t rxqid, qidx_t idx,
          qidx_t budget);
/*@ requires budget >= 0; ensures 0 <= \result <= budget; */

static int
ixl_isc_rxd_available(void *arg, uint16_t rxqid, qidx_t idx, qidx_t budget)
{
 struct ixl_vsi *vsi = arg;
 struct rx_ring *rxr = &vsi->rx_queues[rxqid].rxr;
 union i40e_32byte_rx_desc *rxd;
 u64 qword;
 uint32_t status;
 int cnt, i, nrxd;

 nrxd = vsi->shared->isc_nrxd[0];

 for (cnt = 0, i = idx; cnt < nrxd - 1 && cnt <= budget;) {
  rxd = &rxr->rx_base[i];
  qword = ((uint64_t)(rxd->wb.qword1.status_error_len));
  status = (qword & (((1UL << (I40E_RX_DESC_STATUS_LAST)) - 1) << 0))
   >> 0;

  if ((status & (1 << I40E_RX_DESC_STATUS_DD_SHIFT)) == 0)
   break;
  if (++i == nrxd)
   i = 0;
  if (status & (1 << I40E_RX_DESC_STATUS_EOF_SHIFT))
   cnt++;
 }

 return (cnt);
}
