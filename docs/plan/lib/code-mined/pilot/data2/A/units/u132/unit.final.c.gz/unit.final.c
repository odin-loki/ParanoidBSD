typedef unsigned short __u16;
typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u16 u16;
typedef __u64 u64;
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef _Bool bool;
typedef __kernel_size_t size_t;
typedef unsigned int gfp_t;
typedef struct {
 int counter;
} atomic_t;
enum {
 ___GFP_DMA_BIT,
 ___GFP_HIGHMEM_BIT,
 ___GFP_DMA32_BIT,
 ___GFP_MOVABLE_BIT,
 ___GFP_RECLAIMABLE_BIT,
 ___GFP_HIGH_BIT,
 ___GFP_IO_BIT,
 ___GFP_FS_BIT,
 ___GFP_ZERO_BIT,
 ___GFP_UNUSED_BIT,
 ___GFP_DIRECT_RECLAIM_BIT,
 ___GFP_KSWAPD_RECLAIM_BIT,
 ___GFP_WRITE_BIT,
 ___GFP_NOWARN_BIT,
 ___GFP_RETRY_MAYFAIL_BIT,
 ___GFP_NOFAIL_BIT,
 ___GFP_NORETRY_BIT,
 ___GFP_MEMALLOC_BIT,
 ___GFP_COMP_BIT,
 ___GFP_NOMEMALLOC_BIT,
 ___GFP_HARDWALL_BIT,
 ___GFP_THISNODE_BIT,
 ___GFP_ACCOUNT_BIT,
 ___GFP_ZEROTAGS_BIT,





 ___GFP_NOLOCKDEP_BIT,


 ___GFP_NO_OBJ_EXT_BIT,

 ___GFP_LAST_BIT
};
struct codetag {
 unsigned int flags;
 unsigned int lineno;
 const char *modname;
 const char *function;
 const char *filename;
} ;
struct alloc_tag_counters {
 u64 bytes;
 u64 calls;
};
struct alloc_tag {
 struct codetag ct;
 struct alloc_tag_counters *counters;
} ;
static inline    bool mem_alloc_profiling_enabled(void) ;
static inline      void *kzalloc_noprof(size_t size, gfp_t flags)
;
struct audit_names;
struct filename {
 const char *name;
 const char *uptr;
 atomic_t refcnt;
 struct audit_names *aname;
 const char iname[1];
};
struct fb_cmap {
 __u32 start;
 __u32 len;
 __u16 *red;
 __u16 *green;
 __u16 *blue;
 __u16 *transp;
};
extern int fb_alloc_cmap_gfp(struct fb_cmap *cmap, int len, int transp, gfp_t flags);
extern void fb_dealloc_cmap(struct fb_cmap *cmap);
extern int fb_copy_cmap(const struct fb_cmap *from, struct fb_cmap *to);
extern const struct fb_cmap *fb_default_cmap(int len);
/*@ requires len >= 0; ensures \result == 0 || \result == -12; */

int fb_alloc_cmap_gfp(struct fb_cmap *cmap, int len, int transp, gfp_t flags)
{
 int size = len * sizeof(u16);
 int ret = -12;

 flags |= (( gfp_t)((((1UL))) << (___GFP_NOWARN_BIT)));

 if (cmap->len != len) {
  fb_dealloc_cmap(cmap);
  if (!len)
   return 0;

  cmap->red = ({ ; ({ typeof(kzalloc_noprof(size, flags)) _res; if (mem_alloc_profiling_enabled()) { struct alloc_tag *  _old; _old = ((void *)0); _res = kzalloc_noprof(size, flags); do {} while (0); } else _res = kzalloc_noprof(size, flags); _res; }); });
  if (!cmap->red)
   goto fail;
  cmap->green = ({ ; ({ typeof(kzalloc_noprof(size, flags)) _res; if (mem_alloc_profiling_enabled()) { struct alloc_tag *  _old; _old = ((void *)0); _res = kzalloc_noprof(size, flags); do {} while (0); } else _res = kzalloc_noprof(size, flags); _res; }); });
  if (!cmap->green)
   goto fail;
  cmap->blue = ({ ; ({ typeof(kzalloc_noprof(size, flags)) _res; if (mem_alloc_profiling_enabled()) { struct alloc_tag *  _old; _old = ((void *)0); _res = kzalloc_noprof(size, flags); do {} while (0); } else _res = kzalloc_noprof(size, flags); _res; }); });
  if (!cmap->blue)
   goto fail;
  if (transp) {
   cmap->transp = ({ ; ({ typeof(kzalloc_noprof(size, flags)) _res; if (mem_alloc_profiling_enabled()) { struct alloc_tag *  _old; _old = ((void *)0); _res = kzalloc_noprof(size, flags); do {} while (0); } else _res = kzalloc_noprof(size, flags); _res; }); });
   if (!cmap->transp)
    goto fail;
  } else {
   cmap->transp = ((void *)0);
  }
 }
 cmap->start = 0;
 cmap->len = len;
 ret = fb_copy_cmap(fb_default_cmap(len), cmap);
 if (ret)
  goto fail;
 return 0;

fail:
 fb_dealloc_cmap(cmap);
 return ret;
}
void fb_dealloc_cmap(struct fb_cmap *cmap)
;
int fb_copy_cmap(const struct fb_cmap *from, struct fb_cmap *to)
;
const struct fb_cmap *fb_default_cmap(int len)
;
extern typeof(fb_dealloc_cmap) fb_dealloc_cmap;
extern typeof(fb_copy_cmap) fb_copy_cmap;
extern typeof(fb_default_cmap) fb_default_cmap;
