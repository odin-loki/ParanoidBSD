typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __int64_t __off_t;
typedef int __ct_rune_t;
typedef union {
 char __mbstate8[128];
 __int64_t _mbstateL;
} __mbstate_t;
typedef __size_t size_t;
int atoi(const char *);
__attribute__((__noreturn__)) void exit(int);
void free(void *);
void *realloc(void *, size_t)  ;
long strtol(const char * restrict, char ** restrict, int);
int system(const char *);
void *(memcpy)(void * restrict, const void * restrict, size_t);
void *(memset)(void *, int, size_t);
char *strchr(const char *, int) ;
char *strdup(const char *) ;
size_t strlen(const char *) ;
typedef __off_t fpos_t;
struct __sbuf {
 unsigned char *_base;
 int _size;
};
struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (* _close)(void *);
 int (* _read)(void *, char *, int);
 fpos_t (* _seek)(void *, fpos_t, int);
 int (* _write)(void *, const char *, int);


 struct __sbuf _ub;
 unsigned char *_up;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;

 struct pthread_mutex *_fl_mutex;
 struct pthread *_fl_owner;
 int _fl_count;
 int _orientation;
 __mbstate_t _mbstate;
 int _flags2;
};
typedef struct __sFILE FILE;
extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;
int fclose(FILE *);
FILE *fopen(const char * restrict, const char * restrict);
int fprintf(FILE * restrict, const char * restrict, ...);
int fputs(const char * restrict, FILE * restrict);
int pclose(FILE *);
FILE *popen(const char *, const char *);
void __assert(const char *, const char *, int, const char *) __attribute__((__noreturn__));
const char *sqlite3_libversion(void);
const char *sqlite3_sourceid(void);
typedef struct sqlite3 sqlite3;
typedef long long int sqlite_int64;
typedef unsigned long long int sqlite_uint64;
typedef sqlite_int64 sqlite3_int64;
typedef sqlite_uint64 sqlite3_uint64;
int sqlite3_exec(
  sqlite3*,
  const char *sql,
  int (*callback)(void*,int,char**,char**),
  void *,
  char **errmsg
);
typedef struct sqlite3_file sqlite3_file;
struct sqlite3_file {
  const struct sqlite3_io_methods *pMethods;
};
typedef struct sqlite3_io_methods sqlite3_io_methods;
struct sqlite3_io_methods {
  int iVersion;
  int (*xClose)(sqlite3_file*);
  int (*xRead)(sqlite3_file*, void*, int iAmt, sqlite3_int64 iOfst);
  int (*xWrite)(sqlite3_file*, const void*, int iAmt, sqlite3_int64 iOfst);
  int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
  int (*xSync)(sqlite3_file*, int flags);
  int (*xFileSize)(sqlite3_file*, sqlite3_int64 *pSize);
  int (*xLock)(sqlite3_file*, int);
  int (*xUnlock)(sqlite3_file*, int);
  int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
  int (*xFileControl)(sqlite3_file*, int op, void *pArg);
  int (*xSectorSize)(sqlite3_file*);
  int (*xDeviceCharacteristics)(sqlite3_file*);

  int (*xShmMap)(sqlite3_file*, int iPg, int pgsz, int, void volatile**);
  int (*xShmLock)(sqlite3_file*, int offset, int n, int flags);
  void (*xShmBarrier)(sqlite3_file*);
  int (*xShmUnmap)(sqlite3_file*, int deleteFlag);

  int (*xFetch)(sqlite3_file*, sqlite3_int64 iOfst, int iAmt, void **pp);
  int (*xUnfetch)(sqlite3_file*, sqlite3_int64 iOfst, void *p);


};
typedef const char *sqlite3_filename;
typedef struct sqlite3_vfs sqlite3_vfs;
typedef void (*sqlite3_syscall_ptr)(void);
struct sqlite3_vfs {
  int iVersion;
  int szOsFile;
  int mxPathname;
  sqlite3_vfs *pNext;
  const char *zName;
  void *pAppData;
  int (*xOpen)(sqlite3_vfs*, sqlite3_filename zName, sqlite3_file*,
               int flags, int *pOutFlags);
  int (*xDelete)(sqlite3_vfs*, const char *zName, int syncDir);
  int (*xAccess)(sqlite3_vfs*, const char *zName, int flags, int *pResOut);
  int (*xFullPathname)(sqlite3_vfs*, const char *zName, int nOut, char *zOut);
  void *(*xDlOpen)(sqlite3_vfs*, const char *zFilename);
  void (*xDlError)(sqlite3_vfs*, int nByte, char *zErrMsg);
  void (*(*xDlSym)(sqlite3_vfs*,void*, const char *zSymbol))(void);
  void (*xDlClose)(sqlite3_vfs*, void*);
  int (*xRandomness)(sqlite3_vfs*, int nByte, char *zOut);
  int (*xSleep)(sqlite3_vfs*, int microseconds);
  int (*xCurrentTime)(sqlite3_vfs*, double*);
  int (*xGetLastError)(sqlite3_vfs*, int, char *);




  int (*xCurrentTimeInt64)(sqlite3_vfs*, sqlite3_int64*);




  int (*xSetSystemCall)(sqlite3_vfs*, const char *zName, sqlite3_syscall_ptr);
  sqlite3_syscall_ptr (*xGetSystemCall)(sqlite3_vfs*, const char *zName);
  const char *(*xNextSystemCall)(sqlite3_vfs*, const char *zName);





};
int sqlite3_db_config(sqlite3*, int op, ...);
int sqlite3_busy_timeout(sqlite3*, int ms);
char *sqlite3_mprintf(const char*,...);
char *sqlite3_snprintf(int,char*,const char*, ...);
void *sqlite3_malloc64(sqlite3_uint64);
void *sqlite3_realloc(void*, int);
void *sqlite3_realloc64(void*, sqlite3_uint64);
void sqlite3_free(void*);
void sqlite3_randomness(int N, void *P);
int sqlite3_set_authorizer(
  sqlite3*,
  int (*xAuth)(void*,int,const char*,const char*,const char*,const char*),
  void *pUserData
);
int sqlite3_trace_v2(
  sqlite3*,
  unsigned uMask,
  int(*xCallback)(unsigned,void*,void*,void*),
  void *pCtx
);
void sqlite3_progress_handler(sqlite3*, int, int(*)(void*), void*);
int sqlite3_open(
  const char *filename,
  sqlite3 **ppDb
);
int sqlite3_open_v2(
  const char *filename,
  sqlite3 **ppDb,
  int flags,
  const char *zVfs
);
const char *sqlite3_errmsg(sqlite3*);
typedef struct sqlite3_stmt sqlite3_stmt;
int sqlite3_limit(sqlite3*, int id, int newVal);
int sqlite3_prepare_v2(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);
int sqlite3_bind_null(sqlite3_stmt*, int);
int sqlite3_bind_text(sqlite3_stmt*,int,const char*,int,void(*)(void*));
int sqlite3_step(sqlite3_stmt*);
double sqlite3_column_double(sqlite3_stmt*, int iCol);
int sqlite3_column_int(sqlite3_stmt*, int iCol);
const unsigned char *sqlite3_column_text(sqlite3_stmt*, int iCol);
int sqlite3_finalize(sqlite3_stmt *pStmt);
int sqlite3_reset(sqlite3_stmt *pStmt);
typedef void (*sqlite3_destructor_type)(void*);
int sqlite3_sleep(int);
int sqlite3_get_autocommit(sqlite3*);
int sqlite3_db_readonly(sqlite3 *db, const char *zDbName);
int sqlite3_txn_state(sqlite3*,const char *zSchema);
int sqlite3_table_column_metadata(
  sqlite3 *db,
  const char *zDbName,
  const char *zTableName,
  const char *zColumnName,
  char const **pzDataType,
  char const **pzCollSeq,
  int *pNotNull,
  int *pPrimaryKey,
  int *pAutoinc
);
int sqlite3_load_extension(
  sqlite3 *db,
  const char *zFile,
  const char *zProc,
  char **pzErrMsg
);
sqlite3_vfs *sqlite3_vfs_find(const char *zVfsName);
int sqlite3_file_control(sqlite3*, const char *zDbName, int op, void*);
int sqlite3_test_control(int op, ...);
typedef struct sqlite3_backup sqlite3_backup;
sqlite3_backup *sqlite3_backup_init(
  sqlite3 *pDest,
  const char *zDestName,
  sqlite3 *pSource,
  const char *zSourceName
);
int sqlite3_backup_step(sqlite3_backup *p, int nPage);
int sqlite3_backup_finish(sqlite3_backup *p);
int sqlite3_stricmp(const char *, const char *);
int sqlite3_strnicmp(const char *, const char *, int);
int sqlite3_strglob(const char *zGlob, const char *zStr);
int sqlite3_strlike(const char *zGlob, const char *zStr, unsigned int cEsc);
typedef sqlite3_int64 i64;
typedef sqlite3_uint64 u64;
typedef unsigned char u8;
static __inline int
__sbistype(__ct_rune_t _c, unsigned long _f)
;
struct pthread;
struct pthread_mutex;
struct pthread;
int chdir(const char *);
extern FILE *popen(const char*,const char*);
extern int pclose(FILE*);
static int enableTimer = 0;
static int cli_strcmp(const char *a, const char *b);
static int cli_strncmp(const char *a, const char *b, size_t n);
static int bail_on_error = 0;
static int stdin_is_interactive = 1;
static sqlite3 *globalDb = 0;
static volatile int seenInterrupt = 0;
static char mainPrompt[128];
static char continuePrompt[128];
static char *shell_strncpy(char *dest, const char *src, size_t n);
static void shell_out_of_memory(void);
static void shell_check_oom(const void *p);
static int strlen30(const char *z);
static FILE * openChrSource(const char *zFile);
static sqlite3_int64 integerValue(const char *zArg);
typedef struct ShellText ShellText;
struct ShellText {
  char *z;
  int n;
  int nAlloc;
};
static void initText(ShellText *p);
static void freeText(ShellText *p);
static void appendText(ShellText *p, const char *zAppend, char quote);
static char quoteChar(const char *zName);
typedef struct sqlite3expert sqlite3expert;
typedef struct IdxColumn IdxColumn;
typedef struct IdxConstraint IdxConstraint;
typedef struct IdxScan IdxScan;
typedef struct IdxStatement IdxStatement;
typedef struct IdxTable IdxTable;
typedef struct IdxWrite IdxWrite;
struct IdxConstraint {
  char *zColl;
  int bRange;
  int iCol;
  int bFlag;
  int bDesc;
  IdxConstraint *pNext;
  IdxConstraint *pLink;
};
struct IdxScan {
  IdxTable *pTab;
  int iDb;
  i64 covering;
  IdxConstraint *pOrder;
  IdxConstraint *pEq;
  IdxConstraint *pRange;
  IdxScan *pNextScan;
};
struct IdxColumn {
  char *zName;
  char *zColl;
  int iPk;
};
struct IdxTable {
  int nCol;
  char *zName;
  IdxColumn *aCol;
  IdxTable *pNext;
};
struct IdxWrite {
  IdxTable *pTab;
  int eOp;
  IdxWrite *pNext;
};
struct IdxStatement {
  int iId;
  char *zSql;
  char *zIdx;
  char *zEQP;
  IdxStatement *pNext;
};
typedef struct IdxHashEntry IdxHashEntry;
typedef struct IdxHash IdxHash;
struct IdxHashEntry {
  char *zKey;
  char *zVal;
  char *zVal2;
  IdxHashEntry *pHashNext;
  IdxHashEntry *pNext;
};
struct IdxHash {
  IdxHashEntry *pFirst;
  IdxHashEntry *aHash[1023];
};
struct sqlite3expert {
  int iSample;
  sqlite3 *db;
  sqlite3 *dbm;
  sqlite3 *dbv;
  IdxTable *pTable;
  IdxScan *pScan;
  IdxWrite *pWrite;
  IdxStatement *pStatement;
  int bRun;
  char **pzErrmsg;
  int rc;
  IdxHash hIdx;
  char *zCandidates;
};
typedef struct ExpertInfo ExpertInfo;
struct ExpertInfo {
  sqlite3expert *pExpert;
  int bVerbose;
};
typedef struct EQPGraphRow EQPGraphRow;
struct EQPGraphRow {
  int iEqpId;
  int iParentId;
  EQPGraphRow *pNext;
  char zText[1];
};
typedef struct EQPGraph EQPGraph;
struct EQPGraph {
  EQPGraphRow *pRow;
  EQPGraphRow *pLast;
  char zPrefix[100];
};
typedef struct ColModeOpts {
  int iWrap;
  u8 bQuote;
  u8 bWordWrap;
} ColModeOpts;
typedef struct ShellState ShellState;
struct ShellState {
  sqlite3 *db;
  u8 autoExplain;
  u8 autoEQP;
  u8 autoEQPtest;
  u8 autoEQPtrace;
  u8 scanstatsOn;
  u8 openMode;
  u8 doXdgOpen;
  u8 nEqpLevel;
  u8 eTraceType;
  u8 bSafeMode;
  u8 bSafeModePersist;
  u8 eRestoreState;
  u8 crlfMode;
  u8 eEscMode;
  ColModeOpts cmOpts;
  unsigned statsOn;
  unsigned mEqpLines;
  int inputNesting;
  int outCount;
  int cnt;
  int lineno;
  int openFlags;
  FILE *in;
  FILE *out;
  FILE *traceOut;
  int nErr;
  int mode;
  int modePrior;
  int cMode;
  int normalMode;
  int writableSchema;
  int showHeader;
  int nCheck;
  unsigned nProgress;
  unsigned mxProgress;
  unsigned flgProgress;
  unsigned shellFlgs;
  unsigned priorShFlgs;
  sqlite3_int64 szMax;
  char *zDestTable;
  char *zTempFile;
  char zTestcase[30];
  char colSeparator[20];
  char rowSeparator[20];
  char colSepPrior[20];
  char rowSepPrior[20];
  int *colWidth;
  int *actualWidth;
  int nWidth;
  char nullValue[20];

  char outfile[1024];
  sqlite3_stmt *pStmt;
  FILE *pLog;
  struct AuxDb {
    sqlite3 *db;
    const char *zDbFilename;
    char *zFreeOnClose;




  } aAuxDb[5],
    *pAuxDb;
  int *aiIndent;
  int nIndent;
  int iIndent;
  char *zNonce;
  EQPGraph sGraph;
  ExpertInfo expert;







};
static const char *shell_EscModeNames[] = { "ascii", "symbol", "off" };
static const char *modeDescr[] = {
  "line",
  "column",
  "list",
  "semi",
  "html",
  "insert",
  "quote",
  "tcl",
  "csv",
  "explain",
  "ascii",
  "prettyprint",
  "eqp",
  "json",
  "markdown",
  "table",
  "box",
  "count",
  "off",
  "scanexp",
  "www",
};
static void failIfSafeMode(
  ShellState *p,
  const char *zErrMsg,
  ...
);
static void outputModePush(ShellState *p);
static void output_c_string(FILE *out, const char *z);
static int safeModeAuth(
  void *pClientData,
  int op,
  const char *zA1,
  const char *zA2,
  const char *zA3,
  const char *zA4
);
static int shellAuth(
  void *pClientData,
  int op,
  const char *zA1,
  const char *zA2,
  const char *zA3,
  const char *zA4
);
static int progress_handler(void *pClientData) ;
static int callback(void *pArg, int nArg, char **azArg, char **azCol);
static int captureOutputCallback(void *pArg, int nArg, char **azArg, char **az);
static void createSelftestTable(ShellState *p);
static void set_table_name(ShellState *p, const char *zName);
static int run_table_dump_query(
  ShellState *p,
  const char *zSelect
);
static int display_stats(
  sqlite3 *db,
  ShellState *pArg,
  int bReset
);
static void bind_table_init(ShellState *p);
static void bind_prepared_stmt(ShellState *pArg, sqlite3_stmt *pStmt);
static int expertFinish(
  ShellState *pState,
  int bCancel,
  char **pzErr
);
static int expertDotCommand(
  ShellState *pState,
  char **azArg,
  int nArg
);
static int shell_exec(
  ShellState *pArg,
  const char *zSql,
  char **pzErrMsg
);
static int run_schema_dump_query(
  ShellState *p,
  const char *zQuery
);
static int showHelp(FILE *out, const char *zPattern);
static int process_input(ShellState *p);
static char *readFile(const char *zName, int *pnByte);
static void open_db(ShellState *p, int openFlags);
void close_db(sqlite3 *db);
static void resolve_backslashes(char *z);
static int booleanValue(const char *zArg);
static void setOrClearFlag(ShellState *p, unsigned mFlag, const char *zArg);
static void output_file_close(FILE *f);
static FILE *output_file_open(const char *zFile);
static int sql_trace_callback(
  unsigned mType,
  void *pArg,
  void *pP,
  void *pX
);
static void test_breakpoint(void);
typedef struct ImportCtx ImportCtx;
struct ImportCtx {
  const char *zFile;
  FILE *in;
  int ( *xCloser)(FILE*);
  char *z;
  int n;
  int nAlloc;
  int nLine;
  int nRow;
  int nErr;
  int bNotFirst;
  int cTerm;
  int cColSep;
  int cRowSep;
};
static void import_cleanup(ImportCtx *p);
static void import_append_char(ImportCtx *p, int c);
static char * csv_read_one_field(ImportCtx *p);
static char * ascii_read_one_field(ImportCtx *p);
static void tryToClone(ShellState *p, const char *zNewDb);
static void output_redir(ShellState *p, FILE *pfNew);
static void output_reset(ShellState *p);
static int db_int(sqlite3 *db, const char *zSql, ...);
static int shell_dbtotxt_command(ShellState *p, int nArg, char **azArg);
static void shellEmitError(const char *zErr);
static int shellDatabaseError(sqlite3 *db);
static int testcase_glob(const char *zGlob, const char *z);
static int optionMatch(const char *zStr, const char *zOpt);
int shellDeleteFile(const char *zFilename);
static void clearTempFile(ShellState *p);
static void newTempFile(ShellState *p, const char *zSuffix);
static int lintDotCommand(
  ShellState *pState,
  char **azArg,
  int nArg
);
static int intckDatabaseCmd(ShellState *pState, i64 nStepPerUnlock);
static char *zAutoColumn(const char *zColNew, sqlite3 **pDb, char **pzRenamed);
static int outputDumpWarning(ShellState *p, const char *zLike);
static struct {
  int iId;
  int iErr;
  int iCnt;
  int iInterval;
  int eVerbose;
  int nHit;
  int nRepeat;
  int nSkip;
} faultsim_state = {-1, 0, 0, 0, 0, 0, 0, 0};
static int faultsim_callback(int iArg);
/*@ requires zLine!=0 && p!=0; ensures \result==0 || \result==1 || \result==2; */

static int do_meta_command(char *zLine, ShellState *p){
  int h = 1;
  int nArg = 0;
  int n, c;
  int rc = 0;
  char *azArg[52];


  if( p->expert.pExpert ){
    expertFinish(p, 1, 0);
  }




  while( zLine[h] && nArg<(int)(sizeof(azArg)/sizeof(azArg[0]))-1 ){
    while( __sbistype(((unsigned char)zLine[h]), 0x00004000L) ){ h++; }
    if( zLine[h]==0 ) break;
    if( zLine[h]=='\'' || zLine[h]=='"' ){
      int delim = zLine[h++];
      azArg[nArg++] = &zLine[h];
      while( zLine[h] && zLine[h]!=delim ){
        if( zLine[h]=='\\' && delim=='"' && zLine[h+1]!=0 ) h++;
        h++;
      }
      if( zLine[h]==delim ){
        zLine[h++] = 0;
      }
      if( delim=='"' ) resolve_backslashes(azArg[nArg-1]);
    }else{
      azArg[nArg++] = &zLine[h];
      while( zLine[h] && !__sbistype(((unsigned char)zLine[h]), 0x00004000L) ){ h++; }
      if( zLine[h] ) zLine[h++] = 0;
    }
  }
  azArg[nArg] = 0;



  if( nArg==0 ) return 0;
  n = strlen30(azArg[0]);
  c = azArg[0][0];
  clearTempFile(p);


  if( c=='a' && cli_strncmp(azArg[0], "auth", n)==0 ){
    if( nArg!=2 ){
      fprintf(__stderrp, "Usage: .auth ON|OFF\n");
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    if( booleanValue(azArg[1]) ){
      sqlite3_set_authorizer(p->db, shellAuth, p);
    }else if( p->bSafeModePersist ){
      sqlite3_set_authorizer(p->db, safeModeAuth, p);
    }else{
      sqlite3_set_authorizer(p->db, 0, 0);
    }
  }else
  if( (c=='b' && n>=3 && cli_strncmp(azArg[0], "backup", n)==0)
   || (c=='s' && n>=3 && cli_strncmp(azArg[0], "save", n)==0)
  ){
    const char *zDestFile = 0;
    const char *zDb = 0;
    sqlite3 *pDest;
    sqlite3_backup *pBackup;
    int j;
    int bAsync = 0;
    const char *zVfs = 0;
    failIfSafeMode(p, "cannot run .%s in safe mode", azArg[0]);
    for(j=1; j<nArg; j++){
      const char *z = azArg[j];
      if( z[0]=='-' ){
        if( z[1]=='-' ) z++;
        if( cli_strcmp(z, "-append")==0 ){
          zVfs = "apndvfs";
        }else
        if( cli_strcmp(z, "-async")==0 ){
          bAsync = 1;
        }else
        {
          fprintf(__stderrp,"unknown option: %s\n", azArg[j]);
          return 1;
        }
      }else if( zDestFile==0 ){
        zDestFile = azArg[j];
      }else if( zDb==0 ){
        zDb = zDestFile;
        zDestFile = azArg[j];
      }else{
        fprintf(__stderrp, "Usage: .backup ?DB? ?OPTIONS? FILENAME\n");
        return 1;
      }
    }
    if( zDestFile==0 ){
      fprintf(__stderrp, "missing FILENAME argument on .backup\n");
      return 1;
    }
    if( zDb==0 ) zDb = "main";
    rc = sqlite3_open_v2(zDestFile, &pDest,
                  0x00000002|0x00000004, zVfs);
    if( rc!=0 ){
      fprintf(__stderrp,"Error: cannot open \"%s\"\n", zDestFile);
      close_db(pDest);
      return 1;
    }
    if( bAsync ){
      sqlite3_exec(pDest, "PRAGMA synchronous=OFF; PRAGMA journal_mode=OFF;",
                   0, 0, 0);
    }
    open_db(p, 0);
    pBackup = sqlite3_backup_init(pDest, "main", p->db, zDb);
    if( pBackup==0 ){
      shellDatabaseError(pDest);
      close_db(pDest);
      return 1;
    }
    while( (rc = sqlite3_backup_step(pBackup,100))==0 ){}
    sqlite3_backup_finish(pBackup);
    if( rc==101 ){
      rc = 0;
    }else{
      shellDatabaseError(pDest);
      rc = 1;
    }
    close_db(pDest);
  }else


  if( c=='b' && n>=3 && cli_strncmp(azArg[0], "bail", n)==0 ){
    if( nArg==2 ){
      bail_on_error = booleanValue(azArg[1]);
    }else{
      fputs("Usage: .bail on|off\n",__stderrp);
      rc = 1;
    }
  }else


  if( c=='b' && n>=3 && cli_strncmp(azArg[0], "binary", n)==0 ){
    fputs("The \".binary\" command is deprecated.\n",__stderrp);
    rc = 1;
  }else




  if( c=='b' && n>=3 && cli_strncmp(azArg[0], "breakpoint", n)==0 ){
    test_breakpoint();
  }else


  if( c=='c' && cli_strcmp(azArg[0],"cd")==0 ){
    failIfSafeMode(p, "cannot run .cd in safe mode");
    if( nArg==2 ){





      rc = chdir(azArg[1]);

      if( rc ){
        fprintf(__stderrp,"Cannot change to directory \"%s\"\n", azArg[1]);
        rc = 1;
      }
    }else{
      fputs("Usage: .cd DIRECTORY\n",__stderrp);
      rc = 1;
    }
  }else


  if( c=='c' && n>=3 && cli_strncmp(azArg[0], "changes", n)==0 ){
    if( nArg==2 ){
      setOrClearFlag(p, 0x00000020, azArg[1]);
    }else{
      fputs("Usage: .changes on|off\n",__stderrp);
      rc = 1;
    }
  }else






  if( c=='c' && n>=3 && cli_strncmp(azArg[0], "check", n)==0 ){
    char *zRes = 0;
    output_reset(p);
    if( nArg!=2 ){
      fputs("Usage: .check GLOB-PATTERN\n",__stderrp);
      rc = 2;
    }else if( (zRes = readFile("testcase-out.txt", 0))==0 ){
      rc = 2;
    }else if( testcase_glob(azArg[1],zRes)==0 ){
      fprintf(__stderrp,
            "testcase-%s FAILED\n Expected: [%s]\n      Got: [%s]\n",
            p->zTestcase, azArg[1], zRes);
      rc = 1;
    }else{
      fprintf(p->out, "testcase-%s ok\n", p->zTestcase);
      p->nCheck++;
    }
    sqlite3_free(zRes);
  }else



  if( c=='c' && cli_strncmp(azArg[0], "clone", n)==0 ){
    failIfSafeMode(p, "cannot run .clone in safe mode");
    if( nArg==2 ){
      tryToClone(p, azArg[1]);
    }else{
      fputs("Usage: .clone FILENAME\n",__stderrp);
      rc = 1;
    }
  }else


  if( c=='c' && cli_strncmp(azArg[0], "connection", n)==0 ){
    if( nArg==1 ){

      int i;
      for(i=0; i<(int)(sizeof(p->aAuxDb)/sizeof(p->aAuxDb[0])); i++){
        const char *zFile = p->aAuxDb[i].zDbFilename;
        if( p->aAuxDb[i].db==0 && p->pAuxDb!=&p->aAuxDb[i] ){
          zFile = "(not open)";
        }else if( zFile==0 ){
          zFile = "(memory)";
        }else if( zFile[0]==0 ){
          zFile = "(temporary-file)";
        }
        if( p->pAuxDb == &p->aAuxDb[i] ){
          fprintf(__stdoutp, "ACTIVE %d: %s\n", i, zFile);
        }else if( p->aAuxDb[i].db!=0 ){
          fprintf(__stdoutp, "       %d: %s\n", i, zFile);
        }
      }
    }else if( nArg==2 && __sbistype(((unsigned char)azArg[1][0]), 0x00000400L) && azArg[1][1]==0 ){
      int i = azArg[1][0] - '0';
      if( p->pAuxDb != &p->aAuxDb[i] && i>=0 && i<(int)(sizeof(p->aAuxDb)/sizeof(p->aAuxDb[0])) ){
        p->pAuxDb->db = p->db;
        p->pAuxDb = &p->aAuxDb[i];
        globalDb = p->db = p->pAuxDb->db;
        p->pAuxDb->db = 0;
      }
    }else if( nArg==3 && cli_strcmp(azArg[1], "close")==0
           && __sbistype(((unsigned char)azArg[2][0]), 0x00000400L) && azArg[2][1]==0 ){
      int i = azArg[2][0] - '0';
      if( i<0 || i>=(int)(sizeof(p->aAuxDb)/sizeof(p->aAuxDb[0])) ){

      }else if( p->pAuxDb == &p->aAuxDb[i] ){
        fputs("cannot close the active database connection\n",__stderrp);
        rc = 1;
      }else if( p->aAuxDb[i].db ){
        ;
        close_db(p->aAuxDb[i].db);
        p->aAuxDb[i].db = 0;
      }
    }else{
      fputs("Usage: .connection [close] [CONNECTION-NUMBER]\n",__stderrp);
      rc = 1;
    }
  }else

  if( c=='c' && n==4
   && (cli_strncmp(azArg[0], "crlf", n)==0
       || cli_strncmp(azArg[0], "crnl",n)==0)
  ){
    if( nArg==2 ){



      p->crlfMode = 0;

    }
    fprintf(__stderrp, "crlf is %s\n", p->crlfMode ? "ON" : "OFF");
  }else

  if( c=='d' && n>1 && cli_strncmp(azArg[0], "databases", n)==0 ){
    char **azName = 0;
    int nName = 0;
    sqlite3_stmt *pStmt;
    int i;
    open_db(p, 0);
    rc = sqlite3_prepare_v2(p->db, "PRAGMA database_list", -1, &pStmt, 0);
    if( rc ){
      shellDatabaseError(p->db);
      rc = 1;
    }else{
      while( sqlite3_step(pStmt)==100 ){
        const char *zSchema = (const char *)sqlite3_column_text(pStmt,1);
        const char *zFile = (const char*)sqlite3_column_text(pStmt,2);
        if( zSchema==0 || zFile==0 ) continue;
        azName = sqlite3_realloc(azName, (nName+1)*2*sizeof(char*));
        shell_check_oom(azName);
        azName[nName*2] = strdup(zSchema);
        azName[nName*2+1] = strdup(zFile);
        nName++;
      }
    }
    sqlite3_finalize(pStmt);
    for(i=0; i<nName; i++){
      int eTxn = sqlite3_txn_state(p->db, azName[i*2]);
      int bRdonly = sqlite3_db_readonly(p->db, azName[i*2]);
      const char *z = azName[i*2+1];
      fprintf(p->out, "%s: %s %s%s\n",
            azName[i*2], z && z[0] ? z : "\"\"", bRdonly ? "r/o" : "r/w",
            eTxn==0 ? "" :
            eTxn==1 ? " read-txn" : " write-txn");
      free(azName[i*2]);
      free(azName[i*2+1]);
    }
    sqlite3_free(azName);
  }else

  if( c=='d' && n>=3 && cli_strncmp(azArg[0], "dbconfig", n)==0 ){
    static const struct DbConfigChoices {
      const char *zName;
      int op;
    } aDbConfig[] = {
        { "attach_create", 1020 },
        { "attach_write", 1021 },
        { "comments", 1022 },
        { "defensive", 1010 },
        { "dqs_ddl", 1014 },
        { "dqs_dml", 1013 },
        { "enable_fkey", 1002 },
        { "enable_qpsg", 1007 },
        { "enable_trigger", 1003 },
        { "enable_view", 1015 },
        { "fts3_tokenizer", 1004 },
        { "legacy_alter_table", 1012 },
        { "legacy_file_format", 1016 },
        { "load_extension", 1005 },
        { "no_ckpt_on_close", 1006 },
        { "reset_database", 1009 },
        { "reverse_scanorder", 1019 },
        { "stmt_scanstatus", 1018 },
        { "trigger_eqp", 1008 },
        { "trusted_schema", 1017 },
        { "writable_schema", 1011 },
    };
    int ii, v;
    open_db(p, 0);
    for(ii=0; ii<(int)(sizeof(aDbConfig)/sizeof(aDbConfig[0])); ii++){
      if( nArg>1 && cli_strcmp(azArg[1], aDbConfig[ii].zName)!=0 ) continue;
      if( nArg>=3 ){
        sqlite3_db_config(p->db, aDbConfig[ii].op, booleanValue(azArg[2]), 0);
      }
      sqlite3_db_config(p->db, aDbConfig[ii].op, -1, &v);
      fprintf(p->out, "%19s %s\n",
                      aDbConfig[ii].zName, v ? "on" : "off");
      if( nArg>1 ) break;
    }
    if( nArg>1 && ii==(int)(sizeof(aDbConfig)/sizeof(aDbConfig[0])) ){
      fprintf(__stderrp,"Error: unknown dbconfig \"%s\"\n", azArg[1]);
      fputs("Enter \".dbconfig\" with no arguments for a list\n",__stderrp);
    }
  }else
  if( c=='d' && cli_strncmp(azArg[0], "dump", n)==0 ){
    char *zLike = 0;
    char *zSql;
    int i;
    int savedShowHeader = p->showHeader;
    int savedShellFlags = p->shellFlgs;
    ((p)->shellFlgs&=(~(0x00000008|0x00000010|0x00000040 |0x00000100|0x00000200)))

                                           ;
    for(i=1; i<nArg; i++){
      if( azArg[i][0]=='-' ){
        const char *z = azArg[i]+1;
        if( z[0]=='-' ) z++;
        if( cli_strcmp(z,"preserve-rowids")==0 ){







          ((p)->shellFlgs|=(0x00000008));

        }else
        if( cli_strcmp(z,"newlines")==0 ){
          ((p)->shellFlgs|=(0x00000010));
        }else
        if( cli_strcmp(z,"data-only")==0 ){
          ((p)->shellFlgs|=(0x00000100));
        }else
        if( cli_strcmp(z,"nosys")==0 ){
          ((p)->shellFlgs|=(0x00000200));
        }else
        {
          fprintf(__stderrp,
               "Unknown option \"%s\" on \".dump\"\n", azArg[i]);
          rc = 1;
          sqlite3_free(zLike);
          goto meta_command_exit;
        }
      }else{





        char *zExpr = sqlite3_mprintf(
            "name LIKE %Q ESCAPE '\\' OR EXISTS ("
            "  SELECT 1 FROM sqlite_schema WHERE "
            "    name LIKE %Q ESCAPE '\\' AND"
            "    sql LIKE 'CREATE VIRTUAL TABLE%%' AND"
            "    substr(o.name, 1, length(name)+1) == (name||'_')"
            ")", azArg[i], azArg[i]
        );

        if( zLike ){
          zLike = sqlite3_mprintf("%z OR %z", zLike, zExpr);
        }else{
          zLike = zExpr;
        }
      }
    }

    open_db(p, 0);

    outputDumpWarning(p, zLike);
    if( (p->shellFlgs & 0x00000100)==0 ){



      fputs("PRAGMA foreign_keys=OFF;\n", p->out);
      fputs("BEGIN TRANSACTION;\n", p->out);
    }
    p->writableSchema = 0;
    p->showHeader = 0;



    sqlite3_exec(p->db, "SAVEPOINT dump; PRAGMA writable_schema=ON", 0, 0, 0);
    p->nErr = 0;
    if( zLike==0 ) zLike = sqlite3_mprintf("true");
    zSql = sqlite3_mprintf(
      "SELECT name, type, sql FROM sqlite_schema AS o "
      "WHERE (%s) AND type=='table'"
      "  AND sql NOT NULL"
      " ORDER BY tbl_name='sqlite_sequence', rowid",
      zLike
    );
    run_schema_dump_query(p,zSql);
    sqlite3_free(zSql);
    if( (p->shellFlgs & 0x00000100)==0 ){
      zSql = sqlite3_mprintf(
        "SELECT sql FROM sqlite_schema AS o "
        "WHERE (%s) AND sql NOT NULL"
        "  AND type IN ('index','trigger','view') "
        "ORDER BY type COLLATE NOCASE DESC",
        zLike
      );
      run_table_dump_query(p, zSql);
      sqlite3_free(zSql);
    }
    sqlite3_free(zLike);
    if( p->writableSchema ){
      fputs("PRAGMA writable_schema=OFF;\n", p->out);
      p->writableSchema = 0;
    }
    sqlite3_exec(p->db, "PRAGMA writable_schema=OFF;", 0, 0, 0);
    sqlite3_exec(p->db, "RELEASE dump;", 0, 0, 0);
    if( (p->shellFlgs & 0x00000100)==0 ){
      fputs(p->nErr?"ROLLBACK; -- due to errors\n":"COMMIT;\n", p->out);
    }
    p->showHeader = savedShowHeader;
    p->shellFlgs = savedShellFlags;
  }else

  if( c=='e' && cli_strncmp(azArg[0], "echo", n)==0 ){
    if( nArg==2 ){
      setOrClearFlag(p, 0x00000040, azArg[1]);
    }else{
      fputs("Usage: .echo on|off\n",__stderrp);
      rc = 1;
    }
  }else

  if( c=='d' && n>=3 && cli_strncmp(azArg[0], "dbtotxt", n)==0 ){
    rc = shell_dbtotxt_command(p, nArg, azArg);
  }else

  if( c=='e' && cli_strncmp(azArg[0], "eqp", n)==0 ){
    if( nArg==2 ){
      p->autoEQPtest = 0;
      if( p->autoEQPtrace ){
        if( p->db ) sqlite3_exec(p->db, "PRAGMA vdbe_trace=OFF;", 0, 0, 0);
        p->autoEQPtrace = 0;
      }
      if( cli_strcmp(azArg[1],"full")==0 ){
        p->autoEQP = 3;
      }else if( cli_strcmp(azArg[1],"trigger")==0 ){
        p->autoEQP = 2;
      }else{
        p->autoEQP = (u8)booleanValue(azArg[1]);
      }
    }else{
      fputs("Usage: .eqp off|on|trace|trigger|full\n",__stderrp);
      rc = 1;
    }
  }else


  if( c=='e' && cli_strncmp(azArg[0], "exit", n)==0 ){
    if( nArg>1 && (rc = (int)integerValue(azArg[1]))!=0 ) exit(rc);
    rc = 2;
  }else




  if( c=='e' && cli_strncmp(azArg[0], "explain", n)==0 ){
    int val = 1;
    if( nArg>=2 ){
      if( cli_strcmp(azArg[1],"auto")==0 ){
        val = 99;
      }else{
        val = booleanValue(azArg[1]);
      }
    }
    if( val==1 && p->mode!=9 ){
      p->normalMode = p->mode;
      p->mode = 9;
      p->autoExplain = 0;
    }else if( val==0 ){
      if( p->mode==9 ) p->mode = p->normalMode;
      p->autoExplain = 0;
    }else if( val==99 ){
      if( p->mode==9 ) p->mode = p->normalMode;
      p->autoExplain = 1;
    }
  }else


  if( c=='e' && cli_strncmp(azArg[0], "expert", n)==0 ){
    if( p->bSafeMode ){
      fprintf(__stderrp,
            "Cannot run experimental commands such as \"%s\" in safe mode\n",
            azArg[0]);
      rc = 1;
    }else{
      open_db(p, 0);
      expertDotCommand(p, azArg, nArg);
    }
  }else


  if( c=='f' && cli_strncmp(azArg[0], "filectrl", n)==0 ){
    static const struct {
       const char *zCtrlName;
       int ctrlCode;
       const char *zUsage;
    } aCtrl[] = {
      { "chunk_size", 6, "SIZE" },
      { "data_version", 35, "" },
      { "has_moved", 20, "" },
      { "lock_timeout", 34, "MILLISEC" },
      { "persist_wal", 10, "[BOOLEAN]" },

      { "psow", 13, "[BOOLEAN]" },
      { "reserve_bytes", 38, "[N]" },
      { "size_limit", 36, "[LIMIT]" },
      { "tempfilename", 16, "" },

    };
    int filectrl = -1;
    int iCtrl = -1;
    sqlite3_int64 iRes = 0;
    int isOk = 0;
    int n2, i;
    const char *zCmd = 0;
    const char *zSchema = 0;

    open_db(p, 0);
    zCmd = nArg>=2 ? azArg[1] : "help";

    if( zCmd[0]=='-'
     && (cli_strcmp(zCmd,"--schema")==0 || cli_strcmp(zCmd,"-schema")==0)
     && nArg>=4
    ){
      zSchema = azArg[2];
      for(i=3; i<nArg; i++) azArg[i-2] = azArg[i];
      nArg -= 2;
      zCmd = azArg[1];
    }


    if( zCmd[0]=='-' && zCmd[1] ){
      zCmd++;
      if( zCmd[0]=='-' && zCmd[1] ) zCmd++;
    }


    if( cli_strcmp(zCmd,"help")==0 ){
      fputs("Available file-controls:\n", p->out);
      for(i=0; i<(int)(sizeof(aCtrl)/sizeof(aCtrl[0])); i++){
        fprintf(p->out,
               "  .filectrl %s %s\n", aCtrl[i].zCtrlName, aCtrl[i].zUsage);
      }
      rc = 1;
      goto meta_command_exit;
    }



    n2 = strlen30(zCmd);
    for(i=0; i<(int)(sizeof(aCtrl)/sizeof(aCtrl[0])); i++){
      if( cli_strncmp(zCmd, aCtrl[i].zCtrlName, n2)==0 ){
        if( filectrl<0 ){
          filectrl = aCtrl[i].ctrlCode;
          iCtrl = i;
        }else{
          fprintf(__stderrp,"Error: ambiguous file-control: \"%s\"\n"
                "Use \".filectrl --help\" for help\n", zCmd);
          rc = 1;
          goto meta_command_exit;
        }
      }
    }
    if( filectrl<0 ){
      fprintf(__stderrp,"Error: unknown file-control: %s\n"
            "Use \".filectrl --help\" for help\n", zCmd);
    }else{
      switch(filectrl){
        case 36: {
          if( nArg!=2 && nArg!=3 ) break;
          iRes = nArg==3 ? integerValue(azArg[2]) : -1;
          sqlite3_file_control(p->db, zSchema, 36, &iRes);
          isOk = 1;
          break;
        }
        case 34:
        case 6: {
          int x;
          if( nArg!=3 ) break;
          x = (int)integerValue(azArg[2]);
          sqlite3_file_control(p->db, zSchema, filectrl, &x);
          isOk = 2;
          break;
        }
        case 10:
        case 13: {
          int x;
          if( nArg!=2 && nArg!=3 ) break;
          x = nArg==3 ? booleanValue(azArg[2]) : -1;
          sqlite3_file_control(p->db, zSchema, filectrl, &x);
          iRes = x;
          isOk = 1;
          break;
        }
        case 35:
        case 20: {
          int x;
          if( nArg!=2 ) break;
          sqlite3_file_control(p->db, zSchema, filectrl, &x);
          iRes = x;
          isOk = 1;
          break;
        }
        case 16: {
          char *z = 0;
          if( nArg!=2 ) break;
          sqlite3_file_control(p->db, zSchema, filectrl, &z);
          if( z ){
            fprintf(p->out, "%s\n", z);
            sqlite3_free(z);
          }
          isOk = 2;
          break;
        }
        case 38: {
          int x;
          if( nArg>=3 ){
            x = atoi(azArg[2]);
            sqlite3_file_control(p->db, zSchema, filectrl, &x);
          }
          x = -1;
          sqlite3_file_control(p->db, zSchema, filectrl, &x);
          fprintf(p->out, "%d\n", x);
          isOk = 2;
          break;
        }
      }
    }
    if( isOk==0 && iCtrl>=0 ){
      fprintf(p->out, "Usage: .filectrl %s %s\n",
                      zCmd, aCtrl[iCtrl].zUsage);
      rc = 1;
    }else if( isOk==1 ){
      char zBuf[100];
      sqlite3_snprintf(sizeof(zBuf), zBuf, "%lld", iRes);
      fprintf(p->out, "%s\n", zBuf);
    }
  }else

  if( c=='f' && cli_strncmp(azArg[0], "fullschema", n)==0 ){
    ShellState data;
    int doStats = 0;
    memcpy(&data, p, sizeof(data));
    data.showHeader = 0;
    data.cMode = data.mode = 3;
    if( nArg==2 && optionMatch(azArg[1], "indent") ){
      data.cMode = data.mode = 11;
      nArg = 1;
    }
    if( nArg!=1 ){
      fputs("Usage: .fullschema ?--indent?\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    rc = sqlite3_exec(p->db,
       "SELECT sql FROM"
       "  (SELECT sql sql, type type, tbl_name tbl_name, name name, rowid x"
       "     FROM sqlite_schema UNION ALL"
       "   SELECT sql, type, tbl_name, name, rowid FROM sqlite_temp_schema) "
       "WHERE type!='meta' AND sql NOTNULL AND name NOT LIKE 'sqlite_%' "
       "ORDER BY x",
       callback, &data, 0
    );
    if( rc==0 ){
      sqlite3_stmt *pStmt;
      rc = sqlite3_prepare_v2(p->db,
               "SELECT rowid FROM sqlite_schema"
               " WHERE name GLOB 'sqlite_stat[134]'",
               -1, &pStmt, 0);
      if( rc==0 ){
        doStats = sqlite3_step(pStmt)==100;
        sqlite3_finalize(pStmt);
      }
    }
    if( doStats==0 ){
      fputs("/* No STAT tables available */\n", p->out);
    }else{
      fputs("ANALYZE sqlite_schema;\n", p->out);
      data.cMode = data.mode = 5;
      data.zDestTable = "sqlite_stat1";
      shell_exec(&data, "SELECT * FROM sqlite_stat1", 0);
      data.zDestTable = "sqlite_stat4";
      shell_exec(&data, "SELECT * FROM sqlite_stat4", 0);
      fputs("ANALYZE sqlite_schema;\n", p->out);
    }
  }else

  if( c=='h' && cli_strncmp(azArg[0], "headers", n)==0 ){
    if( nArg==2 ){
      p->showHeader = booleanValue(azArg[1]);
      p->shellFlgs |= 0x00000080;
    }else{
      fputs("Usage: .headers on|off\n",__stderrp);
      rc = 1;
    }
  }else

  if( c=='h' && cli_strncmp(azArg[0], "help", n)==0 ){
    if( nArg>=2 ){
      n = showHelp(p->out, azArg[1]);
      if( n==0 ){
        fprintf(p->out, "Nothing matches '%s'\n", azArg[1]);
      }
    }else{
      showHelp(p->out, 0);
    }
  }else


  if( c=='i' && cli_strncmp(azArg[0], "import", n)==0 ){
    char *zTable = 0;
    char *zSchema = 0;
    char *zFile = 0;
    sqlite3_stmt *pStmt = ((void *)0);
    int nCol;
    i64 nByte;
    int i, j;
    int needCommit;
    int nSep;
    char *zSql = 0;
    ImportCtx sCtx;
    char *( *xRead)(ImportCtx*);
    int eVerbose = 0;
    int nSkip = 0;
    int useOutputMode = 1;
    char *zCreate = 0;

    failIfSafeMode(p, "cannot run .import in safe mode");
    memset(&sCtx, 0, sizeof(sCtx));
    if( p->mode==10 ){
      xRead = ascii_read_one_field;
    }else{
      xRead = csv_read_one_field;
    }
    rc = 1;
    for(i=1; i<nArg; i++){
      char *z = azArg[i];
      if( z[0]=='-' && z[1]=='-' ) z++;
      if( z[0]!='-' ){
        if( zFile==0 ){
          zFile = z;
        }else if( zTable==0 ){
          zTable = z;
        }else{
          fprintf(p->out, "ERROR: extra argument: \"%s\". Usage:\n",z);
          showHelp(p->out, "import");
          goto meta_command_exit;
        }
      }else if( cli_strcmp(z,"-v")==0 ){
        eVerbose++;
      }else if( cli_strcmp(z,"-schema")==0 && i<nArg-1 ){
        zSchema = azArg[++i];
      }else if( cli_strcmp(z,"-skip")==0 && i<nArg-1 ){
        nSkip = integerValue(azArg[++i]);
      }else if( cli_strcmp(z,"-ascii")==0 ){
        sCtx.cColSep = "\x1F"[0];
        sCtx.cRowSep = "\x1E"[0];
        xRead = ascii_read_one_field;
        useOutputMode = 0;
      }else if( cli_strcmp(z,"-csv")==0 ){
        sCtx.cColSep = ',';
        sCtx.cRowSep = '\n';
        xRead = csv_read_one_field;
        useOutputMode = 0;
      }else{
        fprintf(p->out, "ERROR: unknown option: \"%s\".  Usage:\n", z);
        showHelp(p->out, "import");
        goto meta_command_exit;
      }
    }
    if( zTable==0 ){
      fprintf(p->out, "ERROR: missing %s argument. Usage:\n",
            zFile==0 ? "FILE" : "TABLE");
      showHelp(p->out, "import");
      goto meta_command_exit;
    }
    seenInterrupt = 0;
    open_db(p, 0);
    if( useOutputMode ){


      nSep = strlen30(p->colSeparator);
      if( nSep==0 ){
        fputs("Error: non-null column separator required for import\n",__stderrp);
        goto meta_command_exit;
      }
      if( nSep>1 ){
        fputs("Error: multi-character column separators not allowed" " for import\n",__stderrp)
                              ;
        goto meta_command_exit;
      }
      nSep = strlen30(p->rowSeparator);
      if( nSep==0 ){
        fputs("Error: non-null row separator required for import\n",__stderrp);
        goto meta_command_exit;
      }
      if( nSep==2 && p->mode==8
       && cli_strcmp(p->rowSeparator,"\r\n")==0
      ){




        sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
        nSep = strlen30(p->rowSeparator);
      }
      if( nSep>1 ){
        fputs("Error: multi-character row separators not allowed" " for import\n",__stderrp)
                              ;
        goto meta_command_exit;
      }
      sCtx.cColSep = (u8)p->colSeparator[0];
      sCtx.cRowSep = (u8)p->rowSeparator[0];
    }
    sCtx.zFile = zFile;
    sCtx.nLine = 1;
    if( sCtx.zFile[0]=='|' ){




      sCtx.in = popen(sCtx.zFile+1, "r");
      sCtx.zFile = "<pipe>";
      sCtx.xCloser = pclose;

    }else{
      sCtx.in = fopen(sCtx.zFile, "rb");
      sCtx.xCloser = fclose;
    }
    if( sCtx.in==0 ){
      fprintf(__stderrp,"Error: cannot open \"%s\"\n", zFile);
      goto meta_command_exit;
    }
    if( eVerbose>=2 || (eVerbose>=1 && useOutputMode) ){
      char zSep[2];
      zSep[1] = 0;
      zSep[0] = sCtx.cColSep;
      fputs("Column separator ", p->out);
      output_c_string(p->out, zSep);
      fputs(", row separator ", p->out);
      zSep[0] = sCtx.cRowSep;
      output_c_string(p->out, zSep);
      fputs("\n", p->out);
    }
    sCtx.z = sqlite3_malloc64(120);
    if( sCtx.z==0 ){
      import_cleanup(&sCtx);
      shell_out_of_memory();
    }

    while( (nSkip--)>0 ){
      while( xRead(&sCtx) && sCtx.cTerm==sCtx.cColSep ){}
    }
    import_append_char(&sCtx, 0);
    if( sqlite3_table_column_metadata(p->db, zSchema, zTable,0,0,0,0,0,0)
     && 0==db_int(p->db, "SELECT count(*) FROM \"%w\".sqlite_schema"
                         " WHERE name=%Q AND type='view'",
                         zSchema ? zSchema : "main", zTable)
    ){

      sqlite3 *dbCols = 0;
      char *zRenames = 0;
      char *zColDefs;
      zCreate = sqlite3_mprintf("CREATE TABLE \"%w\".\"%w\"",
                    zSchema ? zSchema : "main", zTable);
      while( xRead(&sCtx) ){
        zAutoColumn(sCtx.z, &dbCols, 0);
        if( sCtx.cTerm!=sCtx.cColSep ) break;
      }
      zColDefs = zAutoColumn(0, &dbCols, &zRenames);
      if( zRenames!=0 ){
        fprintf((stdin_is_interactive && p->in==__stdinp)? p->out : __stderrp,
              "Columns renamed during .import %s due to duplicates:\n"
              "%s\n", sCtx.zFile, zRenames);
        sqlite3_free(zRenames);
      }
      ((void)sizeof(((_Bool(*)(_Bool))0)(dbCols==0)), (dbCols==0) ? (void)0 : __assert(__func__, "/mnt/c/ParanoidBSD/dreamy-mahavira-7e0e79/hbsd/src/contrib/sqlite3/shell.c", 29780, "dbCols==0"));
      if( zColDefs==0 ){
        fprintf(__stderrp,"%s: empty file\n", sCtx.zFile);
        import_cleanup(&sCtx);
        rc = 1;
        sqlite3_free(zCreate);
        goto meta_command_exit;
      }
      zCreate = sqlite3_mprintf("%z%z\n", zCreate, zColDefs);
      if( zCreate==0 ){
        import_cleanup(&sCtx);
        shell_out_of_memory();
      }
      if( eVerbose>=1 ){
        fprintf(p->out, "%s\n", zCreate);
      }
      rc = sqlite3_exec(p->db, zCreate, 0, 0, 0);
      if( rc ){
        fprintf(__stderrp,
             "%s failed:\n%s\n", zCreate, sqlite3_errmsg(p->db));
      }
      sqlite3_free(zCreate);
      zCreate = 0;
      if( rc ){
        import_cleanup(&sCtx);
        rc = 1;
        goto meta_command_exit;
      }
    }
    zSql = sqlite3_mprintf("SELECT count(*) FROM pragma_table_info(%Q,%Q);",
                           zTable, zSchema);
    if( zSql==0 ){
      import_cleanup(&sCtx);
      shell_out_of_memory();
    }
    rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
    sqlite3_free(zSql);
    zSql = 0;
    if( rc ){
      if (pStmt) sqlite3_finalize(pStmt);
      shellDatabaseError(p->db);
      import_cleanup(&sCtx);
      rc = 1;
      goto meta_command_exit;
    }
    if( sqlite3_step(pStmt)==100 ){
      nCol = sqlite3_column_int(pStmt, 0);
    }else{
      nCol = 0;
    }
    sqlite3_finalize(pStmt);
    pStmt = 0;
    if( nCol==0 ) return 0;

    nByte = 64
          + (zSchema ? strlen(zSchema)*2 + 2: 0)
          + strlen(zTable)*2 + 2
          + nCol*2;
    zSql = sqlite3_malloc64( nByte );
    if( zSql==0 ){
      import_cleanup(&sCtx);
      shell_out_of_memory();
    }
    if( zSchema ){
      sqlite3_snprintf(nByte, zSql, "INSERT INTO \"%w\".\"%w\" VALUES(?",
                       zSchema, zTable);
    }else{
      sqlite3_snprintf(nByte, zSql, "INSERT INTO \"%w\" VALUES(?", zTable);
    }
    j = strlen30(zSql);
    for(i=1; i<nCol; i++){
      zSql[j++] = ',';
      zSql[j++] = '?';
    }
    zSql[j++] = ')';
    zSql[j] = 0;
    ((void)sizeof(((_Bool(*)(_Bool))0)(j<nByte)), (j<nByte) ? (void)0 : __assert(__func__, "/mnt/c/ParanoidBSD/dreamy-mahavira-7e0e79/hbsd/src/contrib/sqlite3/shell.c", 29856, "j<nByte"));
    if( eVerbose>=2 ){
      fprintf(p->out, "Insert using: %s\n", zSql);
    }
    rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
    sqlite3_free(zSql);
    zSql = 0;
    if( rc ){
      shellDatabaseError(p->db);
      if (pStmt) sqlite3_finalize(pStmt);
      import_cleanup(&sCtx);
      rc = 1;
      goto meta_command_exit;
    }
    needCommit = sqlite3_get_autocommit(p->db);
    if( needCommit ) sqlite3_exec(p->db, "BEGIN", 0, 0, 0);
    do{
      int startLine = sCtx.nLine;
      for(i=0; i<nCol; i++){
        char *z = xRead(&sCtx);




        if( z==0 && i==0 ) break;





        if( p->mode==10 && (z==0 || z[0]==0) && i==0 ) break;





        if( z==0 && (xRead==csv_read_one_field) && i==nCol-1 && i>0 ){
          z = "";
        }
        sqlite3_bind_text(pStmt, i+1, z, -1, ((sqlite3_destructor_type)-1));
        if( i<nCol-1 && sCtx.cTerm!=sCtx.cColSep ){
          fprintf(__stderrp,"%s:%d: expected %d columns but found %d"
                " - filling the rest with NULL\n",
                sCtx.zFile, startLine, nCol, i+1);
          i += 2;
          while( i<=nCol ){ sqlite3_bind_null(pStmt, i); i++; }
        }
      }
      if( sCtx.cTerm==sCtx.cColSep ){
        do{
          xRead(&sCtx);
          i++;
        }while( sCtx.cTerm==sCtx.cColSep );
        fprintf(__stderrp,
              "%s:%d: expected %d columns but found %d - extras ignored\n",
              sCtx.zFile, startLine, nCol, i);
      }
      if( i>=nCol ){
        sqlite3_step(pStmt);
        rc = sqlite3_reset(pStmt);
        if( rc!=0 ){
          fprintf(__stderrp,"%s:%d: INSERT failed: %s\n",
                sCtx.zFile, startLine, sqlite3_errmsg(p->db));
          sCtx.nErr++;
        }else{
          sCtx.nRow++;
        }
      }
    }while( sCtx.cTerm!=(-1) );

    import_cleanup(&sCtx);
    sqlite3_finalize(pStmt);
    if( needCommit ) sqlite3_exec(p->db, "COMMIT", 0, 0, 0);
    if( eVerbose>0 ){
      fprintf(p->out,
            "Added %d rows with %d errors using %d lines of input\n",
            sCtx.nRow, sCtx.nErr, sCtx.nLine-1);
    }
  }else



  if( c=='i' && cli_strncmp(azArg[0], "imposter", n)==0 ){
    char *zSql;
    char *zCollist = 0;
    sqlite3_stmt *pStmt;
    int tnum = 0;
    int isWO = 0;
    int lenPK = 0;
    int i;
    if( !(((p)->shellFlgs & (0x00000400))!=0) ){
      fprintf(__stderrp,".%s unavailable without --unsafe-testing\n",
            "imposter");
      rc = 1;
      goto meta_command_exit;
    }
    if( !(nArg==3 || (nArg==2 && sqlite3_stricmp(azArg[1],"off")==0)) ){
      fputs("Usage: .imposter INDEX IMPOSTER\n" "       .imposter off\n",__stderrp)
                                     ;







      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    if( nArg==2 ){
      sqlite3_test_control(25, p->db, "main", 0, 1);
      goto meta_command_exit;
    }
    zSql = sqlite3_mprintf(
      "SELECT rootpage, 0 FROM sqlite_schema"
      " WHERE name='%q' AND type='index'"
      "UNION ALL "
      "SELECT rootpage, 1 FROM sqlite_schema"
      " WHERE name='%q' AND type='table'"
      "   AND sql LIKE '%%without%%rowid%%'",
      azArg[1], azArg[1]
    );
    sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
    sqlite3_free(zSql);
    if( sqlite3_step(pStmt)==100 ){
      tnum = sqlite3_column_int(pStmt, 0);
      isWO = sqlite3_column_int(pStmt, 1);
    }
    sqlite3_finalize(pStmt);
    zSql = sqlite3_mprintf("PRAGMA index_xinfo='%q'", azArg[1]);
    rc = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
    sqlite3_free(zSql);
    i = 0;
    while( rc==0 && sqlite3_step(pStmt)==100 ){
      char zLabel[20];
      const char *zCol = (const char*)sqlite3_column_text(pStmt,2);
      i++;
      if( zCol==0 ){
        if( sqlite3_column_int(pStmt,1)==-1 ){
          zCol = "_ROWID_";
        }else{
          sqlite3_snprintf(sizeof(zLabel),zLabel,"expr%d",i);
          zCol = zLabel;
        }
      }
      if( isWO && lenPK==0 && sqlite3_column_int(pStmt,5)==0 && zCollist ){
        lenPK = (int)strlen(zCollist);
      }
      if( zCollist==0 ){
        zCollist = sqlite3_mprintf("\"%w\"", zCol);
      }else{
        zCollist = sqlite3_mprintf("%z,\"%w\"", zCollist, zCol);
      }
    }
    sqlite3_finalize(pStmt);
    if( i==0 || tnum==0 ){
      fprintf(__stderrp,"no such index: \"%s\"\n", azArg[1]);
      rc = 1;
      sqlite3_free(zCollist);
      goto meta_command_exit;
    }
    if( lenPK==0 ) lenPK = 100000;
    zSql = sqlite3_mprintf(
          "CREATE TABLE \"%w\"(%s,PRIMARY KEY(%.*s))WITHOUT ROWID",
          azArg[2], zCollist, lenPK, zCollist);
    sqlite3_free(zCollist);
    rc = sqlite3_test_control(25, p->db, "main", 1, tnum);
    if( rc==0 ){
      rc = sqlite3_exec(p->db, zSql, 0, 0, 0);
      sqlite3_test_control(25, p->db, "main", 0, 0);
      if( rc ){
        fprintf(__stderrp,
              "Error in [%s]: %s\n", zSql, sqlite3_errmsg(p->db));
      }else{
        fprintf(__stdoutp, "%s;\n", zSql);
        fprintf(__stdoutp,
              "WARNING: writing to an imposter table will corrupt"
              " the \"%s\" %s!\n", azArg[1], isWO ? "table" : "index");
      }
    }else{
      fprintf(__stderrp,"SQLITE_TESTCTRL_IMPOSTER returns %d\n", rc);
      rc = 1;
    }
    sqlite3_free(zSql);
  }else


  if( c=='i' && cli_strncmp(azArg[0], "intck", n)==0 ){
    i64 iArg = 0;
    if( nArg==2 ){
      iArg = integerValue(azArg[1]);
      if( iArg==0 ) iArg = -1;
    }
    if( (nArg!=1 && nArg!=2) || iArg<0 ){
      fprintf(__stderrp,"%s","Usage: .intck STEPS_PER_UNLOCK\n");
      rc = 1;
      goto meta_command_exit;
    }
    open_db(p, 0);
    rc = intckDatabaseCmd(p, iArg);
  }else
  if( c=='l' && n>=5 && cli_strncmp(azArg[0], "limits", n)==0 ){
    static const struct {
       const char *zLimitName;
       int limitCode;
    } aLimit[] = {
      { "length", 0 },
      { "sql_length", 1 },
      { "column", 2 },
      { "expr_depth", 3 },
      { "compound_select", 4 },
      { "vdbe_op", 5 },
      { "function_arg", 6 },
      { "attached", 7 },
      { "like_pattern_length", 8 },
      { "variable_number", 9 },
      { "trigger_depth", 10 },
      { "worker_threads", 11 },
    };
    int i, n2;
    open_db(p, 0);
    if( nArg==1 ){
      for(i=0; i<(int)(sizeof(aLimit)/sizeof(aLimit[0])); i++){
        fprintf(__stdoutp, "%20s %d\n", aLimit[i].zLimitName,
              sqlite3_limit(p->db, aLimit[i].limitCode, -1));
      }
    }else if( nArg>3 ){
      fputs("Usage: .limit NAME ?NEW-VALUE?\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }else{
      int iLimit = -1;
      n2 = strlen30(azArg[1]);
      for(i=0; i<(int)(sizeof(aLimit)/sizeof(aLimit[0])); i++){
        if( sqlite3_strnicmp(aLimit[i].zLimitName, azArg[1], n2)==0 ){
          if( iLimit<0 ){
            iLimit = i;
          }else{
            fprintf(__stderrp,"ambiguous limit: \"%s\"\n", azArg[1]);
            rc = 1;
            goto meta_command_exit;
          }
        }
      }
      if( iLimit<0 ){
        fprintf(__stderrp,"unknown limit: \"%s\"\n"
              "enter \".limits\" with no arguments for a list.\n",
              azArg[1]);
        rc = 1;
        goto meta_command_exit;
      }
      if( nArg==3 ){
        sqlite3_limit(p->db, aLimit[iLimit].limitCode,
                      (int)integerValue(azArg[2]));
      }
      fprintf(__stdoutp, "%20s %d\n", aLimit[iLimit].zLimitName,
            sqlite3_limit(p->db, aLimit[iLimit].limitCode, -1));
    }
  }else

  if( c=='l' && n>2 && cli_strncmp(azArg[0], "lint", n)==0 ){
    open_db(p, 0);
    lintDotCommand(p, azArg, nArg);
  }else


  if( c=='l' && cli_strncmp(azArg[0], "load", n)==0 ){
    const char *zFile, *zProc;
    char *zErrMsg = 0;
    failIfSafeMode(p, "cannot run .load in safe mode");
    if( nArg<2 || azArg[1][0]==0 ){

      fputs("Usage: .load FILE ?ENTRYPOINT?\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    zFile = azArg[1];
    zProc = nArg>=3 ? azArg[2] : 0;
    open_db(p, 0);
    rc = sqlite3_load_extension(p->db, zFile, zProc, &zErrMsg);
    if( rc!=0 ){
      shellEmitError(zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    }
  }else


  if( c=='l' && cli_strncmp(azArg[0], "log", n)==0 ){
    if( nArg!=2 ){
      fputs("Usage: .log FILENAME\n",__stderrp);
      rc = 1;
    }else{
      const char *zFile = azArg[1];
      if( p->bSafeMode
       && cli_strcmp(zFile,"on")!=0
       && cli_strcmp(zFile,"off")!=0
      ){
        fputs("cannot set .log to anything other" " than \"on\" or \"off\"\n",__stdoutp)
                                          ;
        zFile = "off";
      }
      output_file_close(p->pLog);
      if( cli_strcmp(zFile,"on")==0 ) zFile = "stdout";
      p->pLog = output_file_open(zFile);
    }
  }else

  if( c=='m' && cli_strncmp(azArg[0], "mode", n)==0 ){
    const char *zMode = 0;
    const char *zTabname = 0;
    int i, n2;
    int chng = 0;
    ColModeOpts cmOpts = { 60, 0, 0 };
    for(i=1; i<nArg; i++){
      const char *z = azArg[i];
      if( optionMatch(z,"wrap") && i+1<nArg ){
        cmOpts.iWrap = integerValue(azArg[++i]);
        chng |= 1;
      }else if( optionMatch(z,"ww") ){
        cmOpts.bWordWrap = 1;
        chng |= 1;
      }else if( optionMatch(z,"wordwrap") && i+1<nArg ){
        cmOpts.bWordWrap = (u8)booleanValue(azArg[++i]);
        chng |= 1;
      }else if( optionMatch(z,"quote") ){
        cmOpts.bQuote = 1;
        chng |= 1;
      }else if( optionMatch(z,"noquote") ){
        cmOpts.bQuote = 0;
        chng |= 1;
      }else if( optionMatch(z,"escape") && i+1<nArg ){

        const char *zEsc = azArg[++i];
        int k;
        for(k=0; k<(int)(sizeof(shell_EscModeNames)/sizeof(shell_EscModeNames[0])); k++){
          if( sqlite3_stricmp(zEsc,shell_EscModeNames[k])==0 ){
            p->eEscMode = k;
            chng |= 2;
            break;
          }
        }
        if( k>=(int)(sizeof(shell_EscModeNames)/sizeof(shell_EscModeNames[0])) ){
          fprintf(__stderrp, "unknown control character escape mode \"%s\""
                                  " - choices:", zEsc);
          for(k=0; k<(int)(sizeof(shell_EscModeNames)/sizeof(shell_EscModeNames[0])); k++){
            fprintf(__stderrp, " %s", shell_EscModeNames[k]);
          }
          fprintf(__stderrp, "\n");
          rc = 1;
          goto meta_command_exit;
        }
      }else if( zMode==0 ){
        zMode = z;



        chng |= 1;
        if( cli_strcmp(z, "qbox")==0 ){
          ColModeOpts cmo = { 60, 1, 0 };
          zMode = "box";
          cmOpts = cmo;
        }
      }else if( zTabname==0 ){
        zTabname = z;
      }else if( z[0]=='-' ){
        fprintf(__stderrp,"unknown option: %s\n", z);
        fputs("options:\n" "  --escape MODE\n" "  --noquote\n" "  --quote\n" "  --wordwrap on/off\n" "  --wrap N\n" "  --ww\n",__stderrp)





                         ;
        rc = 1;
        goto meta_command_exit;
      }else{
        fprintf(__stderrp,"extra argument: \"%s\"\n", z);
        rc = 1;
        goto meta_command_exit;
      }
    }
    if( !chng ){
      if( p->mode==1
       || (p->mode>=14 && p->mode<=16)
      ){
        fprintf(p->out,
              "current output mode: %s --wrap %d --wordwrap %s "
              "--%squote --escape %s\n",
              modeDescr[p->mode], p->cmOpts.iWrap,
              p->cmOpts.bWordWrap ? "on" : "off",
              p->cmOpts.bQuote ? "" : "no",
              shell_EscModeNames[p->eEscMode]
        );
      }else{
        fprintf(p->out,
              "current output mode: %s --escape %s\n",
              modeDescr[p->mode],
              shell_EscModeNames[p->eEscMode]
        );
      }
    }
    if( zMode==0 ){
      zMode = modeDescr[p->mode];
      if( (chng&1)==0 ) cmOpts = p->cmOpts;
    }
    n2 = strlen30(zMode);
    if( cli_strncmp(zMode,"lines",n2)==0 ){
      p->mode = 0;
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
    }else if( cli_strncmp(zMode,"columns",n2)==0 ){
      p->mode = 1;
      if( (p->shellFlgs & 0x00000080)==0 ){
        p->showHeader = 1;
      }
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
      p->cmOpts = cmOpts;
    }else if( cli_strncmp(zMode,"list",n2)==0 ){
      p->mode = 2;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, "|");
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
    }else if( cli_strncmp(zMode,"html",n2)==0 ){
      p->mode = 4;
    }else if( cli_strncmp(zMode,"tcl",n2)==0 ){
      p->mode = 7;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, " ");
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
    }else if( cli_strncmp(zMode,"csv",n2)==0 ){
      p->mode = 8;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, ",");
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\r\n");
    }else if( cli_strncmp(zMode,"tabs",n2)==0 ){
      p->mode = 2;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, "\t");
    }else if( cli_strncmp(zMode,"insert",n2)==0 ){
      p->mode = 5;
      set_table_name(p, zTabname ? zTabname : "table");
      if( p->eEscMode==2 ){
        ((p)->shellFlgs|=(0x00000010));
      }else{
        ((p)->shellFlgs&=(~(0x00000010)));
      }
    }else if( cli_strncmp(zMode,"quote",n2)==0 ){
      p->mode = 6;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, ",");
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\n");
    }else if( cli_strncmp(zMode,"ascii",n2)==0 ){
      p->mode = 10;
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, "\x1F");
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\x1E");
    }else if( cli_strncmp(zMode,"markdown",n2)==0 ){
      p->mode = 14;
      p->cmOpts = cmOpts;
    }else if( cli_strncmp(zMode,"table",n2)==0 ){
      p->mode = 15;
      p->cmOpts = cmOpts;
    }else if( cli_strncmp(zMode,"box",n2)==0 ){
      p->mode = 16;
      p->cmOpts = cmOpts;
    }else if( cli_strncmp(zMode,"count",n2)==0 ){
      p->mode = 17;
    }else if( cli_strncmp(zMode,"off",n2)==0 ){
      p->mode = 18;
    }else if( cli_strncmp(zMode,"json",n2)==0 ){
      p->mode = 13;
    }else{
      fputs("Error: mode should be one of: " "ascii box column csv html insert json line list markdown " "qbox quote table tabs tcl\n",__stderrp)

                                          ;
      rc = 1;
    }
    p->cMode = p->mode;
  }else


  if( c=='n' && cli_strcmp(azArg[0], "nonce")==0 ){
    if( nArg!=2 ){
      fputs("Usage: .nonce NONCE\n",__stderrp);
      rc = 1;
    }else if( p->zNonce==0 || cli_strcmp(azArg[1],p->zNonce)!=0 ){
      fprintf(__stderrp,"line %d: incorrect nonce: \"%s\"\n",
            p->lineno, azArg[1]);
      exit(1);
    }else{
      p->bSafeMode = 0;
      return 0;

    }
  }else


  if( c=='n' && cli_strncmp(azArg[0], "nullvalue", n)==0 ){
    if( nArg==2 ){
      sqlite3_snprintf(sizeof(p->nullValue), p->nullValue,
                       "%.*s", (int)(int)(sizeof(p->nullValue)/sizeof(p->nullValue[0]))-1, azArg[1]);
    }else{
      fputs("Usage: .nullvalue STRING\n",__stderrp);
      rc = 1;
    }
  }else

  if( c=='o' && cli_strncmp(azArg[0], "open", n)==0 && n>=2 ){
    const char *zFN = 0;
    char *zNewFilename = 0;
    int iName = 1;
    int newFlag = 0;
    int openMode = 0;


    for(iName=1; iName<nArg; iName++){
      const char *z = azArg[iName];

      if( optionMatch(z,"new") ){
        newFlag = 1;




      }else if( optionMatch(z, "append") ){
        openMode = 2;
      }else if( optionMatch(z, "readonly") ){
        openMode = 4;
      }else if( optionMatch(z, "nofollow") ){
        p->openFlags |= 0x01000000;

      }else if( optionMatch(z, "deserialize") ){
        openMode = 5;
      }else if( optionMatch(z, "hexdb") ){
        openMode = 6;
      }else if( optionMatch(z, "maxsize") && iName+1<nArg ){
        p->szMax = integerValue(azArg[++iName]);

      }else

      if( z[0]=='-' ){
        fprintf(__stderrp,"unknown option: %s\n", z);
        rc = 1;
        goto meta_command_exit;
      }else if( zFN ){
        fprintf(__stderrp,"extra argument: \"%s\"\n", z);
        rc = 1;
        goto meta_command_exit;
      }else{
        zFN = z;
      }
    }


    ;
    close_db(p->db);
    p->db = 0;
    p->pAuxDb->zDbFilename = 0;
    sqlite3_free(p->pAuxDb->zFreeOnClose);
    p->pAuxDb->zFreeOnClose = 0;
    p->openMode = openMode;
    p->openFlags = 0;
    p->szMax = 0;


    if( zFN || p->openMode==6 ){
      if( newFlag && zFN && !p->bSafeMode ) shellDeleteFile(zFN);

      if( p->bSafeMode
       && p->openMode!=6
       && zFN
       && cli_strcmp(zFN,":memory:")!=0
      ){
        failIfSafeMode(p, "cannot open disk-based database files in safe mode");
      }



      if( zFN ){
        zNewFilename = sqlite3_mprintf("%s", zFN);
        shell_check_oom(zNewFilename);
      }else{
        zNewFilename = 0;
      }
      p->pAuxDb->zDbFilename = zNewFilename;
      open_db(p, 0x001);
      if( p->db==0 ){
        fprintf(__stderrp,"Error: cannot open '%s'\n", zNewFilename);
        sqlite3_free(zNewFilename);
      }else{
        p->pAuxDb->zFreeOnClose = zNewFilename;
      }
    }
    if( p->db==0 ){

      p->pAuxDb->zDbFilename = 0;
      open_db(p, 0);
    }
  }else


  if( (c=='o'
        && (cli_strncmp(azArg[0], "output", n)==0
            || cli_strncmp(azArg[0], "once", n)==0))
   || (c=='e' && n==5 && cli_strcmp(azArg[0],"excel")==0)
   || (c=='w' && n==3 && cli_strcmp(azArg[0],"www")==0)
  ){
    char *zFile = 0;
    int i;
    int eMode = 0;
    int bOnce = 0;
    int bPlain = 0;
    static const char *zBomUtf8 = "\357\273\277";
    const char *zBom = 0;

    failIfSafeMode(p, "cannot run .%s in safe mode", azArg[0]);
    if( c=='e' ){
      eMode = 'x';
      bOnce = 2;
    }else if( c=='w' ){
      eMode = 'w';
      bOnce = 2;
    }else if( cli_strncmp(azArg[0],"once",n)==0 ){
      bOnce = 1;
    }
    for(i=1; i<nArg; i++){
      char *z = azArg[i];
      if( z[0]=='-' ){
        if( z[1]=='-' ) z++;
        if( cli_strcmp(z,"-bom")==0 ){
          zBom = zBomUtf8;
        }else if( cli_strcmp(z,"-plain")==0 ){
          bPlain = 1;
        }else if( c=='o' && cli_strcmp(z,"-x")==0 ){
          eMode = 'x';
        }else if( c=='o' && cli_strcmp(z,"-e")==0 ){
          eMode = 'e';
        }else if( c=='o' && cli_strcmp(z,"-w")==0 ){
          eMode = 'w';
        }else{
          fprintf(p->out,
                          "ERROR: unknown option: \"%s\". Usage:\n", azArg[i]);
          showHelp(p->out, azArg[0]);
          rc = 1;
          goto meta_command_exit;
        }
      }else if( zFile==0 && eMode==0 ){
        if( cli_strcmp(z, "off")==0 ){



          zFile = sqlite3_mprintf("/dev/null");

        }else{
          zFile = sqlite3_mprintf("%s", z);
        }
        if( zFile && zFile[0]=='|' ){
          while( i+1<nArg ) zFile = sqlite3_mprintf("%z %s", zFile, azArg[++i]);
          break;
        }
      }else{
        fprintf(p->out,
            "ERROR: extra parameter: \"%s\".  Usage:\n", azArg[i]);
        showHelp(p->out, azArg[0]);
        rc = 1;
        sqlite3_free(zFile);
        goto meta_command_exit;
      }
    }
    if( zFile==0 ){
      zFile = sqlite3_mprintf("stdout");
    }
    shell_check_oom(zFile);
    if( bOnce ){
      p->outCount = 2;
    }else{
      p->outCount = 0;
    }
    output_reset(p);

    if( eMode=='e' || eMode=='x' || eMode=='w' ){
      p->doXdgOpen = 1;
      outputModePush(p);
      if( eMode=='x' ){

        newTempFile(p, "csv");
        ((p)->shellFlgs&=(~(0x00000040)));
        p->mode = 8;
        sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator, ",");
        sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator, "\r\n");




      }else if( eMode=='w' ){

        newTempFile(p, "html");
        if( !bPlain ) p->mode = 20;
      }else{

        newTempFile(p, "txt");
      }
      sqlite3_free(zFile);
      zFile = sqlite3_mprintf("%s", p->zTempFile);
    }

    shell_check_oom(zFile);
    if( zFile[0]=='|' ){





      FILE *pfPipe = popen(zFile + 1, "w");
      if( pfPipe==0 ){
        ((void)sizeof(((_Bool(*)(_Bool))0)(__stderrp!=((void *)0))), (__stderrp!=((void *)0)) ? (void)0 : __assert(__func__, "/mnt/c/ParanoidBSD/dreamy-mahavira-7e0e79/hbsd/src/contrib/sqlite3/shell.c", 30590, "stderr!=NULL"));
        fprintf(__stderrp,"Error: cannot open pipe \"%s\"\n", zFile + 1);
        rc = 1;
      }else{
        output_redir(p, pfPipe);
        if( zBom ) fputs(zBom, pfPipe);
        sqlite3_snprintf(sizeof(p->outfile), p->outfile, "%s", zFile);
      }

    }else{
      FILE *pfFile = output_file_open(zFile);
      if( pfFile==0 ){
        if( cli_strcmp(zFile,"off")!=0 ){
         ((void)sizeof(((_Bool(*)(_Bool))0)(__stderrp!=((void *)0))), (__stderrp!=((void *)0)) ? (void)0 : __assert(__func__, "/mnt/c/ParanoidBSD/dreamy-mahavira-7e0e79/hbsd/src/contrib/sqlite3/shell.c", 30603, "stderr!=NULL"));
         fprintf(__stderrp,"Error: cannot write to \"%s\"\n", zFile);
        }
        rc = 1;
      } else {
        output_redir(p, pfFile);
        if( zBom ) fputs(zBom, pfFile);
        if( bPlain && eMode=='w' ){
          fputs(
            "<!DOCTYPE html>\n<BODY>\n<PLAINTEXT>\n",
            pfFile
          );
        }
        sqlite3_snprintf(sizeof(p->outfile), p->outfile, "%s", zFile);
      }
    }
    sqlite3_free(zFile);
  }else


  if( c=='p' && n>=3 && cli_strncmp(azArg[0], "parameter", n)==0 ){
    open_db(p,0);
    if( nArg<=1 ) goto parameter_syntax_error;




    if( nArg==2 && cli_strcmp(azArg[1],"clear")==0 ){
      sqlite3_exec(p->db, "DROP TABLE IF EXISTS temp.sqlite_parameters;",
                   0, 0, 0);
    }else




    if( nArg==2 && cli_strcmp(azArg[1],"list")==0 ){
      sqlite3_stmt *pStmt = 0;
      int rx;
      int len = 0;
      rx = sqlite3_prepare_v2(p->db,
             "SELECT max(length(key)) "
             "FROM temp.sqlite_parameters;", -1, &pStmt, 0);
      if( rx==0 && sqlite3_step(pStmt)==100 ){
        len = sqlite3_column_int(pStmt, 0);
        if( len>40 ) len = 40;
      }
      sqlite3_finalize(pStmt);
      pStmt = 0;
      if( len ){
        rx = sqlite3_prepare_v2(p->db,
             "SELECT key, quote(value) "
             "FROM temp.sqlite_parameters;", -1, &pStmt, 0);
        while( rx==0 && sqlite3_step(pStmt)==100 ){
          fprintf(p->out,
                "%-*s %s\n", len, sqlite3_column_text(pStmt,0),
                sqlite3_column_text(pStmt,1));
        }
        sqlite3_finalize(pStmt);
      }
    }else





    if( nArg==2 && cli_strcmp(azArg[1],"init")==0 ){
      bind_table_init(p);
    }else







    if( nArg==4 && cli_strcmp(azArg[1],"set")==0 ){
      int rx;
      char *zSql;
      sqlite3_stmt *pStmt;
      const char *zKey = azArg[2];
      const char *zValue = azArg[3];
      bind_table_init(p);
      zSql = sqlite3_mprintf(
                  "REPLACE INTO temp.sqlite_parameters(key,value)"
                  "VALUES(%Q,%s);", zKey, zValue);
      shell_check_oom(zSql);
      pStmt = 0;
      rx = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
      sqlite3_free(zSql);
      if( rx!=0 ){
        sqlite3_finalize(pStmt);
        pStmt = 0;
        zSql = sqlite3_mprintf(
                   "REPLACE INTO temp.sqlite_parameters(key,value)"
                   "VALUES(%Q,%Q);", zKey, zValue);
        shell_check_oom(zSql);
        rx = sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
        sqlite3_free(zSql);
        if( rx!=0 ){
          fprintf(p->out, "Error: %s\n", sqlite3_errmsg(p->db));
          sqlite3_finalize(pStmt);
          pStmt = 0;
          rc = 1;
        }
      }
      bind_prepared_stmt(p, pStmt);
      sqlite3_step(pStmt);
      sqlite3_finalize(pStmt);
    }else





    if( nArg==3 && cli_strcmp(azArg[1],"unset")==0 ){
      char *zSql = sqlite3_mprintf(
          "DELETE FROM temp.sqlite_parameters WHERE key=%Q", azArg[2]);
      shell_check_oom(zSql);
      sqlite3_exec(p->db, zSql, 0, 0, 0);
      sqlite3_free(zSql);
    }else

    parameter_syntax_error:
    showHelp(p->out, "parameter");
  }else

  if( c=='p' && n>=3 && cli_strncmp(azArg[0], "print", n)==0 ){
    int i;
    for(i=1; i<nArg; i++){
      if( i>1 ) fputs(" ", p->out);
      fputs(azArg[i], p->out);
    }
    fputs("\n", p->out);
  }else


  if( c=='p' && n>=3 && cli_strncmp(azArg[0], "progress", n)==0 ){
    int i;
    int nn = 0;
    p->flgProgress = 0;
    p->mxProgress = 0;
    p->nProgress = 0;
    for(i=1; i<nArg; i++){
      const char *z = azArg[i];
      if( z[0]=='-' ){
        z++;
        if( z[0]=='-' ) z++;
        if( cli_strcmp(z,"quiet")==0 || cli_strcmp(z,"q")==0 ){
          p->flgProgress |= 0x01;
          continue;
        }
        if( cli_strcmp(z,"reset")==0 ){
          p->flgProgress |= 0x02;
          continue;
        }
        if( cli_strcmp(z,"once")==0 ){
          p->flgProgress |= 0x04;
          continue;
        }
        if( cli_strcmp(z,"limit")==0 ){
          if( i+1>=nArg ){
            fputs("Error: missing argument on --limit\n",__stderrp);
            rc = 1;
            goto meta_command_exit;
          }else{
            p->mxProgress = (int)integerValue(azArg[++i]);
          }
          continue;
        }
        fprintf(__stderrp,"Error: unknown option: \"%s\"\n", azArg[i]);
        rc = 1;
        goto meta_command_exit;
      }else{
        nn = (int)integerValue(z);
      }
    }
    open_db(p, 0);
    sqlite3_progress_handler(p->db, nn, progress_handler, p);
  }else


  if( c=='p' && cli_strncmp(azArg[0], "prompt", n)==0 ){
    if( nArg >= 2) {
      shell_strncpy(mainPrompt,azArg[1],(int)(int)(sizeof(mainPrompt)/sizeof(mainPrompt[0]))-1);
    }
    if( nArg >= 3) {
      shell_strncpy(continuePrompt,azArg[2],(int)(int)(sizeof(continuePrompt)/sizeof(continuePrompt[0]))-1);
    }
  }else


  if( c=='q' && cli_strncmp(azArg[0], "quit", n)==0 ){
    rc = 2;
  }else



  if( c=='r' && n>=3 && cli_strncmp(azArg[0], "read", n)==0 ){
    FILE *inSaved = p->in;
    int savedLineno = p->lineno;
    failIfSafeMode(p, "cannot run .read in safe mode");
    if( nArg!=2 ){
      fputs("Usage: .read FILE\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    if( azArg[1][0]=='|' ){




      p->in = popen(azArg[1]+1, "r");
      if( p->in==0 ){
        fprintf(__stderrp,"Error: cannot open \"%s\"\n", azArg[1]);
        rc = 1;
      }else{
        rc = process_input(p);
        pclose(p->in);
      }

    }else if( (p->in = openChrSource(azArg[1]))==0 ){
      fprintf(__stderrp,"Error: cannot open \"%s\"\n", azArg[1]);
      rc = 1;
    }else{
      rc = process_input(p);
      fclose(p->in);
    }
    p->in = inSaved;
    p->lineno = savedLineno;
  }else



  if( c=='r' && n>=3 && cli_strncmp(azArg[0], "restore", n)==0 ){
    const char *zSrcFile;
    const char *zDb;
    sqlite3 *pSrc;
    sqlite3_backup *pBackup;
    int nTimeout = 0;

    failIfSafeMode(p, "cannot run .restore in safe mode");
    if( nArg==2 ){
      zSrcFile = azArg[1];
      zDb = "main";
    }else if( nArg==3 ){
      zSrcFile = azArg[2];
      zDb = azArg[1];
    }else{
      fputs("Usage: .restore ?DB? FILE\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    rc = sqlite3_open(zSrcFile, &pSrc);
    if( rc!=0 ){
      fprintf(__stderrp,"Error: cannot open \"%s\"\n", zSrcFile);
      close_db(pSrc);
      return 1;
    }
    open_db(p, 0);
    pBackup = sqlite3_backup_init(p->db, zDb, pSrc, "main");
    if( pBackup==0 ){
      shellDatabaseError(p->db);
      close_db(pSrc);
      return 1;
    }
    while( (rc = sqlite3_backup_step(pBackup,100))==0
          || rc==5 ){
      if( rc==5 ){
        if( nTimeout++ >= 3 ) break;
        sqlite3_sleep(100);
      }
    }
    sqlite3_backup_finish(pBackup);
    if( rc==101 ){
      rc = 0;
    }else if( rc==5 || rc==6 ){
      fputs("Error: source database is busy\n",__stderrp);
      rc = 1;
    }else{
      shellDatabaseError(p->db);
      rc = 1;
    }
    close_db(pSrc);
  }else


  if( c=='s' &&
     (cli_strncmp(azArg[0], "scanstats", n)==0 ||
      cli_strncmp(azArg[0], "scanstatus", n)==0)
  ){
    if( nArg==2 ){
      if( cli_strcmp(azArg[1], "vm")==0 ){
        p->scanstatsOn = 3;
      }else
      if( cli_strcmp(azArg[1], "est")==0 ){
        p->scanstatsOn = 2;
      }else{
        p->scanstatsOn = (u8)booleanValue(azArg[1]);
      }
      open_db(p, 0);
      sqlite3_db_config(
          p->db, 1018, p->scanstatsOn, (int*)0
      );

      fputs("Warning: .scanstats not available in this build.\n",__stderrp);





    }else{
      fputs("Usage: .scanstats on|off|est\n",__stderrp);
      rc = 1;
    }
  }else

  if( c=='s' && cli_strncmp(azArg[0], "schema", n)==0 ){
    ShellText sSelect;
    ShellState data;
    char *zErrMsg = 0;
    const char *zDiv = "(";
    const char *zName = 0;
    int iSchema = 0;
    int bDebug = 0;
    int bNoSystemTabs = 0;
    int ii;

    open_db(p, 0);
    memcpy(&data, p, sizeof(data));
    data.showHeader = 0;
    data.cMode = data.mode = 3;
    initText(&sSelect);
    for(ii=1; ii<nArg; ii++){
      if( optionMatch(azArg[ii],"indent") ){
        data.cMode = data.mode = 11;
      }else if( optionMatch(azArg[ii],"debug") ){
        bDebug = 1;
      }else if( optionMatch(azArg[ii],"nosys") ){
        bNoSystemTabs = 1;
      }else if( azArg[ii][0]=='-' ){
        fprintf(__stderrp,"Unknown option: \"%s\"\n", azArg[ii]);
        rc = 1;
        goto meta_command_exit;
      }else if( zName==0 ){
        zName = azArg[ii];
      }else{
        fputs("Usage: .schema ?--indent? ?--nosys? ?LIKE-PATTERN?\n",__stderrp);
        rc = 1;
        goto meta_command_exit;
      }
    }
    if( zName!=0 ){
      int isSchema = sqlite3_strlike(zName, "sqlite_master", '\\')==0
                  || sqlite3_strlike(zName, "sqlite_schema", '\\')==0
                  || sqlite3_strlike(zName,"sqlite_temp_master", '\\')==0
                  || sqlite3_strlike(zName,"sqlite_temp_schema", '\\')==0;
      if( isSchema ){
        char *new_argv[2], *new_colv[2];
        new_argv[0] = sqlite3_mprintf(
                      "CREATE TABLE %s (\n"
                      "  type text,\n"
                      "  name text,\n"
                      "  tbl_name text,\n"
                      "  rootpage integer,\n"
                      "  sql text\n"
                      ")", zName);
        shell_check_oom(new_argv[0]);
        new_argv[1] = 0;
        new_colv[0] = "sql";
        new_colv[1] = 0;
        callback(&data, 1, new_argv, new_colv);
        sqlite3_free(new_argv[0]);
      }
    }
    if( zDiv ){
      sqlite3_stmt *pStmt = 0;
      rc = sqlite3_prepare_v2(p->db, "SELECT name FROM pragma_database_list",
                              -1, &pStmt, 0);
      if( rc ){
        shellDatabaseError(p->db);
        sqlite3_finalize(pStmt);
        rc = 1;
        goto meta_command_exit;
      }
      appendText(&sSelect, "SELECT sql FROM", 0);
      iSchema = 0;
      while( sqlite3_step(pStmt)==100 ){
        const char *zDb = (const char*)sqlite3_column_text(pStmt, 0);
        char zScNum[30];
        sqlite3_snprintf(sizeof(zScNum), zScNum, "%d", ++iSchema);
        appendText(&sSelect, zDiv, 0);
        zDiv = " UNION ALL ";
        appendText(&sSelect, "SELECT shell_add_schema(sql,", 0);
        if( sqlite3_stricmp(zDb, "main")!=0 ){
          appendText(&sSelect, zDb, '\'');
        }else{
          appendText(&sSelect, "NULL", 0);
        }
        appendText(&sSelect, ",name) AS sql, type, tbl_name, name, rowid,", 0);
        appendText(&sSelect, zScNum, 0);
        appendText(&sSelect, " AS snum, ", 0);
        appendText(&sSelect, zDb, '\'');
        appendText(&sSelect, " AS sname FROM ", 0);
        appendText(&sSelect, zDb, quoteChar(zDb));
        appendText(&sSelect, ".sqlite_schema", 0);
      }
      sqlite3_finalize(pStmt);

      if( zName ){
        appendText(&sSelect,
           " UNION ALL SELECT shell_module_schema(name),"
           " 'table', name, name, name, 9e+99, 'main' FROM pragma_module_list",
        0);
      }

      appendText(&sSelect, ") WHERE ", 0);
      if( zName ){
        char *zQarg = sqlite3_mprintf("%Q", zName);
        int bGlob;
        shell_check_oom(zQarg);
        bGlob = strchr(zName, '*') != 0 || strchr(zName, '?') != 0 ||
                strchr(zName, '[') != 0;
        if( strchr(zName, '.') ){
          appendText(&sSelect, "lower(printf('%s.%s',sname,tbl_name))", 0);
        }else{
          appendText(&sSelect, "lower(tbl_name)", 0);
        }
        appendText(&sSelect, bGlob ? " GLOB " : " LIKE ", 0);
        appendText(&sSelect, zQarg, 0);
        if( !bGlob ){
          appendText(&sSelect, " ESCAPE '\\' ", 0);
        }
        appendText(&sSelect, " AND ", 0);
        sqlite3_free(zQarg);
      }
      if( bNoSystemTabs ){
        appendText(&sSelect, "name NOT LIKE 'sqlite_%%' AND ", 0);
      }
      appendText(&sSelect, "sql IS NOT NULL"
                           " ORDER BY snum, rowid", 0);
      if( bDebug ){
        fprintf(p->out, "SQL: %s;\n", sSelect.z);
      }else{
        rc = sqlite3_exec(p->db, sSelect.z, callback, &data, &zErrMsg);
      }
      freeText(&sSelect);
    }
    if( zErrMsg ){
      shellEmitError(zErrMsg);
      sqlite3_free(zErrMsg);
      rc = 1;
    }else if( rc != 0 ){
      fputs("Error: querying schema information\n",__stderrp);
      rc = 1;
    }else{
      rc = 0;
    }
  }else

  if( (c=='s' && n==11 && cli_strncmp(azArg[0], "selecttrace", n)==0)
   || (c=='t' && n==9 && cli_strncmp(azArg[0], "treetrace", n)==0)
  ){
    unsigned int x = nArg>=2? (unsigned int)integerValue(azArg[1]) : 0xffffffff;
    sqlite3_test_control(31, 1, &x);
  }else
  if( c=='s' && n>=4 && cli_strncmp(azArg[0],"selftest",n)==0 ){
    int bIsInit = 0;
    int bVerbose = 0;
    int bSelftestExists;
    int i, k;
    int nTest = 0;
    int nErr = 0;
    ShellText str;
    sqlite3_stmt *pStmt = 0;

    open_db(p,0);
    for(i=1; i<nArg; i++){
      const char *z = azArg[i];
      if( z[0]=='-' && z[1]=='-' ) z++;
      if( cli_strcmp(z,"-init")==0 ){
        bIsInit = 1;
      }else
      if( cli_strcmp(z,"-v")==0 ){
        bVerbose++;
      }else
      {
        fprintf(__stderrp,
              "Unknown option \"%s\" on \"%s\"\n", azArg[i], azArg[0]);
        fputs("Should be one of: --init -v\n", __stderrp);
        rc = 1;
        goto meta_command_exit;
      }
    }
    if( sqlite3_table_column_metadata(p->db,"main","selftest",0,0,0,0,0,0)
           != 0 ){
      bSelftestExists = 0;
    }else{
      bSelftestExists = 1;
    }
    if( bIsInit ){
      createSelftestTable(p);
      bSelftestExists = 1;
    }
    initText(&str);
    appendText(&str, "x", 0);
    for(k=bSelftestExists; k>=0; k--){
      if( k==1 ){
        rc = sqlite3_prepare_v2(p->db,
            "SELECT tno,op,cmd,ans FROM selftest ORDER BY tno",
            -1, &pStmt, 0);
      }else{
        rc = sqlite3_prepare_v2(p->db,
          "VALUES(0,'memo','Missing SELFTEST table - default checks only',''),"
          "      (1,'run','PRAGMA integrity_check','ok')",
          -1, &pStmt, 0);
      }
      if( rc ){
        fputs("Error querying the selftest table\n",__stderrp);
        rc = 1;
        sqlite3_finalize(pStmt);
        goto meta_command_exit;
      }
      for(i=1; sqlite3_step(pStmt)==100; i++){
        int tno = sqlite3_column_int(pStmt, 0);
        const char *zOp = (const char*)sqlite3_column_text(pStmt, 1);
        const char *zSql = (const char*)sqlite3_column_text(pStmt, 2);
        const char *zAns = (const char*)sqlite3_column_text(pStmt, 3);

        if( zOp==0 ) continue;
        if( zSql==0 ) continue;
        if( zAns==0 ) continue;
        k = 0;
        if( bVerbose>0 ){
          fprintf(__stdoutp, "%d: %s %s\n", tno, zOp, zSql);
        }
        if( cli_strcmp(zOp,"memo")==0 ){
          fprintf(p->out, "%s\n", zSql);
        }else
        if( cli_strcmp(zOp,"run")==0 ){
          char *zErrMsg = 0;
          str.n = 0;
          str.z[0] = 0;
          rc = sqlite3_exec(p->db, zSql, captureOutputCallback, &str, &zErrMsg);
          nTest++;
          if( bVerbose ){
            fprintf(p->out, "Result: %s\n", str.z);
          }
          if( rc || zErrMsg ){
            nErr++;
            rc = 1;
            fprintf(p->out, "%d: error-code-%d: %s\n", tno, rc,zErrMsg);
            sqlite3_free(zErrMsg);
          }else if( cli_strcmp(zAns,str.z)!=0 ){
            nErr++;
            rc = 1;
            fprintf(p->out, "%d: Expected: [%s]\n", tno, zAns);
            fprintf(p->out, "%d:      Got: [%s]\n", tno, str.z);
          }
        }
        else{
          fprintf(__stderrp,
                "Unknown operation \"%s\" on selftest line %d\n", zOp, tno);
          rc = 1;
          break;
        }
      }
      sqlite3_finalize(pStmt);
    }
    freeText(&str);
    fprintf(p->out, "%d errors out of %d tests\n", nErr, nTest);
  }else

  if( c=='s' && cli_strncmp(azArg[0], "separator", n)==0 ){
    if( nArg<2 || nArg>3 ){
      fputs("Usage: .separator COL ?ROW?\n",__stderrp);
      rc = 1;
    }
    if( nArg>=2 ){
      sqlite3_snprintf(sizeof(p->colSeparator), p->colSeparator,
                       "%.*s", (int)(int)(sizeof(p->colSeparator)/sizeof(p->colSeparator[0]))-1, azArg[1]);
    }
    if( nArg>=3 ){
      sqlite3_snprintf(sizeof(p->rowSeparator), p->rowSeparator,
                       "%.*s", (int)(int)(sizeof(p->rowSeparator)/sizeof(p->rowSeparator[0]))-1, azArg[2]);
    }
  }else

  if( c=='s' && n>=4 && cli_strncmp(azArg[0],"sha3sum",n)==0 ){
    const char *zLike = 0;
    int i;
    int bSchema = 0;
    int bSeparate = 0;
    int iSize = 224;
    int bDebug = 0;
    sqlite3_stmt *pStmt;
    char *zSql;
    char *zSep;
    ShellText sSql;
    ShellText sQuery;
    open_db(p, 0);
    for(i=1; i<nArg; i++){
      const char *z = azArg[i];
      if( z[0]=='-' ){
        z++;
        if( z[0]=='-' ) z++;
        if( cli_strcmp(z,"schema")==0 ){
          bSchema = 1;
        }else
        if( cli_strcmp(z,"sha3-224")==0 || cli_strcmp(z,"sha3-256")==0
         || cli_strcmp(z,"sha3-384")==0 || cli_strcmp(z,"sha3-512")==0
        ){
          iSize = atoi(&z[5]);
        }else
        if( cli_strcmp(z,"debug")==0 ){
          bDebug = 1;
        }else
        {
          fprintf(__stderrp,
                  "Unknown option \"%s\" on \"%s\"\n", azArg[i], azArg[0]);
          showHelp(p->out, azArg[0]);
          rc = 1;
          goto meta_command_exit;
        }
      }else if( zLike ){
        fputs("Usage: .sha3sum ?OPTIONS? ?LIKE-PATTERN?\n",__stderrp);
        rc = 1;
        goto meta_command_exit;
      }else{
        zLike = z;
        bSeparate = 1;
        if( sqlite3_strlike("sqlite\\_%", zLike, '\\')==0 ) bSchema = 1;
      }
    }
    if( bSchema ){
      zSql = "SELECT lower(name) as tname FROM sqlite_schema"
             " WHERE type='table' AND coalesce(rootpage,0)>1"
             " UNION ALL SELECT 'sqlite_schema'"
             " ORDER BY 1 collate nocase";
    }else{
      zSql = "SELECT lower(name) as tname FROM sqlite_schema"
             " WHERE type='table' AND coalesce(rootpage,0)>1"
             " AND name NOT LIKE 'sqlite_%'"
             " ORDER BY 1 collate nocase";
    }
    sqlite3_prepare_v2(p->db, zSql, -1, &pStmt, 0);
    initText(&sQuery);
    initText(&sSql);
    appendText(&sSql, "WITH [sha3sum$query](a,b) AS(",0);
    zSep = "VALUES(";
    while( 100==sqlite3_step(pStmt) ){
      const char *zTab = (const char*)sqlite3_column_text(pStmt,0);
      if( zTab==0 ) continue;
      if( zLike && sqlite3_strlike(zLike, zTab, 0)!=0 ) continue;
      if( cli_strncmp(zTab, "sqlite_",7)!=0 ){
        appendText(&sQuery,"SELECT * FROM ", 0);
        appendText(&sQuery,zTab,'"');
        appendText(&sQuery," NOT INDEXED;", 0);
      }else if( cli_strcmp(zTab, "sqlite_schema")==0 ){
        appendText(&sQuery,"SELECT type,name,tbl_name,sql FROM sqlite_schema"
                           " ORDER BY name;", 0);
      }else if( cli_strcmp(zTab, "sqlite_sequence")==0 ){
        appendText(&sQuery,"SELECT name,seq FROM sqlite_sequence"
                           " ORDER BY name;", 0);
      }else if( cli_strcmp(zTab, "sqlite_stat1")==0 ){
        appendText(&sQuery,"SELECT tbl,idx,stat FROM sqlite_stat1"
                           " ORDER BY tbl,idx;", 0);
      }else if( cli_strcmp(zTab, "sqlite_stat4")==0 ){
        appendText(&sQuery, "SELECT * FROM ", 0);
        appendText(&sQuery, zTab, 0);
        appendText(&sQuery, " ORDER BY tbl, idx, rowid;\n", 0);
      }
      appendText(&sSql, zSep, 0);
      appendText(&sSql, sQuery.z, '\'');
      sQuery.n = 0;
      appendText(&sSql, ",", 0);
      appendText(&sSql, zTab, '\'');
      zSep = "),(";
    }
    sqlite3_finalize(pStmt);
    if( bSeparate ){
      zSql = sqlite3_mprintf(
          "%s))"
          " SELECT lower(hex(sha3_query(a,%d))) AS hash, b AS label"
          "   FROM [sha3sum$query]",
          sSql.z, iSize);
    }else{
      zSql = sqlite3_mprintf(
          "%s))"
          " SELECT lower(hex(sha3_query(group_concat(a,''),%d))) AS hash"
          "   FROM [sha3sum$query]",
          sSql.z, iSize);
    }
    shell_check_oom(zSql);
    freeText(&sQuery);
    freeText(&sSql);
    if( bDebug ){
      fprintf(p->out, "%s\n", zSql);
    }else{
      shell_exec(p, zSql, 0);
    }

    {
      int lrc;
      char *zRevText =
        "SELECT lower(name) as tname FROM sqlite_schema\n"
        "WHERE type='table' AND coalesce(rootpage,0)>1\n"
        "AND name NOT LIKE 'sqlite_%%'%s\n"
        "ORDER BY 1 collate nocase";
      zRevText = sqlite3_mprintf(zRevText, zLike? " AND name LIKE $tspec" : "");
      zRevText = sqlite3_mprintf(

          "with tabcols as materialized(\n"
          "select tname, cname\n"
          "from ("
          " select printf('\"%%w\"',ss.tname) as tname,"
          " printf('\"%%w\"',ti.name) as cname\n"
          " from (%z) ss\n inner join pragma_table_info(tname) ti))\n"
          "select 'SELECT total(bad_text_count) AS bad_text_count\n"
          "FROM ('||group_concat(query, ' UNION ALL ')||')' as btc_query\n"
          " from (select 'SELECT COUNT(*) AS bad_text_count\n"
          "FROM '||tname||' WHERE '\n"
          "||group_concat('CAST(CAST('||cname||' AS BLOB) AS TEXT)<>'||cname\n"
          "|| ' AND typeof('||cname||')=''text'' ',\n"
          "' OR ') as query, tname from tabcols group by tname)"
          , zRevText);
      shell_check_oom(zRevText);
      if( bDebug ) fprintf(p->out, "%s\n", zRevText);
      lrc = sqlite3_prepare_v2(p->db, zRevText, -1, &pStmt, 0);
      if( lrc!=0 ){


        rc = 1;
      }else{
        if( zLike ) sqlite3_bind_text(pStmt,1,zLike,-1,((sqlite3_destructor_type)0));
        lrc = 100==sqlite3_step(pStmt);
        if( lrc ){
          const char *zGenQuery = (char*)sqlite3_column_text(pStmt,0);
          sqlite3_stmt *pCheckStmt;
          lrc = sqlite3_prepare_v2(p->db, zGenQuery, -1, &pCheckStmt, 0);
          if( bDebug ) fprintf(p->out, "%s\n", zGenQuery);
          if( lrc!=0 ){
            rc = 1;
          }else{
            if( 100==sqlite3_step(pCheckStmt) ){
              double countIrreversible = sqlite3_column_double(pCheckStmt, 0);
              if( countIrreversible>0 ){
                int sz = (int)(countIrreversible + 0.5);
                fprintf(__stderrp,
                      "Digest includes %d invalidly encoded text field%s.\n",
                      sz, (sz>1)? "s": "");
              }
            }
            sqlite3_finalize(pCheckStmt);
          }
          sqlite3_finalize(pStmt);
        }
      }
      if( rc ) fputs(".sha3sum failed.\n",__stderrp);
      sqlite3_free(zRevText);
    }

    sqlite3_free(zSql);
  }else


  if( c=='s'
   && (cli_strncmp(azArg[0], "shell", n)==0
       || cli_strncmp(azArg[0],"system",n)==0)
  ){
    char *zCmd;
    int i, x;
    failIfSafeMode(p, "cannot run .%s in safe mode", azArg[0]);
    if( nArg<2 ){
      fputs("Usage: .system COMMAND\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    zCmd = sqlite3_mprintf(strchr(azArg[1],' ')==0?"%s":"\"%s\"", azArg[1]);
    for(i=2; i<nArg && zCmd!=0; i++){
      zCmd = sqlite3_mprintf(strchr(azArg[i],' ')==0?"%z %s":"%z \"%s\"",
                             zCmd, azArg[i]);
    }

    x = zCmd!=0 ? system(zCmd) : 1;

    sqlite3_free(zCmd);
    if( x ) fprintf(__stderrp,"System command returns %d\n", x);
  }else


  if( c=='s' && cli_strncmp(azArg[0], "show", n)==0 ){
    static const char *azBool[] = { "off", "on", "trigger", "full"};
    const char *zOut;
    int i;
    if( nArg!=1 ){
      fputs("Usage: .show\n",__stderrp);
      rc = 1;
      goto meta_command_exit;
    }
    fprintf(p->out, "%12.12s: %s\n","echo",
          azBool[(((p)->shellFlgs & (0x00000040))!=0)]);
    fprintf(p->out, "%12.12s: %s\n","eqp", azBool[p->autoEQP&3]);
    fprintf(p->out, "%12.12s: %s\n","explain",
          p->mode==9 ? "on" : p->autoExplain ? "auto" : "off");
    fprintf(p->out, "%12.12s: %s\n","headers",
          azBool[p->showHeader!=0]);
    if( p->mode==1
     || (p->mode>=14 && p->mode<=16)
    ){
      fprintf(p->out,
            "%12.12s: %s --wrap %d --wordwrap %s --%squote\n", "mode",
            modeDescr[p->mode], p->cmOpts.iWrap,
            p->cmOpts.bWordWrap ? "on" : "off",
            p->cmOpts.bQuote ? "" : "no");
    }else{
      fprintf(p->out, "%12.12s: %s\n","mode", modeDescr[p->mode]);
    }
    fprintf(p->out, "%12.12s: ", "nullvalue");
    output_c_string(p->out, p->nullValue);
    fputs("\n", p->out);
    fprintf(p->out, "%12.12s: %s\n","output",
          strlen30(p->outfile) ? p->outfile : "stdout");
    fprintf(p->out, "%12.12s: ", "colseparator");
    output_c_string(p->out, p->colSeparator);
    fputs("\n", p->out);
    fprintf(p->out, "%12.12s: ", "rowseparator");
    output_c_string(p->out, p->rowSeparator);
    fputs("\n", p->out);
    switch( p->statsOn ){
      case 0: zOut = "off"; break;
      default: zOut = "on"; break;
      case 2: zOut = "stmt"; break;
      case 3: zOut = "vmstep"; break;
    }
    fprintf(p->out, "%12.12s: %s\n","stats", zOut);
    fprintf(p->out, "%12.12s: ", "width");
    for (i=0;i<p->nWidth;i++) {
      fprintf(p->out, "%d ", p->colWidth[i]);
    }
    fputs("\n", p->out);
    fprintf(p->out, "%12.12s: %s\n", "filename",
          p->pAuxDb->zDbFilename ? p->pAuxDb->zDbFilename : "");
  }else

  if( c=='s' && cli_strncmp(azArg[0], "stats", n)==0 ){
    if( nArg==2 ){
      if( cli_strcmp(azArg[1],"stmt")==0 ){
        p->statsOn = 2;
      }else if( cli_strcmp(azArg[1],"vmstep")==0 ){
        p->statsOn = 3;
      }else{
        p->statsOn = (u8)booleanValue(azArg[1]);
      }
    }else if( nArg==1 ){
      display_stats(p->db, p, 0);
    }else{
      fputs("Usage: .stats ?on|off|stmt|vmstep?\n",__stderrp);
      rc = 1;
    }
  }else

  if( (c=='t' && n>1 && cli_strncmp(azArg[0], "tables", n)==0)
   || (c=='i' && (cli_strncmp(azArg[0], "indices", n)==0
                 || cli_strncmp(azArg[0], "indexes", n)==0) )
  ){
    sqlite3_stmt *pStmt;
    char **azResult;
    int nRow, nAlloc;
    int ii;
    ShellText s;
    initText(&s);
    open_db(p, 0);
    rc = sqlite3_prepare_v2(p->db, "PRAGMA database_list", -1, &pStmt, 0);
    if( rc ){
      sqlite3_finalize(pStmt);
      return shellDatabaseError(p->db);
    }

    if( nArg>2 && c=='i' ){



      fputs("Usage: .indexes ?LIKE-PATTERN?\n",__stderrp);
      rc = 1;
      sqlite3_finalize(pStmt);
      goto meta_command_exit;
    }
    for(ii=0; sqlite3_step(pStmt)==100; ii++){
      const char *zDbName = (const char*)sqlite3_column_text(pStmt, 1);
      if( zDbName==0 ) continue;
      if( s.z && s.z[0] ) appendText(&s, " UNION ALL ", 0);
      if( sqlite3_stricmp(zDbName, "main")==0 ){
        appendText(&s, "SELECT name FROM ", 0);
      }else{
        appendText(&s, "SELECT ", 0);
        appendText(&s, zDbName, '\'');
        appendText(&s, "||'.'||name FROM ", 0);
      }
      appendText(&s, zDbName, '"');
      appendText(&s, ".sqlite_schema ", 0);
      if( c=='t' ){
        appendText(&s," WHERE type IN ('table','view')"
                      "   AND name NOT LIKE 'sqlite_%'"
                      "   AND name LIKE ?1", 0);
      }else{
        appendText(&s," WHERE type='index'"
                      "   AND tbl_name LIKE ?1", 0);
      }
    }
    rc = sqlite3_finalize(pStmt);
    if( rc==0 ){
      appendText(&s, " ORDER BY 1", 0);
      rc = sqlite3_prepare_v2(p->db, s.z, -1, &pStmt, 0);
    }
    freeText(&s);
    if( rc ) return shellDatabaseError(p->db);



    nRow = nAlloc = 0;
    azResult = 0;
    if( nArg>1 ){
      sqlite3_bind_text(pStmt, 1, azArg[1], -1, ((sqlite3_destructor_type)-1));
    }else{
      sqlite3_bind_text(pStmt, 1, "%", -1, ((sqlite3_destructor_type)0));
    }
    while( sqlite3_step(pStmt)==100 ){
      if( nRow>=nAlloc ){
        char **azNew;
        int n2 = nAlloc*2 + 10;
        azNew = sqlite3_realloc64(azResult, sizeof(azResult[0])*n2);
        shell_check_oom(azNew);
        nAlloc = n2;
        azResult = azNew;
      }
      azResult[nRow] = sqlite3_mprintf("%s", sqlite3_column_text(pStmt, 0));
      shell_check_oom(azResult[nRow]);
      nRow++;
    }
    if( sqlite3_finalize(pStmt)!=0 ){
      rc = shellDatabaseError(p->db);
    }


    if( rc==0 && nRow>0 ){
      int len, maxlen = 0;
      int i, j;
      int nPrintCol, nPrintRow;
      for(i=0; i<nRow; i++){
        len = strlen30(azResult[i]);
        if( len>maxlen ) maxlen = len;
      }
      nPrintCol = 80/(maxlen+2);
      if( nPrintCol<1 ) nPrintCol = 1;
      nPrintRow = (nRow + nPrintCol - 1)/nPrintCol;
      for(i=0; i<nPrintRow; i++){
        for(j=i; j<nRow; j+=nPrintRow){
          char *zSp = j<nPrintRow ? "" : "  ";
          fprintf(p->out,
               "%s%-*s", zSp, maxlen, azResult[j] ? azResult[j]:"");
        }
        fputs("\n", p->out);
      }
    }

    for(ii=0; ii<nRow; ii++) sqlite3_free(azResult[ii]);
    sqlite3_free(azResult);
  }else



  if( c=='t' && cli_strcmp(azArg[0],"testcase")==0 ){
    output_reset(p);
    p->out = output_file_open("testcase-out.txt");
    if( p->out==0 ){
      fputs("Error: cannot open 'testcase-out.txt'\n",__stderrp);
    }
    if( nArg>=2 ){
      sqlite3_snprintf(sizeof(p->zTestcase), p->zTestcase, "%s", azArg[1]);
    }else{
      sqlite3_snprintf(sizeof(p->zTestcase), p->zTestcase, "?");
    }
  }else



  if( c=='t' && n>=8 && cli_strncmp(azArg[0], "testctrl", n)==0 ){
    static const struct {
       const char *zCtrlName;
       int ctrlCode;
       int unSafe;
       const char *zUsage;
    } aCtrl[] = {
    {"always", 13, 1, "BOOLEAN" },
    {"assert", 12, 1, "BOOLEAN" },


    {"byteorder", 22, 0, "" },
    {"extra_schema_checks",29,0,"BOOLEAN" },
    {"fault_install", 9, 1,"args..." },
    {"fk_no_action", 7, 0, "BOOLEAN" },
    {"imposter", 25,1,"SCHEMA ON/OFF ROOTPAGE"},
    {"internal_functions", 17,0,"" },
    {"json_selfcheck", 14 ,0,"BOOLEAN" },
    {"localtime_fault", 18,0,"BOOLEAN" },
    {"never_corrupt", 20,1, "BOOLEAN" },
    {"optimizations", 15,0,"DISABLE-MASK ..."},



    {"pending_byte", 11,1, "OFFSET  " },
    {"prng_restore", 6,0, "" },
    {"prng_save", 5, 0, "" },
    {"prng_seed", 28, 0, "SEED ?db?" },
    {"seek_count", 30, 0, "" },
    {"sorter_mmap", 24, 0, "NMAX" },
    {"tune", 32, 1, "ID VALUE" },
    };
    int testctrl = -1;
    int iCtrl = -1;
    int rc2 = 0;
    int isOk = 0;
    int i, n2;
    const char *zCmd = 0;

    open_db(p, 0);
    zCmd = nArg>=2 ? azArg[1] : "help";


    if( zCmd[0]=='-' && zCmd[1] ){
      zCmd++;
      if( zCmd[0]=='-' && zCmd[1] ) zCmd++;
    }


    if( cli_strcmp(zCmd,"help")==0 ){
      fputs("Available test-controls:\n", p->out);
      for(i=0; i<(int)(sizeof(aCtrl)/sizeof(aCtrl[0])); i++){
        if( aCtrl[i].unSafe && !(((p)->shellFlgs & (0x00000400))!=0) ) continue;
        fprintf(p->out, "  .testctrl %s %s\n",
              aCtrl[i].zCtrlName, aCtrl[i].zUsage);
      }
      rc = 1;
      goto meta_command_exit;
    }



    n2 = strlen30(zCmd);
    for(i=0; i<(int)(sizeof(aCtrl)/sizeof(aCtrl[0])); i++){
      if( aCtrl[i].unSafe && !(((p)->shellFlgs & (0x00000400))!=0) ) continue;
      if( cli_strncmp(zCmd, aCtrl[i].zCtrlName, n2)==0 ){
        if( testctrl<0 ){
          testctrl = aCtrl[i].ctrlCode;
          iCtrl = i;
        }else{
          fprintf(__stderrp,"Error: ambiguous test-control: \"%s\"\n"
                "Use \".testctrl --help\" for help\n", zCmd);
          rc = 1;
          goto meta_command_exit;
        }
      }
    }
    if( testctrl<0 ){
      fprintf(__stderrp,"Error: unknown test-control: %s\n"
            "Use \".testctrl --help\" for help\n", zCmd);
    }else{
      switch(testctrl){
        case 15: {
          static const struct {
             unsigned int mask;
             unsigned int bDsply;
             const char *zLabel;
          } aLabel[] = {
            { 0x00000001, 1, "QueryFlattener" },
            { 0x00000001, 0, "Flatten" },
            { 0x00000002, 1, "WindowFunc" },
            { 0x00000004, 1, "GroupByOrder" },
            { 0x00000008, 1, "FactorOutConst" },
            { 0x00000010, 1, "DistinctOpt" },
            { 0x00000020, 1, "CoverIdxScan" },
            { 0x00000040, 1, "OrderByIdxJoin" },
            { 0x00000080, 1, "Transitive" },
            { 0x00000100, 1, "OmitNoopJoin" },
            { 0x00000200, 1, "CountOfView" },
            { 0x00000400, 1, "CurosrHints" },
            { 0x00000800, 1, "Stat4" },
            { 0x00001000, 1, "PushDown" },
            { 0x00002000, 1, "SimplifyJoin" },
            { 0x00004000, 1, "SkipScan" },
            { 0x00008000, 1, "PropagateConst" },
            { 0x00010000, 1, "MinMaxOpt" },
            { 0x00020000, 1, "SeekScan" },
            { 0x00040000, 1, "OmitOrderBy" },
            { 0x00080000, 1, "BloomFilter" },
            { 0x00100000, 1, "BloomPulldown" },
            { 0x00200000, 1, "BalancedMerge" },
            { 0x00400000, 1, "ReleaseReg" },
            { 0x00800000, 1, "FlttnUnionAll" },
            { 0x01000000, 1, "IndexedEXpr" },
            { 0x02000000, 1, "Coroutines" },
            { 0x04000000, 1, "NullUnusedCols" },
            { 0x08000000, 1, "OnePass" },
            { 0x10000000, 1, "OrderBySubq" },
            { 0x20000000, 1, "StarQuery" },
            { 0xffffffff, 0, "All" },
          };
          unsigned int curOpt;
          unsigned int newOpt;
          unsigned int m;
          int ii;
          int nOff;
          sqlite3_test_control(16, p->db, &curOpt);
          newOpt = curOpt;
          for(ii=2; ii<nArg; ii++){
            const char *z = azArg[ii];
            int useLabel = 0;
            const char *zLabel = 0;
            if( (z[0]=='+'|| z[0]=='-') && !__sbistype(((unsigned char)z[1]), 0x00000400L) ){
              useLabel = z[0];
              zLabel = &z[1];
            }else if( !__sbistype(((unsigned char)z[0]), 0x00000400L) && z[0]!=0 && !__sbistype(((unsigned char)z[1]), 0x00000400L) ){
              useLabel = '+';
              zLabel = z;
            }else{
              newOpt = (unsigned int)strtol(z,0,0);
            }
            if( useLabel ){
              int jj;
              for(jj=0; jj<(int)(sizeof(aLabel)/sizeof(aLabel[0])); jj++){
                if( sqlite3_stricmp(zLabel, aLabel[jj].zLabel)==0 ) break;
              }
              if( jj>=(int)(sizeof(aLabel)/sizeof(aLabel[0])) ){
                fprintf(__stderrp,
                    "Error: no such optimization: \"%s\"\n", zLabel);
                fputs("Should be one of:", __stderrp);
                for(jj=0; jj<(int)(sizeof(aLabel)/sizeof(aLabel[0])); jj++){
                  fprintf(__stderrp," %s", aLabel[jj].zLabel);
                }
                fputs("\n", __stderrp);
                rc = 1;
                goto meta_command_exit;
              }
              if( useLabel=='+' ){
                newOpt &= ~aLabel[jj].mask;
              }else{
                newOpt |= aLabel[jj].mask;
              }
            }
          }
          if( curOpt!=newOpt ){
            sqlite3_test_control(15,p->db,newOpt);
          }
          for(ii=nOff=0, m=1; ii<32; ii++, m <<= 1){
            if( m & newOpt ) nOff++;
          }
          if( nOff<12 ){
            fputs("+All", p->out);
            for(ii=0; ii<(int)(sizeof(aLabel)/sizeof(aLabel[0])); ii++){
              if( !aLabel[ii].bDsply ) continue;
              if( (newOpt & aLabel[ii].mask)!=0 ){
                fprintf(p->out, " -%s", aLabel[ii].zLabel);
              }
            }
          }else{
            fputs("-All", p->out);
            for(ii=0; ii<(int)(sizeof(aLabel)/sizeof(aLabel[0])); ii++){
              if( !aLabel[ii].bDsply ) continue;
              if( (newOpt & aLabel[ii].mask)==0 ){
                fprintf(p->out, " +%s", aLabel[ii].zLabel);
              }
            }
          }
          fputs("\n", p->out);
          rc2 = isOk = 3;
          break;
        }


        case 7:
          if( nArg==3 ){
            unsigned int opt = (unsigned int)strtol(azArg[2], 0, 0);
            rc2 = sqlite3_test_control(testctrl, p->db, opt);
            isOk = 3;
          }
          break;


        case 5:
        case 6:
        case 22:
          if( nArg==2 ){
            rc2 = sqlite3_test_control(testctrl);
            isOk = testctrl==22 ? 1 : 3;
          }
          break;


        case 11:
          if( nArg==3 ){
            unsigned int opt = (unsigned int)integerValue(azArg[2]);
            rc2 = sqlite3_test_control(testctrl, opt);
            isOk = 3;
          }
          break;


        case 28:
          if( nArg==3 || nArg==4 ){
            int ii = (int)integerValue(azArg[2]);
            sqlite3 *db;
            if( ii==0 && cli_strcmp(azArg[2],"random")==0 ){
              sqlite3_randomness(sizeof(ii),&ii);
              fprintf(__stdoutp, "-- random seed: %d\n", ii);
            }
            if( nArg==3 ){
              db = 0;
            }else{
              db = p->db;

              sqlite3_table_column_metadata(db, 0, "x", 0, 0, 0, 0, 0, 0);
            }
            rc2 = sqlite3_test_control(testctrl, ii, db);
            isOk = 3;
          }
          break;


        case 12:
        case 13:
          if( nArg==3 ){
            int opt = booleanValue(azArg[2]);
            rc2 = sqlite3_test_control(testctrl, opt);
            isOk = 1;
          }
          break;


        case 18:
        case 20:
          if( nArg==3 ){
            int opt = booleanValue(azArg[2]);
            rc2 = sqlite3_test_control(testctrl, opt);
            isOk = 3;
          }
          break;


        case 17:
          rc2 = sqlite3_test_control(testctrl, p->db);
          isOk = 3;
          break;

        case 25:
          if( nArg==5 ){
            rc2 = sqlite3_test_control(testctrl, p->db,
                          azArg[2],
                          integerValue(azArg[3]),
                          integerValue(azArg[4]));
            isOk = 3;
          }
          break;

        case 30: {
          u64 x = 0;
          rc2 = sqlite3_test_control(testctrl, p->db, &x);
          fprintf(p->out, "%llu\n", x);
          isOk = 3;
          break;
        }
        case 24:
          if( nArg==3 ){
            int opt = (unsigned int)integerValue(azArg[2]);
            rc2 = sqlite3_test_control(testctrl, p->db, opt);
            isOk = 3;
          }
          break;
        case 14:
          if( nArg==2 ){
            rc2 = -1;
            isOk = 1;
          }else{
            rc2 = booleanValue(azArg[2]);
            isOk = 3;
          }
          sqlite3_test_control(testctrl, &rc2);
          break;
        case 9: {
          int kk;
          int bShowHelp = nArg<=2;
          isOk = 3;
          for(kk=2; kk<nArg; kk++){
            const char *z = azArg[kk];
            if( z[0]=='-' && z[1]=='-' ) z++;
            if( cli_strcmp(z,"off")==0 ){
              sqlite3_test_control(testctrl, 0);
            }else if( cli_strcmp(z,"on")==0 ){
              faultsim_state.iCnt = faultsim_state.nSkip;
              if( faultsim_state.iErr==0 ) faultsim_state.iErr = 1;
              faultsim_state.nHit = 0;
              sqlite3_test_control(testctrl, faultsim_callback);
            }else if( cli_strcmp(z,"reset")==0 ){
              faultsim_state.iCnt = faultsim_state.nSkip;
              faultsim_state.nHit = 0;
              sqlite3_test_control(testctrl, faultsim_callback);
            }else if( cli_strcmp(z,"status")==0 ){
              fprintf(p->out, "faultsim.iId:       %d\n",
                              faultsim_state.iId);
              fprintf(p->out, "faultsim.iErr:      %d\n",
                              faultsim_state.iErr);
              fprintf(p->out, "faultsim.iCnt:      %d\n",
                              faultsim_state.iCnt);
              fprintf(p->out, "faultsim.nHit:      %d\n",
                              faultsim_state.nHit);
              fprintf(p->out, "faultsim.iInterval: %d\n",
                              faultsim_state.iInterval);
              fprintf(p->out, "faultsim.eVerbose:  %d\n",
                              faultsim_state.eVerbose);
              fprintf(p->out, "faultsim.nRepeat:   %d\n",
                              faultsim_state.nRepeat);
              fprintf(p->out, "faultsim.nSkip:     %d\n",
                              faultsim_state.nSkip);
            }else if( cli_strcmp(z,"-v")==0 ){
              if( faultsim_state.eVerbose<2 ) faultsim_state.eVerbose++;
            }else if( cli_strcmp(z,"-q")==0 ){
              if( faultsim_state.eVerbose>0 ) faultsim_state.eVerbose--;
            }else if( cli_strcmp(z,"-id")==0 && kk+1<nArg ){
              faultsim_state.iId = atoi(azArg[++kk]);
            }else if( cli_strcmp(z,"-errcode")==0 && kk+1<nArg ){
              faultsim_state.iErr = atoi(azArg[++kk]);
            }else if( cli_strcmp(z,"-interval")==0 && kk+1<nArg ){
              faultsim_state.iInterval = atoi(azArg[++kk]);
            }else if( cli_strcmp(z,"-repeat")==0 && kk+1<nArg ){
              faultsim_state.nRepeat = atoi(azArg[++kk]);
           }else if( cli_strcmp(z,"-skip")==0 && kk+1<nArg ){
              faultsim_state.nSkip = atoi(azArg[++kk]);
            }else if( cli_strcmp(z,"-?")==0 || sqlite3_strglob("*help*",z)==0){
              bShowHelp = 1;
            }else{
              fprintf(__stderrp,
                  "Unrecognized fault_install argument: \"%s\"\n",
                  azArg[kk]);
              rc = 1;
              bShowHelp = 1;
              break;
            }
          }
          if( bShowHelp ){
            fputs(
               "Usage: .testctrl fault_install ARGS\n"
               "Possible arguments:\n"
               "   off               Disable faultsim\n"
               "   on                Activate faultsim\n"
               "   reset             Reset the trigger counter\n"
               "   status            Show current status\n"
               "   -v                Increase verbosity\n"
               "   -q                Decrease verbosity\n"
               "   --errcode N       When triggered, return N as error code\n"
               "   --id ID           Trigger only for the ID specified\n"
               "   --interval N      Trigger only after every N-th call\n"
               "   --repeat N        Turn off after N hits.  0 means never\n"
               "   --skip N          Skip the first N encounters\n"
               ,p->out
            );
          }
          break;
        }
      }
    }
    if( isOk==0 && iCtrl>=0 ){
      fprintf(p->out,
          "Usage: .testctrl %s %s\n", zCmd,aCtrl[iCtrl].zUsage);
      rc = 1;
    }else if( isOk==1 ){
      fprintf(p->out, "%d\n", rc2);
    }else if( isOk==2 ){
      fprintf(p->out, "0x%08x\n", rc2);
    }
  }else


  if( c=='t' && n>4 && cli_strncmp(azArg[0], "timeout", n)==0 ){
    open_db(p, 0);
    sqlite3_busy_timeout(p->db, nArg>=2 ? (int)integerValue(azArg[1]) : 0);
  }else

  if( c=='t' && n>=5 && cli_strncmp(azArg[0], "timer", n)==0 ){
    if( nArg==2 ){
      enableTimer = booleanValue(azArg[1]);
      if( enableTimer && !1 ){
        fputs("Error: timer not available on this system.\n",__stderrp);
        enableTimer = 0;
      }
    }else{
      fputs("Usage: .timer on|off\n",__stderrp);
      rc = 1;
    }
  }else


  if( c=='t' && cli_strncmp(azArg[0], "trace", n)==0 ){
    int mType = 0;
    int jj;
    open_db(p, 0);
    for(jj=1; jj<nArg; jj++){
      const char *z = azArg[jj];
      if( z[0]=='-' ){
        if( optionMatch(z, "expanded") ){
          p->eTraceType = 1;
        }





        else if( optionMatch(z, "plain") ){
          p->eTraceType = 0;
        }
        else if( optionMatch(z, "profile") ){
          mType |= 0x02;
        }
        else if( optionMatch(z, "row") ){
          mType |= 0x04;
        }
        else if( optionMatch(z, "stmt") ){
          mType |= 0x01;
        }
        else if( optionMatch(z, "close") ){
          mType |= 0x08;
        }
        else {
          fprintf(__stderrp,"Unknown option \"%s\" on \".trace\"\n", z);
          rc = 1;
          goto meta_command_exit;
        }
      }else{
        output_file_close(p->traceOut);
        p->traceOut = output_file_open(z);
      }
    }
    if( p->traceOut==0 ){
      sqlite3_trace_v2(p->db, 0, 0, 0);
    }else{
      if( mType==0 ) mType = 0x01;
      sqlite3_trace_v2(p->db, mType, sql_trace_callback, p);
    }
  }else
  if( c=='v' && cli_strncmp(azArg[0], "version", n)==0 ){
    char *zPtrSz = sizeof(void*)==8 ? "64-bit" : "32-bit";
    fprintf(p->out, "SQLite %s %s\n" ,
          sqlite3_libversion(), sqlite3_sourceid());










    fprintf(p->out, "gcc-" "13.3.0" " (%s)\n", zPtrSz);

  }else

  if( c=='v' && cli_strncmp(azArg[0], "vfsinfo", n)==0 ){
    const char *zDbName = nArg==2 ? azArg[1] : "main";
    sqlite3_vfs *pVfs = 0;
    if( p->db ){
      sqlite3_file_control(p->db, zDbName, 27, &pVfs);
      if( pVfs ){
        fprintf(p->out, "vfs.zName      = \"%s\"\n", pVfs->zName);
        fprintf(p->out, "vfs.iVersion   = %d\n", pVfs->iVersion);
        fprintf(p->out, "vfs.szOsFile   = %d\n", pVfs->szOsFile);
        fprintf(p->out, "vfs.mxPathname = %d\n", pVfs->mxPathname);
      }
    }
  }else

  if( c=='v' && cli_strncmp(azArg[0], "vfslist", n)==0 ){
    sqlite3_vfs *pVfs;
    sqlite3_vfs *pCurrent = 0;
    if( p->db ){
      sqlite3_file_control(p->db, "main", 27, &pCurrent);
    }
    for(pVfs=sqlite3_vfs_find(0); pVfs; pVfs=pVfs->pNext){
      fprintf(p->out, "vfs.zName      = \"%s\"%s\n", pVfs->zName,
            pVfs==pCurrent ? "  <--- CURRENT" : "");
      fprintf(p->out, "vfs.iVersion   = %d\n", pVfs->iVersion);
      fprintf(p->out, "vfs.szOsFile   = %d\n", pVfs->szOsFile);
      fprintf(p->out, "vfs.mxPathname = %d\n", pVfs->mxPathname);
      if( pVfs->pNext ){
        fputs("-----------------------------------\n", p->out);
      }
    }
  }else

  if( c=='v' && cli_strncmp(azArg[0], "vfsname", n)==0 ){
    const char *zDbName = nArg==2 ? azArg[1] : "main";
    char *zVfsName = 0;
    if( p->db ){
      sqlite3_file_control(p->db, zDbName, 12, &zVfsName);
      if( zVfsName ){
        fprintf(p->out, "%s\n", zVfsName);
        sqlite3_free(zVfsName);
      }
    }
  }else

  if( c=='w' && cli_strncmp(azArg[0], "wheretrace", n)==0 ){
    unsigned int x = nArg>=2? (unsigned int)integerValue(azArg[1]) : 0xffffffff;
    sqlite3_test_control(31, 3, &x);
  }else

  if( c=='w' && cli_strncmp(azArg[0], "width", n)==0 ){
    int j;
    ((void)sizeof(((_Bool(*)(_Bool))0)(nArg<=(int)(sizeof(azArg)/sizeof(azArg[0])))), (nArg<=(int)(sizeof(azArg)/sizeof(azArg[0]))) ? (void)0 : __assert(__func__, "/mnt/c/ParanoidBSD/dreamy-mahavira-7e0e79/hbsd/src/contrib/sqlite3/shell.c", 32421, "nArg<=ArraySize(azArg)"));
    p->nWidth = nArg-1;
    p->colWidth = realloc(p->colWidth, (p->nWidth+1)*sizeof(int)*2);
    if( p->colWidth==0 && p->nWidth>0 ) shell_out_of_memory();
    if( p->nWidth ) p->actualWidth = &p->colWidth[p->nWidth];
    for(j=1; j<nArg; j++){
      p->colWidth[j-1] = (int)integerValue(azArg[j]);
    }
  }else

  {
    fprintf(__stderrp,"Error: unknown command or invalid arguments: "
          " \"%s\". Enter \".help\" for help\n", azArg[0]);
    rc = 1;
  }

meta_command_exit:
  if( p->outCount ){
    p->outCount--;
    if( p->outCount==0 ) output_reset(p);
  }
  p->bSafeMode = p->bSafeModePersist;
  return rc;
}
static int process_input(ShellState *p);
