typedef unsigned short __uint16_t;
typedef unsigned int __uint32_t;
typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef unsigned char u_char;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __size_t size_t;
struct malloc_type;
struct malloc_type;
struct malloc_type_stats {
 uint64_t mts_memalloced;
 uint64_t mts_memfreed;
 uint64_t mts_numallocs;
 uint64_t mts_numfrees;
 uint64_t mts_size;
 uint64_t _mts_reserved1;
 uint64_t _mts_reserved2;
 uint64_t _mts_reserved3;
};
struct malloc_type_internal {
 uint32_t mti_probes[2];

 u_char mti_zone;
 struct malloc_type_stats *mti_stats;
 u_long mti_spare[8];
};
struct malloc_type {
 struct malloc_type *ks_next;
 u_long ks_version;
 const char *ks_shortdesc;
 struct malloc_type_internal ks_mti;
};
void free(void *addr, struct malloc_type *type);
void *malloc(size_t size, struct malloc_type *type, int flags) 
      ;
typedef struct MD4Context {
  u_int32_t state[4];
  u_int32_t count[2];
  unsigned char buffer[64];
} MD4_CTX;
void MD4Init(MD4_CTX *);
void MD4Update(MD4_CTX *, const unsigned char *, unsigned int);
void MD4Final(unsigned char [static (16)], MD4_CTX *);
struct malloc_type;
extern struct malloc_type M_SMBTEMP[1];
void smb_strtouni(u_int16_t *dst, const char *src);
int smb_ntencrypt(const u_char *apwd, u_char *C8, u_char *RN);
static void
smb_E(const u_char *key, u_char *data, u_char *dest)
;
/*@ requires apwd != ((void *)0) && C8 != ((void *)0) && RN != ((void *)0); ensures \result == 0; */

int
smb_ntencrypt(const u_char *apwd, u_char *C8, u_char *RN)
{
 u_char S21[21];
 u_int16_t *unipwd;
 MD4_CTX *ctxp;
 u_int len;

 len = __builtin_strlen((apwd));
 unipwd = ({ void *_malloc_item; size_t _size = ((len + 1) * sizeof(u_int16_t)); if (__builtin_constant_p((len + 1) * sizeof(u_int16_t)) && __builtin_constant_p(0x0002) && ((0x0002) & 0x0100) != 0) { _malloc_item = malloc(_size, M_SMBTEMP, (0x0002) &~ 0x0100); if (((0x0002) & 0x0002) != 0 || __builtin_expect((_malloc_item != ((void *)0)), 1)) __builtin_memset((_malloc_item), (0), (_size)); } else { _malloc_item = malloc(_size, M_SMBTEMP, 0x0002); } _malloc_item; });



 smb_strtouni(unipwd, apwd);
 ctxp = ({ void *_malloc_item; size_t _size = (sizeof(MD4_CTX)); if (__builtin_constant_p(sizeof(MD4_CTX)) && __builtin_constant_p(0x0002) && ((0x0002) & 0x0100) != 0) { _malloc_item = malloc(_size, M_SMBTEMP, (0x0002) &~ 0x0100); if (((0x0002) & 0x0002) != 0 || __builtin_expect((_malloc_item != ((void *)0)), 1)) __builtin_memset((_malloc_item), (0), (_size)); } else { _malloc_item = malloc(_size, M_SMBTEMP, 0x0002); } _malloc_item; });
 MD4Init(ctxp);
 MD4Update(ctxp, (u_char*)unipwd, len * sizeof(u_int16_t));
 free(unipwd, M_SMBTEMP);
 __builtin_memset((S21), 0, (21));
 MD4Final(S21, ctxp);
 free(ctxp, M_SMBTEMP);

 smb_E(S21, C8, RN);
 smb_E(S21 + 7, C8, RN + 8);
 smb_E(S21 + 14, C8, RN + 16);
 return 0;
}
