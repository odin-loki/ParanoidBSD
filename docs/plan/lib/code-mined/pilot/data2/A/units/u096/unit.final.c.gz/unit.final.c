int yylex(void);
extern int yylex(void);
/*@ requires \true; ensures \result == -1; */

int
yylex(void)
{
    return -1;
}
