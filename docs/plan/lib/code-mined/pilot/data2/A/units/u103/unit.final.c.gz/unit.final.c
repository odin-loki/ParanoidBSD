typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u8 u8;
typedef __u16 u16;
typedef __u32 u32;
static inline    void put_unaligned_le16(u16 val, void *p)
;
/*@ requires offset + 4 < 1468; ensures \result == 5 || \result == 0; */

static int wilc_wlan_cfg_set_byte(u8 *frame, u32 offset, u16 id, u8 val8)
{
 if ((offset + 4) >= 1468)
  return 0;

 put_unaligned_le16(id, &frame[offset]);
 put_unaligned_le16(1, &frame[offset + 2]);
 frame[offset + 4] = val8;
 return 5;
}
