enum {
 false = 0,
 true = 1
};
enum v4l2_mpeg_video_hevc_level {
 V4L2_MPEG_VIDEO_HEVC_LEVEL_1 = 0,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_2 = 1,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_2_1 = 2,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_3 = 3,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_3_1 = 4,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_4 = 5,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_4_1 = 6,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_5 = 7,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_5_1 = 8,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_5_2 = 9,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_6 = 10,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_6_1 = 11,
 V4L2_MPEG_VIDEO_HEVC_LEVEL_6_2 = 12,
};
/*@ requires true; ensures (\result >= 30 && \result <= 1860) || \result == -22; */

static inline    int nal_hevc_level(enum v4l2_mpeg_video_hevc_level level)
{





 int factor = 30 / 10;

 switch (level) {
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_1:
  return factor * 10;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_2:
  return factor * 20;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_2_1:
  return factor * 21;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_3:
  return factor * 30;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_3_1:
  return factor * 31;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_4:
  return factor * 40;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_4_1:
  return factor * 41;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_5:
  return factor * 50;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_5_1:
  return factor * 51;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_5_2:
  return factor * 52;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_6:
  return factor * 60;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_6_1:
  return factor * 61;
 case V4L2_MPEG_VIDEO_HEVC_LEVEL_6_2:
  return factor * 62;
 default:
  return -22;
 }
}
