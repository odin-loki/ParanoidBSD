typedef unsigned long __uint64_t;
typedef __uint64_t __size_t;
typedef __size_t size_t;
int (snprintf)(char * restrict, size_t, const char * restrict,
     ...) ;
void free(void *);
void *malloc(size_t)   ;
size_t strlen(const char *) ;
struct vector_str {

 size_t size;

 size_t capacity;

 char **container;
};
enum type_qualifier {
 TYPE_PTR, TYPE_REF, TYPE_CMX, TYPE_IMG, TYPE_EXT, TYPE_RST, TYPE_VAT,
 TYPE_CST, TYPE_VEC, TYPE_RREF
};
struct vector_type_qualifier {
 size_t size, capacity;
 enum type_qualifier *q_container;
 struct vector_str ext_name;
};
enum read_cmd {
 READ_FAIL, READ_NEST, READ_TMPL, READ_EXPR, READ_EXPL, READ_LOCAL,
 READ_TYPE, READ_FUNC, READ_PTRMEM
};
struct read_cmd_item {
 enum read_cmd cmd;
 void *data;
};
struct vector_read_cmd {
 size_t size, capacity;
 struct read_cmd_item *r_container;
};
enum push_qualifier {
 PUSH_ALL_QUALIFIER,
 PUSH_CV_QUALIFIER,
 PUSH_NON_CV_QUALIFIER,
};
struct cpp_demangle_data {
 struct vector_str output;
 struct vector_str subst;
 struct vector_str tmpl;
 struct vector_str class_type;
 struct vector_str *cur_output;
 struct vector_read_cmd cmd;
 _Bool mem_rst;
 _Bool mem_vat;
 _Bool mem_cst;
 _Bool mem_ref;
 _Bool mem_rref;
 _Bool is_tmpl;
 _Bool is_functype;
 _Bool ref_qualifier;
 enum type_qualifier ref_qualifier_type;
 enum push_qualifier push_qualifier;
 int func_type;
 const char *cur;
 const char *last_sname;
};
static void
vector_str_dest(struct vector_str *v)
;
static _Bool
vector_str_init(struct vector_str *v)
;
static _Bool
vector_str_push(struct vector_str *v, const char *str, size_t len)
;
static int cpp_demangle_push_str(struct cpp_demangle_data *, const char *,
      size_t);
static int cpp_demangle_push_subst_v(struct cpp_demangle_data *,
      struct vector_str *);
static int cpp_demangle_push_type_qualifier(struct cpp_demangle_data *,
      struct vector_type_qualifier *, const char *);
static int
cpp_demangle_push_str(struct cpp_demangle_data *ddata, const char *str,
    size_t len)
;
static int
cpp_demangle_push_subst_v(struct cpp_demangle_data *ddata, struct vector_str *v)
;
/*@ requires ddata != ((void *)0) && v != ((void *)0); ensures \result == 1 || \result == 0; */

static int
cpp_demangle_push_type_qualifier(struct cpp_demangle_data *ddata,
    struct vector_type_qualifier *v, const char *type_str)
{
 struct vector_str subst_v;
 enum type_qualifier t;
 size_t idx, e_idx, e_len;
 char *buf;
 int rtn;
 _Bool cv;

 if (ddata == ((void *)0) || v == ((void *)0))
  return (0);

 if ((idx = v->size) == 0)
  return (1);

 rtn = 0;
 if (type_str != ((void *)0)) {
  if (!vector_str_init(&subst_v))
   return (0);
  if (!vector_str_push((&subst_v), (type_str), strlen((type_str))))
   goto clean;
 }

 cv = 1;
 e_idx = 0;
 while (idx > 0) {
  switch (v->q_container[idx - 1]) {
  case TYPE_PTR:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (!cpp_demangle_push_str((ddata), ("*"), strlen(("*"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), ("*"), strlen(("*"))))
     goto clean;
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_REF:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (!cpp_demangle_push_str((ddata), ("&"), strlen(("&"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), ("&"), strlen(("&"))))
     goto clean;
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_RREF:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (!cpp_demangle_push_str((ddata), ("&&"), strlen(("&&"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), ("&&"), strlen(("&&"))))
     goto clean;
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_CMX:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (!cpp_demangle_push_str((ddata), (" complex"), strlen((" complex"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (" complex"), strlen((" complex"))))
     goto clean;
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_IMG:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (!cpp_demangle_push_str((ddata), (" imaginary"), strlen((" imaginary"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (" imaginary"), strlen((" imaginary"))))
     goto clean;
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_EXT:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (v->ext_name.size == 0 ||
       e_idx > v->ext_name.size - 1)
    goto clean;
   if ((e_len = strlen(v->ext_name.container[e_idx])) ==
       0)
    goto clean;
   if ((buf = malloc(e_len + 2)) == ((void *)0))
    goto clean;
   snprintf(buf, e_len + 2, " %s",
       v->ext_name.container[e_idx]);

   if (!cpp_demangle_push_str((ddata), (buf), strlen((buf)))) {
    free(buf);
    goto clean;
   }

   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (buf), strlen((buf)))) {
     free(buf);
     goto clean;
    }
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v)) {
     free(buf);
     goto clean;
    }
   }
   free(buf);
   ++e_idx;
   break;

  case TYPE_RST:
   if (ddata->push_qualifier == PUSH_NON_CV_QUALIFIER &&
       cv)
    break;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER && !cv)
    break;
   if (!cpp_demangle_push_str((ddata), (" restrict"), strlen((" restrict"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (" restrict"), strlen((" restrict"))))
     goto clean;
    if (idx - 1 > 0) {
     t = v->q_container[idx - 2];
     if (t == TYPE_RST || t == TYPE_VAT ||
         t == TYPE_CST)
      break;
    }
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_VAT:
   if (ddata->push_qualifier == PUSH_NON_CV_QUALIFIER &&
       cv)
    break;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER && !cv)
    break;
   if (!cpp_demangle_push_str((ddata), (" volatile"), strlen((" volatile"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (" volatile"), strlen((" volatile"))))
     goto clean;
    if (idx - 1 > 0) {
     t = v->q_container[idx - 2];
     if (t == TYPE_RST || t == TYPE_VAT ||
         t == TYPE_CST)
      break;
    }
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_CST:
   if (ddata->push_qualifier == PUSH_NON_CV_QUALIFIER &&
       cv)
    break;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER && !cv)
    break;
   if (!cpp_demangle_push_str((ddata), (" const"), strlen((" const"))))
    goto clean;
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (" const"), strlen((" const"))))
     goto clean;
    if (idx - 1 > 0) {
     t = v->q_container[idx - 2];
     if (t == TYPE_RST || t == TYPE_VAT ||
         t == TYPE_CST)
      break;
    }
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v))
     goto clean;
   }
   break;

  case TYPE_VEC:
   cv = 0;
   if (ddata->push_qualifier == PUSH_CV_QUALIFIER)
    break;
   if (v->ext_name.size == 0 ||
       e_idx > v->ext_name.size - 1)
    goto clean;
   if ((e_len = strlen(v->ext_name.container[e_idx])) ==
       0)
    goto clean;
   if ((buf = malloc(e_len + 12)) == ((void *)0))
    goto clean;
   snprintf(buf, e_len + 12, " __vector(%s)",
       v->ext_name.container[e_idx]);
   if (!cpp_demangle_push_str((ddata), (buf), strlen((buf)))) {
    free(buf);
    goto clean;
   }
   if (type_str != ((void *)0)) {
    if (!vector_str_push((&subst_v), (buf), strlen((buf)))) {
     free(buf);
     goto clean;
    }
    if (!cpp_demangle_push_subst_v(ddata,
        &subst_v)) {
     free(buf);
     goto clean;
    }
   }
   free(buf);
   ++e_idx;
   break;
  }
  --idx;
 }

 rtn = 1;
clean:
 if (type_str != ((void *)0))
  vector_str_dest(&subst_v);

 return (rtn);
}
