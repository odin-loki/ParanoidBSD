enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
enum packet_id {
 PACKET_WREG_32 = 0x1,
 PACKET_WREG_BULK = 0x2,
 PACKET_MSG_LONG = 0x3,
 PACKET_MSG_SHORT = 0x4,
 PACKET_CP_DMA = 0x5,
 PACKET_MSG_PROT = 0x7,
 PACKET_FENCE = 0x8,
 PACKET_LIN_DMA = 0x9,
 PACKET_NOP = 0xA,
 PACKET_STOP = 0xB,
 MAX_PACKET_ID = (0x1F00000000000000ull >>
    56) + 1
};
/*@ requires \true; ensures \result == (id == PACKET_WREG_32 || id == PACKET_WREG_BULK || id == PACKET_MSG_LONG || id == PACKET_MSG_SHORT || id == PACKET_CP_DMA || id == PACKET_MSG_PROT || id == PACKET_FENCE || id == PACKET_LIN_DMA || id == PACKET_NOP || id == PACKET_STOP); */

static inline    bool validate_packet_id(enum packet_id id)
{
 switch (id) {
 case PACKET_WREG_32:
 case PACKET_WREG_BULK:
 case PACKET_MSG_LONG:
 case PACKET_MSG_SHORT:
 case PACKET_CP_DMA:
 case PACKET_MSG_PROT:
 case PACKET_FENCE:
 case PACKET_LIN_DMA:
 case PACKET_NOP:
 case PACKET_STOP:
  return true;
 default:
  return false;
 }
}
