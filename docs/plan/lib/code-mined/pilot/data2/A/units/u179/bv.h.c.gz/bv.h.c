typedef unsigned char __u8;
typedef __signed__ short __s16;
typedef unsigned short __u16;
typedef __signed__ int __s32;
typedef unsigned int __u32;
__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
typedef __u8 u8;
typedef __s16 s16;
typedef __u16 u16;
typedef __s32 s32;
typedef __u32 u32;
typedef __s64 s64;
typedef __u64 u64;
enum {
 false = 0,
 true = 1
};
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef int __kernel_pid_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef unsigned __poll_t;
typedef u32 __kernel_dev_t;
typedef __kernel_dev_t dev_t;
typedef unsigned short umode_t;
typedef __kernel_pid_t pid_t;
typedef __kernel_clockid_t clockid_t;
typedef _Bool bool;
typedef __kernel_uid32_t uid_t;
typedef __kernel_gid32_t gid_t;
typedef __kernel_loff_t loff_t;
typedef __kernel_size_t size_t;
typedef __kernel_ssize_t ssize_t;
typedef __kernel_ptrdiff_t ptrdiff_t;
typedef s32 int32_t;
typedef u32 uint32_t;
typedef s64 ktime_t;
typedef u64 sector_t;
typedef u64 blkcnt_t;
typedef unsigned int gfp_t;
typedef unsigned int fmode_t;
typedef struct {
 int counter;
} atomic_t;
typedef struct {
 s64 counter;
} atomic64_t;
typedef struct {
 atomic_t refcnt;
} rcuref_t;
struct list_head {
 struct list_head *next, *prev;
};
struct hlist_head {
 struct hlist_node *first;
};
struct hlist_node {
 struct hlist_node *next, **pprev;
};
struct callback_head {
 struct callback_head *next;
 void (*func)(struct callback_head *head);
} ;
struct rcuwait {
 struct task_struct *task;
};
struct file_system_type;
typedef struct qspinlock {
 union {
  atomic_t val;







  struct {
   u8 locked;
   u8 pending;
  };
  struct {
   u16 locked_pending;
   u16 tail;
  };
 };
} arch_spinlock_t;
typedef struct qrwlock {
 union {
  atomic_t cnts;
  struct {

   u8 wlocked;
   u8 __lstate[3];




  };
 };
 arch_spinlock_t wait_lock;
} arch_rwlock_t;
struct lockdep_subclass_key {
 char __one_byte;
} __attribute__((__packed__));
struct lock_class_key {
 union {
  struct hlist_node hash_entry;
  struct lockdep_subclass_key subkeys[8UL];
 };
};
struct lock_trace;
struct lockdep_map;
typedef int (*lock_cmp_fn)(const struct lockdep_map *a,
      const struct lockdep_map *b);
typedef void (*lock_print_fn)(const struct lockdep_map *map);
struct lock_class {



 struct hlist_node hash_entry;






 struct list_head lock_entry;






 struct list_head locks_after, locks_before;

 const struct lockdep_subclass_key *key;
 lock_cmp_fn cmp_fn;
 lock_print_fn print_fn;

 unsigned int subclass;
 unsigned int dep_gen_id;




 unsigned long usage_mask;
 const struct lock_trace *usage_traces[(2*4 + 2)];

 const char *name;




 int name_version;

 u8 wait_type_inner;
 u8 wait_type_outer;
 u8 lock_type;



 unsigned long contention_point[4];
 unsigned long contending_point[4];

} ;
struct lockdep_map {
 struct lock_class_key *key;
 struct lock_class *class_cache[2];
 const char *name;
 u8 wait_type_outer;
 u8 wait_type_inner;
 u8 lock_type;


 int cpu;
 unsigned long ip;

};
struct held_lock {
 u64 prev_chain_key;
 unsigned long acquire_ip;
 struct lockdep_map *instance;
 struct lockdep_map *nest_lock;

 u64 waittime_stamp;
 u64 holdtime_stamp;






 unsigned int class_idx:13;
 unsigned int irq_context:2;
 unsigned int trylock:1;

 unsigned int read:2;
 unsigned int check:1;
 unsigned int hardirqs_off:1;
 unsigned int sync:1;
 unsigned int references:11;
 unsigned int pin_count;
};
typedef struct raw_spinlock {
 arch_spinlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} raw_spinlock_t;
struct ratelimit_state {
 raw_spinlock_t lock;

 int interval;
 int burst;
 atomic_t rs_n_left;
 atomic_t missed;
 unsigned int flags;
 unsigned long begin;
};
struct ctl_table;
struct module;
struct module;
struct inode;
struct module;
struct task_struct;
struct irqtrace_events {
 unsigned int irq_events;
 unsigned long hardirq_enable_ip;
 unsigned long hardirq_disable_ip;
 unsigned int hardirq_enable_event;
 unsigned int hardirq_disable_event;
 unsigned long softirq_disable_ip;
 unsigned long softirq_enable_ip;
 unsigned int softirq_disable_event;
 unsigned int softirq_enable_event;
};
struct desc_struct {
 u16 limit0;
 u16 base0;
 u16 base1: 8, type: 4, s: 1, dpl: 2, p: 1;
 u16 limit1: 4, avl: 1, l: 1, d: 1, g: 1, base2: 8;
} __attribute__((packed));
typedef unsigned long pteval_t;
typedef unsigned long pmdval_t;
typedef unsigned long pudval_t;
typedef unsigned long pgdval_t;
typedef unsigned long pgprotval_t;
typedef struct { pteval_t pte; } pte_t;
typedef struct { pmdval_t pmd; } pmd_t;
typedef struct pgprot { pgprotval_t pgprot; } pgprot_t;
typedef struct { pgdval_t pgd; } pgd_t;
typedef struct { pudval_t pud; } pud_t;
typedef struct page *pgtable_t;
struct file;
struct page;
struct thread_struct;
struct mm_struct;
struct desc_struct;
struct task_struct;
struct cpumask;
struct vm_area_struct;
struct qspinlock;
struct mm_struct;
static inline     
int __ilog2_u32(u32 n)
;
static inline     
int __ilog2_u64(u64 n)
;
static inline    
int __bits_per(unsigned long n)
;
struct completion;
struct user;
typedef struct cpumask { unsigned long bits[(((8192) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } cpumask_t;
typedef atomic64_t atomic_long_t;
typedef struct { unsigned long bits[((((1 << 10)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))]; } nodemask_t;
struct task_struct;
struct __kernel_timespec;
struct old_timespec32;
struct pollfd;
enum timespec_type {
 TT_NONE = 0,
 TT_NATIVE = 1,
 TT_COMPAT = 2,
};
struct restart_block {
 unsigned long arch_data;
 long (*fn)(struct restart_block *);
 union {

  struct {
   u32 *uaddr;
   u32 val;
   u32 flags;
   u32 bitset;
   u64 time;
   u32 *uaddr2;
  } futex;

  struct {
   clockid_t clockid;
   enum timespec_type type;
   union {
    struct __kernel_timespec *rmtp;
    struct old_timespec32 *compat_rmtp;
   };
   u64 expires;
  } nanosleep;

  struct {
   struct pollfd *ufds;
   int nfds;
   int has_timeout;
   unsigned long tv_sec;
   unsigned long tv_nsec;
  } poll;
 };
};
struct task_struct;
struct page;
struct range {
 u64 start;
 u64 end;
};
struct task_struct;
struct task_struct;
struct mm_struct;
struct io_bitmap;
struct task_struct;
struct task_struct;
struct task_struct;
struct thread_shstk {
 u64 base;
 u64 size;
};
struct perf_event;
struct thread_struct {

 struct desc_struct tls_array[3];



 unsigned long sp;



 unsigned short es;
 unsigned short ds;
 unsigned short fsindex;
 unsigned short gsindex;



 unsigned long fsbase;
 unsigned long gsbase;
 struct perf_event *ptrace_bps[4];

 unsigned long virtual_dr6;

 unsigned long ptrace_dr7;

 unsigned long cr2;
 unsigned long trap_nr;
 unsigned long error_code;





 struct io_bitmap *io_bitmap;






 unsigned long iopl_emul;

 unsigned int iopl_warn:1;
 u32 pkru;


 unsigned long features;
 unsigned long features_locked;

 struct thread_shstk shstk;

};
struct thread_info {
 unsigned long flags;
 unsigned long syscall_work;
 u32 status;

 u32 cpu;

};
struct llist_head {
 struct llist_node *first;
};
struct llist_node {
 struct llist_node *next;
};
struct __call_single_node {
 struct llist_node llist;
 union {
  unsigned int u_flags;
  atomic_t a_flags;
 };

 u16 src, dst;

};
typedef void (*smp_call_func_t)(void *info);
struct __call_single_data {
 struct __call_single_node node;
 smp_call_func_t func;
 void *info;
};
typedef struct __call_single_data call_single_data_t
 ;
struct task_struct;
struct task_struct;
struct task_struct;
struct task_struct;
extern  __typeof__(unsigned int) lockdep_recursion;
typedef struct spinlock {
 union {
  struct raw_spinlock rlock;


  struct {
   u8 __padding[(__builtin_offsetof(struct raw_spinlock, dep_map))];
   struct lockdep_map dep_map;
  };

 };
} spinlock_t;
typedef struct {
 arch_rwlock_t raw_lock;

 unsigned int magic, owner_cpu;
 void *owner;


 struct lockdep_map dep_map;

} rwlock_t;
struct wait_queue_head {
 spinlock_t lock;
 struct list_head head;
};
typedef struct wait_queue_head wait_queue_head_t;
struct task_struct;
enum pid_type {
 PIDTYPE_PID,
 PIDTYPE_TGID,
 PIDTYPE_PGID,
 PIDTYPE_SID,
 PIDTYPE_MAX,
};
struct pid_namespace;
struct sem_undo_list;
struct sysv_sem {

 struct sem_undo_list *undo_list;

};
struct file;
struct task_struct;
struct sysv_shm {
 struct list_head shm_clist;
};
struct optimistic_spin_queue {




 atomic_t tail;
};
struct mutex {
 atomic_long_t owner;
 raw_spinlock_t wait_lock;

 struct optimistic_spin_queue osq;

 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct plist_node {
 int prio;
 struct list_head prio_list;
 struct list_head node_list;
};
struct rb_node {
 unsigned long __rb_parent_color;
 struct rb_node *rb_right;
 struct rb_node *rb_left;
} ;
struct rb_root {
 struct rb_node *rb_node;
};
struct rb_root_cached {
 struct rb_root rb_root;
 struct rb_node *rb_leftmost;
};
struct timerqueue_node {
 struct rb_node node;
 ktime_t expires;
};
struct timerqueue_head {
 struct rb_root_cached rb_root;
};
struct hrtimer_clock_base;
enum hrtimer_restart {
 HRTIMER_NORESTART,
 HRTIMER_RESTART,
};
struct hrtimer {
 struct timerqueue_node node;
 ktime_t _softexpires;
 enum hrtimer_restart (* function)(struct hrtimer *);
 struct hrtimer_clock_base *base;
 u8 state;
 u8 is_rel;
 u8 is_soft;
 u8 is_hard;
};
struct timer_list {




 struct hlist_node entry;
 unsigned long expires;
 void (*function)(struct timer_list *);
 u32 flags;


 struct lockdep_map lockdep_map;

};
struct seccomp_filter;
struct seccomp {
 int mode;
 atomic_t filter_count;
 struct seccomp_filter *filter;
};
typedef struct refcount_struct {
 atomic_t refs;
} refcount_t;
struct __kernel_timespec {
 __kernel_time64_t tv_sec;
 long long tv_nsec;
};
struct rlimit {
 __kernel_ulong_t rlim_cur;
 __kernel_ulong_t rlim_max;
};
struct task_struct;
struct task_struct;
struct latency_record {
 unsigned long backtrace[12];
 unsigned int count;
 unsigned long time;
 unsigned long max;
};
typedef struct {
 unsigned long sig[(64 / 64)];
} sigset_t;
typedef void __signalfn_t(int);
typedef __signalfn_t *__sighandler_t;
typedef void __restorefn_t(void);
typedef __restorefn_t *__sigrestore_t;
typedef union sigval {
 int sival_int;
 void *sival_ptr;
} sigval_t;
union __sifields {

 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
 } _kill;


 struct {
  __kernel_timer_t _tid;
  int _overrun;
  sigval_t _sigval;
  int _sys_private;
 } _timer;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  sigval_t _sigval;
 } _rt;


 struct {
  __kernel_pid_t _pid;
  __kernel_uid32_t _uid;
  int _status;
  __kernel_clock_t _utime;
  __kernel_clock_t _stime;
 } _sigchld;


 struct {
  void *_addr;


  union {

   int _trapno;




   short _addr_lsb;

   struct {
    char _dummy_bnd[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    void *_lower;
    void *_upper;
   } _addr_bnd;

   struct {
    char _dummy_pkey[(__alignof__(void *) < sizeof(short) ? sizeof(short) : __alignof__(void *))];
    __u32 _pkey;
   } _addr_pkey;

   struct {
    unsigned long _data;
    __u32 _type;
    __u32 _flags;
   } _perf;
  };
 } _sigfault;


 struct {
  long _band;
  int _fd;
 } _sigpoll;


 struct {
  void *_call_addr;
  int _syscall;
  unsigned int _arch;
 } _sigsys;
};
typedef struct kernel_siginfo {
 struct { int si_signo; int si_errno; int si_code; union __sifields _sifields; };
} kernel_siginfo_t;
struct ucounts;
struct sigpending {
 struct list_head list;
 sigset_t signal;
};
struct sigaction {

 __sighandler_t sa_handler;
 unsigned long sa_flags;





 __sigrestore_t sa_restorer;

 sigset_t sa_mask;
};
struct k_sigaction {
 struct sigaction sa;



};
struct syscall_user_dispatch {
 char *selector;
 unsigned long offset;
 unsigned long len;
 bool on_dispatch;
};
struct arch_tlbflush_unmap_batch {




 struct cpumask cpumask;




 bool unmapped_pages;
};
enum {
 MM_FILEPAGES,
 MM_ANONPAGES,
 MM_SWAPENTS,
 MM_SHMEMPAGES,
 NR_MM_COUNTERS
};
struct page;
struct page_frag {
 struct page *page;

 __u32 offset;
 __u32 size;




};
struct tlbflush_unmap_batch {
 struct arch_tlbflush_unmap_batch arch;


 bool flush_required;






 bool writable;

};
struct task_io_accounting {


 u64 rchar;

 u64 wchar;

 u64 syscr;

 u64 syscw;







 u64 read_bytes;





 u64 write_bytes;
 u64 cancelled_write_bytes;

};
struct posix_cputimer_base {
 u64 nextevt;
 struct timerqueue_head tqhead;
};
struct posix_cputimers {
 struct posix_cputimer_base bases[3];
 unsigned int timers_active;
 unsigned int expiry_active;
};
struct posix_cputimers_work {
 struct callback_head work;
 struct mutex mutex;
 unsigned int scheduled;
};
struct rseq_cs {

 __u32 version;

 __u32 flags;
 __u64 start_ip;

 __u64 post_commit_offset;
 __u64 abort_ip;
} ;
struct rseq {
 __u32 cpu_id_start;
 __u32 cpu_id;
 __u64 rseq_cs;
 __u32 flags;







 __u32 node_id;
 __u32 mm_cid;




 char end[1];
} ;
typedef struct seqcount {
 unsigned sequence;

 struct lockdep_map dep_map;

} seqcount_t;
typedef struct seqcount_raw_spinlock { seqcount_t seqcount; raw_spinlock_t *lock; } seqcount_raw_spinlock_t;
typedef struct seqcount_spinlock { seqcount_t seqcount; spinlock_t *lock; } seqcount_spinlock_t;
typedef struct {




 seqcount_spinlock_t seqcount;
 spinlock_t lock;
} seqlock_t;
struct da_monitor {
 bool monitoring;
 unsigned int curr_state;
};
struct ltl_monitor {
 unsigned long states[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
 unsigned long unknown_atoms[(((32) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
};
union rv_task_monitor {
 struct da_monitor da_mon;
 struct ltl_monitor ltl_mon;
};
typedef struct {
 uid_t val;
} kuid_t;
typedef struct {
 gid_t val;
} kgid_t;
struct unwind_cache {
 unsigned long unwind_completed;
 unsigned int nr_entries;
 unsigned long entries[1];
};
union unwind_task_id {
 struct {
  u32 cpu;
  u32 cnt;
 };
 u64 id;
};
struct unwind_task_info {
 unsigned long unwind_mask;
 struct unwind_cache *cache;
 struct callback_head work;
 union unwind_task_id id;
};
struct audit_context;
struct bio_list;
struct blk_plug;
struct bpf_local_storage;
struct bpf_run_ctx;
struct bpf_net_context;
struct capture_control;
struct cfs_rq;
struct fs_struct;
struct futex_pi_state;
struct io_context;
struct io_uring_task;
struct mempolicy;
struct nameidata;
struct nsproxy;
struct perf_event_context;
struct perf_ctx_data;
struct pid_namespace;
struct pipe_inode_info;
struct rcu_node;
struct reclaim_state;
struct robust_list_head;
struct rq;
struct sched_dl_entity;
struct seq_file;
struct sighand_struct;
struct signal_struct;
struct task_delay_info;
struct task_group;
struct task_struct;
struct user_event_mm;
enum {
 TASK_COMM_LEN = 16,
};
struct prev_cputime {

 u64 utime;
 u64 stime;
 raw_spinlock_t lock;

};
enum uclamp_id {
 UCLAMP_MIN = 0,
 UCLAMP_MAX,
 UCLAMP_CNT
};
struct sched_info {




 unsigned long pcount;


 unsigned long long run_delay;


 unsigned long long max_run_delay;


 unsigned long long min_run_delay;




 unsigned long long last_arrival;


 unsigned long long last_queued;


};
struct load_weight {
 unsigned long weight;
 u32 inv_weight;
};
struct sched_avg {
 u64 last_update_time;
 u64 load_sum;
 u64 runnable_sum;
 u32 util_sum;
 u32 period_contrib;
 unsigned long load_avg;
 unsigned long runnable_avg;
 unsigned long util_avg;
 unsigned int util_est;
} ;
struct sched_statistics {

 u64 wait_start;
 u64 wait_max;
 u64 wait_count;
 u64 wait_sum;
 u64 iowait_count;
 u64 iowait_sum;

 u64 sleep_start;
 u64 sleep_max;
 s64 sum_sleep_runtime;

 u64 block_start;
 u64 block_max;
 s64 sum_block_runtime;

 s64 exec_max;
 u64 slice_max;

 u64 nr_migrations_cold;
 u64 nr_failed_migrations_affine;
 u64 nr_failed_migrations_running;
 u64 nr_failed_migrations_hot;
 u64 nr_forced_migrations;

 u64 nr_wakeups;
 u64 nr_wakeups_sync;
 u64 nr_wakeups_migrate;
 u64 nr_wakeups_local;
 u64 nr_wakeups_remote;
 u64 nr_wakeups_affine;
 u64 nr_wakeups_affine_attempts;
 u64 nr_wakeups_passive;
 u64 nr_wakeups_idle;


 u64 core_forceidle_sum;


} ;
struct sched_entity {

 struct load_weight load;
 struct rb_node run_node;
 u64 deadline;
 u64 min_vruntime;
 u64 min_slice;
 u64 max_slice;

 struct list_head group_node;
 unsigned char on_rq;
 unsigned char sched_delayed;
 unsigned char rel_deadline;
 unsigned char custom_slice;


 u64 exec_start;
 u64 sum_exec_runtime;
 u64 prev_sum_exec_runtime;
 u64 vruntime;

 s64 vlag;

 u64 vprot;
 u64 slice;

 u64 nr_migrations;


 int depth;
 struct sched_entity *parent;

 struct cfs_rq *cfs_rq;

 struct cfs_rq *my_q;

 unsigned long runnable_weight;
 struct sched_avg avg;
};
struct sched_rt_entity {
 struct list_head run_list;
 unsigned long timeout;
 unsigned long watchdog_stamp;
 unsigned int time_slice;
 unsigned short on_rq;
 unsigned short on_list;

 struct sched_rt_entity *back;

 struct sched_rt_entity *parent;

 struct rt_rq *rt_rq;

 struct rt_rq *my_q;

} ;
typedef struct task_struct *(*dl_server_pick_f)(struct sched_dl_entity *);
struct sched_dl_entity {
 struct rb_node rb_node;






 u64 dl_runtime;
 u64 dl_deadline;
 u64 dl_period;
 u64 dl_bw;
 u64 dl_density;






 s64 runtime;
 u64 deadline;
 unsigned int flags;
 unsigned int dl_throttled : 1;
 unsigned int dl_yielded : 1;
 unsigned int dl_non_contending : 1;
 unsigned int dl_overrun : 1;
 unsigned int dl_server : 1;
 unsigned int dl_server_active : 1;
 unsigned int dl_defer : 1;
 unsigned int dl_defer_armed : 1;
 unsigned int dl_defer_running : 1;





 struct hrtimer dl_timer;
 struct hrtimer inactive_timer;
 struct rq *rq;
 dl_server_pick_f server_pick_task;







 struct sched_dl_entity *pi_se;

};
struct uclamp_se {
 unsigned int value : 11 ;
 unsigned int bucket_id : 3 ;
 unsigned int active : 1;
 unsigned int user_defined : 1;
};
union rcu_special {
 struct {
  u8 blocked;
  u8 need_qs;
  u8 exp_hint;
  u8 need_mb;
 } b;
 u32 s;
};
struct wake_q_node {
 struct wake_q_node *next;
};
struct kmap_ctrl {




};
struct task_struct {





 struct thread_info thread_info;

 unsigned int __state;


 unsigned int saved_state;







 void *stack;
 refcount_t usage;

 unsigned int flags;
 unsigned int ptrace;





 int on_cpu;
 struct __call_single_node wake_entry;
 unsigned int wakee_flips;
 unsigned long wakee_flip_decay_ts;
 struct task_struct *last_wakee;
 int recent_used_cpu;
 int wake_cpu;
 int on_rq;

 int prio;
 int static_prio;
 int normal_prio;
 unsigned int rt_priority;

 struct sched_entity se;
 struct sched_rt_entity rt;
 struct sched_dl_entity dl;
 struct sched_dl_entity *dl_server;



 const struct sched_class *sched_class;


 struct rb_node core_node;
 unsigned long core_cookie;
 unsigned int core_occupation;



 struct task_group *sched_task_group;

 struct callback_head sched_throttle_work;
 struct list_head throttle_node;
 bool throttled;
 struct uclamp_se uclamp_req[UCLAMP_CNT];




 struct uclamp_se uclamp[UCLAMP_CNT];


 struct sched_statistics stats;



 struct hlist_head preempt_notifiers;



 unsigned int btrace_seq;


 unsigned int policy;
 unsigned long max_allowed_capacity;
 int nr_cpus_allowed;
 const cpumask_t *cpus_ptr;
 cpumask_t *user_cpus_ptr;
 cpumask_t cpus_mask;
 void *migration_pending;
 unsigned short migration_disabled;
 unsigned short migration_flags;


 int rcu_read_lock_nesting;
 union rcu_special rcu_read_unlock_special;
 struct list_head rcu_node_entry;
 struct rcu_node *rcu_blocked_node;



 unsigned long rcu_tasks_nvcsw;
 u8 rcu_tasks_holdout;
 u8 rcu_tasks_idx;
 int rcu_tasks_idle_cpu;
 struct list_head rcu_tasks_holdout_list;
 int rcu_tasks_exit_cpu;
 struct list_head rcu_tasks_exit_list;



 int trc_reader_nesting;
 int trc_ipi_to_cpu;
 union rcu_special trc_reader_special;
 struct list_head trc_holdout_list;
 struct list_head trc_blkd_node;
 int trc_blkd_cpu;


 struct sched_info sched_info;

 struct list_head tasks;
 struct plist_node pushable_tasks;
 struct rb_node pushable_dl_tasks;

 struct mm_struct *mm;
 struct mm_struct *active_mm;
 struct address_space *faults_disabled_mapping;

 int exit_state;
 int exit_code;
 int exit_signal;

 int pdeath_signal;

 unsigned long jobctl;


 unsigned int personality;


 unsigned sched_reset_on_fork:1;
 unsigned sched_contributes_to_load:1;
 unsigned sched_migrated:1;
 unsigned sched_task_hot:1;


 unsigned :0;
 unsigned sched_remote_wakeup:1;

 unsigned sched_rt_mutex:1;



 unsigned user_dumpable:1;


 unsigned in_execve:1;
 unsigned in_iowait:1;

 unsigned restore_sigmask:1;


 unsigned in_user_fault:1;



 unsigned in_lru_fault:1;


 unsigned brk_randomized:1;



 unsigned no_cgroup_migration:1;

 unsigned frozen:1;


 unsigned use_memdelay:1;



 unsigned in_memstall:1;



 unsigned in_page_owner:1;



 unsigned in_eventfd:1;


 unsigned pasid_activated:1;


 unsigned reported_split_lock:1;



 unsigned in_thrashing:1;

 unsigned in_nf_duplicate:1;



 unsigned long atomic_flags;

 struct restart_block restart_block;

 pid_t pid;
 pid_t tgid;



 unsigned long stack_canary;
 struct task_struct *real_parent;


 struct task_struct *parent;




 struct list_head children;
 struct list_head sibling;
 struct task_struct *group_leader;







 struct list_head ptraced;
 struct list_head ptrace_entry;


 struct pid *thread_pid;
 struct hlist_node pid_links[PIDTYPE_MAX];
 struct list_head thread_node;

 struct completion *vfork_done;


 int *set_child_tid;


 int *clear_child_tid;


 void *worker_private;

 u64 utime;
 u64 stime;




 u64 gtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw;
 unsigned long nivcsw;


 u64 start_time;


 u64 start_boottime;


 unsigned long min_flt;
 unsigned long maj_flt;


 struct posix_cputimers posix_cputimers;


 struct posix_cputimers_work posix_cputimers_work;





 const struct cred *ptracer_cred;


 const struct cred *real_cred;


 const struct cred *cred;



 struct key *cached_requested_key;
 char comm[TASK_COMM_LEN];

 struct nameidata *nameidata;


 struct sysv_sem sysvsem;
 struct sysv_shm sysvshm;


 unsigned long last_switch_count;
 unsigned long last_switch_time;


 struct fs_struct *fs;


 struct files_struct *files;


 struct io_uring_task *io_uring;



 struct nsproxy *nsproxy;


 struct signal_struct *signal;
 struct sighand_struct *sighand;
 sigset_t blocked;
 sigset_t real_blocked;

 sigset_t saved_sigmask;
 struct sigpending pending;
 unsigned long sas_ss_sp;
 size_t sas_ss_size;
 unsigned int sas_ss_flags;

 struct callback_head *task_works;



 struct audit_context *audit_context;

 kuid_t loginuid;
 unsigned int sessionid;

 struct seccomp seccomp;
 struct syscall_user_dispatch syscall_dispatch;


 u64 parent_exec_id;
 u64 self_exec_id;


 spinlock_t alloc_lock;


 raw_spinlock_t pi_lock;

 struct wake_q_node wake_q;



 struct rb_root_cached pi_waiters;

 struct task_struct *pi_top_task;

 struct rt_mutex_waiter *pi_blocked_on;


 struct mutex *blocked_on;






 unsigned long blocker;



 int non_block_count;



 struct irqtrace_events irqtrace;
 unsigned int hardirq_threaded;
 u64 hardirq_chain_key;
 int softirqs_enabled;
 int softirq_context;
 int irq_config;






 u64 curr_chain_key;
 int lockdep_depth;
 unsigned int lockdep_recursion;
 struct held_lock held_locks[48UL];







 void *journal_info;


 struct bio_list *bio_list;


 struct blk_plug *plug;


 struct reclaim_state *reclaim_state;

 struct io_context *io_context;


 struct capture_control *capture_control;


 unsigned long ptrace_message;
 kernel_siginfo_t *last_siginfo;

 struct task_io_accounting ioac;


 unsigned int psi_flags;



 u64 acct_rss_mem1;

 u64 acct_vm_mem1;

 u64 acct_timexpd;



 nodemask_t mems_allowed;

 seqcount_spinlock_t mems_allowed_seq;
 int cpuset_mem_spread_rotor;



 struct css_set *cgroups;

 struct list_head cg_list;


 u32 closid;
 u32 rmid;


 struct robust_list_head *robust_list;

 struct compat_robust_list_head *compat_robust_list;

 struct list_head pi_state_list;
 struct futex_pi_state *pi_state_cache;
 struct mutex futex_exit_mutex;
 unsigned int futex_state;


 u8 perf_recursion[4];
 struct perf_event_context *perf_event_ctxp;
 struct mutex perf_event_mutex;
 struct list_head perf_event_list;
 struct perf_ctx_data *perf_ctx_data;


 unsigned long preempt_disable_ip;



 struct mempolicy *mempolicy;
 short il_prev;
 u8 il_weight;
 short pref_node_fork;


 int numa_scan_seq;
 unsigned int numa_scan_period;
 unsigned int numa_scan_period_max;
 int numa_preferred_nid;
 unsigned long numa_migrate_retry;

 u64 node_stamp;
 u64 last_task_numa_placement;
 u64 last_sum_exec_runtime;
 struct callback_head numa_work;
 struct numa_group *numa_group;
 unsigned long *numa_faults;
 unsigned long total_numa_faults;







 unsigned long numa_faults_locality[3];

 unsigned long numa_pages_migrated;



 struct rseq *rseq;
 u32 rseq_len;
 u32 rseq_sig;




 unsigned long rseq_event_mask;







 char rseq_fields[sizeof(struct rseq)];




 int mm_cid;
 int last_mm_cid;
 int migrate_from_cpu;
 int mm_cid_active;
 struct callback_head cid_work;


 struct tlbflush_unmap_batch tlb_ubc;


 struct pipe_inode_info *splice_pipe;

 struct page_frag task_frag;


 struct task_delay_info *delays;



 int make_it_fail;
 unsigned int fail_nth;





 int nr_dirtied;
 int nr_dirtied_pause;

 unsigned long dirty_paused_when;


 int latency_record_count;
 struct latency_record latency_record[32];





 u64 timer_slack_ns;
 u64 default_timer_slack_ns;
 struct kunit *kunit_test;




 int curr_ret_stack;
 int curr_ret_depth;


 unsigned long *ret_stack;


 unsigned long long ftrace_timestamp;
 unsigned long long ftrace_sleeptime;





 atomic_t trace_overrun;


 atomic_t tracing_graph_pause;




 unsigned long trace_recursion;
 struct mem_cgroup *memcg_in_oom;




 unsigned int memcg_nr_pages_over_high;


 struct mem_cgroup *active_memcg;


 struct obj_cgroup *objcg;



 struct gendisk *throttle_disk;



 struct uprobe_task *utask;


 unsigned int sequential_io;
 unsigned int sequential_io_avg;

 struct kmap_ctrl kmap_ctrl;

 unsigned long task_state_change;




 struct callback_head rcu;
 refcount_t rcu_users;
 int pagefault_disabled;

 struct task_struct *oom_reaper_list;
 struct timer_list oom_reaper_timer;


 struct vm_struct *stack_vm_area;



 refcount_t stack_refcount;






 void *security;



 struct bpf_local_storage *bpf_storage;

 struct bpf_run_ctx *bpf_ctx;


 struct bpf_net_context *bpf_net_context;
 u32 kstack_offset;



 void *mce_vaddr;
 __u64 mce_kflags;
 u64 mce_addr;
 __u64 mce_ripv : 1,
     mce_whole_page : 1,
     __mce_reserved : 62;
 struct callback_head mce_kill_me;
 int mce_count;



 struct llist_head kretprobe_instances;


 struct llist_head rethooks;
 struct callback_head l1d_flush_kill;







 union rv_task_monitor rv[2];



 struct user_event_mm *user_event_mm;



 struct unwind_task_info unwind_info;



 struct thread_struct thread;






} ;
struct rq;
struct task_struct;
struct hlist_bl_head {
 struct hlist_bl_node *first;
};
struct hlist_bl_node {
 struct hlist_bl_node *next, **pprev;
};
struct lockref {
 union {



  struct {
   spinlock_t lock;
   int count;
  };
 };
};
struct path;
struct file;
struct vfsmount;
struct qstr {
 union {
  struct {
   u32 hash; u32 len;
  };
  u64 hash_len;
 };
 const unsigned char *name;
};
union shortname_store {
 unsigned char string[(5*sizeof(unsigned long))];
 unsigned long words[5];
};
struct dentry {

 unsigned int d_flags;
 seqcount_spinlock_t d_seq;
 struct hlist_bl_node d_hash;
 struct dentry *d_parent;
 union {
 struct qstr __d_name;
 const struct qstr d_name;
 };
 struct inode *d_inode;

 union shortname_store d_shortname;



 const struct dentry_operations *d_op;
 struct super_block *d_sb;
 unsigned long d_time;
 void *d_fsdata;

 struct lockref d_lockref;




 union {
  struct list_head d_lru;
  wait_queue_head_t *d_wait;
 };
 struct hlist_node d_sib;
 struct hlist_head d_children;



 union {
  struct hlist_node d_alias;
  struct hlist_bl_node d_in_lookup_hash;
   struct callback_head d_rcu;
 } d_u;
};
enum d_real_type {
 D_REAL_DATA,
 D_REAL_METADATA,
};
struct dentry_operations {
 int (*d_revalidate)(struct inode *, const struct qstr *,
       struct dentry *, unsigned int);
 int (*d_weak_revalidate)(struct dentry *, unsigned int);
 int (*d_hash)(const struct dentry *, struct qstr *);
 int (*d_compare)(const struct dentry *,
   unsigned int, const char *, const struct qstr *);
 int (*d_delete)(const struct dentry *);
 int (*d_init)(struct dentry *);
 void (*d_release)(struct dentry *);
 void (*d_prune)(struct dentry *);
 void (*d_iput)(struct dentry *, struct inode *);
 char *(*d_dname)(struct dentry *, char *, int);
 struct vfsmount *(*d_automount)(struct path *);
 int (*d_manage)(const struct path *, bool);
 struct dentry *(*d_real)(struct dentry *, enum d_real_type type);
 bool (*d_unalias_trylock)(const struct dentry *);
 void (*d_unalias_unlock)(const struct dentry *);
} ;
extern void d_delete(struct dentry *);
static inline    struct inode *d_inode(const struct dentry *dentry)
;
static inline    struct dentry *d_real(struct dentry *dentry, enum d_real_type type)
;
struct dentry;
struct vfsmount;
struct path {
 struct vfsmount *mnt;
 struct dentry *dentry;
} ;
typedef __s64 time64_t;
struct timespec64 {
 time64_t tv_sec;
 long tv_nsec;
};
struct module;
struct page;
struct vm_area_struct;
struct mm_struct;
typedef s32 old_time32_t;
struct old_timespec32 {
 old_time32_t tv_sec;
 s32 tv_nsec;
};
struct user_namespace;
struct uid_gid_map;
struct kstat {
 u32 result_mask;
 umode_t mode;
 unsigned int nlink;
 uint32_t blksize;
 u64 attributes;
 u64 attributes_mask;










 u64 ino;
 dev_t dev;
 dev_t rdev;
 kuid_t uid;
 kgid_t gid;
 loff_t size;
 struct timespec64 atime;
 struct timespec64 mtime;
 struct timespec64 ctime;
 struct timespec64 btime;
 u64 blocks;
 u64 mnt_id;
 u64 change_cookie;
 u64 subvol;
 u32 dio_mem_align;
 u32 dio_offset_align;
 u32 dio_read_offset_align;
 u32 atomic_write_unit_min;
 u32 atomic_write_unit_max;
 u32 atomic_write_unit_max_opt;
 u32 atomic_write_segments_max;
};
struct mutex;
struct task_struct;
struct swait_queue_head {
 raw_spinlock_t lock;
 struct list_head task_list;
};
struct completion {
 unsigned int done;
 struct swait_queue_head wait;
};
struct shrink_control {
 gfp_t gfp_mask;


 int nid;






 unsigned long nr_to_scan;






 unsigned long nr_scanned;


 struct mem_cgroup *memcg;
};
struct shrinker {
 unsigned long (*count_objects)(struct shrinker *,
           struct shrink_control *sc);
 unsigned long (*scan_objects)(struct shrinker *,
          struct shrink_control *sc);

 long batch;
 int seeks;
 unsigned flags;
 refcount_t refcount;
 struct completion done;
 struct callback_head rcu;

 void *private_data;


 struct list_head list;


 int id;


 int debugfs_id;
 const char *name;
 struct dentry *debugfs_entry;


 atomic_long_t *nr_deferred;
};
struct hlist_nulls_node {
 struct hlist_nulls_node *next, **pprev;
};
struct page;
struct kref {
 refcount_t refcount;
};
struct maple_tree {
 union {
  spinlock_t ma_lock;

  struct lockdep_map *ma_external_lock;

 };
 unsigned int ma_flags;
 void *ma_root;
};
enum maple_status {
 ma_active,
 ma_start,
 ma_root,
 ma_none,
 ma_pause,
 ma_overflow,
 ma_underflow,
 ma_error,
};
struct rw_semaphore {
 atomic_long_t count;





 atomic_long_t owner;

 struct optimistic_spin_queue osq;

 raw_spinlock_t wait_lock;
 struct list_head wait_list;

 void *magic;


 struct lockdep_map dep_map;

};
struct hrtimer;
struct uprobe;
struct vm_area_struct;
struct mm_struct;
struct inode;
struct page;
struct workqueue_struct;
struct work_struct;
typedef void (*work_func_t)(struct work_struct *work);
struct work_struct {
 atomic_long_t data;
 struct list_head entry;
 work_func_t func;

 struct lockdep_map lockdep_map;

};
struct uprobe_xol_ops;
struct arch_uprobe {
 union {
  u8 insn[16];
  u8 ixol[16];
 };

 const struct uprobe_xol_ops *ops;

 union {
  struct {
   s32 offs;
   u8 ilen;
   u8 opc1;
  } branch;
  struct {
   u8 fixups;
   u8 ilen;
  } defparam;
  struct {
   u8 reg_offset;
   u8 ilen;
  } push;
 };

 unsigned long flags;
};
struct arch_uprobe_task {

 unsigned long saved_scratch_register;

 unsigned int saved_trap_nr;
 unsigned int saved_tf;
};
enum uprobe_task_state {
 UTASK_RUNNING,
 UTASK_SSTEP,
 UTASK_SSTEP_ACK,
 UTASK_SSTEP_TRAPPED,
};
enum hprobe_state {
 HPROBE_LEASED,
 HPROBE_STABLE,
 HPROBE_GONE,
 HPROBE_CONSUMED,
};
struct hprobe {
 enum hprobe_state state;
 int srcu_idx;
 struct uprobe *uprobe;
};
struct uprobe_task {
 enum uprobe_task_state state;

 unsigned int depth;
 struct return_instance *return_instances;

 struct return_instance *ri_pool;
 struct timer_list ri_timer;
 seqcount_t ri_seqcount;

 union {
  struct {
   struct arch_uprobe_task autask;
   unsigned long vaddr;
  };

  struct {
   struct callback_head dup_xol_work;
   unsigned long dup_xol_addr;
  };
 };

 struct uprobe *active_uprobe;
 unsigned long xol_vaddr;
 bool signal_denied;

 struct arch_uprobe *auprobe;
};
struct return_consumer {
 __u64 cookie;
 __u64 id;
};
struct return_instance {
 struct hprobe hprobe;
 unsigned long func;
 unsigned long stack;
 unsigned long orig_ret_vaddr;
 bool chained;
 int cons_cnt;

 struct return_instance *next;
 struct callback_head rcu;


 struct return_consumer consumer;




 struct return_consumer *extra_consumers;
} ;
struct xol_area;
struct uprobes_state {
 struct xol_area *xol_area;

 struct hlist_head head_tramps;

};
struct percpu_counter {
 raw_spinlock_t lock;
 s64 count;

 struct list_head list;

 s32 *counters;
};
typedef struct {




 u64 ctx_id;
 atomic64_t tlb_gen;

 unsigned long next_trim_cpumask;


 struct rw_semaphore ldt_usr_sem;
 struct ldt_struct *ldt;


 unsigned long flags;



 unsigned long lam_cr3_mask;


 u64 untag_mask;


 struct mutex lock;
 void *vdso;
 const struct vdso_image *vdso_image;

 atomic_t perf_rdpmc_allowed;





 u16 pkey_allocation_map;
 s16 execute_only_pkey;
 u16 global_asid;


 bool asid_transition;

} mm_context_t;
struct address_space;
struct mem_cgroup;
typedef struct {
 unsigned long f;
} memdesc_flags_t;
struct page {
 memdesc_flags_t flags;







 union {
  struct {





   union {
    struct list_head lru;


    struct list_head buddy_list;
    struct list_head pcp_list;
    struct llist_node pcp_llist;
   };
   struct address_space *mapping;
   union {
    unsigned long __folio_index;
    unsigned long share;
   };







   unsigned long private;
  };
  struct {




   unsigned long pp_magic;
   struct page_pool *pp;
   unsigned long _pp_mapping_pad;
   unsigned long dma_addr;
   atomic_long_t pp_ref_count;
  };
  struct {
   unsigned long compound_head;
  };
  struct {




   void *_unused_pgmap_compound_head;
   void *zone_device_data;
  };


  struct callback_head callback_head;
 };

 union {
  unsigned int page_type;
  atomic_t _mapcount;
 };


 atomic_t _refcount;


 unsigned long memcg_data;
} ;
typedef struct {
 unsigned long val;
} swp_entry_t;
typedef int mm_id_mapcount_t;
typedef unsigned int mm_id_t;
struct folio {

 union {
  struct {

   memdesc_flags_t flags;
   union {
    struct list_head lru;


    struct {

     void *__filler;

     unsigned int mlock_count;

    };

    struct dev_pagemap *pgmap;
   };
   struct address_space *mapping;
   union {
    unsigned long index;
    unsigned long share;
   };
   union {
    void *private;
    swp_entry_t swap;
   };
   atomic_t _mapcount;
   atomic_t _refcount;

   unsigned long memcg_data;
  };
  struct page page;
 };
 union {
  struct {
   unsigned long _flags_1;
   unsigned long _head_1;
   union {
    struct {

     atomic_t _large_mapcount;
     atomic_t _nr_pages_mapped;

     atomic_t _entire_mapcount;
     atomic_t _pincount;

     mm_id_mapcount_t _mm_id_mapcount[2];
     union {
      mm_id_t _mm_id[2];
      unsigned long _mm_ids;
     };

    };
    unsigned long _usable_1[4];
   };
   atomic_t _mapcount_1;
   atomic_t _refcount_1;


   unsigned int _nr_pages;


  };
  struct page __page_1;
 };
 union {
  struct {
   unsigned long _flags_2;
   unsigned long _head_2;

   struct list_head _deferred_list;





  };
  struct page __page_2;
 };
 union {
  struct {
   unsigned long _flags_3;
   unsigned long _head_3;

   void *_hugetlb_subpool;
   void *_hugetlb_cgroup;
   void *_hugetlb_cgroup_rsvd;
   void *_hugetlb_hwpoison;

  };
  struct page __page_3;
 };
};
typedef unsigned long vm_flags_t;
typedef struct { unsigned long v; } freeptr_t;
struct vm_userfaultfd_ctx {
 struct userfaultfd_ctx *ctx;
};
struct anon_vma_name {
 struct kref kref;

 char name[1];
};
struct anon_vma_name *anon_vma_name(struct vm_area_struct *vma);
struct vma_numab_state {





 unsigned long next_scan;





 unsigned long pids_active_reset;
 unsigned long pids_active[2];


 int start_scan_seq;





 int prev_scan_seq;
};
struct pfnmap_track_ctx {
 struct kref kref;
 unsigned long pfn;
 unsigned long size;
};
struct vm_area_desc {

 const struct mm_struct *const mm;
 struct file *const file;
 unsigned long start;
 unsigned long end;


 unsigned long pgoff;
 struct file *vm_file;
 vm_flags_t vm_flags;
 pgprot_t page_prot;


 const struct vm_operations_struct *vm_ops;
 void *private_data;
};
struct vm_area_struct {


 union {
  struct {

   unsigned long vm_start;
   unsigned long vm_end;
  };
  freeptr_t vm_freeptr;
 };





 struct mm_struct *vm_mm;
 pgprot_t vm_page_prot;





 union {
  const vm_flags_t vm_flags;
  vm_flags_t __vm_flags;
 };
 unsigned int vm_lock_seq;







 struct list_head anon_vma_chain;

 struct anon_vma *anon_vma;


 const struct vm_operations_struct *vm_ops;


 unsigned long vm_pgoff;

 struct file * vm_file;
 void * vm_private_data;


 atomic_long_t swap_readahead_info;





 struct mempolicy *vm_policy;


 struct vma_numab_state *numab_state;



 refcount_t vm_refcnt ;

 struct lockdep_map vmlock_dep_map;







 struct {
  struct rb_node rb;
  unsigned long rb_subtree_last;
 } shared;






 struct anon_vma_name *anon_name;

 struct vm_userfaultfd_ctx vm_userfaultfd_ctx;

 struct pfnmap_track_ctx *pfnmap_track_ctx;

} ;
struct mm_cid {
 u64 time;
 int cid;
 int recent_cid;
};
typedef struct {
 unsigned long __mm_flags[((((64)) + ((sizeof(long) * 8)) - 1) / ((sizeof(long) * 8)))];
} mm_flags_t;
struct kioctx_table;
struct iommu_mm_data;
struct mm_struct {
 struct {




  struct {







   atomic_t mm_count;
  } ;

  struct maple_tree mm_mt;

  unsigned long mmap_base;
  unsigned long mmap_legacy_base;


  unsigned long mmap_compat_base;
  unsigned long mmap_compat_legacy_base;

  unsigned long task_size;
  pgd_t * pgd;
  atomic_t membarrier_state;
  atomic_t mm_users;
  struct mm_cid *pcpu_cid;





  unsigned long mm_cid_next_scan;






  unsigned int nr_cpus_allowed;







  atomic_t max_nr_cid;






  raw_spinlock_t cpus_allowed_lock;


  atomic_long_t pgtables_bytes;

  int map_count;

  spinlock_t page_table_lock;
  struct rw_semaphore mmap_lock;

  struct list_head mmlist;





  struct rcuwait vma_writer_wait;
  seqcount_t mm_lock_seq;


  atomic64_t futex_unique_id;
  unsigned long hiwater_rss;
  unsigned long hiwater_vm;

  unsigned long total_vm;
  unsigned long locked_vm;
  atomic64_t pinned_vm;
  unsigned long data_vm;
  unsigned long exec_vm;
  unsigned long stack_vm;
  vm_flags_t def_flags;






  seqcount_t write_protect_seq;

  spinlock_t arg_lock;

  unsigned long start_code, end_code, start_data, end_data;
  unsigned long start_brk, brk, start_stack;
  unsigned long arg_start, arg_end, env_start, env_end;

  unsigned long saved_auxv[(2*(3 + 24 + 1))];






  struct percpu_counter rss_stat[NR_MM_COUNTERS];

  struct linux_binfmt *binfmt;


  mm_context_t context;

  mm_flags_t flags;


  spinlock_t ioctx_lock;
  struct kioctx_table *ioctx_table;
  struct task_struct *owner;

  struct user_namespace *user_ns;


  struct file *exe_file;

  struct mmu_notifier_subscriptions *notifier_subscriptions;
  unsigned long numa_next_scan;


  unsigned long numa_scan_offset;


  int numa_scan_seq;






  atomic_t tlb_flush_pending;


  atomic_t tlb_flush_batched;

  struct uprobes_state uprobes_state;




  atomic_long_t hugetlb_usage;

  struct work_struct async_put_work;


  struct iommu_mm_data *iommu_mm;






  unsigned long ksm_merging_pages;




  unsigned long ksm_rmap_items;




  atomic_long_t ksm_zero_pages;


  struct {

   struct list_head list;





   unsigned long bitmap;


   struct mem_cgroup *memcg;

  } lru_gen;


  mm_id_t mm_id;

 } ;





 unsigned long cpu_bitmap[1];
};
struct vm_fault;
typedef unsigned int vm_fault_t;
enum fault_flag {
 FAULT_FLAG_WRITE = 1 << 0,
 FAULT_FLAG_MKWRITE = 1 << 1,
 FAULT_FLAG_ALLOW_RETRY = 1 << 2,
 FAULT_FLAG_RETRY_NOWAIT = 1 << 3,
 FAULT_FLAG_KILLABLE = 1 << 4,
 FAULT_FLAG_TRIED = 1 << 5,
 FAULT_FLAG_USER = 1 << 6,
 FAULT_FLAG_REMOTE = 1 << 7,
 FAULT_FLAG_INSTRUCTION = 1 << 8,
 FAULT_FLAG_INTERRUPTIBLE = 1 << 9,
 FAULT_FLAG_UNSHARE = 1 << 10,
 FAULT_FLAG_ORIG_PTE_VALID = 1 << 11,
 FAULT_FLAG_VMA_LOCK = 1 << 12,
};
struct page;
struct vmem_altmap;
struct dev_pagemap;
struct page;
struct timespec64;
struct vm_area_struct;
struct mempolicy;
struct list_lru;
struct xarray {
 spinlock_t xa_lock;

 gfp_t xa_flags;
 void * xa_head;
};
static inline    void *xa_head(const struct xarray *xa)
;
struct mem_cgroup;
struct list_lru_one {
 struct list_head list;

 long nr_items;

 spinlock_t lock;
};
struct list_lru_node {

 struct list_lru_one lru;
 atomic_long_t nr_items;
} ;
struct list_lru {
 struct list_lru_node *node;

 struct list_head list;
 int shrinker_id;
 bool memcg_aware;
 struct xarray xa;


 struct lock_class_key *key;

};
struct pidfs_attr;
struct upid {
 int nr;
 struct pid_namespace *ns;
};
struct pid {
 refcount_t count;
 unsigned int level;
 spinlock_t lock;
 struct {
  u64 ino;
  struct rb_node pidfs_node;
  struct dentry *stashed;
  struct pidfs_attr *attr;
 };

 struct hlist_head tasks[PIDTYPE_MAX];
 struct hlist_head inodes;

 wait_queue_head_t wait_pidfd;
 struct callback_head rcu;
 struct upid numbers[1];
};
struct file;
typedef struct { u64 val; } kernel_cap_t;
struct file;
struct inode;
struct dentry;
struct task_struct;
struct user_namespace;
struct mnt_idmap;
struct flock {
 short l_type;
 short l_whence;
 __kernel_off_t l_start;
 __kernel_off_t l_len;
 __kernel_pid_t l_pid;






};
enum migrate_mode {
 MIGRATE_ASYNC,
 MIGRATE_SYNC_LIGHT,
 MIGRATE_SYNC,
};
struct task_struct;
enum pid_type;
struct seq_file;
struct task_struct;
struct task_struct;
struct mmu_notifier_subscriptions;
struct seq_file;
struct vm_area_struct;
struct mm_struct;
struct vm_area_struct;
static inline    bool pagefault_disabled(void)
;
struct task_struct;
struct css_set;
struct completion;
struct ctl_table;
struct nsproxy;
struct ctl_table_root;
struct ctl_table_header;
struct ctl_dir;
typedef int proc_handler(const struct ctl_table *ctl, int write, void *buffer,
  size_t *lenp, loff_t *ppos);
struct ctl_table_poll {
 atomic_t event;
 wait_queue_head_t wait;
};
struct ctl_table {
 const char *procname;
 void *data;
 int maxlen;
 umode_t mode;
 proc_handler *proc_handler;
 struct ctl_table_poll *poll;
 void *extra1;
 void *extra2;
} ;
struct ctl_node {
 struct rb_node node;
 struct ctl_table_header *header;
};
struct ctl_table_header {
 union {
  struct {
   const struct ctl_table *ctl_table;
   int ctl_table_size;
   int used;
   int count;
   int nreg;
  };
  struct callback_head rcu;
 };
 struct completion *unregistering;
 const struct ctl_table *ctl_table_arg;
 struct ctl_table_root *root;
 struct ctl_table_set *set;
 struct ctl_dir *parent;
 struct ctl_node *node;
 struct hlist_head inodes;







 enum {
  SYSCTL_TABLE_TYPE_DEFAULT,
  SYSCTL_TABLE_TYPE_PERMANENTLY_EMPTY,
 } type;
};
struct ctl_dir {

 struct ctl_table_header header;
 struct rb_root root;
};
struct ctl_table_set {
 int (*is_seen)(struct ctl_table_set *);
 struct ctl_dir dir;
};
struct ctl_table_root {
 struct ctl_table_set default_set;
 struct ctl_table_set *(*lookup)(struct ctl_table_root *root);
 void (*set_ownership)(struct ctl_table_header *head,
         kuid_t *uid, kgid_t *gid);
 int (*permissions)(struct ctl_table_header *head, const struct ctl_table *table);
};
struct assoc_array {
 struct assoc_array_ptr *root;
 unsigned long nr_leaves_on_tree;
};
typedef int32_t key_serial_t;
typedef uint32_t key_perm_t;
struct key;
struct net;
struct seq_file;
struct user_struct;
struct signal_struct;
struct cred;
struct key_type;
struct key_tag;
struct key_tag {
 struct callback_head rcu;
 atomic64_t index_id;
 refcount_t usage;
 bool removed;
};
struct keyring_index_key {

 unsigned long hash;
 union {
  struct {

   u16 desc_len;
   char desc[sizeof(long) - 2];




  };
  unsigned long x;
 };
 struct key_type *type;
 struct key_tag *domain_tag;
 const char *description;
 u64 type_id;
 u64 domain_id;
};
union key_payload {
 void *rcu_data0;
 void *data[4];
};
typedef int (*key_restrict_link_func_t)(struct key *dest_keyring,
     const struct key_type *type,
     const union key_payload *payload,
     struct key *restriction_key);
struct key_restriction {
 key_restrict_link_func_t check;
 struct key *key;
 struct key_type *keytype;
};
struct key {
 refcount_t usage;
 key_serial_t serial;
 union {
  struct list_head graveyard_link;
  struct rb_node serial_node;
 };

 struct watch_list *watchers;

 struct rw_semaphore sem;
 struct key_user *user;
 void *security;
 union {
  time64_t expiry;
  time64_t revoked_at;
 };
 time64_t last_used_at;
 kuid_t uid;
 kgid_t gid;
 key_perm_t perm;
 unsigned short quotalen;
 unsigned short datalen;



 short state;






 unsigned long flags;






 union {
  struct keyring_index_key index_key;
  struct {
   unsigned long hash;
   unsigned long len_desc;
   struct key_type *type;
   struct key_tag *domain_tag;
   char *description;
   u64 type_id;
   u64 domain_id;
  };
 };





 union {
  union key_payload payload;
  struct {

   struct list_head name_link;
   struct assoc_array keys;
  };
 };
 struct key_restriction *restrict_link;
};
struct user_struct {
 refcount_t __count;

 struct percpu_counter epoll_watches;

 unsigned long unix_inflight;
 atomic_long_t pipe_bufs;


 struct hlist_node uidhash_node;
 kuid_t uid;




 atomic_long_t locked_vm;


 atomic_long_t perf_mlock;


 atomic_t nr_watches;



 struct ratelimit_state ratelimit;
};
struct cred;
struct inode;
struct group_info {
 refcount_t usage;
 int ngroups;
 kgid_t gid[1];
} ;
struct cred {
 atomic_long_t usage;
 kuid_t uid;
 kgid_t gid;
 kuid_t suid;
 kgid_t sgid;
 kuid_t euid;
 kgid_t egid;
 kuid_t fsuid;
 kgid_t fsgid;
 unsigned securebits;
 kernel_cap_t cap_inheritable;
 kernel_cap_t cap_permitted;
 kernel_cap_t cap_effective;
 kernel_cap_t cap_bset;
 kernel_cap_t cap_ambient;

 unsigned char jit_keyring;

 struct key *session_keyring;
 struct key *process_keyring;
 struct key *thread_keyring;
 struct key *request_key_auth;


 void *security;

 struct user_struct *user;
 struct user_namespace *user_ns;
 struct ucounts *ucounts;
 struct group_info *group_info;

 union {
  int non_rcu;
  struct callback_head rcu;
 };
} ;
struct hrtimer_clock_base {
 struct hrtimer_cpu_base *cpu_base;
 unsigned int index;
 clockid_t clockid;
 seqcount_raw_spinlock_t seq;
 struct hrtimer *running;
 struct timerqueue_head active;
 ktime_t offset;
} ;
enum hrtimer_base_type {
 HRTIMER_BASE_MONOTONIC,
 HRTIMER_BASE_REALTIME,
 HRTIMER_BASE_BOOTTIME,
 HRTIMER_BASE_TAI,
 HRTIMER_BASE_MONOTONIC_SOFT,
 HRTIMER_BASE_REALTIME_SOFT,
 HRTIMER_BASE_BOOTTIME_SOFT,
 HRTIMER_BASE_TAI_SOFT,
 HRTIMER_MAX_CLOCK_BASES,
};
struct hrtimer_cpu_base {
 raw_spinlock_t lock;
 unsigned int cpu;
 unsigned int active_bases;
 unsigned int clock_was_set_seq;
 unsigned int hres_active : 1,
     in_hrtirq : 1,
     hang_detected : 1,
     softirq_activated : 1,
     online : 1;

 unsigned int nr_events;
 unsigned short nr_retries;
 unsigned short nr_hangs;
 unsigned int max_hang_time;





 ktime_t expires_next;
 struct hrtimer *next_timer;
 ktime_t softirq_expires_next;
 struct hrtimer *softirq_next_timer;
 struct hrtimer_clock_base clock_base[HRTIMER_MAX_CLOCK_BASES];
 call_single_data_t csd;
} ;
static inline    void hrtimer_restart(struct hrtimer *timer)
;
struct kernel_siginfo;
struct task_struct;
struct sighand_struct {
 spinlock_t siglock;
 refcount_t count;
 wait_queue_head_t signalfd_wqh;
 struct k_sigaction action[64];
};
struct pacct_struct {
 int ac_flag;
 long ac_exitcode;
 unsigned long ac_mem;
 u64 ac_utime, ac_stime;
 unsigned long ac_minflt, ac_majflt;
};
struct cpu_itimer {
 u64 expires;
 u64 incr;
};
struct task_cputime_atomic {
 atomic64_t utime;
 atomic64_t stime;
 atomic64_t sum_exec_runtime;
};
struct thread_group_cputimer {
 struct task_cputime_atomic cputime_atomic;
};
struct core_thread {
 struct task_struct *task;
 struct core_thread *next;
};
struct core_state {
 atomic_t nr_threads;
 struct core_thread dumper;
 struct completion startup;
};
struct signal_struct {
 refcount_t sigcnt;
 atomic_t live;
 int nr_threads;
 int quick_threads;
 struct list_head thread_head;

 wait_queue_head_t wait_chldexit;


 struct task_struct *curr_target;


 struct sigpending shared_pending;


 struct hlist_head multiprocess;


 int group_exit_code;

 int notify_count;
 struct task_struct *group_exec_task;


 int group_stop_count;
 unsigned int flags;

 struct core_state *core_state;
 unsigned int is_child_subreaper:1;
 unsigned int has_child_subreaper:1;




 unsigned int timer_create_restore_ids:1;
 atomic_t next_posix_timer_id;
 struct hlist_head posix_timers;
 struct hlist_head ignored_posix_timers;


 struct hrtimer real_timer;
 ktime_t it_real_incr;






 struct cpu_itimer it[2];





 struct thread_group_cputimer cputimer;



 struct posix_cputimers posix_cputimers;


 struct pid *pids[PIDTYPE_MAX];





 struct pid *tty_old_pgrp;


 int leader;

 struct tty_struct *tty;


 struct autogroup *autogroup;







 seqlock_t stats_lock;
 u64 utime, stime, cutime, cstime;
 u64 gtime;
 u64 cgtime;
 struct prev_cputime prev_cputime;
 unsigned long nvcsw, nivcsw, cnvcsw, cnivcsw;
 unsigned long min_flt, maj_flt, cmin_flt, cmaj_flt;
 unsigned long inblock, oublock, cinblock, coublock;
 unsigned long maxrss, cmaxrss;
 struct task_io_accounting ioac;







 unsigned long long sum_sched_runtime;
 struct rlimit rlim[16];


 struct pacct_struct pacct;


 struct taskstats *stats;


 unsigned audit_tty;
 struct tty_audit_buf *tty_audit_buf;



 struct rw_semaphore cgroup_threadgroup_rwsem;






 bool oom_flag_origin;
 short oom_score_adj;
 short oom_score_adj_min;

 struct mm_struct *oom_mm;


 struct mutex cred_guard_mutex;





 struct rw_semaphore exec_update_lock;




} ;
static inline    int sas_ss_flags(unsigned long sp)
;
static inline    unsigned long rlimit(unsigned int limit)
;
static inline    unsigned long rlimit_max(unsigned int limit)
;
struct rcu_sync {
 int gp_state;
 int gp_count;
 wait_queue_head_t gp_wait;

 struct callback_head cb_head;
};
struct percpu_rw_semaphore {
 struct rcu_sync rss;
 unsigned int *read_count;
 struct rcuwait writer;
 wait_queue_head_t waiters;
 atomic_t block;

 struct lockdep_map dep_map;

};
struct delayed_call {
 void (*fn)(void *);
 void *arg;
};
typedef struct {
 __u8 b[16];
} uuid_t;
typedef u32 errseq_t;
struct task_struct;
struct io_cq {
 struct request_queue *q;
 struct io_context *ioc;







 union {
  struct list_head q_node;
  struct kmem_cache *__rcu_icq_cache;
 };
 union {
  struct hlist_node ioc_node;
  struct callback_head __rcu_head;
 };

 unsigned int flags;
};
struct io_context {
 atomic_long_t refcount;
 atomic_t active_ref;

 unsigned short ioprio;



 spinlock_t lock;

 struct xarray icq_tree;
 struct io_cq *icq_hint;
 struct hlist_head icq_list;

 struct work_struct release_work;

};
struct task_struct;
struct super_block;
struct dentry;
struct user_namespace;
struct mnt_idmap;
struct file_system_type;
struct fs_context;
struct file;
struct path;
struct vfsmount {
 struct dentry *mnt_root;
 struct super_block *mnt_sb;
 int mnt_flags;
 struct mnt_idmap *mnt_idmap;
} ;
static inline    struct mnt_idmap *mnt_idmap(const struct vfsmount *mnt)
;
int mnt_get_write_access(struct vfsmount *mnt);
struct mnt_idmap;
struct user_namespace;
typedef struct {
 uid_t val;
} vfsuid_t;
typedef struct {
 gid_t val;
} vfsgid_t;
struct percpu_ref;
typedef void (percpu_ref_func_t)(struct percpu_ref *);
struct percpu_ref_data {
 atomic_long_t count;
 percpu_ref_func_t *release;
 percpu_ref_func_t *confirm_switch;
 bool force_atomic:1;
 bool allow_reinit:1;
 struct callback_head rcu;
 struct percpu_ref *ref;
};
struct percpu_ref {




 unsigned long percpu_count_ptr;







 struct percpu_ref_data *data;
};
struct kmem_cache;
struct page;
struct vm_struct;
struct task_struct;
struct list_lru;
struct mem_cgroup;
enum rw_hint {
 WRITE_LIFE_NOT_SET = 0,
 WRITE_LIFE_NONE = 1,
 WRITE_LIFE_SHORT = 2,
 WRITE_LIFE_MEDIUM = 3,
 WRITE_LIFE_LONG = 4,
 WRITE_LIFE_EXTREME = 5,
 WRITE_LIFE_HINT_NR,
} __attribute__((__packed__));
typedef struct {

 atomic64_t refcnt;



} file_ref_t;
struct utf8data;
struct utf8data_table;
enum utf8_normalization {
 UTF8_NFDI = 0,
 UTF8_NFDICF,
 UTF8_NMAX,
};
struct unicode_map {
 unsigned int version;
 const struct utf8data *ntab[UTF8_NMAX];
 const struct utf8data_table *tables;
 struct callback_head rcu;
};
struct backing_dev_info;
struct bdi_writeback;
struct io_comp_batch;
struct export_operations;
struct fiemap_extent_info;
struct kiocb;
struct pipe_inode_info;
struct poll_table_struct;
struct kstatfs;
struct vm_area_struct;
struct vfsmount;
struct cred;
struct swap_info_struct;
struct seq_file;
struct workqueue_struct;
struct iov_iter;
struct fscrypt_operations;
struct fsverity_operations;
struct fsnotify_mark_connector;
struct fsnotify_sb_info;
struct fs_context;
struct fs_parameter_spec;
struct file_kattr;
struct iattr {
 unsigned int ia_valid;
 umode_t ia_mode;
 union {
  kuid_t ia_uid;
  vfsuid_t ia_vfsuid;
 };
 union {
  kgid_t ia_gid;
  vfsgid_t ia_vfsgid;
 };
 loff_t ia_size;
 struct timespec64 ia_atime;
 struct timespec64 ia_mtime;
 struct timespec64 ia_ctime;






 struct file *ia_file;
};
struct dquot;
struct kqid;
struct user_namespace;
typedef __kernel_uid32_t projid_t;
typedef struct {
 projid_t val;
} kprojid_t;
enum quota_type {
 USRQUOTA = 0,
 GRPQUOTA = 1,
 PRJQUOTA = 2,
};
typedef long long qsize_t;
struct kqid {
 union {
  kuid_t uid;
  kgid_t gid;
  kprojid_t projid;
 };
 enum quota_type type;
};
struct mem_dqblk {
 qsize_t dqb_bhardlimit;
 qsize_t dqb_bsoftlimit;
 qsize_t dqb_curspace;
 qsize_t dqb_rsvspace;
 qsize_t dqb_ihardlimit;
 qsize_t dqb_isoftlimit;
 qsize_t dqb_curinodes;
 time64_t dqb_btime;
 time64_t dqb_itime;
};
struct quota_format_type;
struct mem_dqinfo {
 struct quota_format_type *dqi_format;
 int dqi_fmt_id;

 struct list_head dqi_dirty_list;
 unsigned long dqi_flags;
 unsigned int dqi_bgrace;
 unsigned int dqi_igrace;
 qsize_t dqi_max_spc_limit;
 qsize_t dqi_max_ino_limit;
 void *dqi_priv;
};
struct super_block;
struct dquot {
 struct hlist_node dq_hash;
 struct list_head dq_inuse;
 struct list_head dq_free;
 struct list_head dq_dirty;
 struct mutex dq_lock;
 spinlock_t dq_dqb_lock;
 atomic_t dq_count;
 struct super_block *dq_sb;
 struct kqid dq_id;
 loff_t dq_off;
 unsigned long dq_flags;
 struct mem_dqblk dq_dqb;
};
struct quota_format_ops {
 int (*check_quota_file)(struct super_block *sb, int type);
 int (*read_file_info)(struct super_block *sb, int type);
 int (*write_file_info)(struct super_block *sb, int type);
 int (*free_file_info)(struct super_block *sb, int type);
 int (*read_dqblk)(struct dquot *dquot);
 int (*commit_dqblk)(struct dquot *dquot);
 int (*release_dqblk)(struct dquot *dquot);
 int (*get_next_id)(struct super_block *sb, struct kqid *qid);
};
struct dquot_operations {
 int (*write_dquot) (struct dquot *);
 struct dquot *(*alloc_dquot)(struct super_block *, int);
 void (*destroy_dquot)(struct dquot *);
 int (*acquire_dquot) (struct dquot *);
 int (*release_dquot) (struct dquot *);
 int (*mark_dirty) (struct dquot *);
 int (*write_info) (struct super_block *, int);


 qsize_t *(*get_reserved_space) (struct inode *);
 int (*get_projid) (struct inode *, kprojid_t *);

 int (*get_inode_usage) (struct inode *, qsize_t *);

 int (*get_next_id) (struct super_block *sb, struct kqid *qid);
};
struct path;
struct qc_dqblk {
 int d_fieldmask;
 u64 d_spc_hardlimit;
 u64 d_spc_softlimit;
 u64 d_ino_hardlimit;
 u64 d_ino_softlimit;
 u64 d_space;
 u64 d_ino_count;
 s64 d_ino_timer;

 s64 d_spc_timer;
 int d_ino_warns;
 int d_spc_warns;
 u64 d_rt_spc_hardlimit;
 u64 d_rt_spc_softlimit;
 u64 d_rt_space;
 s64 d_rt_spc_timer;
 int d_rt_spc_warns;
};
struct qc_type_state {
 unsigned int flags;
 unsigned int spc_timelimit;

 unsigned int ino_timelimit;
 unsigned int rt_spc_timelimit;
 unsigned int spc_warnlimit;
 unsigned int ino_warnlimit;
 unsigned int rt_spc_warnlimit;
 unsigned long long ino;
 blkcnt_t blocks;
 blkcnt_t nextents;
};
struct qc_state {
 unsigned int s_incoredqs;
 struct qc_type_state s_state[3];
};
struct qc_info {
 int i_fieldmask;
 unsigned int i_flags;
 unsigned int i_spc_timelimit;

 unsigned int i_ino_timelimit;
 unsigned int i_rt_spc_timelimit;
 unsigned int i_spc_warnlimit;
 unsigned int i_ino_warnlimit;
 unsigned int i_rt_spc_warnlimit;
};
struct quotactl_ops {
 int (*quota_on)(struct super_block *, int, int, const struct path *);
 int (*quota_off)(struct super_block *, int);
 int (*quota_enable)(struct super_block *, unsigned int);
 int (*quota_disable)(struct super_block *, unsigned int);
 int (*quota_sync)(struct super_block *, int);
 int (*set_info)(struct super_block *, int, struct qc_info *);
 int (*get_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_nextdqblk)(struct super_block *, struct kqid *,
        struct qc_dqblk *);
 int (*set_dqblk)(struct super_block *, struct kqid, struct qc_dqblk *);
 int (*get_state)(struct super_block *, struct qc_state *);
 int (*rm_xquota)(struct super_block *, unsigned int);
};
struct quota_format_type {
 int qf_fmt_id;
 const struct quota_format_ops *qf_ops;
 struct module *qf_owner;
 struct quota_format_type *qf_next;
};
struct quota_info {
 unsigned int flags;
 struct rw_semaphore dqio_sem;
 struct inode *files[3];
 struct mem_dqinfo info[3];
 const struct quota_format_ops *ops[3];
};
struct page;
struct address_space;
struct writeback_control;
struct readahead_control;
struct kiocb {
 struct file *ki_filp;
 loff_t ki_pos;
 void (*ki_complete)(struct kiocb *iocb, long ret);
 void *private;
 int ki_flags;
 u16 ki_ioprio;
 u8 ki_write_stream;
 union {





  struct wait_page_queue *ki_waitq;
  ssize_t (*dio_complete)(void *data);
 };
};
struct address_space_operations {
 int (*read_folio)(struct file *, struct folio *);


 int (*writepages)(struct address_space *, struct writeback_control *);


 bool (*dirty_folio)(struct address_space *, struct folio *);

 void (*readahead)(struct readahead_control *);

 int (*write_begin)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len,
    struct folio **foliop, void **fsdata);
 int (*write_end)(const struct kiocb *, struct address_space *mapping,
    loff_t pos, unsigned len, unsigned copied,
    struct folio *folio, void *fsdata);


 sector_t (*bmap)(struct address_space *, sector_t);
 void (*invalidate_folio) (struct folio *, size_t offset, size_t len);
 bool (*release_folio)(struct folio *, gfp_t);
 void (*free_folio)(struct folio *folio);
 ssize_t (*direct_IO)(struct kiocb *, struct iov_iter *iter);




 int (*migrate_folio)(struct address_space *, struct folio *dst,
   struct folio *src, enum migrate_mode);
 int (*launder_folio)(struct folio *);
 bool (*is_partially_uptodate) (struct folio *, size_t from,
   size_t count);
 void (*is_dirty_writeback) (struct folio *, bool *dirty, bool *wb);
 int (*error_remove_folio)(struct address_space *, struct folio *);


 int (*swap_activate)(struct swap_info_struct *sis, struct file *file,
    sector_t *span);
 void (*swap_deactivate)(struct file *file);
 int (*swap_rw)(struct kiocb *iocb, struct iov_iter *iter);
};
struct address_space {
 struct inode *host;
 struct xarray i_pages;
 struct rw_semaphore invalidate_lock;
 gfp_t gfp_mask;
 atomic_t i_mmap_writable;


 atomic_t nr_thps;

 struct rb_root_cached i_mmap;
 unsigned long nrpages;
 unsigned long writeback_index;
 const struct address_space_operations *a_ops;
 unsigned long flags;
 errseq_t wb_err;
 spinlock_t i_private_lock;
 struct list_head i_private_list;
 struct rw_semaphore i_mmap_rwsem;
 void * i_private_data;
}  ;
struct posix_acl;
enum inode_state_bits {
 __I_NEW = 0U,
 __I_SYNC = 1U,
 __I_LRU_ISOLATING = 2U

};
enum inode_state_flags_t {
 I_NEW = (1U << __I_NEW),
 I_SYNC = (1U << __I_SYNC),
 I_LRU_ISOLATING = (1U << __I_LRU_ISOLATING),

 I_DIRTY_SYNC = (1U << 4),
 I_DIRTY_DATASYNC = (1U << 5),
 I_DIRTY_PAGES = (1U << 6),
 I_WILL_FREE = (1U << 7),
 I_FREEING = (1U << 8),
 I_CLEAR = (1U << 9),
 I_REFERENCED = (1U << 10),
 I_LINKABLE = (1U << 11),
 I_DIRTY_TIME = (1U << 12),
 I_WB_SWITCH = (1U << 13),
 I_OVL_INUSE = (1U << 14),
 I_CREATING = (1U << 15),
 I_DONTCACHE = (1U << 16),
 I_SYNC_QUEUED = (1U << 17),
 I_PINNING_NETFS_WB = (1U << 18)
};
struct inode {
 umode_t i_mode;
 unsigned short i_opflags;
 kuid_t i_uid;
 kgid_t i_gid;
 unsigned int i_flags;


 struct posix_acl *i_acl;
 struct posix_acl *i_default_acl;


 const struct inode_operations *i_op;
 struct super_block *i_sb;
 struct address_space *i_mapping;


 void *i_security;



 unsigned long i_ino;







 union {
  const unsigned int i_nlink;
  unsigned int __i_nlink;
 };
 dev_t i_rdev;
 loff_t i_size;
 time64_t i_atime_sec;
 time64_t i_mtime_sec;
 time64_t i_ctime_sec;
 u32 i_atime_nsec;
 u32 i_mtime_nsec;
 u32 i_ctime_nsec;
 u32 i_generation;
 spinlock_t i_lock;
 unsigned short i_bytes;
 u8 i_blkbits;
 enum rw_hint i_write_hint;
 blkcnt_t i_blocks;






 enum inode_state_flags_t i_state;

 struct rw_semaphore i_rwsem;

 unsigned long dirtied_when;
 unsigned long dirtied_time_when;

 struct hlist_node i_hash;
 struct list_head i_io_list;

 struct bdi_writeback *i_wb;


 int i_wb_frn_winner;
 u16 i_wb_frn_avg_time;
 u16 i_wb_frn_history;

 struct list_head i_lru;
 struct list_head i_sb_list;
 struct list_head i_wb_list;
 union {
  struct hlist_head i_dentry;
  struct callback_head i_rcu;
 };
 atomic64_t i_version;
 atomic64_t i_sequence;
 atomic_t i_count;
 atomic_t i_dio_count;
 atomic_t i_writecount;

 atomic_t i_readcount;

 union {
  const struct file_operations *i_fop;
  void (*free_inode)(struct inode *);
 };
 struct file_lock_context *i_flctx;
 struct address_space i_data;
 union {
  struct list_head i_devices;
  int i_linklen;
 };
 union {
  struct pipe_inode_info *i_pipe;
  struct cdev *i_cdev;
  char *i_link;
  unsigned i_dir_seq;
 };



 __u32 i_fsnotify_mask;

 struct fsnotify_mark_connector *i_fsnotify_marks;


 void *i_private;
} ;
struct fown_struct {
 struct file *file;
 rwlock_t lock;
 struct pid *pid;
 enum pid_type pid_type;
 kuid_t uid, euid;
 int signum;
};
struct file_ra_state {
 unsigned long start;
 unsigned int size;
 unsigned int async_size;
 unsigned int ra_pages;
 unsigned short order;
 unsigned short mmap_miss;
 loff_t prev_pos;
};
struct file {
 spinlock_t f_lock;
 fmode_t f_mode;
 const struct file_operations *f_op;
 struct address_space *f_mapping;
 void *private_data;
 struct inode *f_inode;
 unsigned int f_flags;
 unsigned int f_iocb_flags;
 const struct cred *f_cred;
 struct fown_struct *f_owner;

 union {
  const struct path f_path;
  struct path __f_path;
 };
 union {

  struct mutex f_pos_lock;

  u64 f_pipe;
 };
 loff_t f_pos;

 void *f_security;


 errseq_t f_wb_err;
 errseq_t f_sb_err;

 struct hlist_head *f_ep;

 union {
  struct callback_head f_task_work;
  struct llist_node f_llist;
  struct file_ra_state f_ra;
  freeptr_t f_freeptr;
 };
 file_ref_t f_ref;

} 
  ;
typedef void *fl_owner_t;
struct file_lock;
struct file_lease;
enum {
 SB_UNFROZEN = 0,
 SB_FREEZE_WRITE = 1,
 SB_FREEZE_PAGEFAULT = 2,
 SB_FREEZE_FS = 3,

 SB_FREEZE_COMPLETE = 4,
};
struct sb_writers {
 unsigned short frozen;
 int freeze_kcount;
 int freeze_ucount;
 const void *freeze_owner;
 struct percpu_rw_semaphore rw_sem[(SB_FREEZE_COMPLETE - 1)];
};
struct mount;
struct super_block {
 struct list_head s_list;
 dev_t s_dev;
 unsigned char s_blocksize_bits;
 unsigned long s_blocksize;
 loff_t s_maxbytes;
 struct file_system_type *s_type;
 const struct super_operations *s_op;
 const struct dquot_operations *dq_op;
 const struct quotactl_ops *s_qcop;
 const struct export_operations *s_export_op;
 unsigned long s_flags;
 unsigned long s_iflags;
 unsigned long s_magic;
 struct dentry *s_root;
 struct rw_semaphore s_umount;
 int s_count;
 atomic_t s_active;

 void *s_security;

 const struct xattr_handler * const *s_xattr;

 const struct fscrypt_operations *s_cop;
 struct fscrypt_keyring *s_master_keys;


 const struct fsverity_operations *s_vop;


 struct unicode_map *s_encoding;
 __u16 s_encoding_flags;

 struct hlist_bl_head s_roots;
 struct mount *s_mounts;
 struct block_device *s_bdev;
 struct file *s_bdev_file;
 struct backing_dev_info *s_bdi;
 struct mtd_info *s_mtd;
 struct hlist_node s_instances;
 unsigned int s_quota_types;
 struct quota_info s_dquot;

 struct sb_writers s_writers;






 void *s_fs_info;


 u32 s_time_gran;

 time64_t s_time_min;
 time64_t s_time_max;

 u32 s_fsnotify_mask;
 struct fsnotify_sb_info *s_fsnotify_info;
 char s_id[32];
 uuid_t s_uuid;
 u8 s_uuid_len;


 char s_sysfs_name[36 + 1];

 unsigned int s_max_links;
 unsigned int s_d_flags;





 struct mutex s_vfs_rename_mutex;





 const char *s_subtype;

 const struct dentry_operations *__s_d_op;

 struct shrinker *s_shrink;


 atomic_long_t s_remove_count;


 int s_readonly_remount;


 errseq_t s_wb_err;


 struct workqueue_struct *s_dio_done_wq;
 struct hlist_head s_pins;






 struct user_namespace *s_user_ns;






 struct list_lru s_dentry_lru;
 struct list_lru s_inode_lru;
 struct callback_head rcu;
 struct work_struct destroy_work;

 struct mutex s_sync_lock;




 int s_stack_depth;


 spinlock_t s_inode_list_lock ;
 struct list_head s_inodes;

 spinlock_t s_inode_wblist_lock;
 struct list_head s_inodes_wb;
} ;
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *, const char *, int, loff_t, u64,
    unsigned);
struct dir_context {
 filldir_t actor;
 loff_t pos;






 int count;

 unsigned int dt_flags_mask;
};
struct iov_iter;
struct io_uring_cmd;
struct offset_ctx;
typedef unsigned int fop_flags_t;
struct file_operations {
 struct module *owner;
 fop_flags_t fop_flags;
 loff_t (*llseek) (struct file *, loff_t, int);
 ssize_t (*read) (struct file *, char *, size_t, loff_t *);
 ssize_t (*write) (struct file *, const char *, size_t, loff_t *);
 ssize_t (*read_iter) (struct kiocb *, struct iov_iter *);
 ssize_t (*write_iter) (struct kiocb *, struct iov_iter *);
 int (*iopoll)(struct kiocb *kiocb, struct io_comp_batch *,
   unsigned int flags);
 int (*iterate_shared) (struct file *, struct dir_context *);
 __poll_t (*poll) (struct file *, struct poll_table_struct *);
 long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
 long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
 int (*mmap) (struct file *, struct vm_area_struct *);
 int (*open) (struct inode *, struct file *);
 int (*flush) (struct file *, fl_owner_t id);
 int (*release) (struct inode *, struct file *);
 int (*fsync) (struct file *, loff_t, loff_t, int datasync);
 int (*fasync) (int, struct file *, int);
 int (*lock) (struct file *, int, struct file_lock *);
 unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
 int (*check_flags)(int);
 int (*flock) (struct file *, int, struct file_lock *);
 ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
 ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
 void (*splice_eof)(struct file *file);
 int (*setlease)(struct file *, int, struct file_lease **, void **);
 long (*fallocate)(struct file *file, int mode, loff_t offset,
     loff_t len);
 void (*show_fdinfo)(struct seq_file *m, struct file *f);



 ssize_t (*copy_file_range)(struct file *, loff_t, struct file *,
   loff_t, size_t, unsigned int);
 loff_t (*remap_file_range)(struct file *file_in, loff_t pos_in,
       struct file *file_out, loff_t pos_out,
       loff_t len, unsigned int remap_flags);
 int (*fadvise)(struct file *, loff_t, loff_t, int);
 int (*uring_cmd)(struct io_uring_cmd *ioucmd, unsigned int issue_flags);
 int (*uring_cmd_iopoll)(struct io_uring_cmd *, struct io_comp_batch *,
    unsigned int poll_flags);
 int (*mmap_prepare)(struct vm_area_desc *);
} ;
struct inode_operations {
 struct dentry * (*lookup) (struct inode *,struct dentry *, unsigned int);
 const char * (*get_link) (struct dentry *, struct inode *, struct delayed_call *);
 int (*permission) (struct mnt_idmap *, struct inode *, int);
 struct posix_acl * (*get_inode_acl)(struct inode *, int, bool);

 int (*readlink) (struct dentry *, char *,int);

 int (*create) (struct mnt_idmap *, struct inode *,struct dentry *,
         umode_t, bool);
 int (*link) (struct dentry *,struct inode *,struct dentry *);
 int (*unlink) (struct inode *,struct dentry *);
 int (*symlink) (struct mnt_idmap *, struct inode *,struct dentry *,
   const char *);
 struct dentry *(*mkdir) (struct mnt_idmap *, struct inode *,
     struct dentry *, umode_t);
 int (*rmdir) (struct inode *,struct dentry *);
 int (*mknod) (struct mnt_idmap *, struct inode *,struct dentry *,
        umode_t,dev_t);
 int (*rename) (struct mnt_idmap *, struct inode *, struct dentry *,
   struct inode *, struct dentry *, unsigned int);
 int (*setattr) (struct mnt_idmap *, struct dentry *, struct iattr *);
 int (*getattr) (struct mnt_idmap *, const struct path *,
   struct kstat *, u32, unsigned int);
 ssize_t (*listxattr) (struct dentry *, char *, size_t);
 int (*fiemap)(struct inode *, struct fiemap_extent_info *, u64 start,
        u64 len);
 int (*update_time)(struct inode *, int);
 int (*atomic_open)(struct inode *, struct dentry *,
      struct file *, unsigned open_flag,
      umode_t create_mode);
 int (*tmpfile) (struct mnt_idmap *, struct inode *,
   struct file *, umode_t);
 struct posix_acl *(*get_acl)(struct mnt_idmap *, struct dentry *,
         int);
 int (*set_acl)(struct mnt_idmap *, struct dentry *,
         struct posix_acl *, int);
 int (*fileattr_set)(struct mnt_idmap *idmap,
       struct dentry *dentry, struct file_kattr *fa);
 int (*fileattr_get)(struct dentry *dentry, struct file_kattr *fa);
 struct offset_ctx *(*get_offset_ctx)(struct inode *inode);
} ;
enum freeze_holder {
 FREEZE_HOLDER_KERNEL = (1U << 0),
 FREEZE_HOLDER_USERSPACE = (1U << 1),
 FREEZE_MAY_NEST = (1U << 2),
 FREEZE_EXCL = (1U << 3),
};
struct super_operations {
    struct inode *(*alloc_inode)(struct super_block *sb);
 void (*destroy_inode)(struct inode *);
 void (*free_inode)(struct inode *);

    void (*dirty_inode) (struct inode *, int flags);
 int (*write_inode) (struct inode *, struct writeback_control *wbc);
 int (*drop_inode) (struct inode *);
 void (*evict_inode) (struct inode *);
 void (*put_super) (struct super_block *);
 int (*sync_fs)(struct super_block *sb, int wait);
 int (*freeze_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*freeze_fs) (struct super_block *);
 int (*thaw_super) (struct super_block *, enum freeze_holder who, const void *owner);
 int (*unfreeze_fs) (struct super_block *);
 int (*statfs) (struct dentry *, struct kstatfs *);
 int (*remount_fs) (struct super_block *, int *, char *);
 void (*umount_begin) (struct super_block *);

 int (*show_options)(struct seq_file *, struct dentry *);
 int (*show_devname)(struct seq_file *, struct dentry *);
 int (*show_path)(struct seq_file *, struct dentry *);
 int (*show_stats)(struct seq_file *, struct dentry *);

 ssize_t (*quota_read)(struct super_block *, int, char *, size_t, loff_t);
 ssize_t (*quota_write)(struct super_block *, int, const char *, size_t, loff_t);
 struct dquot **(*get_dquots)(struct inode *);

 long (*nr_cached_objects)(struct super_block *,
      struct shrink_control *);
 long (*free_cached_objects)(struct super_block *,
        struct shrink_control *);
 int (*remove_bdev)(struct super_block *sb, struct block_device *bdev);
 void (*shutdown)(struct super_block *sb);
};
struct file_system_type {
 const char *name;
 int fs_flags;
 int (*init_fs_context)(struct fs_context *);
 const struct fs_parameter_spec *parameters;
 struct dentry *(*mount) (struct file_system_type *, int,
         const char *, void *);
 void (*kill_sb) (struct super_block *);
 struct module *owner;
 struct file_system_type * next;
 struct hlist_head fs_supers;

 struct lock_class_key s_lock_key;
 struct lock_class_key s_umount_key;
 struct lock_class_key s_vfs_rename_key;
 struct lock_class_key s_writers_key[(SB_FREEZE_COMPLETE - 1)];

 struct lock_class_key i_lock_key;
 struct lock_class_key i_mutex_key;
 struct lock_class_key invalidate_lock_key;
 struct lock_class_key i_mutex_dir_key;
};
int freeze_super(struct super_block *super, enum freeze_holder who,
   const void *freeze_owner);
int thaw_super(struct super_block *super, enum freeze_holder who,
        const void *freeze_owner);
extern int bmap(struct inode *inode, sector_t *block);
struct inode *alloc_inode(struct super_block *sb);
struct offset_ctx {
 struct maple_tree mt;
 unsigned long next_offset;
};
struct ctl_table;
struct file;
struct vmem_altmap {
 unsigned long base_pfn;
 const unsigned long end_pfn;
 const unsigned long reserve;
 unsigned long free;
 unsigned long align;
 unsigned long alloc;
 bool inaccessible;
};
enum memory_type {

 MEMORY_DEVICE_PRIVATE = 1,
 MEMORY_DEVICE_COHERENT,
 MEMORY_DEVICE_FS_DAX,
 MEMORY_DEVICE_GENERIC,
 MEMORY_DEVICE_PCI_P2PDMA,
};
struct dev_pagemap_ops {





 void (*page_free)(struct page *page);





 vm_fault_t (*migrate_to_ram)(struct vm_fault *vmf);
 int (*memory_failure)(struct dev_pagemap *pgmap, unsigned long pfn,
         unsigned long nr_pages, int mf_flags);
};
struct dev_pagemap {
 struct vmem_altmap altmap;
 struct percpu_ref ref;
 struct completion done;
 enum memory_type type;
 unsigned int flags;
 unsigned long vmemmap_shift;
 const struct dev_pagemap_ops *ops;
 void *owner;
 int nr_range;
 union {
  struct range range;
  struct { struct { } __empty_ranges; struct range ranges[1]; };
 };
};
struct mempolicy;
struct anon_vma;
struct anon_vma_chain;
struct user_struct;
struct vm_fault {
 const struct {
  struct vm_area_struct *vma;
  gfp_t gfp_mask;
  unsigned long pgoff;
  unsigned long address;
  unsigned long real_address;
 };
 enum fault_flag flags;

 pmd_t *pmd;

 pud_t *pud;


 union {
  pte_t orig_pte;
  pmd_t orig_pmd;


 };

 struct page *cow_page;
 struct page *page;





 pte_t *pte;



 spinlock_t *ptl;



 pgtable_t prealloc_pte;






};
struct vm_operations_struct {
 void (*open)(struct vm_area_struct * area);




 void (*close)(struct vm_area_struct * area);

 int (*may_split)(struct vm_area_struct *area, unsigned long addr);
 int (*mremap)(struct vm_area_struct *area);





 int (*mprotect)(struct vm_area_struct *vma, unsigned long start,
   unsigned long end, unsigned long newflags);
 vm_fault_t (*fault)(struct vm_fault *vmf);
 vm_fault_t (*huge_fault)(struct vm_fault *vmf, unsigned int order);
 vm_fault_t (*map_pages)(struct vm_fault *vmf,
   unsigned long start_pgoff, unsigned long end_pgoff);
 unsigned long (*pagesize)(struct vm_area_struct * area);



 vm_fault_t (*page_mkwrite)(struct vm_fault *vmf);


 vm_fault_t (*pfn_mkwrite)(struct vm_fault *vmf);





 int (*access)(struct vm_area_struct *vma, unsigned long addr,
        void *buf, int len, int write);




 const char *(*name)(struct vm_area_struct *vma);
 int (*set_policy)(struct vm_area_struct *vma, struct mempolicy *new);
 struct mempolicy *(*get_policy)(struct vm_area_struct *vma,
     unsigned long addr, unsigned long *ilx);
 struct page *(*find_normal_page)(struct vm_area_struct *vma,
      unsigned long addr);

};
struct inode;
struct file;
struct dentry;
struct iattr;
struct seq_file;
struct vm_area_struct;
struct vm_operations_struct;
struct super_block;
struct file_system_type;
struct poll_table_struct;
struct fs_context;
struct module;
struct file;
struct vm_area_struct;
struct address_space;
static inline    unsigned long
get_unmapped_area(struct file *file, unsigned long addr, unsigned long len,
    unsigned long pgoff, unsigned long flags)
;
struct vmem_altmap;
enum mf_flags {
 MF_COUNT_INCREASED = 1 << 0,
 MF_ACTION_REQUIRED = 1 << 1,
 MF_MUST_KILL = 1 << 2,
 MF_SOFT_OFFLINE = 1 << 3,
 MF_UNPOISON = 1 << 4,
 MF_SW_SIMULATED = 1 << 5,
 MF_NO_RETRY = 1 << 6,
 MF_MEM_PRE_REMOVE = 1 << 7,
};
extern int memory_failure(unsigned long pfn, int flags);
struct mnt_namespace;
struct uts_namespace;
struct ipc_namespace;
struct pid_namespace;
struct cgroup_namespace;
struct fs_struct;
struct nsproxy {
 refcount_t count;
 struct uts_namespace *uts_ns;
 struct ipc_namespace *ipc_ns;
 struct mnt_namespace *mnt_ns;
 struct pid_namespace *pid_ns_for_children;
 struct net *net_ns;
 struct time_namespace *time_ns;
 struct time_namespace *time_ns_for_children;
 struct cgroup_namespace *cgroup_ns;
};
struct proc_ns_operations;
struct cgroup_namespace;
struct ipc_namespace;
struct mnt_namespace;
struct net;
struct pid_namespace;
struct time_namespace;
struct user_namespace;
struct uts_namespace;
struct ns_common {
 u32 ns_type;
 struct dentry *stashed;
 const struct proc_ns_operations *ops;
 unsigned int inum;
 refcount_t __ns_ref;
 union {
  struct {
   u64 ns_id;
   struct rb_node ns_tree_node;
   struct list_head ns_list_node;
  };
  struct callback_head ns_rcu;
 };
};
struct uid_gid_extent {
 u32 first;
 u32 lower_first;
 u32 count;
};
struct uid_gid_map {
 union {
  struct {
   struct uid_gid_extent extent[5];
   u32 nr_extents;
  };
  struct {
   struct uid_gid_extent *forward;
   struct uid_gid_extent *reverse;
  };
 };
};
struct ucounts;
enum ucount_type {
 UCOUNT_USER_NAMESPACES,
 UCOUNT_PID_NAMESPACES,
 UCOUNT_UTS_NAMESPACES,
 UCOUNT_IPC_NAMESPACES,
 UCOUNT_NET_NAMESPACES,
 UCOUNT_MNT_NAMESPACES,
 UCOUNT_CGROUP_NAMESPACES,
 UCOUNT_TIME_NAMESPACES,

 UCOUNT_INOTIFY_INSTANCES,
 UCOUNT_INOTIFY_WATCHES,


 UCOUNT_FANOTIFY_GROUPS,
 UCOUNT_FANOTIFY_MARKS,

 UCOUNT_COUNTS,
};
enum rlimit_type {
 UCOUNT_RLIMIT_NPROC,
 UCOUNT_RLIMIT_MSGQUEUE,
 UCOUNT_RLIMIT_SIGPENDING,
 UCOUNT_RLIMIT_MEMLOCK,
 UCOUNT_RLIMIT_COUNTS,
};
struct binfmt_misc;
struct user_namespace {
 struct uid_gid_map uid_map;
 struct uid_gid_map gid_map;
 struct uid_gid_map projid_map;
 struct user_namespace *parent;
 int level;
 kuid_t owner;
 kgid_t group;
 struct ns_common ns;
 unsigned long flags;


 bool parent_could_setfcap;







 struct list_head keyring_name_list;
 struct key *user_keyring_register;
 struct rw_semaphore keyring_sem;




 struct key *persistent_keyring_register;

 struct work_struct work;

 struct ctl_table_set set;
 struct ctl_table_header *sysctls;

 struct ucounts *ucounts;
 long ucount_max[UCOUNT_COUNTS];
 long rlimit_max[UCOUNT_RLIMIT_COUNTS];


 struct binfmt_misc *binfmt_misc;

} ;
struct ucounts {
 struct hlist_nulls_node node;
 struct user_namespace *ns;
 kuid_t uid;
 struct callback_head rcu;
 rcuref_t count;
 atomic_long_t ucount[UCOUNT_COUNTS];
 atomic_long_t rlimit[UCOUNT_RLIMIT_COUNTS];
};
struct inode;
struct dentry;
struct xattr_handler {
 const char *name;
 const char *prefix;
 int flags;
 bool (*list)(struct dentry *dentry);
 int (*get)(const struct xattr_handler *, struct dentry *dentry,
     struct inode *inode, const char *name, void *buffer,
     size_t size);
 int (*set)(const struct xattr_handler *,
     struct mnt_idmap *idmap, struct dentry *dentry,
     struct inode *inode, const char *name, const void *buffer,
     size_t size, int flags);
};
struct dentry;
struct iattr;
struct inode;
struct iomap;
struct super_block;
struct vfsmount;
struct fid {
 union {
  struct {
   u32 ino;
   u32 gen;
   u32 parent_ino;
   u32 parent_gen;
  } i32;
  struct {
   u64 ino;
   u32 gen;
  } __attribute__((__packed__)) i64;
  struct {
    u32 block;
    u16 partref;
    u16 parent_partref;
    u32 generation;
    u32 parent_block;
    u32 parent_generation;
   } udf;
  struct { struct { } __empty_raw; __u32 raw[1]; };
 };
};
enum handle_to_path_flags {
 HANDLE_CHECK_PERMS = (1 << 0),
 HANDLE_CHECK_SUBTREE = (1 << 1),
};
struct handle_to_path_ctx {
 struct path root;
 enum handle_to_path_flags flags;
 unsigned int fh_flags;
};
struct export_operations {
 int (*encode_fh)(struct inode *inode, __u32 *fh, int *max_len,
   struct inode *parent);
 struct dentry * (*fh_to_dentry)(struct super_block *sb, struct fid *fid,
   int fh_len, int fh_type);
 struct dentry * (*fh_to_parent)(struct super_block *sb, struct fid *fid,
   int fh_len, int fh_type);
 int (*get_name)(struct dentry *parent, char *name,
   struct dentry *child);
 struct dentry * (*get_parent)(struct dentry *child);
 int (*commit_metadata)(struct inode *inode);

 int (*get_uuid)(struct super_block *sb, u8 *buf, u32 *len, u64 *offset);
 int (*map_blocks)(struct inode *inode, loff_t offset,
     u64 len, struct iomap *iomap,
     bool write, u32 *device_generation);
 int (*commit_blocks)(struct inode *inode, struct iomap *iomaps,
        int nr_iomaps, struct iattr *iattr);
 int (*permission)(struct handle_to_path_ctx *ctx, unsigned int oflags);
 struct file * (*open)(const struct path *path, unsigned int oflags);


 unsigned long flags;
};
struct file;
struct file_operations;
struct task_struct;
struct vfsmount;
struct dentry;
struct inode;
struct path;
struct file_kattr {
 u32 flags;

 u32 fsx_xflags;
 u32 fsx_extsize;
 u32 fsx_nextents;
 u32 fsx_projid;
 u32 fsx_cowextsize;

 bool flags_valid:1;
 bool fsx_valid:1;
};
struct module;
struct fsverity_operations {





 ptrdiff_t inode_info_offs;
 int (*begin_enable_verity)(struct file *filp);
 int (*end_enable_verity)(struct file *filp, const void *desc,
     size_t desc_size, u64 merkle_tree_size);
 int (*get_verity_descriptor)(struct inode *inode, void *buf,
         size_t bufsize);
 struct page *(*read_merkle_tree_page)(struct inode *inode,
           unsigned long index,
           unsigned long num_ra_pages);
 int (*write_merkle_tree_block)(struct inode *inode, const void *buf,
           u64 pos, unsigned int size);
};
struct user_namespace;
struct posix_acl_entry {
 short e_tag;
 unsigned short e_perm;
 union {
  kuid_t e_uid;
  kgid_t e_gid;
 };
};
struct posix_acl {

 union { struct { refcount_t a_refcount; unsigned int a_count; struct callback_head a_rcu; } ; struct posix_acl_hdr { refcount_t a_refcount; unsigned int a_count; struct callback_head a_rcu; } hdr; }



  ;
 struct posix_acl_entry a_entries[1] ;
};
struct posix_acl *get_inode_acl(struct inode *inode, int type);
struct ovl_config {
 char *upperdir;
 char *workdir;
 char **lowerdirs;
 bool default_permissions;
 int redirect_mode;
 int verity_mode;
 bool index;
 int uuid;
 bool nfs_export;
 int xino;
 bool metacopy;
 bool userxattr;
 int fsync_mode;
};
struct ovl_sb {
 struct super_block *sb;
 dev_t pseudo_dev;

 bool bad_uuid;

 bool is_lower;
};
struct ovl_layer {

 struct vfsmount *mnt;

 struct inode *trap;
 struct ovl_sb *fs;

 int idx;

 int fsid;

 bool has_xwhiteouts;
};
struct ovl_fs {
 unsigned int numlayer;

 unsigned int numfs;

 unsigned int numdatalayer;
 struct ovl_layer *layers;
 struct ovl_sb *fs;

 struct dentry *workbasedir;

 struct dentry *workdir;
 long namelen;

 struct ovl_config config;

 const struct cred *creator_cred;
 bool tmpfile;
 bool noxattr;
 bool nofh;

 bool upperdir_locked;
 bool workdir_locked;

 struct inode *workbasedir_trap;
 struct inode *workdir_trap;

 int xino_mode;

 atomic_long_t last_ino;

 struct dentry *whiteout;
 bool no_shared_whiteout;
 struct mutex whiteout_lock;

 errseq_t errseq;
 bool casefold;
};
static inline    struct vfsmount *ovl_upper_mnt(struct ovl_fs *ofs)
;
static inline    struct ovl_fs *OVL_FS(struct super_block *sb)
;
int ovl_get_write_access(struct dentry *dentry);
/*@ requires true; ensures \result == 0 || \result < 0; */

int ovl_get_write_access(struct dentry *dentry)
{
 struct ovl_fs *ofs = OVL_FS(dentry->d_sb);
 return mnt_get_write_access(ovl_upper_mnt(ofs));
}

/* ---- bit-vector harness generated by acsl2bv (see acsl2bv.cpp for the semantics) ---- */
void __CPROVER_assume(int); void __CPROVER_assert(int, const char*);
static __int128 bv_chk(int ok, __int128 v) { __CPROVER_assert(ok, "contract arithmetic stays inside 128 bits"); return v; }
static __int128 bv_add(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_add_overflow(a, b, &r), r); }
static __int128 bv_sub(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_sub_overflow(a, b, &r), r); }
static __int128 bv_mul(__int128 a, __int128 b) { __int128 r; return bv_chk(!__builtin_mul_overflow(a, b, &r), r); }
static __int128 bv_neg(__int128 a) { __int128 r; return bv_chk(!__builtin_sub_overflow((__int128)0, a, &r), r); }
static __int128 bv_div(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "division by zero in contract"); return b == 0 ? 0 : a / b; }
static __int128 bv_mod(__int128 a, __int128 b) { __CPROVER_assert(b != 0, "modulo by zero in contract"); return b == 0 ? 0 : a % b; }
static __int128 bv_shl(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); __int128 r; if (n < 0 || n >= 100) return 0; return bv_chk(!__builtin_mul_overflow(a, ((__int128)1) << n, &r), r); }
static __int128 bv_shr(__int128 a, __int128 n) { __CPROVER_assert(n >= 0 && n < 100, "shift count in contract"); if (n < 0 || n >= 100) return 0; return a >> n; }
int main(void) {
  struct dentry * dentry;
  __CPROVER_assume(((((__int128)1)) != 0));
  extern void *malloc(unsigned long);
  { int c_dentry; dentry = c_dentry ? 0 : malloc(sizeof(struct dentry)); }
  int bv_r = ovl_get_write_access(dentry);
  __CPROVER_assert((((__int128)((((__int128)(((__int128)bv_r) == ((__int128)0ULL))) != 0) || ((((__int128)(((__int128)bv_r) < ((__int128)0ULL)))) != 0))) != 0), "ensures");
  return 0;
}
