enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
static bool __is_raid10_far(int layout);
static unsigned int __raid10_far_copies(int layout)
;
static bool __is_raid10_offset(int layout)
;
/*@ requires true; ensures \result == (!(layout & (1 << 16)) && ((layout >> 8) & 0xFF) > 1); */

static bool __is_raid10_far(int layout)
{
 return !__is_raid10_offset(layout) && __raid10_far_copies(layout) > 1;
}
