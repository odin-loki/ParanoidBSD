typedef _Bool bool;
static inline    bool perfmon_capable(void)
;
extern int security_perf_event_open(int type);
extern int sysctl_perf_event_paranoid;
extern int perf_allow_kernel(void);
int sysctl_perf_event_paranoid  = 2;
/*@ requires sysctl_perf_event_paranoid >= 0; ensures \result == 0 || \result < 0; */

int perf_allow_kernel(void)
{
 if (sysctl_perf_event_paranoid > 1 && !perfmon_capable())
  return -13;

 return security_perf_event_open(2);
}
extern typeof(perf_allow_kernel) perf_allow_kernel;
