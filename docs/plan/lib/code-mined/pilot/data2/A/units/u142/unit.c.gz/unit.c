typedef unsigned int insn_attr_t;
/*@ requires true; ensures \result == ((attr & (((1 << 5) - 1) << ((0 + 5) + 2))) >> ((0 + 5) + 2)); */

static inline int inat_group_id(insn_attr_t attr)
{
 return (attr & (((1 << 5) - 1) << ((0 + 5) + 2))) >> ((0 + 5) + 2);
}
