typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef __u8 u8;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef __u16 __le16;
typedef _Bool bool;
struct regmap;
int regmap_write(struct regmap *map, unsigned int reg, unsigned int val);
struct regmap;
struct adxl345_chip_info {
 const char *name;
 int uscale;
};
struct adxl345_state {
 const struct adxl345_chip_info *info;
 struct regmap *regmap;
 bool fifo_delay;
 u8 watermark;
 u8 fifo_mode;

 u8 inact_threshold;
 u32 inact_time_ms;

 u32 tap_duration_us;
 u32 tap_latent_us;
 u32 tap_window_us;

 __le16 fifo_buf[3 * 32 + 1] ;
};
/*@ requires true; ensures \result == 0 || \result < 0; */

static int adxl345_set_freefall_time(struct adxl345_state *st, u32 val_fract)
{





 st->inact_time_ms = (((val_fract) + (1000UL) - 1) / (1000UL));

 return regmap_write(st->regmap, 0x29,
       ( { typeof(val_fract) __x = val_fract; typeof(5) __d = 5; (((typeof(val_fract))-1) > 0 || ((typeof(5))-1) > 0 || (((__x) > 0) == ((__d) > 0))) ? (((__x) + ((__d) / 2)) / (__d)) : (((__x) - ((__d) / 2)) / (__d)); } ));
}
