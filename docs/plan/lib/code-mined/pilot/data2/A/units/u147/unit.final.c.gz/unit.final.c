enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == ((prot & ~(0x1 | 0x2 | 0x4 | 0x8)) == 0); */

static inline    bool arch_validate_prot(unsigned long prot, unsigned long addr)
{
 return (prot & ~(0x1 | 0x2 | 0x4 | 0x8)) == 0;
}
