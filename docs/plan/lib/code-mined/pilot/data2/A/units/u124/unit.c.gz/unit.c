typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long __int64_t;
typedef unsigned long __uint64_t;
typedef __int64_t __intmax_t;
typedef __uint64_t __uintptr_t;
typedef __uint64_t __vm_offset_t;
typedef __uint64_t __vm_size_t;
typedef __uint64_t __size_t;
typedef __int64_t __ssize_t;
typedef __int64_t __register_t;
typedef __int64_t __time_t;
typedef __uint64_t __vm_paddr_t;
typedef __uint32_t __gid_t;
typedef __int32_t __lwpid_t;
typedef __uint16_t __mode_t;
typedef __int64_t __off_t;
typedef __int32_t __pid_t;
typedef __int64_t __sbintime_t;
typedef __int64_t __rlim_t;
typedef long __suseconds_t;
typedef __uint32_t __uid_t;
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __uintptr_t uintptr_t;
typedef __intmax_t intmax_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef char * caddr_t;
typedef __gid_t gid_t;
typedef __lwpid_t lwpid_t;
typedef __mode_t mode_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __register_t register_t;
typedef __rlim_t rlim_t;
typedef __sbintime_t sbintime_t;
typedef __size_t size_t;
typedef __ssize_t ssize_t;
typedef __suseconds_t suseconds_t;
typedef __time_t time_t;
typedef __uid_t uid_t;
typedef __vm_offset_t vm_offset_t;
typedef __uint64_t vm_ooffset_t;
typedef __vm_paddr_t vm_paddr_t;
typedef __vm_size_t vm_size_t;
typedef __register_t syscallarg_t;
typedef struct _device *device_t;
typedef char vm_memattr_t;
typedef struct __sigset {
 __uint32_t __bits[4];
} __sigset_t;
struct timeval {
 time_t tv_sec;
 suseconds_t tv_usec;
};
struct timespec {
 time_t tv_sec;
 long tv_nsec;
};
typedef __sigset_t sigset_t;
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
struct lock_object;
typedef void callout_func_t(void *);
struct callout {
 union {
  struct { struct callout *le_next; struct callout **le_prev; } le;
  struct { struct callout *sle_next; } sle;
  struct { struct callout *tqe_next; struct callout **tqe_prev; } tqe;
 } c_links;
 __sbintime_t c_time;
 __sbintime_t c_precision;
 void *c_arg;
 callout_func_t *c_func;
 struct lock_object *c_lock;
 short c_flags;
 short c_iflags;
 volatile int c_cpu;
};
struct region_descriptor;
struct lock_object {
 const char *lo_name;
 unsigned int lo_flags;
 unsigned int lo_data;
 struct witness *lo_witness;
};
struct mtx {
 struct lock_object lock_object;
 volatile __uintptr_t mtx_lock;
};
struct sx {
 struct lock_object lock_object;
 volatile __uintptr_t sx_lock;
};
struct thread;
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
 long ru_maxrss;
 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;
};
struct system_segment_descriptor {
 u_int64_t sd_lolimit:16;
 u_int64_t sd_lobase:24;
 u_int64_t sd_type:5;
 u_int64_t sd_dpl:2;
 u_int64_t sd_p:1;
 u_int64_t sd_hilimit:4;
 u_int64_t sd_xx0:3;
 u_int64_t sd_gran:1;
 u_int64_t sd_hibase:40 __attribute__((__packed__));
 u_int64_t sd_xx1:8;
 u_int64_t sd_mbz:5;
 u_int64_t sd_xx2:19;
} __attribute__((__packed__));
struct region_descriptor {
 uint64_t rd_limit:16;
 uint64_t rd_base:64 __attribute__((__packed__));
} __attribute__((__packed__));
struct amd64tss {
 u_int32_t tss_rsvd0;
 u_int64_t tss_rsp0 __attribute__((__packed__));
 u_int64_t tss_rsp1 __attribute__((__packed__));
 u_int64_t tss_rsp2 __attribute__((__packed__));
 u_int32_t tss_rsvd1;
 u_int32_t tss_rsvd2;
 u_int64_t tss_ist1 __attribute__((__packed__));
 u_int64_t tss_ist2 __attribute__((__packed__));
 u_int64_t tss_ist3 __attribute__((__packed__));
 u_int64_t tss_ist4 __attribute__((__packed__));
 u_int64_t tss_ist5 __attribute__((__packed__));
 u_int64_t tss_ist6 __attribute__((__packed__));
 u_int64_t tss_ist7 __attribute__((__packed__));
 u_int32_t tss_rsvd3;
 u_int32_t tss_rsvd4;
 u_int16_t tss_rsvd5;
 u_int16_t tss_iobase;
};
struct lock_object;
struct mtx;
struct proc;
struct thread;
struct tty;
struct ucred;
struct uio;
struct trapframe;
struct cdev;
void DELAY(int usec);
struct unrhdr;
struct lock_list_entry;
struct thread;
struct lock_profile_object;
struct lpohead { struct lock_profile_object *lh_first; };
struct mount;
struct vnode;
struct thread;
struct proc;
struct kevent {
 __uintptr_t ident;
 short filter;
 unsigned short flags;
 unsigned int fflags;
 __int64_t data;
 void *udata;
 __uint64_t ext[4];
};
struct knote;
struct klist { struct knote *slh_first; };
struct kqueue;
struct knlist {
 struct klist kl_list;
 void (*kl_lock)(void *);
 void (*kl_unlock)(void *);
 void (*kl_assert_lock)(void *, int);
 void *kl_lockarg;
 int kl_autodestroy;
};
struct kinfo_knote;
struct proc;
struct filterops {
 int f_isfd;
 int (*f_attach)(struct knote *kn);
 void (*f_detach)(struct knote *kn);
 int (*f_event)(struct knote *kn, long hint);
 void (*f_touch)(struct knote *kn, struct kevent *kev, u_long type);
 int (*f_userdump)(struct proc *p, struct knote *kn,
      struct kinfo_knote *kin);
 int (*f_copy)(struct knote *kn, struct proc *p1);
};
struct knote {
 struct { struct knote *sle_next; } kn_link;
 struct { struct knote *sle_next; } kn_selnext;
 struct knlist *kn_knlist;
 struct { struct knote *tqe_next; struct knote **tqe_prev; } kn_tqe;
 struct kqueue *kn_kq;
 struct kevent kn_kevent;
 void *kn_hook;
 int kn_hookid;
 int kn_status;
 int kn_influx;
 unsigned int kn_sfflags;
 int64_t kn_sdata;
 union {
  struct file *p_fp;
  struct proc *p_proc;
  struct kaiocb *p_aio;
  struct aioliojob *p_lio;
  struct prison *p_prison;
  void *p_v;
 } kn_ptr;
 const struct filterops *kn_fop;

};
struct thread;
struct proc;
struct knlist;
struct mtx;
void knote(struct knlist *list, long hint, int lockflags);
struct selfd;
struct selfdlist { struct selfd *tqh_first; struct selfd **tqh_last; };
struct selinfo {
 struct selfdlist si_tdlist;
 struct knlist si_note;
 struct mtx *si_mtx;
};
struct kexterr {
 int error;
 const char *msg;
 __uint64_t p1;
 __uint64_t p2;
 unsigned cat;
 unsigned src_line;
};
struct cv {
 const char *cv_description;
 int cv_waiters;
};
struct lock_object;
struct osd {
 u_int osd_nslots;
 void **osd_slots;
 struct { struct osd *le_next; struct osd **le_prev; } osd_next;
};
struct thread;
struct sigio {
 union {
  struct proc *siu_proc;
  struct pgrp *siu_pgrp;
 } sio_u;
 struct { struct sigio *sle_next; } sio_pgsigio;
 struct sigio **sio_myref;

 struct ucred *sio_ucred;
 pid_t sio_pgid;
};
struct sigiolst { struct sigio *slh_first; };
typedef struct sigaltstack stack_t;
struct sigaltstack {
 void *ss_sp;
 __size_t ss_size;
 int ss_flags;
};
union sigval {

 int sival_int;
 void *sival_ptr;

 int sigval_int;
 void *sigval_ptr;
};
typedef void __sighandler_t(int);
typedef struct __siginfo {
 int si_signo;
 int si_errno;






 int si_code;
 __pid_t si_pid;
 __uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 union {
  struct {
   int _trapno;
  } _fault;
  struct {
   int _timerid;
   int _overrun;
  } _timer;
  struct {
   int _mqd;
  } _mesgq;
  struct {
   long _band;
  } _poll;
  struct {
   int _syscall;



  } _capsicum;
  struct {
   long __spare1__;
   int __spare2__[7];
  } __spare__;
 } _reason;
} siginfo_t;
struct __siginfo;
typedef __sighandler_t *sig_t;
struct sigacts {
 sig_t ps_sigact[128];
 sigset_t ps_catchmask[128];
 sigset_t ps_sigonstack;
 sigset_t ps_sigintr;
 sigset_t ps_sigreset;
 sigset_t ps_signodefer;
 sigset_t ps_siginfo;
 sigset_t ps_sigignore;
 sigset_t ps_sigcatch;
 sigset_t ps_freebsd4;
 sigset_t ps_osigset;
 sigset_t ps_usertramp;
 int ps_flag;
 u_int ps_refcnt;
 struct mtx ps_mtx;
};
typedef struct ksiginfo {
 struct { struct ksiginfo *tqe_next; struct ksiginfo **tqe_prev; } ksi_link;
 siginfo_t ksi_info;
 int ksi_flags;
 struct sigqueue *ksi_sigq;
} ksiginfo_t;
typedef struct sigqueue {
 sigset_t sq_signals;
 sigset_t sq_kill;
 sigset_t sq_ptrace;
 struct { struct ksiginfo *tqh_first; struct ksiginfo **tqh_last; } sq_list;
 struct proc *sq_proc;
 int sq_flags;
} sigqueue_t;
struct pgrp;
struct proc;
struct sigio;
struct thread;
struct thread;
typedef uid_t au_id_t;
typedef pid_t au_asid_t;
typedef u_int64_t au_asflgs_t ;
struct au_tid_addr {
 u_int32_t at_port;
 u_int32_t at_type;
 u_int32_t at_addr[4];
};
typedef struct au_tid_addr au_tid_addr_t;
struct au_mask {
 unsigned int am_success;
 unsigned int am_failure;
};
typedef struct au_mask au_mask_t;
struct auditinfo_addr {
 au_id_t ai_auid;
 au_mask_t ai_mask;
 au_tid_addr_t ai_termid;
 au_asid_t ai_asid;
 au_asflgs_t ai_flags;
};
struct label;
struct loginclass;
struct prison;
struct uidinfo;
struct ucred {
 struct mtx cr_mtx;
 long cr_ref;
 u_int cr_users;
 u_int cr_flags;
 struct auditinfo_addr cr_audit;
 int cr_ngroups;
 uid_t cr_uid;
 uid_t cr_ruid;
 uid_t cr_svuid;
 gid_t cr_gid;
 gid_t cr_rgid;
 gid_t cr_svgid;
 struct uidinfo *cr_uidinfo;
 struct uidinfo *cr_ruidinfo;
 struct prison *cr_prison;
 struct loginclass *cr_loginclass;
 void *cr_pspare2[2];
 struct label *cr_label;
 gid_t *cr_groups;
 int cr_agroups;

 gid_t cr_smallgroups[16];
};
struct thread;
struct proc;
struct domainset;
struct domainset_ref {
 struct domainset * volatile dr_policy;
 unsigned int dr_iter;
};
struct fpacc87 {
 uint8_t fp_bytes[10];
};
struct xmmacc {
 uint8_t xmm_bytes[16];
};
struct envxmm {
 uint16_t en_cw;
 uint16_t en_sw;
 uint8_t en_tw;
 uint8_t en_zero;
 uint16_t en_opcode;
 uint64_t en_rip;
 uint64_t en_rdp;
 uint32_t en_mxcsr;
 uint32_t en_mxcsr_mask;
};
struct savefpu {
 struct envxmm sv_env;
 struct {
  struct fpacc87 fp_acc;
  uint8_t fp_pad[6];
 } sv_fp[8];
 struct xmmacc sv_xmm[16];
 uint8_t sv_pad[96];
} ;
struct pcb {
 register_t pcb_r15;
 register_t pcb_r14;
 register_t pcb_r13;
 register_t pcb_r12;
 register_t pcb_rbp;
 register_t pcb_rsp;
 register_t pcb_rbx;
 register_t pcb_rip;
 register_t pcb_fsbase;
 register_t pcb_gsbase;
 register_t pcb_kgsbase;
 register_t pcb_cr0;
 register_t pcb_cr2;
 register_t pcb_cr3;
 register_t pcb_cr4;
 register_t pcb_dr0;
 register_t pcb_dr1;
 register_t pcb_dr2;
 register_t pcb_dr3;
 register_t pcb_dr6;
 register_t pcb_dr7;

 struct region_descriptor pcb_gdt;
 struct region_descriptor pcb_idt;
 struct region_descriptor pcb_ldt;
 uint16_t pcb_tr;

 u_int pcb_flags;

 uint16_t pcb_initial_fpucw;


 caddr_t pcb_onfault;

 uint64_t pcb_saved_ucr3;


 struct amd64tss *pcb_tssp;


 register_t pcb_efer;
 register_t pcb_star;
 register_t pcb_lstar;
 register_t pcb_cstar;
 register_t pcb_sfmask;

 struct savefpu *pcb_save;

 register_t pcb_tlsbase;
 uint64_t pcb_pad[4];
};
struct trapframe;
struct proc_ldt {
 caddr_t ldt_base;
 int ldt_refcnt;
};
struct pmap_invl_gen {
 u_long gen;
 union {
  struct { struct pmap_invl_gen *le_next; struct pmap_invl_gen **le_prev; } link;
  struct {
   struct pmap_invl_gen *next;
   u_char saved_pri;
  };
 };
} ;
struct mdthread {
 int md_spinlock_count;
 register_t md_saved_flags;
 register_t md_spurflt_addr;
 struct pmap_invl_gen md_invl_gen;
 register_t md_efirt_tmp;
 int md_efirt_dis_pf;
 struct pcb md_pcb;
 vm_offset_t md_stack_base;
 void *md_usr_fpu_save;
};
struct mdproc {
 struct proc_ldt *md_ldt;
 struct system_segment_descriptor md_ldt_sd;
 u_int md_flags;
};
struct trapframe {
 register_t tf_rdi;
 register_t tf_rsi;
 register_t tf_rdx;
 register_t tf_rcx;
 register_t tf_r8;
 register_t tf_r9;
 register_t tf_rax;
 register_t tf_rbx;
 register_t tf_rbp;
 register_t tf_r10;
 register_t tf_r11;
 register_t tf_r12;
 register_t tf_r13;
 register_t tf_r14;
 register_t tf_r15;
 uint32_t tf_trapno;
 uint16_t tf_fs;
 uint16_t tf_gs;
 register_t tf_addr;
 uint32_t tf_flags;
 uint16_t tf_es;
 uint16_t tf_ds;

 register_t tf_err;
 register_t tf_rip;
 uint16_t tf_cs;
 uint16_t tf_fred_evinfo3;
 uint32_t tf_fred_zero2;
 register_t tf_rflags;

 register_t tf_rsp;
 uint16_t tf_ss;
 uint16_t tf_fred_evinfo1;
 uint32_t tf_fred_evinfo2;
};
struct session {
 u_int s_count;
 struct proc *s_leader;
 struct vnode *s_ttyvp;
 struct cdev_priv *s_ttydp;
 struct tty *s_ttyp;
 pid_t s_sid;

 char s_login[((((33)+((sizeof(long))-1))/(sizeof(long)))*(sizeof(long)))];
 struct mtx s_mtx;
};
struct pgrp {
 struct { struct pgrp *le_next; struct pgrp **le_prev; } pg_hash;
 struct { struct proc *lh_first; } pg_members;
 struct session *pg_session;
 struct sigiolst pg_sigiolst;
 pid_t pg_id;
 struct mtx pg_mtx;
 int pg_flags;
 struct sx pg_killsx;

};
struct pargs {
 u_int ar_ref;
 u_int ar_length;
 u_char ar_args[1];
};
struct cpuset;
struct filemon;
struct kaioinfo;
struct kaudit_record;
struct kcov_info;
struct kdtrace_proc;
struct kdtrace_thread;
struct kmsan_td;
struct kq_timer_cb_data;
struct mqueue_notifier;
struct proc;
struct procdesc;
struct racct;
struct sleepqueue;
struct thread;
struct trapframe;
struct turnstile;
struct vm_map;
struct vm_map_entry;
struct syscall_args {
 u_int code;
 u_int original_code;
 struct sysent *callp;
 register_t args[8];
};
struct rusage_ext {
 uint64_t rux_runtime;
 uint64_t rux_uticks;
 uint64_t rux_sticks;
 uint64_t rux_iticks;
 uint64_t rux_uu;
 uint64_t rux_su;
 uint64_t rux_tu;
};
struct thread {
 struct mtx *volatile td_lock;
 struct proc *td_proc;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_plist;
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_runq;
 union {
  struct { struct thread *tqe_next; struct thread **tqe_prev; } td_slpq;
  struct thread *td_zombie;
 };
 struct { struct thread *tqe_next; struct thread **tqe_prev; } td_lockq;
 struct { struct thread *le_next; struct thread **le_prev; } td_hash;
 struct cpuset *td_cpuset;
 struct domainset_ref td_domain;
 struct seltd *td_sel;
 struct sleepqueue *td_sleepqueue;
 struct turnstile *td_turnstile;
 void *td_pad1;
 struct umtx_q *td_umtxq;
 lwpid_t td_tid;
 sigqueue_t td_sigqueue;
 u_char td_lend_user_pri;
 u_char td_allocdomain;
 u_char td_base_ithread_pri;
 struct kmsan_td *td_kmsan;


 int td_flags;
 int td_ast;
 int td_inhibitors;
 int td_pflags;
 int td_pflags2;
 int td_dupfd;
 int td_sqqueue;
 const void *td_wchan;
 const char *td_wmesg;
 volatile u_char td_owepreempt;
 u_char td_tsqueue;
 u_char _td_pad0[2];
 int td_locks;
 int td_rw_rlocks;
 int td_sx_slocks;
 int td_lk_slocks;
 struct lock_object *td_wantedlock;
 struct turnstile *td_blocked;
 const char *td_lockname;
 struct { struct turnstile *lh_first; } td_contested;
 struct lock_list_entry *td_sleeplocks;
 int td_intr_nesting_level;
 int td_pinned;
 struct ucred *td_realucred;
 struct ucred *td_ucred;
 struct plimit *td_limit;
 int td_slptick;
 int td_blktick;
 int td_swvoltick;
 int td_swinvoltick;
 u_int td_cow;
 struct rusage td_ru;
 struct rusage_ext td_rux;
 uint64_t td_incruntime;
 uint64_t td_runtime;
 u_int td_pticks;
 u_int td_sticks;
 u_int td_iticks;
 u_int td_uticks;
 int td_intrval;
 sigset_t td_oldsigmask;
 volatile u_int td_generation;
 stack_t td_sigstk;
 int td_xsig;
 u_long td_profil_addr;
 u_int td_profil_ticks;
 char td_name[19 + 1];
 struct file *td_fpop;
 int td_dbgflags;
 siginfo_t td_si;
 int td_ng_outbound;
 struct osd td_osd;
 struct vm_map_entry *td_map_def_user;
 pid_t td_dbg_forked;
 u_int td_no_sleeping;
 struct vnode *td_vp_reserved;
 void *td_su;
 sbintime_t td_sleeptimo;
 int td_rtcgen;
 int td_errno;
 size_t td_vslock_sz;
 struct kcov_info *td_kcov_info;
 long td_ucredref;
 struct kexterr td_kexterr;


 sigset_t td_sigmask;
 u_char td_rqindex;
 u_char td_base_pri;
 u_char td_priority;
 u_char td_pri_class;
 u_char td_user_pri;
 u_char td_base_user_pri;
 uint32_t td_pax;
 uintptr_t td_rb_list;
 uintptr_t td_rbp_list;
 uintptr_t td_rb_inact;
 struct syscall_args td_sa;

 void *td_sigblock_ptr;
 uint32_t td_sigblock_val;

 void *td_exterr_ptr;





 struct pcb *td_pcb;
 enum td_states {
  TDS_INACTIVE = 0x0,
  TDS_INHIBITED,
  TDS_CAN_RUN,
  TDS_RUNQ,
  TDS_RUNNING
 } td_state;

 union {
  syscallarg_t tdu_retval[2];
  off_t tdu_off;
 } td_uretoff;
 u_int td_cowgen;

 struct callout td_slpcallout;
 struct trapframe *td_frame;
 vm_offset_t td_kstack;
 u_short td_kstack_pages;
 u_short td_kstack_domain;
 volatile u_int td_critnest;
 struct mdthread td_md;
 struct kaudit_record *td_ar;
 struct lpohead td_lprof[2];
 struct kdtrace_thread *td_dtrace;
 struct vnet *td_vnet;
 const char *td_vnet_lpush;
 struct trapframe *td_intr_frame;
 struct proc *td_rfppwait_p;
 struct vm_page **td_ma;
 int td_ma_cnt;

 void *td_emuldata;
 int td_lastcpu;
 int td_oncpu;
 void *td_lkpi_task;
 int td_pmcpend;
 void *td_remotereq;
 off_t td_ktr_io_lim;



};
struct proc {
 struct { struct proc *le_next; struct proc **le_prev; } p_list;
 struct { struct thread *tqh_first; struct thread **tqh_last; } p_threads;
 struct mtx p_slock;
 struct ucred *p_ucred;
 struct filedesc *p_fd;
 struct filedesc_to_leader *p_fdtol;
 struct pwddesc *p_pd;
 struct pstats *p_stats;
 struct plimit *p_limit;
 struct callout p_limco;
 struct sigacts *p_sigacts;

 int p_flag;
 int p_flag2;
 enum p_states {
  PRS_NEW = 0,
  PRS_NORMAL,
  PRS_ZOMBIE
 } p_state;
 pid_t p_pid;
 struct { struct proc *le_next; struct proc **le_prev; } p_hash;
 struct { struct proc *le_next; struct proc **le_prev; } p_pglist;
 struct proc *p_pptr;
 struct { struct proc *le_next; struct proc **le_prev; } p_sibling;
 struct { struct proc *lh_first; } p_children;
 struct proc *p_reaper;
 struct { struct proc *lh_first; } p_reaplist;

 struct { struct proc *le_next; struct proc **le_prev; } p_reapsibling;

 struct mtx p_mtx;
 struct mtx p_statmtx;
 struct mtx p_itimmtx;
 struct mtx p_profmtx;
 struct ksiginfo *p_ksi;
 sigqueue_t p_sigqueue;
 pid_t p_oppid;


 struct vmspace *p_vmspace;
 u_int p_swtick;
 u_int p_cowgen;
 struct itimerval p_realtimer;
 struct rusage p_ru;
 struct rusage_ext p_rux;
 struct rusage_ext p_crux;
 int p_profthreads;
 volatile int p_exitthreads;
 int p_traceflag;
 struct ktr_io_params *p_ktrioparms;
 struct vnode *p_textvp;
 struct vnode *p_textdvp;
 char *p_binname;
 u_int p_lock;
 struct sigiolst p_sigiolst;
 int p_sigparent;
 int p_sig;
 u_int p_ptevents;
 struct kaioinfo *p_aioinfo;
 struct thread *p_singlethread;
 int p_suspcount;
 struct thread *p_xthread;
 int p_boundary_count;
 int p_pendingcnt;
 struct itimers *p_itimers;
 struct procdesc *p_procdesc;
 u_int p_treeflag;
 int p_pendingexits;
 struct filemon *p_filemon;
 int p_pdeathsig;



 u_int p_magic;
 int p_osrel;

 uint32_t p_fctl0;
 char p_comm[19 + 1];
 struct sysentvec *p_sysent;
 struct pargs *p_args;
 rlim_t p_cpulimit;
 signed char p_nice;
 int p_fibnum;
 uint32_t p_pax;
 pid_t p_reapsubtree;


 vm_offset_t p_usrstack;
 vm_offset_t p_psstrings;
 vm_offset_t p_timekeep_base;
 vm_offset_t p_shared_page_base;
 vm_offset_t p_sigcode_base;
 vm_offset_t p_vdso_base;
 uint64_t p_elf_flags;
 const void *p_elf_brandinfo;

 sbintime_t p_umtx_min_timeout;


 u_int p_xexit;
 u_int p_xsig;
 struct pgrp *p_pgrp;
 struct knlist *p_klist;
 int p_numthreads;
 struct mdproc p_md;
 struct callout p_itcallout;
 u_short p_acflag;
 struct proc *p_peers;
 struct proc *p_leader;
 void *p_emuldata;
 struct label *p_label;
 struct { struct ktr_request *stqh_first; struct ktr_request **stqh_last; } p_ktr;
 struct { struct mqueue_notifier *lh_first; } p_mqnotifier;
 struct kdtrace_proc *p_dtrace;
 struct cv p_pwait;
 struct racct *p_racct;
 int p_throttled;






 struct { struct proc *le_next; struct proc **le_prev; } p_orphan;
 struct { struct proc *lh_first; } p_orphans;

 struct { struct kq_timer_cb_data *tqh_first; struct kq_timer_cb_data **tqh_last; } p_kqtim_stop;
 struct { struct proc *le_next; struct proc **le_prev; } p_jaillist;
 u_int p_asig;
 u_int p_tree_refcnt;
 u_int p_execblock;
};
typedef void (*ich_func_t)(void *_arg);
struct intr_config_hook {
 struct { struct intr_config_hook *stqe_next; } ich_links;
 uintptr_t ich_state;
 ich_func_t ich_func;
 void *ich_arg;
};
struct snapdata;
struct cdevsw;
struct file;
struct cdev {
 void *si_spare0;
 u_int si_flags;
 struct timespec si_atime;
 struct timespec si_ctime;
 struct timespec si_mtime;
 uid_t si_uid;
 gid_t si_gid;
 mode_t si_mode;
 struct ucred *si_cred;
 int si_drv0;
 int si_refcount;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_list;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_clone;
 struct { struct cdev *lh_first; } si_children;
 struct { struct cdev *le_next; struct cdev **le_prev; } si_siblings;
 struct cdev *si_parent;
 struct mount *si_mountpt;
 void *si_drv1, *si_drv2;
 struct cdevsw *si_devsw;
 int si_iosize_max;
 u_long si_usecount;
 u_long si_threadcount;
 union {
  struct snapdata *__sid_snapdata;
 } __si_u;
 char si_name[255 + 1];
};
struct bio;
struct buf;
struct thread;
struct uio;
struct knote;
struct vm_object;
struct vnode;
typedef int d_open_t(struct cdev *dev, int oflags, int devtype, struct thread *td);
typedef int d_fdopen_t(struct cdev *dev, int oflags, struct thread *td, struct file *fp);
typedef int d_close_t(struct cdev *dev, int fflag, int devtype, struct thread *td);
typedef void d_strategy_t(struct bio *bp);
typedef int d_ioctl_t(struct cdev *dev, u_long cmd, caddr_t data,
        int fflag, struct thread *td);
typedef int d_read_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_write_t(struct cdev *dev, struct uio *uio, int ioflag);
typedef int d_poll_t(struct cdev *dev, int events, struct thread *td);
typedef int d_kqfilter_t(struct cdev *dev, struct knote *kn);
typedef int d_mmap_t(struct cdev *dev, vm_ooffset_t offset, vm_paddr_t *paddr,
       int nprot, vm_memattr_t *memattr);
typedef int d_mmap_single_t(struct cdev *cdev, vm_ooffset_t *offset,
    vm_size_t size, struct vm_object **object, int nprot);
typedef void d_purge_t(struct cdev *dev);
struct cdevsw {
 int d_version;
 u_int d_flags;
 const char *d_name;
 d_open_t *d_open;
 d_fdopen_t *d_fdopen;
 d_close_t *d_close;
 d_read_t *d_read;
 d_write_t *d_write;
 d_ioctl_t *d_ioctl;
 d_poll_t *d_poll;
 d_mmap_t *d_mmap;
 d_strategy_t *d_strategy;
 void *d_spare0;
 d_kqfilter_t *d_kqfilter;
 d_purge_t *d_purge;
 d_mmap_single_t *d_mmap_single;

 int32_t d_spare1[3];
 void *d_spare2[3];


 struct { struct cdev *lh_first; } d_devs;
 int d_spare3;
 union {
  struct cdevsw *gianttrick;
  struct { struct cdevsw *sle_next; } postfree_list;
 } __d_giant;
};
typedef u_char vm_prot_t;
struct vm_map_entry;
struct vm_map;
typedef struct vm_map *vm_map_t;
struct vm_object;
struct ucred;
struct filedesc;
struct proc;
struct stat;
struct thread;
struct uio;
struct knote;
struct vnode;
struct file;
struct kaiocb;
struct kinfo_file;
struct ucred;
typedef int fo_rdwr_t(struct file *fp, struct uio *uio,
      struct ucred *active_cred, int flags,
      struct thread *td);
typedef int fo_truncate_t(struct file *fp, off_t length,
      struct ucred *active_cred, struct thread *td);
typedef int fo_ioctl_t(struct file *fp, u_long com, void *data,
      struct ucred *active_cred, struct thread *td);
typedef int fo_poll_t(struct file *fp, int events,
      struct ucred *active_cred, struct thread *td);
typedef int fo_kqfilter_t(struct file *fp, struct knote *kn);
typedef int fo_stat_t(struct file *fp, struct stat *sb,
      struct ucred *active_cred);
typedef int fo_close_t(struct file *fp, struct thread *td);
typedef void fo_fdclose_t(struct file *fp, int fd, struct thread *td);
typedef int fo_chmod_t(struct file *fp, mode_t mode,
      struct ucred *active_cred, struct thread *td);
typedef int fo_chown_t(struct file *fp, uid_t uid, gid_t gid,
      struct ucred *active_cred, struct thread *td);
typedef int fo_sendfile_t(struct file *fp, int sockfd, struct uio *hdr_uio,
      struct uio *trl_uio, off_t offset, size_t nbytes,
      off_t *sent, int flags, struct thread *td);
typedef int fo_seek_t(struct file *fp, off_t offset, int whence,
      struct thread *td);
typedef int fo_fill_kinfo_t(struct file *fp, struct kinfo_file *kif,
      struct filedesc *fdp);
typedef int fo_mmap_t(struct file *fp, vm_map_t map, vm_offset_t *addr,
      vm_size_t size, vm_prot_t prot, vm_prot_t cap_maxprot,
      int flags, vm_ooffset_t foff, struct thread *td);
typedef int fo_aio_queue_t(struct file *fp, struct kaiocb *job);
typedef int fo_add_seals_t(struct file *fp, int flags);
typedef int fo_get_seals_t(struct file *fp, int *flags);
typedef int fo_fallocate_t(struct file *fp, off_t offset, off_t len,
      struct thread *td);
typedef int fo_fspacectl_t(struct file *fp, int cmd,
      off_t *offset, off_t *length, int flags,
      struct ucred *active_cred, struct thread *td);
typedef int fo_cmp_t(struct file *fp, struct file *fp1, struct thread *td);
typedef int fo_fork_t(struct filedesc *fdp, struct file *fp, struct file **fp1,
      struct proc *p1, struct thread *td);
typedef int fo_spare_t(struct file *fp);
typedef int fo_flags_t;
struct fileops {
 fo_rdwr_t *fo_read;
 fo_rdwr_t *fo_write;
 fo_truncate_t *fo_truncate;
 fo_ioctl_t *fo_ioctl;
 fo_poll_t *fo_poll;
 fo_kqfilter_t *fo_kqfilter;
 fo_stat_t *fo_stat;
 fo_close_t *fo_close;
 fo_fdclose_t *fo_fdclose;
 fo_chmod_t *fo_chmod;
 fo_chown_t *fo_chown;
 fo_sendfile_t *fo_sendfile;
 fo_seek_t *fo_seek;
 fo_fill_kinfo_t *fo_fill_kinfo;
 fo_mmap_t *fo_mmap;
 fo_aio_queue_t *fo_aio_queue;
 fo_add_seals_t *fo_add_seals;
 fo_get_seals_t *fo_get_seals;
 fo_fallocate_t *fo_fallocate;
 fo_fspacectl_t *fo_fspacectl;
 fo_cmp_t *fo_cmp;
 fo_fork_t *fo_fork;
 fo_spare_t *fo_spares[7];
 fo_flags_t fo_flags;
};
struct fadvise_info {
 int fa_advice;
 off_t fa_start;
 off_t fa_end;
};
struct file {
 volatile u_int f_flag;
 volatile u_int f_count;
 void *f_data;
 const struct fileops *f_ops;
 struct vnode *f_vnode;
 struct ucred *f_cred;
 short f_type;
 short f_vflags;



 union {
  int16_t f_seqcount[2];
  int f_pipegen;
 };
 off_t f_nextoff[2];
 union {
  struct cdev_privdata *fvn_cdevpriv;

  struct fadvise_info *fvn_advice;
 } f_vnun;



 off_t f_offset;
};
static __inline fo_rdwr_t fo_read;
static __inline fo_rdwr_t fo_write;
static __inline fo_truncate_t fo_truncate;
static __inline fo_ioctl_t fo_ioctl;
static __inline fo_poll_t fo_poll;
static __inline fo_kqfilter_t fo_kqfilter;
static __inline fo_stat_t fo_stat;
static __inline fo_close_t fo_close;
static __inline fo_chmod_t fo_chmod;
static __inline fo_chown_t fo_chown;
static __inline fo_sendfile_t fo_sendfile;
static __inline int
fo_read(struct file *fp, struct uio *uio, struct ucred *active_cred,
    int flags, struct thread *td)
;
static __inline int
fo_write(struct file *fp, struct uio *uio, struct ucred *active_cred,
    int flags, struct thread *td)
;
static __inline int
fo_truncate(struct file *fp, off_t length, struct ucred *active_cred,
    struct thread *td)
;
static __inline int
fo_ioctl(struct file *fp, u_long com, void *data, struct ucred *active_cred,
    struct thread *td)
;
static __inline int
fo_poll(struct file *fp, int events, struct ucred *active_cred,
    struct thread *td)
;
static __inline int
fo_stat(struct file *fp, struct stat *sb, struct ucred *active_cred)
;
static __inline int
fo_close(struct file *fp, struct thread *td)
;
static __inline int
fo_kqfilter(struct file *fp, struct knote *kn)
;
static __inline int
fo_chmod(struct file *fp, mode_t mode, struct ucred *active_cred,
    struct thread *td)
;
static __inline int
fo_chown(struct file *fp, uid_t uid, gid_t gid, struct ucred *active_cred,
    struct thread *td)
;
static __inline int
fo_sendfile(struct file *fp, int sockfd, struct uio *hdr_uio,
    struct uio *trl_uio, off_t offset, size_t nbytes, off_t *sent, int flags,
    struct thread *td)
;
static __inline int
fo_seek(struct file *fp, off_t offset, int whence, struct thread *td)
;
static __inline int
fo_fill_kinfo(struct file *fp, struct kinfo_file *kif, struct filedesc *fdp)
;
static __inline int
fo_mmap(struct file *fp, vm_map_t map, vm_offset_t *addr, vm_size_t size,
    vm_prot_t prot, vm_prot_t cap_maxprot, int flags, vm_ooffset_t foff,
    struct thread *td)
;
static __inline int
fo_aio_queue(struct file *fp, struct kaiocb *job)
;
static __inline int
fo_add_seals(struct file *fp, int seals)
;
static __inline int
fo_get_seals(struct file *fp, int *seals)
;
static __inline int
fo_fallocate(struct file *fp, off_t offset, off_t len, struct thread *td)
;
static __inline int
fo_fspacectl(struct file *fp, int cmd, off_t *offset, off_t *length,
    int flags, struct ucred *active_cred, struct thread *td)
;
static __inline int
fo_cmp(struct file *fp1, struct file *fp2, struct thread *td)
;
struct iovec {
 void *iov_base;
 size_t iov_len;
};
enum uio_rw {
 UIO_READ,
 UIO_WRITE
};
enum uio_seg {
 UIO_USERSPACE,
 UIO_SYSSPACE,
 UIO_NOCOPY
};
struct uio {
 struct iovec *uio_iov;
 int uio_iovcnt;
 off_t uio_offset;
 ssize_t uio_resid;
 enum uio_seg uio_segflg;
 enum uio_rw uio_rw;
 struct thread *uio_td;
};
struct vm_object;
struct vm_page;
struct domainset;
typedef uint64_t bus_addr_t;
typedef uint64_t bus_space_tag_t;
typedef uint64_t bus_space_handle_t;
typedef struct bus_dma_tag *bus_dma_tag_t;
typedef struct bus_dmamap *bus_dmamap_t;
typedef struct kobj *kobj_t;
typedef struct kobj_class *kobj_class_t;
typedef const struct kobj_method kobj_method_t;
typedef void (*kobjop_t)(void);
typedef struct kobj_ops *kobj_ops_t;
typedef struct kobjop_desc *kobjop_desc_t;
struct kobj_method {
 kobjop_desc_t desc;
 kobjop_t func;
};
struct kobj_class {
 const char *name; kobj_method_t *methods; size_t size; kobj_class_t *baseclasses; u_int refs; kobj_ops_t ops;
};
struct kobj {
 kobj_ops_t ops;
};
struct kobj_ops {
 kobj_method_t *cache[256];
 kobj_class_t cls;
};
struct kobjop_desc {
 unsigned int id;
 kobj_method_t deflt;
};
struct resource;
int device_printf(device_t dev, const char *, ...) ;
struct bio;
struct uio;
struct resource {
 struct resource_i *__r_i;
 bus_space_tag_t r_bustag;
 bus_space_handle_t r_bushandle;
};
struct resource_i;
struct file;
struct prison;
struct uio;
struct thread;
struct sysctl_req {
 struct thread *td;
 int lock;
 void *oldptr;
 size_t oldlen;
 size_t oldidx;
 int (*oldfunc)(struct sysctl_req *, const void *, size_t);
 const void *newptr;
 size_t newlen;
 size_t newidx;
 int (*newfunc)(struct sysctl_req *, void *, size_t);
 size_t validlen;
 int flags;
};
struct sysctl_oid;
struct sysctl_oid_list { struct sysctl_oid *rbh_root; };
struct sysctl_oid {
 struct sysctl_oid_list oid_children;
 struct sysctl_oid_list* oid_parent;
 struct { struct sysctl_oid *rbe_link[3]; } oid_link;

 int oid_number;
 u_int oid_kind;
 void *oid_arg1;
 intmax_t oid_arg2;

 const char *oid_name;
 int (*oid_handler)(struct sysctl_oid *oidp, void *arg1, intmax_t arg2, struct sysctl_req *req);
 const char *oid_fmt;
 int oid_refcnt;
 u_int oid_running;
 const char *oid_descr;
 const char *oid_label;
};
struct sysctl_ctx_entry {
 struct sysctl_oid *entry;
 struct { struct sysctl_ctx_entry *tqe_next; struct sysctl_ctx_entry **tqe_prev; } link;
};
struct sysctl_ctx_list { struct sysctl_ctx_entry *tqh_first; struct sysctl_ctx_entry **tqh_last; };
struct thread;
struct thread;
struct pcmchan_matrix {
 int id;
 uint8_t channels, ext;
 struct {
  int type;
  uint32_t members;
 } map[18 + 1];
 uint32_t mask;
 int8_t offset[18];
};
struct pcm_channel;
struct pcmchan_syncgroup;
struct pcmchan_syncmember;
struct pcmchan_syncgroup {
 struct { struct pcmchan_syncgroup *sle_next; } link;
 struct { struct pcmchan_syncmember *slh_first; } members;
 int id;
};
struct pcmchan_syncmember {
 struct { struct pcmchan_syncmember *sle_next; } link;
 struct pcmchan_syncgroup *parent;
 struct pcm_channel *ch;
};
struct pcm_channel {
 kobj_t methods;

 pid_t pid;
 struct pcm_feeder *feeder;
 u_int32_t align;

 int latency;
 u_int32_t speed;
 u_int32_t format;
 u_int32_t flags;
 u_int32_t feederflags;
 u_int64_t blocks;

 int direction;
 unsigned int interrupts, xruns, feedcount;
 unsigned int timeout;
 struct snd_dbuf *bufhard, *bufsoft;
 struct snddev_info *parentsnddev;
 struct pcm_channel *parentchannel;
 void *devinfo;
 device_t dev;
 int unit;
 int type;
 char name[32];
 char comm[19 + 1];
 struct mtx lock;
 int trigger;



 struct cv intr_cv;




 unsigned int inprog;

 unsigned int sleeping;





 struct cv cv;







 unsigned int lw;




 struct pcmchan_syncmember *sm;




 struct {
  struct { struct pcm_channel *slh_first; } head;
  struct { struct pcm_channel *sle_next; } link;
  struct {
   struct { struct pcm_channel *slh_first; } head;
   struct { struct pcm_channel *sle_next; } link;
  } busy;
 } children;

 struct {
  struct {
   struct { struct pcm_channel *sle_next; } link;
   struct {
    struct { struct pcm_channel *sle_next; } link;
   } busy;
   struct {
    struct { struct pcm_channel *sle_next; } link;
   } opened;
   struct {
    struct { struct pcm_channel *sle_next; } link;
   } primary;
  } pcm;
 } channels;

 struct pcmchan_matrix matrix;
   struct pcmchan_matrix matrix_scratch;

 int16_t volume[3][(18 + 1)];
   int8_t muted[3][(18 + 1)];
};
enum feeder_type {
 FEEDER_ROOT,
 FEEDER_FORMAT,
 FEEDER_MIXER,
 FEEDER_RATE,
 FEEDER_EQ,
 FEEDER_VOLUME,
 FEEDER_MATRIX,
 FEEDER_LAST,
};
struct pcm_feederdesc {
 u_int32_t in, out;
};
struct feeder_class {
 const char *name; kobj_method_t *methods; size_t size; kobj_class_t *baseclasses; u_int refs; kobj_ops_t ops;
 enum feeder_type type;
 struct { struct feeder_class *sle_next; } link;
};
struct pcm_feeder {
     kobj_ops_t ops;
 struct pcm_feederdesc desc;
 void *data;
 struct feeder_class *class;
 struct pcm_feeder *source, *parent;
};
struct snd_dbuf {
 u_int8_t *buf, *tmpbuf;
 u_int8_t *shadbuf;
 volatile int sl;
 unsigned int bufsize, maxsize, allocsize;
 volatile int dl;
 volatile int rp;
 volatile int rl;
 volatile int hp;
 volatile u_int64_t total, prev_total;
 int dmachan;
 u_int32_t fmt, spd, bps, align;
 unsigned int blksz, blkcnt;
 int xrun;
 u_int32_t flags;
 bus_dmamap_t dmamap;
 bus_dma_tag_t dmatag;
 bus_addr_t buf_addr;
 int dmaflags;
 unsigned int refcount;
 struct selinfo sel;
 struct pcm_channel *channel;
 char name[48];
};
struct snddev_info {
 struct {
  struct {
   struct { struct pcm_channel *slh_first; } head;
   struct {
    struct { struct pcm_channel *slh_first; } head;
   } busy;
   struct {
    struct { struct pcm_channel *slh_first; } head;
   } opened;
   struct {
    struct { struct pcm_channel *slh_first; } head;
   } primary;
  } pcm;
 } channels;
 unsigned playcount, reccount, pvchancount, rvchancount;
 unsigned flags;
 void *devinfo;
 device_t dev;
 char status[64];
 struct mtx lock;
 struct cdev *mixer_dev;
 struct cdev *dsp_dev;
 uint32_t pvchanrate, pvchanformat, pvchanmode;
 uint32_t rvchanrate, rvchanformat, rvchanmode;
 int32_t eqpreamp;
 struct sysctl_ctx_list play_sysctl_ctx, rec_sysctl_ctx;
 struct sysctl_oid *play_sysctl_tree, *rec_sysctl_tree;
 struct cv cv;
 struct unrhdr *p_unr;
 struct unrhdr *vp_unr;
 struct unrhdr *r_unr;
 struct unrhdr *vr_unr;
};
struct ac97_info;
struct ich_desc {
 volatile uint32_t buffer;
 volatile uint32_t length;
};
struct sc_info;
struct sc_chinfo {
 uint32_t num:8, run:1, run_save:1;
 uint32_t blksz, blkcnt, spd;
 uint32_t regbase, spdreg;
 uint32_t imask;
 uint32_t civ;

 struct snd_dbuf *buffer;
 struct pcm_channel *channel;
 struct sc_info *parent;

 struct ich_desc *dtbl;
 bus_addr_t desc_addr;
};
struct sc_info {
 device_t dev;
 int hasvra, hasvrm, hasmic;
 unsigned int chnum, bufsz, blkcnt;
 int sample_size, swap_reg;

 struct resource *nambar, *nabmbar, *irq;
 int regtype, nambarid, nabmbarid, irqid;
 bus_space_tag_t nambart, nabmbart;
 bus_space_handle_t nambarh, nabmbarh;
 bus_dma_tag_t dmat, chan_dmat;
 bus_dmamap_t dtmap;
 void *ih;

 struct ac97_info *codec;
 struct sc_chinfo ch[3];
 int ac97rate;
 struct ich_desc *dtbl;
 unsigned int dtbl_size;
 bus_addr_t desc_addr;
 struct intr_config_hook intrhook;
 uint16_t vendor;
 uint16_t devid;
 uint32_t flags;
 struct mtx ich_lock;
};
static __inline uint32_t
ich_rd(struct sc_info *sc, int regno, int size)
;
/*@ requires \true; ensures (\result == 0 || \result == 60) && (\result == 0 || (sc->flags & (1 << 1)) == 0); */

static int
ich_waitcd(void *devinfo)
{
 struct sc_info *sc = (struct sc_info *)devinfo;
 uint32_t data;
 int i;

 for (i = 0; i < 1000; i++) {
  data = ich_rd(sc, 0x34, 1);
  if ((data & 0x01) == 0)
   return (0);
  DELAY(1);
 }
 if ((sc->flags & (1 << 1)) != 0)
  return (0);
 device_printf(sc->dev, "CODEC semaphore timeout\n");
 return (60);
}
