typedef unsigned int __u32;
__extension__ typedef unsigned long long __u64;
typedef __u32 u32;
typedef __u64 u64;
typedef u64 dma_addr_t;
typedef u64 gen8_pte_t;
u64 gen8_ggtt_pte_encode(dma_addr_t addr,
    unsigned int pat_index,
    u32 flags);
/*@ requires addr >= 0; ensures \result == (addr | ((((1ULL))) << (0)) | ((flags & ((((1UL))) << (1))) ? ((((1ULL))) << (1)) : 0)); */

u64 gen8_ggtt_pte_encode(dma_addr_t addr,
    unsigned int pat_index,
    u32 flags)
{
 gen8_pte_t pte = addr | ((((1ULL))) << (0));

 if (flags & ((((1UL))) << (1)))
  pte |= ((((1ULL))) << (1));

 return pte;
}
