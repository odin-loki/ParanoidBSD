enum fun_xcvr_type {
 FUN_XCVR_BASET = 0x0,
 FUN_XCVR_CU = 0x1,
 FUN_XCVR_SMF = 0x2,
 FUN_XCVR_MMF = 0x3,
 FUN_XCVR_AOC = 0x4,
 FUN_XCVR_SFPP = 0x10,
 FUN_XCVR_QSFPP = 0x11,
 FUN_XCVR_QSFPDD = 0x12,
};
/*@ requires 0 <= xcvr <= 4294967295; ensures (xcvr == 0 ==> \result == 0xef) && ((xcvr & 7) == FUN_XCVR_BASET ==> \result == 0x00) && ((xcvr & 7) == FUN_XCVR_CU ==> \result == 0x05) && (xcvr != 0 && (xcvr & 7) != FUN_XCVR_BASET && (xcvr & 7) != FUN_XCVR_CU ==> \result == 0x03); */

static unsigned int fun_port_type(unsigned int xcvr)
{
 if (!xcvr)
  return 0xef;

 switch (xcvr & 7) {
 case FUN_XCVR_BASET:
  return 0x00;
 case FUN_XCVR_CU:
  return 0x05;
 default:
  return 0x03;
 }
}
