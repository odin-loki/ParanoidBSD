typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
/*@ requires true; ensures \result == ps / 1000; */

static u32 tc358768_ps_to_ns(u32 ps)
{
 return ps / 1000;
}
