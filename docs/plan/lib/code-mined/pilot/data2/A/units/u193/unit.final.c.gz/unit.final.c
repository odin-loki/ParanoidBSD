typedef unsigned int __u32;
typedef __u32 u32;
enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires true; ensures \result == ((fifo_sta & ((((1UL))) << (2))) != 0); */

static inline    bool mcp251xfd_tx_fifo_sta_empty(u32 fifo_sta)
{
 return fifo_sta & ((((1UL))) << (2));
}
