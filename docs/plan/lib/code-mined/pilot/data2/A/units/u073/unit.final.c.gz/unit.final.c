enum {
 false = 0,
 true = 1
};
typedef _Bool bool;
/*@ requires \true; ensures \result == 1 <==> (expected_len == attr_len || expected_len == -1 || expected_len == -2); */

static bool check_attr_len(unsigned int attr_len, unsigned int expected_len)
{
 return expected_len == attr_len ||
        expected_len == -1 ||
        expected_len == -2;
}
