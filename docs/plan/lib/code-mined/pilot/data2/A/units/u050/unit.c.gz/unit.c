/*@ requires c <= 1 && a < 67108864 && b < 67108864; ensures \result == (a + b + c) / 67108864 && *low == (a + b + c) % 67108864; */

static __always_inline u8
addcarryx_u26(u8 c, u32 a, u32 b, u32 *low)
{



 u32 x = a + b + c;
 *low = x & ((1 << 26) - 1);
 return (x >> 26) & 1;
}
