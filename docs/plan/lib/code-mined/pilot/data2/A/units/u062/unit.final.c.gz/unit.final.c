enum {
 false = 0,
 true = 1
};
static int  ad5446_spi_register_driver(void)
;
static void ad5446_spi_unregister_driver(void)
;
static int  ad5446_i2c_register_driver(void)
;
/*@ requires true; ensures (\result == 0 || \result < 0); */

static int  ad5446_init(void)
{
 int ret;

 ret = ad5446_spi_register_driver();
 if (ret)
  return ret;

 ret = ad5446_i2c_register_driver();
 if (ret) {
  ad5446_spi_unregister_driver();
  return ret;
 }

 return 0;
}
